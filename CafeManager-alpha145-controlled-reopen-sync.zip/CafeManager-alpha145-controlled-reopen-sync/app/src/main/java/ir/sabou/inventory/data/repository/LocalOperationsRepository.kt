package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryCountEntity
import ir.sabou.inventory.data.db.InventoryLotConsumptionEntity
import ir.sabou.inventory.data.db.InventoryPeriodClosureEntity
import ir.sabou.inventory.data.db.InventoryPeriodClosureLineEntity
import ir.sabou.inventory.data.db.AuditLogEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.db.SupplierEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryCountRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodCloseDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodReopenDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureDetails
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureLineRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodCalculator
import ir.sabou.inventory.domain.operations.AuditLogRecord
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.InventoryUsageInsight
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.operations.PurchaseSummary
import ir.sabou.inventory.domain.operations.SupplierPriceInsight
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.SupplierRecord
import ir.sabou.inventory.domain.operations.WasteDraft
import ir.sabou.inventory.domain.operations.WasteRecord
import java.math.BigInteger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.combine

class LocalOperationsRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : OperationsRepository {
    override val suppliers: Flow<List<SupplierRecord>> =
        database.supplierDao().observeActive().map { rows -> rows.map(SupplierEntity::toRecord) }

    override val inventoryItems: Flow<List<InventoryItemRecord>> =
        database.inventoryDao().observeActive().map { rows -> rows.map(InventoryItemEntity::toRecord) }

    override val lowStockItems: Flow<List<InventoryItemRecord>> =
        database.inventoryDao().observeLowStock().map { rows -> rows.map(InventoryItemEntity::toRecord) }

    override val inventoryCounts: Flow<List<InventoryCountRecord>> =
        database.inventoryControlDao().observeRecentCounts().map { rows -> rows.map { InventoryCountRecord(it.id, it.itemId, it.previousQuantityMicros, it.countedQuantityMicros, it.previousValueRial, it.countedValueRial, it.countEpochDay, it.reason) } }

    override val inventoryPeriodClosures: Flow<List<InventoryPeriodClosureRecord>> =
        database.inventoryControlDao().observeClosures().map { rows ->
            rows.map { it.toRecord() }
        }

    override fun inventoryPeriodClosureDetails(closureId: Long): Flow<InventoryPeriodClosureDetails?> = combine(
        database.inventoryControlDao().observeClosure(closureId),
        database.inventoryControlDao().observeClosureLines(closureId),
    ) { closure, lines ->
        closure?.let {
            InventoryPeriodClosureDetails(
                closure = it.toRecord(),
                lines = lines.map { line ->
                    InventoryPeriodClosureLineRecord(
                        line.itemId, line.itemNameSnapshot, line.unitSnapshot,
                        line.openingQuantityMicros, line.openingValueRial,
                        line.netPurchaseQuantityMicros, line.netPurchaseValueRial,
                        line.recordedOutflowQuantityMicros, line.recordedOutflowValueRial,
                        line.adjustmentQuantityMicros, line.adjustmentValueRial,
                        line.expectedClosingQuantityMicros, line.expectedClosingValueRial,
                        line.countedClosingQuantityMicros, line.countedClosingValueRial,
                    )
                },
            )
        }
    }

    override val auditLogs: Flow<List<AuditLogRecord>> =
        database.auditLogDao().observeRecent().map { rows -> rows.map { AuditLogRecord(it.id, it.action, it.entityType, it.entityId, it.description, it.actor, it.createdAtEpochMillis) } }

    override val usageInsights: Flow<List<InventoryUsageInsight>> =
        database.stockMovementDao().observeUsageSince((clock() / 86_400_000L) - 29L).map { rows ->
            rows.map { row ->
                InventoryUsageInsight(
                    itemId = row.itemId,
                    itemName = row.itemName,
                    unit = row.unit,
                    usageMicros30Days = row.usageMicros,
                    averageDailyUsageMicros = row.usageMicros / 30L,
                )
            }
        }

    override val supplierPriceInsights: Flow<List<SupplierPriceInsight>> =
        database.purchaseDao().observeSupplierPriceInsights().map { rows ->
            rows.map { row ->
                SupplierPriceInsight(
                    itemId = row.itemId,
                    itemName = row.itemName,
                    supplierName = row.supplierName,
                    latestUnitCostRial = row.latestUnitCostRial,
                    previousUnitCostRial = row.previousUnitCostRial,
                )
            }
        }

    override val wasteRecords: Flow<List<WasteRecord>> =
        database.stockMovementDao().observeWasteRecords().map { rows ->
            rows.map { row ->
                WasteRecord(
                    id = row.id,
                    itemId = row.itemId,
                    itemName = row.itemName,
                    unit = row.unit,
                    quantityMicros = row.quantityMicros,
                    valueRial = row.valueRial,
                    wasteEpochDay = row.wasteEpochDay,
                    reason = row.reason,
                )
            }
        }

    override fun purchases(query: String): Flow<List<PurchaseSummary>> =
        database.purchaseDao().observeSearch(query.trim()).map { rows ->
            rows.map { row ->
                PurchaseSummary(
                    id = row.purchaseId,
                    invoiceNo = row.invoiceNo,
                    supplierName = row.supplierName,
                    purchaseEpochDay = row.purchaseEpochDay,
                    dueEpochDay = row.dueEpochDay,
                    totalRial = row.totalRial,
                    paidRial = row.paidRial,
                    isPaid = row.paymentStatus == "PAID",
                    paymentStatus = row.paymentStatus,
                    paymentMethod = row.paymentMethod,
                    reminderEnabled = row.reminderEnabled,
                    reminderEpochDay = row.reminderEpochDay,
                )
            }
        }

    override suspend fun createSupplier(draft: SupplierDraft): Long {
        authorizer.require("SUPPLIERS")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val previous = database.supplierDao().byName(valid.name)
            if (previous != null) {
                require(!previous.isActive) { "تأمین‌کننده‌ای با این نام وجود دارد." }
                check(
                    database.supplierDao().update(
                        previous.copy(
                            contactName = valid.contactName,
                            phone = valid.phone,
                            address = valid.address,
                            paymentTermsDays = valid.paymentTermsDays,
                            notes = valid.notes,
                            isActive = true,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "فعال‌سازی دوباره تأمین‌کننده انجام نشد." }
                syncRecorder?.record("SUPPLIER", previous.id, "UPSERT", now)
                return@withTransaction previous.id
            }
            val id = database.supplierDao().insert(
                SupplierEntity(
                    name = valid.name,
                    contactName = valid.contactName,
                    phone = valid.phone,
                    address = valid.address,
                    paymentTermsDays = valid.paymentTermsDays,
                    notes = valid.notes,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("SUPPLIER", id, "CREATE", now)
            id
        }
    }

    override suspend fun updateSupplier(id: Long, draft: SupplierDraft) {
        authorizer.require("SUPPLIERS")
        val current = database.supplierDao().activeById(id)
            ?: error("تأمین‌کننده پیدا نشد.")
        val valid = draft.validated()
        val now = clock()
        check(
            database.supplierDao().update(
                current.copy(
                    name = valid.name,
                    contactName = valid.contactName,
                    phone = valid.phone,
                    address = valid.address,
                    paymentTermsDays = valid.paymentTermsDays,
                    notes = valid.notes,
                    updatedAtEpochMillis = now,
                ),
            ) == 1,
        ) { "ویرایش تأمین‌کننده انجام نشد." }
        syncRecorder?.record("SUPPLIER", id, "UPDATE", now)
    }

    override suspend fun deactivateSupplier(id: Long) {
        authorizer.require("SUPPLIERS")
        database.withTransaction {
            val now = clock()
            check(database.supplierDao().deactivate(id, now) == 1) {
                "حذف تأمین‌کننده انجام نشد."
            }
            database.inventoryDao().clearSupplierReference(id, now)
            syncRecorder?.record("SUPPLIER", id, "DEACTIVATE", now)
        }
    }

    override suspend fun createInventoryItem(draft: InventoryItemDraft): Long {
        authorizer.require("INVENTORY")
        val valid = draft.validated()
        ensureSupplierIsActive(valid.supplierId)
        val now = clock()
        return database.withTransaction {
            val previous = database.inventoryDao().byName(valid.name)
            if (previous != null) {
                require(!previous.isActive) { "کالایی با این نام وجود دارد." }
                check(
                    database.inventoryDao().update(
                        previous.copy(
                            category = valid.category,
                            unit = valid.unit,
                            alertEnabled = valid.alertEnabled,
                            alertThresholdMicros = valid.alertThresholdMicros,
                            supplierId = valid.supplierId,
                            isActive = true,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "فعال‌سازی دوباره کالا انجام نشد." }
                syncRecorder?.record("INVENTORY_ITEM", previous.id, "UPSERT", now)
                return@withTransaction previous.id
            }
            val id = database.inventoryDao().insert(
                InventoryItemEntity(
                    name = valid.name,
                    category = valid.category,
                    unit = valid.unit,
                    alertEnabled = valid.alertEnabled,
                    alertThresholdMicros = valid.alertThresholdMicros,
                    supplierId = valid.supplierId,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("INVENTORY_ITEM", id, "CREATE", now)
            id
        }
    }

    override suspend fun updateInventoryItem(id: Long, draft: InventoryItemDraft) {
        authorizer.require("INVENTORY")
        val current = database.inventoryDao().activeById(id)
            ?: error("کالا پیدا نشد.")
        val valid = draft.validated()
        ensureSupplierIsActive(valid.supplierId)
        val now = clock()
        check(
            database.inventoryDao().update(
                current.copy(
                    name = valid.name,
                    category = valid.category,
                    unit = valid.unit,
                    alertEnabled = valid.alertEnabled,
                    alertThresholdMicros = valid.alertThresholdMicros,
                    supplierId = valid.supplierId,
                    updatedAtEpochMillis = now,
                ),
            ) == 1,
        ) { "ویرایش کالا انجام نشد." }
        syncRecorder?.record("INVENTORY_ITEM", id, "UPDATE", now)
    }

    override suspend fun deactivateInventoryItem(id: Long) {
        authorizer.require("INVENTORY")
        val current = database.inventoryDao().activeById(id)
            ?: error("کالا پیدا نشد.")
        require(current.stockMicros == 0L && current.inventoryValueRial == 0L) {
            "کالای دارای موجودی یا ارزش انبار را نمی‌توان غیرفعال کرد؛ ابتدا موجودی آن را تعیین تکلیف کنید."
        }
        val now = clock()
        check(database.inventoryDao().deactivate(id, now) == 1) {
            "غیرفعال‌سازی کالا انجام نشد؛ اطلاعات آن هم‌زمان تغییر کرده است."
        }
        log("DEACTIVATE", "INVENTORY_ITEM", id, "غیرفعال‌سازی کالا: ${current.name}")
        syncRecorder?.record("INVENTORY_ITEM", id, "DEACTIVATE", now)
    }

    override suspend fun postInventoryCount(draft: InventoryCountDraft): Long {
        authorizer.require("INVENTORY")
        val valid = draft.validated()
        return database.withTransaction {
            val current = database.inventoryDao().activeById(valid.itemId) ?: error("کالا پیدا نشد.")
            val now = clock()
            val countId = database.inventoryControlDao().insertCount(
                InventoryCountEntity(
                    itemId = current.id, previousQuantityMicros = current.stockMicros,
                    countedQuantityMicros = valid.countedQuantityMicros, previousValueRial = current.inventoryValueRial,
                    countedValueRial = valid.countedValueRial, countEpochDay = valid.countEpochDay,
                    reason = valid.reason, createdAtEpochMillis = now,
                ),
            )
            check(database.inventoryDao().updateValuation(current.id, valid.countedQuantityMicros, valid.countedValueRial, now) == 1) { "اصلاح موجودی انجام نشد." }
            val movementId = database.stockMovementDao().insert(StockMovementEntity(
                itemId = current.id, movementType = "INVENTORY_COUNT",
                quantityDeltaMicros = valid.countedQuantityMicros - current.stockMicros,
                valueDeltaRial = valid.countedValueRial - current.inventoryValueRial,
                referenceType = "INVENTORY_COUNT", referenceId = countId,
                movementEpochDay = valid.countEpochDay, notes = valid.reason, createdAtEpochMillis = now,
            ))
            if (valid.countedQuantityMicros < current.stockMicros) {
                val allocatedLots = database.managementControlDao().allocatedQuantity(current.id)
                var remainingLotQuantity = (allocatedLots - valid.countedQuantityMicros).coerceAtLeast(0L)
                for (lot in database.managementControlDao().availableLotsFefo(current.id)) {
                    if (remainingLotQuantity == 0L) break
                    val consumed = minOf(remainingLotQuantity, lot.quantityMicros)
                    check(database.managementControlDao().updateLot(lot.copy(quantityMicros = lot.quantityMicros - consumed, updatedAtEpochMillis = now)) == 1)
                    database.managementControlDao().insertLotConsumption(InventoryLotConsumptionEntity(stockMovementId = movementId, lotId = lot.id, quantityMicros = consumed))
                    remainingLotQuantity -= consumed
                }
            }
            database.auditLogDao().insert(AuditLogEntity(action="INVENTORY_COUNT", entityType="INVENTORY_ITEM", entityId=current.id, description="انبارگردانی ${current.name}: ${current.stockMicros} → ${valid.countedQuantityMicros}", actor=authorizer.actor(), createdAtEpochMillis=now))
            countId
        }
    }

    override suspend fun closeInventoryPeriod(draft: InventoryPeriodCloseDraft): Long {
        authorizer.require("INVENTORY")
        val valid = draft.validated()
        return database.withTransaction {
            val control = database.inventoryControlDao()
            val previousClosure = control.closureByRange(valid.fromEpochDay, valid.toEpochDay)
            require(previousClosure?.status != "CLOSED") { "این دوره قبلاً بسته شده است." }
            require(!control.closureOverlaps(valid.fromEpochDay, valid.toEpochDay)) { "این بازه با دوره بسته‌شده دیگری هم‌پوشانی دارد." }
            control.lastClosedEpochDay()?.let { lastDay ->
                require(valid.fromEpochDay == lastDay + 1L) { "دوره جدید باید از روز بعد آخرین دوره بسته‌شده شروع شود." }
            }
            val items = database.inventoryDao().activeItems()
            require(items.isNotEmpty()) { "برای بستن دوره، کالای فعال وجود ندارد." }
            val latestCounts = control.countsOnDay(valid.toEpochDay)
                .groupBy { it.itemId }
                .mapValues { (_, rows) -> rows.maxBy { it.createdAtEpochMillis } }
            val missing = items.filter { latestCounts[it.id] == null }.map { it.name }
            require(missing.isEmpty()) { "ابتدا در تاریخ پایان دوره برای همه کالاها انبارگردانی ثبت کنید: ${missing.take(6).joinToString("، ")}" }
            val stale = items.filter { item ->
                val count = latestCounts.getValue(item.id)
                count.countedQuantityMicros != item.stockMicros || count.countedValueRial != item.inventoryValueRial
            }.map { it.name }
            require(stale.isEmpty()) { "پس از آخرین شمارش این کالاها گردش جدید ثبت شده؛ دوباره شمارش کنید: ${stale.take(6).joinToString("، ")}" }
            val totalsByItem = control.movementTotals(valid.fromEpochDay, valid.toEpochDay).associateBy { it.itemId }
            val calculations = items.associateWith { item ->
                val totals = totalsByItem[item.id]
                InventoryPeriodCalculator.calculate(
                    countedClosingQuantityMicros = item.stockMicros,
                    countedClosingValueRial = item.inventoryValueRial,
                    netMovementQuantityMicros = totals?.netQuantityMicros ?: 0,
                    netMovementValueRial = totals?.netValueRial ?: 0,
                    netPurchaseQuantityMicros = totals?.netPurchaseQuantityMicros ?: 0,
                    netPurchaseValueRial = totals?.netPurchaseValueRial ?: 0,
                    countAdjustmentQuantityMicros = totals?.countAdjustmentQuantityMicros ?: 0,
                    countAdjustmentValueRial = totals?.countAdjustmentValueRial ?: 0,
                )
            }
            fun total(selector: (ir.sabou.inventory.domain.operations.InventoryPeriodLineCalculation) -> Long): Long =
                calculations.values.fold(0L) { sum, line -> SignedLongMath.add(sum, selector(line)) }
            val openingValue = total { it.openingValueRial }
            val purchases = total { it.netPurchaseValueRial }
            val outflow = total { it.recordedOutflowValueRial }
            val expected = total { it.expectedClosingValueRial }
            val counted = total { it.countedClosingValueRial }
            val variance = SignedLongMath.subtract(counted, expected)
            val now = clock()
            val refreshed = InventoryPeriodClosureEntity(
                id = previousClosure?.id ?: 0,
                fromEpochDay = valid.fromEpochDay, toEpochDay = valid.toEpochDay,
                openingValueRial = openingValue, netPurchaseValueRial = purchases,
                recordedOutflowValueRial = outflow, expectedClosingValueRial = expected,
                countedClosingValueRial = counted, varianceValueRial = variance,
                itemCount = items.size, status = "CLOSED", revisionNo = (previousClosure?.revisionNo ?: 0) + 1,
                closedBy = authorizer.actor(), note = valid.note,
                createdAtEpochMillis = now,
            )
            val closureId = if (previousClosure == null) {
                control.insertClosure(refreshed)
            } else {
                check(control.updateClosure(refreshed) == 1) { "بستن مجدد دوره انجام نشد." }
                control.deleteClosureLines(previousClosure.id)
                previousClosure.id
            }
            control.insertClosureLines(calculations.map { (item, line) ->
                InventoryPeriodClosureLineEntity(
                    closureId = closureId, itemId = item.id, itemNameSnapshot = item.name, unitSnapshot = item.unit,
                    openingQuantityMicros = line.openingQuantityMicros, openingValueRial = line.openingValueRial,
                    netPurchaseQuantityMicros = line.netPurchaseQuantityMicros, netPurchaseValueRial = line.netPurchaseValueRial,
                    recordedOutflowQuantityMicros = line.recordedOutflowQuantityMicros, recordedOutflowValueRial = line.recordedOutflowValueRial,
                    adjustmentQuantityMicros = line.adjustmentQuantityMicros, adjustmentValueRial = line.adjustmentValueRial,
                    expectedClosingQuantityMicros = line.expectedClosingQuantityMicros, expectedClosingValueRial = line.expectedClosingValueRial,
                    countedClosingQuantityMicros = line.countedClosingQuantityMicros, countedClosingValueRial = line.countedClosingValueRial,
                )
            })
            database.auditLogDao().insert(AuditLogEntity(
                action = "CLOSE", entityType = "INVENTORY_PERIOD", entityId = closureId,
                description = "بستن انبار ${valid.fromEpochDay} تا ${valid.toEpochDay}؛ مغایرت ارزش $variance ریال",
                actor = authorizer.actor(), createdAtEpochMillis = now,
            ))
            syncRecorder?.record("INVENTORY_PERIOD", closureId, "CLOSE", now)
            closureId
        }
    }

    override suspend fun reopenInventoryPeriod(draft: InventoryPeriodReopenDraft) {
        authorizer.requireOwner()
        val valid = draft.validated()
        database.withTransaction {
            val control = database.inventoryControlDao()
            val closure = control.closureById(valid.closureId) ?: error("دوره انبار پیدا نشد.")
            require(closure.status == "CLOSED") { "این دوره در وضعیت بسته نیست." }
            require(control.latestClosedClosure()?.id == closure.id) { "فقط آخرین دوره بسته‌شده قابل بازگشایی است." }
            val actor = authorizer.actor()
            val now = clock()
            check(control.updateClosure(closure.copy(status = "REOPENED", reopenedBy = actor, reopenReason = valid.reason, reopenedAtEpochMillis = now)) == 1) {
                "بازگشایی دوره انبار انجام نشد."
            }
            database.auditLogDao().insert(AuditLogEntity(
                action = "REOPEN", entityType = "INVENTORY_PERIOD", entityId = closure.id,
                description = "بازگشایی کنترل‌شده انبار ${closure.fromEpochDay} تا ${closure.toEpochDay}: ${valid.reason}",
                actor = actor, createdAtEpochMillis = now,
            ))
            syncRecorder?.record("INVENTORY_PERIOD", closure.id, "REOPEN", now)
        }
    }

    override suspend fun postWaste(draft: WasteDraft): Long {
        authorizer.require("INVENTORY")
        val valid = draft.validated()
        return database.withTransaction {
            val current = database.inventoryDao().activeById(valid.itemId)
                ?: error("کالای ضایعات پیدا نشد.")
            require(current.stockMicros >= valid.quantityMicros) {
                "مقدار ضایعات از موجودی ${current.name} بیشتر است."
            }
            val wasteValue = if (current.stockMicros == 0L) 0L else {
                BigInteger.valueOf(current.inventoryValueRial)
                    .multiply(BigInteger.valueOf(valid.quantityMicros))
                    .divide(BigInteger.valueOf(current.stockMicros))
                    .longValueExact()
            }
            val now = clock()
            check(
                database.inventoryDao().updateValuation(
                    current.id,
                    SignedLongMath.subtract(current.stockMicros, valid.quantityMicros),
                    SignedLongMath.subtract(current.inventoryValueRial, wasteValue),
                    now,
                ) == 1,
            ) { "ثبت ضایعات به‌علت تغییر هم‌زمان موجودی انجام نشد." }
            val description = buildString {
                append(valid.reason)
                if (valid.notes.isNotBlank()) append(" — ${valid.notes}")
            }
            val wasteId = database.stockMovementDao().insert(
                StockMovementEntity(
                    itemId = current.id,
                    movementType = "WASTE",
                    quantityDeltaMicros = -valid.quantityMicros,
                    valueDeltaRial = -wasteValue,
                    referenceType = "WASTE",
                    referenceId = 0,
                    movementEpochDay = valid.wasteEpochDay,
                    notes = description,
                    createdAtEpochMillis = now,
                ),
            )
            var remainingLotQuantity = valid.quantityMicros
            for (lot in database.managementControlDao().availableLotsFefo(current.id)) {
                if (remainingLotQuantity == 0L) break
                val consumed = minOf(remainingLotQuantity, lot.quantityMicros)
                check(database.managementControlDao().updateLot(lot.copy(quantityMicros = lot.quantityMicros - consumed, updatedAtEpochMillis = now)) == 1)
                database.managementControlDao().insertLotConsumption(InventoryLotConsumptionEntity(stockMovementId = wasteId, lotId = lot.id, quantityMicros = consumed))
                remainingLotQuantity -= consumed
            }
            if (wasteValue > 0L) {
                check(database.accountingDao().activeAccountExists("6104"))
                check(database.accountingDao().activeAccountExists("1301"))
                val journalId = database.accountingDao().insertEntry(
                    ir.sabou.inventory.data.db.JournalEntryEntity(
                        entryNo = "ض-$wasteId",
                        entryEpochDay = valid.wasteEpochDay,
                        description = "ضایعات ${current.name}: ${valid.reason}",
                        sourceType = "WASTE",
                        sourceId = wasteId,
                        createdAtEpochMillis = now,
                    ),
                )
                database.accountingDao().insertLines(
                    listOf(
                        ir.sabou.inventory.data.db.JournalLineEntity(
                            entryId = journalId, accountCode = "6104", debitRial = wasteValue, creditRial = 0,
                        ),
                        ir.sabou.inventory.data.db.JournalLineEntity(
                            entryId = journalId, accountCode = "1301", debitRial = 0, creditRial = wasteValue,
                        ),
                    ),
                )
            }
            database.auditLogDao().insert(
                AuditLogEntity(
                    action = "WASTE",
                    entityType = "INVENTORY_ITEM",
                    entityId = current.id,
                    description = "ضایعات ${current.name}: ${valid.quantityMicros} میکروواحد · $description",
                    actor = authorizer.actor(),
                    createdAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("WASTE", wasteId, "CREATE", now)
            wasteId
        }
    }

    private fun InventoryPeriodClosureEntity.toRecord() = InventoryPeriodClosureRecord(
        id, fromEpochDay, toEpochDay, openingValueRial, netPurchaseValueRial,
        recordedOutflowValueRial, expectedClosingValueRial, countedClosingValueRial,
        varianceValueRial, itemCount, status, revisionNo, closedBy, note, reopenedBy, reopenReason,
    )

    private suspend fun log(action: String, entityType: String, entityId: Long?, description: String) {
        database.auditLogDao().insert(AuditLogEntity(action=action, entityType=entityType, entityId=entityId, description=description, actor=authorizer.actor(), createdAtEpochMillis=clock()))
    }

    private suspend fun ensureSupplierIsActive(supplierId: Long?) {
        if (supplierId != null) {
            require(database.supplierDao().activeById(supplierId) != null) {
                "تأمین‌کننده انتخاب‌شده فعال نیست."
            }
        }
    }
}

private fun SupplierEntity.toRecord() = SupplierRecord(
    id = id,
    name = name,
    contactName = contactName,
    phone = phone,
    address = address,
    paymentTermsDays = paymentTermsDays,
    notes = notes,
)

private fun InventoryItemEntity.toRecord() = InventoryItemRecord(
    id = id,
    name = name,
    category = category,
    unit = unit,
    stockMicros = stockMicros,
    inventoryValueRial = inventoryValueRial,
    alertEnabled = alertEnabled,
    alertThresholdMicros = alertThresholdMicros,
    supplierId = supplierId,
)
