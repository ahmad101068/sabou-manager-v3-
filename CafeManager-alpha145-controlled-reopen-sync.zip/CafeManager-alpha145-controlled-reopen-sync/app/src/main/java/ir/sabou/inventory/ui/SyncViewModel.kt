package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.data.repository.LocalSyncRepository
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.domain.operations.CloudSyncConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import ir.sabou.inventory.domain.operations.SyncHealth
import ir.sabou.inventory.domain.operations.SyncStatusCalculator
import ir.sabou.inventory.domain.operations.SyncStatusSummary
import ir.sabou.inventory.domain.operations.SyncQueueReport
import ir.sabou.inventory.domain.operations.SyncQueueReporter
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class SyncUiState(val summary: SyncStatusSummary = SyncStatusSummary(0, 0, 0, 0, null, SyncHealth.HEALTHY),val queue:SyncQueueReport=SyncQueueReport(0,0,0,0,null),val config:CloudSyncConfig=CloudSyncConfig("","",false),val message:String?=null,val running:Boolean=false)

class SyncViewModel(private val repository: LocalSyncRepository,private val container:AppContainer) : ViewModel() {
    private val transient=MutableStateFlow(Triple(container.syncConfig(),null as String?,false))
    val state: StateFlow<SyncUiState> = combine(repository.changes,transient) { changes,extra->SyncUiState(SyncStatusCalculator.summarize(changes),SyncQueueReporter.summarize(changes),extra.first,extra.second,extra.third) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SyncUiState())
    fun save(endpoint:String,tenant:String,enabled:Boolean){val value=CloudSyncConfig(endpoint,tenant,enabled);viewModelScope.launch{transient.value=runCatching{container.saveSyncConfig(value);Triple(value,"تنظیمات همگام‌سازی ذخیره شد.",false)}.getOrElse{Triple(value,it.message,false)}}}
    fun runNow(){if(transient.value.third)return;viewModelScope.launch{transient.value=transient.value.copy(third=true);val text=runCatching{container.runSyncAuthorized()}.fold({"${it.uploaded} تغییر همگام شد؛ ${it.conflicts} تعارض"},{it.message?:"همگام‌سازی انجام نشد."});transient.value=transient.value.copy(second=text,third=false)}}
    fun requeueDeadLetters(){viewModelScope.launch{val count=repository.requeueDeadLetters();transient.value=transient.value.copy(second="$count پیام Dead-letter برای تلاش مجدد آماده شد.")}}
    fun clearMessage(){transient.value=transient.value.copy(second=null)}

    companion object {
        fun factory(repository: LocalSyncRepository,container:AppContainer) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = SyncViewModel(repository,container) as T
        }
    }
}
