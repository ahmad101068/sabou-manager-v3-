package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "planned_shifts", indices = [Index("employeeId"), Index("epochDay")])
data class PlannedShiftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val employeeName: String,
    val role: String,
    val epochDay: Long,
    val startMinute: Int,
    val endMinute: Int,
)

@Entity(
    tableName = "purchase_order_follow_ups",
    foreignKeys = [ForeignKey(entity = PurchaseOrderEntity::class, parentColumns = ["id"], childColumns = ["purchaseOrderId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("purchaseOrderId"), Index("createdAtEpochMillis")],
)
data class PurchaseOrderFollowUpEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val purchaseOrderId: Long,
    val note: String,
    val actor: String,
    val createdAtEpochMillis: Long,
)

@Entity(tableName = "storage_locations", indices = [Index(value = ["name"], unique = true), Index("isActive")])
data class StorageLocationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val kind: String,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "inventory_lots",
    foreignKeys = [
        ForeignKey(entity = InventoryItemEntity::class, parentColumns = ["id"], childColumns = ["itemId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = StorageLocationEntity::class, parentColumns = ["id"], childColumns = ["locationId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index(value = ["itemId", "locationId", "lotCode"], unique = true), Index("barcode"), Index("locationId"), Index("expiryEpochDay")],
)
data class InventoryLotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val locationId: Long,
    val lotCode: String,
    val receivedEpochDay: Long,
    val expiryEpochDay: Long?,
    val quantityMicros: Long,
    val unitCostRial: Long,
    val barcode: String?,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "stock_transfers",
    foreignKeys = [
        ForeignKey(entity = StorageLocationEntity::class, parentColumns = ["id"], childColumns = ["sourceLocationId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = StorageLocationEntity::class, parentColumns = ["id"], childColumns = ["destinationLocationId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index(value = ["transferNo"], unique = true), Index("sourceLocationId"), Index("destinationLocationId"), Index("transferEpochDay")],
)
data class StockTransferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transferNo: String,
    val sourceLocationId: Long,
    val destinationLocationId: Long,
    val transferEpochDay: Long,
    val note: String,
    val transferredBy: String,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "stock_transfer_lines",
    foreignKeys = [
        ForeignKey(entity = StockTransferEntity::class, parentColumns = ["id"], childColumns = ["transferId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = InventoryItemEntity::class, parentColumns = ["id"], childColumns = ["itemId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("transferId"), Index("itemId")],
)
data class StockTransferLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transferId: Long,
    val itemId: Long,
    val lotCode: String,
    val quantityMicros: Long,
)

@Entity(
    tableName = "operating_budgets",
    indices = [Index(value = ["name", "fromEpochDay", "toEpochDay"], unique = true), Index("category"), Index("costCenter")],
)
data class OperatingBudgetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val costCenter: String,
    val fromEpochDay: Long,
    val toEpochDay: Long,
    val limitRial: Long,
    val createdBy: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "budget_spend_entries",
    foreignKeys = [ForeignKey(entity = OperatingBudgetEntity::class, parentColumns = ["id"], childColumns = ["budgetId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("budgetId"), Index("spendEpochDay")],
)
data class BudgetSpendEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val budgetId: Long,
    val amountRial: Long,
    val spendEpochDay: Long,
    val reference: String,
    val actor: String,
    val createdAtEpochMillis: Long,
)

@Entity(tableName = "labor_policy")
data class LaborPolicyEntity(
    @PrimaryKey val singletonId: Int = 1,
    val maxWeeklyMinutes: Int,
    val maxShiftMinutes: Int,
    val minimumRestMinutes: Int,
    val breakRequiredAfterMinutes: Int,
    val minimumBreakMinutes: Int,
    val updatedBy: String,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "work_breaks",
    foreignKeys = [ForeignKey(entity = PlannedShiftEntity::class, parentColumns = ["id"], childColumns = ["shiftId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("shiftId")],
)
data class WorkBreakEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val startMinute: Int,
    val endMinute: Int,
    val recordedBy: String,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "employee_availability",
    foreignKeys = [ForeignKey(entity = EmployeeEntity::class, parentColumns = ["id"], childColumns = ["employeeId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index(value = ["employeeId", "dayOfWeek"], unique = true), Index("dayOfWeek")],
)
data class EmployeeAvailabilityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val dayOfWeek: Int,
    val fromMinute: Int,
    val toMinute: Int,
    val isAvailable: Boolean,
    val updatedBy: String,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "shift_swap_requests",
    foreignKeys = [
        ForeignKey(entity = PlannedShiftEntity::class, parentColumns = ["id"], childColumns = ["shiftId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = EmployeeEntity::class, parentColumns = ["id"], childColumns = ["requesterEmployeeId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("shiftId"), Index("requesterEmployeeId"), Index("targetEmployeeId"), Index("status")],
)
data class ShiftSwapRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val shiftId: Long,
    val requesterEmployeeId: Long,
    val targetEmployeeId: Long?,
    val status: String,
    val note: String,
    val reviewedBy: String?,
    val createdAtEpochMillis: Long,
    val reviewedAtEpochMillis: Long?,
)

@Entity(
    tableName = "inventory_lot_consumptions",
    foreignKeys = [
        ForeignKey(entity = StockMovementEntity::class, parentColumns = ["id"], childColumns = ["stockMovementId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = InventoryLotEntity::class, parentColumns = ["id"], childColumns = ["lotId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("stockMovementId"), Index("lotId")],
)
data class InventoryLotConsumptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val stockMovementId: Long,
    val lotId: Long,
    val quantityMicros: Long,
    val reversedQuantityMicros: Long = 0,
)

data class InventoryLotRow(
    val id: Long,
    val itemId: Long,
    val itemName: String,
    val locationId: Long,
    val locationName: String,
    val lotCode: String,
    val receivedEpochDay: Long,
    val expiryEpochDay: Long?,
    val quantityMicros: Long,
    val unitCostRial: Long,
    val barcode: String?,
)

data class BudgetWithSpendRow(
    val id: Long,
    val name: String,
    val category: String,
    val costCenter: String,
    val fromEpochDay: Long,
    val toEpochDay: Long,
    val limitRial: Long,
    val manualSpendRial: Long,
    val automaticSpendRial: Long,
)

data class FoodCostRow(val salesRial: Long, val theoreticalCostRial: Long, val actualCostRial: Long, val wasteCostRial: Long)
data class ShiftBreakRow(val shiftId: Long, val employeeId: Long, val employeeName: String, val epochDay: Long, val startMinute: Int, val endMinute: Int, val breakMinutes: Int)
data class EmployeeAvailabilityRow(val id: Long, val employeeId: Long, val employeeName: String, val dayOfWeek: Int, val fromMinute: Int, val toMinute: Int, val isAvailable: Boolean)
data class ShiftSwapRow(val id: Long, val shiftId: Long, val requesterEmployeeId: Long, val requesterName: String, val targetEmployeeId: Long?, val targetName: String?, val status: String, val note: String)
