package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.accounting.CashFlowCalculator
import ir.sabou.inventory.domain.accounting.CashFlowEvent
import ir.sabou.inventory.domain.operations.ReorderInput
import ir.sabou.inventory.domain.operations.SmartReorderCalculator
import ir.sabou.inventory.domain.operations.RestaurantKpiCalculator

@Composable
fun ReportsCenterScreen(
    dashboard: DashboardSnapshot,
    sales: DailySalesUiState,
    accounting: AccountingUiState,
    operations: OperationsUiState,
    personnel: PersonnelUiState,
    assets: AssetUiState,
    onOpenSales: () -> Unit,
    onOpenAccounting: () -> Unit,
    onOpenInventory: () -> Unit,
    onSetReportRange: (Long, Long) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var showRange by remember { mutableStateOf(false) }
    val netProfit = accounting.profitLoss.netProfitRial
    val liquidity = dashboard.cashBalanceRial + dashboard.bankBalanceRial
    val lowStock = operations.lowStockItems.size
    val openSettlements = operations.settlementAlerts.size
    val salesReport = sales.report
    val kpi = RestaurantKpiCalculator.calculate(
        salesRial = (salesReport?.salesRial ?: 0).coerceAtLeast(0),
        costRial = (salesReport?.costOfGoodsRial ?: 0).coerceAtLeast(0),
        invoiceCount = salesReport?.dayCount ?: 0,
    )
    val cashFlow = CashFlowCalculator.forecast(
        startBalanceRial = liquidity.coerceAtLeast(0),
        events = operations.purchases.filter { it.outstandingRial > 0 }.map {
            CashFlowEvent(it.dueEpochDay, it.outstandingRial, "بدهی ${it.invoiceNo}", incoming = false)
        },
    )
    val reorders = operations.inventoryItems.map { item ->
        val usage = operations.usageInsights.firstOrNull { it.itemId == item.id }
        SmartReorderCalculator.recommend(ReorderInput(
            itemId = item.id, itemName = item.name, unit = item.unit,
            currentStockMicros = item.stockMicros,
            averageDailyUsageMicros = usage?.averageDailyUsageMicros ?: 0,
            minimumStockMicros = item.alertThresholdMicros,
        ))
    }.filter { it.recommendedOrderMicros > 0 }.sortedByDescending { it.urgency.ordinal }
    val payrollCost = personnel.payrolls
        .filter { it.paymentEpochDay in sales.reportFromEpochDay..sales.reportToEpochDay && it.status != "REVERSED" }
        .sumOf { it.netPayRial }
    val laborCostPercent = if (kpi.salesRial <= 0L) 0 else ((payrollCost.toDouble() / kpi.salesRial.toDouble()) * 100.0).toInt()
    val activeAssetBookValue = assets.assets.filter { it.isActive }.sumOf { it.bookValueRial }
    Scaffold(topBar = { ProfessionalTopBar("مرکز گزارش‌ها", "تصمیم‌گیری سریع با شاخص‌های کلیدی", onBack) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PremiumHero("سود خالص بازه", formatMoney(netProfit), "نقدینگی در دسترس ${formatMoney(liquidity)}") }
            item {
                OutlinedButton(onClick = { showRange = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("بازه گزارش: ${epochDayToPersian(sales.reportFromEpochDay).display()} تا ${epochDayToPersian(sales.reportToEpochDay).display()}")
                }
            }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("فروش فعال", formatMoney(sales.activeSalesRial), Modifier.weight(1f)); MetricTile("سود ناخالص", formatMoney(sales.grossProfitRial), Modifier.weight(1f)) } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("روزهای رویداد", (salesReport?.dayCount ?: 0).toString(), Modifier.weight(1f)); MetricTile("ارزش انبار", formatMoney(dashboard.inventoryValueRial), Modifier.weight(1f)) } }
            item {
                OutlinedButton(
                    onClick = {
                        printManagementSummary(
                            context = context,
                            netProfitRial = netProfit,
                            liquidityRial = liquidity,
                            salesRial = sales.activeSalesRial,
                            grossProfitRial = sales.grossProfitRial,
                            receivablesRial = sales.receivablesRial,
                            inventoryRial = dashboard.inventoryValueRial,
                            lowStockCount = lowStock,
                            overdueCount = openSettlements,
                            fromEpochDay = sales.reportFromEpochDay,
                            toEpochDay = sales.reportToEpochDay,
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("چاپ گزارش مدیریتی / PDF") }
            }
            item { SectionHeading("شاخص‌های فروش و منو", "محاسبه زنده از آمار روزانه صندوق و رسپی‌ها") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("حاشیه سود", "${kpi.marginPercent}%", Modifier.weight(1f)); MetricTile("روزهای رویداد", kpi.invoiceCount.toString(), Modifier.weight(1f)) } }
            item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("پیش‌بینی جریان نقدی", fontWeight = FontWeight.ExtraBold)
                ReportAlertRow("مانده پایان دوره", formatMoney(cashFlow.endBalanceRial), cashFlow.endBalanceRial < 0)
                ReportAlertRow("کمترین مانده", formatMoney(cashFlow.minimumBalanceRial), cashFlow.minimumBalanceRial < 0)
                ReportAlertRow("روزهای کسری", "${cashFlow.deficitDays.size} روز", cashFlow.deficitDays.isNotEmpty())
            } } }
            sales.report?.menuPerformance?.takeIf { it.isNotEmpty() }?.let { menu -> item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("مهندسی منو", fontWeight = FontWeight.ExtraBold)
                menu.take(8).forEach { result -> ReportAlertRow(result.name, "${result.quadrant.name} · ${formatMoney(result.grossProfitRial)}", result.grossProfitRial < 0) }
            } } } }
            if (reorders.isNotEmpty()) item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("پیشنهاد سفارش مجدد بر اساس مصرف ۳۰روزه", fontWeight = FontWeight.ExtraBold)
                reorders.take(8).forEach { result -> ReportAlertRow(result.itemName, "${formatQuantity(result.recommendedOrderMicros)} ${result.unit}", true) }
            } } }
            operations.supplierPriceInsights.filter { it.changePercent >= 5 }.takeIf { it.isNotEmpty() }?.let { changes -> item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("هشدار افزایش قیمت خرید", fontWeight = FontWeight.ExtraBold)
                changes.sortedByDescending { it.changePercent }.take(8).forEach { result -> ReportAlertRow(result.itemName, "+${result.changePercent}% · ${result.supplierName}", true) }
            } } } }
            operations.wasteRecords.takeIf { it.isNotEmpty() }?.let { wastes -> item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("کنترل ضایعات", fontWeight = FontWeight.ExtraBold)
                ReportAlertRow("ارزش کل ضایعات ثبت‌شده", formatMoney(wastes.sumOf { it.valueRial }), wastes.sumOf { it.valueRial } > 0)
                wastes.take(5).forEach { waste -> ReportAlertRow(waste.itemName, "${formatQuantity(waste.quantityMicros)} ${waste.unit}", true) }
            } } } }
            item { SectionHeading("نیروی انسانی و دارایی", "کنترل هزینه کار و ظرفیت عملیاتی") }
            item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                ReportAlertRow("نسبت حقوق ثبت‌شده به فروش", "$laborCostPercent%", laborCostPercent > 35)
                ReportAlertRow("مرخصی در انتظار بررسی", "${personnel.pendingLeaves.size} درخواست", personnel.pendingLeaves.isNotEmpty())
                ReportAlertRow("ارزش دفتری دارایی‌های فعال", formatMoney(activeAssetBookValue), false)
            } } }
            item { SectionHeading("نیازمند توجه", "مواردی که بهتر است امروز بررسی شوند") }
            item { Card(shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) { Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) { ReportAlertRow("کالاهای کم‌موجود", "$lowStock مورد", lowStock > 0); ReportAlertRow("تسویه‌های سررسید", "$openSettlements مورد", openSettlements > 0); ReportAlertRow("بدهی تأمین‌کنندگان", formatMoney(dashboard.supplierPayablesRial), dashboard.supplierPayablesRial > 0) } } }
            item { SectionHeading("گزارش‌های تفصیلی", "ورود سریع به تحلیل هر حوزه") }
            item { ReportDestinationCard("فروش و درآمد", "فروش روزانه POS، بهای تمام‌شده و سود ناخالص", "مشاهده فروش", onOpenSales) }
            item { ReportDestinationCard("حسابداری و تراز", "سود و زیان، تراز آزمایشی و اسناد", "ورود به حسابداری", onOpenAccounting) }
            item { ReportDestinationCard("موجودی و تأمین", "ارزش انبار، کمبودها و اصلاح موجودی", "مشاهده انبار", onOpenInventory) }
        }
    }
    if (showRange) {
        ReportsRangeDialog(
            initialFrom = sales.reportFromEpochDay,
            initialTo = sales.reportToEpochDay,
            onDismiss = { showRange = false },
            onApply = { from, to ->
                onSetReportRange(from, to)
                showRange = false
            },
        )
    }
}

@Composable
private fun ReportsRangeDialog(
    initialFrom: Long,
    initialTo: Long,
    onDismiss: () -> Unit,
    onApply: (Long, Long) -> Unit,
) {
    var from by remember(initialFrom) { mutableLongStateOf(initialFrom) }
    var to by remember(initialTo) { mutableLongStateOf(initialTo) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بازه یکپارچه گزارش‌ها") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("فروش، سود ناخالص، سود خالص و نسبت هزینه حقوق با همین بازه محاسبه می‌شوند.")
                PersianDateField("از تاریخ", from, { from = it })
                PersianDateField("تا تاریخ", to, { to = it })
            }
        },
        confirmButton = {
            Button(onClick = { if (from > 0 && to >= from) onApply(from, to) }) { Text("اعمال بازه") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun ReportAlertRow(title: String, value: String, needsAttention: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.SemiBold)
        StatusPill(
            text = value,
            containerColor = if (needsAttention) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
            contentColor = if (needsAttention) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
        )
    }
}

@Composable
private fun ReportDestinationCard(title: String, description: String, action: String, onClick: () -> Unit) {
    Card(
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
            Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(action) }
        }
    }
}
