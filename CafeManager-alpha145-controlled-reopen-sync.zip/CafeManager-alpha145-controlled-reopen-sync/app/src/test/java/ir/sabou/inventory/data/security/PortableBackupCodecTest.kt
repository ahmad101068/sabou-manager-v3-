package ir.sabou.inventory.data.security

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.test.assertContentEquals
import kotlin.test.assertFails
import org.junit.Test

class PortableBackupCodecTest {
    @Test
    fun roundTripPreservesDatabaseAndDatabaseKey() {
        val key = ByteArray(32) { (it * 3).toByte() }
        val database = ByteArray(8_192) { (it % 251).toByte() }
        val encrypted = ByteArrayOutputStream()

        PortableBackupCodec.encrypt(key, ByteArrayInputStream(database), "a strong portable password".toCharArray(), encrypted)

        val restored = ByteArrayOutputStream()
        val restoredKey = PortableBackupCodec.decrypt(
            ByteArrayInputStream(encrypted.toByteArray()),
            "a strong portable password".toCharArray(),
            restored,
        )
        assertContentEquals(key, restoredKey)
        assertContentEquals(database, restored.toByteArray())
    }

    @Test
    fun wrongPasswordAndTamperingAreRejected() {
        val encrypted = ByteArrayOutputStream().also {
            PortableBackupCodec.encrypt(ByteArray(32), ByteArrayInputStream(ByteArray(4_096)), "right password 123".toCharArray(), it)
        }.toByteArray()
        assertFails {
            PortableBackupCodec.decrypt(ByteArrayInputStream(encrypted), "wrong password 123".toCharArray(), ByteArrayOutputStream())
        }
        encrypted[encrypted.lastIndex - 3] = (encrypted[encrypted.lastIndex - 3].toInt() xor 1).toByte()
        assertFails {
            PortableBackupCodec.decrypt(ByteArrayInputStream(encrypted), "right password 123".toCharArray(), ByteArrayOutputStream())
        }
    }
}
