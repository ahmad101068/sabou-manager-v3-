package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "customers", indices = [Index(value = ["name"], unique = true)])
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val creditLimitRial: Long = 0,
    val notes: String = "",
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "sales",
    indices = [Index(value = ["invoiceNo"], unique = true), Index("customerId"), Index("saleEpochDay"), Index("dueEpochDay"), Index("replacementOfSaleId")],
    foreignKeys = [ForeignKey(entity = CustomerEntity::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT)],
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val invoiceNo: String,
    val customerId: Long?,
    val customerNameSnapshot: String,
    val saleEpochDay: Long,
    val dueEpochDay: Long?,
    val channel: String,
    val subtotalRial: Long,
    val discountRial: Long,
    val deliveryRial: Long,
    val totalRial: Long,
    val paidRial: Long,
    val paymentStatus: String,
    val paymentMethod: String?,
    val notes: String,
    val createdAtEpochMillis: Long,
    val reversedAtEpochDay: Long? = null,
    val replacementOfSaleId: Long? = null,
)

@Entity(
    tableName = "sale_lines",
    foreignKeys = [ForeignKey(entity = SaleEntity::class, parentColumns = ["id"], childColumns = ["saleId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("saleId"), Index("menuItemId")],
)
data class SaleLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val menuItemId: Long?,
    val productNameSnapshot: String,
    val quantityMicros: Long,
    val unitPriceRial: Long,
    val lineTotalRial: Long,
    val costOfGoodsRial: Long = 0,
)

@Entity(
    tableName = "sale_payments",
    foreignKeys = [ForeignKey(entity = SaleEntity::class, parentColumns = ["id"], childColumns = ["saleId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("saleId"), Index("reversalOfPaymentId")],
)
data class SalePaymentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val amountRial: Long,
    val paymentEpochDay: Long,
    val method: String,
    val journalEntryId: Long,
    val reversalOfPaymentId: Long? = null,
)
