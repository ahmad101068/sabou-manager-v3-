@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CrmScreen(state: CrmState, onAdjustPoints: (Long,Long,String)->Unit, onAddFollowUp:(Long,String,Long,String)->Unit, onComplete:(Long)->Unit, onBack:()->Unit) {
    var selected by remember { mutableStateOf<Long?>(null) }
    var points by remember { mutableStateOf("") }; var reason by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }; var due by remember { mutableStateOf("") }; var notes by remember { mutableStateOf("") }
    Scaffold(topBar={ TopAppBar(title={Text("باشگاه مشتریان و CRM")}, navigationIcon={TextButton(onClick=onBack){Text("بازگشت")}}) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            item { state.message?.let { Text(it) }; Text("مشتریان", style=MaterialTheme.typography.titleLarge) }
            items(state.customers) { c -> Card(onClick={selected=c.id}) { Column(Modifier.padding(12.dp)){ Text(c.name); Text("امتیاز: ${c.points} | ارزش خرید: ${formatMoney(c.lifetimeValueRial)}"); if(c.phone.isNotBlank()) Text(c.phone) } } }
            if(selected != null) item {
                Card { Column(Modifier.padding(12.dp), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                    Text("ثبت امتیاز دستی"); OutlinedTextField(points,{points=it},label={Text("تغییر امتیاز؛ منفی مجاز")}); OutlinedTextField(reason,{reason=it},label={Text("دلیل")}); Button(onClick={ points.toLongOrNull()?.let { onAdjustPoints(selected!!,it,reason); points=""; reason="" } }){Text("ثبت امتیاز")}
                    HorizontalDivider(); Text("پیگیری جدید"); OutlinedTextField(title,{title=it},label={Text("عنوان")}); OutlinedTextField(due,{due=it},label={Text("روز سررسید Epoch Day")}); OutlinedTextField(notes,{notes=it},label={Text("یادداشت")}); Button(onClick={ due.toLongOrNull()?.let { onAddFollowUp(selected!!,title,it,notes); title=""; due=""; notes="" } }){Text("ثبت پیگیری")}
                } }
            }
            item { Text("پیگیری‌ها", style=MaterialTheme.typography.titleLarge) }
            items(state.followUps) { f -> Card { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.SpaceBetween){ Column(Modifier.weight(1f)){Text(f.customerName+" — "+f.title); Text("سررسید: ${f.dueEpochDay}"); if(f.notes.isNotBlank()) Text(f.notes)}; if(!f.isDone) TextButton(onClick={onComplete(f.id)}){Text("انجام شد")} else Text("تکمیل") } } }
        }
    }
}
