package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.domain.sales.CustomerItem
import ir.sabou.inventory.domain.sales.SaleListItem
import ir.sabou.inventory.domain.sales.SaleDraft
import ir.sabou.inventory.domain.sales.SaleLineDraft
import ir.sabou.inventory.domain.sales.SalePaymentItem
import ir.sabou.inventory.domain.sales.SalePaymentMethod
import ir.sabou.inventory.domain.sales.SalesRepository
import ir.sabou.inventory.domain.sales.SalesReport
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class SaleLineInput(val menuItemId: Long? = null, val productName: String, val quantity: String, val unitPriceRial: Long)

data class SalesUiState(
    val sales: List<SaleListItem> = emptyList(), val customers: List<CustomerItem> = emptyList(),
    val selectedSaleId: Long? = null, val payments: List<SalePaymentItem> = emptyList(),
    val search: String = "", val menuItems: List<MenuItem> = emptyList(), val busy: Boolean = false, val message: String? = null,
    val activeSalesRial: Long = 0, val grossProfitRial: Long = 0, val receivablesRial: Long = 0,
    val reportFromEpochDay: Long = 0, val reportToEpochDay: Long = 0, val report: SalesReport? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class SalesViewModel(private val repository: SalesRepository, private val recipeRepository: RecipeRepository) : ViewModel() {
    private val search = MutableStateFlow("")
    private val selectedSaleId = MutableStateFlow<Long?>(null)
    private val busy = MutableStateFlow(false)
    private val today = currentEpochDay()
    private val reportRange = MutableStateFlow((today - 30L) to today)
    private val message = MutableStateFlow<String?>(null)
    private val payments = selectedSaleId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.observePayments(id) }
    private val report = reportRange.flatMapLatest { (from, to) -> repository.observeReport(from, to) }
    private val contentBase = combine(
        search.flatMapLatest(repository::observeSales),
        repository.observeCustomers(),
        selectedSaleId,
        payments,
        recipeRepository.observeMenuItems(),
    ) { sales, customers, selected, pay, menu ->
        val active = sales.filterNot { it.reversed }
        SalesUiState(
            sales = sales,
            customers = customers,
            selectedSaleId = selected,
            payments = pay,
            search = search.value,
            menuItems = menu,
            activeSalesRial = active.sumOf { it.totalRial },
            grossProfitRial = active.sumOf { it.totalRial - it.costOfGoodsRial },
            receivablesRial = active.sumOf { (it.totalRial - it.paidRial).coerceAtLeast(0) },
        )
    }
    private val content = combine(contentBase, report) { base, currentReport ->
        base.copy(
            reportFromEpochDay = currentReport.fromEpochDay,
            reportToEpochDay = currentReport.toEpochDay,
            report = currentReport,
        )
    }

    val state: StateFlow<SalesUiState> = combine(content, busy, message) { current, isBusy, msg ->
        current.copy(busy = isBusy, message = msg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SalesUiState())

    fun search(value: String) { search.value = value }
    fun clearMessage() { message.value = null }
    fun selectSale(id: Long?) { selectedSaleId.value = id }
    fun setReportRange(fromEpochDay: Long, toEpochDay: Long) { if (fromEpochDay <= toEpochDay) reportRange.value = fromEpochDay to toEpochDay else message.value = "بازه گزارش نامعتبر است." }
    fun addCustomer(name: String, phone: String, address: String, creditLimitRial: Long, notes: String, done: () -> Unit = {}) = run("مشتری ثبت شد.", done) { repository.addCustomer(name, phone, address, creditLimitRial, notes) }
    fun postSale(invoiceNo: String, customerId: Long?, customerName: String, saleDay: Long, dueDay: Long?, channel: String, discountRial: Long, deliveryRial: Long, paymentMethod: SalePaymentMethod, notes: String, lines: List<SaleLineInput>, done: () -> Unit = {}) = run("فاکتور فروش ثبت شد.", done) {
        repository.post(SaleDraft(invoiceNo, customerId, customerName, saleDay, dueDay, channel, MoneyRial.of(discountRial), MoneyRial.of(deliveryRial), paymentMethod, notes, lines.map { SaleLineDraft(it.menuItemId, it.productName, QuantityMicros.parse(it.quantity), MoneyRial.of(it.unitPriceRial)) }))
    }
    fun receive(saleId: Long, amountRial: Long, day: Long, method: SalePaymentMethod, done: () -> Unit = {}) = run("وصول ثبت شد.", done) { repository.receive(saleId, MoneyRial.of(amountRial), day, method) }
    fun reverse(paymentId: Long, day: Long) = run("وصول با سند معکوس برگشت خورد.") { repository.reverseReceipt(paymentId, day) }
    fun reverseSale(saleId: Long, day: Long) = run("فاکتور فروش و اثر انبار آن برگشت خورد.") { repository.reverseSale(saleId, day); selectSale(null) }
    fun replaceSale(saleId: Long, reversalDay: Long, invoiceNo: String, customerId: Long?, customerName: String, saleDay: Long, dueDay: Long?, channel: String, discountRial: Long, deliveryRial: Long, paymentMethod: SalePaymentMethod, notes: String, lines: List<SaleLineInput>, done: () -> Unit = {}) = run("فاکتور قبلی برگشت و فاکتور جایگزین ثبت شد.", done) { repository.replaceSale(saleId, reversalDay, SaleDraft(invoiceNo, customerId, customerName, saleDay, dueDay, channel, MoneyRial.of(discountRial), MoneyRial.of(deliveryRial), paymentMethod, notes, lines.map { SaleLineDraft(it.menuItemId, it.productName, QuantityMicros.parse(it.quantity), MoneyRial.of(it.unitPriceRial)) })); selectSale(null) }
    private fun run(success: String, done: () -> Unit = {}, block: suspend () -> Unit) { if (busy.value) return; viewModelScope.launch { busy.value = true; message.value = null; try { block(); message.value = success; done() } catch (e: Exception) { message.value = UiErrorHandler.message("SalesViewModel", e) } finally { busy.value = false } } }
    companion object { fun factory(repository: SalesRepository, recipeRepository: RecipeRepository): ViewModelProvider.Factory = object : ViewModelProvider.Factory { @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = SalesViewModel(repository, recipeRepository) as T } }
}
