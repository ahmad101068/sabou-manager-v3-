package ir.sabou.inventory.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RestaurantOperationsDao {
    @Query("SELECT * FROM restaurant_tables ORDER BY zone,label") fun observeTables(): Flow<List<RestaurantTableEntity>>
    @Insert suspend fun insertTable(value: RestaurantTableEntity): Long
    @Update suspend fun updateTable(value: RestaurantTableEntity): Int
    @Query("SELECT * FROM restaurant_tables WHERE id=:id") suspend fun table(id: Long): RestaurantTableEntity?

    @Query("SELECT * FROM table_orders WHERE status='OPEN' ORDER BY openedAtEpochMillis,id") fun observeOpenOrders(): Flow<List<TableOrderEntity>>
    @Query("SELECT * FROM table_order_lines WHERE status='ACTIVE' ORDER BY orderId,courseNo,seatNo,id") fun observeActiveOrderLines(): Flow<List<TableOrderLineEntity>>
    @Query("SELECT * FROM table_orders WHERE id=:id LIMIT 1") suspend fun order(id: Long): TableOrderEntity?
    @Query("SELECT * FROM table_order_lines WHERE orderId=:orderId AND status='ACTIVE' ORDER BY courseNo,seatNo,id") suspend fun activeOrderLines(orderId: Long): List<TableOrderLineEntity>
    @Query("SELECT * FROM table_order_lines WHERE id=:id LIMIT 1") suspend fun orderLine(id: Long): TableOrderLineEntity?
    @Query("SELECT * FROM table_orders WHERE tableId=:tableId AND status='OPEN' LIMIT 1") suspend fun openOrderForTable(tableId: Long): TableOrderEntity?
    @Insert suspend fun insertOrder(value: TableOrderEntity): Long
    @Update suspend fun updateOrder(value: TableOrderEntity): Int
    @Insert suspend fun insertOrderLine(value: TableOrderLineEntity): Long
    @Query("UPDATE table_order_lines SET orderId=:targetOrderId WHERE orderId=:sourceOrderId AND status='ACTIVE'") suspend fun moveActiveOrderLines(sourceOrderId: Long, targetOrderId: Long): Int
    @Query("UPDATE table_order_lines SET orderId=:targetOrderId WHERE id=:lineId AND orderId=:sourceOrderId AND status='ACTIVE'") suspend fun moveOrderLine(lineId: Long, sourceOrderId: Long, targetOrderId: Long): Int
    @Query("UPDATE table_order_lines SET status='VOIDED',voidReason=:reason,voidedBy=:by,voidedAtEpochMillis=:now WHERE id=:lineId AND status='ACTIVE'") suspend fun voidOrderLine(lineId: Long, reason: String, by: String, now: Long): Int
    @Query(
        """
        UPDATE restaurant_tables SET status='CLEANING',activeOrderId=NULL
        WHERE status='WAITING_PAYMENT'
          AND id=(SELECT tableId FROM table_orders WHERE saleId=:saleId OR id=(SELECT orderId FROM bill_splits WHERE saleId=:saleId LIMIT 1) LIMIT 1)
          AND NOT EXISTS(
              SELECT 1 FROM bill_splits bs INNER JOIN sales s ON s.id=bs.saleId
              WHERE bs.orderId=(SELECT id FROM table_orders WHERE saleId=:saleId OR id=(SELECT orderId FROM bill_splits WHERE saleId=:saleId LIMIT 1) LIMIT 1)
                AND bs.status='SETTLED' AND s.paymentStatus!='PAID'
          )
        """,
    )
    suspend fun markTableCleaningForSale(saleId: Long): Int
    @Query("UPDATE restaurant_tables SET status='WAITING_PAYMENT',activeOrderId=NULL WHERE status='CLEANING' AND id=(SELECT tableId FROM table_orders WHERE saleId=:saleId OR id=(SELECT orderId FROM bill_splits WHERE saleId=:saleId LIMIT 1) LIMIT 1)") suspend fun markTableWaitingForSale(saleId: Long): Int

    @Query("SELECT * FROM bill_splits WHERE status IN ('OPEN','SETTLED') ORDER BY orderId,id") fun observeCurrentBillSplits(): Flow<List<BillSplitEntity>>
    @Query("SELECT * FROM bill_split_lines ORDER BY splitId,id") fun observeBillSplitLines(): Flow<List<BillSplitLineEntity>>
    @Query("SELECT * FROM bill_splits WHERE id=:id LIMIT 1") suspend fun billSplit(id: Long): BillSplitEntity?
    @Query("SELECT l.* FROM table_order_lines l INNER JOIN bill_split_lines bl ON bl.orderLineId=l.id WHERE bl.splitId=:splitId ORDER BY l.courseNo,l.seatNo,l.id") suspend fun linesForBillSplit(splitId: Long): List<TableOrderLineEntity>
    @Query("SELECT COUNT(*) FROM bill_splits WHERE orderId=:orderId AND status='SETTLED'") suspend fun settledSplitCount(orderId: Long): Int
    @Query("SELECT COUNT(*) FROM bill_splits WHERE orderId=:orderId AND status='OPEN'") suspend fun openSplitCount(orderId: Long): Int
    @Query("SELECT COUNT(*) FROM bill_split_lines bl INNER JOIN bill_splits bs ON bs.id=bl.splitId WHERE bl.orderLineId=:lineId AND bs.status IN ('OPEN','SETTLED')") suspend fun currentSplitAssignmentCount(lineId: Long): Int
    @Query("UPDATE bill_splits SET status='CANCELLED' WHERE orderId=:orderId AND status='OPEN'") suspend fun cancelOpenBillSplits(orderId: Long): Int
    @Insert suspend fun insertBillSplit(value: BillSplitEntity): Long
    @Insert suspend fun insertBillSplitLines(values: List<BillSplitLineEntity>)
    @Update suspend fun updateBillSplit(value: BillSplitEntity): Int
    @Query("SELECT COUNT(*) FROM bill_splits bs INNER JOIN sales s ON s.id=bs.saleId WHERE bs.orderId=:orderId AND bs.status='SETTLED' AND s.paymentStatus!='PAID'") suspend fun unsettledSaleCountForOrder(orderId: Long): Int

    @Query("SELECT * FROM cash_shifts ORDER BY openedAtEpochMillis DESC,id DESC") fun observeCashShifts(): Flow<List<CashShiftEntity>>
    @Query("SELECT * FROM cash_shifts WHERE status='OPEN' ORDER BY id DESC LIMIT 1") suspend fun activeCashShift(): CashShiftEntity?
    @Insert suspend fun insertCashShift(value: CashShiftEntity): Long
    @Update suspend fun updateCashShift(value: CashShiftEntity): Int
    @Query(
        """
        SELECT :openingFloatRial
          + COALESCE((
              SELECT SUM(jl.debitRial-jl.creditRial)
              FROM journal_lines jl INNER JOIN journal_entries je ON je.id=jl.entryId
              WHERE jl.accountCode='1101' AND je.createdAtEpochMillis>=:openedAtEpochMillis
            ),0)
        """,
    )
    suspend fun expectedCashRial(openedAtEpochMillis: Long, openingFloatRial: Long): Long

    @Query("SELECT * FROM reservations ORDER BY startEpochMillis") fun observeReservations(): Flow<List<ReservationEntity>>
    @Query("SELECT * FROM reservations") suspend fun allReservations(): List<ReservationEntity>
    @Insert suspend fun insertReservation(value: ReservationEntity): Long

    @Query("SELECT * FROM kitchen_tickets ORDER BY priority DESC,createdAtEpochMillis") fun observeKitchenTickets(): Flow<List<KitchenTicketEntity>>
    @Insert suspend fun insertKitchenTicket(value: KitchenTicketEntity): Long
    @Insert suspend fun insertKitchenTickets(values: List<KitchenTicketEntity>)
    @Update suspend fun updateKitchenTicket(value: KitchenTicketEntity): Int
    @Query("SELECT * FROM kitchen_tickets WHERE id=:id") suspend fun kitchenTicket(id: Long): KitchenTicketEntity?
    @Query("SELECT * FROM kitchen_tickets WHERE orderLineId=:orderLineId ORDER BY id DESC LIMIT 1") suspend fun kitchenTicketForOrderLine(orderLineId: Long): KitchenTicketEntity?
    @Query("SELECT * FROM kitchen_tickets WHERE orderLineId IS NULL AND orderNo=:orderNo AND itemName LIKE :itemName || '%' ORDER BY id DESC LIMIT 1") suspend fun legacyKitchenTicketForOrderLine(orderNo: String, itemName: String): KitchenTicketEntity?
    @Query("UPDATE kitchen_tickets SET status='CANCELLED' WHERE orderLineId=:orderLineId AND status IN ('QUEUED','PREPARING')") suspend fun cancelKitchenTicketForOrderLine(orderLineId: Long): Int
    @Query("UPDATE kitchen_tickets SET orderNo=:targetOrderNo WHERE orderLineId=:orderLineId AND status IN ('QUEUED','PREPARING')") suspend fun relabelKitchenTicketForOrderLine(orderLineId: Long, targetOrderNo: String): Int
    @Query("UPDATE kitchen_tickets SET status='CANCELLED' WHERE orderNo=:orderNo AND status IN ('QUEUED','PREPARING')")
    suspend fun cancelActiveKitchenTickets(orderNo: String): Int

    @Query("SELECT * FROM planned_shifts ORDER BY epochDay,startMinute") fun observeShifts(): Flow<List<PlannedShiftEntity>>
    @Insert suspend fun insertShifts(values: List<PlannedShiftEntity>)

    @Query("SELECT * FROM approval_requests ORDER BY id DESC") fun observeApprovals(): Flow<List<ApprovalRequestEntity>>
    @Insert suspend fun insertApproval(value: ApprovalRequestEntity): Long
    @Update suspend fun updateApproval(value: ApprovalRequestEntity): Int
    @Query("SELECT * FROM approval_requests WHERE id=:id") suspend fun approval(id: Long): ApprovalRequestEntity?
}
