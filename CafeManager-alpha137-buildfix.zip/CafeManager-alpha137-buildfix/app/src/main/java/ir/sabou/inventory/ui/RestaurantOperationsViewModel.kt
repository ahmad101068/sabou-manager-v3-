package ir.sabou.inventory.ui

import androidx.lifecycle.*
import ir.sabou.inventory.domain.operations.*
import ir.sabou.inventory.domain.sales.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RestaurantOperationsUiState(val tables:List<RestaurantTable> = emptyList(),val reservations:List<Reservation> = emptyList(),val tickets:List<KitchenTicket> = emptyList(),val shifts:List<PlannedShift> = emptyList(),val approvals:List<ApprovalRequest> = emptyList(),val openOrders:List<TableOrder> = emptyList(),val cashShifts:List<CashShift> = emptyList(),val busy:Boolean=false,val message:String?=null)

class RestaurantOperationsViewModel(private val repository:RestaurantOperationsRepository):ViewModel(){
    private val message=MutableStateFlow<String?>(null)
    private val busy=MutableStateFlow(false)
    private val base=combine(repository.tables,repository.reservations,repository.kitchenTickets,repository.shifts,repository.approvals){ tables,reservations,tickets,shifts,approvals->RestaurantOperationsUiState(tables,reservations,tickets,shifts,approvals) }
    private val content=combine(base,repository.openOrders,repository.cashShifts){ value,orders,cash->value.copy(openOrders=orders,cashShifts=cash) }
    val state=combine(content,busy,message){ value,isBusy,text->value.copy(busy=isBusy,message=text)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),RestaurantOperationsUiState())
    private fun run(success:String,done:()->Unit={},block:suspend()->Unit)=viewModelScope.launch{if(busy.value)return@launch;busy.value=true;message.value=runCatching{block();done();success}.getOrElse{it.message?:"عملیات انجام نشد."};busy.value=false}
    fun addTable(label:String,capacity:Int,zone:String)=run("میز ثبت شد."){repository.addTable(label,capacity,zone)}
    fun transitionTable(id:Long,status:TableStatus,orderId:Long?=null)=run("وضعیت میز تغییر کرد."){repository.transitionTable(id,status,orderId)}
    fun addReservation(value:Reservation)=run("رزرو ثبت شد."){repository.addReservation(value)}
    fun addTicket(orderNo:String,station:String,item:String,quantity:Int,priority:Int)=run("سفارش آشپزخانه ثبت شد."){repository.addKitchenTicket(orderNo,station,item,quantity,priority)}
    fun transitionTicket(id:Long,status:KitchenTicketStatus)=run("وضعیت سفارش تغییر کرد."){repository.transitionKitchenTicket(id,status)}
    fun planShift(demand:ShiftDemand,staff:List<StaffAvailability>)=run("شیفت برنامه‌ریزی شد."){repository.planShift(demand,staff)}
    fun requestApproval(type:String,entityId:Long,amount:Long,by:String)=run("درخواست تأیید ثبت شد."){repository.requestApproval(type,entityId,amount,by)}
    fun review(id:Long,approve:Boolean,by:String,note:String="")=run("درخواست بررسی شد."){repository.reviewApproval(id,approve,by,note)}
    fun openOrder(draft:OpenTableOrderDraft,done:()->Unit={})=run("سفارش میز باز شد.",done){repository.openTableOrder(draft)}
    fun addOrderItem(orderId:Long,draft:TableOrderItemDraft,done:()->Unit={})=run("آیتم به سفارش و آشپزخانه ارسال شد.",done){repository.addTableOrderItem(orderId,draft)}
    fun transferOrder(orderId:Long,targetTableId:Long,done:()->Unit={})=run("سفارش به میز جدید منتقل شد.",done){repository.transferTableOrder(orderId,targetTableId)}
    fun mergeOrders(sourceOrderId:Long,targetOrderId:Long,done:()->Unit={})=run("سفارش‌ها ادغام شدند.",done){repository.mergeTableOrders(sourceOrderId,targetOrderId)}
    fun checkoutOrder(orderId:Long,draft:TableCheckoutDraft,done:()->Unit={})=run("صورتحساب ثبت و سفارش بسته شد.",done){repository.checkoutTableOrder(orderId,draft)}
    fun transferLine(lineId:Long,targetOrderId:Long,done:()->Unit={})=run("ردیف سفارش منتقل شد.",done){repository.transferTableOrderLine(lineId,targetOrderId)}
    fun voidLine(lineId:Long,draft:VoidOrderLineDraft,done:()->Unit={})=run("ردیف سفارش با ثبت علت ابطال شد.",done){repository.voidTableOrderLine(lineId,draft)}
    fun createSplits(orderId:Long,mode:BillSplitMode,done:()->Unit={})=run("صورتحساب تفکیکی ساخته شد.",done){repository.createBillSplits(orderId,mode)}
    fun checkoutSplit(splitId:Long,draft:TableCheckoutDraft,done:()->Unit={})=run("سهم صورتحساب تسویه شد.",done){repository.checkoutBillSplit(splitId,draft)}
    fun openCashShift(openingFloat:Long,note:String,done:()->Unit={})=run("شیفت صندوق باز شد.",done){repository.openCashShift(ir.sabou.inventory.core.MoneyRial.of(openingFloat),note)}
    fun closeCashShift(countedCash:Long,note:String,done:()->Unit={})=run("شیفت صندوق بسته و مغایرت محاسبه شد.",done){repository.closeCashShift(ir.sabou.inventory.core.MoneyRial.of(countedCash),note)}
    fun clearMessage(){message.value=null}
    companion object{fun factory(repository:RestaurantOperationsRepository)=object:ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST") override fun<T:ViewModel>create(modelClass:Class<T>):T=RestaurantOperationsViewModel(repository) as T}}
}
