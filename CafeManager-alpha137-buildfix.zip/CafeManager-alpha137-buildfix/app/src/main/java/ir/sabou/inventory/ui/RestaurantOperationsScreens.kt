package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.ApprovalStatus
import ir.sabou.inventory.domain.operations.KitchenTicketStatus
import ir.sabou.inventory.domain.operations.ShiftDemand
import ir.sabou.inventory.domain.operations.StaffAvailability
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.sales.Reservation
import ir.sabou.inventory.domain.sales.RestaurantTable
import ir.sabou.inventory.domain.sales.CustomerItem
import ir.sabou.inventory.domain.sales.OpenTableOrderDraft
import ir.sabou.inventory.domain.sales.SalePaymentAllocation
import ir.sabou.inventory.domain.sales.SalePaymentMethod
import ir.sabou.inventory.domain.sales.TableCheckoutDraft
import ir.sabou.inventory.domain.sales.TableOrder
import ir.sabou.inventory.domain.sales.TableOrderItemDraft
import ir.sabou.inventory.domain.sales.TableStatus
import ir.sabou.inventory.domain.sales.BillSplitMode
import ir.sabou.inventory.domain.sales.BillSplitStatus
import ir.sabou.inventory.domain.sales.CashShiftStatus
import ir.sabou.inventory.domain.sales.VoidOrderLineDraft
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros

private enum class OpsDialog { TABLE, RESERVATION, KITCHEN, SHIFT, APPROVAL }
private enum class OrderDialogMode { OPEN, ADD_ITEM, TRANSFER, MERGE, CHECKOUT, SPLIT, SPLIT_CHECKOUT, LINE_TRANSFER, LINE_VOID }
private data class OrderDialogTarget(val mode: OrderDialogMode, val tableId: Long, val orderId: Long? = null, val subjectId: Long? = null)

@Composable
fun RestaurantOperationsScreen(
    state: RestaurantOperationsUiState,
    employees: List<EmployeeRecord>,
    menuItems: List<MenuItem>,
    customers: List<CustomerItem>,
    canManageTables: Boolean,
    canManageKitchen: Boolean,
    canManageShifts: Boolean,
    canManageApprovals: Boolean,
    onAddTable: (String, Int, String) -> Unit,
    onTable: (Long, TableStatus, Long?) -> Unit,
    onReservation: (Reservation) -> Unit,
    onTicket: (String, String, String, Int, Int) -> Unit,
    onTicketStatus: (Long, KitchenTicketStatus) -> Unit,
    onShift: (ShiftDemand, List<StaffAvailability>) -> Unit,
    onApproval: (String, Long, Long, String) -> Unit,
    onReview: (Long, Boolean, String, String) -> Unit,
    onOpenOrder: (OpenTableOrderDraft, () -> Unit) -> Unit,
    onAddOrderItem: (Long, TableOrderItemDraft, () -> Unit) -> Unit,
    onTransferOrder: (Long, Long, () -> Unit) -> Unit,
    onMergeOrders: (Long, Long, () -> Unit) -> Unit,
    onCheckoutOrder: (Long, TableCheckoutDraft, () -> Unit) -> Unit,
    onTransferLine: (Long, Long, () -> Unit) -> Unit,
    onVoidLine: (Long, VoidOrderLineDraft, () -> Unit) -> Unit,
    onCreateSplits: (Long, BillSplitMode, () -> Unit) -> Unit,
    onCheckoutSplit: (Long, TableCheckoutDraft, () -> Unit) -> Unit,
    onOpenCashShift: (Long, String, () -> Unit) -> Unit,
    onCloseCashShift: (Long, String, () -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var dialog by remember { mutableStateOf<OpsDialog?>(null) }
    var orderDialog by remember { mutableStateOf<OrderDialogTarget?>(null) }
    var cashShiftDialogOpen by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val actions = buildList {
        if (canManageTables) {
            add("میز" to OpsDialog.TABLE)
            add("رزرو" to OpsDialog.RESERVATION)
        }
        if (canManageKitchen) add("آشپزخانه" to OpsDialog.KITCHEN)
        if (canManageShifts) add("شیفت" to OpsDialog.SHIFT)
        if (canManageApprovals) add("تأیید" to OpsDialog.APPROVAL)
    }

    Scaffold(
        topBar = { ProfessionalTopBar("عملیات رستوران", "میز، رزرو، آشپزخانه، شیفت و تأیید", onBack) },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.message?.let { message ->
                item { StatusPill(message, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer) }
            }
            if (actions.isNotEmpty()) item { ActionStrip(actions) { dialog = it } }

            if (canManageTables) {
                val openCashShift = state.cashShifts.firstOrNull { it.status == CashShiftStatus.OPEN }
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("صندوق و تطبیق نقدی", fontWeight = FontWeight.Bold)
                            if (openCashShift == null) {
                                Text("شیفت صندوق بازی وجود ندارد.")
                                FilledTonalButton(onClick = { cashShiftDialogOpen = true }) { Text("باز کردن شیفت صندوق") }
                            } else {
                                Text("افتتاح: ${formatMoney(openCashShift.openingFloat.value)} · کاربر ${openCashShift.openedBy}")
                                Button(onClick = { cashShiftDialogOpen = true }) { Text("بستن و شمارش صندوق") }
                            }
                            state.cashShifts.firstOrNull { it.status == CashShiftStatus.CLOSED }?.let { closed ->
                                Text("آخرین مغایرت: ${formatSignedMoney(closed.varianceRial ?: 0)}")
                                OutlinedButton(onClick = { printCashShift(context, closed) }) { Text("چاپ گزارش صندوق") }
                            }
                        }
                    }
                }
            }

            if (canManageTables) {
                item { SectionHeading("میزها و رزرو", "${state.tables.size} میز · ${state.reservations.size} رزرو") }
                items(state.tables, key = { restaurantTableListKey(it.id) }) { table ->
                    val order = state.openOrders.firstOrNull { it.tableId == table.id }
                    Card {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("میز ${table.label} · ${table.zone}", fontWeight = FontWeight.Bold)
                            Text("ظرفیت ${table.capacity} · ${tableStatusLabel(table.status)}")
                            if (order != null) {
                                Text("${order.guestCount} مهمان · مسئول ${order.waiterName} · ${order.lines.size} ردیف")
                                Text("جمع فعلی: ${formatMoney(order.subtotal.value)}", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                order.lines.forEach { line ->
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("${line.itemName} × ${formatQuantity(line.quantity.value)}${if (line.seatNo > 0) " · مهمان ${line.seatNo}" else ""}", modifier = Modifier.weight(1f))
                                        if (order.billSplits.isEmpty()) {
                                            TextButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.LINE_TRANSFER, table.id, order.id, line.id) }) { Text("انتقال") }
                                            if (canManageApprovals) TextButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.LINE_VOID, table.id, order.id, line.id) }) { Text("ابطال") }
                                        }
                                    }
                                }
                                HorizontalDivider()
                                if (order.billSplits.isEmpty()) {
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        item { FilledTonalButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.ADD_ITEM, table.id, order.id) }) { Text("افزودن آیتم") } }
                                        item { TextButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.TRANSFER, table.id, order.id) }) { Text("انتقال میز") } }
                                        item { TextButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.MERGE, table.id, order.id) }) { Text("ادغام") } }
                                        item { TextButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.SPLIT, table.id, order.id) }) { Text("تقسیم صورتحساب") } }
                                        item { Button(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.CHECKOUT, table.id, order.id) }) { Text("تسویه کامل") } }
                                    }
                                } else {
                                    Text("سهم‌های صورتحساب", fontWeight = FontWeight.Bold)
                                    order.billSplits.forEach { split ->
                                        Card {
                                            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text("${split.label} · ${formatMoney(split.subtotal.value)}", fontWeight = FontWeight.Bold)
                                                Text(split.lines.joinToString("، ") { it.itemName })
                                                OutlinedButton(onClick = { printBillSplit(context, order, split) }) { Text("چاپ این سهم") }
                                                if (split.status == BillSplitStatus.OPEN) Button(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.SPLIT_CHECKOUT, table.id, order.id, split.id) }) { Text("تسویه این سهم") }
                                                else StatusPill("تسویه‌شده", MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer)
                                            }
                                        }
                                    }
                                }
                                OutlinedButton(onClick = { printTableOrder(context, order) }, modifier = Modifier.fillMaxWidth()) { Text("چاپ برگه میز / PDF") }
                            } else if (table.status == TableStatus.FREE || table.status == TableStatus.RESERVED) {
                                FilledTonalButton(onClick = { orderDialog = OrderDialogTarget(OrderDialogMode.OPEN, table.id) }) { Text("باز کردن سفارش") }
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    nextTableStatuses(table.status).forEach { next ->
                                        TextButton(onClick = { onTable(table.id, next, table.activeOrderId) }) { Text(tableStatusLabel(next)) }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (canManageKitchen) {
                item { SectionHeading("صف آشپزخانه", "اولویت‌بندی زنده سفارش‌ها") }
                items(state.tickets, key = { restaurantTicketListKey(it.id) }) { ticket ->
                    Card {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column {
                                Text("${ticket.orderNo} · ${ticket.itemName}", fontWeight = FontWeight.Bold)
                                Text("${ticket.quantity} عدد · ${ticket.station} · ${ticket.status.name}")
                            }
                            nextTicketStatus(ticket.status)?.let { next ->
                                TextButton(onClick = { onTicketStatus(ticket.id, next) }) { Text(next.name) }
                            }
                        }
                    }
                }
            }

            if (canManageShifts) {
                item { SectionHeading("شیفت‌ها", "${state.shifts.size} شیفت برنامه‌ریزی‌شده") }
                items(
                    state.shifts.take(8),
                    key = { restaurantShiftListKey(it.id) },
                ) { shift ->
                    Text("${shift.employeeName} · ${epochDayToPersian(shift.epochDay).display()} · ${shift.startMinute / 60}:${(shift.startMinute % 60).toString().padStart(2, '0')}–${shift.endMinute / 60}:${(shift.endMinute % 60).toString().padStart(2, '0')}")
                }
            }

            if (canManageApprovals) {
                item { SectionHeading("تأییدها", "${state.approvals.count { it.status == ApprovalStatus.PENDING }} در انتظار") }
                items(state.approvals, key = { restaurantApprovalListKey(it.id) }) { request ->
                    Card {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text("${request.requestType} · ${formatMoney(request.amountRial)}", fontWeight = FontWeight.Bold)
                            Text(request.status.name)
                            if (request.status == ApprovalStatus.PENDING) {
                                Row {
                                    TextButton(onClick = { onReview(request.id, true, "مدیر", "") }) { Text("تأیید") }
                                    TextButton(onClick = { onReview(request.id, false, "مدیر", "رد توسط مدیر") }) { Text("رد") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    dialog?.let { mode ->
        OperationsInputDialog(mode, state.tables, employees, { dialog = null }) { a, b, c, d, e, selectedDay, tableId, startMinute, endMinute ->
            when (mode) {
                OpsDialog.TABLE -> onAddTable(a, b.toIntOrNull() ?: 0, c)
                OpsDialog.RESERVATION -> {
                    if (tableId != null) {
                        onReservation(
                            Reservation(
                                0,
                                a,
                                b,
                                tableId,
                                selectedDay * 86_400_000L + startMinute * 60_000L,
                                selectedDay * 86_400_000L + endMinute * 60_000L,
                                c.toIntOrNull() ?: 1,
                                d,
                            ),
                        )
                    }
                }
                OpsDialog.KITCHEN -> onTicket(a, b, c, d.toIntOrNull() ?: 1, e.toIntOrNull() ?: 0)
                OpsDialog.SHIFT -> onShift(
                    ShiftDemand(selectedDay, a.toIntOrNull() ?: 540, b.toIntOrNull() ?: 1020, c.toIntOrNull() ?: 1),
                    employees.filter { it.isActive }.map { StaffAvailability(it.id, it.name, 0, 1440, it.jobTitle) },
                )
                OpsDialog.APPROVAL -> onApproval(a, b.toLongOrNull() ?: 1, parseMoneyInputOrZero(c), d)
            }
        }
    }

    orderDialog?.let { target ->
        val order = target.orderId?.let { id -> state.openOrders.firstOrNull { it.id == id } }
        when (target.mode) {
            OrderDialogMode.OPEN -> OpenOrderDialog(
                table = state.tables.first { it.id == target.tableId },
                customers = customers,
                dismiss = { orderDialog = null },
                save = { draft -> onOpenOrder(draft) { orderDialog = null } },
            )
            OrderDialogMode.ADD_ITEM -> if (order != null) AddOrderItemDialog(
                order = order,
                menuItems = menuItems,
                dismiss = { orderDialog = null },
                save = { draft -> onAddOrderItem(order.id, draft) { orderDialog = null } },
            )
            OrderDialogMode.TRANSFER -> if (order != null) OrderTargetDialog(
                title = "انتقال سفارش",
                options = state.tables.filter { it.id != order.tableId && it.status == TableStatus.FREE }.map { it.id to "میز ${it.label} · ${it.zone} · ظرفیت ${it.capacity}" },
                dismiss = { orderDialog = null },
                save = { tableId -> onTransferOrder(order.id, tableId) { orderDialog = null } },
            )
            OrderDialogMode.MERGE -> if (order != null) OrderTargetDialog(
                title = "ادغام با سفارش دیگر",
                options = state.openOrders.filter { it.id != order.id && it.billSplits.isEmpty() }.map { it.id to "میز ${it.tableLabel} · ${formatMoney(it.subtotal.value)}" },
                dismiss = { orderDialog = null },
                save = { targetOrderId -> onMergeOrders(order.id, targetOrderId) { orderDialog = null } },
            )
            OrderDialogMode.CHECKOUT -> if (order != null) CheckoutOrderDialog(
                order = order,
                dismiss = { orderDialog = null },
                save = { draft -> onCheckoutOrder(order.id, draft) { orderDialog = null } },
            )
            OrderDialogMode.SPLIT -> if (order != null) BillSplitModeDialog(
                dismiss = { orderDialog = null },
                save = { mode -> onCreateSplits(order.id, mode) { orderDialog = null } },
            )
            OrderDialogMode.SPLIT_CHECKOUT -> if (order != null) order.billSplits.firstOrNull { it.id == target.subjectId }?.let { split ->
                CheckoutOrderDialog(
                    order = order.copy(lines = split.lines),
                    title = "تسویه ${split.label} · میز ${order.tableLabel}",
                    dismiss = { orderDialog = null },
                    save = { draft -> onCheckoutSplit(split.id, draft) { orderDialog = null } },
                )
            }
            OrderDialogMode.LINE_TRANSFER -> if (order != null && target.subjectId != null) OrderTargetDialog(
                title = "انتقال ردیف سفارش",
                options = state.openOrders.filter { it.id != order.id && it.billSplits.isEmpty() }.map { it.id to "میز ${it.tableLabel} · ${it.waiterName}" },
                dismiss = { orderDialog = null },
                save = { targetOrderId -> onTransferLine(target.subjectId, targetOrderId) { orderDialog = null } },
            )
            OrderDialogMode.LINE_VOID -> if (target.subjectId != null) VoidOrderLineDialog(
                dismiss = { orderDialog = null },
                save = { draft -> onVoidLine(target.subjectId, draft) { orderDialog = null } },
            )
        }
    }

    if (cashShiftDialogOpen) {
        CashShiftDialog(
            activeShift = state.cashShifts.firstOrNull { it.status == CashShiftStatus.OPEN },
            dismiss = { cashShiftDialogOpen = false },
            open = { amount, note -> onOpenCashShift(amount, note) { cashShiftDialogOpen = false } },
            close = { amount, note -> onCloseCashShift(amount, note) { cashShiftDialogOpen = false } },
        )
    }
}

private fun formatSignedMoney(value: Long): String = when {
    value > 0 -> "+${formatMoney(value)} اضافی"
    value < 0 -> "${formatMoney(-value)} کسری"
    else -> "بدون مغایرت"
}

private fun tableStatusLabel(status: TableStatus) = when (status) {
    TableStatus.FREE -> "خالی"
    TableStatus.RESERVED -> "رزرو"
    TableStatus.OCCUPIED -> "مشغول"
    TableStatus.WAITING_PAYMENT -> "منتظر تسویه"
    TableStatus.CLEANING -> "نیازمند نظافت"
}

@Composable
private fun ActionStrip(actions: List<Pair<String, OpsDialog>>, onClick: (OpsDialog) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(actions) { (label, mode) ->
            FilledTonalButton(onClick = { onClick(mode) }) { Text("افزودن $label") }
        }
    }
}

private fun nextTableStatuses(status: TableStatus) = when (status) {
    TableStatus.FREE -> listOf(TableStatus.RESERVED, TableStatus.OCCUPIED)
    TableStatus.RESERVED -> listOf(TableStatus.OCCUPIED, TableStatus.FREE)
    TableStatus.OCCUPIED -> listOf(TableStatus.WAITING_PAYMENT, TableStatus.CLEANING)
    TableStatus.WAITING_PAYMENT -> listOf(TableStatus.CLEANING)
    TableStatus.CLEANING -> listOf(TableStatus.FREE)
}

private fun nextTicketStatus(status: KitchenTicketStatus) = when (status) {
    KitchenTicketStatus.QUEUED -> KitchenTicketStatus.PREPARING
    KitchenTicketStatus.PREPARING -> KitchenTicketStatus.READY
    KitchenTicketStatus.READY -> KitchenTicketStatus.SERVED
    else -> null
}

@Composable
private fun OpenOrderDialog(
    table: RestaurantTable,
    customers: List<CustomerItem>,
    dismiss: () -> Unit,
    save: (OpenTableOrderDraft) -> Unit,
) {
    var guestCount by remember { mutableStateOf("1") }
    var waiterName by remember { mutableStateOf("") }
    var customerId by remember { mutableStateOf<Long?>(null) }
    var customerName by remember { mutableStateOf("مشتری متفرقه") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("سفارش جدید · میز ${table.label}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ظرفیت میز: ${table.capacity}")
                OutlinedTextField(guestCount, { guestCount = it.filter(Char::isDigit) }, label = { Text("تعداد مهمان") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(waiterName, { waiterName = it }, label = { Text("مسئول میز / گارسون") }, singleLine = true)
                Text("مشتری", fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    item { FilterChip(selected = customerId == null, onClick = { customerId = null; customerName = "مشتری متفرقه" }, label = { Text("متفرقه") }) }
                    items(customers.take(12), key = { "open-customer-${it.id}" }) { customer ->
                        FilterChip(selected = customerId == customer.id, onClick = { customerId = customer.id; customerName = customer.name }, label = { Text(customer.name, maxLines = 1) })
                    }
                }
                OutlinedTextField(customerName, { customerName = it }, label = { Text("نام مشتری") }, enabled = customerId == null, singleLine = true)
                OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات سفارش") })
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val result = runCatching {
                    OpenTableOrderDraft(table.id, guestCount.toIntOrNull() ?: 0, waiterName, customerId, customerName, notes).validated()
                }
                result.onSuccess(save).onFailure { error = it.message }
            }) { Text("باز کردن سفارش") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun AddOrderItemDialog(
    order: TableOrder,
    menuItems: List<MenuItem>,
    dismiss: () -> Unit,
    save: (TableOrderItemDraft) -> Unit,
) {
    var menuId by remember { mutableStateOf<Long?>(null) }
    var quantity by remember { mutableStateOf("1") }
    var seatNo by remember { mutableStateOf("0") }
    var courseNo by remember { mutableStateOf("1") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val selected = menuItems.firstOrNull { it.id == menuId }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("افزودن آیتم · میز ${order.tableLabel}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (menuItems.isEmpty()) Text("ابتدا محصول و دستور پخت را در ماژول رسپی تعریف کنید.")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    items(menuItems, key = { "order-menu-${it.id}" }) { menu ->
                        FilterChip(selected = menuId == menu.id, onClick = { menuId = menu.id }, label = { Text(menu.name, maxLines = 1) })
                    }
                }
                selected?.let { Text("قیمت واحد: ${formatMoney(it.salePriceRial)} · ایستگاه بر اساس گروه ${it.category}") }
                OutlinedTextField(quantity, { quantity = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("تعداد") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(seatNo, { seatNo = it.filter(Char::isDigit) }, label = { Text("شماره مهمان (اختیاری)") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(courseNo, { courseNo = it.filter(Char::isDigit) }, label = { Text("مرحله سرو") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("تغییرات و توضیحات غذا") })
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(enabled = menuItems.isNotEmpty(), onClick = {
                val result = runCatching {
                    TableOrderItemDraft(
                        menuItemId = requireNotNull(menuId) { "یک محصول انتخاب کنید." },
                        quantity = QuantityMicros.parse(quantity),
                        seatNo = seatNo.toIntOrNull() ?: 0,
                        courseNo = courseNo.toIntOrNull() ?: 1,
                        notes = notes,
                    ).validated()
                }
                result.onSuccess(save).onFailure { error = it.message }
            }) { Text("افزودن و ارسال به آشپزخانه") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun OrderTargetDialog(
    title: String,
    options: List<Pair<Long, String>>,
    dismiss: () -> Unit,
    save: (Long) -> Unit,
) {
    var selectedId by remember(options) { mutableStateOf(options.firstOrNull()?.first) }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (options.isEmpty()) Text("گزینه مناسبی برای این عملیات وجود ندارد.")
                else SelectionField(
                    label = "مقصد",
                    selectedText = options.firstOrNull { it.first == selectedId }?.second,
                    options = options,
                    onSelected = { selectedId = it },
                )
            }
        },
        confirmButton = { Button(enabled = selectedId != null, onClick = { selectedId?.let(save) }) { Text("تأیید") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun BillSplitModeDialog(dismiss: () -> Unit, save: (BillSplitMode) -> Unit) {
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("تقسیم صورتحساب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("روش تقسیم را انتخاب کنید. پس از ایجاد سهم‌ها، تغییر اقلام سفارش تا پایان تسویه غیرفعال می‌شود.")
                FilledTonalButton(onClick = { save(BillSplitMode.BY_GUEST) }, modifier = Modifier.fillMaxWidth()) { Text("بر اساس شماره مهمان") }
                OutlinedButton(onClick = { save(BillSplitMode.BY_ITEM) }, modifier = Modifier.fillMaxWidth()) { Text("هر آیتم یک صورتحساب") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun VoidOrderLineDialog(dismiss: () -> Unit, save: (VoidOrderLineDraft) -> Unit) {
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("ابطال ردیف سفارش") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("این عملیات فقط برای کاربر دارای دسترسی حسابرسی انجام می‌شود و هویت تأییدکننده خودکار ثبت خواهد شد.")
                Text("غذای آماده یا سرو‌شده از این مسیر قابل ابطال نیست و باید به‌عنوان ضایعات یا برگشت مدیریت شود.")
                OutlinedTextField(reason, { reason = it }, label = { Text("علت ابطال") }, modifier = Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching { VoidOrderLineDraft(reason).validated() }
                    .onSuccess(save)
                    .onFailure { error = it.message }
            }) { Text("ثبت ابطال") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun CashShiftDialog(
    activeShift: ir.sabou.inventory.domain.sales.CashShift?,
    dismiss: () -> Unit,
    open: (Long, String) -> Unit,
    close: (Long, String) -> Unit,
) {
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text(if (activeShift == null) "افتتاح صندوق" else "بستن صندوق") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                activeShift?.let { Text("موجودی ابتدای شیفت: ${formatMoney(it.openingFloat.value)}") }
                OutlinedTextField(
                    amount,
                    { amount = formatMoneyInput(it) },
                    label = { Text(if (activeShift == null) "تنخواه ابتدای شیفت" else "وجه نقد شمارش‌شده") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(note, { note = it }, label = { Text("یادداشت") }, modifier = Modifier.fillMaxWidth())
                if (activeShift != null) Text("پس از ثبت، فروش نقدی و دریافت‌های نقدی این شیفت با مبلغ شمارش‌شده تطبیق داده می‌شوند.")
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching { parseMoneyInputOrZero(amount) }.onSuccess { value ->
                    if (activeShift == null) open(value, note) else close(value, note)
                }.onFailure { error = it.message }
            }) { Text(if (activeShift == null) "باز کردن" else "بستن و محاسبه مغایرت") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun CheckoutOrderDialog(
    order: TableOrder,
    title: String = "تسویه میز ${order.tableLabel}",
    dismiss: () -> Unit,
    save: (TableCheckoutDraft) -> Unit,
) {
    var discount by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("") }
    var card by remember { mutableStateOf("") }
    var transfer by remember { mutableStateOf("") }
    var dueDay by remember { mutableStateOf<Long?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val discountRial = parseMoneyInputOrZero(discount)
    val serviceRial = parseMoneyInputOrZero(service)
    val totalRial = (order.subtotal.value - discountRial + serviceRial).coerceAtLeast(0L)
    val paidRial = listOf(cash, card, transfer).sumOf(::parseMoneyInputOrZero)
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${order.lines.size} ردیف · ${order.guestCount} مهمان")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(discount, { discount = formatMoneyInput(it) }, label = { Text("تخفیف") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(service, { service = formatMoneyInput(it) }, label = { Text("خدمات") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                HorizontalDivider()
                Text("تقسیم پرداخت", fontWeight = FontWeight.Bold)
                OutlinedTextField(cash, { cash = formatMoneyInput(it) }, label = { Text("نقدی") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(card, { card = formatMoneyInput(it) }, label = { Text("کارتخوان") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(transfer, { transfer = formatMoneyInput(it) }, label = { Text("حواله") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("مبلغ صورتحساب"); Text(formatMoney(totalRial), fontWeight = FontWeight.Bold) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("پرداخت‌شده"); Text(formatMoney(paidRial)) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("باقیمانده"); Text(formatMoney((totalRial - paidRial).coerceAtLeast(0)), color = if (paidRial < totalRial) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }
                if (paidRial < totalRial) {
                    Text(if (order.customerId == null) "برای مانده اعتباری، سفارش باید به مشتری ثبت‌شده متصل باشد." else "مانده به حساب ${order.customerName} ثبت می‌شود.")
                    OptionalPersianDateField("تاریخ سررسید", dueDay, { dueDay = it }, defaultEpochDay = currentEpochDay())
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(onClick = {
                val result = runCatching {
                    require(discountRial <= order.subtotal.value) { "تخفیف از جمع سفارش بیشتر است." }
                    require(paidRial <= totalRial) { "مجموع پرداخت‌ها از صورتحساب بیشتر است." }
                    val allocations = buildList {
                        parseMoneyInputOrZero(cash).takeIf { it > 0 }?.let { add(SalePaymentAllocation(SalePaymentMethod.CASH, MoneyRial.of(it))) }
                        parseMoneyInputOrZero(card).takeIf { it > 0 }?.let { add(SalePaymentAllocation(SalePaymentMethod.CARD, MoneyRial.of(it))) }
                        parseMoneyInputOrZero(transfer).takeIf { it > 0 }?.let { add(SalePaymentAllocation(SalePaymentMethod.TRANSFER, MoneyRial.of(it))) }
                    }
                    TableCheckoutDraft(MoneyRial.of(discountRial), MoneyRial.of(serviceRial), allocations, currentEpochDay(), dueDay)
                }
                result.onSuccess(save).onFailure { error = it.message }
            }) { Text("ثبت صورتحساب") }
        },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}

@Composable
private fun OperationsInputDialog(
    mode: OpsDialog,
    tables: List<RestaurantTable>,
    employees: List<EmployeeRecord>,
    dismiss: () -> Unit,
    save: (String, String, String, String, String, Long, Long?, Int, Int) -> Unit,
) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    var d by remember { mutableStateOf("") }
    var e by remember { mutableStateOf("") }
    var selectedDay by remember { mutableLongStateOf(currentEpochDay()) }
    var selectedTableId by remember(tables) { mutableStateOf(tables.firstOrNull()?.id) }
    var startTime by remember { mutableStateOf("12:00") }
    var endTime by remember { mutableStateOf("14:00") }
    var error by remember { mutableStateOf<String?>(null) }
    val labels = when (mode) {
        OpsDialog.TABLE -> listOf("برچسب میز", "ظرفیت", "بخش")
        OpsDialog.RESERVATION -> listOf("نام مشتری", "تلفن", "تعداد مهمان", "یادداشت")
        OpsDialog.KITCHEN -> listOf("شماره سفارش", "ایستگاه", "نام آیتم", "تعداد", "اولویت ۰ تا ۱۰")
        OpsDialog.SHIFT -> listOf("شروع به دقیقه", "پایان به دقیقه", "نیروی موردنیاز")
        OpsDialog.APPROVAL -> listOf("نوع درخواست", "شناسه مرجع", "مبلغ", "درخواست‌کننده")
    }
    val values = listOf(a, b, c, d, e)
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("ثبت ${mode.name}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                if (mode == OpsDialog.RESERVATION) {
                    SelectionField(
                        label = "میز رزرو",
                        selectedText = tables.firstOrNull { it.id == selectedTableId }?.let { "میز ${it.label} · ظرفیت ${it.capacity}" },
                        options = tables.map { it.id to "میز ${it.label} · ${it.zone} · ظرفیت ${it.capacity}" },
                        onSelected = { selectedTableId = it },
                    )
                }
                if (mode == OpsDialog.SHIFT) Text("${employees.count { it.isActive }} پرسنل فعال")
                if (mode == OpsDialog.RESERVATION || mode == OpsDialog.SHIFT) {
                    PersianDateField(
                        label = if (mode == OpsDialog.RESERVATION) "تاریخ رزرو" else "تاریخ شیفت",
                        epochDay = selectedDay,
                        onSelected = { selectedDay = it },
                    )
                }
                labels.forEachIndexed { index, label ->
                    OutlinedTextField(
                        values[index],
                        { rawValue ->
                            val value = if (mode == OpsDialog.APPROVAL && index == 2) formatMoneyInput(rawValue) else rawValue
                            when (index) {
                                0 -> a = value
                                1 -> b = value
                                2 -> c = value
                                3 -> d = value
                                else -> e = value
                            }
                        },
                        label = { Text(label) },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = if (mode == OpsDialog.APPROVAL && index == 2) KeyboardType.Number else KeyboardType.Text,
                        ),
                        singleLine = true,
                    )
                }
                if (mode == OpsDialog.RESERVATION) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            startTime,
                            { startTime = normalizeClockInput(it) },
                            label = { Text("ساعت شروع") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            endTime,
                            { endTime = normalizeClockInput(it) },
                            label = { Text("ساعت پایان") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                        )
                    }
                }
            }
        },
        confirmButton = { Button(onClick = {
            runCatching {
                val start = if (mode == OpsDialog.RESERVATION) parseClockMinute(startTime) else 0
                val end = if (mode == OpsDialog.RESERVATION) parseClockMinute(endTime) else 0
                if (mode == OpsDialog.RESERVATION) {
                    require(selectedTableId != null) { "یک میز برای رزرو انتخاب کنید." }
                    require(end > start) { "ساعت پایان باید بعد از ساعت شروع باشد." }
                }
                save(a, b, c, d, e, selectedDay, selectedTableId, start, end)
            }.onSuccess { dismiss() }.onFailure { error = it.message ?: "اطلاعات رزرو معتبر نیست." }
        }) { Text("ثبت") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}
