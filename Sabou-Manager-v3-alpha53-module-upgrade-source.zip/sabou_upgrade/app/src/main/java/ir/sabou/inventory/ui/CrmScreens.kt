@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun CrmScreen(state: CrmState, onAdjustPoints: (Long,Long,String)->Unit, onAddFollowUp:(Long,String,Long,String)->Unit, onComplete:(Long)->Unit, onBack:()->Unit) {
    var selected by remember { mutableStateOf<Long?>(null) }
    var points by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var due by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    val selectedCustomer = state.customers.firstOrNull { it.id == selected }
    val openFollowUps = state.followUps.count { !it.isDone }
    val totalValue = state.customers.sumOf { it.lifetimeValueRial }
    val topCustomer = state.customers.maxByOrNull { it.lifetimeValueRial }

    Scaffold(topBar = { ProfessionalTopBar("مشتریان", "وفاداری، ارزش خرید و پیگیری ارتباطات", onBack) }, containerColor = MaterialTheme.colorScheme.background) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item { PremiumHero("ارزش جامعه مشتریان", formatMoney(totalValue), if (topCustomer == null) "هنوز خریدی ثبت نشده" else "مشتری برتر: ${topCustomer.name}") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("مشتریان", state.customers.size.toString(), Modifier.weight(1f)); MetricTile("پیگیری باز", openFollowUps.toString(), Modifier.weight(1f)) } }
            item { SectionHeading("پروفایل مشتریان", "برای عملیات وفاداری یک مشتری را انتخاب کنید") }
            if (state.customers.isEmpty()) item { EmptyStatePanel("هنوز مشتری ندارید", "با ثبت اولین فروش، پروفایل مشتری ساخته می‌شود.") }
            items(state.customers, key = { it.id }) { c ->
                ElevatedCard(onClick = { selected = if (selected == c.id) null else c.id }, shape = RoundedCornerShape(24.dp), colors = CardDefaults.elevatedCardColors(containerColor = if (selected == c.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface), elevation = CardDefaults.elevatedCardElevation(1.dp)) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(c.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black); Text(if (c.phone.isBlank()) "بدون شماره تماس" else c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                            StatusPill("${c.points} امتیاز")
                        }
                        CompactInfoRow("ارزش خرید", formatMoney(c.lifetimeValueRial), true)
                    }
                }
            }
            selectedCustomer?.let { customer -> item {
                FormSection("اقدامات ${customer.name}", "امتیاز وفاداری و پیگیری جدید") {
                    OutlinedTextField(points, { points = it }, label = { Text("تغییر امتیاز") }, supportingText = { Text("برای کسر، عدد منفی وارد کنید") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(reason, { reason = it }, label = { Text("دلیل تغییر") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { points.toLongOrNull()?.let { onAdjustPoints(customer.id, it, reason); points=""; reason="" } }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("ثبت تغییر امتیاز") }
                    HorizontalDivider()
                    OutlinedTextField(title, { title = it }, label = { Text("عنوان پیگیری") }, modifier = Modifier.fillMaxWidth())
                    PersianDateField("تاریخ پیگیری", due.toLongOrNull() ?: (System.currentTimeMillis()/86_400_000L)) { due = it.toString() }
                    OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    FilledTonalButton(onClick = { due.toLongOrNull()?.let { onAddFollowUp(customer.id, title, it, notes); title=""; due=""; notes="" } }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("ثبت پیگیری") }
                }
            } }
            item { SectionHeading("پیگیری‌های ارتباطی", "کارهای باز در ابتدای فهرست") }
            if (state.followUps.isEmpty()) item { EmptyStatePanel("پیگیری فعالی نیست", "برای تماس یا یادآوری یک پیگیری بسازید.") }
            items(state.followUps.sortedBy { it.isDone }, key = { it.id }) { f ->
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = if (f.isDone) MaterialTheme.colorScheme.surfaceContainerLow else MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) { Column(Modifier.weight(1f)) { Text(f.title, fontWeight = FontWeight.Black); Text(f.customerName, style = MaterialTheme.typography.bodySmall) }; StatusPill(if (f.isDone) "انجام‌شده" else "باز") }
                        CompactInfoRow("سررسید", epochDayToPersian(f.dueEpochDay).display())
                        if (f.notes.isNotBlank()) Text(f.notes, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (!f.isDone) FilledTonalButton(onClick = { onComplete(f.id) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("انجام شد") }
                    }
                }
            }
        }
    }
}

