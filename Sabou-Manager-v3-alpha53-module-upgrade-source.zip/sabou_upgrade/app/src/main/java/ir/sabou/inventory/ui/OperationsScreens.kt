package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.SupplierRecord
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseLineDraft
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod

@Composable
fun SuppliersScreen(
    state: OperationsUiState,
    onSave: (Long?, SupplierDraft, () -> Unit) -> Unit,
    onDeactivate: (Long) -> Unit,
    onBack: () -> Unit,
) {
    var editorOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<SupplierRecord?>(null) }
    var deactivateTarget by remember { mutableStateOf<SupplierRecord?>(null) }
    val averageTerms = if (state.suppliers.isEmpty()) 0 else state.suppliers.map { it.paymentTermsDays }.average().toInt()
    Scaffold(topBar = { ProfessionalTopBar("تأمین‌کنندگان", "شبکه تأمین، تماس‌ها و شرایط پرداخت", onBack, "تأمین‌کننده جدید") { selected = null; editorOpen = true } }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item { PremiumHero("شبکه تأمین فعال", "${state.suppliers.size} تأمین‌کننده", "میانگین مهلت پرداخت $averageTerms روز") }
            item { SectionHeading("شرکای تأمین", "اطلاعات تماس و شرایط همکاری") }
            if (state.suppliers.isEmpty()) item { EmptyStatePanel("تأمین‌کننده‌ای ثبت نشده", "اولین شریک تأمین را اضافه کنید تا ثبت خرید سریع‌تر شود.") }
            items(state.suppliers, key = { it.id }) { supplier ->
                ElevatedCard(shape = RoundedCornerShape(24.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.elevatedCardElevation(1.dp)) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(supplier.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                                Text(if (supplier.contactName.isBlank()) "بدون رابط ثبت‌شده" else supplier.contactName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill("${supplier.paymentTermsDays} روز")
                        }
                        if (supplier.phone.isNotBlank()) CompactInfoRow("شماره تماس", supplier.phone)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { selected = supplier; editorOpen = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("ویرایش") }
                            TextButton(onClick = { deactivateTarget = supplier }, modifier = Modifier.weight(1f)) { Text("غیرفعال‌کردن", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }
    if (editorOpen) SupplierEditorDialog(existing = selected, busy = state.busy, onDismiss = { editorOpen = false }, onSave = { draft -> onSave(selected?.id, draft) { editorOpen = false } })
    deactivateTarget?.let { target -> ConfirmDeactivateDialog("غیرفعال‌کردن تأمین‌کننده", "«${target.name}» از فهرست انتخاب‌ها حذف می‌شود؛ سوابق قبلی باقی می‌مانند.", { deactivateTarget = null }) { deactivateTarget = null; onDeactivate(target.id) } }
}

@Composable
fun InventoryScreen(
    state: OperationsUiState,
    onSave: (Long?, InventoryItemDraft, () -> Unit) -> Unit,
    onDeactivate: (Long) -> Unit,
    onCount: (InventoryCountDraft, () -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var editorOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<InventoryItemRecord?>(null) }
    var deactivateTarget by remember { mutableStateOf<InventoryItemRecord?>(null) }
    var countTarget by remember { mutableStateOf<InventoryItemRecord?>(null) }
    val totalValue = state.inventoryItems.sumOf { it.inventoryValueRial }
    val healthyCount = (state.inventoryItems.size - state.lowStockItems.size).coerceAtLeast(0)

    Scaffold(
        topBar = { ProfessionalTopBar("انبار", "موجودی، ارزش کالاها و هشدارهای تأمین", onBack, "کالای جدید") { selected = null; editorOpen = true } },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            state.message?.let { item { MessageCard(it) } }
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("ارزش موجودی", color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = .72f), style = MaterialTheme.typography.labelLarge)
                        Text(formatMoney(totalValue), color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile("کالای سالم", healthyCount.toString(), Modifier.weight(1f))
                            MetricTile("نیازمند تأمین", state.lowStockItems.size.toString(), Modifier.weight(1f))
                        }
                    }
                }
            }
            item { SectionHeading("کالاها", "موجودی لحظه‌ای و عملیات انبارگردانی") }
            if (state.inventoryItems.isEmpty()) item { EmptyStatePanel("انبار خالی است", "اولین کالا را ثبت کنید و موجودی اولیه را وارد کنید.") }
            items(state.inventoryItems, key = { it.id }) { item ->
                val isLow = state.lowStockItems.any { it.id == item.id }
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
                                Text(item.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill(
                                if (isLow) "کمبود" else "موجود",
                                containerColor = if (isLow) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = if (isLow) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("موجودی", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${formatQuantity(item.stockMicros)} ${item.unit}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("ارزش", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatMoney(item.inventoryValueRial), fontWeight = FontWeight.Bold)
                            }
                        }
                        if (item.alertEnabled) Text("حد هشدار: ${formatQuantity(item.alertThresholdMicros)} ${item.unit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { countTarget = item }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("انبارگردانی") }
                            TextButton(onClick = { selected = item; editorOpen = true }) { Text("ویرایش") }
                            TextButton(onClick = { deactivateTarget = item }) { Text("غیرفعال", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }
    if (editorOpen) InventoryEditorDialog(existing = selected, suppliers = state.suppliers, busy = state.busy, onDismiss = { editorOpen = false }, onSave = { draft -> onSave(selected?.id, draft) { editorOpen = false } })
    deactivateTarget?.let { target -> ConfirmDeactivateDialog("غیرفعال‌کردن کالا", "«${target.name}» از فهرست کالاهای فعال حذف می‌شود؛ گردش انبار قبلی باقی می‌ماند.", { deactivateTarget = null }) { deactivateTarget = null; onDeactivate(target.id) } }
    countTarget?.let { item -> InventoryCountDialog(item, state.busy, onDismiss = { countTarget = null }) { draft -> onCount(draft) { countTarget = null } } }
}

@Composable
private fun InventoryCountDialog(item: InventoryItemRecord, busy: Boolean, onDismiss: () -> Unit, onSave: (InventoryCountDraft) -> Unit) {
    var quantity by remember { mutableStateOf((item.stockMicros / 1_000_000.0).toString()) }
    var value by remember { mutableStateOf(item.inventoryValueRial.toString()) }
    var day by remember { mutableStateOf((System.currentTimeMillis() / 86_400_000L).toString()) }
    var reason by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("انبارگردانی ${item.name}")}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("موجودی فعلی: ${item.stockMicros / 1_000_000.0} ${item.unit}")
        OutlinedTextField(quantity,{quantity=it.filter{c->c.isDigit()||c=='.'}},label={Text("مقدار شمارش‌شده")})
        OutlinedTextField(value,{value=it.filter(Char::isDigit)},label={Text("ارزش کل موجودی (ریال)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        OutlinedTextField(day,{day=it.filter(Char::isDigit)},label={Text("روز سیستم")})
        OutlinedTextField(reason,{reason=it},label={Text("دلیل اصلاح")})
    }}, confirmButton={Button(enabled=!busy,onClick={
        val micros=((quantity.toDoubleOrNull()?:-1.0)*1_000_000.0).toLong()
        onSave(InventoryCountDraft(item.id,micros,value.toLongOrNull()?:-1,day.toLongOrNull()?:0,reason))
    }){Text("ثبت انبارگردانی")}}, dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
fun AuditLogScreen(state: OperationsUiState, onBack: () -> Unit) {
    Scaffold(topBar={ ScreenHeader("لاگ عملیات", null, {}, onBack) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(state.auditLogs, key={it.id}) { log -> Card { Column(Modifier.fillMaxWidth().padding(12.dp)) { Text(log.action, fontWeight=FontWeight.Bold); Text(log.description); Text("${log.actor} · ${log.createdAtEpochMillis}", style=MaterialTheme.typography.labelSmall) } } }
        }
    }
}

@Composable
fun PurchasesScreen(
    state: OperationsUiState,
    onSearch: (String) -> Unit,
    onSelect: (Long?) -> Unit,
    onSettle: (ir.sabou.inventory.domain.purchase.PurchaseSettlementDraft, () -> Unit) -> Unit,
    onReverseSettlement: (ir.sabou.inventory.domain.purchase.PurchaseSettlementReversalDraft, () -> Unit) -> Unit,
    onReverse: (ir.sabou.inventory.domain.purchase.PurchaseReversalDraft, () -> Unit) -> Unit,
    onAdd: () -> Unit,
    onBack: () -> Unit,
) {
    val open = state.purchases.filter { it.outstandingRial > 0 && it.paymentStatus != "REVERSED" }
    val outstanding = open.sumOf { it.outstandingRial }
    Scaffold(topBar = { ProfessionalTopBar("خرید و تأمین", "فاکتورها، پرداخت‌ها و تعهدات", onBack, "خرید جدید", onAdd) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item { PremiumHero("تعهد باز خرید", formatMoney(outstanding), "${open.size} فاکتور نیازمند تسویه") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("کل فاکتورها", state.purchases.size.toString(), Modifier.weight(1f)); MetricTile("تسویه‌شده", state.purchases.count { it.paymentStatus == "PAID" }.toString(), Modifier.weight(1f)) } }
            item { PremiumSearchField(state.purchaseSearch, onSearch, "شماره فاکتور یا نام تأمین‌کننده") }
            item { SectionHeading("فاکتورهای خرید", "برای مشاهده جزئیات و تسویه روی کارت بزنید") }
            if (state.purchases.isEmpty()) item { EmptyStatePanel(if (state.purchaseSearch.isBlank()) "هنوز خریدی ثبت نشده" else "نتیجه‌ای پیدا نشد", if (state.purchaseSearch.isBlank()) "اولین فاکتور خرید را ثبت کنید." else "عبارت جست‌وجو را تغییر دهید.") }
            items(state.purchases, key = { it.id }) { purchase ->
                val status = when (purchase.paymentStatus) { "PAID" -> "تسویه‌شده"; "PARTIAL" -> "پرداخت ناقص"; "REVERSED" -> "برگشت‌خورده"; else -> "تسویه‌نشده" }
                InvoiceSummaryCard("فاکتور ${purchase.invoiceNo}", purchase.supplierName, formatMoney(purchase.totalRial), status, "خرید ${epochDayToPersian(purchase.purchaseEpochDay).display()} • سررسید ${epochDayToPersian(purchase.dueEpochDay).display()}", purchase.outstandingRial.takeIf { it > 0 && purchase.paymentStatus != "REVERSED" }?.let(::formatMoney)) { onSelect(purchase.id) }
            }
        }
    }
    state.selectedPurchase?.let { details -> PurchaseDetailsDialog(details, state.busy, { onSelect(null) }, onSettle, onReverseSettlement, onReverse) }
}

private data class PurchaseLineForm(
    val rowId: Int,
    val itemId: Long? = null,
    val quantity: String = "",
    val unitCostRial: String = "",
)

@Composable
fun PurchaseEntryScreen(
    state: OperationsUiState,
    onPost: (PurchaseDraft, (PostedPurchase) -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    val todayEpochDay = remember { System.currentTimeMillis() / 86_400_000L }
    var invoiceNo by remember { mutableStateOf("") }
    var supplierId by remember { mutableStateOf<Long?>(null) }
    var purchaseEpochDay by remember { mutableLongStateOf(todayEpochDay) }
    var dueEpochDay by remember { mutableLongStateOf(todayEpochDay) }
    var paymentMethod by remember { mutableStateOf(PurchasePaymentMethod.PAYABLE) }
    var reminderEnabled by remember { mutableStateOf(true) }
    var reminderEpochDay by remember { mutableLongStateOf(todayEpochDay) }
    var nextRowId by remember { mutableIntStateOf(2) }
    var lines by remember { mutableStateOf(listOf(PurchaseLineForm(rowId = 1))) }
    var localError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            ScreenHeader(
                title = "ثبت فاکتور خرید",
                actionLabel = null,
                onAction = {},
                onBack = onBack,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.message?.let { MessageCard(it) }
            localError?.let { MessageCard(it, isError = true) }
            if (state.suppliers.isEmpty() || state.inventoryItems.isEmpty()) {
                MessageCard(
                    "برای ثبت خرید، ابتدا حداقل یک تأمین‌کننده و یک کالا ثبت کنید.",
                    isError = true,
                )
            }
            OutlinedTextField(
                value = invoiceNo,
                onValueChange = { invoiceNo = it },
                label = { Text("شماره فاکتور") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            SelectionField(
                label = "تأمین‌کننده",
                selectedText = state.suppliers.firstOrNull { it.id == supplierId }?.name,
                options = state.suppliers.map { it.id to it.name },
                onSelected = { id ->
                    supplierId = id
                    val terms = state.suppliers.first { it.id == id }.paymentTermsDays
                    dueEpochDay = purchaseEpochDay + terms.toLong()
                    reminderEpochDay = dueEpochDay
                },
            )
            PersianDateField(
                label = "تاریخ خرید",
                epochDay = purchaseEpochDay,
                onSelected = { selectedDate ->
                    val previousTerm = dueEpochDay - purchaseEpochDay
                    purchaseEpochDay = selectedDate
                    dueEpochDay = selectedDate + previousTerm.coerceAtLeast(0)
                    if (reminderEpochDay < selectedDate) reminderEpochDay = selectedDate
                },
            )
            PersianDateField(
                label = "تاریخ تسویه",
                epochDay = dueEpochDay,
                onSelected = { dueEpochDay = it },
            )
            PaymentMethodField(paymentMethod) { paymentMethod = it }
            if (paymentMethod == PurchasePaymentMethod.PAYABLE) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = reminderEnabled,
                        onCheckedChange = { reminderEnabled = it },
                    )
                    Text("یادآوری تسویه")
                }
                if (reminderEnabled) {
                    PersianDateField(
                        label = "تاریخ یادآوری",
                        epochDay = reminderEpochDay,
                        onSelected = { reminderEpochDay = it },
                    )
                }
            }

            Text("اقلام فاکتور", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            lines.forEachIndexed { index, line ->
                PurchaseLineEditor(
                    index = index,
                    line = line,
                    items = state.inventoryItems,
                    removable = lines.size > 1,
                    onChanged = { changed ->
                        lines = lines.map { if (it.rowId == line.rowId) changed else it }
                    },
                    onRemove = {
                        lines = lines.filterNot { it.rowId == line.rowId }
                    },
                )
            }
            OutlinedButton(
                onClick = {
                    lines = lines + PurchaseLineForm(rowId = nextRowId)
                    nextRowId++
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("افزودن ردیف")
            }
            Button(
                enabled = !state.busy && state.suppliers.isNotEmpty() && state.inventoryItems.isNotEmpty(),
                onClick = {
                    try {
                        localError = null
                        val draft = PurchaseDraft(
                            invoiceNo = invoiceNo.trim(),
                            supplierId = requireNotNull(supplierId) { "تأمین‌کننده را انتخاب کنید." },
                            purchaseEpochDay = purchaseEpochDay,
                            dueEpochDay = dueEpochDay,
                            paymentMethod = paymentMethod,
                            reminderEnabled = paymentMethod == PurchasePaymentMethod.PAYABLE && reminderEnabled,
                            reminderEpochDay = if (
                                paymentMethod == PurchasePaymentMethod.PAYABLE && reminderEnabled
                            ) {
                                reminderEpochDay
                            } else {
                                null
                            },
                            lines = lines.map { line ->
                                PurchaseLineDraft(
                                    itemId = requireNotNull(line.itemId) {
                                        "کالای ردیف فاکتور را انتخاب کنید."
                                    },
                                    quantity = parseQuantity(line.quantity),
                                    unitCost = parseMoneyRial(line.unitCostRial),
                                )
                            },
                        )
                        onPost(draft) { onBack() }
                    } catch (error: Exception) {
                        localError = error.message ?: "اطلاعات فاکتور کامل نیست."
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (state.busy) "در حال ثبت…" else "ثبت نهایی خرید")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PurchaseLineEditor(
    index: Int,
    line: PurchaseLineForm,
    items: List<InventoryItemRecord>,
    removable: Boolean,
    onChanged: (PurchaseLineForm) -> Unit,
    onRemove: () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("ردیف ${index + 1}", fontWeight = FontWeight.Bold)
                if (removable) TextButton(onClick = onRemove) { Text("حذف ردیف") }
            }
            SelectionField(
                label = "کالا",
                selectedText = items.firstOrNull { it.id == line.itemId }?.name,
                options = items.map { it.id to "${it.name} (${it.unit})" },
                onSelected = { onChanged(line.copy(itemId = it)) },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = line.quantity,
                    onValueChange = { onChanged(line.copy(quantity = it)) },
                    label = { Text("مقدار") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = line.unitCostRial,
                    onValueChange = { onChanged(line.copy(unitCostRial = it)) },
                    label = { Text("بهای واحد (ریال)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun SupplierEditorDialog(
    existing: SupplierRecord?,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (SupplierDraft) -> Unit,
) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var contact by remember(existing?.id) { mutableStateOf(existing?.contactName.orEmpty()) }
    var phone by remember(existing?.id) { mutableStateOf(existing?.phone.orEmpty()) }
    var address by remember(existing?.id) { mutableStateOf(existing?.address.orEmpty()) }
    var terms by remember(existing?.id) { mutableStateOf(existing?.paymentTermsDays?.toString() ?: "0") }
    var notes by remember(existing?.id) { mutableStateOf(existing?.notes.orEmpty()) }
    var error by remember(existing?.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "تأمین‌کننده جدید" else "ویرایش تأمین‌کننده") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedTextField(name, { name = it }, label = { Text("نام") })
                OutlinedTextField(contact, { contact = it }, label = { Text("نام رابط") })
                OutlinedTextField(
                    phone,
                    { phone = it },
                    label = { Text("شماره تماس") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
                OutlinedTextField(address, { address = it }, label = { Text("نشانی") })
                OutlinedTextField(
                    terms,
                    { terms = it },
                    label = { Text("مهلت تسویه پیش‌فرض (روز)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") })
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    try {
                        val parsedTerms = normalizeNumberInput(terms).toInt()
                        onSave(
                            SupplierDraft(
                                name = name,
                                contactName = contact,
                                phone = phone,
                                address = address,
                                paymentTermsDays = parsedTerms,
                                notes = notes,
                            ),
                        )
                    } catch (failure: Exception) {
                        error = failure.message ?: "مهلت تسویه معتبر نیست."
                    }
                },
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun InventoryEditorDialog(
    existing: InventoryItemRecord?,
    suppliers: List<SupplierRecord>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (InventoryItemDraft) -> Unit,
) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var category by remember(existing?.id) { mutableStateOf(existing?.category.orEmpty()) }
    var unit by remember(existing?.id) { mutableStateOf(existing?.unit.orEmpty()) }
    var supplierId by remember(existing?.id) { mutableStateOf(existing?.supplierId) }
    var alertEnabled by remember(existing?.id) { mutableStateOf(existing?.alertEnabled ?: true) }
    var threshold by remember(existing?.id) {
        mutableStateOf(existing?.let { formatQuantity(it.alertThresholdMicros) } ?: "5")
    }
    var error by remember(existing?.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "کالای جدید" else "ویرایش کالا") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedTextField(name, { name = it }, label = { Text("نام کالا") })
                OutlinedTextField(category, { category = it }, label = { Text("دسته‌بندی") })
                OutlinedTextField(unit, { unit = it }, label = { Text("واحد؛ مثل کیلو، عدد یا بسته") })
                SelectionField(
                    label = "تأمین‌کننده پیش‌فرض (اختیاری)",
                    selectedText = suppliers.firstOrNull { it.id == supplierId }?.name,
                    options = listOf(0L to "بدون تأمین‌کننده") + suppliers.map { it.id to it.name },
                    onSelected = { supplierId = it.takeIf { selectedId -> selectedId != 0L } },
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alertEnabled, onCheckedChange = { alertEnabled = it })
                    Text("هشدار کمبود موجودی")
                }
                if (alertEnabled) {
                    OutlinedTextField(
                        threshold,
                        { threshold = it },
                        label = { Text("حد هشدار") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    try {
                        onSave(
                            InventoryItemDraft(
                                name = name,
                                category = category,
                                unit = unit,
                                alertEnabled = alertEnabled,
                                alertThresholdMicros = if (alertEnabled) {
                                    parseQuantity(threshold).value
                                } else {
                                    0L
                                },
                                supplierId = supplierId,
                            ),
                        )
                    } catch (failure: Exception) {
                        error = failure.message ?: "اطلاعات کالا معتبر نیست."
                    }
                },
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PaymentMethodField(
    selected: PurchasePaymentMethod,
    onSelected: (PurchasePaymentMethod) -> Unit,
) {
    val labels = listOf(
        PurchasePaymentMethod.PAYABLE to "نسیه",
        PurchasePaymentMethod.CASH to "نقدی",
        PurchasePaymentMethod.CARD to "کارتخوان",
        PurchasePaymentMethod.TRANSFER to "حواله",
    )
    SelectionField(
        label = "روش پرداخت",
        selectedText = labels.first { it.first == selected }.second,
        options = labels.mapIndexed { index, value -> index.toLong() to value.second },
        onSelected = { index -> onSelected(labels[index.toInt()].first) },
    )
}

@Composable
internal fun SelectionField(
    label: String,
    selectedText: String?,
    options: List<Pair<Long, String>>,
    onSelected: (Long) -> Unit,
) {
    var expanded by remember { mutableStateOf(false) }
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Box(Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = { expanded = true },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(selectedText ?: "انتخاب کنید")
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
            ) {
                options.forEach { (id, title) ->
                    DropdownMenuItem(
                        text = { Text(title) },
                        onClick = {
                            expanded = false
                            onSelected(id)
                        },
                    )
                }
            }
        }
    }
}

@Composable
internal fun PersianDateField(
    label: String,
    epochDay: Long,
    onSelected: (Long) -> Unit,
) {
    var dialogOpen by remember { mutableStateOf(false) }
    val value = epochDayToPersian(epochDay)
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium)
        OutlinedButton(
            onClick = { dialogOpen = true },
            modifier = Modifier.fillMaxWidth(),
        ) {
            Text(value.display())
        }
    }
    if (dialogOpen) {
        PersianDatePickerDialog(
            initial = value,
            onDismiss = { dialogOpen = false },
            onConfirm = {
                dialogOpen = false
                onSelected(it.toEpochDay())
            },
        )
    }
}

@Composable
private fun PersianDatePickerDialog(
    initial: PersianDate,
    onDismiss: () -> Unit,
    onConfirm: (PersianDate) -> Unit,
) {
    var year by remember { mutableIntStateOf(initial.year) }
    var month by remember { mutableIntStateOf(initial.month) }
    var day by remember { mutableIntStateOf(initial.day) }
    var yearExpanded by remember { mutableStateOf(false) }
    var monthExpanded by remember { mutableStateOf(false) }
    val monthNames = listOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
    )
    val weekDays = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")
    val maxDay = daysInPersianMonth(year, month)
    val effectiveDay = day.coerceAtMost(maxDay)
    val firstWeekDay = runCatching {
        val javaDay = PersianDate(year, month, 1).toEpochDay()
        ((javaDay + 3L) % 7L).toInt() // 0 = شنبه
    }.getOrDefault(0)
    val cells = List(firstWeekDay) { 0 } + (1..maxDay).toList()

    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("انتخاب تاریخ", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                Text(
                    "${effectiveDay} ${monthNames[month - 1]} ${year}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { monthExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(monthNames[month - 1], maxLines = 1)
                        }
                        DropdownMenu(expanded = monthExpanded, onDismissRequest = { monthExpanded = false }) {
                            monthNames.forEachIndexed { index, name ->
                                DropdownMenuItem(text = { Text(name) }, onClick = {
                                    month = index + 1
                                    day = day.coerceAtMost(daysInPersianMonth(year, month))
                                    monthExpanded = false
                                })
                            }
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        OutlinedButton(onClick = { yearExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(year.toString())
                        }
                        DropdownMenu(expanded = yearExpanded, onDismissRequest = { yearExpanded = false }) {
                            (1380..1450).forEach { option ->
                                DropdownMenuItem(text = { Text(option.toString()) }, onClick = {
                                    year = option
                                    day = day.coerceAtMost(daysInPersianMonth(year, month))
                                    yearExpanded = false
                                })
                            }
                        }
                    }
                }

                Row(Modifier.fillMaxWidth()) {
                    weekDays.forEach { label ->
                        Text(
                            text = label,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(7),
                    modifier = Modifier.height(250.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    userScrollEnabled = false,
                ) {
                    items(cells) { option ->
                        Box(modifier = Modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
                            if (option > 0) {
                                val selected = option == effectiveDay
                                Surface(
                                    onClick = { day = option },
                                    modifier = Modifier.fillMaxSize().padding(2.dp),
                                    shape = CircleShape,
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = option.toString(),
                                            maxLines = 1,
                                            softWrap = false,
                                            textAlign = TextAlign.Center,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = if (selected) FontWeight.Black else FontWeight.Medium,
                                            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(PersianDate(year, month, effectiveDay)) }) { Text("انتخاب تاریخ") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun OperationsScaffold(
    title: String,
    actionLabel: String,
    onAction: () -> Unit,
    onBack: () -> Unit,
    message: String?,
    content: @Composable (androidx.compose.foundation.layout.PaddingValues) -> Unit,
) {
    Scaffold(
        topBar = {
            ScreenHeader(
                title = title,
                actionLabel = actionLabel,
                onAction = onAction,
                onBack = onBack,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
        ) {
            Spacer(Modifier.height(padding.calculateTopPadding()))
            message?.let { MessageCard(it) }
            content(androidx.compose.foundation.layout.PaddingValues(bottom = padding.calculateBottomPadding()))
        }
    }
}

@Composable
internal fun ScreenHeader(
    title: String,
    actionLabel: String?,
    onAction: () -> Unit,
    onBack: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) { Text("بازگشت") }
            Spacer(Modifier.width(6.dp))
            Text(
                title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
            )
            if (actionLabel != null) {
                Button(onClick = onAction) { Text(actionLabel) }
            }
        }
    }
}

@Composable
internal fun MessageCard(message: String, isError: Boolean = false) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isError) {
                MaterialTheme.colorScheme.errorContainer
            } else {
                MaterialTheme.colorScheme.secondaryContainer
            },
        ),
    ) {
        Text(message, modifier = Modifier.padding(12.dp))
    }
}

@Composable
private fun EmptyState(
    text: String,
    padding: androidx.compose.foundation.layout.PaddingValues,
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding),
        contentAlignment = Alignment.Center,
    ) {
        Text(text)
    }
}

@Composable
private fun ConfirmDeactivateDialog(
    title: String,
    body: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body) },
        confirmButton = { Button(onClick = onConfirm) { Text("تأیید") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
