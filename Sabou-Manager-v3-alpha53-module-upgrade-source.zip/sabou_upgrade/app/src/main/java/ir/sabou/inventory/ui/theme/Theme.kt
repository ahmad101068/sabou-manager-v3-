package ir.sabou.inventory.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * هویت بصری سابو: «گرمای مهمان‌نوازی + دقت مدیریت».
 * مرجانی برای اقدام، زعفرانی برای توجه، سبز سرو برای اطمینان و جوهری برای خوانایی.
 */
object SabouBrand {
    val Coral = Color(0xFFE84C61)
    val CoralDeep = Color(0xFFB72D46)
    val Saffron = Color(0xFFF5B942)
    val Cypress = Color(0xFF2F6B59)
    val Ink = Color(0xFF211A1C)
    val Porcelain = Color(0xFFFCF9F7)
    val RoseMist = Color(0xFFFFE9EC)
    val Sand = Color(0xFFF4EEE9)
}

private val SabouLightColors = lightColorScheme(
    primary = SabouBrand.Coral,
    onPrimary = Color.White,
    primaryContainer = SabouBrand.RoseMist,
    onPrimaryContainer = Color(0xFF5A1020),
    secondary = SabouBrand.Cypress,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDCEFE7),
    onSecondaryContainer = Color(0xFF123B30),
    tertiary = Color(0xFF8A5B00),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDEA0),
    onTertiaryContainer = Color(0xFF2A1900),
    background = SabouBrand.Porcelain,
    onBackground = SabouBrand.Ink,
    surface = Color.White,
    onSurface = SabouBrand.Ink,
    surfaceVariant = SabouBrand.Sand,
    onSurfaceVariant = Color(0xFF6F6265),
    outline = Color(0xFF94878A),
    outlineVariant = Color(0xFFE7DDDF),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
)

private val SabouDarkColors = darkColorScheme(
    primary = Color(0xFFFFB1BD),
    onPrimary = Color(0xFF680023),
    primaryContainer = Color(0xFF8E1739),
    onPrimaryContainer = Color(0xFFFFD9DE),
    secondary = Color(0xFF9ED6C0),
    onSecondary = Color(0xFF00382B),
    secondaryContainer = Color(0xFF185141),
    onSecondaryContainer = Color(0xFFBAF2DB),
    tertiary = Color(0xFFFFC95C),
    onTertiary = Color(0xFF452B00),
    tertiaryContainer = Color(0xFF644100),
    onTertiaryContainer = Color(0xFFFFDEA0),
    background = Color(0xFF171214),
    onBackground = Color(0xFFF1E2E5),
    surface = Color(0xFF211A1C),
    onSurface = Color(0xFFF1E2E5),
    surfaceVariant = Color(0xFF514447),
    onSurfaceVariant = Color(0xFFD8C2C7),
    outline = Color(0xFFA28F94),
    outlineVariant = Color(0xFF514447),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
)

private val SabouTypography = Typography(
    displaySmall = TextStyle(fontSize = 36.sp, lineHeight = 46.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.5).sp),
    headlineMedium = TextStyle(fontSize = 27.sp, lineHeight = 38.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.2).sp),
    headlineSmall = TextStyle(fontSize = 23.sp, lineHeight = 32.sp, fontWeight = FontWeight.ExtraBold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 29.sp, fontWeight = FontWeight.ExtraBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Bold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 27.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
)

private val SabouShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(34.dp),
)

@Composable
fun SabouTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) SabouDarkColors else SabouLightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.background.toArgb()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.navigationBarColor = colors.surface.toArgb()
            }
        }
    }
    MaterialTheme(
        colorScheme = colors,
        typography = SabouTypography,
        shapes = SabouShapes,
        content = content,
    )
}
