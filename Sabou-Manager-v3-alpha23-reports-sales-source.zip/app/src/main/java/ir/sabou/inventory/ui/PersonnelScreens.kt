@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import java.time.LocalDate

@Composable
fun PersonnelScreen(state: PersonnelUiState, onSaveEmployee: (Long?, EmployeeDraft)->Unit, onDeactivate:(Long)->Unit, onPostPayroll:(PayrollDraft)->Unit, onBack:()->Unit) {
    var showEmployee by remember { mutableStateOf(false) }
    var showPayroll by remember { mutableStateOf(false) }
    Scaffold(topBar={ TopAppBar(title={Text("پرسنل و حقوق")}, navigationIcon={TextButton(onClick=onBack){Text("بازگشت")}}) },
        floatingActionButton={ ExtendedFloatingActionButton(onClick={showEmployee=true}, content={Text("پرسنل جدید")}) }) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad).padding(12.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            item { Button(onClick={showPayroll=true}, enabled=state.employees.any{it.isActive}) { Text("ثبت حقوق ماهانه") } }
            state.message?.let { item { Text(it, color=MaterialTheme.colorScheme.primary) } }
            item { Text("پرسنل", style=MaterialTheme.typography.titleLarge) }
            items(state.employees, key={it.id}) { e -> Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Text("${e.name} · ${e.jobTitle}"); Text("حقوق پایه: ${formatMoney(e.monthlySalaryRial, CurrencyUnit.RIAL)}")
                if(e.isActive) TextButton(onClick={onDeactivate(e.id)}){Text("غیرفعال‌کردن")}
            } } }
            item { Text("سوابق پرداخت", style=MaterialTheme.typography.titleLarge) }
            items(state.payrolls, key={it.id}) { p -> Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                Text("${p.employeeName} · ${p.periodYear}/${p.periodMonth}")
                Text("خالص: ${formatMoney(p.netPayRial, CurrencyUnit.RIAL)}")
            } } }
        }
    }
    if(showEmployee) EmployeeDialog(onDismiss={showEmployee=false}) { onSaveEmployee(null,it); showEmployee=false }
    if(showPayroll) PayrollDialog(state, onDismiss={showPayroll=false}) { onPostPayroll(it); showPayroll=false }
}

@Composable private fun EmployeeDialog(onDismiss:()->Unit,onSave:(EmployeeDraft)->Unit){
    var name by remember{mutableStateOf("")}; var job by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var salary by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("پرسنل جدید")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(name,{name=it},label={Text("نام")}); OutlinedTextField(job,{job=it},label={Text("عنوان شغلی")}); OutlinedTextField(phone,{phone=it},label={Text("تلفن")}); OutlinedTextField(salary,{salary=it},label={Text("حقوق پایه ریال")})
    }},confirmButton={Button(onClick={onSave(EmployeeDraft(name,job,phone,salary.toLongOrNull()?:0))}){Text("ذخیره")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable private fun PayrollDialog(state: PersonnelUiState,onDismiss:()->Unit,onSave:(PayrollDraft)->Unit){
    val active=state.employees.filter{it.isActive}; var selected by remember{mutableStateOf(active.firstOrNull()?.id?:0)}; var expanded by remember{mutableStateOf(false)}
    val now=LocalDate.now(); val todayPersian = epochDayToPersian(now.toEpochDay()); var year by remember{mutableStateOf(todayPersian.year.toString())}; var month by remember{mutableStateOf(todayPersian.month.toString())}; var overtime by remember{mutableStateOf("0")}; var bonus by remember{mutableStateOf("0")}; var deductions by remember{mutableStateOf("0")}; var insurance by remember{mutableStateOf("0")}; var tax by remember{mutableStateOf("0")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("ثبت حقوق")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){
        Box { OutlinedButton(onClick={expanded=true}){Text(active.firstOrNull{it.id==selected}?.name?:"انتخاب پرسنل")}; DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){active.forEach{ DropdownMenuItem(text={Text(it.name)},onClick={selected=it.id;expanded=false}) }}}
        Row{ OutlinedTextField(year,{year=it},Modifier.weight(1f),label={Text("سال")}); Spacer(Modifier.width(6.dp)); OutlinedTextField(month,{month=it},Modifier.weight(1f),label={Text("ماه")}) }
        OutlinedTextField(overtime,{overtime=it},label={Text("اضافه‌کار")}); OutlinedTextField(bonus,{bonus=it},label={Text("پاداش")}); OutlinedTextField(deductions,{deductions=it},label={Text("کسورات")}); OutlinedTextField(insurance,{insurance=it},label={Text("بیمه")}); OutlinedTextField(tax,{tax=it},label={Text("مالیات")})
    }},confirmButton={Button(onClick={onSave(PayrollDraft(selected,year.toIntOrNull()?:0,month.toIntOrNull()?:0,overtime.toLongOrNull()?:0,bonus.toLongOrNull()?:0,deductions.toLongOrNull()?:0,insurance.toLongOrNull()?:0,tax.toLongOrNull()?:0,now.toEpochDay(),"BANK",""))}){Text("ثبت و صدور سند")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}
