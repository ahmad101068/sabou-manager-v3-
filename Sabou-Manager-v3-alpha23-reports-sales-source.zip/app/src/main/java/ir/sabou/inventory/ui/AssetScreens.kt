@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.assets.*
import java.time.LocalDate

@Composable fun AssetScreen(state:AssetUiState,onSave:(Long?,AssetDraft)->Unit,onDispose:(Long)->Unit,onDepreciate:(DepreciationDraft)->Unit,onBack:()->Unit){
 var add by remember{mutableStateOf(false)}; var dep by remember{mutableStateOf(false)}
 Scaffold(topBar={TopAppBar(title={Text("دارایی‌های ثابت")},navigationIcon={TextButton(onClick=onBack){Text("بازگشت")}})},floatingActionButton={ExtendedFloatingActionButton(onClick={add=true}, content={Text("دارایی جدید")})}){pad->
  LazyColumn(Modifier.fillMaxSize().padding(pad).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   item{Button(onClick={dep=true},enabled=state.assets.any{it.isActive}){Text("ثبت استهلاک ماهانه")}}
   state.message?.let{item{Text(it,color=MaterialTheme.colorScheme.primary)}}
   items(state.assets,key={it.id}){a->Card{Column(Modifier.fillMaxWidth().padding(12.dp)){Text("${a.assetCode} · ${a.name}");Text("${a.category} · ${a.location}");Text("ارزش دفتری: ${formatMoney(a.bookValueRial,CurrencyUnit.RIAL)}");Text("استهلاک انباشته: ${formatMoney(a.accumulatedDepreciationRial,CurrencyUnit.RIAL)}");if(a.isActive)TextButton(onClick={onDispose(a.id)}){Text("خروج از بهره‌برداری")}}}}
   item{Text("سوابق استهلاک",style=MaterialTheme.typography.titleLarge)}
   items(state.depreciations,key={it.id}){d->Card{Column(Modifier.fillMaxWidth().padding(12.dp)){Text("${d.assetName} · ${d.periodYear}/${d.periodMonth}");Text(formatMoney(d.amountRial,CurrencyUnit.RIAL))}}}
  }
 }
 if(add) AssetDialog({add=false}){onSave(null,it);add=false}; if(dep) DepDialog(state,{dep=false}){onDepreciate(it);dep=false}
}
@Composable private fun AssetDialog(onDismiss:()->Unit,onSave:(AssetDraft)->Unit){
 var code by remember{mutableStateOf("")};var name by remember{mutableStateOf("")};var cat by remember{mutableStateOf("")};var cost by remember{mutableStateOf("")};var salvage by remember{mutableStateOf("0")};var life by remember{mutableStateOf("")};var location by remember{mutableStateOf("")};val today=LocalDate.now().toEpochDay()
 AlertDialog(onDismissRequest=onDismiss,title={Text("دارایی جدید")},text={Column(verticalArrangement=Arrangement.spacedBy(6.dp)){OutlinedTextField(code,{code=it},label={Text("کد دارایی")});OutlinedTextField(name,{name=it},label={Text("نام")});OutlinedTextField(cat,{cat=it},label={Text("دسته‌بندی")});OutlinedTextField(cost,{cost=it},label={Text("بهای خرید ریال")});OutlinedTextField(salvage,{salvage=it},label={Text("ارزش اسقاط")});OutlinedTextField(life,{life=it},label={Text("عمر مفید (ماه)")});OutlinedTextField(location,{location=it},label={Text("محل استقرار")})}},confirmButton={Button(onClick={onSave(AssetDraft(code,name,cat,today,cost.toLongOrNull()?:0,salvage.toLongOrNull()?:0,life.toIntOrNull()?:0,location,""))}){Text("ذخیره")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}
@Composable private fun DepDialog(state:AssetUiState,onDismiss:()->Unit,onSave:(DepreciationDraft)->Unit){val active=state.assets.filter{it.isActive};var selected by remember{mutableStateOf(active.firstOrNull()?.id?:0)};var ex by remember{mutableStateOf(false)};val p=epochDayToPersian(LocalDate.now().toEpochDay());var year by remember{mutableStateOf(p.year.toString())};var month by remember{mutableStateOf(p.month.toString())}
 AlertDialog(onDismissRequest=onDismiss,title={Text("ثبت استهلاک")},text={Column{Box{OutlinedButton(onClick={ex=true}){Text(active.firstOrNull{it.id==selected}?.name?:"انتخاب دارایی")};DropdownMenu(ex,{ex=false}){active.forEach{DropdownMenuItem(text={Text(it.name)},onClick={selected=it.id;ex=false})}}};OutlinedTextField(year,{year=it},label={Text("سال")});OutlinedTextField(month,{month=it},label={Text("ماه")})}},confirmButton={Button(onClick={onSave(DepreciationDraft(selected,year.toIntOrNull()?:0,month.toIntOrNull()?:0,LocalDate.now().toEpochDay()))}){Text("ثبت و صدور سند")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}
