@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun AlertCenterScreen(
    state: AlertUiState,
    onRefresh: () -> Unit,
    onRead: (Long) -> Unit,
    onDismiss: (Long) -> Unit,
    onClearDismissed: () -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مرکز هشدارها") },
                navigationIcon = { TextButton(onClick = onBack) { Text("بازگشت") } },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onRefresh, enabled = !state.refreshing) {
                        Text(if (state.refreshing) "در حال بررسی…" else "بررسی اکنون")
                    }
                    OutlinedButton(onClick = onClearDismissed) { Text("پاک‌سازی کنارگذاشته‌ها") }
                }
                state.message?.let { Text(it, modifier = Modifier.padding(top = 8.dp)) }
                Text("هشدار فعال: ${state.alerts.size}", style = MaterialTheme.typography.titleMedium)
            }
            if (state.alerts.isEmpty()) item { Text("هشدار فعالی وجود ندارد.") }
            items(state.alerts, key = { it.id }) { alert ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            alert.title,
                            fontWeight = if (alert.isRead) FontWeight.Normal else FontWeight.Bold,
                            color = when (alert.severity) {
                                "HIGH" -> MaterialTheme.colorScheme.error
                                else -> MaterialTheme.colorScheme.primary
                            },
                        )
                        Text(alert.message)
                        alert.dueEpochDay?.let { Text("سررسید: $it") }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!alert.isRead) TextButton(onClick = { onRead(alert.id) }) { Text("خوانده شد") }
                            TextButton(onClick = { onDismiss(alert.id) }) { Text("کنار گذاشتن") }
                        }
                    }
                }
            }
        }
    }
}
