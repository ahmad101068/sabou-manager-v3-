#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
failures: list[str] = []

def text(path: str) -> str:
    p = ROOT / path
    if not p.is_file():
        failures.append(f"missing file: {path}")
        return ""
    return p.read_text(encoding="utf-8")

def require(condition: bool, message: str) -> None:
    if not condition:
        failures.append(message)

def contains(path: str, *needles: str) -> str:
    body = text(path)
    for needle in needles:
        require(needle in body, f"{path}: missing {needle!r}")
    return body

app_db = contains(
    "app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt",
    "APP_DATABASE_SCHEMA_VERSION = 48",
)
contains(
    "app/src/main/java/ir/sabou/inventory/data/db/migration/AppMigrations.kt",
    "MIGRATION_44_45",
    "MIGRATION_45_46",
    "MIGRATION_46_47",
    "MIGRATION_47_48",
)
migration = contains(
    "app/src/main/java/ir/sabou/inventory/data/db/migration/Alpha162Migrations.kt",
    "Migration(45, 46)",
)
for table in (
    "treasury_transactions", "treasury_ledger_entries", "treasury_reconciliations",
    "restaurant_halls", "restaurant_tables", "restaurant_reservations", "restaurant_orders",
    "restaurant_order_lines", "kitchen_tickets", "kitchen_ticket_events", "restaurant_bill_splits",
    "recipe_components", "recipe_substitutions", "asset_lifecycle_events", "asset_maintenance",
    "customer_receivable_ledger", "customer_merge_history",
):
    require(table in migration, f"45->46 migration missing table contract: {table}")
for backfill in ("SALES_INVOICE", "SALES_RETURN"):
    require(backfill in migration, f"45->46 migration missing AR historical backfill: {backfill}")
require("FOREIGN KEY(waiterUserId) REFERENCES app_users(id)" in migration, "restaurant order waiter FK missing from 45->46 migration")
require("FOREIGN KEY(customerId) REFERENCES customers(id)" in migration, "restaurant order customer FK missing from 45->46 migration")
require("index_restaurant_orders_customerId" in migration, "restaurant order customer index missing")
branch_migration = contains(
    "app/src/main/java/ir/sabou/inventory/data/db/migration/Alpha162BranchMigrations.kt",
    "Migration(46, 47)", "sales_invoices", "purchases", "storage_locations", "branchName",
    "index_sales_invoices_branchName", "index_purchases_branchName", "index_storage_locations_branchName",
)

contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/db/EnterpriseCoreMigration45To46Test.kt",
    "integrity_check", "foreign_key_check", "750",
    "index_restaurant_orders_customerId",
    "PRAGMA foreign_key_list(`$childTable`)",
    'assertForeignKey(db, "restaurant_orders", "app_users", "waiterUserId"',
    'assertForeignKey(db, "restaurant_orders", "customers", "customerId"',
    'assertForeignKey(db, "restaurant_orders", "restaurant_tables", "tableId"',
)

# Vertical slices and navigation wiring.
for path, markers in {
    "app/src/main/java/ir/sabou/inventory/application/treasury/TreasuryUseCases.kt": ("class TreasuryUseCases",),
    "app/src/main/java/ir/sabou/inventory/application/restaurant/RestaurantUseCases.kt": ("class RestaurantUseCases",),
    "app/src/main/java/ir/sabou/inventory/application/recipe/RecipeUseCases.kt": ("class RecipeUseCases",),
    "app/src/main/java/ir/sabou/inventory/application/assets/AssetUseCases.kt": ("class AssetUseCases",),
    "app/src/main/java/ir/sabou/inventory/application/crm/CrmUseCases.kt": ("class CrmUseCases",),
    "app/src/main/java/ir/sabou/inventory/data/treasury/LocalTreasuryServiceV2.kt": ("withTransaction", "accounting"),
    "app/src/main/java/ir/sabou/inventory/data/repository/LocalRestaurantService.kt": ("withTransaction", "sales.post", "createHall", "transitionReservation", "waiterUserId"),
    "app/src/main/java/ir/sabou/inventory/data/repository/LocalCustomerAccountService.kt": ("customerReceivableDao", "CUSTOMER_MERGE"),
    "app/src/main/java/ir/sabou/inventory/ui/TreasuryViewModel.kt": ("TreasuryUseCases",),
    "app/src/main/java/ir/sabou/inventory/ui/RestaurantViewModel.kt": ("RestaurantUseCases",),
    "app/src/main/java/ir/sabou/inventory/ui/CrmViewModel.kt": ("CrmUseCases",),
}.items():
    body = text(path)
    for marker in markers:
        require(marker in body, f"{path}: missing wiring marker {marker!r}")

screens = text("app/src/main/java/ir/sabou/inventory/ui/AppRoutes.kt")
for screen in ("TREASURY", "RESTAURANT", "CRM"):
    require(screen in screens, f"AppScreen missing {screen}")
restaurant_ui = text("app/src/main/java/ir/sabou/inventory/ui/RestaurantScreens.kt")
for marker in ("restaurant_shift_reference", "رزروهای فعال", "restaurant_reservation_${reservation.id}_${target.name}"):
    require(marker in restaurant_ui, f"Restaurant UI missing waiter/shift/reservation lifecycle marker: {marker}")
# Full module access moved out of Home in Dashboard UX 2.0; preserve semantic reachability in the More/Operations hubs.
navigation_hubs = text("app/src/main/java/ir/sabou/inventory/ui/NavigationHubScreens.kt")
require("testTag(\"module_${module.screen.name}\")" in navigation_hubs, "Navigation hub module semantics tag missing")
require("AppScreen.TREASURY" in navigation_hubs, "Treasury is not reachable from the role-aware navigation hubs")

# Unused Treasury 1.x adapter must not return to production now that Treasury 2.0 is authoritative.
require(not (ROOT / "app/src/main/java/ir/sabou/inventory/data/treasury/LocalTreasuryServiceAdapter.kt").exists(), "dead Treasury 1.x adapter returned to production")

# Active workforce UI may not invoke legacy fail-fast payroll API.
personnel_vm = text("app/src/main/java/ir/sabou/inventory/ui/PersonnelViewModel.kt")
for forbidden in (".calculatePayroll(", ".postPayroll(", ".approvePayroll(", ".reversePayroll("):
    require(forbidden not in personnel_vm, f"active PersonnelViewModel still calls legacy API: {forbidden}")

# Meaningful God-class extraction: payment orchestration is a dependency, not copied helper methods.
payment = contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/PayrollPaymentPostingService.kt",
    "class PayrollPaymentPostingService", "TreasuryService", "AuditService",
)
hr = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalHrPayrollService.kt")
require("PayrollPaymentPostingService(" in hr, "LocalHrPayrollService does not delegate payroll payment responsibility")
require("paymentPosting.pay(" in hr and "paymentPosting.reverse(" in hr, "Payroll payment delegation incomplete")
contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/PayrollBatchPreparationService.kt",
    "class PayrollBatchPreparationService", "PayrollCalculationService.calculate", "AttendanceCalculationEngine.calculate",
)
require("PayrollBatchPreparationService(database)" in hr, "LocalHrPayrollService does not delegate payroll calculation preparation")
require("calculationPreparation.prepare(" in hr, "Payroll calculation preparation delegation incomplete")
contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/PersonnelAttendanceService.kt",
    "class PersonnelAttendanceService", "database.withTransaction", "Permission.ATTENDANCE_CORRECTION_APPROVE",
)
personnel_repo = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt")
require("PersonnelAttendanceService(" in personnel_repo, "LocalPersonnelRepository does not delegate attendance responsibility")
require("attendanceService.save(" in personnel_repo and "attendanceService.dailySummary(" in personnel_repo, "Personnel attendance delegation incomplete")
contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/InventoryLotMovementService.kt",
    "class InventoryLotMovementService", "FefoLotAllocator.allocate", "compareAndSetQuantity",
)
inventory_engine = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryCommandEngine.kt")
require("InventoryLotMovementService(database)" in inventory_engine, "Inventory command engine does not delegate lot responsibility")
require("lotMovements.planIssue(" in inventory_engine and "lotMovements.applyIssue(" in inventory_engine, "Inventory lot delegation incomplete")
contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/SalesRecipeCostSnapshotService.kt",
    "class SalesRecipeCostSnapshotService", "flattenIngredients", "nestedRecipeExtras",
)
sales_repo = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalProfessionalSalesRepository.kt")
require("SalesRecipeCostSnapshotService(database)" in sales_repo, "Professional sales does not delegate nested recipe costing")
contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/SalesCustomerMasterService.kt",
    "class SalesCustomerMasterService", "Permission.CUSTOMERS", "CUSTOMER_MASTER_MAINTENANCE",
)
require("SalesCustomerMasterService(" in sales_repo and "customerMaster.save(" in sales_repo, "Professional sales does not delegate customer-master responsibility")
procurement_repo = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt")
contains(
    "app/src/main/java/ir/sabou/inventory/data/repository/ProcurementSourcingService.kt",
    "class ProcurementSourcingService", "database.withTransaction", "SupplierSourcingAdvisor.choose",
)
require("ProcurementSourcingService(" in procurement_repo and "sourcingService.submitSuggestedRequisition(" in procurement_repo, "Procurement repository does not delegate sourcing responsibility")
hr_screens = text("app/src/main/java/ir/sabou/inventory/ui/HrPayrollScreens.kt")
hr_dialogs = contains(
    "app/src/main/java/ir/sabou/inventory/ui/HrPayrollDialogs.kt",
    "internal fun Employee360Dialog", "internal fun PayrollPeriodDialog",
    "internal fun AttendanceCorrectionDialog", "internal fun PayslipPaymentDialog",
)
require(len(hr_screens.splitlines()) < 900, "HrPayrollScreens regressed into a presentation God Class")
require(len(hr_dialogs.splitlines()) < 800, "HrPayrollDialogs exceeds focused presentation responsibility threshold")

# Compose UI architecture is present and exercises production MainActivity with persisted result assertions.
libs = text("gradle/libs.versions.toml")
require("androidx-compose-ui-test-junit4" in libs, "Compose UI test dependency missing")
build = text("app/build.gradle.kts")
require("androidTestImplementation(libs.androidx.compose.ui.test.junit4)" in build, "Compose test dependency not wired")
compose_test = contains(
    "app/src/androidTest/java/ir/sabou/inventory/ui/EnterpriseCoreComposeE2ETest.kt",
    "createAndroidComposeRule<MainActivity>()",
    "persisted.journalEntryId",
    "afterBalance",
)
required_compose_flows = (
    "professionalSale_uiToInventoryCogsAndAccounting_isAtomic",
    "saleReturn_uiRestoresInventoryAndCreatesFinancialReversal",
    "purchaseGoodsReceipt_uiIncreasesStockAndPostsBalancedReceiptJournal",
    "inventoryTransfer_uiApproveIssueReceive_preservesTotalOnHand",
    "inventoryCount_uiRecordApproveAndPost_reachesPostedWithoutChangingExactBalance",
    "payrollRegistrationAndApproval_uiCalculatesReviewsAndPostsAccrual",
    "payrollPayment_uiPostsTreasuryAndClosesPayslipBalance",
    "treasuryReceipt_uiToLedgerAndBalance_isPersistedAndPosted",
    "assetDepreciation_uiUpdatesBookValueAndPostsBalancedJournal",
    "recipeActivation_uiCreatesDraftAndActivatesImmutableVersion",
    "restaurantTableKitchenInvoiceMultiPayment_uiClosesTableAndPostsSale",
    "treasuryReversal_uiCreatesCompensatingJournalLedgerReferenceAndMarksOriginalReversed",
    "crmReceipt_viaTreasuryUi_updatesReceivableLedgerAndAgingBalance",
    "crmAdjustment_uiToUseCaseLedgerAccountingAndAudit_isPersisted",
)
for flow in required_compose_flows:
    require(flow in compose_test, f"Enterprise Compose E2E missing mandatory flow: {flow}")
compose_test_count = len(re.findall(r"(?m)^\s*@Test\s*$", compose_test))
require(compose_test_count >= 14, f"Enterprise Compose E2E has only {compose_test_count} @Test methods; expected at least 14")
require("mockito" not in compose_test.lower() and "mockk" not in compose_test.lower(), "Enterprise Compose E2E must not use mock repositories")
startup_compose = contains(
    "app/src/androidTest/java/ir/sabou/inventory/ui/StartupAuthenticationBoundaryComposeTest.kt",
    "createAndroidComposeRule<MainActivity>()",
    "coldStartWithoutSession_showsSecurityAndDoesNotComposeProtectedModules",
    "cashierWithoutPayrollPermission_logsInWithoutPayrollSubscription_andLogoutTearsDownProtectedGraph",
    "ownerWithPayrollPermission_afterLoginCanLoadPayrollWorkspace",
    "persistedSessionInvalidatedByStartupBoundary_returnsToLoginAndDropsProtectedGraph",
)
startup_compose_count = len(re.findall(r"(?m)^\s*@Test\s*$", startup_compose))
require(startup_compose_count >= 4, "Startup authentication Compose regression coverage incomplete")
compose_total = compose_test_count + startup_compose_count
require(compose_total >= 15, f"Total production Compose E2E/regression coverage is {compose_total}; expected at least 15")


# Alpha162 DAO constraints/query coverage must be explicit, not inferred from repository tests.
dao_test = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/db/Alpha162DaoTest.kt",
    "SQLiteConstraintException", "restaurantDao_enforcesHallForeignKeyAndUniqueTableNumberPerHall",
    "treasuryDao_rejectsDuplicateCommandAndOrphanLedgerEntry",
    "restaurantOrder_rejectsOrphanWaiterAndCustomerReferences",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", dao_test)) >= 4, "Alpha162 DAO coverage must contain at least four tests")

# Transaction/idempotency/state-machine integration coverage for the new vertical slices.
treasury_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/TreasuryV2IntegrationTest.kt",
    "receiptReplay_isIdempotentAcrossTreasuryLedgerAndAccounting",
    "missingCustomerAfterAccountingPost_rollsBackEntireTreasuryCommand",
    "internalTransfer_preservesCombinedTreasuryBalanceAndPostsBalancedJournal",
    "receiptReversal_restoresBalanceAndMarksOriginalReversed",
    "purchasePayableSettlement_updatesOperationalPayable_andReversalRestoresIt",
    "reconciliation_persistsDifferenceAndBalancedJournal_zeroDifferenceNeedsNoJournal",
    "paymentReversal_viaUseCase_restoresBalance_setsLedgerReference_andBlocksDoubleReverse",
    "internalTransferReversal_viaUseCase_restoresBothAccountsAndReversesBalancedJournal",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", treasury_it)) >= 8, "Treasury 2.0 integration coverage must contain at least eight tests")
restaurant_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/RestaurantV2IntegrationTest.kt",
    "openTableReplay_isIdempotent_andSecondCommandCannotDoubleOccupyTable",
    "kitchenInvalidTransition_isRejectedWithoutStateOrEventMutation_thenValidPathIsAudited",
    "transferTable_movesOpenOrderAtomicallyAndReleasesSourceTable",
    "reservationLifecycle_updatesTableState_andOpenTablePersistsValidatedWaiterAndShift",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", restaurant_it)) >= 4, "Restaurant 2.0 integration coverage must contain at least four tests")
crm_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/CrmReceivablesIntegrationTest.kt",
    "aging_appliesCreditsFifoAcrossRequiredBuckets",
    "duplicateCandidates_matchesNormalizedPhoneOrNationalId_withoutReturningSelf",
    "merge_movesLedgerPreservesCombinedBalance_marksSourceMerged_andAudits",
    "openingBalance_postsLedgerBalancedAccountingAudit_andReplaysIdempotently",
    "adjustment_debitAndCredit_createRealLedgerAccountingAndAudit",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", crm_it)) >= 5, "CRM/Receivables integration coverage must contain at least five tests")

# Receivable aging must have one deterministic source of truth shared by CRM and alerts.
aging = contains(
    "app/src/main/java/ir/sabou/inventory/domain/crm/ReceivableAgingCalculator.kt",
    "object ReceivableAgingCalculator", "fun calculate",
)
crm_service = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalCustomerAccountService.kt")
alerts = text("app/src/main/java/ir/sabou/inventory/data/repository/LocalAlertRepository.kt")
require("ReceivableAgingCalculator.calculate" in crm_service, "CRM Aging does not use shared ReceivableAgingCalculator")
require("ReceivableAgingCalculator.calculate" in alerts, "Receivable alert does not use shared ReceivableAgingCalculator")
contains(
    "app/src/test/java/ir/sabou/inventory/domain/crm/ReceivableAgingCalculatorTest.kt",
    "fifoCreditSettlesOldestDueLots_beforeCurrentReceivable", "overpaymentDoesNotCreateNegativeAging",
)
alert_receivable_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/AlertReceivableIntegrationTest.kt",
    "fullySettledOverdueInvoice_doesNotGenerateFalseReceivableAlert_butPartialDoes",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", alert_receivable_it)) >= 1, "Receivable alert integration regression test missing")

asset_lifecycle_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/AssetLifecycleIntegrationTest.kt",
    "transfer_changesOperationalOwnership_preservesHistoricalCost_andAuditsLifecycle",
    "maintenance_persistsSchedule_postsBalancedExpenseJournal_andKeepsAssetCostImmutable",
    "impairment_reducesBookValue_withoutMutatingHistoricalCost_andPostsBalancedJournal",
    "sale_afterDepreciationAndImpairment_preservesHistoricalCost_calculatesGain_andBalancesJournal",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", asset_lifecycle_it)) >= 4, "Asset lifecycle integration coverage must contain at least four tests")

recipe_lifecycle_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/RecipeLifecycleIntegrationTest.kt",
    "directCircularDependency_AtoBtoA_isRejectedAndDraftInsertRollsBack",
    "indirectCircularDependency_AtoBtoCtoA_isRejectedWithoutPartialVersion",
    "activeVersion_isImmutable_editRequiresDraft_andActivationRetiresPreviousVersion",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", recipe_lifecycle_it)) >= 3, "Recipe lifecycle integration coverage must contain at least three tests")

permission_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/EnterprisePermissionIntegrationTest.kt",
    "treasuryReceipt_requiresTreasuryPermissionAtDomainBoundary",
    "restaurantMerge_requiresDedicatedMergePermission_evenWhenCashierCanUseRestaurantPos",
    "customerMerge_requiresCustomerMergePermission_andDoesNotMoveReferencesOnDenial",
    "assetTransfer_requiresLifecyclePermission_andLeavesAssetUntouchedOnDenial",
    "recipeActivation_requiresDedicatedPermission_evenWhenRoleCanEditRecipes",
)
require(len(re.findall(r"(?m)^\s*@Test\s*$", permission_it)) >= 5, "Enterprise permission integration coverage must contain at least five tests")
treasury_service = text("app/src/main/java/ir/sabou/inventory/data/treasury/LocalTreasuryServiceV2.kt")
require(treasury_service.count("authorizer.require(Permission.TREASURY)") >= 2, "Treasury execute/reverse must require TREASURY permission at domain boundary")

alert_state_it = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/AlertStateIntegrationTest.kt",
    "repeatedRefresh_isIdempotent_andStateTransitionsFollowRealConditionLifecycle",
    'assertEquals("READ"', 'assertEquals("ACTIONED"', 'assertEquals("RESOLVED"', 'assertEquals("DISMISSED"',
)
require("COUNT(*) FROM app_alerts" in alert_state_it, "Alert state test must verify duplicate prevention in persistent storage")

# Dashboard filter controls must be wired to truth-bearing branch/location keys.
dashboard_vm = text("app/src/main/java/ir/sabou/inventory/ui/DashboardViewModel.kt")
require("fun branch(" in dashboard_vm and "fun warehouse(" in dashboard_vm, "Dashboard branch/warehouse filter commands missing")
dashboard_dao = text("app/src/main/java/ir/sabou/inventory/data/db/DashboardAnalyticsDao.kt")
require(":branchName" in dashboard_dao and ":warehouseLocationId" in dashboard_dao, "Dashboard DAO does not apply branch/warehouse filters")

# Alpha162.2 Personnel 2.1 engineering gates: preserve enterprise-core authentication/migration/wiring/reversal/CRM/branch scope and require current release metadata.
sabou_app = text("app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt")
require("if (authenticatedUser == null)" in sabou_app and "AuthenticatedSabouApp(" in sabou_app, "P0 auth boundary is not explicit")
require("AuthenticatedSessionViewModelScope(sessionUserId = authenticatedUser.id)" in sabou_app, "protected ViewModel store is not session-scoped")
require("owner.viewModelStore.clear()" in sabou_app, "logout/session disposal does not tear down protected ViewModels")
require("canObservePayroll" in sabou_app and "Permission.PAYROLL_VIEW_ALL" in sabou_app, "Payroll protected subscription is not permission-gated")
require("ProtectedWorkScheduler.enable(context)" in sabou_app and "ProtectedWorkScheduler.disable(context)" in sabou_app, "protected workers are not tied to authenticated composition")
contains("app/src/main/java/ir/sabou/inventory/ProtectedWorkScheduler.kt", "cancelUniqueWork(ALERT_WORK)", "cancelUniqueWork(SYNC_WORK)")
contains("app/src/main/java/ir/sabou/inventory/SabouApplication.kt", "ProtectedWorkScheduler.disable(this)")
contains("app/src/main/java/ir/sabou/inventory/data/security/StartupSessionBoundary.kt", "DELETE FROM app_session")
contains("app/src/androidTest/java/ir/sabou/inventory/data/repository/StartupSessionBoundaryIntegrationTest.kt", "invalidatePersistedSession")

chain_test = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/db/EnterpriseCompletionMigration44To47Test.kt",
    "MIGRATION_44_45", "MIGRATION_45_46", "MIGRATION_46_47", "integrity_check", "foreign_key_check",
)
require("APP_DATABASE_SCHEMA_VERSION" in app_db, "current Room schema constant missing")

operations_vm = text("app/src/main/java/ir/sabou/inventory/ui/OperationsViewModel.kt")
contains("app/src/main/java/ir/sabou/inventory/application/inventory/OperationsInventoryUseCases.kt", "class OperationsInventoryUseCases", "authorizeSensitiveAction", "postWaste")
for forbidden in (
    "operationsRepository.postInventoryCount(", "operationsRepository.postWaste(", "operationsRepository.closeInventoryPeriod(",
    "operationsRepository.reopenInventoryPeriod(", "purchaseRepository.post(", "purchaseRepository.settle(",
    "purchaseRepository.reverseSettlement(", "purchaseRepository.reverse(",
):
    require(forbidden not in operations_vm, f"OperationsViewModel bypasses application boundary: {forbidden}")
require("inventoryOperations.postInventoryCount(" in operations_vm and "procurementUseCases.postPurchase(" in operations_vm, "Operations commands are not wired through UseCases")
accounting_vm = text("app/src/main/java/ir/sabou/inventory/ui/AccountingViewModel.kt")
require("AccountingUseCases" in accounting_vm and "AccountingRepository" not in accounting_vm, "AccountingViewModel bypasses AccountingUseCases")

reverse_uc = contains(
    "app/src/main/java/ir/sabou/inventory/application/treasury/TreasuryUseCases.kt",
    "class ReverseTreasuryTransactionUseCase", "reason.trim()", "status == \"POSTED\"",
)
treasury_ui = contains(
    "app/src/main/java/ir/sabou/inventory/ui/TreasuryScreen.kt",
    "treasury_reverse_${transaction.id}", "treasury_reverse_reason", "treasury_reverse_confirm",
)
require('reference = "REVERSAL_OF:${original.id}"' in treasury_service, "Treasury reversal ledger reference missing")
require("ReverseTreasuryTransactionUseCase" in text("app/src/main/java/ir/sabou/inventory/ui/TreasuryViewModel.kt"), "TreasuryViewModel is not wired to reversal UseCase")

crm_ui = text("app/src/main/java/ir/sabou/inventory/ui/CrmScreen.kt")
for tag in (
    "crm_customer_name", "crm_customer_phone", "crm_customer_mobile", "crm_customer_national_id",
    "crm_customer_address", "crm_customer_branch", "crm_customer_credit_limit", "crm_customer_payment_terms",
    "crm_customer_status", "crm_customer_notes", "crm_opening_action", "crm_adjustment_action",
):
    require(tag in crm_ui, f"CRM master/accounting UI missing {tag}")
require("postOpeningBalance" in crm_service and "CRM_OPENING" in crm_service and "postAdjustment" in crm_service and "CRM_ADJUSTMENT" in crm_service, "CRM opening/adjustment persistence missing")

branch_test = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/DashboardBranchFilteringIntegrationTest.kt",
    "Branch A", "Branch B", "100", "300", "400",
)
for metric in ("grossSalesRial", "netSalesRial", "purchaseRial", "purchaseReturnRial", "supplierPayablesRial", "inventoryValueRial", "wasteRial", "customerReceivablesRial", "presentCount", "unpaidPayrollRial"):
    require(metric in dashboard_dao, f"Dashboard DAO lost branch-aware KPI field {metric}")
require(dashboard_dao.count(":branchName") >= 20, "Dashboard branch filter is not applied broadly at query level")

refactor_test = contains(
    "app/src/androidTest/java/ir/sabou/inventory/data/repository/ExtractedResponsibilityServicesIntegrationTest.kt",
    "salesCustomerMasterService_ownsNumberingDuplicatePolicyOutstandingRuleAndAudit",
    "procurementSourcingService_ownsValidatedPolicyAndSupplierOfferPersistence",
)
require(len(sales_repo.splitlines()) < 900, "LocalProfessionalSalesRepository regressed past focused threshold")
require(len(procurement_repo.splitlines()) < 760, "LocalProcurementRepository regressed past focused threshold")

require("versionCode = 209" in build, "Alpha162.2 Personnel 2.1 versionCode must be 209")
require('versionName = "3.2.0-alpha162.2-personnel-2.1-engineering"' in build, "Alpha162.2 Personnel 2.1 versionName missing")
require("release {" in build and "isDebuggable = false" in build, "Release build must explicitly be non-debuggable")

# Current CI must run this verifier in addition to legacy gates.
workflow = text(".github/workflows/build-apk.yml")
require("verify-alpha162-enterprise-core.py" in workflow, "GitHub Actions does not run Alpha162 verifier")

if failures:
    print("ALPHA162_ENTERPRISE_CORE_VERIFICATION=FAIL")
    for failure in failures:
        print(f" - {failure}")
    sys.exit(1)
print(f"ALPHA162_ENTERPRISE_CORE_VERIFICATION=PASS schema=48 vertical_slices=5 compose_e2e={compose_total}")
