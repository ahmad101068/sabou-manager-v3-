package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.application.treasury.TreasuryUseCases
import ir.sabou.inventory.application.treasury.ReverseTreasuryTransactionUseCase
import ir.sabou.inventory.core.CorrelationId
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.domain.treasury.TreasuryAccount
import ir.sabou.inventory.domain.treasury.TreasuryAccountId
import ir.sabou.inventory.domain.treasury.TreasuryCommand
import ir.sabou.inventory.domain.treasury.TreasuryDirection
import ir.sabou.inventory.domain.treasury.TreasuryLedgerRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TreasuryUiState(
    val accounts: List<TreasuryAccount> = emptyList(),
    val transactions: List<TreasuryLedgerRecord> = emptyList(),
    val isBusy: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
)

class TreasuryViewModel(
    private val useCases: TreasuryUseCases,
    private val reverseTransaction: ReverseTreasuryTransactionUseCase,
) : ViewModel() {
    private val _state = MutableStateFlow(TreasuryUiState(accounts = useCases.activeAccounts()))
    val state: StateFlow<TreasuryUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            useCases.recentTransactions.collect { rows -> _state.update { it.copy(transactions = rows) } }
        }
    }

    fun receipt(accountId: String, amountRial: Long, sourceType: String, sourceId: Long, reason: String) = execute { account ->
        val id = GlobalId.new()
        TreasuryCommand.Receipt(id, currentLocalEpochDay(), CorrelationId.forCommand("treasury_receipt", id), normalizeSource(sourceType), sourceId, reason.trim(), account.id, account.channel, MoneyRial.of(amountRial))
    }(accountId)

    fun payment(accountId: String, amountRial: Long, sourceType: String, sourceId: Long, reason: String) = execute { account ->
        val id = GlobalId.new()
        TreasuryCommand.Payment(id, currentLocalEpochDay(), CorrelationId.forCommand("treasury_payment", id), normalizeSource(sourceType), sourceId, reason.trim(), account.id, account.channel, MoneyRial.of(amountRial))
    }(accountId)

    fun settlement(accountId: String, direction: TreasuryDirection, amountRial: Long, sourceType: String, sourceId: Long, reason: String) = execute { account ->
        val id = GlobalId.new()
        TreasuryCommand.Settlement(id, currentLocalEpochDay(), CorrelationId.forCommand("treasury_settlement", id), normalizeSource(sourceType), sourceId, reason.trim(), account.id, direction, account.channel, MoneyRial.of(amountRial))
    }(accountId)

    fun transfer(fromAccountId: String, toAccountId: String, amountRial: Long, reason: String) {
        runCommand {
            val from = account(fromAccountId)
            val to = account(toAccountId)
            val id = GlobalId.new()
            TreasuryCommand.InternalTransfer(id, currentLocalEpochDay(), CorrelationId.forCommand("treasury_transfer", id), "INTERNAL_TRANSFER", 1L, reason.trim(), from.id, to.id, MoneyRial.of(amountRial))
        }
    }

    fun reconcile(accountId: String, expectedRial: Long, actualRial: Long, reason: String) = execute { account ->
        val id = GlobalId.new()
        TreasuryCommand.Reconciliation(id, currentLocalEpochDay(), CorrelationId.forCommand("treasury_reconcile", id), "TREASURY_RECONCILIATION", 1L, reason.trim(), account.id, MoneyRial.of(expectedRial), MoneyRial.of(actualRial))
    }(accountId)

    fun reverse(transactionId: String, reason: String) {
        if (_state.value.isBusy) return
        viewModelScope.launch {
            _state.update { it.copy(isBusy = true, message = null, isError = false) }
            runCatching { reverseTransaction(transactionId, reason) }
                .onSuccess { result ->
                    _state.update { it.copy(isBusy = false, message = "تراکنش خزانه با سند جبرانی برگشت خورد · ${result.amount.value} ریال") }
                }
                .onFailure { error ->
                    _state.update { it.copy(isBusy = false, message = UiErrorHandler.message("TreasuryViewModel.reverse", error), isError = true) }
                }
        }
    }

    fun clearMessage() = _state.update { it.copy(message = null, isError = false) }

    private fun execute(factory: (TreasuryAccount) -> TreasuryCommand): (String) -> Unit = { accountId ->
        runCommand { factory(account(accountId)) }
    }

    private fun runCommand(factory: () -> TreasuryCommand) {
        if (_state.value.isBusy) return
        viewModelScope.launch {
            _state.update { it.copy(isBusy = true, message = null, isError = false) }
            runCatching { useCases.execute(factory()) }
                .onSuccess { result -> _state.update { it.copy(isBusy = false, message = "تراکنش خزانه ثبت شد · ${result.amount.value} ریال") } }
                .onFailure { error -> _state.update { it.copy(isBusy = false, message = error.message ?: "ثبت تراکنش خزانه انجام نشد.", isError = true) } }
        }
    }

    private fun account(raw: String): TreasuryAccount {
        val id = TreasuryAccountId.parse(raw)
        return _state.value.accounts.firstOrNull { it.id == id } ?: error("حساب خزانه فعال پیدا نشد.")
    }

    private fun normalizeSource(raw: String): String = raw.trim().uppercase().replace(' ', '_').also {
        require(it.matches(Regex("[A-Z][A-Z0-9_]{1,63}"))) { "نوع مرجع خزانه معتبر نیست." }
    }

    companion object {
        fun factory(
            useCases: TreasuryUseCases,
            reverseTransaction: ReverseTreasuryTransactionUseCase,
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                require(modelClass.isAssignableFrom(TreasuryViewModel::class.java))
                return TreasuryViewModel(useCases, reverseTransaction) as T
            }
        }
    }
}
