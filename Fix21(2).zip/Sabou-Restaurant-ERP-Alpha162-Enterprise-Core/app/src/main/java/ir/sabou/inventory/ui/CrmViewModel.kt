package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.application.crm.CrmUseCases
import ir.sabou.inventory.application.sales.SalesUseCases
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.domain.crm.CustomerDuplicateCandidate
import ir.sabou.inventory.domain.crm.CustomerOpeningBalanceCommand
import ir.sabou.inventory.domain.crm.CustomerReceivableAdjustmentCommand
import ir.sabou.inventory.domain.crm.ReceivableAdjustmentDirection
import ir.sabou.inventory.domain.crm.ReceivableAging
import ir.sabou.inventory.domain.crm.ReceivableLedgerRecord
import ir.sabou.inventory.domain.sales.CustomerDraft
import ir.sabou.inventory.domain.sales.CustomerRecord
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
data class CrmUiState(
    val customers: List<CustomerRecord> = emptyList(),
    val selectedCustomerId: Long? = null,
    val ledger: List<ReceivableLedgerRecord> = emptyList(),
    val aging: ReceivableAging? = null,
    val duplicateCandidates: List<CustomerDuplicateCandidate> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
)

@OptIn(ExperimentalCoroutinesApi::class)
class CrmViewModel(
    private val crm: CrmUseCases,
    private val sales: SalesUseCases,
) : ViewModel() {
    private val selected = MutableStateFlow<Long?>(null)
    private val transient = MutableStateFlow(CrmUiState())
    private val ledger = selected.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else crm.ledger(id) }

    val state: StateFlow<CrmUiState> = combine(sales.customers, selected, ledger, transient) { customers, customerId, rows, local ->
        local.copy(customers = customers, selectedCustomerId = customerId, ledger = rows)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CrmUiState())

    fun select(customerId: Long?) {
        selected.value = customerId
        transient.update { it.copy(aging = null, duplicateCandidates = emptyList(), message = null, isError = false) }
        if (customerId != null) refreshAging(customerId)
    }

    fun saveCustomer(id: Long?, draft: CustomerDraft) {
        command("اطلاعات مشتری ذخیره شد.") {
            val savedId = sales.saveCustomer(id, draft.validated())
            selected.value = savedId
        }
    }

    fun postOpeningBalance(
        amountRial: Long,
        direction: ReceivableAdjustmentDirection,
        businessEpochDay: Long,
        dueEpochDay: Long?,
        reason: String,
    ) {
        val customerId = selected.value ?: return
        command("مانده افتتاحیه با سند حسابداری ثبت شد.") {
            crm.postOpeningBalance(CustomerOpeningBalanceCommand(customerId, businessEpochDay, amountRial, direction, dueEpochDay, reason))
            refreshAgingAfterCommand(customerId)
        }
    }

    fun postAdjustment(
        amountRial: Long,
        direction: ReceivableAdjustmentDirection,
        businessEpochDay: Long,
        dueEpochDay: Long?,
        reason: String,
    ) {
        val customerId = selected.value ?: return
        command("تعدیل حساب با سند حسابداری ثبت شد.") {
            crm.postAdjustment(CustomerReceivableAdjustmentCommand(customerId, businessEpochDay, amountRial, direction, dueEpochDay, reason))
            refreshAgingAfterCommand(customerId)
        }
    }

    fun refreshAging(customerId: Long? = selected.value) {
        val id = customerId ?: return
        command(null) { refreshAgingAfterCommand(id) }
    }

    private suspend fun refreshAgingAfterCommand(customerId: Long) {
        val result = crm.aging(customerId, currentLocalEpochDay())
        transient.update { it.copy(aging = result) }
    }

    fun detectDuplicates(customerId: Long? = selected.value) {
        val id = customerId ?: return
        command(null) {
            val customer = state.value.customers.firstOrNull { it.id == id } ?: error("مشتری پیدا نشد.")
            val rows = crm.duplicateCandidates(id, customer.phone.ifBlank { customer.mobile }, customer.nationalId)
            transient.update { it.copy(duplicateCandidates = rows) }
        }
    }

    fun merge(targetCustomerId: Long, reason: String) {
        val sourceId = selected.value ?: return
        command("ادغام مشتری با انتقال تمام مراجع ثبت شد.") {
            crm.merge(sourceId, targetCustomerId, reason)
            selected.value = targetCustomerId
            transient.update { it.copy(duplicateCandidates = emptyList()) }
        }
    }

    fun clearMessage() = transient.update { it.copy(message = null, isError = false) }

    private fun command(success: String?, block: suspend () -> Unit) {
        if (transient.value.busy) return
        viewModelScope.launch {
            transient.update { it.copy(busy = true, message = null, isError = false) }
            try {
                block()
                transient.update { it.copy(busy = false, message = success) }
            } catch (e: Exception) {
                transient.update { it.copy(busy = false, message = e.message ?: "عملیات حساب مشتری انجام نشد.", isError = true) }
            }
        }
    }

    companion object {
        fun factory(crm: CrmUseCases, sales: SalesUseCases): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                require(modelClass.isAssignableFrom(CrmViewModel::class.java))
                return CrmViewModel(crm, sales) as T
            }
        }
    }
}
