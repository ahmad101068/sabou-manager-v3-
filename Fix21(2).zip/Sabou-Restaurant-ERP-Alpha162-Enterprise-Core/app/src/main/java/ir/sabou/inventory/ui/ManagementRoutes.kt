package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.security.Permission

@Composable
internal fun ManagementRoutes(
    screen: AppScreen,
    dashboardState: DashboardSnapshot,
    operationsState: OperationsUiState,
    operations: OperationsViewModel,
    inventory: InventoryWorkspaceViewModel,
    accountingState: AccountingUiState,
    accounting: AccountingViewModel,
    salesState: DailySalesUiState,
    sales: DailySalesViewModel,
    personnelState: PersonnelUiState,
    assetState: AssetUiState,
    managementState: ControlCenterUiState,
    management: ManagementControlViewModel,
    alertState: AlertUiState,
    alerts: AlertViewModel,
    currentUser: AppUserRecord?,
    users: List<AppUserRecord>,
    notificationPermissionGranted: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onRequestEmployeeProfile: (Long?) -> Unit,
    navigate: (AppScreen) -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.AUDIT_LOG -> AuditLogScreen(
            state = operationsState,
            users = users,
            canSensitiveView = currentUser?.role?.allows(Permission.AUDIT_SENSITIVE_VIEW) == true,
            onSearch = operations::setAuditSearch,
            onActor = operations::setAuditActor,
            onAction = operations::setAuditAction,
            onEntity = operations::setAuditEntity,
            onEntityId = operations::setAuditEntityId,
            onSourceReference = operations::setAuditSourceReference,
            onSeverity = operations::setAuditSeverity,
            onDateRange = operations::setAuditDateRange,
            onClearFilters = operations::clearAuditFilters,
            onBack = navigateBack,
        )

        AppScreen.MANAGEMENT_CONTROL -> ManagementControlScreen(
            state = managementState,
            employees = personnelState.employees,
            onSetRange = management::setRange,
            onFollowUp = management::followUp,
            onOpenInventory = { navigate(AppScreen.INVENTORY) },
            onOpenWorkforce = { navigate(AppScreen.PERSONNEL) },
            onSaveBudget = management::saveBudget,
            onRecordSpend = management::recordSpend,
            onCloseAccountingPeriod = management::closeAccountingPeriod,
            onReopenAccountingPeriod = management::reopenAccountingPeriod,
            onReconcileSalesCash = management::reconcileSalesCash,
            onBack = navigateBack,
        )

        AppScreen.ALERTS -> AlertCenterScreen(
            state = alertState,
            notificationPermissionGranted = notificationPermissionGranted,
            onRequestNotificationPermission = onRequestNotificationPermission,
            onRefresh = alerts::refresh,
            onRead = alerts::markRead,
            onActioned = alerts::markActioned,
            onResolve = alerts::resolve,
            onDismiss = alerts::dismiss,
            onOpenSource = { sourceType, sourceId ->
                when (sourceType) {
                    "LOW_STOCK", "LOT_EXPIRING", "LOT_EXPIRED", "INVENTORY_DISCREPANCY" -> {
                        inventory.focusItem(sourceId)
                        navigate(AppScreen.INVENTORY)
                    }
                    "PURCHASE_PAYABLE", "PURCHASE_DELIVERY_OVERDUE" -> {
                        operations.selectPurchase(sourceId)
                        navigate(AppScreen.PURCHASES)
                    }
                    "CUSTOMER_RECEIVABLE" -> navigate(AppScreen.SALES)
                    "CONTRACT_EXPIRY", "UNPAID_PAYROLL", "ATTENDANCE_ANOMALY" -> navigate(AppScreen.PERSONNEL)
                    "ASSET_MAINTENANCE" -> navigate(AppScreen.ASSETS)
                }
            },
            onClearDismissed = alerts::clearDismissed,
            onBack = navigateBack,
        )

        AppScreen.REPORTS -> ReportsCenterScreen(
            dashboard = dashboardState,
            sales = salesState,
            accounting = accountingState,
            operations = operationsState,
            personnel = personnelState,
            assets = assetState,
            onOpenSales = { navigate(AppScreen.SALES) },
            onOpenAccounting = { navigate(AppScreen.ACCOUNTING) },
            onOpenInventory = { navigate(AppScreen.INVENTORY) },
            onOpenStockMovements = { navigate(AppScreen.STOCK_MOVEMENTS) },
            onOpenPersonnel = { navigate(AppScreen.PERSONNEL) },
            onSetReportRange = { from, to ->
                sales.setReportRange(from, to)
                accounting.setProfitLossRange(from, to)
            },
            navigateTopLevel = navigate,
            onBack = navigateBack,
        )

        AppScreen.GLOBAL_SEARCH -> GlobalSearchScreen(
            currentUser = currentUser,
            operations = operationsState,
            accounting = accountingState,
            personnel = personnelState,
            onOpen = navigate,
            onOpenEntity = { target, key ->
                when {
                    key.startsWith("item-") -> {
                        key.removePrefix("item-").toLongOrNull()?.let(inventory::focusItem)
                    }
                    key.startsWith("purchase-") -> {
                        operations.selectPurchase(key.removePrefix("purchase-").toLongOrNull())
                    }
                    key.startsWith("journal-") -> {
                        accounting.selectJournal(key.removePrefix("journal-").toLongOrNull())
                    }
                    key.startsWith("account-") -> accounting.selectLedger(key.removePrefix("account-"))
                    key.startsWith("employee-") -> {
                        onRequestEmployeeProfile(key.removePrefix("employee-").toLongOrNull())
                    }
                    key.startsWith("movement-") -> {
                        key.removePrefix("movement-").substringBefore('-').toLongOrNull()?.let { itemId ->
                            inventory.focusItem(itemId, InventoryWorkspaceSection.MOVEMENTS)
                        }
                    }
                }
                navigate(target)
            },
            onBack = navigateBack,
        )

        else -> error("management_route_group_mismatch:${screen.name}")
    }
}
