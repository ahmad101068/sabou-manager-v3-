package ir.sabou.inventory.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddBox
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material.icons.outlined.Inventory
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.inventory.InventoryDashboardSnapshot
import ir.sabou.inventory.domain.inventory.InventoryLotStatus
import ir.sabou.inventory.domain.inventory.InventoryMovementView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun InventoryWorkspaceScreen(
    state: InventoryWorkspaceUiState,
    viewModel: InventoryWorkspaceViewModel,
    operationsState: OperationsUiState,
    operations: OperationsViewModel,
    onBack: () -> Unit,
    onNavigate: (AppScreen) -> Unit = {},
) {
    val section = state.section
    if (section == InventoryWorkspaceSection.OVERVIEW) {
        Scaffold(
            containerColor = ErpPalette.Canvas,
            bottomBar = { ErpBottomNavigation(AppScreen.INVENTORY, onNavigate) },
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                state.message?.let { MessageCard(it) }
                InventoryOverviewScreen(
                    state = state,
                    onOpen = viewModel::selectSection,
                    onRefresh = viewModel::refresh,
                    onNavigate = onNavigate,
                )
            }
        }
        return
    }

    val title = inventorySectionTitle(section)
    val subtitle = inventorySectionSubtitle(section)
    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = title,
                subtitle = subtitle,
                onBack = { viewModel.selectSection(InventoryWorkspaceSection.OVERVIEW) },
                actionLabel = "تازه‌سازی",
                onAction = viewModel::refresh,
            )
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            state.message?.let { MessageCard(it) }
            when (section) {
                InventoryWorkspaceSection.OVERVIEW -> Unit
                InventoryWorkspaceSection.ITEMS -> InventoryItemCenterScreen(state, viewModel)
                InventoryWorkspaceSection.EXPIRY -> InventoryExpiryCenterScreen(state, viewModel)
                InventoryWorkspaceSection.MOVEMENTS -> InventoryMovementCenterScreen(state)
                InventoryWorkspaceSection.COUNTS -> InventoryCountCenterScreen(state, viewModel)
                InventoryWorkspaceSection.WASTE -> InventoryWasteCenterScreen(state, viewModel)
                InventoryWorkspaceSection.TRANSFERS -> InventoryTransferCenterScreen(state, viewModel)
                InventoryWorkspaceSection.REPLENISHMENT -> InventoryReplenishmentCenterScreen(state, viewModel)
                InventoryWorkspaceSection.PERIODS -> InventoryPeriodCenterScreen(
                    state = operationsState,
                    onClose = operations::closeInventoryPeriod,
                    onReopen = operations::reopenInventoryPeriod,
                    onSelectClosure = operations::selectInventoryClosure,
                )
            }
        }
    }
}

@Composable
private fun InventoryOverviewScreen(
    state: InventoryWorkspaceUiState,
    onOpen: (InventoryWorkspaceSection) -> Unit,
    onRefresh: () -> Unit,
    onNavigate: (AppScreen) -> Unit,
) {
    val dashboard = state.dashboard
    LazyColumn(
        modifier = Modifier.fillMaxSize().testTag("inventory_overview_list"),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp),
    ) {
        item { InventoryHeader(state, onRefresh) }
        if (state.loading && dashboard == null) item { MessageCard("در حال خواندن دفترکل و کنترل‌های انبار…") }
        item { InventoryHeroCard(dashboard) }
        item { InventoryNeedsAction(dashboard, onOpen) }
        item { InventoryQuickActions(onOpen) }
        item { InventoryStatusSection(state) }
        item { RecentInventoryActivity(state.movements, onOpen) }
        item { InventoryControlCenters(state, onOpen) }
        item { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun InventoryHeader(state: InventoryWorkspaceUiState, onRefresh: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SabouGeometricLogo()
            Column(Modifier.weight(1f).padding(horizontal = 11.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("انبار", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, color = ErpPalette.Ink)
                Text("سبوی عشق", style = MaterialTheme.typography.labelMedium, color = ErpPalette.Muted)
            }
            IconButton(onClick = {}, modifier = Modifier.size(40.dp)) { Icon(Icons.Outlined.Search, contentDescription = "جست‌وجو", tint = ErpPalette.Ink) }
            IconButton(onClick = {}, modifier = Modifier.size(40.dp)) { Icon(Icons.Outlined.FilterAlt, contentDescription = "فیلتر", tint = ErpPalette.Ink) }
            IconButton(onClick = onRefresh, modifier = Modifier.size(40.dp)) { Icon(Icons.Outlined.NotificationsNone, contentDescription = "تازه‌سازی", tint = ErpPalette.Ink) }
            Surface(shape = CircleShape, color = ErpPalette.IndigoSoft, modifier = Modifier.size(40.dp)) {
                Icon(Icons.Outlined.PersonOutline, contentDescription = "کاربر", tint = ErpPalette.Indigo, modifier = Modifier.padding(9.dp))
            }
        }

        val selectedWarehouse = state.locationId?.let { id -> state.locations.firstOrNull { it.id == id }?.name }
            ?: state.locations.firstOrNull()?.name
            ?: "انبار مرکزی"
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White,
            border = BorderStroke(1.dp, ErpPalette.Border),
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                PastelIcon(Icons.Outlined.Inventory2, ErpPalette.TealLight, ErpPalette.Teal, Modifier.size(38.dp))
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    Text("انبار فعال", style = MaterialTheme.typography.labelSmall, color = ErpPalette.Muted)
                    Text(selectedWarehouse, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = ErpPalette.Ink)
                }
                Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = ErpPalette.Muted.copy(alpha = .6f), modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun InventoryHeroCard(dashboard: InventoryDashboardSnapshot?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Column(
            Modifier
                .background(Brush.linearGradient(listOf(ErpPalette.TealDark, ErpPalette.Teal, Color(0xFF179486))))
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ارزش موجودی", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelLarge)
                    Text(
                        formatMoney(dashboard?.totalInventoryValueRial ?: 0L, CurrencyUnit.TOMAN),
                        color = Color.White,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Box(
                    Modifier.size(70.dp).background(Color.White.copy(alpha = .1f), RoundedCornerShape(22.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Outlined.Inventory, contentDescription = null, tint = Color.White.copy(alpha = .85f), modifier = Modifier.size(38.dp))
                }
            }
            Row(
                Modifier.fillMaxWidth().background(Color.White.copy(alpha = .1f), RoundedCornerShape(18.dp)).padding(vertical = 12.dp, horizontal = 7.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
            ) {
                HeroMetric("کالاها", toPersianDigits((dashboard?.activeItemCount ?: 0).toString()), Modifier.weight(1f))
                HeroMetric("کم‌موجود", toPersianDigits((dashboard?.lowStockItemCount ?: 0).toString()), Modifier.weight(1f))
                HeroMetric("اتمام", toPersianDigits((dashboard?.outOfStockItemCount ?: 0).toString()), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun InventoryNeedsAction(
    dashboard: InventoryDashboardSnapshot?,
    onOpen: (InventoryWorkspaceSection) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ErpSectionTitle("نیازمند اقدام")
        InventoryActionRow(
            title = "کالاهای کم‌موجود",
            description = "${toPersianDigits((dashboard?.lowStockItemCount ?: 0).toString())} قلم کالا نیاز به سفارش یا تأمین دارند",
            icon = Icons.Outlined.WarningAmber,
            accent = ErpPalette.Amber,
            soft = ErpPalette.AmberSoft,
            target = InventoryWorkspaceSection.REPLENISHMENT,
            onOpen = onOpen,
        )
        InventoryActionRow(
            title = "کالاهای نزدیک به انقضا",
            description = "${toPersianDigits((dashboard?.expiringLotCount ?: 0).toString())} قلم کالا تا ۶۰ روز آینده منقضی می‌شوند",
            icon = Icons.Outlined.Inventory2,
            accent = ErpPalette.Red,
            soft = ErpPalette.RedSoft,
            target = InventoryWorkspaceSection.EXPIRY,
            onOpen = onOpen,
        )
        InventoryActionRow(
            title = "انتقال‌های در جریان",
            description = "${toPersianDigits((dashboard?.pendingTransferCount ?: 0).toString())} انتقال بین انبارها در حال انجام است",
            icon = Icons.Outlined.SwapHoriz,
            accent = ErpPalette.Blue,
            soft = ErpPalette.BlueSoft,
            target = InventoryWorkspaceSection.TRANSFERS,
            onOpen = onOpen,
        )
        InventoryActionRow(
            title = "جلسات شمارش باز",
            description = "${toPersianDigits((dashboard?.pendingCountSessionCount ?: 0).toString())} جلسه شمارش در حال انجام است",
            icon = Icons.Outlined.TaskAlt,
            accent = ErpPalette.Green,
            soft = ErpPalette.GreenSoft,
            target = InventoryWorkspaceSection.COUNTS,
            onOpen = onOpen,
        )
    }
}

@Composable
private fun InventoryActionRow(
    title: String,
    description: String,
    icon: ImageVector,
    accent: Color,
    soft: Color,
    target: InventoryWorkspaceSection,
    onOpen: (InventoryWorkspaceSection) -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable { onOpen(target) },
        shape = RoundedCornerShape(19.dp),
        color = Color.White,
        border = BorderStroke(1.dp, ErpPalette.Border),
        shadowElevation = 1.dp,
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(9.dp).background(accent, CircleShape))
            PastelIcon(icon, soft, accent, Modifier.padding(start = 10.dp))
            Column(Modifier.weight(1f).padding(horizontal = 11.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, fontWeight = FontWeight.Bold, color = ErpPalette.Ink)
                Text(description, style = MaterialTheme.typography.bodySmall, color = ErpPalette.Muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = ErpPalette.Muted.copy(alpha = .55f), modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun InventoryQuickActions(onOpen: (InventoryWorkspaceSection) -> Unit) {
    val actions = listOf(
        InventoryQuickAction("ورود کالا", Icons.Outlined.ArrowDownward, InventoryWorkspaceSection.MOVEMENTS, ErpPalette.GreenSoft, ErpPalette.Green),
        InventoryQuickAction("خروج کالا", Icons.Outlined.ArrowUpward, InventoryWorkspaceSection.MOVEMENTS, ErpPalette.RedSoft, ErpPalette.Red),
        InventoryQuickAction("انتقال", Icons.Outlined.SwapHoriz, InventoryWorkspaceSection.TRANSFERS, ErpPalette.BlueSoft, ErpPalette.Blue),
        InventoryQuickAction("شمارش", Icons.Outlined.TaskAlt, InventoryWorkspaceSection.COUNTS, ErpPalette.IndigoSoft, ErpPalette.Indigo),
        InventoryQuickAction("ضایعات", Icons.Outlined.DeleteOutline, InventoryWorkspaceSection.WASTE, ErpPalette.AmberSoft, ErpPalette.Amber),
        InventoryQuickAction("کالای جدید", Icons.Outlined.AddBox, InventoryWorkspaceSection.ITEMS, ErpPalette.TealLight, ErpPalette.Teal),
    )
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ErpSectionTitle("عملیات سریع")
        actions.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                row.forEach { action ->
                    Surface(
                        modifier = Modifier.weight(1f).clickable { onOpen(action.target) },
                        shape = RoundedCornerShape(19.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, ErpPalette.Border),
                    ) {
                        Column(
                            Modifier.padding(horizontal = 8.dp, vertical = 13.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(7.dp),
                        ) {
                            PastelIcon(action.icon, action.soft, action.accent)
                            Text(action.title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

private data class InventoryQuickAction(
    val title: String,
    val icon: ImageVector,
    val target: InventoryWorkspaceSection,
    val soft: Color,
    val accent: Color,
)

@Composable
private fun InventoryStatusSection(state: InventoryWorkspaceUiState) {
    val dashboard = state.dashboard
    val healthy = ((dashboard?.activeItemCount ?: 0) - (dashboard?.lowStockItemCount ?: 0) - (dashboard?.outOfStockItemCount ?: 0)).coerceAtLeast(0)
    val quarantined = state.lots.count { it.status == InventoryLotStatus.QUARANTINED }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        ErpSectionTitle("وضعیت موجودی")
        val cards = listOf(
            InventoryStatusUi("موجودی کافی", healthy, ErpPalette.Green, ErpPalette.GreenSoft),
            InventoryStatusUi("کم‌موجود", dashboard?.lowStockItemCount ?: 0, ErpPalette.Amber, ErpPalette.AmberSoft),
            InventoryStatusUi("نزدیک به انقضا", dashboard?.expiringLotCount ?: 0, ErpPalette.Red, ErpPalette.RedSoft),
            InventoryStatusUi("قرنطینه", quarantined, ErpPalette.Purple, ErpPalette.PurpleSoft),
        )
        cards.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                row.forEach { status ->
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, ErpPalette.Border),
                    ) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(10.dp).background(status.accent, CircleShape))
                            Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                                Text(status.title, style = MaterialTheme.typography.labelMedium, color = ErpPalette.Muted)
                                Text(toPersianDigits(status.value.toString()), style = MaterialTheme.typography.titleLarge, color = ErpPalette.Ink, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class InventoryStatusUi(val title: String, val value: Int, val accent: Color, val soft: Color)

@Composable
private fun RecentInventoryActivity(
    movements: List<InventoryMovementView>,
    onOpen: (InventoryWorkspaceSection) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ErpSectionTitle("گردش اخیر", "مشاهده همه", onAction = { onOpen(InventoryWorkspaceSection.MOVEMENTS) })
        if (movements.isEmpty()) {
            Surface(shape = RoundedCornerShape(18.dp), color = Color.White, border = BorderStroke(1.dp, ErpPalette.Border)) {
                Text("گردش ثبت‌شده‌ای برای نمایش وجود ندارد.", Modifier.fillMaxWidth().padding(15.dp), color = ErpPalette.Muted, style = MaterialTheme.typography.bodySmall)
            }
        } else {
            movements.take(3).forEach { movement -> RecentMovementRow(movement) }
        }
    }
}

@Composable
private fun RecentMovementRow(movement: InventoryMovementView) {
    val positive = movement.quantityDeltaMicros >= 0
    val accent = if (positive) ErpPalette.Green else ErpPalette.Red
    val soft = if (positive) ErpPalette.GreenSoft else ErpPalette.RedSoft
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.White,
        border = BorderStroke(1.dp, ErpPalette.Border),
    ) {
        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            PastelIcon(if (positive) Icons.Outlined.ArrowDownward else Icons.Outlined.ArrowUpward, soft, accent)
            Column(Modifier.weight(1f).padding(horizontal = 10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(movementTypeTitle(movement.movementType), fontWeight = FontWeight.Bold, color = ErpPalette.Ink, style = MaterialTheme.typography.bodyMedium)
                Text(movement.itemName, style = MaterialTheme.typography.bodySmall, color = ErpPalette.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    listOfNotNull(movement.locationName, movement.actorId?.let { "کاربر #${toPersianDigits(it.toString())}" }).joinToString(" · "),
                    style = MaterialTheme.typography.labelSmall,
                    color = ErpPalette.Muted.copy(alpha = .85f),
                    maxLines = 1,
                )
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    "${if (positive) "+" else ""}${formatQuantity(movement.quantityDeltaMicros)} ${movement.baseUnit}",
                    style = MaterialTheme.typography.labelMedium,
                    color = accent,
                    fontWeight = FontWeight.ExtraBold,
                )
                Text(formatActivityTime(movement.createdAtEpochMillis), style = MaterialTheme.typography.labelSmall, color = ErpPalette.Muted)
            }
        }
    }
}

@Composable
private fun InventoryControlCenters(
    state: InventoryWorkspaceUiState,
    onOpen: (InventoryWorkspaceSection) -> Unit,
) {
    val actionableReplenishment = state.replenishment.count { it.isActionable }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ErpSectionTitle("مراکز کنترل")
        inventoryCenters.forEach { (target, description) ->
            Surface(
                modifier = Modifier.fillMaxWidth().testTag("inventory_section_${target.name}").clickable { onOpen(target) },
                shape = RoundedCornerShape(18.dp),
                color = Color.White,
                border = BorderStroke(1.dp, ErpPalette.Border),
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(inventorySectionTitle(target), fontWeight = FontWeight.Bold, color = ErpPalette.Ink)
                        Text(
                            if (target == InventoryWorkspaceSection.REPLENISHMENT) "$description · ${toPersianDigits(actionableReplenishment.toString())} پیشنهاد قابل اقدام" else description,
                            color = ErpPalette.Muted,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                        )
                    }
                    Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = ErpPalette.Muted.copy(alpha = .55f), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

private fun formatActivityTime(epochMillis: Long): String {
    if (epochMillis <= 0L) return "—"
    val formatter = SimpleDateFormat("HH:mm", Locale.forLanguageTag("fa-IR"))
    return "امروز ${formatter.format(Date(epochMillis))}"
}

private val inventoryCenters = listOf(
    InventoryWorkspaceSection.ITEMS to "کالا، SKU، بارکد، محل و مانده",
    InventoryWorkspaceSection.EXPIRY to "FEFO، انقضا، قرنطینه و لات",
    InventoryWorkspaceSection.MOVEMENTS to "دفتر غیرقابل‌ویرایش گردش موجودی",
    InventoryWorkspaceSection.COUNTS to "شمارش کور، بازشماری، تأیید و Posting",
    InventoryWorkspaceSection.WASTE to "ضایعات ردیابی‌پذیر و بهای ثبت‌شده",
    InventoryWorkspaceSection.TRANSFERS to "انتقال سندمحور و کالای در راه",
    InventoryWorkspaceSection.REPLENISHMENT to "پوشش، نقطه سفارش و درخواست خرید",
    InventoryWorkspaceSection.PERIODS to "بستن و بازگشایی کنترل‌شده دوره انبار",
)

internal fun inventorySectionTitle(section: InventoryWorkspaceSection): String = when (section) {
    InventoryWorkspaceSection.OVERVIEW -> "انبار"
    InventoryWorkspaceSection.ITEMS -> "کالا و محل نگهداری"
    InventoryWorkspaceSection.EXPIRY -> "مرکز انقضا و لات"
    InventoryWorkspaceSection.MOVEMENTS -> "دفتر گردش موجودی"
    InventoryWorkspaceSection.COUNTS -> "مرکز انبارگردانی"
    InventoryWorkspaceSection.WASTE -> "مرکز ضایعات"
    InventoryWorkspaceSection.TRANSFERS -> "مرکز انتقال"
    InventoryWorkspaceSection.REPLENISHMENT -> "تأمین مجدد"
    InventoryWorkspaceSection.PERIODS -> "کنترل دوره انبار"
}

private fun inventorySectionSubtitle(section: InventoryWorkspaceSection): String = when (section) {
    InventoryWorkspaceSection.OVERVIEW -> "آنچه اکنون نیازمند تصمیم و اقدام است"
    InventoryWorkspaceSection.ITEMS -> "Master Data، موجودی مکان‌محور و جست‌وجوی سریع"
    InventoryWorkspaceSection.EXPIRY -> "مصرف FEFO، قرنطینه و تبدیل صریح به ضایعات"
    InventoryWorkspaceSection.MOVEMENTS -> "ردیابی تا سند مبدأ، Actor و correlationId"
    InventoryWorkspaceSection.COUNTS -> "چرخه Draft تا Posted با تفکیک وظایف"
    InventoryWorkspaceSection.WASTE -> "مقدار، علت، بهای تاریخی، تأیید و ثبت"
    InventoryWorkspaceSection.TRANSFERS -> "درخواست، صدور، کالای در راه و دریافت"
    InventoryWorkspaceSection.REPLENISHMENT -> "تقاضا، Lead Time، Safety Stock و Procurement"
    InventoryWorkspaceSection.PERIODS -> "کنترل ثبت اسناد Backdated موجودی"
}

@Composable
internal fun InventoryEmptyState(text: String) {
    EmptyStatePanel("موردی یافت نشد", text)
}

@Preview(showBackground = true, widthDp = 390, heightDp = 844, locale = "fa")
@Composable
private fun InventoryOverviewPreview() {
    val state = InventoryWorkspaceUiState(
        loading = false,
        dashboard = InventoryDashboardSnapshot(
            totalInventoryValueRial = 1_284_500_000_000,
            activeItemCount = 1_248,
            lowStockItemCount = 86,
            outOfStockItemCount = 23,
            expiringLotCount = 32,
            expiredLotCount = 4,
            wasteCostRial = 0,
            inventoryVarianceRial = 0,
            pendingTransferCount = 5,
            pendingCountSessionCount = 2,
        ),
    )
    MaterialTheme {
        Scaffold(containerColor = ErpPalette.Canvas, bottomBar = { ErpBottomNavigation(AppScreen.INVENTORY) {} }) { padding ->
            Box(Modifier.padding(padding)) {
                InventoryOverviewScreen(state, {}, {}, {})
            }
        }
    }
}
