package ir.sabou.inventory.data.treasury

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.CustomerReceivableLedgerEntity
import ir.sabou.inventory.data.db.TreasuryLedgerEntryEntity
import ir.sabou.inventory.data.db.TreasuryReconciliationEntity
import ir.sabou.inventory.data.db.TreasuryTransactionEntity
import ir.sabou.inventory.data.repository.LocalAuditEventWriter
import ir.sabou.inventory.domain.accounting.AccountingPostingCommand
import ir.sabou.inventory.domain.accounting.AccountingPostingService
import ir.sabou.inventory.domain.accounting.AccountingReversalCommand
import ir.sabou.inventory.domain.accounting.JournalStatus
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.security.AuthorizationService
import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.purchase.PurchasePaymentStatus
import ir.sabou.inventory.domain.treasury.TreasuryAccount
import ir.sabou.inventory.domain.treasury.TreasuryAccountCatalog
import ir.sabou.inventory.domain.treasury.TreasuryChannel
import ir.sabou.inventory.domain.treasury.TreasuryCommand
import ir.sabou.inventory.domain.treasury.TreasuryDirection
import ir.sabou.inventory.domain.treasury.TreasuryReversalCommand
import ir.sabou.inventory.domain.treasury.TreasuryService
import ir.sabou.inventory.domain.treasury.TreasuryTransaction
import ir.sabou.inventory.domain.treasury.TreasuryTransactionKind
import ir.sabou.inventory.domain.treasury.TreasuryLedgerReader
import ir.sabou.inventory.domain.treasury.TreasuryLedgerRecord
import ir.sabou.inventory.domain.treasury.TreasuryReversalContext
import ir.sabou.inventory.domain.treasury.validated
import kotlin.math.absoluteValue
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * Treasury 2.0 owns an append-only operational ledger while accounting remains the financial
 * source of truth. The accounting posting, treasury header/lines and audit event share the same
 * outer Room transaction, so a failure in any side effect rolls the whole command back.
 */
class LocalTreasuryServiceV2(
    private val database: AppDatabase,
    private val accounting: AccountingPostingService,
    private val authorizer: AuthorizationService,
    private val accountCatalog: TreasuryAccountCatalog,
    private val clock: () -> Long = System::currentTimeMillis,
) : TreasuryService, TreasuryLedgerReader {
    private val audit = LocalAuditEventWriter(database)

    override val recentTransactions: Flow<List<TreasuryLedgerRecord>> = database.treasuryDao().observeRecentTransactions().map { rows ->
        rows.map { row -> TreasuryLedgerRecord(
            id = row.id, kind = TreasuryTransactionKind.valueOf(row.kind), businessEpochDay = row.businessEpochDay,
            sourceType = row.sourceType, sourceId = row.sourceId, amountRial = row.amountRial, status = row.status, reason = row.reason,
            journalEntryId = row.journalEntryId, createdAtEpochMillis = row.createdAtEpochMillis,
        ) }
    }

    override fun observeBalance(accountId: ir.sabou.inventory.domain.treasury.TreasuryAccountId): Flow<Long> =
        database.treasuryDao().observeLedgerBalance(accountId.value)

    override suspend fun reversalContext(transactionId: String): TreasuryReversalContext? {
        val normalizedId = transactionId.trim()
        if (normalizedId.isEmpty()) return null
        val transaction = database.treasuryDao().transactionById(normalizedId) ?: return null
        val primaryLine = database.treasuryDao().entriesForTransaction(normalizedId).firstOrNull() ?: return null
        val accountId = ir.sabou.inventory.domain.treasury.TreasuryAccountId.parse(primaryLine.accountId)
        val account = accountCatalog.account(accountId) ?: return null
        return TreasuryReversalContext(
            transactionId = transaction.id,
            status = transaction.status,
            journalEntryId = transaction.journalEntryId,
            businessEpochDay = transaction.businessEpochDay,
            sourceType = transaction.sourceType,
            sourceId = transaction.sourceId,
            amountRial = transaction.amountRial,
            accountId = account.id,
            channel = account.channel,
            reversalOfTransactionId = transaction.reversalOfTransactionId,
        )
    }

    override suspend fun execute(command: TreasuryCommand): TreasuryTransaction {
        val valid = command.validated()
        authorizer.require(Permission.TREASURY)
        val actor = when (valid) {
            is TreasuryCommand.Payment, is TreasuryCommand.Settlement -> {
                authorizer.require(Permission.PAYMENT_APPROVE)
            }
            else -> authorizer.require(Permission.ACCOUNTING)
        }
        return database.withTransaction {
            database.treasuryDao().byCommandId(valid.commandId.value)?.let { existing ->
                verifyReplay(existing, valid)
                return@withTransaction existing.toDomain(idempotentReplay = true)
            }

            val now = clock()
            val posting = when (valid) {
                is TreasuryCommand.Receipt -> postReceipt(valid, actor.id)
                is TreasuryCommand.Payment -> postPayment(valid, actor.id)
                is TreasuryCommand.InternalTransfer -> postTransfer(valid, actor.id)
                is TreasuryCommand.Settlement -> postSettlement(valid, actor.id)
                is TreasuryCommand.Reconciliation -> postReconciliation(valid, actor.id)
            }
            val entries = ledgerEntries(valid, actor.id, now)
            if (valid is TreasuryCommand.Settlement && valid.direction == TreasuryDirection.PAYMENT && valid.isPurchasePayableSettlement()) {
                applyPurchasePayableSettlement(valid)
            }
            val transaction = TreasuryTransactionEntity(
                id = valid.commandId.value,
                commandId = valid.commandId.value,
                kind = valid.kindName(),
                businessEpochDay = valid.businessEpochDay,
                sourceType = valid.sourceType,
                sourceId = valid.sourceId,
                counterpartyType = valid.sourceType,
                counterpartyId = valid.sourceId,
                reference = valid.commandId.value,
                reason = valid.reason,
                amountRial = valid.transactionAmountRial(),
                journalEntryId = posting?.entryId,
                actorId = actor.id,
                correlationId = valid.correlationId.value,
                createdAtEpochMillis = now,
            )
            database.treasuryDao().insertTransaction(transaction)
            if (entries.isNotEmpty()) database.treasuryDao().insertLedgerEntries(entries)
            val customerReceiptAmount = when (valid) {
                is TreasuryCommand.Receipt -> if (receiptCounterpart(valid.sourceType) == SemanticAccountRole.CUSTOMER_RECEIVABLE) valid.amount.value else 0L
                is TreasuryCommand.Settlement -> if (valid.direction == TreasuryDirection.RECEIPT) valid.amount.value else 0L
                else -> 0L
            }
            if (customerReceiptAmount > 0) {
                val customer = database.salesDao().activeCustomerById(valid.sourceId) ?: throw BusinessError.EntityNotFound("ACTIVE_CUSTOMER", valid.sourceId).asViolation()
                database.customerReceivableDao().insertLedger(
                    CustomerReceivableLedgerEntity(
                        customerId = customer.id, businessEpochDay = valid.businessEpochDay, entryType = "RECEIPT", debitRial = 0, creditRial = customerReceiptAmount,
                        sourceType = "TREASURY_RECEIPT", sourceId = valid.sourceId, reference = valid.commandId.value, actorId = actor.id, createdAtEpochMillis = now,
                    ),
                )
            }
            if (valid is TreasuryCommand.Reconciliation) {
                val difference = valid.actual.value - valid.expected.value
                database.treasuryDao().insertReconciliation(
                    TreasuryReconciliationEntity(
                        transactionId = transaction.id,
                        accountId = valid.accountId.value,
                        businessEpochDay = valid.businessEpochDay,
                        expectedRial = valid.expected.value,
                        actualRial = valid.actual.value,
                        differenceRial = difference,
                        reason = valid.reason,
                        actorId = actor.id,
                        createdAtEpochMillis = now,
                    ),
                )
            }
            audit.appendAuthorized(
                authorizer = authorizer,
                action = "POST",
                entityType = "TREASURY_TRANSACTION",
                entityId = null,
                description = "${transaction.kind} ${transaction.amountRial} ریال؛ ${transaction.sourceType}:${transaction.sourceId}",
                occurredAtEpochMillis = now,
                businessEpochDay = transaction.businessEpochDay,
                reason = transaction.reason,
                afterSnapshot = "id=${transaction.id};kind=${transaction.kind};amount=${transaction.amountRial};journal=${transaction.journalEntryId}",
                correlationId = transaction.correlationId,
                referenceType = transaction.sourceType,
                referenceId = transaction.sourceId,
            )
            transaction.toDomain(idempotentReplay = posting?.idempotentReplay == true)
        }
    }

    override suspend fun reverse(command: TreasuryReversalCommand): TreasuryTransaction {
        val valid = command.validated()
        authorizer.require(Permission.TREASURY)
        val actor = authorizer.require(Permission.JOURNAL_REVERSE)
        return database.withTransaction {
            database.treasuryDao().byCommandId(valid.commandId.value)?.let { replay ->
                return@withTransaction replay.toDomain(idempotentReplay = true)
            }
            val original = database.treasuryDao().transactionById(valid.originalTransactionId)
                ?: throw BusinessError.EntityNotFound("TREASURY_TRANSACTION", null).asViolation()
            require(original.status == "POSTED") { "treasury_transaction_not_posted" }
            require(original.journalEntryId == valid.originalJournalEntryId) { "treasury_original_journal_mismatch" }
            require(valid.sourceId == original.sourceId) { "treasury_reversal_source_id_mismatch" }
            require(valid.amount.value == original.amountRial) { "treasury_reversal_amount_mismatch" }
            val originalLines = database.treasuryDao().entriesForTransaction(original.id)
            val result = accounting.reverse(
                AccountingReversalCommand(
                    originalEntryId = valid.originalJournalEntryId,
                    entryNo = "خز-ب-${valid.commandId.value}",
                    sourceType = valid.sourceType,
                    sourceId = valid.sourceId,
                    businessEpochDay = valid.businessEpochDay,
                    reason = valid.reason,
                    idempotencyKey = "TREASURY_REVERSAL:${valid.commandId.value}",
                    correlationId = valid.correlationId,
                    actorId = actor.id,
                ),
            )
            val now = clock()
            require(database.treasuryDao().markReversed(original.id, now) == 1) { "treasury_concurrent_reversal" }
            val reversal = TreasuryTransactionEntity(
                id = valid.commandId.value,
                commandId = valid.commandId.value,
                kind = original.kind,
                businessEpochDay = valid.businessEpochDay,
                sourceType = valid.sourceType,
                sourceId = valid.sourceId,
                counterpartyType = original.counterpartyType,
                counterpartyId = original.counterpartyId,
                reference = original.reference,
                reason = valid.reason,
                amountRial = original.amountRial,
                status = "POSTED",
                journalEntryId = result.entryId,
                reversalOfTransactionId = original.id,
                actorId = actor.id,
                correlationId = valid.correlationId.value,
                createdAtEpochMillis = now,
            )
            database.treasuryDao().insertTransaction(reversal)
            database.treasuryDao().insertLedgerEntries(
                originalLines.map { line ->
                    line.copy(
                        id = 0,
                        transactionId = reversal.id,
                        direction = if (line.direction == TreasuryDirection.RECEIPT.name) TreasuryDirection.PAYMENT.name else TreasuryDirection.RECEIPT.name,
                        sourceType = valid.sourceType,
                        sourceId = valid.sourceId,
                        reference = "REVERSAL_OF:${original.id}",
                        actorId = actor.id,
                        createdAtEpochMillis = now,
                    )
                },
            )
            val reversesCustomerReceipt =
                (original.kind == TreasuryTransactionKind.RECEIPT.name && receiptCounterpart(original.sourceType) == SemanticAccountRole.CUSTOMER_RECEIVABLE) ||
                    (original.kind == TreasuryTransactionKind.SETTLEMENT.name && originalLines.any { it.direction == TreasuryDirection.RECEIPT.name })
            if (reversesCustomerReceipt) {
                val customerId = original.counterpartyId ?: original.sourceId
                database.salesDao().activeCustomerById(customerId)
                    ?: throw BusinessError.EntityNotFound("ACTIVE_CUSTOMER", customerId).asViolation()
                database.customerReceivableDao().insertLedger(
                    CustomerReceivableLedgerEntity(
                        customerId = customerId,
                        businessEpochDay = valid.businessEpochDay,
                        entryType = "REVERSAL",
                        debitRial = original.amountRial,
                        creditRial = 0,
                        sourceType = "TREASURY_REVERSAL",
                        sourceId = customerId,
                        reference = valid.commandId.value,
                        actorId = actor.id,
                        createdAtEpochMillis = now,
                    ),
                )
            }
            if (original.kind == TreasuryTransactionKind.SETTLEMENT.name &&
                original.sourceType in PURCHASE_PAYABLE_SETTLEMENT_SOURCES &&
                originalLines.any { it.direction == TreasuryDirection.PAYMENT.name }
            ) {
                reversePurchasePayableSettlement(original.sourceId, original.amountRial)
            }
            audit.appendAuthorized(
                authorizer = authorizer,
                action = "REVERSE",
                entityType = "TREASURY_TRANSACTION",
                entityId = null,
                description = "برگشت تراکنش خزانه ${original.id}",
                occurredAtEpochMillis = now,
                businessEpochDay = valid.businessEpochDay,
                reason = valid.reason,
                beforeSnapshot = "id=${original.id};status=${original.status};journal=${original.journalEntryId}",
                afterSnapshot = "reversal=${reversal.id};journal=${reversal.journalEntryId}",
                correlationId = valid.correlationId.value,
                referenceType = valid.sourceType,
                referenceId = valid.sourceId,
            )
            reversal.toDomain(idempotentReplay = result.idempotentReplay)
        }
    }

    private suspend fun applyPurchasePayableSettlement(command: TreasuryCommand.Settlement) {
        val purchase = database.purchaseDao().byId(command.sourceId)
            ?: throw BusinessError.EntityNotFound("PURCHASE_PAYABLE", command.sourceId).asViolation()
        require(purchase.paymentMethod == null) { "treasury_purchase_already_paid_at_source" }
        val status = PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus)
        require(status in setOf(PurchasePaymentStatus.UNPAID, PurchasePaymentStatus.PARTIAL)) { "treasury_purchase_not_payable" }
        val remaining = Math.subtractExact(purchase.totalRial, purchase.paidRial)
        require(command.amount.value <= remaining) { "treasury_settlement_exceeds_purchase_payable" }
        val newPaid = Math.addExact(purchase.paidRial, command.amount.value)
        val paidInFull = newPaid == purchase.totalRial
        check(
            database.purchaseDao().updateSettlementState(
                purchaseId = purchase.id,
                expectedPaidRial = purchase.paidRial,
                newPaidRial = newPaid,
                paymentStatus = if (paidInFull) PurchasePaymentStatus.PAID.storedValue else PurchasePaymentStatus.PARTIAL.storedValue,
                reminderEnabled = !paidInFull && purchase.reminderEnabled,
                reminderEpochDay = if (paidInFull) null else purchase.reminderEpochDay,
            ) == 1,
        ) { "treasury_purchase_payable_concurrent_change" }
    }

    private suspend fun reversePurchasePayableSettlement(purchaseId: Long, amountRial: Long) {
        val purchase = database.purchaseDao().byId(purchaseId)
            ?: throw BusinessError.EntityNotFound("PURCHASE_PAYABLE", purchaseId).asViolation()
        require(purchase.paymentMethod == null) { "treasury_purchase_reversal_source_invalid" }
        require(amountRial in 1..purchase.paidRial) { "treasury_purchase_reversal_amount_invalid" }
        val newPaid = Math.subtractExact(purchase.paidRial, amountRial)
        val newStatus = if (newPaid == 0L) PurchasePaymentStatus.UNPAID else PurchasePaymentStatus.PARTIAL
        check(
            database.purchaseDao().updateSettlementState(
                purchaseId = purchase.id,
                expectedPaidRial = purchase.paidRial,
                newPaidRial = newPaid,
                paymentStatus = newStatus.storedValue,
                reminderEnabled = purchase.reminderEnabled,
                reminderEpochDay = purchase.reminderEpochDay,
            ) == 1,
        ) { "treasury_purchase_payable_reversal_concurrent_change" }
    }

    private fun TreasuryCommand.Settlement.isPurchasePayableSettlement(): Boolean =
        sourceType in PURCHASE_PAYABLE_SETTLEMENT_SOURCES

    private suspend fun postReceipt(command: TreasuryCommand.Receipt, actorId: Long) =
        accounting.post(
            postingCommand(
                command = command,
                actorId = actorId,
                lines = listOf(
                    SemanticJournalLine(accountRole(account(command.accountId)), debit = command.amount, memo = command.reason),
                    SemanticJournalLine(receiptCounterpart(command.sourceType), credit = command.amount, memo = command.sourceType),
                ),
            ),
        )

    private suspend fun postPayment(command: TreasuryCommand.Payment, actorId: Long) =
        accounting.post(
            postingCommand(
                command = command,
                actorId = actorId,
                lines = listOf(
                    SemanticJournalLine(paymentCounterpart(command.sourceType), debit = command.amount, memo = command.sourceType),
                    SemanticJournalLine(accountRole(account(command.accountId)), credit = command.amount, memo = command.reason),
                ),
            ),
        )

    private suspend fun postSettlement(command: TreasuryCommand.Settlement, actorId: Long) =
        if (command.direction == TreasuryDirection.RECEIPT) {
            accounting.post(
                postingCommand(
                    command,
                    actorId,
                    listOf(
                        SemanticJournalLine(accountRole(account(command.accountId)), debit = command.amount),
                        SemanticJournalLine(SemanticAccountRole.CUSTOMER_RECEIVABLE, credit = command.amount),
                    ),
                ),
            )
        } else {
            accounting.post(
                postingCommand(
                    command,
                    actorId,
                    listOf(
                        SemanticJournalLine(SemanticAccountRole.SUPPLIER_PAYABLE, debit = command.amount),
                        SemanticJournalLine(accountRole(account(command.accountId)), credit = command.amount),
                    ),
                ),
            )
        }

    private suspend fun postTransfer(command: TreasuryCommand.InternalTransfer, actorId: Long) =
        accounting.post(
            postingCommand(
                command,
                actorId,
                listOf(
                    SemanticJournalLine(accountRole(account(command.toAccountId)), debit = command.amount, memo = "انتقال ورودی"),
                    SemanticJournalLine(accountRole(account(command.fromAccountId)), credit = command.amount, memo = "انتقال خروجی"),
                ),
            ),
        )

    private suspend fun postReconciliation(command: TreasuryCommand.Reconciliation, actorId: Long): ir.sabou.inventory.domain.accounting.AccountingPostingResult? {
        val difference = command.actual.value - command.expected.value
        if (difference == 0L) return null
        val amount = MoneyRial.of(difference.absoluteValue)
        val accountRole = accountRole(account(command.accountId))
        val lines = if (difference > 0) {
            listOf(
                SemanticJournalLine(accountRole, debit = amount, memo = "افزایش ناشی از مغایرت"),
                SemanticJournalLine(SemanticAccountRole.OTHER_INCOME, credit = amount, memo = command.reason),
            )
        } else {
            listOf(
                SemanticJournalLine(SemanticAccountRole.OTHER_OPERATING_EXPENSE, debit = amount, memo = command.reason),
                SemanticJournalLine(accountRole, credit = amount, memo = "کسری ناشی از مغایرت"),
            )
        }
        return accounting.post(postingCommand(command, actorId, lines))
    }

    private fun postingCommand(command: TreasuryCommand, actorId: Long, lines: List<SemanticJournalLine>) =
        AccountingPostingCommand(
            entryNo = "خز-${command.commandId.value}",
            sourceType = command.sourceType,
            sourceId = command.sourceId,
            businessEpochDay = command.businessEpochDay,
            description = command.reason,
            lines = lines,
            idempotencyKey = "TREASURY:${command.commandId.value}",
            correlationId = command.correlationId,
            actorId = actorId,
            status = JournalStatus.POSTED,
        )

    private fun account(id: ir.sabou.inventory.domain.treasury.TreasuryAccountId): TreasuryAccount =
        accountCatalog.account(id)?.takeIf { it.isActive }
            ?: throw BusinessError.EntityNotFound("TREASURY_ACCOUNT", null).asViolation()

    private fun accountRole(account: TreasuryAccount): SemanticAccountRole = when (account.channel) {
        TreasuryChannel.CASH -> SemanticAccountRole.CASH
        TreasuryChannel.BANK, TreasuryChannel.CARD, TreasuryChannel.TRANSFER -> SemanticAccountRole.BANK
    }

    private fun receiptCounterpart(sourceType: String): SemanticAccountRole = when {
        sourceType.contains("CUSTOMER") || sourceType.contains("RECEIVABLE") -> SemanticAccountRole.CUSTOMER_RECEIVABLE
        else -> SemanticAccountRole.OTHER_INCOME
    }

    private fun paymentCounterpart(sourceType: String): SemanticAccountRole = when {
        sourceType.contains("PAYROLL") || sourceType.contains("EMPLOYEE") -> SemanticAccountRole.PAYROLL_PAYABLE
        sourceType.contains("SUPPLIER") || sourceType.contains("PURCHASE") -> SemanticAccountRole.SUPPLIER_PAYABLE
        else -> SemanticAccountRole.OTHER_OPERATING_EXPENSE
    }

    private fun ledgerEntries(command: TreasuryCommand, actorId: Long, now: Long): List<TreasuryLedgerEntryEntity> {
        fun row(accountId: String, direction: TreasuryDirection, amount: Long) = TreasuryLedgerEntryEntity(
            transactionId = command.commandId.value,
            accountId = accountId,
            direction = direction.name,
            amountRial = amount,
            sourceType = command.sourceType,
            sourceId = command.sourceId,
            counterpartyType = command.sourceType,
            counterpartyId = command.sourceId,
            reference = command.commandId.value,
            businessEpochDay = command.businessEpochDay,
            actorId = actorId,
            createdAtEpochMillis = now,
        )
        return when (command) {
            is TreasuryCommand.Receipt -> listOf(row(command.accountId.value, TreasuryDirection.RECEIPT, command.amount.value))
            is TreasuryCommand.Payment -> listOf(row(command.accountId.value, TreasuryDirection.PAYMENT, command.amount.value))
            is TreasuryCommand.Settlement -> listOf(row(command.accountId.value, command.direction, command.amount.value))
            is TreasuryCommand.InternalTransfer -> listOf(
                row(command.fromAccountId.value, TreasuryDirection.PAYMENT, command.amount.value),
                row(command.toAccountId.value, TreasuryDirection.RECEIPT, command.amount.value),
            )
            is TreasuryCommand.Reconciliation -> {
                val difference = command.actual.value - command.expected.value
                if (difference == 0L) emptyList() else listOf(
                    row(
                        command.accountId.value,
                        if (difference > 0) TreasuryDirection.RECEIPT else TreasuryDirection.PAYMENT,
                        difference.absoluteValue,
                    ),
                )
            }
        }
    }

    private fun verifyReplay(existing: TreasuryTransactionEntity, command: TreasuryCommand) {
        if (existing.kind != command.kindName() || existing.businessEpochDay != command.businessEpochDay ||
            existing.sourceType != command.sourceType || existing.sourceId != command.sourceId ||
            existing.amountRial != command.transactionAmountRial() || existing.reason != command.reason
        ) {
            throw BusinessError.IdempotencyConflict(command.commandId.value).asViolation()
        }
    }

    private companion object {
        val PURCHASE_PAYABLE_SETTLEMENT_SOURCES = setOf("PURCHASE_PAYABLE", "PURCHASE_SETTLEMENT")
    }
}

private fun TreasuryCommand.kindName(): String = when (this) {
    is TreasuryCommand.Receipt -> TreasuryTransactionKind.RECEIPT.name
    is TreasuryCommand.Payment -> TreasuryTransactionKind.PAYMENT.name
    is TreasuryCommand.InternalTransfer -> TreasuryTransactionKind.INTERNAL_TRANSFER.name
    is TreasuryCommand.Settlement -> TreasuryTransactionKind.SETTLEMENT.name
    is TreasuryCommand.Reconciliation -> TreasuryTransactionKind.RECONCILIATION.name
}

private fun TreasuryCommand.transactionAmountRial(): Long = when (this) {
    is TreasuryCommand.Receipt -> amount.value
    is TreasuryCommand.Payment -> amount.value
    is TreasuryCommand.InternalTransfer -> amount.value
    is TreasuryCommand.Settlement -> amount.value
    is TreasuryCommand.Reconciliation -> (actual.value - expected.value).absoluteValue
}

private fun TreasuryTransactionEntity.toDomain(idempotentReplay: Boolean) = TreasuryTransaction(
    id = id,
    kind = TreasuryTransactionKind.valueOf(kind),
    businessEpochDay = businessEpochDay,
    correlationId = ir.sabou.inventory.core.CorrelationId.parse(correlationId),
    sourceType = sourceType,
    sourceId = sourceId,
    amount = MoneyRial.of(amountRial),
    journalEntryId = journalEntryId,
    idempotentReplay = idempotentReplay,
)
