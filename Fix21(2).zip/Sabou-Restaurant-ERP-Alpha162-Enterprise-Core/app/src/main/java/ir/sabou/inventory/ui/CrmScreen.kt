package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.domain.crm.ReceivableAdjustmentDirection
import ir.sabou.inventory.domain.sales.CustomerDraft
import ir.sabou.inventory.domain.sales.CustomerRecord

@Composable
internal fun CrmScreen(
    state: CrmUiState,
    onSelect: (Long?) -> Unit,
    onSaveCustomer: (Long?, CustomerDraft) -> Unit,
    onPostOpening: (Long, ReceivableAdjustmentDirection, Long, Long?, String) -> Unit,
    onPostAdjustment: (Long, ReceivableAdjustmentDirection, Long, Long?, String) -> Unit,
    onRefreshAging: (Long) -> Unit,
    onDetectDuplicates: (Long) -> Unit,
    onMerge: (Long, String) -> Unit,
    onBack: () -> Unit,
) {
    var editingCustomer by remember { mutableStateOf<CustomerRecord?>(null) }
    var createCustomer by remember { mutableStateOf(false) }
    var accountAction by remember { mutableStateOf<String?>(null) }
    var mergeTarget by remember { mutableStateOf("") }
    var mergeReason by remember { mutableStateOf("") }
    val selected = state.customers.firstOrNull { it.id == state.selectedCustomerId }

    if (createCustomer || editingCustomer != null) {
        CustomerMasterDialog(
            customer = editingCustomer,
            busy = state.busy,
            onDismiss = { createCustomer = false; editingCustomer = null },
            onSave = { draft ->
                onSaveCustomer(editingCustomer?.id, draft)
                createCustomer = false
                editingCustomer = null
            },
        )
    }
    if (selected != null && accountAction != null) {
        CustomerAccountEntryDialog(
            title = if (accountAction == "OPENING") "ثبت مانده افتتاحیه" else "ثبت تعدیل حساب",
            confirmTag = if (accountAction == "OPENING") "crm_opening_confirm" else "crm_adjustment_confirm",
            busy = state.busy,
            onDismiss = { accountAction = null },
            onConfirm = { amount, direction, businessDay, dueDay, reason ->
                if (accountAction == "OPENING") onPostOpening(amount, direction, businessDay, dueDay, reason)
                else onPostAdjustment(amount, direction, businessDay, dueDay, reason)
                accountAction = null
            },
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("CRM و حساب دریافتنی", style = MaterialTheme.typography.headlineSmall)
                TextButton(onClick = onBack) { Text("بازگشت") }
            }
        }
        state.message?.let { message -> item { Text(message, color = if (state.isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) } }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("مشتریان", style = MaterialTheme.typography.titleMedium)
                Button(
                    enabled = !state.busy,
                    modifier = Modifier.testTag("crm_new_customer"),
                    onClick = { createCustomer = true },
                ) { Text("مشتری جدید") }
            }
        }
        if (state.customers.isEmpty()) {
            item { Text("مشتری ثبت‌شده‌ای وجود ندارد.") }
        } else {
            items(state.customers, key = { it.id }) { customer ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${customer.customerCode} · ${customer.name}")
                        Text("مانده: ${formatMoney(customer.outstandingRial)} · سقف اعتبار: ${formatMoney(customer.creditLimitRial)}", style = MaterialTheme.typography.bodySmall)
                        Text("${customer.phone.ifBlank { customer.mobile }} · ${customer.status} · شعبه ${customer.branch.ifBlank { "—" }}", style = MaterialTheme.typography.bodySmall)
                        Text("مهلت پرداخت: ${customer.paymentTermsDays} روز · ${customer.address.ifBlank { "بدون آدرس" }}", style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                modifier = Modifier.testTag("crm_select_${customer.id}"),
                                onClick = { onSelect(customer.id) },
                            ) { Text("دفتر و Aging") }
                            OutlinedButton(
                                modifier = Modifier.testTag("crm_edit_${customer.id}"),
                                onClick = { editingCustomer = customer },
                            ) { Text("ویرایش Master") }
                        }
                    }
                }
            }
        }
        if (selected != null) {
            item {
                Text("حساب ${selected.name}", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !state.busy, onClick = { onRefreshAging(selected.id) }) { Text("محاسبه Aging") }
                    OutlinedButton(enabled = !state.busy, onClick = { onDetectDuplicates(selected.id) }) { Text("بررسی تکراری") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        enabled = !state.busy,
                        modifier = Modifier.testTag("crm_opening_action"),
                        onClick = { accountAction = "OPENING" },
                    ) { Text("مانده افتتاحیه") }
                    OutlinedButton(
                        enabled = !state.busy,
                        modifier = Modifier.testTag("crm_adjustment_action"),
                        onClick = { accountAction = "ADJUSTMENT" },
                    ) { Text("تعدیل حساب") }
                }
            }
            state.aging?.let { aging ->
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Aging مطالبات", style = MaterialTheme.typography.titleSmall)
                            Text("جاری: ${formatMoney(aging.currentRial)}")
                            Text("۱–۳۰: ${formatMoney(aging.days1To30Rial)} · ۳۱–۶۰: ${formatMoney(aging.days31To60Rial)}")
                            Text("۶۱–۹۰: ${formatMoney(aging.days61To90Rial)} · بیش از ۹۰: ${formatMoney(aging.over90Rial)}")
                            Text("کل: ${formatMoney(aging.totalRial)}", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
            }
            item { Text("دفتر دریافتنی", style = MaterialTheme.typography.titleMedium) }
            if (state.ledger.isEmpty()) {
                item { Text("گردشی برای این مشتری ثبت نشده است.") }
            } else {
                items(state.ledger, key = { "crm-ledger-${it.id}" }) { row ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text("${row.entryType} · ${row.reference}")
                            Text("بدهکار ${formatMoney(row.debitRial)} · بستانکار ${formatMoney(row.creditRial)} · ${epochDayToPersian(row.businessEpochDay).display()}", style = MaterialTheme.typography.bodySmall)
                            row.dueEpochDay?.let { Text("سررسید ${epochDayToPersian(it).display()}", style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }
            if (state.duplicateCandidates.isNotEmpty()) {
                item { Text("مشتریان مشابه", style = MaterialTheme.typography.titleMedium) }
                items(state.duplicateCandidates, key = { "duplicate-${it.id}" }) { candidate ->
                    OutlinedButton(
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { mergeTarget = candidate.id.toString() },
                    ) { Text("${candidate.customerCode} · ${candidate.name} · ${candidate.phone}") }
                }
                item {
                    OutlinedTextField(mergeTarget, { mergeTarget = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("شناسه مشتری مقصد") })
                    OutlinedTextField(mergeReason, { mergeReason = it }, Modifier.fillMaxWidth(), label = { Text("دلیل ادغام") })
                    Button(
                        enabled = !state.busy && mergeTarget.toLongOrNull() != null && mergeReason.trim().length >= 3,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { onMerge(mergeTarget.toLongOrNull() ?: 0L, mergeReason) },
                    ) { Text("ادغام کنترل‌شده و انتقال مراجع") }
                }
            }
        }
    }
}

@Composable
private fun CustomerMasterDialog(
    customer: CustomerRecord?,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (CustomerDraft) -> Unit,
) {
    var name by remember(customer?.id) { mutableStateOf(customer?.name.orEmpty()) }
    var phone by remember(customer?.id) { mutableStateOf(customer?.phone.orEmpty()) }
    var mobile by remember(customer?.id) { mutableStateOf(customer?.mobile.orEmpty()) }
    var nationalId by remember(customer?.id) { mutableStateOf(customer?.nationalId.orEmpty()) }
    var address by remember(customer?.id) { mutableStateOf(customer?.address.orEmpty()) }
    var branch by remember(customer?.id) { mutableStateOf(customer?.branch.orEmpty()) }
    var creditLimit by remember(customer?.id) { mutableStateOf(customer?.creditLimitRial?.toString().orEmpty()) }
    var paymentTerms by remember(customer?.id) { mutableStateOf(customer?.paymentTermsDays?.toString() ?: "0") }
    var status by remember(customer?.id) { mutableStateOf(customer?.status ?: "ACTIVE") }
    var notes by remember(customer?.id) { mutableStateOf(customer?.notes.orEmpty()) }
    val parsedCredit = if (creditLimit.isBlank()) 0L else parseMoneyInputOrNull(creditLimit)
    val parsedTerms = paymentTerms.toIntOrNull()
    val valid = name.trim().length >= 2 && parsedCredit != null && parsedCredit >= 0L && parsedTerms != null && parsedTerms in 0..3650 && status.trim().uppercase() in setOf("ACTIVE", "ON_HOLD", "INACTIVE")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (customer == null) "مشتری جدید" else "ویرایش ${customer.customerCode}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(customer?.customerCode ?: "پس از ثبت خودکار", {}, Modifier.fillMaxWidth(), enabled = false, label = { Text("کد مشتری") })
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth().testTag("crm_customer_name"), label = { Text("نام") })
                OutlinedTextField(phone, { phone = it.filter(Char::isDigit) }, Modifier.fillMaxWidth().testTag("crm_customer_phone"), label = { Text("تلفن") })
                OutlinedTextField(mobile, { mobile = it.filter(Char::isDigit) }, Modifier.fillMaxWidth().testTag("crm_customer_mobile"), label = { Text("موبایل") })
                OutlinedTextField(nationalId, { nationalId = it.filter(Char::isDigit) }, Modifier.fillMaxWidth().testTag("crm_customer_national_id"), label = { Text("کد ملی/شناسه") })
                OutlinedTextField(address, { address = it }, Modifier.fillMaxWidth().testTag("crm_customer_address"), label = { Text("آدرس") })
                OutlinedTextField(branch, { branch = it }, Modifier.fillMaxWidth().testTag("crm_customer_branch"), label = { Text("شعبه") })
                OutlinedTextField(creditLimit, { creditLimit = it }, Modifier.fillMaxWidth().testTag("crm_customer_credit_limit"), label = { Text("سقف اعتبار (ریال)") })
                OutlinedTextField(paymentTerms, { paymentTerms = it.filter(Char::isDigit) }, Modifier.fillMaxWidth().testTag("crm_customer_payment_terms"), label = { Text("مهلت پرداخت (روز)") })
                OutlinedTextField(status, { status = it.uppercase() }, Modifier.fillMaxWidth().testTag("crm_customer_status"), label = { Text("وضعیت: ACTIVE / ON_HOLD / INACTIVE") })
                OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().testTag("crm_customer_notes"), label = { Text("یادداشت") })
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && valid,
                modifier = Modifier.testTag("crm_customer_save"),
                onClick = {
                    onSave(
                        CustomerDraft(
                            name = name,
                            phone = phone,
                            nationalId = nationalId,
                            creditLimitRial = parsedCredit ?: 0L,
                            notes = notes,
                            mobile = mobile,
                            address = address,
                            branch = branch,
                            paymentTermsDays = parsedTerms ?: 0,
                            status = status,
                        ),
                    )
                },
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun CustomerAccountEntryDialog(
    title: String,
    confirmTag: String,
    busy: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Long, ReceivableAdjustmentDirection, Long, Long?, String) -> Unit,
) {
    var amount by remember { mutableStateOf("") }
    var direction by remember { mutableStateOf(ReceivableAdjustmentDirection.DEBIT) }
    var businessDay by remember { mutableStateOf(currentLocalEpochDay()) }
    var dueDay by remember { mutableStateOf(currentLocalEpochDay()) }
    var reason by remember { mutableStateOf("") }
    val parsedAmount = parseMoneyInputOrNull(amount)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(amount, { amount = it }, Modifier.fillMaxWidth().testTag("crm_account_amount"), label = { Text("مبلغ (ریال)") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { direction = ReceivableAdjustmentDirection.DEBIT }) { Text(if (direction == ReceivableAdjustmentDirection.DEBIT) "✓ بدهکار" else "بدهکار") }
                    OutlinedButton(onClick = { direction = ReceivableAdjustmentDirection.CREDIT }) { Text(if (direction == ReceivableAdjustmentDirection.CREDIT) "✓ بستانکار" else "بستانکار") }
                }
                PersianDateField("تاریخ ثبت", businessDay) { businessDay = it; if (dueDay < it) dueDay = it }
                PersianDateField("سررسید", dueDay) { dueDay = it }
                OutlinedTextField(reason, { reason = it }, Modifier.fillMaxWidth().testTag("crm_account_reason"), label = { Text("دلیل") })
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && parsedAmount != null && parsedAmount > 0 && dueDay >= businessDay && reason.trim().length >= 3,
                modifier = Modifier.testTag(confirmTag),
                onClick = { onConfirm(parsedAmount ?: 0L, direction, businessDay, dueDay, reason) },
            ) { Text("ثبت با سند حسابداری") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
