package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable

@Composable
internal fun AccountingRoutes(
    screen: AppScreen,
    state: AccountingUiState,
    accounting: AccountingViewModel,
    sales: DailySalesViewModel,
    treasuryState: TreasuryUiState,
    treasury: TreasuryViewModel,
    crmState: CrmUiState,
    crm: CrmViewModel,
    navigate: (AppScreen) -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.ACCOUNTING -> AccountingScreen(
            state = state,
            onSearch = accounting::searchJournals,
            onSelectJournal = accounting::selectJournal,
            onSelectLedger = accounting::selectLedger,
            onSaveAccount = accounting::saveAccount,
            onDeactivateAccount = accounting::deactivateAccount,
            onReverse = accounting::reverseManual,
            onSetProfitLossRange = { from, to ->
                accounting.setProfitLossRange(from, to)
                sales.setReportRange(from, to)
            },
            onAddJournal = { navigate(AppScreen.NEW_JOURNAL) },
            onBack = navigateBack,
        )

        AppScreen.NEW_JOURNAL -> ManualJournalEntryScreen(
            state = state,
            onPost = accounting::postManual,
            onBack = navigateBack,
        )

        AppScreen.TREASURY -> TreasuryScreen(
            state = treasuryState,
            onReceipt = treasury::receipt,
            onPayment = treasury::payment,
            onSettlement = treasury::settlement,
            onTransfer = treasury::transfer,
            onReconcile = treasury::reconcile,
            onReverse = treasury::reverse,
            onBack = navigateBack,
        )

        AppScreen.CRM -> CrmScreen(
            state = crmState,
            onSelect = crm::select,
            onSaveCustomer = crm::saveCustomer,
            onPostOpening = crm::postOpeningBalance,
            onPostAdjustment = crm::postAdjustment,
            onRefreshAging = crm::refreshAging,
            onDetectDuplicates = crm::detectDuplicates,
            onMerge = crm::merge,
            onBack = navigateBack,
        )

        else -> error("accounting_route_group_mismatch:${screen.name}")
    }
}
