package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.application.restaurant.RestaurantUseCases
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.restaurant.KitchenTicketRecord
import ir.sabou.inventory.domain.restaurant.KitchenTicketStatus
import ir.sabou.inventory.domain.restaurant.OpenTableCommand
import ir.sabou.inventory.domain.restaurant.RestaurantCourse
import ir.sabou.inventory.domain.restaurant.RestaurantHallRecord
import ir.sabou.inventory.domain.restaurant.RestaurantOrderLineDraft
import ir.sabou.inventory.domain.restaurant.RestaurantOrderLineRecord
import ir.sabou.inventory.domain.restaurant.RestaurantOrderRecord
import ir.sabou.inventory.domain.restaurant.RestaurantPaymentSplit
import ir.sabou.inventory.domain.restaurant.RestaurantReservationRecord
import ir.sabou.inventory.domain.restaurant.RestaurantReservationStatus
import ir.sabou.inventory.domain.restaurant.RestaurantTableRecord
import ir.sabou.inventory.domain.restaurant.TableReservationDraft
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class RestaurantUiState(
    val halls: List<RestaurantHallRecord> = emptyList(),
    val tables: List<RestaurantTableRecord> = emptyList(),
    val reservations: List<RestaurantReservationRecord> = emptyList(),
    val openOrders: List<RestaurantOrderRecord> = emptyList(),
    val kitchenTickets: List<KitchenTicketRecord> = emptyList(),
    val menuItems: List<MenuItem> = emptyList(),
    val selectedOrderId: Long? = null,
    val selectedOrderLines: List<RestaurantOrderLineRecord> = emptyList(),
    val isBusy: Boolean = false,
    val message: String? = null,
    val isError: Boolean = false,
)

class RestaurantViewModel(private val useCases: RestaurantUseCases, recipes: RecipeRepository) : ViewModel() {
    private val selectedOrder = MutableStateFlow<Long?>(null)
    private val _state = MutableStateFlow(RestaurantUiState())
    val state: StateFlow<RestaurantUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch { useCases.halls.collect { rows -> _state.update { it.copy(halls = rows) } } }
        viewModelScope.launch { useCases.tables.collect { rows -> _state.update { it.copy(tables = rows) } } }
        viewModelScope.launch { useCases.reservations.collect { rows -> _state.update { it.copy(reservations = rows) } } }
        viewModelScope.launch { useCases.openOrders.collect { rows -> _state.update { it.copy(openOrders = rows) } } }
        viewModelScope.launch { useCases.kitchenTickets.collect { rows -> _state.update { it.copy(kitchenTickets = rows) } } }
        viewModelScope.launch { recipes.observeMenuItems().collect { rows -> _state.update { it.copy(menuItems = rows) } } }
        viewModelScope.launch {
            selectedOrder.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else useCases.orderLines(id) }.collect { rows ->
                _state.update { it.copy(selectedOrderId = selectedOrder.value, selectedOrderLines = rows) }
            }
        }
    }

    fun selectOrder(id: Long?) { selectedOrder.value = id }
    fun createHall(name: String) = command("سالن ایجاد شد.") { useCases.createHall(name) }
    fun createTable(hallId: Long, tableNo: String, capacity: Int) = command("میز ایجاد شد.") { useCases.createTable(hallId, tableNo, capacity) }
    fun reserve(draft: TableReservationDraft) = command("رزرو ثبت شد.") { useCases.reserve(draft) }
    fun reservationStatus(reservationId: Long, to: RestaurantReservationStatus, reason: String = "") = command("وضعیت رزرو به‌روزرسانی شد.") { useCases.transitionReservation(reservationId, to, reason) }
    fun openTable(command: OpenTableCommand) = command("میز باز شد.") { useCases.openTable(command).also { selectedOrder.value = it } }
    fun addItem(orderId: Long, menuItemId: Long, quantityUnits: Long, course: RestaurantCourse, note: String) = command("آیتم به سفارش و KDS اضافه شد.") {
        require(quantityUnits > 0); useCases.addItem(RestaurantOrderLineDraft(orderId, menuItemId, QuantityMicros.of(Math.multiplyExact(quantityUnits, 1_000_000L)), course, note))
    }
    fun changeQuantity(lineId: Long, quantityUnits: Long) = command("تعداد اصلاح شد.") { require(quantityUnits > 0); useCases.changeQuantity(lineId, QuantityMicros.of(Math.multiplyExact(quantityUnits, 1_000_000L))) }
    fun transfer(orderId: Long, targetTableId: Long, reason: String) = command("انتقال میز انجام شد.") { useCases.transferTable(orderId, targetTableId, reason) }
    fun merge(sourceOrderId: Long, targetOrderId: Long, reason: String) = command("ادغام میزها انجام شد.") { useCases.mergeTables(sourceOrderId, targetOrderId, reason) }
    fun kitchen(ticketId: Long, status: KitchenTicketStatus, reason: String = "") = command("وضعیت آشپزخانه به‌روزرسانی شد.") { useCases.transitionKitchen(ticketId, status, reason) }
    fun close(orderId: Long, payments: List<RestaurantPaymentSplit>, dueEpochDay: Long?) = command("میز با فاکتور نهایی بسته شد.") { useCases.closeTable(orderId, payments, dueEpochDay).also { selectedOrder.value = null } }
    fun clearMessage() = _state.update { it.copy(message = null, isError = false) }

    private fun command(success: String, block: suspend () -> Any?) {
        if (_state.value.isBusy) return
        viewModelScope.launch {
            _state.update { it.copy(isBusy = true, message = null, isError = false) }
            runCatching { block() }
                .onSuccess { _state.update { it.copy(isBusy = false, message = success) } }
                .onFailure { e -> _state.update { it.copy(isBusy = false, message = e.message ?: "عملیات رستوران انجام نشد.", isError = true) } }
        }
    }

    companion object {
        fun factory(useCases: RestaurantUseCases, recipes: RecipeRepository): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T { require(modelClass.isAssignableFrom(RestaurantViewModel::class.java)); return RestaurantViewModel(useCases, recipes) as T }
        }
    }
}
