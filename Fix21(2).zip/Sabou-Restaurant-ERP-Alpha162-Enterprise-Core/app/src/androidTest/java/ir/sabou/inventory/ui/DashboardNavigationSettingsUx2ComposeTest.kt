package ir.sabou.inventory.ui

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import ir.sabou.inventory.MainActivity
import ir.sabou.inventory.SabouApplication
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test

class DashboardNavigationSettingsUx2ComposeTest {
    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    private val app: SabouApplication
        get() = composeRule.activity.application as SabouApplication

    private lateinit var owner: AppUserRecord

    @Before
    fun authenticateOwner() {
        owner = runBlocking {
            val security = app.container.securityRepository
            val users = security.users.first()
            val existing = users.firstOrNull { it.username in KNOWN_OWNER_USERNAMES }
            val resolved = existing ?: run {
                check(users.none { it.role == UserRole.OWNER }) {
                    "Unexpected owner account exists; refusing to guess credentials in UX2 instrumentation test"
                }
                security.save(null, UserDraft(OWNER_USERNAME, "مالک UX2", OWNER_PIN, UserRole.OWNER, OWNER_RECOVERY))
                security.users.first().first { it.username == OWNER_USERNAME }
            }
            if (security.currentUser.first()?.id != resolved.id) security.switchUser(resolved.id, OWNER_PIN)
            resolved
        }
        composeRule.waitUntil(15_000) { composeRule.onAllNodesWithTag("home_dashboard").fetchSemanticsNodes().isNotEmpty() }
    }

    @After
    fun restoreOwner() {
        runBlocking {
            val security = app.container.securityRepository
            if (security.currentUser.first()?.id != owner.id) runCatching { security.switchUser(owner.id, OWNER_PIN) }
        }
    }

    @Test
    fun ownerHome_hasFourPrimarySections_andNoAuditOrModuleDump() {
        composeRule.onNodeWithTag("home_header").assertIsDisplayed()
        composeRule.onNodeWithTag("home_kpi_summary").assertIsDisplayed()
        composeRule.onNodeWithTag("home_quick_actions").assertIsDisplayed()
        composeRule.onNodeWithTag("home_attention_center").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("home_kpi_sales").performScrollTo().assertIsDisplayed()
        assertTrue(composeRule.onAllNodesWithText("فعالیت‌های اخیر").fetchSemanticsNodes().isEmpty())
        assertTrue(composeRule.onAllNodesWithTag("module_AUDIT_LOG").fetchSemanticsNodes().isEmpty())
        composeRule.onNodeWithTag("nav_operations").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_reports").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_more").assertIsDisplayed()
    }

    @Test
    fun morePage_groupsAuthorizedModules_andTopLevelNavigationReturnsHome() {
        composeRule.onNodeWithTag("nav_more").performClick()
        composeRule.onNodeWithTag("more_hub").assertIsDisplayed()
        composeRule.onNodeWithTag("module_SALES").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("more_hub").performScrollToNode(hasTestTag("module_AUDIT_LOG"))
        composeRule.onNodeWithTag("module_AUDIT_LOG").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_home").performClick()
        composeRule.onNodeWithTag("home_dashboard").assertIsDisplayed()
    }

    @Test
    fun settingsSecurityAudit_isPrimaryReachableAuditPath() {
        composeRule.onNodeWithTag("home_profile").performClick()
        composeRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_sections").performScrollToNode(hasTestTag("settings_section_SECURITY_AUDIT"))
        composeRule.onNodeWithTag("settings_section_SECURITY_AUDIT").performClick()
        composeRule.onNodeWithTag("settings_security_audit").performScrollTo().performClick()
        composeRule.onNodeWithTag("audit_log_screen").assertIsDisplayed()
        composeRule.onNodeWithText("رویدادهای سیستم").assertIsDisplayed()
        composeRule.onNodeWithTag("audit_filter_search").assertIsDisplayed()
    }

    @Test
    fun cashierHome_filtersSensitiveKpisAndActionsBeforeRendering() {
        switchToRoleUser(CASHIER_USERNAME, CASHIER_PIN, UserRole.CASHIER)
        composeRule.onNodeWithTag("home_action_sale").performScrollTo().assertIsDisplayed()
        assertTrue(composeRule.onAllNodesWithTag("home_action_personnel").fetchSemanticsNodes().isEmpty())
        assertTrue(composeRule.onAllNodesWithTag("home_kpi_liquidity").fetchSemanticsNodes().isEmpty())
        composeRule.onNodeWithTag("home_kpi_sales").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun inventoryHome_showsInventoryKpis_withoutFinancialKpis() {
        switchToRoleUser(INVENTORY_USERNAME, INVENTORY_PIN, UserRole.INVENTORY)
        composeRule.onNodeWithTag("home_kpi_low_stock").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("home_kpi_expiry").performScrollTo().assertIsDisplayed()
        assertTrue(composeRule.onAllNodesWithTag("home_kpi_liquidity").fetchSemanticsNodes().isEmpty())
        composeRule.onNodeWithTag("home_action_inventory").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun operationsHub_isReachableFromBottomNavigation() {
        composeRule.onNodeWithTag("nav_operations").performClick()
        composeRule.onNodeWithTag("operations_hub").assertIsDisplayed()
        composeRule.onNodeWithTag("module_SALES").assertIsDisplayed()
    }

    private fun switchToRoleUser(username: String, pin: String, role: UserRole) {
        val target = runBlocking {
            val security = app.container.securityRepository
            if (security.currentUser.first()?.id != owner.id) security.switchUser(owner.id, OWNER_PIN)
            val existing = security.users.first().firstOrNull { it.username == username }
            val user = existing ?: run {
                security.save(null, UserDraft(username, "کاربر ${role.title}", pin, role))
                security.users.first().first { it.username == username }
            }
            security.switchUser(user.id, pin)
            user
        }
        composeRule.waitUntil(10_000) {
            composeRule.onAllNodesWithTag("home_dashboard").fetchSemanticsNodes().isNotEmpty() &&
                runBlocking { app.container.securityRepository.currentUser.first()?.id == target.id }
        }
    }

    private companion object {
        const val OWNER_USERNAME = "ux2owner"
        const val OWNER_PIN = "246810"
        const val OWNER_RECOVERY = "86421357"
        const val CASHIER_USERNAME = "ux2cashier"
        const val CASHIER_PIN = "135790"
        const val INVENTORY_USERNAME = "ux2inventory"
        const val INVENTORY_PIN = "112233"
        val KNOWN_OWNER_USERNAMES = setOf(OWNER_USERNAME, "e2eowner", "authowner")
    }
}
