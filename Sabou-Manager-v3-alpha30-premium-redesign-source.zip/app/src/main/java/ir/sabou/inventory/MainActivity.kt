package ir.sabou.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ir.sabou.inventory.ui.SabouApp
import ir.sabou.inventory.ui.ThemePreference
import ir.sabou.inventory.ui.theme.SabouTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val preferences = getSharedPreferences("sabou_ui", MODE_PRIVATE)
        var selectedTheme by mutableStateOf(
            runCatching { ThemePreference.valueOf(preferences.getString("theme", ThemePreference.SYSTEM.name)!!) }
                .getOrDefault(ThemePreference.SYSTEM),
        )
        setContent {
            val dark = when (selectedTheme) {
                ThemePreference.SYSTEM -> isSystemInDarkTheme()
                ThemePreference.LIGHT -> false
                ThemePreference.DARK -> true
            }
            SabouTheme(darkTheme = dark) {
                SabouApp(
                    container = (application as SabouApplication).container,
                    themePreference = selectedTheme,
                    onThemePreferenceChange = { value ->
                        selectedTheme = value
                        preferences.edit().putString("theme", value.name).apply()
                    },
                )
            }
        }
    }
}
