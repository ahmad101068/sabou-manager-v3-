package ir.sabou.inventory.domain.treasury

import ir.sabou.inventory.core.MoneyRial

enum class TreasuryChannel { CASH, BANK, CARD, TRANSFER }
enum class TreasuryDirection { RECEIPT, PAYMENT }
enum class SettlementStatus { PENDING, SETTLED, REVERSED }

data class TreasuryMovementDraft(
    val direction: TreasuryDirection,
    val channel: TreasuryChannel,
    val amount: MoneyRial,
    val epochDay: Long,
    val sourceType: String,
    val sourceId: Long,
    val reference: String = "",
) {
    fun validated(): TreasuryMovementDraft {
        require(amount > MoneyRial.ZERO) { "مبلغ گردش خزانه باید بیشتر از صفر باشد." }
        require(epochDay > 0) { "تاریخ گردش خزانه نامعتبر است." }
        require(sourceType.isNotBlank() && sourceId > 0) { "منشأ گردش خزانه الزامی است." }
        return copy(sourceType = sourceType.trim(), reference = reference.trim())
    }
}
