package ir.sabou.inventory.data.security

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.BusinessRuleViolation
import ir.sabou.inventory.domain.security.AuthorizationService
import ir.sabou.inventory.domain.security.AuthorizedActor
import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.security.UserRole
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

class AuthenticationRequiredException :
    BusinessRuleViolation(BusinessError.AuthenticationRequired)

class AccessDeniedException(val permission: Permission) :
    BusinessRuleViolation(BusinessError.PermissionDenied(permission))

/** Enforces authorization at the data-command boundary. UI filtering is not a security boundary. */
class SessionAuthorizer(private val database: AppDatabase) : AuthorizationService {
    suspend fun actor(): String = database.securityDao().currentUser()
        ?.let { it.displayName.ifBlank { it.username } }
        ?: "SYSTEM"

    override suspend fun actorIdentity(): AuthorizedActor {
        val user = database.securityDao().currentUser() ?: throw AuthenticationRequiredException()
        if (!user.isActive) throw AuthenticationRequiredException()
        return AuthorizedActor(
            id = user.id,
            displayName = user.displayName.ifBlank { user.username },
            role = UserRole.fromStoredValue(user.role),
        )
    }

    override suspend fun can(permission: Permission): Boolean {
        val user = database.securityDao().currentUser() ?: return false
        if (!user.isActive) return false
        return UserRole.fromStoredValue(user.role).allows(permission)
    }

    override suspend fun require(permission: Permission): AuthorizedActor {
        val actor = actorIdentity()
        val role = actor.role
        if (!role.allows(permission)) throw AccessDeniedException(permission)
        return actor
    }

    suspend fun requireOwner(): AuthorizedActor {
        val actor = actorIdentity()
        if (actor.role != UserRole.OWNER) {
            throw AccessDeniedException(Permission.MANAGE_USERS)
        }
        return actor
    }

    internal suspend fun currentUserId(): Long {
        return actorIdentity().id
    }

    /**
     * A session-aware read boundary for Room streams.
     *
     * The permission is re-evaluated whenever the active session or user row changes. Switching
     * from an authorized user to a restricted user immediately unsubscribes from the upstream DAO
     * and emits the supplied redacted value, so already-created ViewModels cannot retain a live
     * unauthorized subscription.
     */
    @OptIn(ExperimentalCoroutinesApi::class)
    internal fun <T> authorizedRead(
        permission: Permission,
        redacted: T,
        upstream: () -> Flow<T>,
    ): Flow<T> = authorizedReadAny(setOf(permission), redacted, upstream)

    @OptIn(ExperimentalCoroutinesApi::class)
    internal fun <T> authorizedReadAny(
        permissions: Set<Permission>,
        redacted: T,
        upstream: () -> Flow<T>,
    ): Flow<T> {
        require(permissions.isNotEmpty()) { "authorized_read_permissions_empty" }
        return database.securityDao().observeCurrentUser()
        .map { user ->
            user?.takeIf { it.isActive }
                ?.let { active ->
                    val role = UserRole.fromStoredValue(active.role)
                    permissions.any(role::allows)
                }
                ?: false
        }
        .distinctUntilChanged()
        .flatMapLatest { allowed -> if (allowed) upstream() else flowOf(redacted) }
    }
}
