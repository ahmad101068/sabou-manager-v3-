@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.domain.personnel.ApproveManualAdjustmentCommand
import ir.sabou.inventory.domain.personnel.ApprovePayrollBatchCommand
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.CalculatePayrollBatchCommand
import ir.sabou.inventory.domain.personnel.ClosePayrollPeriodCommand
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractRecord
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.EmploymentContractStatus
import ir.sabou.inventory.domain.personnel.EmploymentStatus
import ir.sabou.inventory.domain.personnel.ManualAdjustmentStatus
import ir.sabou.inventory.domain.personnel.ManualPayrollAdjustmentCommand
import ir.sabou.inventory.domain.personnel.PayPayslipCommand
import ir.sabou.inventory.domain.personnel.PayrollAdvanceDeductionRequest
import ir.sabou.inventory.domain.personnel.PayrollBatchDraftV2
import ir.sabou.inventory.domain.personnel.PayrollBatchRecordV2
import ir.sabou.inventory.domain.personnel.PayrollBatchStatus
import ir.sabou.inventory.domain.personnel.PayrollComponentDirection
import ir.sabou.inventory.domain.personnel.PayrollComponentType
import ir.sabou.inventory.domain.personnel.PayrollPaymentStatus
import ir.sabou.inventory.domain.personnel.PayrollPayslipDetailV2
import ir.sabou.inventory.domain.personnel.PayrollPayslipRecordV2
import ir.sabou.inventory.domain.personnel.PayrollPayslipStatus
import ir.sabou.inventory.domain.personnel.PayrollPeriodDraftV2
import ir.sabou.inventory.domain.personnel.PayrollPeriodRecordV2
import ir.sabou.inventory.domain.personnel.PayrollPeriodStatus
import ir.sabou.inventory.domain.personnel.ReopenPayrollPeriodCommand
import ir.sabou.inventory.domain.personnel.ReversePayrollPaymentCommand
import ir.sabou.inventory.domain.personnel.ReversePayslipCommandV2
import ir.sabou.inventory.domain.personnel.ReviewPayrollBatchCommand
import ir.sabou.inventory.domain.treasury.TreasuryChannel

private enum class HrWorkspaceSection(val title: String) {
    PEOPLE("افراد"),
    ATTENDANCE("حضور"),
    LEAVE("مرخصی"),
    PAYROLL("حقوق"),
    ADVANCES("مساعده"),
    PERFORMANCE("عملکرد"),
}

private enum class EmployeeDetailSection(val title: String) {
    OVERVIEW("نمای کلی"),
    EMPLOYMENT("استخدام"),
    CONTRACTS("قراردادها"),
    ATTENDANCE("حضور"),
    LEAVE("مرخصی"),
    PAYROLL("حقوق"),
    ADVANCES("مساعده"),
    PERFORMANCE("عملکرد"),
    DOCUMENTS("اسناد"),
    AUDIT("ممیزی"),
}

@Composable
internal fun HrPayrollWorkspaceScreen(
    personnelState: PersonnelUiState,
    hrState: HrPayrollUiState,
    requestedProfileEmployeeId: Long?,
    onProfileRequestConsumed: () -> Unit,
    performanceState: PerformanceUiState,
    workforceState: ControlCenterUiState,
    personnel: PersonnelViewModel,
    performance: PerformanceViewModel,
    workforce: ManagementControlViewModel,
    onBack: () -> Unit,
) {
    var section by rememberSaveable { mutableStateOf(HrWorkspaceSection.PEOPLE) }
    var editingEmployee by remember { mutableStateOf<EmployeeRecord?>(null) }
    var showEmployeeEditor by remember { mutableStateOf(false) }
    var detailEmployee by remember { mutableStateOf<EmployeeRecord?>(null) }
    var showAttendance by remember { mutableStateOf(false) }
    var correctionTarget by remember { mutableStateOf<AttendanceRecord?>(null) }
    var showAttendanceSummary by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }
    var showAdvance by remember { mutableStateOf(false) }
    var contractRevisionBase by remember { mutableStateOf<EmployeeContractRecord?>(null) }
    var showContract by remember { mutableStateOf(false) }
    var showPayrollPolicy by remember { mutableStateOf(false) }
    var showPeriod by remember { mutableStateOf(false) }
    var showBatch by remember { mutableStateOf(false) }
    var calculateBatch by remember { mutableStateOf<PayrollBatchRecordV2?>(null) }
    var showAdjustment by remember { mutableStateOf(false) }
    var paymentTarget by remember { mutableStateOf<PayrollPayslipRecordV2?>(null) }
    var reversalTarget by remember { mutableStateOf<PayrollPayslipRecordV2?>(null) }
    var paymentReversalTarget by remember { mutableStateOf<Long?>(null) }
    var showLaborPolicy by remember { mutableStateOf(false) }
    var showAvailability by remember { mutableStateOf(false) }
    var showShiftSwap by remember { mutableStateOf(false) }
    var breakTarget by remember { mutableStateOf<ir.sabou.inventory.domain.control.LaborShiftInput?>(null) }

    LaunchedEffect(requestedProfileEmployeeId, personnelState.employees) {
        personnelState.employees.firstOrNull { it.id == requestedProfileEmployeeId }?.let { employee ->
            section = HrWorkspaceSection.PEOPLE
            personnel.selectEmployee(employee.id)
            detailEmployee = employee
            onProfileRequestConsumed()
        }
    }

    Scaffold(
        topBar = {
            ProfessionalTopBar(
                "منابع انسانی و حقوق",
                "Employee 360، حضور، قرارداد و دفتر حقوق",
                onBack,
            )
        },
        floatingActionButton = {
            when (section) {
                HrWorkspaceSection.PEOPLE -> ExtendedFloatingActionButton(onClick = {
                    editingEmployee = null
                    showEmployeeEditor = true
                }) { Text("پرسنل جدید") }
                HrWorkspaceSection.ATTENDANCE -> ExtendedFloatingActionButton(onClick = { showAttendance = true }) { Text("ثبت حضور") }
                HrWorkspaceSection.LEAVE -> ExtendedFloatingActionButton(onClick = { showLeave = true }) { Text("درخواست مرخصی") }
                HrWorkspaceSection.PAYROLL -> ExtendedFloatingActionButton(onClick = { showPeriod = true }) { Text("دوره جدید") }
                HrWorkspaceSection.ADVANCES -> ExtendedFloatingActionButton(
                    onClick = { showAdvance = personnelState.selectedEmployeeId != null },
                ) { Text("مساعده جدید") }
                HrWorkspaceSection.PERFORMANCE -> Unit
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            HrWorkspaceNavigation(section) { section = it }
            personnelState.message?.let { MessageCard(it) }
            if (hrState.busy || workforceState.busy) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    CircularProgressIndicator(modifier = Modifier.padding(2.dp))
                    Text("در حال اجرای عملیات کنترل‌شده…")
                }
            }
            Box(Modifier.weight(1f)) {
                when (section) {
                    HrWorkspaceSection.PEOPLE -> PeopleHome(
                        state = personnelState,
                        onOpen = { employee -> personnel.selectEmployee(employee.id); detailEmployee = employee },
                        onEdit = { employee -> editingEmployee = employee; showEmployeeEditor = true },
                    )
                    HrWorkspaceSection.ATTENDANCE -> AttendanceCenter(
                        state = personnelState,
                        onSummary = { showAttendanceSummary = true },
                        onCorrect = { correctionTarget = it },
                    )
                    HrWorkspaceSection.LEAVE -> LeaveCenter(personnelState, personnel::reviewLeave, personnel::cancelLeave)
                    HrWorkspaceSection.PAYROLL -> PayrollCenter(
                        personnelState,
                        hrState,
                        onPolicy = { showPayrollPolicy = true },
                        onCreateBatch = { showBatch = true },
                        onCalculate = { calculateBatch = it },
                        onReview = { personnel.reviewPayrollBatch(ReviewPayrollBatchCommand(it.id, "بازبینی اجزای حقوق")) },
                        onApprove = { personnel.approvePayrollBatch(ApprovePayrollBatchCommand(it.id, "تأیید نهایی دسته حقوق")) },
                        onAdjustment = { showAdjustment = true },
                        onLoadAdjustments = personnel::loadManualAdjustments,
                        onApproveAdjustment = { personnel.approveManualAdjustment(ApproveManualAdjustmentCommand(it)) },
                        onOpenPayslip = personnel::loadPayslipDetail,
                        onSelectEmployee = personnel::selectEmployee,
                        onClosePeriod = { personnel.closePayrollPeriod(ClosePayrollPeriodCommand(it.id, "بستن کنترل‌شده دوره حقوق")) },
                        onReopenPeriod = { personnel.reopenPayrollPeriod(ReopenPayrollPeriodCommand(it.id, "بازگشایی برای Revision حقوق")) },
                    )
                    HrWorkspaceSection.ADVANCES -> AdvancesCenter(personnelState) { employee ->
                        personnel.selectEmployee(employee.id)
                        showAdvance = true
                    }
                    HrWorkspaceSection.PERFORMANCE -> WorkforcePerformanceCenter(
                        personnelState,
                        performanceState,
                        workforceState,
                        onPolicy = { showLaborPolicy = true },
                        onAvailability = { showAvailability = true },
                        onSwap = { showShiftSwap = true },
                        onBreak = { breakTarget = it },
                        onReviewSwap = workforce::reviewShiftSwap,
                    )
                }
            }
        }
    }

    if (showEmployeeEditor) EmployeeDialog(editingEmployee, { showEmployeeEditor = false }) { draft ->
        personnel.saveEmployee(editingEmployee?.id, draft)
        showEmployeeEditor = false
    }
    if (showAttendance) AttendanceDialog(personnelState, { showAttendance = false }) { draft ->
        personnel.saveAttendance(null, draft)
        showAttendance = false
    }
    correctionTarget?.let { attendance ->
        AttendanceCorrectionDialog(attendance, { correctionTarget = null }) { draft ->
            personnel.saveAttendance(attendance.id, draft)
            correctionTarget = null
        }
    }
    if (showAttendanceSummary) AttendanceSummaryDialog(personnelState, { showAttendanceSummary = false }, personnel::loadAttendanceSummary)
    if (showLeave) LeaveDialog(personnelState, { showLeave = false }) { draft ->
        personnel.requestLeave(draft)
        showLeave = false
    }
    if (showAdvance) AdvanceDialog(personnelState, { showAdvance = false }, personnel::settleAdvance) { draft ->
        personnel.postAdvance(draft)
        showAdvance = false
    }
    if (showContract) ContractVersionDialog(
        personnelState,
        contractRevisionBase,
        { showContract = false },
    ) { draft ->
        personnel.saveContract(contractRevisionBase?.id, draft)
        showContract = false
    }
    if (showPayrollPolicy) PayrollPolicyDialog({ showPayrollPolicy = false }) { draft ->
        personnel.savePayrollPolicy(draft)
        showPayrollPolicy = false
    }
    if (showPeriod) PayrollPeriodDialog({ showPeriod = false }) { draft ->
        personnel.openPayrollPeriod(draft)
        showPeriod = false
    }
    if (showBatch) PayrollBatchDialog(hrState.periods, { showBatch = false }) { draft ->
        personnel.createPayrollBatch(draft)
        showBatch = false
    }
    calculateBatch?.let { batch ->
        CalculateBatchDialog(batch, personnelState, { calculateBatch = null }) { command ->
            personnel.calculatePayrollBatch(command)
            calculateBatch = null
        }
    }
    if (showAdjustment) ManualAdjustmentDialog(personnelState, hrState.periods, { showAdjustment = false }) { command ->
        personnel.submitManualAdjustment(command)
        showAdjustment = false
    }
    detailEmployee?.let { employee ->
        Employee360Dialog(
            employee = employee,
            personnelState = personnelState,
            hrState = hrState,
            performanceState = performanceState,
            onDismiss = { detailEmployee = null; personnel.selectEmployee(null) },
            onEdit = { editingEmployee = employee; showEmployeeEditor = true },
            onNewContract = { base -> contractRevisionBase = base; showContract = true },
            onApproveContract = personnel::approveContract,
            onAdvance = { showAdvance = true },
            onOpenPayslip = personnel::loadPayslipDetail,
            onDeactivate = { personnel.deactivate(employee.id) },
        )
    }
    hrState.payslipDetail?.let { detail ->
        PayslipDetailDialog(
            detail,
            onDismiss = personnel::clearPayslipDetail,
            onPay = { paymentTarget = detail.payslip },
            onReverse = { reversalTarget = detail.payslip },
            onReversePayment = { paymentReversalTarget = it },
        )
    }
    paymentTarget?.let { payslip ->
        PayslipPaymentDialog(payslip, { paymentTarget = null }) { command ->
            personnel.payPayslip(command)
            paymentTarget = null
        }
    }
    reversalTarget?.let { payslip ->
        PayslipReversalDialog(payslip, { reversalTarget = null }) { command ->
            personnel.reversePayslipV2(command)
            reversalTarget = null
        }
    }
    paymentReversalTarget?.let { paymentId ->
        PaymentReversalDialog(paymentId, { paymentReversalTarget = null }) { command ->
            personnel.reversePayrollPayment(command)
            paymentReversalTarget = null
        }
    }
    if (showLaborPolicy) LaborPolicyDialog({ showLaborPolicy = false }) { policy ->
        workforce.saveLaborPolicy(policy) { showLaborPolicy = false }
    }
    if (showAvailability) AvailabilityDialog(personnelState.employees, { showAvailability = false }) { draft ->
        workforce.saveAvailability(draft) { showAvailability = false }
    }
    if (showShiftSwap && workforceState.snapshot != null) ShiftSwapDialog(
        workforceState.snapshot.plannedShifts,
        personnelState.employees,
        { showShiftSwap = false },
    ) { draft -> workforce.requestShiftSwap(draft) { showShiftSwap = false } }
    breakTarget?.let { shift ->
        WorkBreakDialog(shift, { breakTarget = null }) { start, end ->
            workforce.recordWorkBreak(shift.shiftId, start, end) { breakTarget = null }
        }
    }
}

@Composable
private fun HrWorkspaceNavigation(selected: HrWorkspaceSection, onSelect: (HrWorkspaceSection) -> Unit) {
    Surface(tonalElevation = 2.dp) {
        LazyRow(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(HrWorkspaceSection.entries, key = { it.name }) { item ->
                FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(item.title) })
            }
        }
    }
}

@Composable
private fun PeopleHome(
    state: PersonnelUiState,
    onOpen: (EmployeeRecord) -> Unit,
    onEdit: (EmployeeRecord) -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    var status by rememberSaveable { mutableStateOf("ACTIVE") }
    val departments = state.employees.map { it.department }.filter { it.isNotBlank() }.distinct().sorted()
    val jobs = state.employees.map { it.jobTitle }.filter { it.isNotBlank() }.distinct().sorted()
    val contractStatuses = state.employees.mapNotNull { it.contractStatus }.distinct().sortedBy { it.storedValue }
    var department by rememberSaveable { mutableStateOf<String?>(null) }
    var job by rememberSaveable { mutableStateOf<String?>(null) }
    var contractStatus by rememberSaveable { mutableStateOf<EmploymentContractStatus?>(null) }
    val rows = state.employees.filter { employee ->
        val searchable = listOf(employee.name, employee.displayName, employee.employeeCode, employee.phone, employee.jobTitle, employee.department)
            .joinToString(" ").lowercase()
        (query.isBlank() || query.trim().lowercase() in searchable) &&
            (status == "ALL" || employee.employmentStatus.storedValue == status) &&
            (department == null || employee.department == department) &&
            (job == null || employee.jobTitle == job) &&
            (contractStatus == null || employee.contractStatus == contractStatus)
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { SectionHeading("People", "جست‌وجو با نام، کد، تلفن، شغل، دپارتمان و وضعیت") }
        item { OutlinedTextField(query, { query = it }, label = { Text("نام، کد پرسنلی، تلفن یا شغل") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("ACTIVE" to "فعال", "TERMINATED" to "خاتمه‌یافته", "ON_LEAVE" to "مرخصی", "ALL" to "همه")) { item ->
                    FilterChip(status == item.first, { status = item.first }, { Text(item.second) })
                }
            }
        }
        if (departments.isNotEmpty()) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(department == null, { department = null }, { Text("همه دپارتمان‌ها") }) }
                items(departments) { value -> FilterChip(department == value, { department = value }, { Text(value) }) }
            }
        }
        if (jobs.isNotEmpty()) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(job == null, { job = null }, { Text("همه سمت‌ها") }) }
                items(jobs) { value -> FilterChip(job == value, { job = value }, { Text(value) }) }
            }
        }
        if (contractStatuses.isNotEmpty()) item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(contractStatus == null, { contractStatus = null }, { Text("همه وضعیت‌های قرارداد") }) }
                items(contractStatuses) { value ->
                    FilterChip(contractStatus == value, { contractStatus = value }, { Text(value.storedValue) })
                }
            }
        }
        if (rows.isEmpty()) item { EmptyStatePanel("پرسنلی یافت نشد", "فیلترها را تغییر دهید یا پروفایل جدید بسازید.") }
        items(rows, key = { it.id }) { employee ->
            Card(onClick = { onOpen(employee) }) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(employee.displayName, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${employee.employeeCode ?: "—"} · ${employee.jobTitle}", style = MaterialTheme.typography.bodySmall)
                        }
                        StatusPill(employee.employmentStatus.storedValue)
                    }
                    CompactInfoRow("دپارتمان / شعبه", "${employee.department.ifBlank { "—" }} / ${employee.branchName.ifBlank { "—" }}")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { onEdit(employee) }) { Text("ویرایش") }
                        TextButton(onClick = { onOpen(employee) }) { Text("Employee 360") }
                    }
                }
            }
        }
    }
}

@Composable
private fun AttendanceCenter(
    state: PersonnelUiState,
    onSummary: () -> Unit,
    onCorrect: (AttendanceRecord) -> Unit,
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                SectionHeading("Attendance", "رویدادها، Projection روزانه و اصلاح دارای دلیل")
                TextButton(onClick = onSummary) { Text("گزارش بازه") }
            }
        }
        if (state.attendance.isEmpty()) item { EmptyStatePanel("رکورد حضور وجود ندارد", "ورود/خروج یا غیبت را ثبت کنید.") }
        items(state.attendance, key = { it.id }) { row ->
            val employee = state.employees.firstOrNull { it.id == row.employeeId }
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(employee?.displayName ?: "پرسنل", fontWeight = FontWeight.Bold)
                        StatusPill(row.status)
                    }
                    CompactInfoRow("تاریخ کسب‌وکار", epochDayToPersian(row.workEpochDay).display())
                    CompactInfoRow("ورود / خروج", "${row.checkInMinute?.let(::formatMinuteOfDay) ?: "—"} / ${row.checkOutMinute?.let(::formatMinuteOfDay) ?: "—"}")
                    CompactInfoRow("کارکرد / تأخیر / اضافه‌کاری", "${row.workedMinutes} / ${row.lateMinutes} / ${row.overtimeMinutes} دقیقه")
                    OutlinedButton(onClick = { onCorrect(row) }, modifier = Modifier.fillMaxWidth()) { Text("اصلاح دستی با ثبت قبل/بعد و دلیل") }
                }
            }
        }
    }
}

@Composable
private fun LeaveCenter(
    state: PersonnelUiState,
    onReview: (ir.sabou.inventory.domain.personnel.LeaveReviewDraft) -> Unit,
    onCancel: (Long) -> Unit,
) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { SectionHeading("Leave", "DRAFT / SUBMITTED / APPROVED / REJECTED / CANCELLED / TAKEN") }
        if (state.leaves.isEmpty()) item { EmptyStatePanel("درخواست مرخصی وجود ندارد", "مرخصی تأییدشده مستقیماً ورودی Payroll است.") }
        items(state.leaves, key = { it.id }) { leave ->
            val employee = state.employees.firstOrNull { it.id == leave.employeeId }
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(employee?.displayName ?: "پرسنل", fontWeight = FontWeight.Bold)
                        StatusPill(leave.typedStatus.storedValue)
                    }
                    CompactInfoRow("نوع", leave.typedLeaveType.storedValue)
                    CompactInfoRow("بازه", "${epochDayToPersian(leave.startEpochDay).display()} تا ${epochDayToPersian(leave.endEpochDay).display()}")
                    if (leave.typedStatus == ir.sabou.inventory.domain.personnel.LeaveStatus.SUBMITTED) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onReview(ir.sabou.inventory.domain.personnel.LeaveReviewDraft(leave.id, "REJECT", "مدیر", "رد درخواست")) }, modifier = Modifier.weight(1f)) { Text("رد") }
                            Button(onClick = { onReview(ir.sabou.inventory.domain.personnel.LeaveReviewDraft(leave.id, "APPROVE", "مدیر", "تأیید درخواست")) }, modifier = Modifier.weight(1f)) { Text("تأیید") }
                        }
                    }
                    if (leave.typedStatus in setOf(ir.sabou.inventory.domain.personnel.LeaveStatus.DRAFT, ir.sabou.inventory.domain.personnel.LeaveStatus.SUBMITTED)) {
                        TextButton(onClick = { onCancel(leave.id) }) { Text("لغو") }
                    }
                }
            }
        }
    }
}

@Composable
private fun PayrollCenter(
    personnelState: PersonnelUiState,
    hrState: HrPayrollUiState,
    onPolicy: () -> Unit,
    onCreateBatch: () -> Unit,
    onCalculate: (PayrollBatchRecordV2) -> Unit,
    onReview: (PayrollBatchRecordV2) -> Unit,
    onApprove: (PayrollBatchRecordV2) -> Unit,
    onAdjustment: () -> Unit,
    onLoadAdjustments: (Long) -> Unit,
    onApproveAdjustment: (Long) -> Unit,
    onOpenPayslip: (Long) -> Unit,
    onSelectEmployee: (Long?) -> Unit,
    onClosePeriod: (PayrollPeriodRecordV2) -> Unit,
    onReopenPeriod: (PayrollPeriodRecordV2) -> Unit,
) {
    val current = hrState.periods.firstOrNull { it.status !in setOf(PayrollPeriodStatus.CLOSED, PayrollPeriodStatus.LEGACY) }
    LaunchedEffect(current?.id) { current?.let { onLoadAdjustments(it.id) } }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onPolicy, modifier = Modifier.weight(1f)) { Text("سیاست حقوق") }
                OutlinedButton(onClick = onAdjustment, enabled = current != null, modifier = Modifier.weight(1f)) { Text("تعدیل دستی") }
                Button(onClick = onCreateBatch, enabled = current != null, modifier = Modifier.weight(1f)) { Text("Batch جدید") }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("تاریخچه حقوق کارمند", fontWeight = FontWeight.Bold)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    item {
                        FilterChip(
                            selected = personnelState.selectedEmployeeId == null,
                            onClick = { onSelectEmployee(null) },
                            label = { Text("انتخاب نشده") },
                        )
                    }
                    items(personnelState.employees, key = { "payroll-employee-${it.id}" }) { employee ->
                        FilterChip(
                            selected = personnelState.selectedEmployeeId == employee.id,
                            onClick = { onSelectEmployee(employee.id) },
                            label = { Text("${employee.employeeCode ?: "—"} · ${employee.displayName}") },
                        )
                    }
                }
            }
        }
        current?.let { period ->
            item {
                Card {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("دوره جاری ${period.periodKey}", fontWeight = FontWeight.Black)
                            StatusPill(period.status.storedValue)
                        }
                        CompactInfoRow("بازه", "${epochDayToPersian(period.startEpochDay).display()} تا ${epochDayToPersian(period.endEpochDay).display()}")
                        if (period.status == PayrollPeriodStatus.PAYMENT) OutlinedButton(onClick = { onClosePeriod(period) }, modifier = Modifier.fillMaxWidth()) { Text("بستن کنترل‌شده دوره") }
                    }
                }
            }
        }
        hrState.periods.firstOrNull { it.status == PayrollPeriodStatus.CLOSED }?.let { closed ->
            item { OutlinedButton(onClick = { onReopenPeriod(closed) }, modifier = Modifier.fillMaxWidth()) { Text("بازگشایی ${closed.periodKey} برای Revision") } }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricTile("در انتظار تأیید", hrState.batches.count { it.status == PayrollBatchStatus.UNDER_REVIEW }.toString(), Modifier.weight(1f))
                MetricTile("در انتظار پرداخت", hrState.batches.count { it.status == PayrollBatchStatus.PAYMENT_PENDING }.toString(), Modifier.weight(1f))
                MetricTile("نیمه‌پرداخت", hrState.batches.count { it.status == PayrollBatchStatus.PARTIALLY_PAID }.toString(), Modifier.weight(1f))
            }
        }
        if (hrState.calculationExceptions.isNotEmpty()) {
            item { SectionHeading("Payroll Exception Center", "محاسبه تا رفع موارد مسدودکننده ادامه پیدا نمی‌کند") }
            items(hrState.calculationExceptions, key = { "${it.employeeId}-${it.code}-${it.detail}" }) { item ->
                MessageCard("${if (item.blocking) "مسدودکننده" else "هشدار"}: ${item.code} · ${item.detail}", item.blocking)
            }
        }
        if (hrState.manualAdjustments.isNotEmpty()) {
            item { SectionHeading("تعدیلات حقوق", "ثبت‌کننده و تأییدکننده باید متفاوت باشند") }
            items(hrState.manualAdjustments, key = { "adjustment-${it.id}" }) { adjustment ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("${adjustment.componentType.storedValue} · ${formatMoney(adjustment.amountRial)}", fontWeight = FontWeight.Bold)
                        Text(adjustment.reason, style = MaterialTheme.typography.bodySmall)
                        StatusPill(adjustment.status.storedValue)
                        if (adjustment.status == ManualAdjustmentStatus.SUBMITTED) {
                            OutlinedButton(onClick = { onApproveAdjustment(adjustment.id) }, modifier = Modifier.fillMaxWidth()) { Text("تأیید توسط کاربر مستقل") }
                        }
                    }
                }
            }
        }
        item { SectionHeading("Payroll Batches", "Calculation، Approval و Payment رویدادهای جدا هستند") }
        if (hrState.batches.isEmpty()) item { EmptyStatePanel("دسته حقوقی وجود ندارد", "ابتدا دوره و سپس Batch بسازید.") }
        items(hrState.batches, key = { it.id }) { batch ->
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(batch.documentNumber, fontWeight = FontWeight.Black)
                        StatusPill(batch.status.storedValue)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricTile("ناخالص", formatMoney(batch.grossPayrollRial), Modifier.weight(1f))
                        MetricTile("خالص", formatMoney(batch.netPayrollRial), Modifier.weight(1f))
                    }
                    CompactInfoRow("پرسنل / استثنا", "${batch.employeesIncluded} / ${batch.exceptionCount}", batch.exceptionCount > 0)
                    CompactInfoRow("پرداخت / مانده", "${formatMoney(batch.paidRial)} / ${formatMoney(batch.remainingRial)}", batch.remainingRial > 0)
                    when (batch.status) {
                        PayrollBatchStatus.DRAFT -> Button(onClick = { onCalculate(batch) }, modifier = Modifier.fillMaxWidth()) { Text("محاسبه Atomic") }
                        PayrollBatchStatus.CALCULATED -> Button(onClick = { onReview(batch) }, modifier = Modifier.fillMaxWidth()) { Text("ارسال برای بازبینی") }
                        PayrollBatchStatus.UNDER_REVIEW -> Button(onClick = { onApprove(batch) }, modifier = Modifier.fillMaxWidth()) { Text("تأیید نهایی و ثبت تعهد") }
                        else -> Unit
                    }
                }
            }
        }
        if (hrState.employeePayslips.isNotEmpty()) {
            item { SectionHeading("تاریخچه حقوق کارمند منتخب", "ماه‌به‌ماه، Revision و مانده پرداخت") }
            items(hrState.employeePayslips, key = { it.id }) { payslip ->
                PayslipHistoryRow(payslip, hrState.periods.firstOrNull { it.id == payslip.periodId }, onOpenPayslip)
            }
        } else if (personnelState.selectedEmployeeId != null) {
            item { EmptyStatePanel("فیشی برای کارمند منتخب نیست", "فیش‌های Legacy نیز بدون ساخت جزئیات جعلی در اینجا نمایش داده می‌شوند.") }
        }
    }
}

@Composable
private fun PayslipHistoryRow(
    payslip: PayrollPayslipRecordV2,
    period: PayrollPeriodRecordV2?,
    onOpen: (Long) -> Unit,
) {
    Card(onClick = { onOpen(payslip.id) }) {
        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${period?.periodKey ?: "دوره #${payslip.periodId}"} · نسخه ${payslip.revisionNo}", fontWeight = FontWeight.Bold)
                StatusPill(payslip.status.storedValue)
            }
            CompactInfoRow("ناخالص / کسورات / خالص", "${formatMoney(payslip.grossPay.value)} / ${formatMoney(payslip.totalDeductions.value)} / ${formatMoney(payslip.netPay.value)}")
            CompactInfoRow("پرداخت / مانده", "${formatMoney(payslip.paidAmount.value)} / ${formatMoney(payslip.remainingAmount.value)}", payslip.remainingAmount.value > 0)
            if (!payslip.componentDetailComplete) Text("Legacy: جزئیات مؤلفه‌ها در منبع تاریخی موجود نبوده و ساخته نشده است.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AdvancesCenter(state: PersonnelUiState, onOpen: (EmployeeRecord) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { SectionHeading("Advances & Loans", "اصل، مانده و تخصیص کسر حقوق به‌صورت مستقل") }
        if (state.openAdvances.isEmpty()) item { EmptyStatePanel("مساعده باز وجود ندارد", "کسر هر Payroll از دفتر تخصیص و مانده کنترل می‌شود.") }
        items(state.employees, key = { "advance-employee-${it.id}" }) { employee ->
            val advances = state.openAdvances.filter { it.employeeId == employee.id }
            if (advances.isNotEmpty()) Card(onClick = { onOpen(employee) }) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text(employee.displayName, fontWeight = FontWeight.Bold)
                    CompactInfoRow("تعداد مساعده باز", advances.size.toString())
                    CompactInfoRow("مانده کل", formatMoney(advances.sumOf { it.remainingAmountRial }))
                }
            }
        }
    }
}

@Composable
private fun WorkforcePerformanceCenter(
    personnelState: PersonnelUiState,
    performanceState: PerformanceUiState,
    workforceState: ControlCenterUiState,
    onPolicy: () -> Unit,
    onAvailability: () -> Unit,
    onSwap: () -> Unit,
    onBreak: (ir.sabou.inventory.domain.control.LaborShiftInput) -> Unit,
    onReviewSwap: (Long, Boolean) -> Unit,
) {
    val snapshot = workforceState.snapshot
    val laborAlerts = snapshot?.laborAlerts.orEmpty()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 14.dp, 16.dp, 96.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item { SectionHeading("Performance", "هدف‌ها و ارزیابی‌های دوره‌ای") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricTile("هدف فعال", performanceState.goals.count { it.status == "ACTIVE" }.toString(), Modifier.weight(1f))
                MetricTile("ارزیابی", performanceState.reviews.size.toString(), Modifier.weight(1f))
                MetricTile("پرسنل", personnelState.employees.size.toString(), Modifier.weight(1f))
            }
        }
        item { SectionHeading("Workforce ownership", "شیفت، دسترس‌پذیری، تعویض و استراحت از Management Control به HR منتقل شده‌اند") }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAvailability, modifier = Modifier.weight(1f)) { Text("دسترس‌پذیری") }
                OutlinedButton(onClick = onSwap, modifier = Modifier.weight(1f)) { Text("تعویض شیفت") }
                OutlinedButton(onClick = onPolicy, modifier = Modifier.weight(1f)) { Text("سیاست کار") }
            }
        }
        if (laborAlerts.isEmpty()) item { EmptyStatePanel("مغایرت کاری وجود ندارد", "کنترل ساعات و استراحت از همین مرکز انجام می‌شود.") }
        else items(laborAlerts, key = { "${it.shiftId}-${it.message}" }) { alert ->
            Card {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(alert.employeeName, fontWeight = FontWeight.Bold)
                    Text(alert.message)
                    snapshot?.plannedShifts?.firstOrNull { it.shiftId == alert.shiftId }?.let { shift ->
                        OutlinedButton(onClick = { onBreak(shift) }, modifier = Modifier.fillMaxWidth()) { Text("ثبت استراحت شیفت") }
                    }
                }
            }
        }
        snapshot?.shiftSwaps?.let { swaps ->
            items(swaps, key = { "swap-${it.id}" }) { swap ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("تعویض شیفت · ${swap.requesterName}", fontWeight = FontWeight.Bold)
                        Text("${swap.note} · ${swap.status}")
                        if (swap.status == "PENDING") Row(Modifier.fillMaxWidth()) {
                            TextButton(onClick = { onReviewSwap(swap.id, false) }) { Text("رد") }
                            TextButton(onClick = { onReviewSwap(swap.id, true) }, enabled = swap.targetEmployeeId != null) { Text("تأیید") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Employee360Dialog(
    employee: EmployeeRecord,
    personnelState: PersonnelUiState,
    hrState: HrPayrollUiState,
    performanceState: PerformanceUiState,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onNewContract: (EmployeeContractRecord?) -> Unit,
    onApproveContract: (Long) -> Unit,
    onAdvance: () -> Unit,
    onOpenPayslip: (Long) -> Unit,
    onDeactivate: () -> Unit,
) {
    var section by rememberSaveable(employee.id) { mutableStateOf(EmployeeDetailSection.OVERVIEW) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(employee.displayName)
                Text("${employee.employeeCode ?: "—"} · ${employee.employmentStatus.storedValue}", style = MaterialTheme.typography.bodySmall)
            }
        },
        text = {
            Column(Modifier.heightIn(max = 620.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(EmployeeDetailSection.entries, key = { it.name }) { item ->
                        FilterChip(section == item, { section = item }, { Text(item.title) })
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (section) {
                        EmployeeDetailSection.OVERVIEW -> {
                            item { CompactInfoRow("نام / تلفن", "${employee.displayName} / ${employee.phone.ifBlank { "—" }}") }
                            item { CompactInfoRow("شغل / دپارتمان", "${employee.jobTitle} / ${employee.department}") }
                            item { CompactInfoRow("شعبه", employee.branchName.ifBlank { "—" }) }
                            item { CompactInfoRow("تاریخ استخدام", employee.hireEpochDay?.let { epochDayToPersian(it).display() } ?: "ثبت نشده") }
                            item { CompactInfoRow("حساب پرداخت", employee.maskedBankAccount.ifBlank { "تعریف نشده" }) }
                        }
                        EmployeeDetailSection.EMPLOYMENT -> {
                            item { Text("وضعیت استخدام: ${employee.employmentStatus.storedValue}", fontWeight = FontWeight.Bold) }
                            item { CompactInfoRow("شروع همکاری", employee.hireEpochDay?.let { epochDayToPersian(it).display() } ?: "نامشخص") }
                            item { CompactInfoRow("خاتمه همکاری", employee.terminationEpochDay?.let { epochDayToPersian(it).display() } ?: "—") }
                            item { SectionHeading("Timeline", "Projection تاریخ‌دار از منابع اصلی؛ بدون کپی‌کردن واقعیت‌های HR") }
                            if (hrState.employeeTimeline.isEmpty()) {
                                item { EmptyStatePanel("رویداد تاریخی ثبت نشده است", "سمت و قرارداد جدید با تاریخ اثر در Timeline ظاهر می‌شوند.") }
                            }
                            items(hrState.employeeTimeline, key = { it.stableKey }) { event ->
                                Card {
                                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                        ) {
                                            Text(event.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                            StatusPill(event.eventType)
                                        }
                                        Text(
                                            "${epochDayToPersian(event.businessEpochDay).display()} · ${event.referenceType} #${event.referenceId}",
                                            style = MaterialTheme.typography.bodySmall,
                                        )
                                    }
                                }
                            }
                        }
                        EmployeeDetailSection.CONTRACTS -> {
                            item { Button(onClick = { onNewContract(null) }, modifier = Modifier.fillMaxWidth()) { Text("قرارداد جدید") } }
                            items(personnelState.contracts, key = { it.id }) { contract ->
                                Card {
                                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                        Text("${contract.contractNumber.ifBlank { "قرارداد #${contract.id}" }} · نسخه ${contract.versionNo}", fontWeight = FontWeight.Bold)
                                        CompactInfoRow("بازه", "${epochDayToPersian(contract.startEpochDay).display()} تا ${contract.endEpochDay?.let { epochDayToPersian(it).display() } ?: "باز"}")
                                        CompactInfoRow("حقوق Snapshot", formatMoney(contract.baseSalaryRial))
                                        StatusPill(contract.typedStatus.storedValue)
                                        if (contract.typedStatus == EmploymentContractStatus.PENDING_APPROVAL) OutlinedButton(onClick = { onApproveContract(contract.id) }, modifier = Modifier.fillMaxWidth()) { Text("تأیید قرارداد") }
                                        OutlinedButton(
                                            onClick = { onNewContract(contract) },
                                            modifier = Modifier.fillMaxWidth(),
                                            enabled = contract.typedStatus !in setOf(
                                                EmploymentContractStatus.SUPERSEDED,
                                                EmploymentContractStatus.CANCELLED,
                                            ),
                                        ) { Text("نسخه اصلاحی") }
                                    }
                                }
                            }
                        }
                        EmployeeDetailSection.ATTENDANCE -> items(personnelState.attendance.filter { it.employeeId == employee.id }.take(30), key = { it.id }) { row ->
                            CompactInfoRow(epochDayToPersian(row.workEpochDay).display(), "${row.status} · ${row.workedMinutes} دقیقه")
                        }
                        EmployeeDetailSection.LEAVE -> items(personnelState.leaves.filter { it.employeeId == employee.id }, key = { it.id }) { leave ->
                            CompactInfoRow("${leave.typedLeaveType.storedValue} · ${leave.typedStatus.storedValue}", "${epochDayToPersian(leave.startEpochDay).display()} تا ${epochDayToPersian(leave.endEpochDay).display()}")
                        }
                        EmployeeDetailSection.PAYROLL -> {
                            if (hrState.employeePayslips.isEmpty()) item { EmptyStatePanel("تاریخچه حقوق موجود نیست", "هیچ مبلغی از حقوق فعلی برای گذشته بازسازی نمی‌شود.") }
                            items(hrState.employeePayslips, key = { it.id }) { payslip ->
                                PayslipHistoryRow(payslip, hrState.periods.firstOrNull { it.id == payslip.periodId }, onOpenPayslip)
                            }
                        }
                        EmployeeDetailSection.ADVANCES -> {
                            item { Button(onClick = onAdvance, modifier = Modifier.fillMaxWidth()) { Text("ثبت/تسویه مساعده") } }
                            items(personnelState.advances, key = { it.id }) { advance ->
                                CompactInfoRow("مساعده #${advance.id} · ${advance.status}", "مانده ${formatMoney(advance.remainingAmountRial)}")
                            }
                        }
                        EmployeeDetailSection.PERFORMANCE -> {
                            items(performanceState.goals.filter { it.employeeId == employee.id }, key = { it.id }) { goal ->
                                CompactInfoRow(goal.title, goal.status)
                            }
                            items(performanceState.reviews.filter { it.employeeId == employee.id }, key = { "review-${it.id}" }) { review ->
                                CompactInfoRow("ارزیابی ${review.status}", "امتیاز ${review.finalScoreBasisPoints / 100.0}")
                            }
                        }
                        EmployeeDetailSection.DOCUMENTS -> {
                            item { SectionHeading("اسناد قابل ارائه", "قراردادها و فیش‌های ذخیره‌شده همین پرسنل") }
                            if (personnelState.contracts.isEmpty() && hrState.employeePayslips.isEmpty()) {
                                item { EmptyStatePanel("سندی ثبت نشده است", "پس از ثبت قرارداد یا محاسبه حقوق، سند واقعی در این بخش نمایش داده می‌شود.") }
                            }
                            items(personnelState.contracts, key = { "document-contract-${it.id}" }) { contract ->
                                Card {
                                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                        Text(contract.contractNumber.ifBlank { "قرارداد #${contract.id}" }, fontWeight = FontWeight.Bold)
                                        CompactInfoRow("نسخه / وضعیت", "${contract.versionNo} / ${contract.typedStatus.storedValue}")
                                        CompactInfoRow("بازه", "${epochDayToPersian(contract.startEpochDay).display()} تا ${contract.endEpochDay?.let { epochDayToPersian(it).display() } ?: "باز"}")
                                    }
                                }
                            }
                            items(hrState.employeePayslips, key = { "document-payslip-${it.id}" }) { payslip ->
                                PayslipHistoryRow(
                                    payslip,
                                    hrState.periods.firstOrNull { it.id == payslip.periodId },
                                    onOpenPayslip,
                                )
                            }
                        }
                        EmployeeDetailSection.AUDIT -> {
                            item { SectionHeading("ردپای ممیزی", "رویدادهای تاریخ‌دار از منابع اصلی و Audit Log") }
                            if (hrState.employeeTimeline.isEmpty()) {
                                item { EmptyStatePanel("رویداد ممیزی ثبت نشده است", "هیچ رویداد مرتبط با این پرسنل در منبع داده موجود نیست.") }
                            }
                            items(hrState.employeeTimeline, key = { "audit-${it.stableKey}" }) { event ->
                                Card {
                                    Column(Modifier.fillMaxWidth().padding(10.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(event.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                            StatusPill(event.eventType)
                                        }
                                        Text(
                                            "${epochDayToPersian(event.businessEpochDay).display()} · ${event.referenceType} #${event.referenceId}",
                                            style = MaterialTheme.typography.bodySmall,
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onEdit) { Text("ویرایش پروفایل") } },
        dismissButton = {
            Row {
                if (employee.employmentStatus != EmploymentStatus.ARCHIVED) TextButton(onClick = onDeactivate) { Text("بایگانی") }
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        },
    )
}

@Composable
private fun PayslipDetailDialog(
    detail: PayrollPayslipDetailV2,
    onDismiss: () -> Unit,
    onPay: () -> Unit,
    onReverse: () -> Unit,
    onReversePayment: (Long) -> Unit,
) {
    val context = LocalContext.current
    val earnings = detail.components.filter { it.direction == PayrollComponentDirection.EARNING }
    val deductions = detail.components.filter { it.direction == PayrollComponentDirection.DEDUCTION }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("فیش ${detail.payslip.employeeNameSnapshot} · نسخه ${detail.payslip.revisionNo}") },
        text = {
            LazyColumn(Modifier.heightIn(max = 620.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { StatusPill(detail.payslip.status.storedValue) }
                item { SectionHeading("Earnings", "اجزای مثبت با منبع") }
                if (earnings.isEmpty()) item { Text("جزئیات درآمد در منبع موجود نیست.") }
                items(earnings) { component -> CompactInfoRow(component.description, formatMoney(component.amountRial)) }
                item { SectionHeading("Deductions", "کسورات مثبت با Direction مجزا") }
                if (deductions.isEmpty()) item { Text("کسری ثبت نشده است.") }
                items(deductions) { component -> CompactInfoRow(component.description, formatMoney(component.amountRial)) }
                item {
                    Card {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            CompactInfoRow("ناخالص", formatMoney(detail.payslip.grossPay.value))
                            CompactInfoRow("کسورات", formatMoney(detail.payslip.totalDeductions.value))
                            CompactInfoRow("خالص", formatMoney(detail.payslip.netPay.value))
                            CompactInfoRow("پرداخت / مانده", "${formatMoney(detail.payslip.paidAmount.value)} / ${formatMoney(detail.payslip.remainingAmount.value)}")
                        }
                    }
                }
                item { SectionHeading("Attendance & Leave Snapshot", "ورودی‌های تأییدشده همان دوره") }
                detail.snapshot?.let { snapshot ->
                    item { CompactInfoRow("کارکرد / اضافه‌کاری", "${snapshot.actualWorkMinutes} / ${snapshot.overtimeMinutes} دقیقه") }
                    item { CompactInfoRow("غیبت / تأخیر", "${snapshot.absenceMinutes} / ${snapshot.lateMinutes} دقیقه") }
                    item { CompactInfoRow("مرخصی باحقوق / بی‌حقوق", "${snapshot.paidLeaveMinutes} / ${snapshot.unpaidLeaveMinutes} دقیقه") }
                    item { CompactInfoRow("قرارداد / نسخه", "${snapshot.contractId} / ${snapshot.contractVersionNo}") }
                    item { CompactInfoRow("حقوق پایه Snapshot", formatMoney(snapshot.baseSalaryRial)) }
                    item { CompactInfoRow("Policy / نسخه", "${snapshot.payrollPolicyId} / ${snapshot.payrollPolicyVersion}") }
                } ?: item { Text("Legacy: Snapshot کامل در منبع قبلی وجود نداشته است.", color = MaterialTheme.colorScheme.error) }
                item { SectionHeading("Advance allocations", "کسرها از مانده مساعده بیشتر نمی‌شوند") }
                items(detail.advanceAllocations) { allocation -> CompactInfoRow("مساعده #${allocation.advanceId}", formatMoney(allocation.amountRial)) }
                item { SectionHeading("Payment ledger", "پرداخت کامل/جزئی و برگشت جبرانی") }
                items(detail.payments, key = { it.id }) { payment ->
                    Card {
                        Column(Modifier.fillMaxWidth().padding(8.dp)) {
                            CompactInfoRow("${payment.status.storedValue} · ${payment.paymentReference}", formatMoney(payment.amountRial))
                            CompactInfoRow("تاریخ / خزانه", "${epochDayToPersian(payment.paymentEpochDay).display()} / ${payment.treasuryAccountId}")
                            if (payment.status == PayrollPaymentStatus.POSTED && payment.reversalOfPaymentId == null) TextButton(onClick = { onReversePayment(payment.id) }) { Text("برگشت پرداخت") }
                        }
                    }
                }
                item { SectionHeading("Accounting", "تعهد و تسویه جدا") }
                item { CompactInfoRow("سند تعهد", detail.accrualJournalEntryId?.toString() ?: "—") }
                item { CompactInfoRow("سند برگشت", detail.reversalJournalEntryId?.toString() ?: "—") }
                item { SectionHeading("Approval & Audit", "actor، timestamp، reason و Correlation") }
                items(detail.approvalHistory, key = { it.id }) { approval ->
                    CompactInfoRow("${approval.eventType} · actor ${approval.actorId}", "${approval.fromStatus} → ${approval.toStatus}")
                }
            }
        },
        confirmButton = {
            if (detail.payslip.status in setOf(PayrollPayslipStatus.PAYMENT_PENDING, PayrollPayslipStatus.PARTIALLY_PAID)) {
                Button(onClick = onPay) { Text("پرداخت ${formatMoney(detail.payslip.remainingAmount.value)}") }
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { printPayrollPayslipV2(context, detail) }) { Text("چاپ فیش") }
                if (detail.payslip.status in setOf(PayrollPayslipStatus.APPROVED, PayrollPayslipStatus.PAYMENT_PENDING, PayrollPayslipStatus.PARTIALLY_PAID, PayrollPayslipStatus.PAID)) {
                    TextButton(onClick = onReverse) { Text("برگشت فیش") }
                }
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        },
    )
}

@Composable
private fun PayrollPeriodDialog(onDismiss: () -> Unit, onSave: (PayrollPeriodDraftV2) -> Unit) {
    val today = currentEpochDay()
    val persian = epochDayToPersian(today)
    var key by remember { mutableStateOf("PAY-${persian.year}-${persian.month.toString().padStart(2, '0')}") }
    var start by remember { mutableLongStateOf(PersianDate(persian.year, persian.month, 1).toEpochDay()) }
    var end by remember { mutableLongStateOf(PersianDate(persian.year, persian.month, daysInPersianMonth(persian.year, persian.month)).toEpochDay()) }
    var due by remember { mutableStateOf<Long?>(null) }
    val commandId = remember { GlobalId.new().value }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("دوره حقوق") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            OutlinedTextField(key, { key = it.uppercase().take(40) }, label = { Text("شناسه یکتا دوره") }, modifier = Modifier.fillMaxWidth())
            PersianDateField("شروع", start) { start = it }
            PersianDateField("پایان", end) { end = it }
            OptionalPersianDateField("سررسید پرداخت", due, { due = it }, end)
        } },
        confirmButton = { Button(onClick = {
            runCatching { PayrollPeriodDraftV2(key, start, end, due, commandId).validated() }.onSuccess(onSave).onFailure { error = it.message }
        }) { Text("باز کردن دوره") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayrollBatchDialog(periods: List<PayrollPeriodRecordV2>, onDismiss: () -> Unit, onSave: (PayrollBatchDraftV2) -> Unit) {
    val available = periods.filter { it.status in setOf(PayrollPeriodStatus.OPEN, PayrollPeriodStatus.REOPENED, PayrollPeriodStatus.CALCULATING) }
    var periodId by remember { mutableLongStateOf(available.firstOrNull()?.id ?: 0L) }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Payroll Batch") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            Text("هر Batch یک سند مستقل با Calculator، Reviewer، Approver و Correlation ID است.")
            available.forEach { period -> FilterChip(periodId == period.id, { periodId = period.id }, { Text(period.periodKey) }) }
            OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("یادداشت") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching { PayrollBatchDraftV2(periodId, notes = notes, commandId = commandId).validated() }
                .onSuccess(onSave)
                .onFailure { error = it.message }
        }, enabled = periodId > 0) { Text("ایجاد Batch") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun CalculateBatchDialog(
    batch: PayrollBatchRecordV2,
    state: PersonnelUiState,
    onDismiss: () -> Unit,
    onCalculate: (CalculatePayrollBatchCommand) -> Unit,
) {
    val employees = state.employees.filter { it.employmentStatus !in setOf(EmploymentStatus.APPLICANT, EmploymentStatus.ARCHIVED) }
    var advanceEmployeeId by remember { mutableLongStateOf(0L) }
    var advanceAmount by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("محاسبه Atomic ${batch.documentNumber}") },
        text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            Text("${employees.size} کارمند بررسی می‌شوند. در صورت Contract/Attendance/Policy Exception هیچ فیشی ساخته نمی‌شود.")
            Text("کسر اختیاری مساعده", fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                item { FilterChip(advanceEmployeeId == 0L, { advanceEmployeeId = 0 }, { Text("بدون کسر") }) }
                items(employees) { employee -> FilterChip(advanceEmployeeId == employee.id, { advanceEmployeeId = employee.id }, { Text(employee.displayName) }) }
            }
            OutlinedTextField(advanceAmount, { advanceAmount = formatMoneyInput(it) }, label = { Text("مبلغ کسر مساعده") }, enabled = advanceEmployeeId > 0, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            val amount = parseMoneyInputOrZero(advanceAmount)
            runCatching {
                CalculatePayrollBatchCommand(
                    batchId = batch.id,
                    employeeIds = employees.map { it.id },
                    advanceDeductions = if (advanceEmployeeId > 0 && amount > 0) listOf(PayrollAdvanceDeductionRequest(advanceEmployeeId, amount)) else emptyList(),
                    commandId = commandId,
                ).validated()
            }.onSuccess(onCalculate).onFailure { error = it.message }
        }, enabled = employees.isNotEmpty()) { Text("محاسبه") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun ManualAdjustmentDialog(
    state: PersonnelUiState,
    periods: List<PayrollPeriodRecordV2>,
    onDismiss: () -> Unit,
    onSave: (ManualPayrollAdjustmentCommand) -> Unit,
) {
    var employeeId by remember { mutableLongStateOf(state.employees.firstOrNull { it.isActive }?.id ?: 0L) }
    var periodId by remember { mutableLongStateOf(periods.firstOrNull { it.status != PayrollPeriodStatus.CLOSED }?.id ?: 0L) }
    var direction by remember { mutableStateOf(PayrollComponentDirection.EARNING) }
    var type by remember { mutableStateOf(PayrollComponentType.BONUS) }
    var amount by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعدیل دستی حقوق") },
        text = { Column(Modifier.heightIn(max = 540.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            Text("Reason و تأیید کاربر مستقل الزامی است.")
            state.employees.filter { it.isActive }.forEach { employee -> FilterChip(employeeId == employee.id, { employeeId = employee.id }, { Text(employee.displayName) }) }
            periods.filter { it.status != PayrollPeriodStatus.CLOSED }.forEach { period -> FilterChip(periodId == period.id, { periodId = period.id }, { Text(period.periodKey) }) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(direction == PayrollComponentDirection.EARNING, { direction = PayrollComponentDirection.EARNING; type = PayrollComponentType.BONUS }, { Text("درآمد") })
                FilterChip(direction == PayrollComponentDirection.DEDUCTION, { direction = PayrollComponentDirection.DEDUCTION; type = PayrollComponentType.OTHER_DEDUCTION }, { Text("کسری") })
            }
            val types = if (direction == PayrollComponentDirection.EARNING) listOf(PayrollComponentType.BONUS, PayrollComponentType.ALLOWANCE, PayrollComponentType.COMMISSION, PayrollComponentType.OTHER_EARNING) else listOf(PayrollComponentType.OTHER_DEDUCTION, PayrollComponentType.LOAN_DEDUCTION)
            types.forEach { value -> FilterChip(type == value, { type = value }, { Text(value.storedValue) }) }
            OutlinedTextField(amount, { amount = formatMoneyInput(it) }, label = { Text("مبلغ") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(reason, { reason = it.take(500) }, label = { Text("دلیل") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching { ManualPayrollAdjustmentCommand(employeeId, periodId, type, direction, parseMoneyInputOrZero(amount), reason, commandId = commandId).validated() }
                .onSuccess(onSave)
                .onFailure { error = it.message }
        }) { Text("ارسال برای تأیید") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun ContractVersionDialog(
    state: PersonnelUiState,
    base: EmployeeContractRecord?,
    onDismiss: () -> Unit,
    onSave: (EmployeeContractDraft) -> Unit,
) {
    val employeeId = state.selectedEmployeeId ?: 0L
    val employee = state.employees.firstOrNull { it.id == employeeId }
    var type by remember { mutableStateOf(base?.contractType ?: "FIXED_TERM") }
    var start by remember { mutableLongStateOf(base?.startEpochDay ?: currentEpochDay()) }
    var end by remember { mutableStateOf(base?.endEpochDay) }
    var salary by remember { mutableStateOf(formatMoneyInputFromRial(base?.baseSalaryRial ?: employee?.monthlySalaryRial ?: 0L)) }
    var dailyMinutes by remember { mutableStateOf((base?.dailyWorkMinutes ?: 480).toString()) }
    var weeklyDays by remember { mutableStateOf((base?.weeklyWorkDays ?: 6).toString()) }
    var policyId by remember { mutableStateOf(base?.payrollPolicyId ?: state.payrollPolicies.firstOrNull()?.id) }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (base == null) "قرارداد جدید" else "نسخه اصلاحی قرارداد") },
        text = { Column(Modifier.heightIn(max = 570.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            OutlinedTextField(type, { type = it.uppercase().take(40) }, label = { Text("نوع قرارداد") }, modifier = Modifier.fillMaxWidth())
            PersianDateField("شروع اثر", start) { start = it }
            OptionalPersianDateField("پایان", end, { end = it }, start)
            OutlinedTextField(salary, { salary = formatMoneyInput(it) }, label = { Text("حقوق پایه ریال") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(dailyMinutes, { dailyMinutes = it.filter(Char::isDigit) }, label = { Text("دقیقه کار روزانه") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(weeklyDays, { weeklyDays = it.filter(Char::isDigit) }, label = { Text("روز کار هفتگی") }, modifier = Modifier.fillMaxWidth())
            state.payrollPolicies.forEach { policy -> FilterChip(policyId == policy.id, { policyId = policy.id }, { Text("${policy.title} · v${policy.versionNo}") }) }
            if (base != null) OutlinedTextField(reason, { reason = it.take(500) }, label = { Text("دلیل اصلاح الزامی") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                EmployeeContractDraft(
                    employeeId = employeeId,
                    contractType = type,
                    startEpochDay = start,
                    endEpochDay = end,
                    baseSalaryRial = parseMoneyInputOrZero(salary),
                    dailyWorkMinutes = dailyMinutes.toInt(),
                    weeklyWorkDays = weeklyDays.toInt(),
                    payrollPolicyId = policyId,
                    jobTitleSnapshot = employee?.jobTitle.orEmpty(),
                    departmentSnapshot = employee?.department.orEmpty(),
                    branchSnapshot = employee?.branchName.orEmpty(),
                    correctionReason = reason,
                ).validated()
            }.onSuccess(onSave).onFailure { error = it.message }
        }) { Text("ذخیره نسخه") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun AttendanceCorrectionDialog(
    row: AttendanceRecord,
    onDismiss: () -> Unit,
    onSave: (AttendanceDraft) -> Unit,
) {
    var checkIn by remember { mutableStateOf(row.checkInMinute?.let(::formatMinuteOfDay).orEmpty()) }
    var checkOut by remember { mutableStateOf(row.checkOutMinute?.let(::formatMinuteOfDay).orEmpty()) }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("اصلاح حضور با Audit") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            OutlinedTextField(checkIn, { checkIn = it.take(5) }, label = { Text("ورود HH:mm") })
            OutlinedTextField(checkOut, { checkOut = it.take(5) }, label = { Text("خروج HH:mm") })
            OutlinedTextField(reason, { reason = it.take(500) }, label = { Text("دلیل اصلاح") })
            Text("قبل/بعد، actor، timestamp و Correlation ID ثبت می‌شوند.", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                AttendanceDraft(
                    employeeId = row.employeeId,
                    workEpochDay = row.workEpochDay,
                    status = "PRESENT",
                    checkInMinute = parseClock(checkIn),
                    checkOutMinute = parseClock(checkOut),
                    notes = "اصلاح دستی",
                    commandId = commandId,
                    correctionReason = reason,
                    requiresApproval = false,
                ).validated()
            }.onSuccess(onSave).onFailure { error = it.message }
        }) { Text("ثبت اصلاح") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayslipPaymentDialog(
    payslip: PayrollPayslipRecordV2,
    onDismiss: () -> Unit,
    onPay: (PayPayslipCommand) -> Unit,
) {
    var amount by remember { mutableStateOf(formatMoneyInputFromRial(payslip.remainingAmount.value)) }
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var channel by remember { mutableStateOf(TreasuryChannel.BANK) }
    var reference by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("پرداخت کامل یا جزئی") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            Text("مانده قابل پرداخت: ${formatMoney(payslip.remainingAmount.value)}")
            OutlinedTextField(amount, { amount = formatMoneyInput(it) }, label = { Text("مبلغ پرداخت") }, modifier = Modifier.fillMaxWidth())
            PersianDateField("تاریخ پرداخت", day) { day = it }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(channel == TreasuryChannel.BANK, { channel = TreasuryChannel.BANK }, { Text("بانک") })
                FilterChip(channel == TreasuryChannel.CASH, { channel = TreasuryChannel.CASH }, { Text("صندوق") })
            }
            OutlinedTextField(reference, { reference = it.take(120) }, label = { Text("مرجع پرداخت") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                PayPayslipCommand(
                    payslip.id,
                    parseMoneyInputOrZero(amount),
                    if (channel == TreasuryChannel.BANK) "bank_main" else "cash_main",
                    channel,
                    day,
                    reference,
                    commandId,
                ).validated()
            }.onSuccess(onPay).onFailure { error = it.message }
        }) { Text("ثبت پرداخت") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayslipReversalDialog(
    payslip: PayrollPayslipRecordV2,
    onDismiss: () -> Unit,
    onReverse: (ReversePayslipCommandV2) -> Unit,
) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("برگشت فیش نسخه ${payslip.revisionNo}") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            MessageCard("اگر پرداخت POSTED وجود دارد ابتدا همان پرداخت را برگشت دهید. اصلاح حقوق با Revision جدید ثبت می‌شود.", true)
            PersianDateField("تاریخ کسب‌وکار برگشت", day) { day = it }
            OutlinedTextField(reason, { reason = it.take(500) }, label = { Text("دلیل برگشت") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching { ReversePayslipCommandV2(payslip.id, day, reason, commandId).validated() }
                .onSuccess(onReverse)
                .onFailure { error = it.message }
        }) { Text("برگشت کنترل‌شده") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PaymentReversalDialog(
    paymentId: Long,
    onDismiss: () -> Unit,
    onReverse: (ReversePayrollPaymentCommand) -> Unit,
) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var reason by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val commandId = remember { GlobalId.new().value }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("برگشت پرداخت #$paymentId") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { MessageCard(it, true) }
            PersianDateField("تاریخ برگشت", day) { day = it }
            OutlinedTextField(reason, { reason = it.take(500) }, label = { Text("دلیل") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching { ReversePayrollPaymentCommand(paymentId, day, reason, commandId).validated() }
                .onSuccess(onReverse)
                .onFailure { error = it.message }
        }) { Text("ثبت تراکنش جبرانی") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

private fun parseClock(value: String): Int {
    val parts = value.trim().split(':')
    require(parts.size == 2) { "قالب ساعت باید HH:mm باشد." }
    val hour = parts[0].toInt()
    val minute = parts[1].toInt()
    require(hour in 0..23 && minute in 0..59) { "ساعت معتبر نیست." }
    return hour * 60 + minute
}
