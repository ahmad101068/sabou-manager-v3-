#!/usr/bin/env python3
"""Host-side regression gate for the non-destructive schema 30 -> 31 migration.

This runs the static SQL from MIGRATION_30_31 against SQLite, derives the archive
table list from production source, and proves that legacy rows remain readable.
It complements (but does not replace) the Android Room migration test.
"""

from __future__ import annotations

import pathlib
import re
import sqlite3
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT / "app/src/main/java/ir/sabou/inventory/data/db/migration/OperationsMigrations.kt"


def fail(message: str) -> None:
    print(f"RETIRED_OPERATIONS_MIGRATION_FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


source = SOURCE.read_text(encoding="utf-8")
start = source.index("internal val MIGRATION_30_31")
end = source.index("private fun preserveRetiredOperationalTable", start)
migration = source[start:end]

table_block = re.search(
    r"listOf\((.*?)\)\.forEach\s*\{\s*table\s*->\s*preserveRetiredOperationalTable",
    migration,
    re.DOTALL,
)
if table_block is None:
    fail("production archive table list was not found")
tables = re.findall(r'"([a-z0-9_]+)"', table_block.group(1))
expected = {
    "customers", "sales", "sale_lines", "sale_payments", "loyalty_transactions",
    "customer_followups", "approval_requests", "restaurant_tables", "reservations",
    "kitchen_tickets", "cash_shifts", "table_orders", "table_order_lines",
    "bill_splits", "bill_split_lines",
}
if set(tables) != expected or len(tables) != len(expected):
    fail(f"archive list mismatch: {tables}")

raw_sql = re.findall(r'db\.execSQL\(\s*"""(.*?)"""\s*,?\s*\)', migration, re.DOTALL)
quoted_sql = re.findall(r'db\.execSQL\("([^"\n]+)"\)', migration)
sql_statements = [statement.strip() for statement in raw_sql + quoted_sql]
if len(sql_statements) < 8:
    fail(f"too few production SQL statements extracted: {len(sql_statements)}")
if any(re.search(r"\bDROP\s+TABLE\b", statement, re.IGNORECASE) for statement in sql_statements):
    fail("MIGRATION_30_31 still executes DROP TABLE")
if any(re.search(r"\bDELETE\s+FROM\s+(?:app_alerts|sync_changes)\b", statement, re.IGNORECASE) for statement in sql_statements):
    fail("MIGRATION_30_31 still deletes legacy alert or sync evidence")

connection = sqlite3.connect(":memory:")
connection.execute("PRAGMA foreign_keys=ON")
connection.execute(
    """CREATE TABLE sales (
        id INTEGER PRIMARY KEY, saleEpochDay INTEGER NOT NULL, subtotalRial INTEGER NOT NULL,
        discountRial INTEGER NOT NULL, deliveryRial INTEGER NOT NULL, totalRial INTEGER NOT NULL,
        paymentMethod TEXT, paidRial INTEGER NOT NULL, reversedAtEpochDay INTEGER,
        createdAtEpochMillis INTEGER NOT NULL, marker TEXT NOT NULL
    )"""
)
connection.execute(
    """CREATE TABLE sale_lines (
        id INTEGER PRIMARY KEY, saleId INTEGER NOT NULL, menuItemId INTEGER,
        productNameSnapshot TEXT NOT NULL, quantityMicros INTEGER NOT NULL,
        lineTotalRial INTEGER NOT NULL, costOfGoodsRial INTEGER NOT NULL, marker TEXT NOT NULL
    )"""
)
connection.execute("CREATE TABLE journal_entries (id INTEGER PRIMARY KEY, description TEXT NOT NULL, sourceType TEXT NOT NULL)")
connection.execute(
    """CREATE TABLE app_alerts (
        id INTEGER PRIMARY KEY, sourceType TEXT NOT NULL, isRead INTEGER NOT NULL,
        isDismissed INTEGER NOT NULL, createdAtEpochMillis INTEGER NOT NULL,
        updatedAtEpochMillis INTEGER NOT NULL
    )"""
)
connection.execute(
    "CREATE TABLE sync_changes (id INTEGER PRIMARY KEY, entityType TEXT NOT NULL, state TEXT NOT NULL, lastError TEXT NOT NULL)"
)
for table in tables:
    if table not in {"sales", "sale_lines"}:
        connection.execute(f"CREATE TABLE {table} (id INTEGER PRIMARY KEY, marker TEXT NOT NULL)")
        connection.execute(f"INSERT INTO {table}(id,marker) VALUES(1,?)", (f"evidence:{table}",))

connection.execute(
    "INSERT INTO sales VALUES(1,20000,100000,10000,5000,95000,'نقدی',95000,NULL,1234,'active-sale')"
)
connection.execute(
    "INSERT INTO sales VALUES(2,20000,50000,0,0,50000,'نقدی',50000,20001,1235,'reversed-sale')"
)
connection.execute(
    "INSERT INTO sale_lines VALUES(1,1,7,'کباب تست',2000000,100000,40000,'active-line')"
)
connection.execute("INSERT INTO journal_entries VALUES(1,'فروش قدیمی','SALE')")
connection.execute("INSERT INTO app_alerts VALUES(1,'CRM_FOLLOW_UP',0,0,900,800)")
connection.execute("INSERT INTO sync_changes VALUES(1,'CUSTOMER','PENDING','')")

try:
    with connection:
        for statement in sql_statements:
            connection.execute(statement)
        for table in tables:
            connection.execute(f"ALTER TABLE {table} RENAME TO legacy_v30_{table}")
except sqlite3.Error as error:
    fail(f"production SQL could not migrate the fixture: {error}")

for table in tables:
    archived = f"legacy_v30_{table}"
    if connection.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=?", (archived,)).fetchone()[0] != 1:
        fail(f"missing archive table {archived}")
    count = connection.execute(f"SELECT COUNT(*) FROM {archived}").fetchone()[0]
    if count < 1:
        fail(f"archive table {archived} lost all rows")

if connection.execute("SELECT COUNT(*),SUM(totalRial) FROM legacy_v30_sales").fetchone() != (2, 145000):
    fail("legacy invoice totals changed")
if connection.execute("SELECT marker FROM legacy_v30_sale_lines").fetchone()[0] != "active-line":
    fail("legacy sale-line evidence changed")
summary = connection.execute(
    "SELECT grossSalesRial,discountRial,serviceRial,netSalesRial,cashRial,theoreticalCostRial FROM daily_sales_summaries"
).fetchone()
if summary != (100000, 10000, 5000, 95000, 95000, 40000):
    fail(f"active-sale summary mismatch: {summary}")
if connection.execute("SELECT isRead,isDismissed,updatedAtEpochMillis FROM app_alerts").fetchone() != (1, 1, 900):
    fail("legacy alert was not retained and dismissed")
sync_state, sync_error = connection.execute("SELECT state,lastError FROM sync_changes").fetchone()
if sync_state != "REJECTED" or "preserved" not in sync_error:
    fail("legacy sync envelope was not retained and quarantined")
if connection.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
    fail("PRAGMA integrity_check failed")
if connection.execute("PRAGMA foreign_key_check").fetchall():
    fail("PRAGMA foreign_key_check found violations")

print(
    "RETIRED_OPERATIONS_MIGRATION_PASS "
    f"tables={len(tables)} rows_preserved={sum(connection.execute(f'SELECT COUNT(*) FROM legacy_v30_{t}').fetchone()[0] for t in tables)} "
    f"sql_statements={len(sql_statements)} integrity=ok foreign_keys=ok"
)
