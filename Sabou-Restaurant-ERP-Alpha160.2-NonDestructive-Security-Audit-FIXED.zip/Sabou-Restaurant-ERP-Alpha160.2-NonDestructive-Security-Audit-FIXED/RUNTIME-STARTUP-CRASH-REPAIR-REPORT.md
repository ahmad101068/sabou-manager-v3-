# Runtime startup crash repair

## Evidence

The device bugreport records an uncaught `AuthenticationRequiredException` on the main thread from
`SessionAuthorizer.actorIdentity(SessionAuthorizer.kt:24)`. The exception occurs immediately after
the login screen appears.

## Root cause

`SabouApp` created and subscribed to every protected feature ViewModel before checking
`SecurityUiState.currentUser`. On application initialization, `AppContainer` intentionally clears
`app_session`, so a protected startup collector could reach `SessionAuthorizer` without an
authenticated actor. The authorizer correctly failed closed, but the uncaught coroutine exception
terminated `MainActivity`.

## Repair

- `SecurityViewModel` is now the only ViewModel created before authentication.
- The unauthenticated branch renders `SecurityScreen` directly and returns before any protected
  repository or ViewModel is observed.
- After login creates a valid session, Compose enters the authenticated branch and creates the
  protected feature ViewModels.
- `SessionAuthorizer`, database constraints, repositories, and authorization rules were not
  weakened or bypassed.
- `UnauthenticatedStartupIntegrationTest` keeps `MainActivity` alive for three seconds after entry,
  covering the delayed Flow/Compose startup window in which the reported crash occurred.

## Changed files

- `app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt`
- `app/src/androidTest/java/ir/sabou/inventory/UnauthenticatedStartupIntegrationTest.kt`

## Verification status

Static review and ZIP integrity verification completed. Local Gradle compilation could not start
because the environment could not download `gradle-8.13-bin.zip` from `services.gradle.org`.
Consequently, compilation and emulator execution remain unverified here and must be run by the
repository's GitHub Actions runtime gates before releasing the APK.
