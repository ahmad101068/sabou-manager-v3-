package ir.sabou.inventory.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DailySalesDao {
    @Query("SELECT EXISTS(SELECT 1 FROM daily_sales_summaries WHERE businessEpochDay = :epochDay)")
    suspend fun dayExists(epochDay: Long): Boolean

    @Insert
    suspend fun insertSummary(entity: DailySalesSummaryEntity): Long

    @Insert
    suspend fun insertLines(entities: List<DailySalesMenuLineEntity>)

    @Query("UPDATE daily_sales_summaries SET journalEntryId = :journalEntryId, costJournalEntryId = :costJournalEntryId WHERE id = :summaryId")
    suspend fun linkJournals(summaryId: Long, journalEntryId: Long, costJournalEntryId: Long?): Int

    @Query(
        """
        SELECT * FROM daily_sales_summaries
        WHERE (:query = '' OR CAST(businessEpochDay AS TEXT) LIKE '%' || :query || '%' OR notes LIKE '%' || :query || '%')
        ORDER BY businessEpochDay DESC, id DESC
        """,
    )
    fun observeSummaries(query: String): Flow<List<DailySalesSummaryEntity>>

    @Query(
        """
        SELECT * FROM daily_sales_summaries
        WHERE businessEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        ORDER BY businessEpochDay DESC, id DESC
        """,
    )
    fun observeRange(fromEpochDay: Long, toEpochDay: Long): Flow<List<DailySalesSummaryEntity>>

    @Query(
        """
        SELECT l.menuItemId, l.menuItemNameSnapshot AS name,
               CAST(COALESCE(SUM(l.quantityMicros), 0) / 1000000 AS INTEGER) AS unitsSold,
               COALESCE(SUM(l.grossSalesRial), 0) AS salesRial,
               COALESCE(SUM(l.theoreticalCostRial), 0) AS costRial
        FROM daily_sales_menu_lines l
        INNER JOIN daily_sales_summaries s ON s.id = l.summaryId
        WHERE s.businessEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        GROUP BY l.menuItemId, l.menuItemNameSnapshot
        ORDER BY COALESCE(SUM(l.grossSalesRial), 0) DESC, l.menuItemNameSnapshot
        """,
    )
    fun observeMenuPerformance(fromEpochDay: Long, toEpochDay: Long): Flow<List<DailyMenuPerformanceRow>>
}

data class DailyMenuPerformanceRow(
    val menuItemId: Long?,
    val name: String,
    val unitsSold: Long,
    val salesRial: Long,
    val costRial: Long,
)
