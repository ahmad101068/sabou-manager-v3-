package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "employees",
    indices = [
        Index(value = ["nationalId"], unique = true),
        Index(value = ["employeeCode"], unique = true),
        Index("branchName"),
        Index("status"),
    ],
)
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val employeeCode: String? = null,
    val jobTitle: String,
    val branchName: String = "",
    val phone: String = "",
    val nationalId: String? = null,
    val birthEpochDay: Long? = null,
    val hireEpochDay: Long? = null,
    val insuranceNumber: String? = null,
    val bankCard: String? = null,
    val address: String = "",
    val emergencyContact: String = "",
    val monthlySalaryRial: Long,
    val leaveBalanceMicros: Long,
    val status: String = "ACTIVE",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["employeeId", "workEpochDay"], unique = true),
        Index("workEpochDay"),
    ],
)
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val workEpochDay: Long,
    val status: String,
    val checkInMinute: Int?,
    val checkOutMinute: Int?,
    val lateMinutes: Int,
    val overtimeMinutes: Int,
    val notes: String,
)

@Entity(
    tableName = "leaves",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("employeeId"), Index("startEpochDay"), Index("endEpochDay")],
)
data class LeaveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val daysMicros: Long,
    val leaveType: String,
    val status: String,
    val notes: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)


@Entity(
    tableName = "payroll_runs",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["employeeId", "periodYear", "periodMonth"], unique = true),
        Index("paymentEpochDay"),
        Index("journalEntryId"),
    ],
)
data class PayrollRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val periodYear: Int,
    val periodMonth: Int,
    val baseSalaryRial: Long,
    val overtimeRial: Long,
    val bonusRial: Long,
    val deductionsRial: Long,
    val insuranceRial: Long,
    val taxRial: Long,
    val netPayRial: Long,
    val paymentEpochDay: Long,
    val paymentMethod: String,
    val journalEntryId: Long,
    val status: String = "PAID",
    val notes: String = "",
    val createdAtEpochMillis: Long,
)


@Entity(
    tableName = "employee_contracts",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("employeeId"),
        Index("startEpochDay"),
        Index("endEpochDay"),
        Index("status"),
    ],
)
data class EmployeeContractEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val contractType: String,
    val startEpochDay: Long,
    val endEpochDay: Long?,
    val baseSalaryRial: Long,
    val dailyWorkMinutes: Int,
    val weeklyWorkDays: Int,
    val status: String = "ACTIVE",
    val notes: String = "",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "employee_advances",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("employeeId"),
        Index("advanceEpochDay"),
        Index("journalEntryId"),
        Index("status"),
    ],
)
data class EmployeeAdvanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val amountRial: Long,
    val advanceEpochDay: Long,
    val paymentMethod: String,
    val journalEntryId: Long,
    val settledAmountRial: Long = 0,
    val status: String = "OPEN",
    val notes: String = "",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
