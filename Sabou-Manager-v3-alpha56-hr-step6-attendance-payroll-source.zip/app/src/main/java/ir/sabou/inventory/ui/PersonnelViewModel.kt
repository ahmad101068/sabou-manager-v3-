package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollCalculation
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

data class PersonnelUiState(val employees: List<EmployeeRecord> = emptyList(), val payrolls: List<PayrollRecord> = emptyList(), val attendance: List<AttendanceRecord> = emptyList(), val payrollPreview: PayrollCalculation? = null, val attendanceSummary: AttendanceSummary? = null, val message: String? = null)

class PersonnelViewModel(private val repository: PersonnelRepository) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    private val payrollPreview = MutableStateFlow<PayrollCalculation?>(null)
    private val attendanceSummary = MutableStateFlow<AttendanceSummary?>(null)
    private val coreState = combine(repository.employees, repository.payrolls, repository.attendance) { e, p, a -> Triple(e, p, a) }
    private val transientState = combine(payrollPreview, attendanceSummary, message) { preview, summary, m -> Triple(preview, summary, m) }
    val state: StateFlow<PersonnelUiState> = combine(coreState, transientState) { core, transient ->
        PersonnelUiState(core.first, core.second, core.third, transient.first, transient.second, transient.third)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersonnelUiState())

    fun saveEmployee(id: Long?, draft: EmployeeDraft) = launch("پرسنل ذخیره شد.") { repository.saveEmployee(id, draft) }
    fun deactivate(id: Long) = launch("پرسنل غیرفعال شد.") { repository.deactivateEmployee(id) }
    fun saveAttendance(id: Long?, draft: AttendanceDraft) = launch("حضور و غیاب ذخیره شد.") { repository.saveAttendance(id, draft) }
    fun approveLeave(draft: LeaveDraft) = launch("مرخصی تأیید شد.") { repository.approveLeave(draft) }
    fun loadAttendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long) = viewModelScope.launch {
        runCatching { repository.attendanceSummary(employeeId, startEpochDay, endEpochDay) }
            .onSuccess { attendanceSummary.value = it }
            .onFailure { message.value = it.message ?: "خطا در گزارش حضور" }
    }
    fun saveContract(id: Long?, draft: EmployeeContractDraft) = launch("قرارداد ذخیره شد.") { repository.saveContract(id, draft) }
    fun postAdvance(draft: EmployeeAdvanceDraft) = launch("مساعده ثبت و سند حسابداری صادر شد.") { repository.postAdvance(draft) }
    fun settleAdvance(id: Long, amountRial: Long) = launch("تسویه مساعده ثبت شد.") { repository.settleAdvance(id, amountRial) }
    fun calculatePayroll(draft: PayrollDraft) = viewModelScope.launch {
        runCatching { repository.calculatePayroll(draft) }
            .onSuccess { payrollPreview.value = it; message.value = "محاسبه حقوق انجام شد." }
            .onFailure { message.value = it.message ?: "خطا در محاسبه حقوق" }
    }
    fun postPayroll(draft: PayrollDraft) = launch("حقوق ثبت و سند حسابداری صادر شد.") { repository.postPayroll(draft); payrollPreview.value = null }
    fun clearMessage() { message.value = null }
    private fun launch(success: String, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }.onSuccess { message.value = success }.onFailure { message.value = it.message ?: "خطا" }
    }
    companion object { fun factory(repo: PersonnelRepository) = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = PersonnelViewModel(repo) as T
    } }
}
