package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryCountRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodCloseDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodReopenDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureDetails
import ir.sabou.inventory.domain.operations.InventoryUsageInsight
import ir.sabou.inventory.domain.operations.AuditLogRecord
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.SensitiveAction
import ir.sabou.inventory.domain.operations.PurchaseSummary
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.SupplierRecord
import ir.sabou.inventory.domain.operations.SupplierPriceInsight
import ir.sabou.inventory.domain.operations.WasteDraft
import ir.sabou.inventory.domain.operations.WasteRecord
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.PurchaseDetails
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseRepository
import ir.sabou.inventory.domain.purchase.PurchaseReversalDraft
import ir.sabou.inventory.domain.purchase.PurchaseSettlementDraft
import ir.sabou.inventory.domain.purchase.PurchaseSettlementReversalDraft
import ir.sabou.inventory.domain.purchase.ProcurementOverview
import ir.sabou.inventory.domain.purchase.ProcurementRepository
import ir.sabou.inventory.domain.purchase.PurchaseRequisitionDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderDraft
import ir.sabou.inventory.domain.purchase.GoodsReceiptDraft
import ir.sabou.inventory.domain.purchase.PurchaseReturnDraft
import ir.sabou.inventory.domain.purchase.ReplenishmentPolicyDraft
import ir.sabou.inventory.domain.purchase.SupplierOfferDraft
import ir.sabou.inventory.domain.purchase.SplitPurchaseOrdersDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderAcknowledgementDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderDispatchChannel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class OperationsUiState(
    val suppliers: List<SupplierRecord> = emptyList(),
    val inventoryItems: List<InventoryItemRecord> = emptyList(),
    val lowStockItems: List<InventoryItemRecord> = emptyList(),
    val inventoryCounts: List<InventoryCountRecord> = emptyList(),
    val inventoryPeriodClosures: List<InventoryPeriodClosureRecord> = emptyList(),
    val selectedInventoryClosureDetails: InventoryPeriodClosureDetails? = null,
    val auditLogs: List<AuditLogRecord> = emptyList(),
    val usageInsights: List<InventoryUsageInsight> = emptyList(),
    val supplierPriceInsights: List<SupplierPriceInsight> = emptyList(),
    val wasteRecords: List<WasteRecord> = emptyList(),
    val purchases: List<PurchaseSummary> = emptyList(),
    val settlementAlerts: List<PurchaseSummary> = emptyList(),
    val procurement: ProcurementOverview = ProcurementOverview(),
    val selectedPurchase: PurchaseDetails? = null,
    val purchaseSearch: String = "",
    val busy: Boolean = false,
    val message: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class OperationsViewModel(
    private val operationsRepository: OperationsRepository,
    private val purchaseRepository: PurchaseRepository,
    private val procurementRepository: ProcurementRepository,
    private val securityRepository: SecurityRepository,
) : ViewModel() {
    private val purchaseSearch = MutableStateFlow("")
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val selectedPurchaseId = MutableStateFlow<Long?>(null)
    private val selectedInventoryClosureId = MutableStateFlow<Long?>(null)
    private val todayEpochDay = currentEpochDay()

    private val inventoryContent = combine(
        operationsRepository.suppliers,
        operationsRepository.inventoryItems,
        operationsRepository.lowStockItems,
        operationsRepository.inventoryCounts,
        operationsRepository.auditLogs,
    ) { suppliers, items, lowStock, counts, logs ->
        OperationsUiState(
            suppliers = suppliers, inventoryItems = items, lowStockItems = lowStock,
            inventoryCounts = counts, auditLogs = logs,
        )
    }

    private val intelligentInventoryContent = combine(
        inventoryContent,
        operationsRepository.usageInsights,
        operationsRepository.supplierPriceInsights,
        operationsRepository.wasteRecords,
        operationsRepository.inventoryPeriodClosures,
    ) { base, usage, prices, wastes, closures ->
        base.copy(
            usageInsights = usage,
            supplierPriceInsights = prices,
            wasteRecords = wastes,
            inventoryPeriodClosures = closures,
        )
    }

    private val content = combine(
        intelligentInventoryContent,
        purchaseSearch.debounce(250).distinctUntilChanged().flatMapLatest(operationsRepository::purchases),
        operationsRepository.purchases(""),
    ) { base, purchases, allPurchases ->
        base.copy(
            purchases = purchases,
            settlementAlerts = allPurchases.filter { it.reminderIsDue(todayEpochDay) },
            purchaseSearch = purchaseSearch.value,
        )
    }

    private val selectedPurchase = selectedPurchaseId.flatMapLatest { purchaseId ->
        if (purchaseId == null) flowOf(null) else purchaseRepository.details(purchaseId)
    }

    private val selectedInventoryClosure = selectedInventoryClosureId.flatMapLatest { closureId ->
        if (closureId == null) flowOf(null) else operationsRepository.inventoryPeriodClosureDetails(closureId)
    }

    private data class SelectedContent(
        val base: OperationsUiState,
        val purchase: PurchaseDetails?,
        val inventoryClosure: InventoryPeriodClosureDetails?,
    )

    private val selectedContent = combine(content, selectedPurchase, selectedInventoryClosure) { base, purchase, closure ->
        SelectedContent(base, purchase, closure)
    }

    val state: StateFlow<OperationsUiState> = combine(
        selectedContent,
        busy,
        message,
        procurementRepository.overview,
    ) { selected, isBusy, currentMessage, procurement ->
        selected.base.copy(
            busy = isBusy,
            message = currentMessage,
            selectedPurchase = selected.purchase,
            selectedInventoryClosureDetails = selected.inventoryClosure,
            procurement = procurement,
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = OperationsUiState(),
    )

    fun searchPurchases(value: String) {
        purchaseSearch.value = value
    }

    fun selectPurchase(purchaseId: Long?) {
        selectedPurchaseId.value = purchaseId
    }

    fun selectInventoryClosure(closureId: Long?) {
        selectedInventoryClosureId.value = closureId
    }

    fun clearMessage() {
        message.value = null
    }

    fun saveSupplier(id: Long?, draft: SupplierDraft, onSuccess: () -> Unit) {
        runAction(
            successMessage = if (id == null) "تأمین‌کننده ثبت شد." else "تأمین‌کننده ویرایش شد.",
            onSuccess = onSuccess,
        ) {
            if (id == null) operationsRepository.createSupplier(draft)
            else operationsRepository.updateSupplier(id, draft)
        }
    }

    fun deactivateSupplier(id: Long) {
        runAction("تأمین‌کننده غیرفعال شد.") {
            operationsRepository.deactivateSupplier(id)
        }
    }

    fun saveInventoryItem(id: Long?, draft: InventoryItemDraft, onSuccess: () -> Unit) {
        runAction(
            successMessage = if (id == null) "کالا ثبت شد." else "کالا ویرایش شد.",
            onSuccess = onSuccess,
        ) {
            if (id == null) operationsRepository.createInventoryItem(draft)
            else operationsRepository.updateInventoryItem(id, draft)
        }
    }

    fun postInventoryCount(draft: InventoryCountDraft, onSuccess: () -> Unit = {}) {
        runAction("انبارگردانی ثبت و موجودی اصلاح شد.", onSuccess) { operationsRepository.postInventoryCount(draft) }
    }

    fun closeInventoryPeriod(draft: InventoryPeriodCloseDraft, pin: String, onSuccess: () -> Unit = {}) {
        runAction("دوره انبار بسته و دفتر گردش آن قفل شد.", onSuccess) {
            securityRepository.authorizeSensitiveAction(SensitiveAction.CLOSE_INVENTORY_PERIOD, pin)
            operationsRepository.closeInventoryPeriod(draft)
        }
    }

    fun reopenInventoryPeriod(closureId: Long, reason: String, pin: String, onSuccess: () -> Unit = {}) {
        runAction("دوره انبار بازگشایی شد؛ پس از اصلاح، آن را دوباره ببندید.", onSuccess) {
            securityRepository.authorizeSensitiveAction(SensitiveAction.REOPEN_INVENTORY_PERIOD, pin)
            operationsRepository.reopenInventoryPeriod(InventoryPeriodReopenDraft(closureId, reason))
        }
    }

    fun postWaste(draft: WasteDraft, onSuccess: () -> Unit = {}) {
        runAction("ضایعات ثبت شد و انبار و حسابداری به‌روزرسانی شدند.", onSuccess) {
            operationsRepository.postWaste(draft)
        }
    }

    fun deactivateInventoryItem(id: Long) {
        runAction("کالا غیرفعال شد.") {
            operationsRepository.deactivateInventoryItem(id)
        }
    }

    fun postPurchase(draft: PurchaseDraft, onSuccess: (PostedPurchase) -> Unit) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                val result = purchaseRepository.post(draft)
                message.value = "فاکتور خرید ثبت شد و موجودی و حسابداری به‌روزرسانی شدند."
                onSuccess(result)
            } catch (error: Exception) {
                message.value = error.message ?: "ثبت فاکتور خرید انجام نشد."
            } finally {
                busy.value = false
            }
        }
    }

    fun submitRequisition(draft: PurchaseRequisitionDraft, onSuccess: () -> Unit = {}) {
        runAction("درخواست خرید برای تأیید ارسال شد.", onSuccess) {
            procurementRepository.submitRequisition(draft)
        }
    }

    fun reviewRequisition(requisitionId: Long, approve: Boolean) {
        runAction(if (approve) "درخواست خرید تأیید شد." else "درخواست خرید رد شد.") {
            procurementRepository.reviewRequisition(requisitionId, approve)
        }
    }

    fun createPurchaseOrder(draft: PurchaseOrderDraft, onSuccess: () -> Unit = {}) {
        runAction("سفارش خرید از درخواست تأییدشده ساخته شد.", onSuccess) {
            procurementRepository.createOrder(draft)
        }
    }

    fun createSplitPurchaseOrders(draft: SplitPurchaseOrdersDraft, onSuccess: () -> Unit = {}) {
        runAction("سفارش‌های خرید به تفکیک تأمین‌کننده ایجاد شدند.", onSuccess) {
            procurementRepository.createSplitOrders(draft)
        }
    }

    fun markPurchaseOrderSent(orderId: Long, channel: PurchaseOrderDispatchChannel) {
        runAction("ارسال سفارش خرید ثبت شد.") { procurementRepository.markOrderSent(orderId, channel) }
    }

    fun acknowledgePurchaseOrder(draft: PurchaseOrderAcknowledgementDraft, onSuccess: () -> Unit = {}) {
        runAction("تأیید تأمین‌کننده و موعد قطعی تحویل ثبت شد.", onSuccess) {
            procurementRepository.acknowledgeOrder(draft)
        }
    }

    fun postGoodsReceipt(draft: GoodsReceiptDraft, onSuccess: () -> Unit = {}) {
        runAction("رسید کالا ثبت شد؛ فقط مقدار پذیرفته‌شده به موجودی اضافه شد.", onSuccess) {
            procurementRepository.postGoodsReceipt(draft)
        }
    }

    fun postPurchaseReturn(draft: PurchaseReturnDraft, onSuccess: () -> Unit = {}) {
        runAction("مرجوعی خرید ثبت شد؛ موجودی، بدهی/اعتبار تأمین‌کننده و حسابداری اصلاح شدند.", onSuccess) {
            procurementRepository.postPurchaseReturn(draft)
        }
    }

    fun saveReplenishmentPolicy(draft: ReplenishmentPolicyDraft, onSuccess: () -> Unit = {}) {
        runAction("سیاست تأمین کالا ذخیره و پیشنهاد سفارش به‌روزرسانی شد.", onSuccess) {
            procurementRepository.saveReplenishmentPolicy(draft)
        }
    }

    fun saveSupplierOffer(draft: SupplierOfferDraft, onSuccess: () -> Unit = {}) {
        runAction("پیشنهاد تأمین‌کننده ذخیره و مقایسه قیمت به‌روزرسانی شد.", onSuccess) {
            procurementRepository.saveSupplierOffer(draft)
        }
    }

    fun submitSuggestedRequisition(itemIds: List<Long>, onSuccess: () -> Unit = {}) {
        runAction("پیشنهادهای تأمین به درخواست خرید قابل تأیید تبدیل شدند.", onSuccess) {
            procurementRepository.submitSuggestedRequisition(itemIds)
        }
    }

    fun postMatchedInvoice(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
        approvePriceVariance: Boolean,
        onSuccess: () -> Unit = {},
    ) {
        runAction("فاکتور با سفارش و رسید تطبیق و ثبت مالی شد.", onSuccess) {
            procurementRepository.postMatchedInvoice(purchaseOrderId, invoice, approvePriceVariance)
        }
    }

    fun settlePurchase(draft: PurchaseSettlementDraft, onSuccess: () -> Unit = {}) {
        runAction("تسویه ثبت شد و مانده تأمین‌کننده و سند حسابداری به‌روزرسانی شدند.", onSuccess) {
            purchaseRepository.settle(draft)
        }
    }

    fun reversePurchaseSettlement(draft: PurchaseSettlementReversalDraft, onSuccess: () -> Unit = {}) {
        runAction("تسویه برگشت خورد و مانده فاکتور با سند معکوس اصلاح شد.", onSuccess) {
            purchaseRepository.reverseSettlement(draft)
        }
    }

    fun reversePurchase(draft: PurchaseReversalDraft, onSuccess: () -> Unit = {}) {
        runAction("فاکتور برگشت خورد و موجودی و حسابداری با سند معکوس اصلاح شدند.", onSuccess) {
            purchaseRepository.reverse(draft)
        }
    }

    private fun runAction(
        successMessage: String,
        onSuccess: () -> Unit = {},
        block: suspend () -> Unit,
    ) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                block()
                message.value = successMessage
                onSuccess()
            } catch (error: Exception) {
                message.value = error.message ?: "عملیات انجام نشد."
            } finally {
                busy.value = false
            }
        }
    }

    companion object {
        fun factory(
            operationsRepository: OperationsRepository,
            purchaseRepository: PurchaseRepository,
            procurementRepository: ProcurementRepository,
            securityRepository: SecurityRepository,
        ): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                OperationsViewModel(operationsRepository, purchaseRepository, procurementRepository, securityRepository) as T
        }
    }
}
