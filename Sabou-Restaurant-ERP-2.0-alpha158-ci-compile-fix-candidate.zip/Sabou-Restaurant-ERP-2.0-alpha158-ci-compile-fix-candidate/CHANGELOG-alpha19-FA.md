# تغییرات 3.0.0-alpha19-dev

- اضافه‌شدن نصب‌کننده مستقل Android SDK برای ویندوز
- نصب SDK 36، Build Tools 36.0.0 و Platform Tools در پوشه محلی پروژه
- کنترل SHA-256 ابزارهای رسمی پیش از استخراج
- تشخیص خودکار JDK 17 از Android Studio، Temurin یا Oracle JDK
- ساخت Debug APK و اجرای تست‌ها با دوبارکلیک
- ساخت Release APK با اطلاعات امضا از متغیرهای محیطی
- ابزار ساخت Keystore بدون ذخیره رمز داخل سورس
- Workflow ساخت خودکار Debug APK در GitHub Actions
- بارگذاری APK و گزارش تست به‌عنوان Artifact
- راهنمای فارسی کامل ساخت بدون Android Studio
- ارتقای versionCode به 45

- رفع خطاهای کامپایل گزارش‌شده در GitHub Actions: SecurityRepository، RecipeViewModel، RecipeScreens و FABهای Material3.
