# وضعیت فعلی پروژه

آخرین نسخه: `3.0.0-alpha157.0-data-boundary-split`

`versionCode: 200` · `Room schema: 42` · تاریخ گزارش: 2026-08-09

## نتیجه این Increment

- `Daos.kt` با ۱٬۷۱۲ خط حذف و ۱۲ DAO به فایل‌های domain-owned منتقل شد؛ بزرگ‌ترین فایل
  حاصل ۴۴۲ خط است.
- parity کامل ۱۲ DAO، ۱۷۲ Query، ۳۹ Insert، ۱۲ Update، دو Transaction، ۲۳ read row و ۱۷
  accessor پایگاه داده کنترل شد.
- Entity، SQL، Repository contract، Schema 42 و Migration chain در این Split تغییر نکردند.
- Journal قطعی فقط از Accounting Posting Boundary ساخته می‌شود، متوازن است و در سطح DB
  update/delete نمی‌شود؛ اصلاح با reversal انجام می‌شود.
- Stock Movement به‌صورت append-only و traceable ثبت می‌شود و Projection موجودی با CAS در
  همان Transaction تغییر می‌کند.
- شمارش، ضایعات، انتقال لات، دریافت/خروج و برگشت‌های حساس idempotency/correlation/actor/
  location دارند.
- ضایعات به‌صورت اتمیک Document، Lot، Projection، Movement، Journal و Audit را ثبت می‌کند.
- Audit ساخت‌یافته، append-only و بخشی از Transaction است.
- Permissionها type-safe، نقش ناشناخته fail-closed و SoD خرید/حقوق فعال شده است.
- Performance جدید از مقدار canonical نوع `Long micros` استفاده می‌کند؛ ستون `REAL` فقط
  برای سازگاری Legacy باقی است.
- Migration `41→42` و Full Migration `1→current` بدون destructive fallback تعریف شده‌اند.

## کنترل کیفیت انجام‌شده

- `scripts/verify-foundation.sh`: موفق
- `git diff --check`: موفق
- Parse نحوی ۱۲ فایل Kotlin منتقل‌شده با tree-sitter: بدون خطا
- ۱۶۴ تست واحد و ۶۱ تست Instrumentation در سورس شناسایی شد؛ تست‌های جدید critical path
  شامل rollback، idempotency، immutability، closed period و Migration هستند.

## کنترل کیفیت انجام‌نشده در این محیط

Gradle 8.13 و Android SDK در محیط اجرای این بازآرایی موجود نبود و دانلود distribution نیز
در دسترس نبود. در نتیجه `testDebugUnitTest`، KSP/Room schema validation، Lint، Debug/Release
Build و Instrumentation اجرا نشده‌اند. Workflow گیت‌هاب این Gateها را اجرا می‌کند و قبل از
Merge باید سبز باشد.

## گیت انتشار عمومی

1. CI کامل روی API 23 و API 35 سبز شود.
2. Schema 42 تولیدشده Room بررسی و Commit شود.
3. Migration روی کپی واقعی Schema 41 و Full Chain بررسی شود.
4. Restore فایل رمزگذاری‌شده روی دستگاه دوم و نصب تازه روی گوشی واقعی آزموده شود.
5. سناریوهای هم‌زمان Retry، دوره بسته، self-approval و کمبود موجودی روی DB واقعی اجرا شوند.

## قابلیت‌های تکمیل‌نشده

POS/KDS سفارش‌محور، Production/WIP، Treasury مستقل، Sync دوطرفه و conflict resolution
چندشعبه‌ای هنوز Production-ready نیستند. God DAO تفکیک شده است؛ `AppDatabase`،
`LocalProcurementRepository`، `OperationsScreens` و `SabouApp` همچنان در Roadmap Split
تدریجی قرار دارند.
