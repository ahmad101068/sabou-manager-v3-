#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAIN_PACKAGE="$PROJECT_ROOT/app/src/main/java/ir/sabou/inventory"

fail() {
  echo "ERP 2.0 foundation verification failed: $*" >&2
  exit 1
}

require_file() {
  test -s "$PROJECT_ROOT/$1" || fail "missing $1"
}

require_literal() {
  local needle="$1"
  local file="$2"
  rg -Fq "$needle" "$PROJECT_ROOT/$file" || fail "missing '$needle' in $file"
}

required_files=(
  "app/src/main/java/ir/sabou/inventory/core/MoneyRial.kt"
  "app/src/main/java/ir/sabou/inventory/core/QuantityMicros.kt"
  "app/src/main/java/ir/sabou/inventory/core/FixedPointRatio.kt"
  "app/src/main/java/ir/sabou/inventory/core/GlobalId.kt"
  "app/src/main/java/ir/sabou/inventory/core/CorrelationId.kt"
  "app/src/main/java/ir/sabou/inventory/domain/common/BusinessError.kt"
  "app/src/main/java/ir/sabou/inventory/domain/accounting/AccountingPosting.kt"
  "app/src/main/java/ir/sabou/inventory/domain/treasury/TreasuryModels.kt"
  "app/src/main/java/ir/sabou/inventory/domain/security/AuthorizationService.kt"
  "app/src/main/java/ir/sabou/inventory/domain/audit/AuditService.kt"
  "app/src/main/java/ir/sabou/inventory/domain/security/Permission.kt"
  "app/src/main/java/ir/sabou/inventory/domain/security/SegregationOfDuties.kt"
  "app/src/main/java/ir/sabou/inventory/domain/inventory/InventoryLedgerModels.kt"
  "app/src/main/java/ir/sabou/inventory/domain/audit/AuditEvent.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/InventoryCommandEntities.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/InventoryLedgerDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/SupplierDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/InventoryDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/PurchaseDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/ProcurementDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/AccountingDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/PersonnelDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/RecipeDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/InventoryControlDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/AuditLogDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/SecurityDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/AssetDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/AlertDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/EnterpriseLedgerGuards.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/migration/AppMigrations.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/migration/LegacyMigrations.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/migration/OperationsMigrations.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/migration/EnterpriseMigrations.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/migration/DatabaseIntegrityLifecycle.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/migration/DatabaseSeedCallback.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalAuditEventWriter.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryCommandEngine.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalAccountingPostingEngine.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/ProcurementReceivingService.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/ProcurementInvoiceMatchingService.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/db/EnterpriseLedgerMigration41To42Test.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/db/FullMigration1ToCurrentTest.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/repository/InventoryLedgerIntegrationTest.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/repository/AccountingPostingIntegrationTest.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/repository/GoodsReceiptTransactionIntegrationTest.kt"
  "app/src/test/java/ir/sabou/inventory/core/FixedPointRatioTest.kt"
  "app/src/test/java/ir/sabou/inventory/core/GlobalIdTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/security/SegregationOfDutiesTest.kt"
  "app/src/test/java/ir/sabou/inventory/data/db/MigrationRegistryTest.kt"
  "app/src/test/java/ir/sabou/inventory/data/repository/GoodsReceiptIdempotencyTest.kt"
  "docs/ERP2-AUDIT-IMPACT-MAP-FA.md"
  "docs/ERP2-TARGET-ARCHITECTURE-FA.md"
  "docs/ERP2-MIGRATION-41-42-FA.md"
  "docs/ERP2-TECHNICAL-REPORT-FA.md"
  "docs/ERP2-REMAINING-ROADMAP-FA.md"
  "docs/ERP2-ALPHA157-DATA-BOUNDARY-IMPACT-MAP-FA.md"
  "docs/ERP2-ALPHA157-DATA-BOUNDARY-REPORT-FA.md"
  "docs/ARCHITECTURE-FOUNDATION-STATUS.md"
  "docs/DOMAIN-BOUNDARIES.md"
  "docs/TRANSACTION-INTEGRITY-MATRIX.md"
  "docs/TYPED-STATE-INVENTORY.md"
  "docs/FOUNDATION-VERIFICATION-REPORT.md"
  "CHANGELOG-alpha157-FA.md"
  "CHANGELOG-alpha158-FA.md"
)

for relative in "${required_files[@]}"; do
  require_file "$relative"
done

schema_version="$(sed -nE 's/^internal const val APP_DATABASE_SCHEMA_VERSION = ([0-9]+)$/\1/p' "$MAIN_PACKAGE/data/db/AppDatabase.kt")"
[[ "$schema_version" =~ ^[1-9][0-9]*$ ]] || fail "database schema version must be a positive single-source constant"
require_literal "MIGRATION_$((schema_version - 1))_${schema_version}" "app/src/main/java/ir/sabou/inventory/data/db/migration/AppMigrations.kt"
require_literal 'version = APP_DATABASE_SCHEMA_VERSION' "app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'versionCode = [1-9][0-9]*' "$PROJECT_ROOT/app/build.gradle.kts" || fail "versionCode is missing"
rg -q 'versionName = "[^"]+"' "$PROJECT_ROOT/app/build.gradle.kts" || fail "versionName is missing"
require_literal 'SupportOpenHelperFactory' "app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
require_literal 'android:allowBackup="false"' "app/src/main/AndroidManifest.xml"
require_literal 'android:usesCleartextTraffic="false"' "app/src/main/AndroidManifest.xml"

require_literal 'database.withTransaction' "app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryCommandEngine.kt"
require_literal 'database.withTransaction' "app/src/main/java/ir/sabou/inventory/data/repository/LocalAccountingPostingEngine.kt"
require_literal 'BusinessError.InsufficientStock' "app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryCommandEngine.kt"
require_literal 'IdempotencyConflict' "app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryCommandEngine.kt"
require_literal 'idempotencyKey' "app/src/main/java/ir/sabou/inventory/data/db/AccountingEntities.kt"
require_literal 'reversalOfEntryId' "app/src/main/java/ir/sabou/inventory/data/db/AccountingEntities.kt"
require_literal 'compareAndSetValuation' "app/src/main/java/ir/sabou/inventory/data/db/InventoryDao.kt"
require_literal 'installPostedJournalGuards' "app/src/main/java/ir/sabou/inventory/data/db/EnterpriseLedgerGuards.kt"
require_literal 'installStockMovementGuards' "app/src/main/java/ir/sabou/inventory/data/db/EnterpriseLedgerGuards.kt"
require_literal 'installInventoryCountGuards' "app/src/main/java/ir/sabou/inventory/data/db/EnterpriseLedgerGuards.kt"
require_literal 'installAuditLogGuards' "app/src/main/java/ir/sabou/inventory/data/db/migration/DatabaseIntegrityLifecycle.kt"
require_literal 'seedSystemLocations' "app/src/main/java/ir/sabou/inventory/data/db/migration/DatabaseSeedCallback.kt"
require_literal 'SegregationOfDuties.requireDifferentActors' "app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
require_literal 'SegregationOfDuties.requireDifferentLegacyAware' "app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt"
require_literal 'Permission.INVENTORY_ADJUST' "app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
require_literal 'SensitiveAction.ADJUST_INVENTORY' "app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
require_literal 'countByIdempotencyKey' "app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
require_literal 'wasteDocumentByIdempotencyKey' "app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
require_literal 'activeSummaryByDay' "app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt"
require_literal 'payrollByGlobalId' "app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
require_literal 'commandCorrelation()' "app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
require_literal 'postExistingDraft' "app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
require_literal 'UiErrorHandler.message' "app/src/main/java/ir/sabou/inventory/ui/OperationsViewModel.kt"
require_literal 'connectedDebugAndroidTest' ".github/workflows/build-apk.yml"
require_literal 'api-level: 23' ".github/workflows/build-apk.yml"
require_literal 'api-level: 35' ".github/workflows/build-apk.yml"

if rg -n 'fallbackToDestructiveMigration' "$PROJECT_ROOT/app/src/main"; then
  fail "destructive Room migration fallback is forbidden"
fi

if rg -n '\bGlobalScope\b' "$PROJECT_ROOT/app/src/main"; then
  fail "GlobalScope is forbidden"
fi

if rg -n '\b[A-Za-z][A-Za-z0-9]*Dao\(\)' "$MAIN_PACKAGE/ui" -g '*.kt'; then
  fail "Compose/UI code must not call a DAO directly"
fi

if rg -n '(accountingDao|journalDao)\(|postDraftEntry\(|insertEntry\(' "$MAIN_PACKAGE/ui" -g '*.kt'; then
  fail "UI code must not mutate the journal ledger"
fi

if rg -n '^import ir\.sabou\.inventory\.ui\.|ir\.sabou\.inventory\.ui\.' "$MAIN_PACKAGE/domain" -g '*.kt'; then
  fail "domain code must not depend on presentation"
fi

if test -e "$MAIN_PACKAGE/data/db/Daos.kt"; then
  fail "God DAO file Daos.kt must remain split by owner domain"
fi

mapfile -t dao_types < <(
  sed -nE 's/^    abstract fun [A-Za-z0-9_]+Dao\(\): ([A-Za-z0-9_]+)$/\1/p' \
    "$MAIN_PACKAGE/data/db/AppDatabase.kt"
)
[[ "${#dao_types[@]}" -gt 0 ]] || fail "AppDatabase has no DAO accessors"
for dao_type in "${dao_types[@]}"; do
  declaration_count="$(rg -n "^interface ${dao_type}\\b" "$MAIN_PACKAGE/data/db" -g '*.kt' | wc -l)"
  [[ "$declaration_count" -eq 1 ]] || fail "$dao_type must have exactly one declaration"
done

app_database_accessor_count="$(rg -n '^    abstract fun .*Dao\(\):' "$MAIN_PACKAGE/data/db/AppDatabase.kt" | wc -l)"
dao_annotation_count="$(rg -n '^@Dao$' "$MAIN_PACKAGE/data/db" -g '*.kt' | wc -l)"
[[ "$app_database_accessor_count" -eq "${#dao_types[@]}" ]] || fail "AppDatabase DAO accessor parsing is inconsistent"
[[ "$dao_annotation_count" -eq "$app_database_accessor_count" ]] || fail "DAO declarations and AppDatabase accessors differ"

if rg -n 'authorizer\.(require|allows)\("[A-Z_]+"' "$PROJECT_ROOT/app/src/main"; then
  fail "stringly typed authorization reached a command boundary"
fi

if rg -n 'return@withTransaction' \
  "$MAIN_PACKAGE/data/repository/LocalInventoryCommandEngine.kt" \
  "$MAIN_PACKAGE/data/repository/LocalAccountingPostingEngine.kt"; then
  fail "transaction wrapper uses an out-of-scope Room label"
fi

if rg -n 'DELETE FROM (journal_entries|journal_lines|stock_movements|audit_logs)' "$PROJECT_ROOT/app/src/main"; then
  fail "direct deletion of immutable ledgers is forbidden"
fi

if rg -n '\b(Double|Float)\b' "$MAIN_PACKAGE/core" "$MAIN_PACKAGE/domain"; then
  fail "floating-point type reached the core/domain model"
fi

mapfile -t stock_projection_writers < <(
  rg -l 'compareAndSetValuation\(' "$MAIN_PACKAGE" -g '*.kt' | sort
)
expected_stock_projection_writers=(
  "$MAIN_PACKAGE/data/db/InventoryDao.kt"
  "$MAIN_PACKAGE/data/repository/LocalInventoryCommandEngine.kt"
)
if [[ "${stock_projection_writers[*]}" != "${expected_stock_projection_writers[*]}" ]]; then
  printf 'Unexpected inventory projection writer:\n%s\n' "${stock_projection_writers[*]}" >&2
  fail "inventory projection writes must pass through LocalInventoryCommandEngine"
fi

mapfile -t migration_edges < <(
  rg -o 'Migration\([0-9]+, *[0-9]+\)' "$MAIN_PACKAGE/data/db/migration" -g '*.kt' \
    | sed -E 's/.*Migration\(([0-9]+), *([0-9]+)\)/\1-\2/' \
    | sort -V
)
[[ "${#migration_edges[@]}" -eq "$((schema_version - 1))" ]] ||
  fail "migration edge count must match the complete 1..$schema_version chain"
duplicate_migration_edges="$(printf '%s\n' "${migration_edges[@]}" | uniq -d)"
[[ -z "$duplicate_migration_edges" ]] || fail "duplicate migration edge: $duplicate_migration_edges"
for ((version = 1; version < schema_version; version++)); do
  expected_edge="$version-$((version + 1))"
  printf '%s\n' "${migration_edges[@]}" | rg -Fxq "$expected_edge" ||
    fail "missing migration edge $expected_edge"
done

if rg -n 'suspend fun post\(draft: SemanticJournalDraft\)' \
  "$MAIN_PACKAGE/data/repository/LocalAccountingPostingEngine.kt"; then
  fail "accounting posting requires an explicit actor/idempotency/correlation context"
fi

mapfile -t direct_draft_posters < <(
  rg -l 'postDraftEntry\(' "$MAIN_PACKAGE/data/repository" | sort
)
expected_draft_posters=(
  "$MAIN_PACKAGE/data/repository/LocalAccountingPostingEngine.kt"
)
if [[ "${direct_draft_posters[*]}" != "${expected_draft_posters[*]}" ]]; then
  printf 'Unexpected direct draft posting boundary:\n%s\n' "${direct_draft_posters[*]}" >&2
  fail "posted journals must pass through LocalAccountingPostingEngine"
fi

mapfile -t audit_entity_files < <(rg -l 'AuditLogEntity\(' "$PROJECT_ROOT/app/src/main" | sort)
expected_audit_files=(
  "$MAIN_PACKAGE/data/db/ControlEntities.kt"
  "$MAIN_PACKAGE/data/repository/LocalAuditEventWriter.kt"
)
if [[ "${audit_entity_files[*]}" != "${expected_audit_files[*]}" ]]; then
  printf 'Unexpected direct AuditLogEntity usage:\n%s\n' "${audit_entity_files[*]}" >&2
  fail "audit events must pass through LocalAuditEventWriter"
fi

if test -d "$PROJECT_ROOT/.git"; then
  git -C "$PROJECT_ROOT" diff --check
fi

echo "Sabou ERP 2.0 foundation architecture static checks passed."
