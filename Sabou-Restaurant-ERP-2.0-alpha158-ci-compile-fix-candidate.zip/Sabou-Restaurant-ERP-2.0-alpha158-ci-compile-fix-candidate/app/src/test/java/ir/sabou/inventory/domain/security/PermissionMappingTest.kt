package ir.sabou.inventory.domain.security

import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class PermissionMappingTest {
    @Test
    fun unknownLegacyRoleGetsNoPermissions() {
        val role = UserRole.fromStoredValue("future-admin-role")
        assertTrue(role == UserRole.LEGACY_RESTRICTED)
        Permission.entries.forEach { permission -> assertFalse(role.allows(permission)) }
    }

    @Test
    fun accountantCannotManageUsersOrAdjustInventory() {
        assertTrue(UserRole.ACCOUNTANT.allows(Permission.ACCOUNTING))
        assertFalse(UserRole.ACCOUNTANT.allows(Permission.MANAGE_USERS))
        assertFalse(UserRole.ACCOUNTANT.allows(Permission.INVENTORY_ADJUST))
    }
}
