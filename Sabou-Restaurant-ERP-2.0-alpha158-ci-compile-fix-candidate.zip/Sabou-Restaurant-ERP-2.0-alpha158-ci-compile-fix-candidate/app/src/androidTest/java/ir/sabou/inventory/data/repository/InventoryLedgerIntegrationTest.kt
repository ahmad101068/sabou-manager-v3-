package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AccountingPeriodLockEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryLotEntity
import ir.sabou.inventory.data.db.InventoryPeriodClosureEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.data.security.SensitiveActionGate
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.BusinessRuleViolation
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReasonCode
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.SensitiveAction
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import ir.sabou.inventory.domain.operations.WasteDraft
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class InventoryLedgerIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var engine: LocalInventoryCommandEngine

    @Before
    fun setUp() {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        engine = LocalInventoryCommandEngine(database, clock = { NOW })
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun receiveIsIdempotentAndLedgerIsAppendOnly() = runBlocking {
        val itemId = insertItem("برنج")
        val context = command("purchase:77:item:$itemId", 77)

        val first = engine.receive(
            itemId = itemId,
            quantityMicros = 2_000_000,
            valueRial = 400_000,
            movementType = InventoryMovementType.PURCHASE,
            referenceType = InventoryReferenceType.PURCHASE,
            referenceId = 77,
            movementEpochDay = 100,
            context = context,
        )
        val replay = engine.receive(
            itemId = itemId,
            quantityMicros = 2_000_000,
            valueRial = 400_000,
            movementType = InventoryMovementType.PURCHASE,
            referenceType = InventoryReferenceType.PURCHASE,
            referenceId = 77,
            movementEpochDay = 100,
            context = context,
        )

        assertFalse(first.idempotentReplay)
        assertTrue(replay.idempotentReplay)
        assertEquals(first.movementId, replay.movementId)
        assertEquals(2_000_000L, database.inventoryDao().byId(itemId)?.stockMicros)
        assertEquals(400_000L, database.inventoryDao().byId(itemId)?.inventoryValueRial)
        assertEquals(1, database.stockMovementDao().observeForItem(itemId).first().size)

        try {
            engine.receive(
                itemId = itemId,
                quantityMicros = 2_000_000,
                valueRial = 500_000,
                movementType = InventoryMovementType.PURCHASE,
                referenceType = InventoryReferenceType.PURCHASE,
                referenceId = 77,
                movementEpochDay = 100,
                context = context,
            )
            fail("payload متفاوت نباید با همان idempotency key پذیرفته شود")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.IdempotencyConflict)
        }

        try {
            database.openHelper.writableDatabase.execSQL(
                "UPDATE stock_movements SET notes='tampered' WHERE id=${first.movementId}",
            )
            fail("گردش موجودی ثبت‌شده نباید ویرایش شود")
        } catch (_: Exception) {
            Unit
        }
    }

    @Test
    fun closedPeriodFailureRollsBackProjectionAndLedger() = runBlocking {
        val itemId = insertItem("روغن")
        database.inventoryControlDao().insertClosure(
            InventoryPeriodClosureEntity(
                fromEpochDay = 200,
                toEpochDay = 210,
                openingValueRial = 0,
                netPurchaseValueRial = 0,
                recordedOutflowValueRial = 0,
                expectedClosingValueRial = 0,
                countedClosingValueRial = 0,
                varianceValueRial = 0,
                itemCount = 1,
                closedBy = "tester",
                note = "integration test",
                createdAtEpochMillis = NOW,
            ),
        )

        try {
            engine.receive(
                itemId = itemId,
                quantityMicros = 1_000_000,
                valueRial = 150_000,
                movementType = InventoryMovementType.PURCHASE,
                referenceType = InventoryReferenceType.PURCHASE,
                referenceId = 88,
                movementEpochDay = 205,
                context = command("purchase:88:item:$itemId", 88),
            )
            fail("دوره بسته باید کل فرمان را rollback کند")
        } catch (_: Exception) {
            Unit
        }

        val item = requireNotNull(database.inventoryDao().byId(itemId))
        assertEquals(0L, item.stockMicros)
        assertEquals(0L, item.inventoryValueRial)
        assertTrue(database.stockMovementDao().observeForItem(itemId).first().isEmpty())
    }

    @Test
    fun wasteDocumentRetryReturnsOriginalResultWithoutDuplicateEffects() = runBlocking {
        val gate = SensitiveActionGate(clockMillis = { NOW })
        signInOwner(gate)
        val repository = operationsRepository(gate)
        val itemId = insertItem("خامه", stockMicros = 2_000_000, inventoryValueRial = 400_000)
        val locationId = requireNotNull(database.managementControlDao().defaultLocationId())
        database.managementControlDao().insertLot(
            InventoryLotEntity(
                itemId = itemId,
                locationId = locationId,
                lotCode = "LOT-WASTE-1",
                receivedEpochDay = 90,
                expiryEpochDay = 120,
                quantityMicros = 2_000_000,
                unitCostRial = 200_000,
                barcode = null,
                updatedAtEpochMillis = NOW,
            ),
        )
        val draft = WasteDraft(
            itemId = itemId,
            quantityMicros = 500_000,
            wasteEpochDay = 100,
            reason = "فساد مواد",
            notes = "کنترل دما",
            commandId = "123e4567-e89b-42d3-a456-426614174000",
        )

        val firstId = repository.postWaste(draft)
        val replayId = repository.postWaste(draft)

        assertEquals(firstId, replayId)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM inventory_waste_documents"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM stock_movements WHERE movementType='WASTE'"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM journal_entries WHERE sourceType='WASTE'"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM audit_logs WHERE action='WASTE'"))
        assertEquals(1_500_000L, database.inventoryDao().byId(itemId)?.stockMicros)
        assertEquals(300_000L, database.inventoryDao().byId(itemId)?.inventoryValueRial)
    }

    @Test
    fun inventoryCountRetryIsIdempotentAfterFreshSensitiveAuthorization() = runBlocking {
        val gate = SensitiveActionGate(clockMillis = { NOW })
        val security = signInOwner(gate)
        val repository = operationsRepository(gate)
        val itemId = insertItem("برنج شمارش", stockMicros = 1_000_000, inventoryValueRial = 100_000)
        val draft = InventoryCountDraft(
            itemId = itemId,
            countedQuantityMicros = 800_000,
            countedValueRial = 80_000,
            countEpochDay = 100,
            reason = "شمارش فیزیکی پایان شیفت",
            commandId = "123e4567-e89b-42d3-a456-426614174001",
        )

        security.authorizeSensitiveAction(SensitiveAction.ADJUST_INVENTORY, "123456")
        val firstId = repository.postInventoryCount(draft)
        security.authorizeSensitiveAction(SensitiveAction.ADJUST_INVENTORY, "123456")
        val replayId = repository.postInventoryCount(draft)

        assertEquals(firstId, replayId)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM inventory_counts"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM stock_movements WHERE movementType='INVENTORY_COUNT'"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM audit_logs WHERE action='INVENTORY_COUNT'"))
        assertEquals(800_000L, database.inventoryDao().byId(itemId)?.stockMicros)
        assertEquals(80_000L, database.inventoryDao().byId(itemId)?.inventoryValueRial)
    }

    @Test
    fun wasteRollsBackDocumentLotProjectionAndMovementWhenAccountingPeriodIsClosed() = runBlocking {
        val gate = SensitiveActionGate(clockMillis = { NOW })
        signInOwner(gate)
        val repository = operationsRepository(gate)
        val itemId = insertItem("شیر", stockMicros = 2_000_000, inventoryValueRial = 400_000)
        val locationId = requireNotNull(database.managementControlDao().defaultLocationId())
        val lotId = database.managementControlDao().insertLot(
            InventoryLotEntity(
                itemId = itemId,
                locationId = locationId,
                lotCode = "LOT-ROLLBACK-1",
                receivedEpochDay = 90,
                expiryEpochDay = 120,
                quantityMicros = 2_000_000,
                unitCostRial = 200_000,
                barcode = null,
                updatedAtEpochMillis = NOW,
            ),
        )
        database.managementControlDao().insertAccountingPeriodLock(
            AccountingPeriodLockEntity(
                fromEpochDay = 100,
                toEpochDay = 100,
                reason = "آزمون rollback",
                closedBy = "owner",
                closedAtEpochMillis = NOW,
            ),
        )

        try {
            repository.postWaste(
                WasteDraft(
                    itemId = itemId,
                    quantityMicros = 500_000,
                    wasteEpochDay = 100,
                    reason = "فساد مواد",
                    commandId = "123e4567-e89b-42d3-a456-426614174002",
                ),
            )
            fail("بسته‌بودن دوره مالی باید تمام عملیات ضایعات را rollback کند")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.ClosedAccountingPeriod)
        }

        assertEquals(0L, scalar("SELECT COUNT(*) FROM inventory_waste_documents"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM stock_movements WHERE movementType='WASTE'"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM journal_entries WHERE sourceType='WASTE'"))
        assertEquals(2_000_000L, database.inventoryDao().byId(itemId)?.stockMicros)
        assertEquals(400_000L, database.inventoryDao().byId(itemId)?.inventoryValueRial)
        assertEquals(2_000_000L, database.managementControlDao().lot(lotId)?.quantityMicros)
    }

    private suspend fun insertItem(
        name: String,
        stockMicros: Long = 0,
        inventoryValueRial: Long = 0,
    ): Long = database.inventoryDao().insert(
        InventoryItemEntity(
            name = name,
            category = "مواد اولیه",
            unit = "کیلوگرم",
            stockMicros = stockMicros,
            inventoryValueRial = inventoryValueRial,
            createdAtEpochMillis = NOW,
            updatedAtEpochMillis = NOW,
        ),
    )

    private suspend fun signInOwner(gate: SensitiveActionGate): LocalSecurityRepository {
        val authorizer = SessionAuthorizer(database)
        return LocalSecurityRepository(
            db = database,
            clock = { NOW },
            authorizer = authorizer,
            sensitiveActionGate = gate,
        ).also { repository ->
            repository.save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER, "87654321"))
        }
    }

    private fun operationsRepository(gate: SensitiveActionGate) = LocalOperationsRepository(
        database = database,
        clock = { NOW },
        authorizer = SessionAuthorizer(database),
        sensitiveActionGate = gate,
    )

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        assertTrue(cursor.moveToFirst())
        cursor.getLong(0)
    }

    private fun command(key: String, referenceId: Long) = InventoryCommandContext(
        idempotencyKey = key,
        correlationId = "integration:inventory:$referenceId",
        actorId = 42,
        deviceId = "instrumentation",
        locationId = null,
        reasonCode = InventoryReasonCode.PURCHASE_RECEIPT,
        reason = "تست دریافت خرید",
    )

    private companion object {
        const val NOW = 1_800_000_000_000L
    }
}
