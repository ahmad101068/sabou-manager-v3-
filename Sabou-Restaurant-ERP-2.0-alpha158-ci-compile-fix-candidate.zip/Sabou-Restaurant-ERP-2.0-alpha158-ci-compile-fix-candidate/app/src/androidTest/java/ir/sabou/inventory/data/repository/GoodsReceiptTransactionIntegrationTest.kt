package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AccountingPeriodLockEntity
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.PurchaseOrderEntity
import ir.sabou.inventory.data.db.PurchaseOrderLineEntity
import ir.sabou.inventory.data.db.PurchaseRequisitionEntity
import ir.sabou.inventory.data.db.SupplierEntity
import ir.sabou.inventory.data.security.SensitiveActionGate
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.BusinessRuleViolation
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import ir.sabou.inventory.domain.purchase.GoodsReceiptDraft
import ir.sabou.inventory.domain.purchase.GoodsReceiptLineDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderStatus
import ir.sabou.inventory.domain.purchase.RequisitionStatus
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class GoodsReceiptTransactionIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var repository: LocalProcurementRepository
    private var orderId: Long = 0
    private var orderLineId: Long = 0
    private var itemId: Long = 0

    @Before
    fun setUp() = runBlocking {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        val authorizer = SessionAuthorizer(database)
        LocalSecurityRepository(
            db = database,
            clock = { NOW },
            authorizer = authorizer,
            sensitiveActionGate = SensitiveActionGate(clockMillis = { NOW }),
        ).save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER, "87654321"))
        repository = LocalProcurementRepository(database, authorizer, clock = { NOW })
        seedOpenOrder()
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun exactReplayReturnsOriginalReceiptWithoutDuplicateEffects() = runBlocking {
        val draft = receiptDraft()

        val firstId = repository.postGoodsReceipt(draft)
        val replayId = repository.postGoodsReceipt(draft)

        assertEquals(firstId, replayId)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM goods_receipts"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM stock_movements WHERE referenceType='GOODS_RECEIPT'"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM journal_entries WHERE sourceType='GOODS_RECEIPT'"))
        assertEquals(1L, scalar("SELECT COUNT(*) FROM audit_logs WHERE entityType='GOODS_RECEIPT' AND action='RECEIVE'"))
        assertEquals(1_000_000L, database.inventoryDao().byId(itemId)?.stockMicros)

        try {
            repository.postGoodsReceipt(draft.copy(note = "payload changed"))
            fail("the same delivery-note key with a different payload must be rejected")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.IdempotencyConflict)
        }
    }

    @Test
    fun accountingFailureRollsBackReceiptInventoryProjectionAndMovement() = runBlocking {
        database.managementControlDao().insertAccountingPeriodLock(
            AccountingPeriodLockEntity(
                fromEpochDay = RECEIPT_DAY,
                toEpochDay = RECEIPT_DAY,
                reason = "integration rollback",
                closedBy = "owner",
                closedAtEpochMillis = NOW,
            ),
        )

        try {
            repository.postGoodsReceipt(receiptDraft())
            fail("a closed accounting period must roll back the complete receipt")
        } catch (error: BusinessRuleViolation) {
            assertTrue(error.error is BusinessError.ClosedAccountingPeriod)
        }

        assertEquals(0L, scalar("SELECT COUNT(*) FROM goods_receipts"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM stock_movements WHERE referenceType='GOODS_RECEIPT'"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM journal_entries WHERE sourceType='GOODS_RECEIPT'"))
        assertEquals(0L, scalar("SELECT COUNT(*) FROM audit_logs WHERE entityType='GOODS_RECEIPT'"))
        assertEquals(0L, database.inventoryDao().byId(itemId)?.stockMicros)
        assertEquals(0L, database.procurementDao().orderLines(orderId).single().receivedQtyMicros)
        assertEquals(PurchaseOrderStatus.OPEN.name, database.procurementDao().orderById(orderId)?.status)
    }

    private suspend fun seedOpenOrder() {
        val supplierId = database.supplierDao().insert(
            SupplierEntity(
                name = "تأمین‌کننده تست",
                createdAtEpochMillis = NOW,
                updatedAtEpochMillis = NOW,
            ),
        )
        itemId = database.inventoryDao().insert(
            InventoryItemEntity(
                name = "برنج تست دریافت",
                category = "مواد اولیه",
                unit = "کیلوگرم",
                supplierId = supplierId,
                createdAtEpochMillis = NOW,
                updatedAtEpochMillis = NOW,
            ),
        )
        val requisitionId = database.procurementDao().insertRequisition(
            PurchaseRequisitionEntity(
                requestNo = "REQ-TEST-1",
                department = "آشپزخانه",
                requiredEpochDay = RECEIPT_DAY,
                status = RequisitionStatus.APPROVED.name,
                requestedBy = "مالک",
                approvedBy = "مالک",
                note = "integration fixture",
                createdAtEpochMillis = NOW,
                updatedAtEpochMillis = NOW,
            ),
        )
        orderId = database.procurementDao().insertOrder(
            PurchaseOrderEntity(
                orderNo = "PO-TEST-1",
                supplierId = supplierId,
                supplierNameSnapshot = "تأمین‌کننده تست",
                requisitionId = requisitionId,
                orderEpochDay = RECEIPT_DAY - 1,
                expectedEpochDay = RECEIPT_DAY,
                sentAtEpochMillis = NOW - 1,
                sentBy = "مالک",
                dispatchChannel = "HAND_DELIVERY",
                acknowledgedAtEpochMillis = NOW - 1,
                supplierConfirmationNo = "CONF-1",
                confirmedExpectedEpochDay = RECEIPT_DAY,
                status = PurchaseOrderStatus.OPEN.name,
                note = "integration fixture",
                createdBy = "مالک",
                createdAtEpochMillis = NOW,
                updatedAtEpochMillis = NOW,
            ),
        )
        database.procurementDao().insertOrderLines(
            listOf(
                PurchaseOrderLineEntity(
                    purchaseOrderId = orderId,
                    itemId = itemId,
                    itemNameSnapshot = "برنج تست دریافت",
                    supplierSkuSnapshot = null,
                    orderedQtyMicros = 1_000_000,
                    unitCostRial = 500_000,
                    receivedQtyMicros = 0,
                    rejectedQtyMicros = 0,
                ),
            ),
        )
        orderLineId = database.procurementDao().orderLines(orderId).single().id
    }

    private fun receiptDraft() = GoodsReceiptDraft(
        purchaseOrderId = orderId,
        receiptEpochDay = RECEIPT_DAY,
        deliveryNoteNo = "DN-TEST-1",
        note = "sealed delivery",
        lines = listOf(
            GoodsReceiptLineDraft(
                purchaseOrderLineId = orderLineId,
                deliveredQtyMicros = 1_000_000,
                acceptedQtyMicros = 1_000_000,
            ),
        ),
    )

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getLong(0)
    }

    private companion object {
        const val NOW = 1_800_000_000_000L
        const val RECEIPT_DAY = 20_000L
    }
}
