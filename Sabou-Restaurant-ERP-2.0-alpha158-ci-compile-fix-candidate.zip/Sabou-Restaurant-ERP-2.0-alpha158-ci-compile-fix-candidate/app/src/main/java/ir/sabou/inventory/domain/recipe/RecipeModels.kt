package ir.sabou.inventory.domain.recipe

import kotlinx.coroutines.flow.Flow

data class MenuItem(
    val id: Long,
    val name: String,
    val category: String,
    val salePriceRial: Long,
    val ingredientCount: Int = 0,
    val recipeRevisionNo: Int = 0,
    val recipeEffectiveFromEpochDay: Long = 0,
    val costProfile: RecipeCostProfile = RecipeCostProfile(),
)

data class RecipeCostProfile(
    val yieldMicros: Long = 1_000_000L,
    val portionWeightMicros: Long = 0,
    val preparationWasteBasisPoints: Int = 0,
    val cookingWasteBasisPoints: Int = 0,
    val packagingCostRial: Long = 0,
    val directLaborCostRial: Long = 0,
    val allocatedOverheadRial: Long = 0,
    val note: String = "",
) {
    fun validated(): RecipeCostProfile {
        require(yieldMicros > 0) { "بازده تولید باید بیشتر از صفر باشد." }
        require(portionWeightMicros >= 0) { "وزن استاندارد هر پرس نامعتبر است." }
        require(preparationWasteBasisPoints in 0..FullCostCalculator.MAX_WASTE_BASIS_POINTS) { "ضایعات آماده‌سازی نامعتبر است." }
        require(cookingWasteBasisPoints in 0..FullCostCalculator.MAX_WASTE_BASIS_POINTS) { "ضایعات پخت نامعتبر است." }
        require(listOf(packagingCostRial, directLaborCostRial, allocatedOverheadRial).all { it >= 0 }) { "اجزای بهای کامل نمی‌توانند منفی باشند." }
        return copy(note = note.trim())
    }
}

data class RecipeIngredientInput(
    val inventoryItemId: Long,
    val quantityMicrosPerUnit: Long,
)

data class RecipeIngredientItem(
    val inventoryItemId: Long,
    val inventoryName: String,
    val unit: String,
    val quantityMicrosPerUnit: Long,
)

data class RecipeRevision(
    val id: Long,
    val revisionNo: Int,
    val effectiveFromEpochDay: Long,
    val costProfile: RecipeCostProfile,
    val createdBy: String,
    val createdAtEpochMillis: Long,
)

interface RecipeRepository {
    suspend fun saveMenuItem(
        id: Long?,
        name: String,
        category: String,
        salePriceRial: Long,
        ingredients: List<RecipeIngredientInput>,
        costProfile: RecipeCostProfile = RecipeCostProfile(),
    ): Long

    fun observeMenuItems(): Flow<List<MenuItem>>
    fun observeIngredients(menuItemId: Long): Flow<List<RecipeIngredientItem>>
    fun observeRevisions(menuItemId: Long): Flow<List<RecipeRevision>>
}
