package ir.sabou.inventory.data.db

import androidx.sqlite.db.SupportSQLiteDatabase

/** Schema-42 append-only and posting invariants, shared by migrations and fresh databases. */
internal fun installAuditLogGuards(db: SupportSQLiteDatabase) {
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_audit_logs_validate_insert
        BEFORE INSERT ON audit_logs
        WHEN NEW.globalId = '' OR NEW.actorId IS NULL OR NEW.actorId <= 0
          OR NEW.deviceId = '' OR NEW.reason = '' OR NEW.correlationId = ''
          OR ((NEW.referenceType IS NULL) != (NEW.referenceId IS NULL))
        BEGIN SELECT RAISE(ABORT, 'INVALID_AUDIT_EVENT'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_update
        BEFORE UPDATE ON audit_logs
        BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_delete
        BEFORE DELETE ON audit_logs
        BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END""",
    )
}

internal fun installPostedJournalGuards(db: SupportSQLiteDatabase) {
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_journal_entries_draft_only_insert
        BEFORE INSERT ON journal_entries
        WHEN NEW.status != 'DRAFT'
          OR NEW.globalId = ''
          OR NEW.idempotencyKey IS NULL OR NEW.idempotencyKey = ''
          OR NEW.correlationId = ''
          OR NEW.postedAtEpochMillis IS NOT NULL
          OR NEW.postedByActorId IS NOT NULL
        BEGIN SELECT RAISE(ABORT, 'JOURNAL_MUST_START_AS_DRAFT'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_journal_entries_status_transition
        BEFORE UPDATE OF status ON journal_entries
        WHEN OLD.status != NEW.status
          AND NOT (OLD.status = 'DRAFT' AND NEW.status = 'POSTED')
        BEGIN SELECT RAISE(ABORT, 'INVALID_JOURNAL_STATUS_TRANSITION'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_journal_entries_validate_post
        BEFORE UPDATE OF status ON journal_entries
        WHEN OLD.status = 'DRAFT' AND NEW.status = 'POSTED' AND (
          NEW.postedAtEpochMillis IS NULL OR NEW.postedAtEpochMillis <= 0
          OR NEW.postedByActorId IS NULL OR NEW.postedByActorId <= 0
          OR (SELECT COUNT(*) FROM journal_lines WHERE entryId = OLD.id) < 2
          OR (SELECT COALESCE(SUM(debitRial), 0) FROM journal_lines WHERE entryId = OLD.id)
             != (SELECT COALESCE(SUM(creditRial), 0) FROM journal_lines WHERE entryId = OLD.id)
        )
        BEGIN SELECT RAISE(ABORT, 'INVALID_JOURNAL_POSTING'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_posted_journal_entries_no_update
        BEFORE UPDATE ON journal_entries
        WHEN OLD.status = 'POSTED'
        BEGIN SELECT RAISE(ABORT, 'POSTED_JOURNAL_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_posted_journal_entries_no_delete
        BEFORE DELETE ON journal_entries
        WHEN OLD.status = 'POSTED'
        BEGIN SELECT RAISE(ABORT, 'POSTED_JOURNAL_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_posted_journal_lines_no_insert
        BEFORE INSERT ON journal_lines
        WHEN EXISTS(SELECT 1 FROM journal_entries e WHERE e.id = NEW.entryId AND e.status = 'POSTED')
        BEGIN SELECT RAISE(ABORT, 'POSTED_JOURNAL_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_posted_journal_lines_no_update
        BEFORE UPDATE ON journal_lines
        WHEN EXISTS(SELECT 1 FROM journal_entries e WHERE e.id IN (OLD.entryId, NEW.entryId) AND e.status = 'POSTED')
        BEGIN SELECT RAISE(ABORT, 'POSTED_JOURNAL_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_posted_journal_lines_no_delete
        BEFORE DELETE ON journal_lines
        WHEN EXISTS(SELECT 1 FROM journal_entries e WHERE e.id = OLD.entryId AND e.status = 'POSTED')
        BEGIN SELECT RAISE(ABORT, 'POSTED_JOURNAL_IMMUTABLE'); END""",
    )
}

internal fun installStockMovementGuards(db: SupportSQLiteDatabase) {
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_movements_validate_insert
        BEFORE INSERT ON stock_movements
        WHEN NEW.globalId = ''
          OR NEW.idempotencyKey = ''
          OR NEW.correlationId = ''
          OR NEW.actorId IS NULL OR NEW.actorId <= 0
          OR NEW.deviceId = '' OR NEW.locationId IS NULL OR NEW.locationId <= 0
          OR NOT EXISTS(SELECT 1 FROM storage_locations location WHERE location.id = NEW.locationId AND location.isActive = 1)
          OR NEW.reasonCode = '' OR NEW.reasonCode IN ('LEGACY', 'LEGACY_BACKFILL')
          OR (NEW.quantityDeltaMicros = 0 AND NEW.valueDeltaRial = 0)
          OR NEW.unitCostRial < 0
        BEGIN SELECT RAISE(ABORT, 'INVALID_STOCK_MOVEMENT'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_movements_no_update
        BEFORE UPDATE ON stock_movements
        BEGIN SELECT RAISE(ABORT, 'STOCK_MOVEMENT_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_movements_no_delete
        BEFORE DELETE ON stock_movements
        BEGIN SELECT RAISE(ABORT, 'STOCK_MOVEMENT_IMMUTABLE'); END""",
    )
}

internal fun installInventoryCountGuards(db: SupportSQLiteDatabase) {
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_inventory_counts_validate_insert
        BEFORE INSERT ON inventory_counts
        WHEN NEW.globalId = '' OR NEW.idempotencyKey = '' OR NEW.correlationId = ''
          OR NEW.actorId IS NULL OR NEW.actorId <= 0 OR NEW.deviceId = ''
          OR NEW.locationId IS NULL OR NEW.locationId <= 0 OR NEW.reason = ''
          OR NEW.previousQuantityMicros < 0 OR NEW.countedQuantityMicros < 0
          OR NEW.previousValueRial < 0 OR NEW.countedValueRial < 0
          OR NOT EXISTS(SELECT 1 FROM storage_locations location WHERE location.id = NEW.locationId AND location.isActive = 1)
        BEGIN SELECT RAISE(ABORT, 'INVALID_INVENTORY_COUNT'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_inventory_counts_no_update
        BEFORE UPDATE ON inventory_counts
        BEGIN SELECT RAISE(ABORT, 'INVENTORY_COUNT_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_inventory_counts_no_delete
        BEFORE DELETE ON inventory_counts
        BEGIN SELECT RAISE(ABORT, 'INVENTORY_COUNT_IMMUTABLE'); END""",
    )
}

internal fun installWasteDocumentGuards(db: SupportSQLiteDatabase) {
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_inventory_waste_documents_validate_insert
        BEFORE INSERT ON inventory_waste_documents
        WHEN NEW.globalId = '' OR NEW.idempotencyKey = '' OR NEW.correlationId = ''
          OR NEW.quantityMicros <= 0 OR NEW.valueRial < 0 OR NEW.actorId <= 0
          OR NEW.deviceId = '' OR NEW.reason = ''
          OR NOT EXISTS(SELECT 1 FROM storage_locations location WHERE location.id = NEW.locationId AND location.isActive = 1)
        BEGIN SELECT RAISE(ABORT, 'INVALID_WASTE_DOCUMENT'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_inventory_waste_documents_no_update
        BEFORE UPDATE ON inventory_waste_documents
        BEGIN SELECT RAISE(ABORT, 'WASTE_DOCUMENT_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_inventory_waste_documents_no_delete
        BEFORE DELETE ON inventory_waste_documents
        BEGIN SELECT RAISE(ABORT, 'WASTE_DOCUMENT_IMMUTABLE'); END""",
    )
}

internal fun installStockTransferGuards(db: SupportSQLiteDatabase) {
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_transfers_validate_insert
        BEFORE INSERT ON stock_transfers
        WHEN NEW.globalId = '' OR NEW.idempotencyKey = '' OR NEW.correlationId = ''
          OR NEW.actorId IS NULL OR NEW.actorId <= 0 OR NEW.deviceId = ''
          OR NEW.sourceLocationId = NEW.destinationLocationId
        BEGIN SELECT RAISE(ABORT, 'INVALID_STOCK_TRANSFER'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_transfers_no_update
        BEFORE UPDATE ON stock_transfers
        BEGIN SELECT RAISE(ABORT, 'STOCK_TRANSFER_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_transfers_no_delete
        BEFORE DELETE ON stock_transfers
        BEGIN SELECT RAISE(ABORT, 'STOCK_TRANSFER_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_transfer_lines_validate_insert
        BEFORE INSERT ON stock_transfer_lines
        WHEN NEW.quantityMicros <= 0
          OR EXISTS(SELECT 1 FROM stock_transfer_lines line WHERE line.transferId = NEW.transferId)
        BEGIN SELECT RAISE(ABORT, 'INVALID_STOCK_TRANSFER_LINE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_transfer_lines_no_update
        BEFORE UPDATE ON stock_transfer_lines
        BEGIN SELECT RAISE(ABORT, 'STOCK_TRANSFER_IMMUTABLE'); END""",
    )
    db.execSQL(
        """CREATE TRIGGER IF NOT EXISTS trg_stock_transfer_lines_no_delete
        BEFORE DELETE ON stock_transfer_lines
        BEGIN SELECT RAISE(ABORT, 'STOCK_TRANSFER_IMMUTABLE'); END""",
    )
}
