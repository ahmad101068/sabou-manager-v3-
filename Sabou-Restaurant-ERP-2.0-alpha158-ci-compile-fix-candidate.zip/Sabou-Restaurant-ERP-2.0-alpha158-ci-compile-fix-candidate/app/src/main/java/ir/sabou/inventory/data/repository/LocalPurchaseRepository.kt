package ir.sabou.inventory.data.repository

import ir.sabou.inventory.domain.security.Permission

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.FixedPointRatio
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.PurchaseEntity
import ir.sabou.inventory.data.db.PurchaseLineEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.accounting.BalancedJournalDraft
import ir.sabou.inventory.domain.accounting.AccountingPostingContext
import ir.sabou.inventory.domain.accounting.JournalLineDraft
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.PostedPurchaseSettlement
import ir.sabou.inventory.domain.purchase.PurchaseCalculator
import ir.sabou.inventory.domain.purchase.PurchaseDetails
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseLineRecord
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod
import ir.sabou.inventory.domain.purchase.PurchasePaymentStatus
import ir.sabou.inventory.domain.purchase.PurchaseRepository
import ir.sabou.inventory.domain.purchase.PurchaseReversalDraft
import ir.sabou.inventory.domain.purchase.PurchaseSettlementDraft
import ir.sabou.inventory.domain.purchase.PurchaseSettlementReversalDraft
import ir.sabou.inventory.domain.purchase.PurchaseSettlementRecord
import ir.sabou.inventory.domain.purchase.SettlementPaymentMethod
import ir.sabou.inventory.domain.operations.UnitConversionFactor
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReasonCode
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class LocalPurchaseRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : PurchaseRepository {
    private val inventoryCommands = LocalInventoryCommandEngine(database, clock = clock)
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)
    private val auditWriter = LocalAuditEventWriter(database)
    override suspend fun post(draft: PurchaseDraft): PostedPurchase {
        val actor = authorizer.require(Permission.PURCHASES)
        val prepared = PurchaseCalculator.prepare(draft)
        val normalizedDraft = prepared.draft
        val preparedLines = prepared.lines
        val total = prepared.total
        val now = clock()

        return database.withTransaction {
            val supplier = database.supplierDao().activeById(normalizedDraft.supplierId)
                ?: error("تأمین‌کننده فعال پیدا نشد.")
            require(!database.purchaseDao().invoiceExists(normalizedDraft.invoiceNo)) {
                "شماره فاکتور خرید تکراری است."
            }

            val paid = normalizedDraft.paymentMethod != PurchasePaymentMethod.PAYABLE
            val purchaseId = database.purchaseDao().insert(
                PurchaseEntity(
                    invoiceNo = normalizedDraft.invoiceNo,
                    supplierId = supplier.id,
                    purchaseEpochDay = normalizedDraft.purchaseEpochDay,
                    dueEpochDay = normalizedDraft.dueEpochDay,
                    totalRial = total.value,
                    paidRial = if (paid) total.value else 0,
                    paymentStatus = if (paid) PurchasePaymentStatus.PAID.storedValue else PurchasePaymentStatus.UNPAID.storedValue,
                    paymentMethod = normalizedDraft.paymentMethod.storedValue,
                    reminderEnabled = !paid && normalizedDraft.reminderEnabled,
                    reminderEpochDay = if (!paid && normalizedDraft.reminderEnabled) normalizedDraft.reminderEpochDay else null,
                    createdAtEpochMillis = now,
                ),
            )

            val purchaseLines = preparedLines.map { line ->
                val item = database.inventoryDao().activeById(line.itemId)
                    ?: error("یکی از کالاهای خرید پیدا نشد.")
                val stockQuantityMicros = UnitConversionFactor(
                    item.purchaseToStockNumerator, item.purchaseToStockDenominator,
                ).toStockMicros(line.quantityMicros)
                inventoryCommands.receive(
                    itemId = item.id,
                    quantityMicros = stockQuantityMicros,
                    valueRial = line.total.value,
                    movementType = InventoryMovementType.PURCHASE,
                    referenceType = InventoryReferenceType.PURCHASE,
                    referenceId = purchaseId,
                    movementEpochDay = normalizedDraft.purchaseEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.PURCHASE,
                        referenceId = purchaseId,
                        suffix = "receive:${item.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.PURCHASE_RECEIPT,
                        reason = "ثبت فاکتور ${normalizedDraft.invoiceNo}",
                        correlationId = "purchase:$purchaseId",
                    ),
                    notes = normalizedDraft.invoiceNo,
                )
                PurchaseLineEntity(
                    purchaseId = purchaseId,
                    itemId = item.id,
                    itemNameSnapshot = item.name,
                    quantityMicros = stockQuantityMicros,
                    unitCostRial = FixedPointRatio.unitCostRial(line.total.value, stockQuantityMicros),
                    lineTotalRial = line.total.value,
                )
            }
            database.purchaseDao().insertLines(purchaseLines)

            val journalId = if (total > MoneyRial.ZERO) {
                LocalAccountingPostingEngine(database, clock = clock).post(
                    draft = SemanticJournalDraft(
                        entryNo = "خ-$purchaseId",
                        description = "خرید مواد اولیه از ${supplier.name}",
                        entryEpochDay = normalizedDraft.purchaseEpochDay,
                        sourceType = "PURCHASE",
                        sourceId = purchaseId,
                        lines = listOf(
                            SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, debit = total),
                            SemanticJournalLine(normalizedDraft.paymentMethod.settlementRole, credit = total),
                        ),
                    ),
                    context = AccountingPostingContext.local(
                        sourceType = "PURCHASE",
                        sourceId = purchaseId,
                        suffix = "post",
                        actorId = actor.id,
                        correlationId = "purchase:$purchaseId",
                    ),
                )
            } else {
                null
            }
            syncRecorder?.record("PURCHASE", purchaseId, "CREATE", now)
            audit("CREATE", purchaseId, "ثبت فاکتور ${normalizedDraft.invoiceNo} به مبلغ ${total.value} ریال؛ سند=${journalId ?: 0}", now)
            PostedPurchase(purchaseId, journalId, total)
        }
    }

    override fun details(purchaseId: Long): Flow<PurchaseDetails?> =
        combine(
            database.purchaseDao().observeHeader(purchaseId),
            database.purchaseDao().observeDetailLines(purchaseId),
            database.accountingDao().observePurchaseSettlements(purchaseId),
        ) { header, lines, settlements ->
            header?.let {
                PurchaseDetails(
                    id = it.purchaseId,
                    invoiceNo = it.invoiceNo,
                    supplierName = it.supplierName,
                    purchaseEpochDay = it.purchaseEpochDay,
                    dueEpochDay = it.dueEpochDay,
                    totalRial = it.totalRial,
                    paidRial = it.paidRial,
                    paymentStatus = PurchasePaymentStatus.fromStoredValue(it.paymentStatus),
                    paymentMethod = PurchasePaymentMethod.fromStored(it.paymentMethod),
                    reminderEnabled = it.reminderEnabled,
                    reminderEpochDay = it.reminderEpochDay,
                    lines = lines.map { line ->
                        PurchaseLineRecord(
                            itemId = line.itemId,
                            itemName = line.itemName,
                            unit = line.unit,
                            quantityMicros = line.quantityMicros,
                            unitCostRial = line.unitCostRial,
                            lineTotalRial = line.lineTotalRial,
                        )
                    },
                    settlements = settlements.map { settlement ->
                        PurchaseSettlementRecord(
                            journalEntryId = settlement.journalEntryId,
                            entryNo = settlement.entryNo,
                            settlementEpochDay = settlement.settlementEpochDay,
                            amountRial = settlement.amountRial,
                            paymentMethod = SettlementPaymentMethod.fromStoredValue(settlement.paymentMethod),
                            referenceNo = settlement.referenceNo,
                            notes = settlement.notes,
                            isReversed = settlement.isReversed,
                        )
                    },
                )
            }
        }

    override suspend fun settle(draft: PurchaseSettlementDraft): PostedPurchaseSettlement {
        val actor = authorizer.require(Permission.PAYMENT_APPROVE)
        val valid = draft.validated()
        return database.withTransaction {
            val purchase = database.purchaseDao().byId(valid.purchaseId)
                ?: error("فاکتور خرید پیدا نشد.")
            val journalDraft = BalancedJournalDraft(
                entryEpochDay = valid.settlementEpochDay,
                description = "تسویه فاکتور ${purchase.invoiceNo} با ${valid.paymentMethod.title}",
                sourceType = "PURCHASE_SETTLEMENT",
                sourceId = purchase.id,
                lines = listOf(
                    JournalLineDraft(
                        accountCode = ir.sabou.inventory.domain.accounting.SystemSemanticAccountResolver.codeFor(SemanticAccountRole.SUPPLIER_PAYABLE),
                        debit = valid.amount,
                        memo = valid.notes,
                    ),
                    JournalLineDraft(
                        accountCode = ir.sabou.inventory.domain.accounting.SystemSemanticAccountResolver.codeFor(valid.paymentMethod.settlementRole),
                        credit = valid.amount,
                        memo = valid.referenceNo,
                    ),
                ),
            )
            val postingContext = AccountingPostingContext.local(
                sourceType = "PURCHASE_SETTLEMENT",
                sourceId = purchase.id,
                suffix = "command:${valid.commandId}",
                actorId = actor.id,
                correlationId = "purchase_settlement:${valid.commandId}",
            )
            if (database.accountingDao().entryByIdempotencyKey(postingContext.idempotencyKey) != null) {
                val replay = accountingPosting.postBalanced(
                    draft = journalDraft,
                    context = postingContext,
                    entryNoFactory = { id -> "ت-$id" },
                )
                val currentRemaining = MoneyRial.of(purchase.totalRial) - MoneyRial.of(purchase.paidRial)
                return@withTransaction PostedPurchaseSettlement(
                    purchaseId = purchase.id,
                    journalEntryId = replay.entryId,
                    journalEntryNo = replay.entryNo,
                    remaining = currentRemaining,
                )
            }
            require(purchase.paymentMethod == null) {
                "این فاکتور هنگام خرید پرداخت شده است."
            }
            require(PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus) in setOf(PurchasePaymentStatus.UNPAID, PurchasePaymentStatus.PARTIAL)) {
                "این فاکتور قابل تسویه نیست."
            }
            require(valid.settlementEpochDay >= purchase.purchaseEpochDay) {
                "تاریخ تسویه نمی‌تواند قبل از تاریخ خرید باشد."
            }
            val remaining = MoneyRial.of(purchase.totalRial) - MoneyRial.of(purchase.paidRial)
            require(valid.amount <= remaining) {
                "مبلغ تسویه از مانده فاکتور بیشتر است."
            }

            val postedJournal = accountingPosting.postBalanced(
                draft = journalDraft,
                context = postingContext,
                entryNoFactory = { id -> "ت-$id" },
            )

            val newPaid = MoneyRial.of(purchase.paidRial) + valid.amount
            val newRemaining = MoneyRial.of(purchase.totalRial) - newPaid
            val paidInFull = newRemaining == MoneyRial.ZERO
            check(
                database.purchaseDao().updateSettlementState(
                    purchaseId = purchase.id,
                    expectedPaidRial = purchase.paidRial,
                    newPaidRial = newPaid.value,
                    paymentStatus = if (paidInFull) PurchasePaymentStatus.PAID.storedValue else PurchasePaymentStatus.PARTIAL.storedValue,
                    reminderEnabled = !paidInFull && purchase.reminderEnabled,
                    reminderEpochDay = if (paidInFull) null else purchase.reminderEpochDay,
                ) == 1,
            ) { "مانده فاکتور هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }

            syncRecorder?.record("PURCHASE", purchase.id, "SETTLEMENT", clock())
            audit("SETTLEMENT", purchase.id, "تسویه ${valid.amount.value} ریال؛ سند=${postedJournal.entryNo}؛ مانده=${newRemaining.value}", clock())

            PostedPurchaseSettlement(
                purchaseId = purchase.id,
                journalEntryId = postedJournal.entryId,
                journalEntryNo = postedJournal.entryNo,
                remaining = newRemaining,
            )
        }
    }


    override suspend fun reverseSettlement(draft: PurchaseSettlementReversalDraft) {
        val actor = authorizer.require(Permission.PAYMENT_APPROVE)
        authorizer.require(Permission.JOURNAL_REVERSE)
        val valid = draft.validated()
        database.withTransaction {
            val purchase = database.purchaseDao().byId(valid.purchaseId)
                ?: error("فاکتور خرید پیدا نشد.")
            require(purchase.paymentMethod == null) {
                "برگشت تسویه فقط برای خرید نسیه مجاز است."
            }
            require(PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus) != PurchasePaymentStatus.REVERSED) {
                "فاکتور برگشت‌خورده قابل اصلاح تسویه نیست."
            }
            val settlementEntry = database.accountingDao().entryById(valid.settlementJournalEntryId)
                ?: error("سند تسویه پیدا نشد.")
            require(settlementEntry.sourceType == "PURCHASE_SETTLEMENT" && settlementEntry.sourceId == purchase.id) {
                "سند انتخاب‌شده متعلق به این فاکتور نیست."
            }
            require(valid.reversalEpochDay >= settlementEntry.entryEpochDay) {
                "تاریخ برگشت تسویه نمی‌تواند قبل از تاریخ خود تسویه باشد."
            }
            val originalLines = database.accountingDao().linesByEntry(settlementEntry.id)
            require(originalLines.size >= 2) { "آرتیکل‌های سند تسویه کامل نیستند." }
            val amount = originalLines.fold(MoneyRial.ZERO) { total, line ->
                total + MoneyRial.of(line.debitRial)
            }
            require(amount > MoneyRial.ZERO) { "مبلغ سند تسویه معتبر نیست." }
            require(amount.value <= purchase.paidRial) {
                "مانده پرداخت‌شده فاکتور از مبلغ این تسویه کمتر است."
            }

            val now = clock()
            val reversalDraft = BalancedJournalDraft(
                entryEpochDay = valid.reversalEpochDay,
                description = "برگشت تسویه ${settlementEntry.entryNo}: ${valid.reason}",
                sourceType = "PURCHASE_SETTLEMENT_REVERSAL",
                sourceId = settlementEntry.id,
                lines = originalLines.map { line ->
                    JournalLineDraft(
                        accountCode = line.accountCode,
                        debit = MoneyRial.of(line.creditRial),
                        credit = MoneyRial.of(line.debitRial),
                        memo = valid.reason,
                    )
                },
            )
            val postingContext = AccountingPostingContext.local(
                sourceType = "PURCHASE_SETTLEMENT_REVERSAL",
                sourceId = settlementEntry.id,
                suffix = "command:${valid.commandId}",
                actorId = actor.id,
                correlationId = "purchase_settlement_reversal:${valid.commandId}",
                reversalOfEntryId = settlementEntry.id,
            )
            if (database.accountingDao().entryByIdempotencyKey(postingContext.idempotencyKey) != null) {
                accountingPosting.postBalanced(
                    draft = reversalDraft,
                    context = postingContext,
                    entryNoFactory = { id -> "بت-$id" },
                )
                return@withTransaction
            }
            require(!database.accountingDao().hasSettlementReversal(settlementEntry.id)) {
                "این تسویه قبلاً برگشت خورده است."
            }
            accountingPosting.postBalanced(
                draft = reversalDraft,
                context = postingContext,
                entryNoFactory = { id -> "بت-$id" },
            )

            val newPaid = MoneyRial.of(purchase.paidRial) - amount
            val newStatus = if (newPaid == MoneyRial.ZERO) PurchasePaymentStatus.UNPAID.storedValue else PurchasePaymentStatus.PARTIAL.storedValue
            check(
                database.purchaseDao().updateSettlementState(
                    purchaseId = purchase.id,
                    expectedPaidRial = purchase.paidRial,
                    newPaidRial = newPaid.value,
                    paymentStatus = newStatus,
                    reminderEnabled = purchase.reminderEnabled,
                    reminderEpochDay = purchase.reminderEpochDay,
                ) == 1,
            ) { "مانده فاکتور هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
            syncRecorder?.record("PURCHASE", purchase.id, "SETTLEMENT_REVERSAL", now)
            audit("REVERSE_SETTLEMENT", purchase.id, "برگشت تسویه ${settlementEntry.entryNo} به مبلغ ${amount.value} ریال؛ دلیل=${valid.reason}", now)
        }
    }

    override suspend fun reverse(draft: PurchaseReversalDraft) {
        authorizer.require(Permission.PURCHASES)
        val actor = authorizer.require(Permission.JOURNAL_REVERSE)
        val valid = draft.validated()
        database.withTransaction {
            val purchase = database.purchaseDao().byId(valid.purchaseId)
                ?: error("فاکتور خرید پیدا نشد.")
            require(PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus) != PurchasePaymentStatus.REVERSED) {
                "این فاکتور قبلاً برگشت خورده است."
            }
            require(!database.purchaseDao().isProcurementInvoice(purchase.id)) {
                "فاکتور تطبیق‌شده با سفارش خرید باید از مسیر برگشت کالا و اصلاح تدارکات برگشت بخورد."
            }
            require(valid.reversalEpochDay >= purchase.purchaseEpochDay) {
                "تاریخ برگشت نمی‌تواند قبل از تاریخ خرید باشد."
            }
            require(purchase.paidRial == 0L || purchase.paymentMethod != null) {
                "فاکتور نسیه‌ای که تسویه دارد ابتدا باید از مسیر اصلاح تسویه بررسی شود."
            }
            require(!database.accountingDao().hasPurchaseReversal(purchase.id)) {
                "برای این فاکتور قبلاً سند برگشت ثبت شده است."
            }
            val originalJournal = if (purchase.totalRial > 0) {
                database.accountingDao().entryBySource("PURCHASE", purchase.id)
                    ?: error("سند حسابداری خرید پیدا نشد.")
            } else null
            val originalJournalLines = originalJournal?.let { originalEntry ->
                database.accountingDao().linesByEntry(originalEntry.id).also { lines ->
                    require(lines.size >= 2) { "آرتیکل‌های سند خرید کامل نیستند." }
                }
            }.orEmpty()
            val purchaseLines = database.purchaseDao().linesByPurchase(purchase.id)
            require(purchaseLines.isNotEmpty()) { "ردیف‌های فاکتور خرید پیدا نشدند." }
            val now = clock()

            purchaseLines.forEach { line ->
                val item = database.inventoryDao().byId(line.itemId)
                    ?: error("کالای «${line.itemNameSnapshot}» پیدا نشد.")
                inventoryCommands.issue(
                    itemId = item.id,
                    quantityMicros = line.quantityMicros,
                    valueRial = line.lineTotalRial,
                    movementType = InventoryMovementType.PURCHASE_REVERSAL,
                    referenceType = InventoryReferenceType.PURCHASE,
                    referenceId = purchase.id,
                    movementEpochDay = valid.reversalEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.PURCHASE,
                        referenceId = purchase.id,
                        suffix = "reverse:${line.itemId}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.PURCHASE_REVERSAL,
                        reason = valid.reason,
                        correlationId = "purchase_reversal:${purchase.id}",
                    ),
                    notes = valid.reason,
                    lotPolicy = LocalInventoryCommandEngine.LotIssuePolicy.FEFO_ALLOCATED_ONLY,
                )
            }

            if (originalJournalLines.isNotEmpty()) {
                accountingPosting.postBalanced(
                    draft = BalancedJournalDraft(
                        entryEpochDay = valid.reversalEpochDay,
                        description = "برگشت فاکتور ${purchase.invoiceNo}: ${valid.reason}",
                        sourceType = "PURCHASE_REVERSAL",
                        sourceId = purchase.id,
                        lines = originalJournalLines.map { line ->
                            JournalLineDraft(
                                accountCode = line.accountCode,
                                debit = MoneyRial.of(line.creditRial),
                                credit = MoneyRial.of(line.debitRial),
                                memo = valid.reason,
                            )
                        },
                    ),
                    context = AccountingPostingContext.local(
                        sourceType = "PURCHASE_REVERSAL",
                        sourceId = purchase.id,
                        suffix = "reverse:${purchase.id}",
                        actorId = actor.id,
                        correlationId = "purchase_reversal:${purchase.id}",
                        reversalOfEntryId = requireNotNull(originalJournal).id,
                    ),
                    entryNoFactory = { id -> "بخ-$id" },
                )
            }
            check(database.purchaseDao().markReversed(purchase.id) == 1) {
                "وضعیت فاکتور تغییر نکرد."
            }
            syncRecorder?.record("PURCHASE", purchase.id, "REVERSAL", now)
            audit("REVERSE", purchase.id, "برگشت فاکتور ${purchase.invoiceNo}؛ مبلغ=${purchase.totalRial}؛ دلیل=${valid.reason}", now)
        }
    }

    private suspend fun audit(action: String, entityId: Long, description: String, now: Long) {
        auditWriter.appendAuthorized(
            authorizer = authorizer,
            action = action,
            entityType = "PURCHASE",
            entityId = entityId,
            description = description,
            occurredAtEpochMillis = now,
            correlationId = "purchase:$entityId:$action:$now",
        )
    }
}
