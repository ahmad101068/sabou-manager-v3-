package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodCloseDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodStatus
import ir.sabou.inventory.domain.purchase.PurchasePaymentStatus
import ir.sabou.inventory.domain.operations.StockMovementRecord
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.SupplierRecord
import ir.sabou.inventory.domain.operations.WasteDraft
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseLineDraft
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod

@Composable
fun PurchasesScreen(
    state: OperationsUiState,
    onSearch: (String) -> Unit,
    onSelect: (Long?) -> Unit,
    onSettle: (ir.sabou.inventory.domain.purchase.PurchaseSettlementDraft, () -> Unit) -> Unit,
    onReverseSettlement: (ir.sabou.inventory.domain.purchase.PurchaseSettlementReversalDraft, () -> Unit) -> Unit,
    onReverse: (ir.sabou.inventory.domain.purchase.PurchaseReversalDraft, () -> Unit) -> Unit,
    onSubmitRequisition: (ir.sabou.inventory.domain.purchase.PurchaseRequisitionDraft, () -> Unit) -> Unit,
    onReviewRequisition: (Long, Boolean) -> Unit,
    onCreateOrder: (ir.sabou.inventory.domain.purchase.PurchaseOrderDraft, () -> Unit) -> Unit,
    onCreateSplitOrders: (ir.sabou.inventory.domain.purchase.SplitPurchaseOrdersDraft, () -> Unit) -> Unit,
    onMarkOrderSent: (Long, ir.sabou.inventory.domain.purchase.PurchaseOrderDispatchChannel) -> Unit,
    onAcknowledgeOrder: (ir.sabou.inventory.domain.purchase.PurchaseOrderAcknowledgementDraft, () -> Unit) -> Unit,
    onReceiveGoods: (ir.sabou.inventory.domain.purchase.GoodsReceiptDraft, () -> Unit) -> Unit,
    onReturnGoods: (ir.sabou.inventory.domain.purchase.PurchaseReturnDraft, () -> Unit) -> Unit,
    onSaveReplenishmentPolicy: (ir.sabou.inventory.domain.purchase.ReplenishmentPolicyDraft, () -> Unit) -> Unit,
    onSaveSupplierOffer: (ir.sabou.inventory.domain.purchase.SupplierOfferDraft, () -> Unit) -> Unit,
    onSubmitSuggestedRequisition: (List<Long>, () -> Unit) -> Unit,
    onMatchInvoice: (Long, PurchaseDraft, Boolean, () -> Unit) -> Unit,
    onAdd: () -> Unit,
    onBack: () -> Unit,
) {
    val open = state.purchases.filter { it.outstandingRial > 0 && it.paymentStatus != PurchasePaymentStatus.REVERSED }
    val outstanding = open.sumOf { it.outstandingRial }
    Scaffold(topBar = { ProfessionalTopBar("خرید و تأمین", "فاکتورها، پرداخت‌ها و تعهدات", onBack, "خرید جدید", onAdd) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item { PremiumHero("تعهد باز خرید", formatMoney(outstanding), "${open.size} فاکتور نیازمند تسویه") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("کل فاکتورها", state.purchases.size.toString(), Modifier.weight(1f)); MetricTile("تسویه‌شده", state.purchases.count { it.paymentStatus == PurchasePaymentStatus.PAID }.toString(), Modifier.weight(1f)) } }
            item { ProcurementControlPanel(state, onSubmitRequisition, onReviewRequisition, onCreateOrder, onCreateSplitOrders, onMarkOrderSent, onAcknowledgeOrder, onReceiveGoods, onReturnGoods, onSaveReplenishmentPolicy, onSaveSupplierOffer, onSubmitSuggestedRequisition, onMatchInvoice) }
            item { PremiumSearchField(state.purchaseSearch, onSearch, "شماره فاکتور یا نام تأمین‌کننده") }
            item { SectionHeading("فاکتورهای خرید", "برای مشاهده جزئیات و تسویه روی کارت بزنید") }
            if (state.purchases.isEmpty()) item { EmptyStatePanel(if (state.purchaseSearch.isBlank()) "هنوز خریدی ثبت نشده" else "نتیجه‌ای پیدا نشد", if (state.purchaseSearch.isBlank()) "اولین فاکتور خرید را ثبت کنید." else "عبارت جست‌وجو را تغییر دهید.") }
            items(state.purchases, key = { it.id }) { purchase ->
                val status = when (purchase.paymentStatus) { PurchasePaymentStatus.PAID -> "تسویه‌شده"; PurchasePaymentStatus.PARTIAL -> "پرداخت ناقص"; PurchasePaymentStatus.REVERSED -> "برگشت‌خورده"; PurchasePaymentStatus.UNPAID -> "تسویه‌نشده"; PurchasePaymentStatus.LEGACY_UNKNOWN -> "نیازمند بررسی" }
                InvoiceSummaryCard("فاکتور ${purchase.invoiceNo}", purchase.supplierName, formatMoney(purchase.totalRial), status, "خرید ${epochDayToPersian(purchase.purchaseEpochDay).display()} • سررسید ${epochDayToPersian(purchase.dueEpochDay).display()}", purchase.outstandingRial.takeIf { it > 0 && purchase.paymentStatus != PurchasePaymentStatus.REVERSED }?.let(::formatMoney)) { onSelect(purchase.id) }
            }
        }
    }
    state.selectedPurchase?.let { details -> PurchaseDetailsDialog(details, state.busy, { onSelect(null) }, onSettle, onReverseSettlement, onReverse) }
}

private data class PurchaseLineForm(
    val rowId: Int,
    val itemId: Long? = null,
    val quantity: String = "",
    val unitCostRial: String = "",
)

@Composable
fun PurchaseEntryScreen(
    state: OperationsUiState,
    onPost: (PurchaseDraft, (PostedPurchase) -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    val todayEpochDay = remember { currentEpochDay() }
    var invoiceNo by remember { mutableStateOf("KH-${System.currentTimeMillis().toString().takeLast(10)}") }
    var supplierId by remember { mutableStateOf<Long?>(null) }
    var purchaseEpochDay by remember { mutableLongStateOf(todayEpochDay) }
    var dueEpochDay by remember { mutableLongStateOf(todayEpochDay) }
    var paymentMethod by remember { mutableStateOf(PurchasePaymentMethod.PAYABLE) }
    var reminderEnabled by remember { mutableStateOf(true) }
    var reminderEpochDay by remember { mutableLongStateOf(todayEpochDay) }
    var nextRowId by remember { mutableIntStateOf(2) }
    var lines by remember { mutableStateOf(listOf(PurchaseLineForm(rowId = 1))) }
    var localError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            ScreenHeader(
                title = "ثبت فاکتور خرید",
                actionLabel = null,
                onAction = {},
                onBack = onBack,
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.message?.let { MessageCard(it) }
            localError?.let { MessageCard(it, isError = true) }
            if (state.suppliers.isEmpty() || state.inventoryItems.isEmpty()) {
                MessageCard(
                    "برای ثبت خرید، ابتدا حداقل یک تأمین‌کننده و یک کالا ثبت کنید.",
                    isError = true,
                )
            }
            OutlinedTextField(
                value = invoiceNo,
                onValueChange = { invoiceNo = it },
                label = { Text("شماره فاکتور") },
                readOnly = true,
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            SelectionField(
                label = "تأمین‌کننده",
                selectedText = state.suppliers.firstOrNull { it.id == supplierId }?.name,
                options = state.suppliers.map { it.id to it.name },
                onSelected = { id ->
                    supplierId = id
                    val terms = state.suppliers.first { it.id == id }.paymentTermsDays
                    dueEpochDay = purchaseEpochDay + terms.toLong()
                    reminderEpochDay = dueEpochDay
                },
            )
            PersianDateField(
                label = "تاریخ خرید",
                epochDay = purchaseEpochDay,
                onSelected = { selectedDate ->
                    val previousTerm = dueEpochDay - purchaseEpochDay
                    purchaseEpochDay = selectedDate
                    dueEpochDay = selectedDate + previousTerm.coerceAtLeast(0)
                    if (reminderEpochDay < selectedDate) reminderEpochDay = selectedDate
                },
            )
            PersianDateField(
                label = "تاریخ تسویه",
                epochDay = dueEpochDay,
                onSelected = { dueEpochDay = it },
            )
            PaymentMethodField(paymentMethod) { paymentMethod = it }
            if (paymentMethod == PurchasePaymentMethod.PAYABLE) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = reminderEnabled,
                        onCheckedChange = { reminderEnabled = it },
                    )
                    Text("یادآوری تسویه")
                }
                if (reminderEnabled) {
                    PersianDateField(
                        label = "تاریخ یادآوری",
                        epochDay = reminderEpochDay,
                        onSelected = { reminderEpochDay = it },
                    )
                }
            }

            Text("اقلام فاکتور", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            lines.forEachIndexed { index, line ->
                PurchaseLineEditor(
                    index = index,
                    line = line,
                    items = state.inventoryItems,
                    removable = lines.size > 1,
                    onChanged = { changed ->
                        lines = lines.map { if (it.rowId == line.rowId) changed else it }
                    },
                    onRemove = {
                        lines = lines.filterNot { it.rowId == line.rowId }
                    },
                )
            }
            OutlinedButton(
                onClick = {
                    lines = lines + PurchaseLineForm(rowId = nextRowId)
                    nextRowId++
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text("افزودن ردیف")
            }
            Button(
                enabled = !state.busy && state.suppliers.isNotEmpty() && state.inventoryItems.isNotEmpty(),
                onClick = {
                    try {
                        localError = null
                        val draft = PurchaseDraft(
                            invoiceNo = invoiceNo.trim(),
                            supplierId = requireNotNull(supplierId) { "تأمین‌کننده را انتخاب کنید." },
                            purchaseEpochDay = purchaseEpochDay,
                            dueEpochDay = dueEpochDay,
                            paymentMethod = paymentMethod,
                            reminderEnabled = paymentMethod == PurchasePaymentMethod.PAYABLE && reminderEnabled,
                            reminderEpochDay = if (
                                paymentMethod == PurchasePaymentMethod.PAYABLE && reminderEnabled
                            ) {
                                reminderEpochDay
                            } else {
                                null
                            },
                            lines = lines.map { line ->
                                PurchaseLineDraft(
                                    itemId = requireNotNull(line.itemId) {
                                        "کالای ردیف فاکتور را انتخاب کنید."
                                    },
                                    quantity = parseQuantity(line.quantity),
                                    unitCost = parseMoneyRial(line.unitCostRial),
                                )
                            },
                        )
                        onPost(draft) { onBack() }
                    } catch (error: Exception) {
                        localError = error.message ?: "اطلاعات فاکتور کامل نیست."
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (state.busy) "در حال ثبت…" else "ثبت نهایی خرید")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PurchaseLineEditor(
    index: Int,
    line: PurchaseLineForm,
    items: List<InventoryItemRecord>,
    removable: Boolean,
    onChanged: (PurchaseLineForm) -> Unit,
    onRemove: () -> Unit,
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("ردیف ${index + 1}", fontWeight = FontWeight.Bold)
                if (removable) TextButton(onClick = onRemove) { Text("حذف ردیف") }
            }
            SelectionField(
                label = "شرح کالا",
                selectedText = items.firstOrNull { it.id == line.itemId }?.name,
                options = items.map { it.id to "${it.name} (${it.unit})" },
                onSelected = { onChanged(line.copy(itemId = it)) },
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = line.quantity,
                    onValueChange = { onChanged(line.copy(quantity = it)) },
                    label = { Text("تعداد") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                    value = formatMoneyInput(line.unitCostRial),
                    onValueChange = { onChanged(line.copy(unitCostRial = formatMoneyInput(it))) },
                    label = { Text("فی واحد (${currencyUnitLabel()})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
            }
            val selectedItem = items.firstOrNull { it.id == line.itemId }
            val rowTotal = runCatching { parseMoneyRial(line.unitCostRial).times(parseQuantity(line.quantity)).value }.getOrDefault(0L)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${selectedItem?.name ?: "شرح کالا"} • ${selectedItem?.unit.orEmpty()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("جمع: ${formatMoney(rowTotal)}", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PaymentMethodField(
    selected: PurchasePaymentMethod,
    onSelected: (PurchasePaymentMethod) -> Unit,
) {
    val labels = listOf(
        PurchasePaymentMethod.PAYABLE to "نسیه",
        PurchasePaymentMethod.CASH to "نقدی",
        PurchasePaymentMethod.CARD to "کارتخوان",
        PurchasePaymentMethod.TRANSFER to "حواله",
    )
    SelectionField(
        label = "روش پرداخت",
        selectedText = labels.first { it.first == selected }.second,
        options = labels.mapIndexed { index, value -> index.toLong() to value.second },
        onSelected = { index -> onSelected(labels[index.toInt()].first) },
    )
}


