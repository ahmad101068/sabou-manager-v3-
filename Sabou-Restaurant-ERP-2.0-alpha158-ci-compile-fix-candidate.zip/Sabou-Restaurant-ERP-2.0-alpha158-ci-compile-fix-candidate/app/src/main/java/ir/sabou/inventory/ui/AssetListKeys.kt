package ir.sabou.inventory.ui

internal fun assetRecordListKey(assetId: Long): String = "asset-$assetId"

internal fun assetDepreciationListKey(depreciationId: Long): String = "asset-depreciation-$depreciationId"
