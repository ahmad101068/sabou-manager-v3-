package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable

@Composable
internal fun AccountingRoutes(
    screen: AppScreen,
    state: AccountingUiState,
    accounting: AccountingViewModel,
    sales: DailySalesViewModel,
    navigate: (AppScreen) -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.ACCOUNTING -> AccountingScreen(
            state = state,
            onSearch = accounting::searchJournals,
            onSelectJournal = accounting::selectJournal,
            onSelectLedger = accounting::selectLedger,
            onSaveAccount = accounting::saveAccount,
            onDeactivateAccount = accounting::deactivateAccount,
            onReverse = accounting::reverseManual,
            onSetProfitLossRange = { from, to ->
                accounting.setProfitLossRange(from, to)
                sales.setReportRange(from, to)
            },
            onAddJournal = { navigate(AppScreen.NEW_JOURNAL) },
            onBack = navigateBack,
        )

        AppScreen.NEW_JOURNAL -> ManualJournalEntryScreen(
            state = state,
            onPost = accounting::postManual,
            onBack = navigateBack,
        )

        else -> error("accounting_route_group_mismatch:${screen.name}")
    }
}
