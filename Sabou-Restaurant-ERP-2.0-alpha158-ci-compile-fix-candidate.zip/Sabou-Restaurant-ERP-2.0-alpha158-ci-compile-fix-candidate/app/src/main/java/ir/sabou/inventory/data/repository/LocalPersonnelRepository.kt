package ir.sabou.inventory.data.repository

import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.security.SegregationOfDuties

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.EmployeeEntity
import ir.sabou.inventory.data.db.EmployeeAdvanceEntity
import ir.sabou.inventory.data.db.EmployeeContractEntity
import ir.sabou.inventory.data.db.AttendanceEntity
import ir.sabou.inventory.data.db.LeaveEntity
import ir.sabou.inventory.data.db.PayrollRunEntity
import ir.sabou.inventory.data.db.PayrollAdvanceAllocationEntity
import ir.sabou.inventory.data.db.PayrollPolicyEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.data.treasury.LegacyTreasuryChannelAdapter
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractRecord
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.AttendanceCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollPolicy
import ir.sabou.inventory.domain.personnel.AttendancePayrollAdjustment
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveRecord
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollCalculation
import ir.sabou.inventory.domain.personnel.PayrollCalculator
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PayrollStatus
import ir.sabou.inventory.domain.personnel.PayrollPolicyDraft
import ir.sabou.inventory.domain.personnel.PayrollPolicyRecord
import ir.sabou.inventory.domain.personnel.PayrollReversalDraft
import ir.sabou.inventory.domain.personnel.AdvanceDeductionAllocator
import ir.sabou.inventory.domain.personnel.OpenAdvanceBalance
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.accounting.JournalStatus
import ir.sabou.inventory.domain.accounting.AccountingPostingContext
import ir.sabou.inventory.domain.accounting.BalancedJournalDraft
import ir.sabou.inventory.domain.accounting.JournalLineDraft
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.treasury.TreasuryChannel
import java.security.MessageDigest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalPersonnelRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : PersonnelRepository {
    private val personnel get() = database.personnelDao()
    private val accounting get() = database.accountingDao()
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)
    private val auditWriter = LocalAuditEventWriter(database)

    override val employees: Flow<List<EmployeeRecord>> = personnel.observeEmployees().map { rows ->
        rows.map {
            EmployeeRecord(
                id = it.id, name = it.name, fatherName = it.fatherName, jobTitle = it.jobTitle, phone = it.phone,
                monthlySalaryRial = it.monthlySalaryRial, isActive = it.status == "ACTIVE", nationalId = it.nationalId,
                birthEpochDay = it.birthEpochDay, hireEpochDay = it.hireEpochDay, employeeCode = it.employeeCode,
                branchName = it.branchName, insuranceNumber = it.insuranceNumber, bankCard = it.bankCard,
                address = it.address, emergencyContact = it.emergencyContact,
            )
        }
    }

    override val payrolls: Flow<List<PayrollRecord>> = personnel.observePayrolls().map { rows ->
        rows.map {
            PayrollRecord(
                it.id,
                it.employeeId,
                it.employeeName,
                it.periodYear,
                it.periodMonth,
                it.revisionNo,
                it.grossPayRial,
                it.netPayRial,
                it.paymentEpochDay,
                LegacyTreasuryChannelAdapter.fromPersonnelStoredValue(it.paymentMethod),
                PayrollStatus.fromStoredValue(it.status),
                it.reversalEpochDay,
                it.reversalReason,
            )
        }
    }

    override val attendance: Flow<List<AttendanceRecord>> = personnel.observeAttendance().map { rows ->
        rows.map { it.toRecord() }
    }

    override val leaves: Flow<List<LeaveRecord>> = personnel.observeLeaves().map { rows -> rows.map { it.toRecord() } }
    override val pendingLeaves: Flow<List<LeaveRecord>> = personnel.observePendingLeaves().map { rows -> rows.map { it.toRecord() } }
    override val payrollPolicies: Flow<List<PayrollPolicyRecord>> = personnel.observePayrollPolicies().map { rows ->
        rows.map { PayrollPolicyRecord(it.id, it.title, it.effectiveFromEpochDay, it.effectiveToEpochDay, it.overtimeHourlyRateRial, it.absenceDailyDeductionRial, it.lateMinuteDeductionRial, it.createdBy) }
    }

    override suspend fun savePayrollPolicy(draft: PayrollPolicyDraft): Long {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        return database.withTransaction {
            personnel.openPayrollPolicyBefore(valid.effectiveFromEpochDay)?.let { previous ->
                check(personnel.closeOpenPayrollPolicy(previous.id, valid.effectiveFromEpochDay - 1L) == 1) {
                    "بستن نسخه قبلی سیاست حقوق انجام نشد."
                }
            }
            require(!personnel.payrollPolicyOverlaps(valid.effectiveFromEpochDay, valid.effectiveToEpochDay ?: Long.MAX_VALUE)) {
                "بازه این سیاست با سیاست حقوق دیگری هم‌پوشانی دارد."
            }
            val now = clock()
            personnel.insertPayrollPolicy(PayrollPolicyEntity(
                title = valid.title, effectiveFromEpochDay = valid.effectiveFromEpochDay,
                effectiveToEpochDay = valid.effectiveToEpochDay, overtimeHourlyRateRial = valid.overtimeHourlyRateRial,
                absenceDailyDeductionRial = valid.absenceDailyDeductionRial, lateMinuteDeductionRial = valid.lateMinuteDeductionRial,
                createdBy = authorizer.actor(), createdAtEpochMillis = now,
            )).also { syncRecorder?.record("PAYROLL_POLICY", it, "CREATE", now) }
        }
    }

    override suspend fun saveEmployee(id: Long?, draft: EmployeeDraft): Long {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            if (id == null) {
                personnel.insertEmployee(EmployeeEntity(name = valid.name, fatherName = valid.fatherName, employeeCode = valid.employeeCode.ifBlank { null }, jobTitle = valid.jobTitle, branchName = valid.branchName, phone = valid.phone,
                    nationalId = valid.nationalId.ifBlank { null }, birthEpochDay = valid.birthEpochDay, hireEpochDay = valid.hireEpochDay,
                    insuranceNumber = valid.insuranceNumber.ifBlank { null }, bankCard = valid.bankCard.ifBlank { null }, address = valid.address, emergencyContact = valid.emergencyContact,
                    monthlySalaryRial = valid.monthlySalaryRial, leaveBalanceMicros = 0, createdAtEpochMillis = now, updatedAtEpochMillis = now)).also { syncRecorder?.record("EMPLOYEE", it, "CREATE", now) }
            } else {
                val current = personnel.employeeById(id) ?: error("پرسنل پیدا نشد.")
                check(personnel.updateEmployee(current.copy(name=valid.name, fatherName=valid.fatherName, employeeCode=valid.employeeCode.ifBlank { null }, jobTitle=valid.jobTitle, branchName=valid.branchName, phone=valid.phone,
                    nationalId=valid.nationalId.ifBlank { null }, birthEpochDay=valid.birthEpochDay, hireEpochDay=valid.hireEpochDay,
                    insuranceNumber=valid.insuranceNumber.ifBlank { null }, bankCard=valid.bankCard.ifBlank { null }, address=valid.address, emergencyContact=valid.emergencyContact,
                    monthlySalaryRial=valid.monthlySalaryRial, status="ACTIVE", updatedAtEpochMillis=now)) == 1)
                syncRecorder?.record("EMPLOYEE", id, "UPDATE", now)
                id
            }
        }
    }

    override suspend fun deactivateEmployee(id: Long) {
        authorizer.require(Permission.PERSONNEL)
        val now = clock()
        check(personnel.deactivateEmployee(id, now) == 1) { "غیرفعال‌کردن پرسنل انجام نشد." }
        syncRecorder?.record("EMPLOYEE", id, "DEACTIVATE", now)
    }

    override fun contracts(employeeId: Long): Flow<List<EmployeeContractRecord>> =
        personnel.observeContracts(employeeId).map { rows ->
            rows.map { it.toRecord() }
        }

    override fun advances(employeeId: Long): Flow<List<EmployeeAdvanceRecord>> =
        personnel.observeAdvances(employeeId).map { rows -> rows.map { it.toRecord() } }

    override val openAdvances: Flow<List<EmployeeAdvanceRecord>> =
        personnel.observeOpenAdvances().map { rows -> rows.map { it.toRecord() } }

    override suspend fun saveContract(id: Long?, draft: EmployeeContractDraft): Long {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان قرارداد ثبت کرد." }
            if (id == null) {
                personnel.insertContract(
                    EmployeeContractEntity(
                        employeeId = valid.employeeId,
                        contractType = valid.contractType,
                        startEpochDay = valid.startEpochDay,
                        endEpochDay = valid.endEpochDay,
                        baseSalaryRial = valid.baseSalaryRial,
                        dailyWorkMinutes = valid.dailyWorkMinutes,
                        weeklyWorkDays = valid.weeklyWorkDays,
                        notes = valid.notes,
                        createdAtEpochMillis = now,
                        updatedAtEpochMillis = now,
                    ),
                )
            } else {
                val current = personnel.contractById(id) ?: error("قرارداد پیدا نشد.")
                require(current.employeeId == valid.employeeId) { "پرسنل قرارداد قابل تغییر نیست." }
                check(
                    personnel.updateContract(
                        current.copy(
                            contractType = valid.contractType,
                            startEpochDay = valid.startEpochDay,
                            endEpochDay = valid.endEpochDay,
                            baseSalaryRial = valid.baseSalaryRial,
                            dailyWorkMinutes = valid.dailyWorkMinutes,
                            weeklyWorkDays = valid.weeklyWorkDays,
                            notes = valid.notes,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "ویرایش قرارداد انجام نشد." }
                id
            }
        }
    }

    override suspend fun saveAttendance(id: Long?, draft: AttendanceDraft): Long {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val calculated = AttendanceCalculator.calculate(valid)
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان حضور ثبت کرد." }
            require(!personnel.attendanceDayLocked(valid.employeeId, valid.workEpochDay)) {
                "دوره حقوق این روز نهایی شده و حضور و غیاب آن قفل است."
            }
            if (valid.status != "LEAVE") {
                require(!personnel.hasApprovedLeave(valid.employeeId, valid.workEpochDay)) { "برای این روز مرخصی تأییدشده وجود دارد." }
            }
            val entity = AttendanceEntity(
                id = id ?: 0, employeeId = valid.employeeId, workEpochDay = valid.workEpochDay,
                status = valid.status, checkInMinute = valid.checkInMinute, checkOutMinute = valid.checkOutMinute,
                lateMinutes = calculated.lateMinutes, overtimeMinutes = calculated.overtimeMinutes, notes = valid.notes,
            )
            if (id == null) personnel.insertAttendance(entity) else {
                val current = personnel.attendanceById(id) ?: error("رکورد حضور پیدا نشد.")
                require(current.employeeId == valid.employeeId) { "پرسنل رکورد حضور قابل تغییر نیست." }
                check(personnel.updateAttendance(entity) == 1) { "ویرایش حضور انجام نشد." }
                id
            }
        }
    }

    override suspend fun attendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long): AttendanceSummary {
        authorizer.require(Permission.PERSONNEL)
        require(employeeId > 0 && startEpochDay > 0 && endEpochDay >= startEpochDay) { "بازه گزارش معتبر نیست." }
        val rows = personnel.attendanceInRange(employeeId, startEpochDay, endEpochDay)
        return AttendanceSummary(
            employeeId, startEpochDay, endEpochDay,
            presentDays = rows.count { it.status == "PRESENT" },
            absentDays = rows.count { it.status == "ABSENT" },
            leaveDays = rows.count { it.status == "LEAVE" },
            missionDays = rows.count { it.status == "MISSION" },
            workedMinutes = rows.sumOf { row -> if (row.checkInMinute != null && row.checkOutMinute != null) row.checkOutMinute - row.checkInMinute else 0 },
            lateMinutes = rows.sumOf { it.lateMinutes },
            overtimeMinutes = rows.sumOf { it.overtimeMinutes },
        )
    }

    override suspend fun attendancePayrollAdjustment(
        employeeId: Long,
        startEpochDay: Long,
        endEpochDay: Long,
        policy: AttendancePayrollPolicy,
    ): AttendancePayrollAdjustment {
        authorizer.require(Permission.PERSONNEL)
        return AttendancePayrollCalculator.calculate(
            attendanceSummary(employeeId, startEpochDay, endEpochDay),
            policy,
        )
    }

    override suspend fun requestLeave(draft: LeaveDraft, requestedBy: String): Long {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        require(requestedBy.trim().isNotEmpty()) { "ثبت‌کننده درخواست مشخص نیست." }
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
            require(!personnel.hasLeaveOverlap(valid.employeeId, valid.startEpochDay, valid.endEpochDay)) { "این درخواست با مرخصی دیگری هم‌پوشانی دارد." }
            val now = clock()
            personnel.insertLeave(LeaveEntity(
                employeeId = valid.employeeId, startEpochDay = valid.startEpochDay, endEpochDay = valid.endEpochDay,
                daysMicros = SignedLongMath.multiply(
                    SignedLongMath.add(SignedLongMath.subtract(valid.endEpochDay, valid.startEpochDay), 1L),
                    1_000_000L,
                ),
                leaveType = valid.leaveType, status = "PENDING", notes = valid.notes, requestedBy = requestedBy.trim(),
                createdAtEpochMillis = now, updatedAtEpochMillis = now,
            ))
        }
    }

    override suspend fun reviewLeave(draft: LeaveReviewDraft) {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        database.withTransaction {
            val current = personnel.leaveById(valid.leaveId) ?: error("درخواست مرخصی پیدا نشد.")
            require(current.status == "PENDING") { "فقط درخواست در انتظار قابل بررسی است." }
            val now = clock()
            if (valid.decision == "APPROVE") {
                require(!personnel.attendanceRangeLocked(current.employeeId, current.startEpochDay, current.endEpochDay)) {
                    "بخشی از بازه مرخصی در دوره حقوق نهایی‌شده قرار دارد و قابل تغییر نیست."
                }
                require(!personnel.hasAttendanceConflict(current.employeeId, current.startEpochDay, current.endEpochDay)) { "در بازه مرخصی، رکورد حضور متعارض وجود دارد." }
                for (day in current.startEpochDay..current.endEpochDay) {
                    val existing = personnel.attendanceByEmployeeDay(current.employeeId, day)
                    if (existing == null) {
                        personnel.insertAttendance(AttendanceEntity(employeeId=current.employeeId, workEpochDay=day, status="LEAVE", checkInMinute=null, checkOutMinute=null, lateMinutes=0, overtimeMinutes=0, notes="ثبت خودکار از گردش کار مرخصی"))
                    }
                }
            }
            check(personnel.updateLeave(current.copy(
                status = if (valid.decision == "APPROVE") "APPROVED" else "REJECTED",
                reviewedBy = valid.reviewer, reviewNotes = valid.notes, reviewedAtEpochMillis = now, updatedAtEpochMillis = now,
            )) == 1) { "ثبت نتیجه بررسی مرخصی انجام نشد." }
        }
    }

    override suspend fun cancelLeave(id: Long) {
        authorizer.require(Permission.PERSONNEL)
        database.withTransaction {
            val current = personnel.leaveById(id) ?: error("درخواست مرخصی پیدا نشد.")
            require(current.status == "PENDING") { "فقط درخواست در انتظار قابل لغو است." }
            val now = clock()
            check(personnel.updateLeave(current.copy(status="CANCELLED", cancelledAtEpochMillis=now, updatedAtEpochMillis=now)) == 1) { "لغو درخواست انجام نشد." }
        }
    }

    override suspend fun approveLeave(draft: LeaveDraft): Long {
        authorizer.require(Permission.PERSONNEL)
        val id = requestLeave(draft, "SYSTEM")
        reviewLeave(LeaveReviewDraft(id, "APPROVE", "SYSTEM", "تأیید مستقیم سازگار با نسخه قبلی"))
        return id
    }

    override suspend fun postAdvance(draft: EmployeeAdvanceDraft): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان مساعده ثبت کرد." }
            val paymentRole = valid.paymentMethod.personnelLedgerRole()
            val now = clock()
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "م-${employee.id}-$now", entryEpochDay = valid.advanceEpochDay,
                    description = "مساعده پرسنل: ${employee.name}", sourceType = "EMPLOYEE_ADVANCE", sourceId = employee.id,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.EMPLOYEE_ADVANCE_RECEIVABLE, debit = MoneyRial.of(valid.amountRial), memo = "مساعده ${employee.name}"),
                        SemanticJournalLine(paymentRole, credit = MoneyRial.of(valid.amountRial), memo = "پرداخت مساعده"),
                    ),
                ),
                context = AccountingPostingContext.local(
                    sourceType = "EMPLOYEE_ADVANCE",
                    sourceId = employee.id,
                    suffix = "post:$now",
                    actorId = actor.id,
                    correlationId = "employee_advance:${employee.id}:$now",
                ),
            )
            personnel.insertAdvance(
                EmployeeAdvanceEntity(
                    employeeId = employee.id,
                    amountRial = valid.amountRial,
                    advanceEpochDay = valid.advanceEpochDay,
                    paymentMethod = LegacyTreasuryChannelAdapter.toPersonnelStoredValue(valid.paymentMethod),
                    journalEntryId = entryId,
                    notes = valid.notes,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
        }
    }

    override suspend fun settleAdvance(
        id: Long,
        amountRial: Long,
        paymentMethod: TreasuryChannel,
        settlementEpochDay: Long,
    ) {
        val actor = authorizer.require(Permission.PERSONNEL)
        require(amountRial > 0) { "مبلغ تسویه باید بیشتر از صفر باشد." }
        require(paymentMethod in setOf(TreasuryChannel.CASH, TreasuryChannel.BANK)) {
            "advance_settlement_channel_unsupported"
        }
        require(settlementEpochDay > 0) { "تاریخ تسویه مساعده معتبر نیست." }
        database.withTransaction {
            val current = personnel.advanceById(id) ?: error("مساعده پیدا نشد.")
            require(current.status == "OPEN") { "این مساعده قبلاً تسویه شده است." }
            val employee = personnel.employeeById(current.employeeId) ?: error("پرسنل پیدا نشد.")
            val newSettled = SignedLongMath.add(current.settledAmountRial, amountRial)
            require(newSettled <= current.amountRial) { "مبلغ تسویه بیشتر از مانده مساعده است." }
            val receiptRole = paymentMethod.personnelLedgerRole()
            val now = clock()
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "م‌ت-${current.id}-$now", entryEpochDay = settlementEpochDay,
                    description = "بازپرداخت مساعده: ${employee.name}", sourceType = "EMPLOYEE_ADVANCE_SETTLEMENT", sourceId = current.id,
                    lines = listOf(
                        SemanticJournalLine(receiptRole, debit = MoneyRial.of(amountRial), memo = "دریافت بازپرداخت مساعده"),
                        SemanticJournalLine(SemanticAccountRole.EMPLOYEE_ADVANCE_RECEIVABLE, credit = MoneyRial.of(amountRial), memo = "کاهش مطالبات مساعده"),
                    ),
                ),
                context = AccountingPostingContext.local(
                    sourceType = "EMPLOYEE_ADVANCE_SETTLEMENT",
                    sourceId = current.id,
                    suffix = "settle:$now",
                    actorId = actor.id,
                    correlationId = "employee_advance_settlement:${current.id}:$now",
                ),
            )
            check(
                personnel.updateAdvance(
                    current.copy(
                        settledAmountRial = newSettled,
                        status = if (newSettled == current.amountRial) "SETTLED" else "OPEN",
                        updatedAtEpochMillis = now,
                    ),
                ) == 1,
            ) { "تسویه مساعده انجام نشد." }
        }
    }

    override suspend fun calculatePayroll(draft: PayrollDraft): PayrollCalculation {
        authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
        require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
        AdvanceDeductionAllocator.allocate(
            valid.advanceDeductionRial,
            personnel.openAdvancesByEmployee(employee.id).map {
                OpenAdvanceBalance(it.id, SignedLongMath.subtract(it.amountRial, it.settledAmountRial))
            },
        )
        val contract = personnel.effectiveContract(employee.id, valid.periodStartEpochDay, valid.periodEndEpochDay)
            ?: error("برای دوره حقوق قرارداد فعال و مؤثر پیدا نشد.")
        require(contract.startEpochDay <= valid.periodStartEpochDay && (contract.endEpochDay == null || contract.endEpochDay >= valid.periodEndEpochDay)) {
            "دوره حقوق باید به طور کامل تحت پوشش یک قرارداد فعال باشد."
        }
        val prepared = prepareAttendancePayroll(valid)
        return PayrollCalculator.calculate(contract.baseSalaryRial, prepared.draft).copy(
            automaticOvertimeRial = prepared.adjustment?.overtimeRial ?: 0,
            attendanceDeductionRial = prepared.adjustment?.totalAttendanceDeductionRial ?: 0,
            payrollPolicyId = prepared.policyId,
        )
    }

    override suspend fun postPayroll(draft: PayrollDraft): Long {
        val creator = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        return database.withTransaction {
            val commandCorrelation = valid.commandCorrelation()
            personnel.payrollByGlobalId(valid.commandId)?.let { existingPayroll ->
                if (
                    existingPayroll.correlationId != commandCorrelation ||
                    existingPayroll.createdByActorId != creator.id
                ) {
                    throw BusinessError.IdempotencyConflict(valid.commandId).asViolation()
                }
                return@withTransaction existingPayroll.id
            }
            val postingContext = AccountingPostingContext.local(
                sourceType = "PAYROLL",
                sourceId = 0,
                suffix = "command:${valid.commandId}",
                actorId = creator.id,
                correlationId = commandCorrelation,
            )
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
            require(!personnel.payrollExists(employee.id, valid.periodYear, valid.periodMonth)) { "حقوق این دوره قبلاً ثبت شده است." }
            val contract = personnel.effectiveContract(employee.id, valid.periodStartEpochDay, valid.periodEndEpochDay)
                ?: error("برای دوره حقوق قرارداد فعال و مؤثر پیدا نشد.")
            require(contract.startEpochDay <= valid.periodStartEpochDay && (contract.endEpochDay == null || contract.endEpochDay >= valid.periodEndEpochDay)) {
                "دوره حقوق باید به طور کامل تحت پوشش یک قرارداد فعال باشد."
            }
            val prepared = prepareAttendancePayroll(valid)
            val effective = prepared.draft
            val calculation = PayrollCalculator.calculate(contract.baseSalaryRial, effective).copy(
                automaticOvertimeRial = prepared.adjustment?.overtimeRial ?: 0,
                attendanceDeductionRial = prepared.adjustment?.totalAttendanceDeductionRial ?: 0,
                payrollPolicyId = prepared.policyId,
            )
            require(calculation.grossPayRial >= calculation.netPayRial) { "محاسبه فیش حقوقی نامعتبر است." }
            val paymentRole = valid.paymentMethod.personnelLedgerRole()
            val tempNo = "TMP-PAY-${valid.commandId.take(8)}"
            val payrollLines = buildList {
                add(SemanticJournalLine(SemanticAccountRole.SALARY_EXPENSE, debit = MoneyRial.of(calculation.grossPayRial), memo = "حقوق، مزایا و پاداش"))
                if (calculation.netPayRial > 0) add(SemanticJournalLine(paymentRole, credit = MoneyRial.of(calculation.netPayRial), memo = "خالص پرداخت"))
                if (effective.insuranceRial > 0) add(SemanticJournalLine(SemanticAccountRole.INSURANCE_PAYABLE, credit = MoneyRial.of(effective.insuranceRial), memo = "بیمه پرداختنی"))
                if (effective.taxRial > 0) add(SemanticJournalLine(SemanticAccountRole.TAX_PAYABLE, credit = MoneyRial.of(effective.taxRial), memo = "مالیات پرداختنی"))
                if (effective.deductionsRial > 0) add(SemanticJournalLine(SemanticAccountRole.PAYROLL_PAYABLE, credit = MoneyRial.of(effective.deductionsRial), memo = "سایر کسورات و حضور"))
                if (valid.advanceDeductionRial > 0) add(SemanticJournalLine(SemanticAccountRole.EMPLOYEE_ADVANCE_RECEIVABLE, credit = MoneyRial.of(valid.advanceDeductionRial), memo = "کسر مساعده"))
            }
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = tempNo, entryEpochDay = valid.paymentEpochDay,
                    description = "حقوق ${employee.name} ${valid.periodYear}/${valid.periodMonth}",
                    sourceType = "PAYROLL", sourceId = 0, status = JournalStatus.DRAFT, lines = payrollLines,
                ),
                context = postingContext,
            )
            val payrollId = personnel.insertPayroll(PayrollRunEntity(employeeId=employee.id, periodYear=valid.periodYear, periodMonth=valid.periodMonth,
                revisionNo=personnel.nextPayrollRevision(employee.id, valid.periodYear, valid.periodMonth),
                baseSalaryRial=calculation.baseSalaryRial, overtimeRial=effective.overtimeRial,
                bonusRial=SignedLongMath.add(valid.bonusRial, valid.allowancesRial),
                deductionsRial=effective.deductionsRial, advanceDeductionRial=valid.advanceDeductionRial,
                periodStartEpochDay=valid.periodStartEpochDay, periodEndEpochDay=valid.periodEndEpochDay,
                payrollPolicyId=prepared.policyId, automaticOvertimeRial=calculation.automaticOvertimeRial,
                attendanceDeductionRial=calculation.attendanceDeductionRial,
                insuranceRial=valid.insuranceRial, taxRial=valid.taxRial, netPayRial=calculation.netPayRial,
                paymentEpochDay=valid.paymentEpochDay,
                paymentMethod=LegacyTreasuryChannelAdapter.toPersonnelStoredValue(valid.paymentMethod),
                journalEntryId=entryId, status=PayrollStatus.PENDING_APPROVAL.storedValue,
                notes=valid.notes, createdAtEpochMillis=clock(), createdByActorId=creator.id,
                globalId=valid.commandId, correlationId=postingContext.correlationId))
            check(payrollId > 0L) { "ثبت فیش حقوقی انجام نشد." }
            val now = clock()
            // Link the journal to the actual payroll row only after its id exists.
            check(accounting.finalizeEntryIdentity(entryId, "ح-$entryId", payrollId) == 1) {
                "تکمیل ارتباط سند حقوق با فیش انجام نشد."
            }
            syncRecorder?.record("PAYROLL", payrollId, "CREATE", now)
            payrollId
        }
    }

    override suspend fun approvePayroll(payrollId: Long) {
        val approver = authorizer.require(Permission.PAYROLL_APPROVE)
        database.withTransaction {
            val payroll = personnel.payrollById(payrollId) ?: error("فیش حقوق پیدا نشد.")
            val payrollStatus = PayrollStatus.fromStoredValue(payroll.status)
            val journal = accounting.entryById(payroll.journalEntryId) ?: error("سند حقوق پیدا نشد.")
            if (payrollStatus == PayrollStatus.PAID) {
                require(journal.status == JournalStatus.POSTED.storedValue) {
                    "فیش پرداخت‌شده سند قطعی معتبر ندارد."
                }
                return@withTransaction
            }
            require(payrollStatus == PayrollStatus.PENDING_APPROVAL) { "این فیش در انتظار تأیید نیست." }
            require(journal.status == "DRAFT") { "سند حقوق در وضعیت پیش‌نویس نیست." }
            if (payroll.createdByActorId == null) {
                authorizer.requireOwner()
            } else {
                SegregationOfDuties.requireDifferentActors(
                    operation = "PAYROLL_APPROVAL",
                    creatorActorId = payroll.createdByActorId,
                    approverActorId = approver.id,
                )
            }
            val openAdvances = personnel.openAdvancesByEmployee(payroll.employeeId)
            val allocations = AdvanceDeductionAllocator.allocate(payroll.advanceDeductionRial, openAdvances.map { OpenAdvanceBalance(it.id, SignedLongMath.subtract(it.amountRial, it.settledAmountRial)) })
            val now = clock()
            if (allocations.isNotEmpty()) {
                personnel.insertPayrollAdvanceAllocations(allocations.map { PayrollAdvanceAllocationEntity(payroll.id, it.advanceId, it.amountRial, now) })
                val byId = openAdvances.associateBy { it.id }
                allocations.forEach { allocation ->
                    val advance = requireNotNull(byId[allocation.advanceId])
                    val settled = SignedLongMath.add(advance.settledAmountRial, allocation.amountRial)
                    check(personnel.updateAdvance(advance.copy(settledAmountRial=settled,status=if(settled==advance.amountRial) "SETTLED" else "OPEN",updatedAtEpochMillis=now)) == 1)
                }
            }
            accountingPosting.postExistingDraft(
                entryId = journal.id,
                businessEpochDay = payroll.paymentEpochDay,
                actorId = approver.id,
            )
            check(personnel.approvePayroll(payroll.id, approver.displayName, approver.id, now) == 1) { "تأیید فیش حقوق انجام نشد." }
            auditWriter.appendAuthorized(
                authorizer = authorizer,
                action = "APPROVE",
                entityType = "PAYROLL",
                entityId = payroll.id,
                description = "تأیید نهایی و پرداخت حقوق ${payroll.periodYear}/${payroll.periodMonth}",
                occurredAtEpochMillis = now,
                businessEpochDay = payroll.paymentEpochDay,
                reason = "تأیید نهایی توسط کاربر مجاز مستقل",
                beforeSnapshot = "status=PENDING_APPROVAL;createdByActorId=${payroll.createdByActorId}",
                afterSnapshot = "status=PAID;approvedByActorId=${approver.id};journalEntryId=${journal.id}",
                correlationId = payroll.correlationId,
            )
            syncRecorder?.record("PAYROLL", payroll.id, "APPROVE_PAYMENT", now)
        }
    }

    override suspend fun reversePayroll(draft: PayrollReversalDraft) {
        authorizer.require(Permission.PERSONNEL)
        val actor = authorizer.require(Permission.JOURNAL_REVERSE)
        database.withTransaction {
            val payroll = personnel.payrollById(draft.payrollId) ?: error("فیش حقوق پیدا نشد.")
            val valid = draft.validated(payroll.paymentEpochDay)
            val status = PayrollStatus.fromStoredValue(payroll.status)
            if (status == PayrollStatus.REVERSED) {
                if (
                    payroll.reversalEpochDay != valid.reversalEpochDay ||
                    payroll.reversalReason != valid.reason
                ) {
                    throw BusinessError.IdempotencyConflict("PAYROLL_REVERSAL:${payroll.id}").asViolation()
                }
                return@withTransaction
            }
            require(status == PayrollStatus.PAID) { "فقط فیش پرداخت‌شده قابل ابطال است." }
            require(!accounting.hasPayrollReversal(payroll.id)) { "سند برگشت این فیش قبلاً ثبت شده است." }
            val originalJournal = accounting.entryById(payroll.journalEntryId) ?: error("سند حسابداری حقوق پیدا نشد.")
            require(originalJournal.status == "POSTED" && originalJournal.sourceType == "PAYROLL" && originalJournal.sourceId == payroll.id) {
                "سند حسابداری با فیش حقوق تطابق ندارد."
            }
            val originalLines = accounting.linesByEntry(originalJournal.id)
            require(originalLines.size >= 2) { "آرتیکل‌های سند حقوق کامل نیستند." }
            val now = clock()
            val reversal = accountingPosting.postBalanced(
                draft = BalancedJournalDraft(
                    entryEpochDay = valid.reversalEpochDay,
                    description = "ابطال حقوق ${payroll.periodYear}/${payroll.periodMonth}: ${valid.reason}",
                    sourceType = "PAYROLL_REVERSAL",
                    sourceId = payroll.id,
                    lines = originalLines.map { line ->
                        JournalLineDraft(
                            accountCode = line.accountCode,
                            debit = MoneyRial.of(line.creditRial),
                            credit = MoneyRial.of(line.debitRial),
                            memo = valid.reason,
                        )
                    },
                ),
                context = AccountingPostingContext.local(
                    sourceType = "PAYROLL_REVERSAL",
                    sourceId = payroll.id,
                    suffix = "reverse:${payroll.id}",
                    actorId = actor.id,
                    correlationId = "payroll_reversal:${payroll.id}",
                    reversalOfEntryId = originalJournal.id,
                ),
                entryNoFactory = { id -> "بح-$id" },
            )
            val allocations = personnel.payrollAdvanceAllocations(payroll.id)
            allocations.forEach { allocation ->
                val advance = personnel.advanceById(allocation.advanceId) ?: error("مساعده تخصیص‌یافته پیدا نشد.")
                val settled = SignedLongMath.subtract(advance.settledAmountRial, allocation.amountRial)
                require(settled >= 0) { "مانده مساعده پس از ابطال نامعتبر می‌شود." }
                check(personnel.updateAdvance(advance.copy(
                    settledAmountRial = settled,
                    status = if (settled < advance.amountRial) "OPEN" else "SETTLED",
                    updatedAtEpochMillis = now,
                )) == 1) { "بازگردانی مانده مساعده انجام نشد." }
            }
            check(personnel.markPayrollReversed(payroll.id, valid.reversalEpochDay, valid.reason, reversal.entryId, actor.displayName) == 1) {
                "وضعیت ابطال فیش حقوق ثبت نشد."
            }
            auditWriter.appendAuthorized(
                authorizer = authorizer,
                action = "REVERSE",
                entityType = "PAYROLL",
                entityId = payroll.id,
                description = "ابطال فیش حقوق ${payroll.periodYear}/${payroll.periodMonth} نسخه ${payroll.revisionNo}: ${valid.reason}",
                occurredAtEpochMillis = now,
                businessEpochDay = valid.reversalEpochDay,
                reason = valid.reason,
                beforeSnapshot = "status=PAID;journalEntryId=${originalJournal.id}",
                afterSnapshot = "status=REVERSED;reversalJournalEntryId=${reversal.entryId}",
                correlationId = "payroll_reversal:${payroll.id}",
            )
            syncRecorder?.record("PAYROLL", payroll.id, "REVERSAL", now)
        }
    }

    private suspend fun prepareAttendancePayroll(valid: PayrollDraft): PreparedPayroll {
        if (valid.periodStartEpochDay == 0L) return PreparedPayroll(valid, null, null)
        val policy = personnel.payrollPolicyForRange(valid.periodStartEpochDay, valid.periodEndEpochDay)
            ?: error("برای کل بازه این دوره، سیاست فعال حقوق تعریف نشده است.")
        val summary = attendanceSummary(valid.employeeId, valid.periodStartEpochDay, valid.periodEndEpochDay)
        val adjustment = AttendancePayrollCalculator.calculate(
            summary,
            AttendancePayrollPolicy(policy.overtimeHourlyRateRial, policy.absenceDailyDeductionRial, policy.lateMinuteDeductionRial),
        )
        return PreparedPayroll(
            valid.copy(
                overtimeRial = SignedLongMath.add(valid.overtimeRial, adjustment.overtimeRial),
                deductionsRial = SignedLongMath.add(valid.deductionsRial, adjustment.totalAttendanceDeductionRial),
            ),
            adjustment,
            policy.id,
        )
    }
}

private fun PayrollDraft.commandCorrelation(): String {
    val encodedPayload = listOf(
        employeeId,
        periodYear,
        periodMonth,
        overtimeRial,
        bonusRial,
        allowancesRial,
        deductionsRial,
        insuranceRial,
        taxRial,
        advanceDeductionRial,
        periodStartEpochDay,
        periodEndEpochDay,
        paymentEpochDay,
        paymentMethod,
        notes,
    ).joinToString(separator = "|") { value ->
        val text = value.toString()
        "${text.length}:$text"
    }
    val fingerprint = MessageDigest.getInstance("SHA-256")
        .digest(encodedPayload.toByteArray(Charsets.UTF_8))
        .take(16)
        .joinToString("") { byte -> "%02x".format(byte) }
    return "payroll:$commandId:$fingerprint"
}

private data class PreparedPayroll(val draft: PayrollDraft, val adjustment: AttendancePayrollAdjustment?, val policyId: Long?)

private fun EmployeeContractEntity.toRecord() = EmployeeContractRecord(
    id = id,
    employeeId = employeeId,
    contractType = contractType,
    startEpochDay = startEpochDay,
    endEpochDay = endEpochDay,
    baseSalaryRial = baseSalaryRial,
    dailyWorkMinutes = dailyWorkMinutes,
    weeklyWorkDays = weeklyWorkDays,
    status = status,
    notes = notes,
)

private fun EmployeeAdvanceEntity.toRecord(): EmployeeAdvanceRecord {
    val remaining = SignedLongMath.subtract(amountRial, settledAmountRial)
    return EmployeeAdvanceRecord(
        id = id,
        employeeId = employeeId,
        amountRial = amountRial,
        settledAmountRial = settledAmountRial,
        remainingAmountRial = remaining,
        advanceEpochDay = advanceEpochDay,
        paymentMethod = LegacyTreasuryChannelAdapter.fromPersonnelStoredValue(paymentMethod),
        journalEntryId = journalEntryId,
        status = status,
        notes = notes,
    )
}


private fun AttendanceEntity.toRecord() = AttendanceRecord(
    id = id, employeeId = employeeId, workEpochDay = workEpochDay, status = status,
    checkInMinute = checkInMinute, checkOutMinute = checkOutMinute,
    workedMinutes = if (checkInMinute != null && checkOutMinute != null) checkOutMinute - checkInMinute else 0,
    lateMinutes = lateMinutes, overtimeMinutes = overtimeMinutes, notes = notes,
)

private fun TreasuryChannel.personnelLedgerRole(): SemanticAccountRole = when (this) {
    TreasuryChannel.CASH -> SemanticAccountRole.CASH
    TreasuryChannel.BANK -> SemanticAccountRole.BANK
    TreasuryChannel.CARD,
    TreasuryChannel.TRANSFER,
    -> throw BusinessError.UnsupportedDomainOperation(
        ownerDomain = "workforce",
        operation = "ledger_role_${storedValue.lowercase()}",
    ).asViolation()
}


private fun LeaveEntity.toRecord() = LeaveRecord(
    id=id, employeeId=employeeId, startEpochDay=startEpochDay, endEpochDay=endEpochDay, daysMicros=daysMicros,
    leaveType=leaveType, status=status, notes=notes, requestedBy=requestedBy, reviewedBy=reviewedBy,
    reviewNotes=reviewNotes, reviewedAtEpochMillis=reviewedAtEpochMillis,
)
