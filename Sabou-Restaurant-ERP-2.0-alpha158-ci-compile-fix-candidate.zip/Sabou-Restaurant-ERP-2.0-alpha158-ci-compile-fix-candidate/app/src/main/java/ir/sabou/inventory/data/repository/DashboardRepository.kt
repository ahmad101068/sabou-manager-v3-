package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SystemSemanticAccountResolver
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

data class DashboardSnapshot(
    val inventoryValueRial: Long = 0,
    val supplierPayablesRial: Long = 0,
    val cashBalanceRial: Long = 0,
    val bankBalanceRial: Long = 0,
)

class DashboardRepository(database: AppDatabase) {
    val snapshot: Flow<DashboardSnapshot> = combine(
        database.inventoryDao().observeInventoryValueRial(),
        database.purchaseDao().observePayablesRial(),
        database.accountingDao().observeBalanceRial(SystemSemanticAccountResolver.codeFor(SemanticAccountRole.CASH)),
        database.accountingDao().observeBalanceRial(SystemSemanticAccountResolver.codeFor(SemanticAccountRole.BANK)),
    ) { inventory, payables, cash, bank ->
        DashboardSnapshot(
            inventoryValueRial = inventory,
            supplierPayablesRial = payables,
            cashBalanceRial = cash,
            bankBalanceRial = bank,
        )
    }
}

