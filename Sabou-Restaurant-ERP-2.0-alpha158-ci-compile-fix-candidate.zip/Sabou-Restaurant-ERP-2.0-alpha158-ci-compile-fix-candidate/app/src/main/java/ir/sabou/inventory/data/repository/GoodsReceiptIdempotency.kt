package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.GoodsReceiptEntity
import ir.sabou.inventory.data.db.GoodsReceiptLineEntity
import ir.sabou.inventory.data.db.PurchaseOrderLineEntity
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.purchase.GoodsReceiptDraft

/**
 * Persistence-boundary equivalence check for the natural goods-receipt command key.
 * A matching key is a replay only when every business-relevant field is identical.
 */
internal object GoodsReceiptIdempotency {
    fun existingReplayIdOrThrow(
        existing: GoodsReceiptEntity?,
        existingLines: List<GoodsReceiptLineEntity>,
        currentOrderLines: List<PurchaseOrderLineEntity>,
        draft: GoodsReceiptDraft,
    ): Long? {
        if (existing == null) return null

        val commandKey = "GOODS_RECEIPT:${draft.purchaseOrderId}:${draft.deliveryNoteNo}"
        val persistedByOrderLine = existingLines.associateBy { it.purchaseOrderLineId }
        val currentById = currentOrderLines.associateBy { it.id }
        val sameHeader = existing.purchaseOrderId == draft.purchaseOrderId &&
            existing.deliveryNoteNo == draft.deliveryNoteNo &&
            existing.receiptEpochDay == draft.receiptEpochDay &&
            existing.note == draft.note
        val sameLines = persistedByOrderLine.size == draft.lines.size && draft.lines.all { requested ->
            val persisted = persistedByOrderLine[requested.purchaseOrderLineId] ?: return@all false
            val orderLine = currentById[requested.purchaseOrderLineId] ?: return@all false
            val expectedRejected = if (draft.finalizeOrder) {
                // Finalization records every still-unreceived unit as rejected. receivedQtyMicros is
                // cumulative and is not reduced by a later supplier return.
                orderLine.orderedQtyMicros - orderLine.receivedQtyMicros
            } else {
                requested.deliveredQtyMicros - requested.acceptedQtyMicros
            }
            persisted.itemId == orderLine.itemId &&
                persisted.deliveredQtyMicros == requested.deliveredQtyMicros &&
                persisted.acceptedQtyMicros == requested.acceptedQtyMicros &&
                persisted.rejectedQtyMicros == expectedRejected &&
                persisted.rejectionReason == requested.rejectionReason
        }

        if (!sameHeader || !sameLines) {
            throw BusinessError.IdempotencyConflict(commandKey).asViolation()
        }
        return existing.id
    }
}
