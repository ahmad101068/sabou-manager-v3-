package ir.sabou.inventory.ui

internal fun personnelEmployeeListKey(employeeId: Long): String = "employee-$employeeId"

internal fun personnelPayrollListKey(payrollId: Long): String = "payroll-$payrollId"
