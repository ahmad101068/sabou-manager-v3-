package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.assets.AssetRecord
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.assets.DepreciationDraft
import ir.sabou.inventory.domain.assets.DepreciationRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AssetUiState(
    val assets: List<AssetRecord> = emptyList(),
    val depreciations: List<DepreciationRecord> = emptyList(),
    val message: String? = null,
)

class AssetViewModel(
    private val repository: AssetRepository,
) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)

    val state: StateFlow<AssetUiState> = combine(
        repository.assets,
        repository.depreciations,
        message,
    ) { assets, depreciations, currentMessage ->
        AssetUiState(assets, depreciations, currentMessage)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = AssetUiState(),
    )

    fun save(id: Long?, draft: AssetDraft) = launch("دارایی ذخیره شد.") {
        repository.save(id, draft)
    }

    fun recognize(id: Long) = launch("دارایی قدیمی با سند مانده افتتاحیه به دفتر متصل شد.") {
        repository.recognizeLegacyAsset(id)
    }

    fun dispose(id: Long) = launch("دارایی از چرخه بهره‌برداری خارج شد.") {
        repository.dispose(id)
    }

    fun depreciate(draft: DepreciationDraft) = launch("استهلاک ثبت و سند حسابداری صادر شد.") {
        repository.postDepreciation(draft)
    }

    fun clearMessage() {
        message.value = null
    }

    private fun launch(success: String, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }
            .onSuccess { message.value = success }
            .onFailure { error -> message.value = UiErrorHandler.message("AssetViewModel", error) }
    }

    companion object {
        fun factory(repository: AssetRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                AssetViewModel(repository) as T
        }
    }
}
