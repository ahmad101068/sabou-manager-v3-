package ir.sabou.inventory.data.db

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** Enterprise ledger upgrade edges. */
internal val MIGRATION_40_41 = object : Migration(40, 41) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE inventory_items ADD COLUMN purchaseUnit TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE inventory_items ADD COLUMN purchaseToStockNumerator INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE inventory_items ADD COLUMN purchaseToStockDenominator INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE inventory_items ADD COLUMN recipeUnit TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE inventory_items ADD COLUMN recipeToStockNumerator INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE inventory_items ADD COLUMN recipeToStockDenominator INTEGER NOT NULL DEFAULT 1")
        // Existing installations are 1:1; preserve the previous unit as all three semantic units.
        db.execSQL("UPDATE inventory_items SET purchaseUnit = unit, recipeUnit = unit")
    }
}

internal val MIGRATION_41_42 = object : Migration(41, 42) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE journal_entries ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE journal_entries ADD COLUMN idempotencyKey TEXT")
        db.execSQL("ALTER TABLE journal_entries ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE journal_entries ADD COLUMN reversalOfEntryId INTEGER")
        db.execSQL("ALTER TABLE journal_entries ADD COLUMN postedAtEpochMillis INTEGER")
        db.execSQL("ALTER TABLE journal_entries ADD COLUMN postedByActorId INTEGER")
        db.execSQL(
            """UPDATE journal_entries
            SET globalId = 'legacy:journal_entry:' || id,
                idempotencyKey = 'legacy:journal:' || id,
                correlationId = 'legacy:journal:' || id,
                postedAtEpochMillis = CASE WHEN status = 'POSTED' THEN createdAtEpochMillis ELSE NULL END""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_journal_entries_globalId ON journal_entries(globalId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_journal_entries_idempotencyKey ON journal_entries(idempotencyKey)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_journal_entries_correlationId ON journal_entries(correlationId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_journal_entries_reversalOfEntryId ON journal_entries(reversalOfEntryId)")

        AccountSeedCallback.seedSystemLocations(db)
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN idempotencyKey TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN actorId INTEGER")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN deviceId TEXT NOT NULL DEFAULT 'legacy-unknown'")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN locationId INTEGER")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN unitCostRial INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN reasonCode TEXT NOT NULL DEFAULT 'LEGACY'")
        db.execSQL("ALTER TABLE stock_movements ADD COLUMN reversalOfMovementId INTEGER")
        db.execSQL(
            """UPDATE stock_movements
            SET globalId = 'legacy:stock_movement:' || id,
                idempotencyKey = 'legacy:stock:' || id,
                correlationId = 'legacy:stock:' || id,
                deviceId = 'legacy-local',
                locationId = (
                    SELECT id FROM storage_locations
                    WHERE isActive = 1
                    ORDER BY CASE WHEN kind = 'PRIMARY' THEN 0 ELSE 1 END, id
                    LIMIT 1
                ),
                reasonCode = 'LEGACY_BACKFILL'""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_movements_globalId ON stock_movements(globalId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_movements_idempotencyKey ON stock_movements(idempotencyKey)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_movements_correlationId ON stock_movements(correlationId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_movements_actorId ON stock_movements(actorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_movements_locationId ON stock_movements(locationId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_movements_reversalOfMovementId ON stock_movements(reversalOfMovementId)")

        db.execSQL("ALTER TABLE inventory_counts ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE inventory_counts ADD COLUMN idempotencyKey TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE inventory_counts ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE inventory_counts ADD COLUMN actorId INTEGER")
        db.execSQL("ALTER TABLE inventory_counts ADD COLUMN deviceId TEXT NOT NULL DEFAULT 'legacy-unknown'")
        db.execSQL("ALTER TABLE inventory_counts ADD COLUMN locationId INTEGER")
        db.execSQL(
            """UPDATE inventory_counts
            SET globalId = 'legacy:inventory_count:' || id,
                idempotencyKey = 'legacy:inventory_count:' || id,
                correlationId = 'legacy:inventory_count:' || id,
                deviceId = 'legacy-local',
                locationId = (
                    SELECT id FROM storage_locations
                    WHERE isActive = 1
                    ORDER BY CASE WHEN kind = 'PRIMARY' THEN 0 ELSE 1 END, id
                    LIMIT 1
                )""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_inventory_counts_globalId ON inventory_counts(globalId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_inventory_counts_idempotencyKey ON inventory_counts(idempotencyKey)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_counts_correlationId ON inventory_counts(correlationId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_counts_actorId ON inventory_counts(actorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_counts_locationId ON inventory_counts(locationId)")

        db.execSQL("ALTER TABLE stock_transfers ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE stock_transfers ADD COLUMN idempotencyKey TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE stock_transfers ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE stock_transfers ADD COLUMN actorId INTEGER")
        db.execSQL("ALTER TABLE stock_transfers ADD COLUMN deviceId TEXT NOT NULL DEFAULT 'legacy-unknown'")
        db.execSQL("UPDATE stock_transfers SET globalId = 'legacy:stock_transfer:' || id, idempotencyKey = 'legacy:stock_transfer:' || id, correlationId = 'legacy:stock_transfer:' || id WHERE globalId = ''")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_transfers_globalId ON stock_transfers(globalId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_transfers_idempotencyKey ON stock_transfers(idempotencyKey)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_transfers_actorId ON stock_transfers(actorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_transfers_correlationId ON stock_transfers(correlationId)")

        db.execSQL("ALTER TABLE audit_logs ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN actorId INTEGER")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN businessEpochDay INTEGER")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN deviceId TEXT NOT NULL DEFAULT 'legacy-unknown'")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN referenceType TEXT")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN referenceId INTEGER")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN reason TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN beforeSnapshot TEXT")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN afterSnapshot TEXT")
        db.execSQL("ALTER TABLE audit_logs ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL(
            """UPDATE audit_logs
            SET globalId = 'legacy:audit_event:' || id,
                deviceId = 'legacy-local',
                reason = 'LEGACY_BACKFILL',
                correlationId = 'legacy:audit:' || id""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_audit_logs_globalId ON audit_logs(globalId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_actorId ON audit_logs(actorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_businessEpochDay ON audit_logs(businessEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_referenceType_referenceId ON audit_logs(referenceType,referenceId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_correlationId ON audit_logs(correlationId)")

        db.execSQL("ALTER TABLE performance_goals ADD COLUMN targetValueMicros INTEGER")
        db.execSQL(
            """UPDATE performance_goals
            SET targetValueMicros = CAST(ROUND(targetValue * 1000000) AS INTEGER)
            WHERE targetValue IS NOT NULL""",
        )
        db.execSQL("ALTER TABLE performance_scores ADD COLUMN achievedValueMicros INTEGER")
        db.execSQL(
            """UPDATE performance_scores
            SET achievedValueMicros = CAST(ROUND(achievedValue * 1000000) AS INTEGER)
            WHERE achievedValue IS NOT NULL""",
        )

        db.execSQL("ALTER TABLE purchase_requisitions ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE purchase_requisitions ADD COLUMN requestedByActorId INTEGER")
        db.execSQL("ALTER TABLE purchase_requisitions ADD COLUMN approvedByActorId INTEGER")
        db.execSQL("ALTER TABLE purchase_requisitions ADD COLUMN firstApprovedByActorId INTEGER")
        db.execSQL("ALTER TABLE purchase_requisitions ADD COLUMN secondApprovedByActorId INTEGER")
        db.execSQL("ALTER TABLE purchase_requisitions ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL(
            """UPDATE purchase_requisitions
            SET globalId = 'legacy:purchase_requisition:' || id,
                correlationId = 'legacy:purchase_requisition:' || id""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_purchase_requisitions_globalId ON purchase_requisitions(globalId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisitions_requestedByActorId ON purchase_requisitions(requestedByActorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisitions_approvedByActorId ON purchase_requisitions(approvedByActorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisitions_correlationId ON purchase_requisitions(correlationId)")

        db.execSQL("ALTER TABLE payroll_runs ADD COLUMN globalId TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE payroll_runs ADD COLUMN createdByActorId INTEGER")
        db.execSQL("ALTER TABLE payroll_runs ADD COLUMN approvedByActorId INTEGER")
        db.execSQL("ALTER TABLE payroll_runs ADD COLUMN correlationId TEXT NOT NULL DEFAULT ''")
        db.execSQL(
            """UPDATE payroll_runs
            SET globalId = 'legacy:payroll_run:' || id,
                correlationId = 'legacy:payroll_run:' || id""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payroll_runs_globalId ON payroll_runs(globalId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_payroll_runs_status ON payroll_runs(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_payroll_runs_createdByActorId ON payroll_runs(createdByActorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_payroll_runs_approvedByActorId ON payroll_runs(approvedByActorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_payroll_runs_correlationId ON payroll_runs(correlationId)")

        db.execSQL(
            """CREATE TABLE IF NOT EXISTS inventory_waste_documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                globalId TEXT NOT NULL DEFAULT '',
                idempotencyKey TEXT NOT NULL,
                correlationId TEXT NOT NULL,
                itemId INTEGER NOT NULL,
                locationId INTEGER NOT NULL,
                quantityMicros INTEGER NOT NULL,
                valueRial INTEGER NOT NULL,
                wasteEpochDay INTEGER NOT NULL,
                reason TEXT NOT NULL,
                notes TEXT NOT NULL,
                actorId INTEGER NOT NULL,
                deviceId TEXT NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(itemId) REFERENCES inventory_items(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
                FOREIGN KEY(locationId) REFERENCES storage_locations(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )""",
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_inventory_waste_documents_globalId ON inventory_waste_documents(globalId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_inventory_waste_documents_idempotencyKey ON inventory_waste_documents(idempotencyKey)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_waste_documents_itemId ON inventory_waste_documents(itemId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_waste_documents_locationId ON inventory_waste_documents(locationId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_waste_documents_wasteEpochDay ON inventory_waste_documents(wasteEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_waste_documents_actorId ON inventory_waste_documents(actorId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_waste_documents_correlationId ON inventory_waste_documents(correlationId)")

        installPostedJournalGuards(db)
        installStockMovementGuards(db)
        installInventoryCountGuards(db)
        installWasteDocumentGuards(db)
        installStockTransferGuards(db)
        installAuditLogGuards(db)
    }
}
