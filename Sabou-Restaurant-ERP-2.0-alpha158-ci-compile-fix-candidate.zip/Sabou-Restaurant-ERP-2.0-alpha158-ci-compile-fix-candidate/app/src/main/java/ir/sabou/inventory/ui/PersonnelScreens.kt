@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft
import ir.sabou.inventory.domain.personnel.PayrollPolicyDraft
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PayrollStatus
import ir.sabou.inventory.domain.personnel.PayrollReversalDraft
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.domain.treasury.TreasuryChannel

@Composable
fun PersonnelScreen(
    state: PersonnelUiState,
    requestedProfileEmployeeId: Long?,
    onProfileRequestConsumed: () -> Unit,
    performanceState: PerformanceUiState,
    onSaveEmployee: (Long?, EmployeeDraft) -> Unit,
    onDeactivate: (Long) -> Unit,
    onSaveAttendance: (Long?, AttendanceDraft) -> Unit,
    onPostPayroll: (PayrollDraft) -> Unit,
    onApprovePayroll: (Long) -> Unit,
    onReversePayroll: (PayrollReversalDraft) -> Unit,
    onCalculatePayroll: (PayrollDraft) -> Unit,
    onSavePayrollPolicy: (PayrollPolicyDraft) -> Unit,
    onSelectEmployee: (Long?) -> Unit,
    onSaveContract: (Long?, EmployeeContractDraft) -> Unit,
    onPostAdvance: (EmployeeAdvanceDraft) -> Unit,
    onSettleAdvance: (Long, Long, TreasuryChannel, Long) -> Unit,
    onRequestLeave: (LeaveDraft, String) -> Unit,
    onReviewLeave: (LeaveReviewDraft) -> Unit,
    onCancelLeave: (Long) -> Unit,
    onLoadAttendanceSummary: (Long, Long, Long) -> Unit,
    onSavePerformanceGoal: (ir.sabou.inventory.domain.personnel.PerformanceGoalDraft) -> Unit,
    onDeactivatePerformanceGoal: (Long) -> Unit,
    onSubmitPerformanceReview: (ir.sabou.inventory.domain.personnel.PerformanceReviewDraft) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var showEmployee by remember { mutableStateOf(false) }
    var editingEmployee by remember { mutableStateOf<EmployeeRecord?>(null) }
    var showPayroll by remember { mutableStateOf(false) }
    var showAttendance by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }
    var showSummary by remember { mutableStateOf(false) }
    var showContract by remember { mutableStateOf(false) }
    var showAdvance by remember { mutableStateOf(false) }
    var showPayrollPolicy by remember { mutableStateOf(false) }
    var payrollReversalTarget by remember { mutableStateOf<PayrollRecord?>(null) }
    var profileTarget by remember { mutableStateOf<EmployeeRecord?>(null) }
    var employeeQuery by rememberSaveable { mutableStateOf("") }
    var employeeFilter by rememberSaveable { mutableStateOf("ACTIVE") }
    val activeEmployees = state.employees.count { it.isActive }
    val totalPayroll = state.payrolls.filter { it.status == PayrollStatus.PAID }.sumOf { it.netPayRial }
    val monthlyCommitment = state.employees.filter { it.isActive }.sumOf { it.monthlySalaryRial }
    val visibleEmployees = state.employees.filter { employee ->
        businessTextMatches(employeeQuery, employee.name, employee.jobTitle, employee.employeeCode) &&
            businessActivityMatches(employeeFilter, employee.isActive)
    }
    androidx.compose.runtime.LaunchedEffect(requestedProfileEmployeeId, state.employees) {
        val requested = state.employees.firstOrNull { it.id == requestedProfileEmployeeId }
        if (requested != null) {
            onSelectEmployee(requested.id)
            profileTarget = requested
            onProfileRequestConsumed()
        }
    }
    Scaffold(topBar = { ProfessionalTopBar("پرسنل و حقوق", "تیم، تعهد حقوق و پرداخت‌های ماهانه", onBack, "ثبت حقوق") { if (activeEmployees > 0) showPayroll = true } }, floatingActionButton = { ExtendedFloatingActionButton(onClick = { showEmployee = true }) { Text("پرسنل جدید") } }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item { PremiumHero("تعهد ماهانه حقوق", formatMoney(monthlyCommitment), "$activeEmployees نیروی فعال") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("کل پرسنل", state.employees.size.toString(), Modifier.weight(1f)); MetricTile("پرداخت‌شده", formatMoney(totalPayroll), Modifier.weight(1f)) } }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { if (activeEmployees > 0) showAttendance = true }, modifier = Modifier.weight(1f)) { Text("ثبت حضور") }
                    OutlinedButton(onClick = { if (activeEmployees > 0) showPayroll = true }, modifier = Modifier.weight(1f)) { Text("ثبت حقوق") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { showLeave = true }, enabled = activeEmployees > 0, modifier = Modifier.weight(1f)) { Text("درخواست مرخصی") }
                    OutlinedButton(onClick = { showSummary = true }, enabled = activeEmployees > 0, modifier = Modifier.weight(1f)) { Text("گزارش حضور") }
                }
            }
            item {
                OutlinedButton(onClick = { showPayrollPolicy = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (state.payrollPolicies.isEmpty()) "تعریف سیاست محاسبه حقوق" else "سیاست‌های حقوق (${state.payrollPolicies.size})")
                }
            }
            if (state.pendingLeaves.isNotEmpty()) {
                item { SectionHeading("مرخصی‌های در انتظار", "تأیید یا رد درخواست‌ها") }
                items(state.pendingLeaves, key = { "leave-${it.id}" }) { leave ->
                    val employee = state.employees.firstOrNull { it.id == leave.employeeId }
                    Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(employee?.name ?: "پرسنل", fontWeight = FontWeight.Bold)
                        Text("${epochDayToPersian(leave.startEpochDay).display()} تا ${epochDayToPersian(leave.endEpochDay).display()}")
                        Row { TextButton(onClick = { onReviewLeave(LeaveReviewDraft(leave.id, "APPROVE", "مدیر")) }) { Text("تأیید") }; TextButton(onClick = { onReviewLeave(LeaveReviewDraft(leave.id, "REJECT", "مدیر")) }) { Text("رد") }; TextButton(onClick = { onCancelLeave(leave.id) }) { Text("لغو") } }
                    } }
                }
            }
            item { SectionHeading("حضور و غیاب اخیر", "ورود، خروج، تأخیر و اضافه‌کاری") }
            if (state.attendance.isEmpty()) item { EmptyStatePanel("رکورد حضوری وجود ندارد", "ورود و خروج روزانه را ثبت کنید.") }
            items(state.attendance.take(10), key = { "attendance-${it.id}" }) { row ->
                val employeeName = state.employees.firstOrNull { it.id == row.employeeId }?.name ?: "پرسنل"
                Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(employeeName, fontWeight = FontWeight.Black); StatusPill(row.status) }
                        CompactInfoRow("تاریخ", epochDayToPersian(row.workEpochDay).display())
                        if (row.checkInMinute != null && row.checkOutMinute != null) {
                            CompactInfoRow("ورود / خروج", "${formatMinuteOfDay(row.checkInMinute)} / ${formatMinuteOfDay(row.checkOutMinute)}")
                        }
                        CompactInfoRow("کارکرد", "${row.workedMinutes} دقیقه")
                        CompactInfoRow("تأخیر / اضافه‌کاری", "${row.lateMinutes} / ${row.overtimeMinutes} دقیقه")
                    }
                }
            }
            item { SectionHeading("اعضای تیم", "اطلاعات شغلی و حقوق پایه") }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PremiumSearchField(employeeQuery, { employeeQuery = it }, "نام، سمت یا کد پرسنلی")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(employeeFilter == "ACTIVE", { employeeFilter = "ACTIVE" }, { Text("فعال") })
                        FilterChip(employeeFilter == "ALL", { employeeFilter = "ALL" }, { Text("همه") })
                        FilterChip(employeeFilter == "INACTIVE", { employeeFilter = "INACTIVE" }, { Text("غیرفعال") })
                    }
                    Text("${visibleEmployees.size} نفر نمایش داده می‌شود", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item {
                PerformanceSection(
                    state = performanceState,
                    employees = state.employees,
                    onSaveGoal = onSavePerformanceGoal,
                    onDeactivateGoal = onDeactivatePerformanceGoal,
                    onSubmitReview = onSubmitPerformanceReview,
                )
            }
            if (state.employees.isEmpty()) item { EmptyStatePanel("هنوز پرسنلی ثبت نشده", "اولین عضو تیم را اضافه کنید.") }
            if (state.employees.isNotEmpty() && visibleEmployees.isEmpty()) item { EmptyStatePanel("پرسنلی با این فیلتر پیدا نشد", "فیلترها را تغییر دهید یا عبارت دیگری وارد کنید.") }
            items(visibleEmployees, key = { personnelEmployeeListKey(it.id) }) { employee ->
                val employeePaidTotal = state.payrolls.filter { it.employeeId == employee.id && it.status == PayrollStatus.PAID }.sumOf { it.netPayRial }
                Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) { Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(employee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black); Text(employee.jobTitle, color = MaterialTheme.colorScheme.onSurfaceVariant) }; StatusPill(if (employee.isActive) "فعال" else "غیرفعال") }
                        if (employee.fatherName.isNotBlank()) CompactInfoRow("نام پدر", employee.fatherName)
                        employee.employeeCode?.takeIf { it.isNotBlank() }?.let { CompactInfoRow("کد پرسنلی", it) }
                        if (employee.branchName.isNotBlank()) CompactInfoRow("شعبه", employee.branchName)
                        CompactInfoRow("حقوق پایه", formatMoney(employee.monthlySalaryRial), true)
                        CompactInfoRow("مجموع حقوق پرداخت‌شده", formatMoney(employeePaidTotal), true)
                        if (employee.phone.isNotBlank()) CompactInfoRow("تماس", employee.phone)
                        employee.nationalId?.let { CompactInfoRow("کد ملی", it) }
                        employee.birthEpochDay?.let { CompactInfoRow("تاریخ تولد", epochDayToPersian(it).display()) }
                        employee.hireEpochDay?.let { CompactInfoRow("تاریخ استخدام", epochDayToPersian(it).display()) }
                        employee.insuranceNumber?.takeIf { it.isNotBlank() }?.let { CompactInfoRow("شماره بیمه", it) }
                        employee.bankCard?.takeIf { it.isNotBlank() }?.let { CompactInfoRow("شماره کارت", it.chunked(4).joinToString(" ")) }
                        if (employee.address.isNotBlank()) CompactInfoRow("آدرس", employee.address)
                        if (employee.emergencyContact.isNotBlank()) CompactInfoRow("تماس اضطراری", employee.emergencyContact)
                        if (employee.isActive) OutlinedButton(onClick = { editingEmployee = employee }, modifier = Modifier.fillMaxWidth()) { Text("ویرایش اطلاعات پرسنل") }
                        if (employee.isActive) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onSelectEmployee(employee.id); showContract = true }, modifier = Modifier.weight(1f)) { Text("قرارداد") }
                            OutlinedButton(onClick = { onSelectEmployee(employee.id); showAdvance = true }, modifier = Modifier.weight(1f)) { Text("مساعده") }
                        }
                        OutlinedButton(onClick = { onSelectEmployee(employee.id); profileTarget = employee }, modifier = Modifier.fillMaxWidth()) { Text("پروفایل عملیاتی و خط مالی") }
                        if (employee.isActive) OutlinedButton(onClick = { onDeactivate(employee.id) }, modifier = Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)) { Text("غیرفعال‌کردن", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            item { SectionHeading("سوابق پرداخت", "آخرین حقوق‌های ثبت‌شده") }
            if (state.payrolls.isEmpty()) item { EmptyStatePanel("سابقه پرداختی وجود ندارد", "بعد از ثبت حقوق، سوابق اینجا دیده می‌شوند.") }
            items(state.payrolls, key = { personnelPayrollListKey(it.id) }) { payroll ->
                Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text(payroll.employeeName, fontWeight = FontWeight.Black); Text("دوره ${payroll.periodYear}/${payroll.periodMonth} · نسخه ${payroll.revisionNo}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; StatusPill(when(payroll.status){PayrollStatus.REVERSED->"باطل‌شده";PayrollStatus.PENDING_APPROVAL->"منتظر تأیید";PayrollStatus.PAID->"پرداخت‌شده";PayrollStatus.LEGACY_UNKNOWN->"نیازمند بررسی"}) }
                        CompactInfoRow("خالص پرداختی", formatMoney(payroll.netPayRial), true)
                        payroll.reversalEpochDay?.let { Text("ابطال در ${epochDayToPersian(it).display()} · ${payroll.reversalReason}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        OutlinedButton(
                            onClick = { printPayrollSlip(context, payroll) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("چاپ فیش حقوقی / PDF") }
                        if (payroll.status == PayrollStatus.PAID) {
                            TextButton(onClick = { payrollReversalTarget = payroll }, modifier = Modifier.fillMaxWidth()) { Text("ابطال فیش و صدور سند معکوس", color = MaterialTheme.colorScheme.error) }
                        }
                        if (payroll.status == PayrollStatus.PENDING_APPROVAL) Button(onClick = { onApprovePayroll(payroll.id) }, modifier = Modifier.fillMaxWidth()) { Text("تأیید نهایی و پرداخت") }
                    }
                }
            }
        }
    }
    if (showEmployee) EmployeeDialog(null, { showEmployee=false }) { onSaveEmployee(null,it); showEmployee=false }
    editingEmployee?.let { employee ->
        EmployeeDialog(employee, { editingEmployee = null }) { onSaveEmployee(employee.id, it); editingEmployee = null }
    }
    if (showAttendance) AttendanceDialog(state, { showAttendance=false }) { onSaveAttendance(null, it); showAttendance=false }
    if (showPayroll) PayrollDialog(state, { showPayroll=false }, onCalculatePayroll) { onPostPayroll(it); showPayroll=false }
    if (showLeave) LeaveDialog(state, { showLeave=false }) { onRequestLeave(it, "مدیر"); showLeave=false }
    if (showSummary) AttendanceSummaryDialog(state, { showSummary=false }, onLoadAttendanceSummary)
    if (showContract) ContractDialog(state, { showContract=false; onSelectEmployee(null) }) { onSaveContract(null, it); showContract=false; onSelectEmployee(null) }
    if (showAdvance) AdvanceDialog(state, { showAdvance=false; onSelectEmployee(null) }, onSettleAdvance) { onPostAdvance(it); showAdvance=false; onSelectEmployee(null) }
    if (showPayrollPolicy) PayrollPolicyDialog({ showPayrollPolicy = false }) { onSavePayrollPolicy(it); showPayrollPolicy = false }
    profileTarget?.let { employee ->
        EmployeeOperationalProfileDialog(employee, state, { profileTarget = null; onSelectEmployee(null) })
    }
    payrollReversalTarget?.let { payroll ->
        PayrollReversalDialog(payroll, { payrollReversalTarget = null }) {
            onReversePayroll(it)
            payrollReversalTarget = null
        }
    }
}

@Composable
private fun EmployeeOperationalProfileDialog(employee: EmployeeRecord, state: PersonnelUiState, onDismiss: () -> Unit) {
    val payrolls = state.payrolls.filter { it.employeeId == employee.id }.sortedByDescending { it.paymentEpochDay }
    val paid = payrolls.filter { it.status == PayrollStatus.PAID }.sumOf { it.netPayRial }
    val employeeAdvances = state.advances.filter { it.employeeId == employee.id }
    val openAdvance = employeeAdvances.filter { it.status == "OPEN" }.sumOf { it.remainingAmountRial }
    val attendance = state.attendance.filter { it.employeeId == employee.id }.sortedByDescending { it.workEpochDay }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(employee.name) },
        text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("پروفایل عملیاتی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                CompactInfoRow("سمت", employee.jobTitle)
                CompactInfoRow("وضعیت", if (employee.isActive) "فعال" else "غیرفعال")
                CompactInfoRow("حقوق پایه", formatMoney(employee.monthlySalaryRial), true)
                CompactInfoRow("کل حقوق پرداخت‌شده", formatMoney(paid), true)
                CompactInfoRow("مانده مساعده", formatMoney(openAdvance), openAdvance > 0)
                CompactInfoRow("قراردادهای ثبت‌شده", state.contracts.size.toString())
                Text("خط مالی اخیر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                if (payrolls.isEmpty() && employeeAdvances.isEmpty()) Text("رویداد مالی ثبت نشده است.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                payrolls.take(6).forEach { payroll ->
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            Text("حقوق ${payroll.periodYear}/${payroll.periodMonth}", fontWeight = FontWeight.Bold)
                            Text("${formatMoney(payroll.netPayRial)} · ${when (payroll.status) { PayrollStatus.PENDING_APPROVAL -> "منتظر تأیید"; PayrollStatus.REVERSED -> "باطل‌شده"; PayrollStatus.PAID -> "پرداخت‌شده"; PayrollStatus.LEGACY_UNKNOWN -> "نیازمند بررسی" }}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                employeeAdvances.take(6).forEach { advance ->
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.tertiaryContainer) {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            Text("مساعده · ${epochDayToPersian(advance.advanceEpochDay).display()}", fontWeight = FontWeight.Bold)
                            Text("اصل ${formatMoney(advance.amountRial)} · مانده ${formatMoney(advance.remainingAmountRial)}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                Text("حضور و کارکرد اخیر", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                if (attendance.isEmpty()) Text("رکورد حضور ثبت نشده است.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                attendance.take(8).forEach { record ->
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(epochDayToPersian(record.workEpochDay).display(), fontWeight = FontWeight.Bold)
                                StatusPill(record.status)
                            }
                            Text("کارکرد ${record.workedMinutes} · تأخیر ${record.lateMinutes} · اضافه‌کاری ${record.overtimeMinutes} دقیقه", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}

@Composable
private fun PayrollReversalDialog(payroll: PayrollRecord, onDismiss: () -> Unit, onConfirm: (PayrollReversalDraft) -> Unit) {
    var day by remember(payroll.id) { mutableLongStateOf(maxOf(currentEpochDay(), payroll.paymentEpochDay)) }
    var reason by remember(payroll.id) { mutableStateOf("") }
    var error by remember(payroll.id) { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ابطال قطعی فیش حقوق") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("سند پرداخت معکوس و تخصیص مساعده آزاد می‌شود. فیش قبلی حذف نمی‌شود و نسخه اصلاحی با شماره جدید قابل ثبت خواهد بود.")
            Text("${payroll.employeeName} · ${payroll.periodYear}/${payroll.periodMonth} · ${formatMoney(payroll.netPayRial)}", fontWeight = FontWeight.Bold)
            PersianDateField("تاریخ ابطال", day, { day = it })
            OutlinedTextField(reason, { reason = it }, label = { Text("دلیل ابطال") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        } },
        confirmButton = { Button(onClick = {
            runCatching { PayrollReversalDraft(payroll.id, day, reason).validated(payroll.paymentEpochDay) }
                .onSuccess(onConfirm).onFailure { error = it.message }
        }) { Text("ابطال و صدور سند") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun EmployeeDialog(existing: EmployeeRecord?, onDismiss: () -> Unit, onSave: (EmployeeDraft) -> Unit) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var fatherName by remember(existing?.id) { mutableStateOf(existing?.fatherName.orEmpty()) }
    var job by remember(existing?.id) { mutableStateOf(existing?.jobTitle.orEmpty()) }
    var phone by remember(existing?.id) { mutableStateOf(existing?.phone.orEmpty()) }
    var salary by remember(existing?.id) { mutableStateOf(existing?.monthlySalaryRial?.let(::formatMoneyInputFromRial).orEmpty()) }
    var nationalId by remember(existing?.id) { mutableStateOf(existing?.nationalId.orEmpty()) }
    var employeeCode by remember(existing?.id) { mutableStateOf(existing?.employeeCode.orEmpty()) }
    var branchName by remember(existing?.id) { mutableStateOf(existing?.branchName.orEmpty()) }
    var insuranceNumber by remember(existing?.id) { mutableStateOf(existing?.insuranceNumber.orEmpty()) }
    var bankCard by remember(existing?.id) { mutableStateOf(existing?.bankCard.orEmpty()) }
    var address by remember(existing?.id) { mutableStateOf(existing?.address.orEmpty()) }
    var emergencyContact by remember(existing?.id) { mutableStateOf(existing?.emergencyContact.orEmpty()) }
    var birthDate by remember(existing?.id) { mutableStateOf(existing?.birthEpochDay) }
    var hireDate by remember(existing?.id) { mutableLongStateOf(existing?.hireEpochDay ?: currentEpochDay()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "ثبت پرسنل جدید" else "ویرایش اطلاعات پرسنل") },
        text = {
            Column(
                Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedTextField(name, { name = it }, label = { Text("نام و نام خانوادگی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(fatherName, { fatherName = it }, label = { Text("نام پدر") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(job, { job = it }, label = { Text("عنوان شغلی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(employeeCode, { employeeCode = it.take(30) }, label = { Text("کد پرسنلی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(branchName, { branchName = it.take(80) }, label = { Text("نام شعبه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(nationalId, { nationalId = it.filter(Char::isDigit).take(10) }, label = { Text("کد ملی (۱۰ رقم)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OptionalPersianDateField("تاریخ تولد", birthDate, { birthDate = it })
                PersianDateField("تاریخ استخدام", hireDate, { hireDate = it })
                OutlinedTextField(
                    phone,
                    { phone = it.filter { ch -> ch.isDigit() || ch == '+' }.take(14) },
                    label = { Text("شماره تماس") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(insuranceNumber, { insuranceNumber = it.take(30) }, label = { Text("شماره بیمه") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(bankCard, { bankCard = it.filter(Char::isDigit).take(16) }, label = { Text("شماره کارت بانکی (۱۶ رقم)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(emergencyContact, { emergencyContact = it.take(80) }, label = { Text("تماس اضطراری") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(address, { address = it.take(300) }, label = { Text("آدرس") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    salary,
                    { salary = formatMoneyInput(it) },
                    label = { Text("حقوق پایه (${currencyUnitLabel()})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching {
                    EmployeeDraft(
                        name = name,
                        fatherName = fatherName,
                        jobTitle = job,
                        phone = phone,
                        monthlySalaryRial = parseMoneyInputOrZero(salary),
                        nationalId = nationalId,
                        birthEpochDay = birthDate,
                        hireEpochDay = hireDate,
                        employeeCode = employeeCode,
                        branchName = branchName,
                        insuranceNumber = insuranceNumber,
                        bankCard = bankCard,
                        address = address,
                        emergencyContact = emergencyContact,
                    ).validated()
                }
                    .onSuccess(onSave)
                    .onFailure { error = it.message ?: "اطلاعات پرسنل معتبر نیست." }
            }) { Text(if (existing == null) "ذخیره پرسنل" else "ذخیره تغییرات") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun AttendanceDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (AttendanceDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }
    var selected by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    val today = remember { currentEpochDay() }
    var workDay by remember { mutableLongStateOf(today) }
    var checkIn by remember { mutableStateOf("08:00") }
    var checkOut by remember { mutableStateOf("16:00") }
    var status by remember { mutableStateOf("PRESENT") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("ثبت حضور روزانه") },
        text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            error?.let { MessageCard(it, isError = true) }
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(active.firstOrNull { it.id == selected }?.name ?: "انتخاب پرسنل") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { active.forEach { employee -> DropdownMenuItem(text = { Text(employee.name) }, onClick = { selected = employee.id; expanded = false }) } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { status = "PRESENT" }, modifier = Modifier.weight(1f)) { Text(if (status == "PRESENT") "✓ حاضر" else "حاضر") }
                OutlinedButton(onClick = { status = "ABSENT" }, modifier = Modifier.weight(1f)) { Text(if (status == "ABSENT") "✓ غایب" else "غایب") }
            }
            if (status == "PRESENT") {
                ClockField(checkIn, { checkIn = it }, "ساعت ورود")
                ClockField(checkOut, { checkOut = it }, "ساعت خروج")
            }
            PersianDateField("تاریخ حضور", workDay, { workDay = it })
            OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                AttendanceDraft(
                    selected,
                    workDay,
                    status,
                    if (status == "PRESENT") parseClockMinute(checkIn) else null,
                    if (status == "PRESENT") parseClockMinute(checkOut) else null,
                    notes = notes,
                ).validated()
            }.onSuccess(onSave).onFailure { error = it.message ?: "اطلاعات حضور معتبر نیست." }
        }) { Text("ذخیره حضور") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayrollPolicyDialog(onDismiss: () -> Unit, onSave: (PayrollPolicyDraft) -> Unit) {
    var title by remember { mutableStateOf("سیاست استاندارد حقوق") }
    var from by remember { mutableLongStateOf(currentEpochDay()) }
    var to by remember { mutableStateOf<Long?>(null) }
    var overtimeRate by remember { mutableStateOf("") }
    var absenceRate by remember { mutableStateOf("") }
    var lateRate by remember { mutableStateOf("0") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سیاست نسخه‌دار حقوق") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            MessageCard("سیاست پس از ثبت و استفاده در فیش تغییر نمی‌کند. برای نرخ‌های جدید، نسخه‌ای با بازه بدون هم‌پوشانی بسازید.")
            error?.let { MessageCard(it, true) }
            OutlinedTextField(title, { title = it.take(80) }, label = { Text("عنوان سیاست") }, modifier = Modifier.fillMaxWidth())
            PersianDateField("شروع اعتبار", from, { from = it })
            OptionalPersianDateField("پایان اعتبار", to, { to = it }, defaultEpochDay = from)
            MoneyField(overtimeRate, { overtimeRate = it }, "نرخ هر ساعت اضافه‌کار (${currencyUnitLabel()})")
            MoneyField(absenceRate, { absenceRate = it }, "کسر هر روز غیبت (${currencyUnitLabel()})")
            MoneyField(lateRate, { lateRate = it }, "کسر هر دقیقه تأخیر (${currencyUnitLabel()})")
        } },
        confirmButton = { Button(onClick = {
            runCatching { PayrollPolicyDraft(title, from, to, parseMoneyInputOrZero(overtimeRate), parseMoneyInputOrZero(absenceRate), parseMoneyInputOrZero(lateRate)).validated() }
                .onSuccess(onSave).onFailure { error = it.message }
        }) { Text("ثبت نسخه سیاست") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayrollDialog(state: PersonnelUiState, onDismiss: () -> Unit, onCalculate: (PayrollDraft) -> Unit, onSave: (PayrollDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }
    var selected by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    val today = remember { currentEpochDay() }
    var periodDay by remember { mutableLongStateOf(today) }
    val payrollPeriod = epochDayToPersian(periodDay)
    var paymentDay by remember { mutableLongStateOf(today) }
    var overtime by remember { mutableStateOf("0") }
    var bonus by remember { mutableStateOf("0") }
    var deductions by remember { mutableStateOf("0") }
    var advanceDeduction by remember { mutableStateOf("0") }
    var insurance by remember { mutableStateOf("0") }
    var tax by remember { mutableStateOf("0") }
    var paymentMethod by remember { mutableStateOf(TreasuryChannel.BANK) }
    var notes by remember { mutableStateOf("") }
    val commandId = remember { GlobalId.new().value }
    var error by remember { mutableStateOf<String?>(null) }
    val openAdvanceBalance = state.openAdvances
        .filter { it.employeeId == selected }
        .fold(0L) { total, advance -> SignedLongMath.add(total, advance.remainingAmountRial) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت حقوق ماهانه") },
        text = {
            Column(
                Modifier.heightIn(max = 580.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(active.firstOrNull { it.id == selected }?.name ?: "انتخاب پرسنل")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    active.forEach { employee ->
                        DropdownMenuItem(text = { Text(employee.name) }, onClick = { selected = employee.id; advanceDeduction = "0"; expanded = false })
                    }
                }
                PersianDateField("دوره حقوق", periodDay, { periodDay = it })
                MessageCard("اضافه‌کار، غیبت و تأخیر از حضور و غیاب همین ماه و سیاست فعال محاسبه می‌شوند؛ فیلدهای زیر فقط اصلاح دستی هستند.")
                MoneyField(overtime, { overtime = it }, "اصلاح دستی اضافه‌کار (${currencyUnitLabel()})")
                MoneyField(bonus, { bonus = it }, "پاداش (${currencyUnitLabel()})")
                MoneyField(deductions, { deductions = it }, "کسورات دستی (${currencyUnitLabel()})")
                MessageCard("مانده مساعده باز: ${formatMoney(openAdvanceBalance)}")
                MoneyField(advanceDeduction, { advanceDeduction = it }, "کسر مساعده این ماه (${currencyUnitLabel()})")
                if (openAdvanceBalance > 0L) {
                    OutlinedButton(
                        onClick = { advanceDeduction = formatMoneyInputFromRial(openAdvanceBalance) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("کسر کل مانده باز") }
                }
                MoneyField(insurance, { insurance = it }, "بیمه (${currencyUnitLabel()})")
                MoneyField(tax, { tax = it }, "مالیات (${currencyUnitLabel()})")
                PersianDateField("تاریخ پرداخت", paymentDay, { paymentDay = it })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { paymentMethod = TreasuryChannel.BANK }, modifier = Modifier.weight(1f)) { Text(if (paymentMethod == TreasuryChannel.BANK) "✓ بانکی" else "بانکی") }
                    OutlinedButton(onClick = { paymentMethod = TreasuryChannel.CASH }, modifier = Modifier.weight(1f)) { Text(if (paymentMethod == TreasuryChannel.CASH) "✓ نقدی" else "نقدی") }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                state.payrollPreview?.let { preview ->
                    MessageCard("ناخالص: ${formatMoney(preview.grossPayRial)} • کسورات: ${formatMoney(preview.totalDeductionsRial)} • خالص: ${formatMoney(preview.netPayRial)}")
                    if (preview.payrollPolicyId != null) {
                        Text("خودکار از حضور: اضافه‌کار ${formatMoney(preview.automaticOvertimeRial)} • کسر غیبت/تأخیر ${formatMoney(preview.attendanceDeductionRial)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val draft = PayrollDraft(
                    employeeId = selected,
                    periodYear = payrollPeriod.year,
                    periodMonth = payrollPeriod.month,
                    overtimeRial = parseMoneyInputOrZero(overtime),
                    bonusRial = parseMoneyInputOrZero(bonus),
                    deductionsRial = parseMoneyInputOrZero(deductions),
                    advanceDeductionRial = parseMoneyInputOrZero(advanceDeduction),
                    periodStartEpochDay = PersianDate(payrollPeriod.year, payrollPeriod.month, 1).toEpochDay(),
                    periodEndEpochDay = PersianDate(payrollPeriod.year, payrollPeriod.month, daysInPersianMonth(payrollPeriod.year, payrollPeriod.month)).toEpochDay(),
                    insuranceRial = parseMoneyInputOrZero(insurance),
                    taxRial = parseMoneyInputOrZero(tax),
                    paymentEpochDay = paymentDay,
                    paymentMethod = paymentMethod,
                    notes = notes,
                    commandId = commandId,
                )
                runCatching { draft.validated() }
                    .onSuccess(onSave)
                    .onFailure { error = it.message ?: "اطلاعات حقوق معتبر نیست." }
            }) { Text("ثبت و صدور سند") }
        },
        dismissButton = { Row { TextButton(onClick = {
            val draft = PayrollDraft(selected, payrollPeriod.year, payrollPeriod.month, parseMoneyInputOrZero(overtime), parseMoneyInputOrZero(bonus), deductionsRial = parseMoneyInputOrZero(deductions), insuranceRial = parseMoneyInputOrZero(insurance), taxRial = parseMoneyInputOrZero(tax), advanceDeductionRial = parseMoneyInputOrZero(advanceDeduction), periodStartEpochDay = PersianDate(payrollPeriod.year, payrollPeriod.month, 1).toEpochDay(), periodEndEpochDay = PersianDate(payrollPeriod.year, payrollPeriod.month, daysInPersianMonth(payrollPeriod.year, payrollPeriod.month)).toEpochDay(), paymentEpochDay = paymentDay, paymentMethod = paymentMethod, notes = notes, commandId = commandId)
            runCatching { draft.validated() }.onSuccess(onCalculate).onFailure { error = it.message }
        }) { Text("محاسبه") }; TextButton(onClick = onDismiss) { Text("انصراف") } } },
    )
}

@Composable
private fun LeaveDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (LeaveDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }; var employeeId by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }; var expanded by remember { mutableStateOf(false) }; var start by remember { mutableLongStateOf(currentEpochDay()) }; var end by remember { mutableLongStateOf(currentEpochDay()) }; var type by remember { mutableStateOf("PAID") }; var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("درخواست مرخصی")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(active.firstOrNull{it.id==employeeId}?.name?:"انتخاب پرسنل")}; DropdownMenu(expanded,{expanded=false}){active.forEach{e->DropdownMenuItem(text={Text(e.name)},onClick={employeeId=e.id;expanded=false})}}; PersianDateField("از تاریخ",start,{start=it}); PersianDateField("تا تاریخ",end,{end=it}); Row{listOf("PAID" to "استحقاقی","SICK" to "استعلاجی","UNPAID" to "بدون حقوق").forEach{(v,t)->TextButton(onClick={type=v}){Text(if(type==v)"✓ $t" else t)}}};OutlinedTextField(notes,{notes=it},label={Text("توضیحات")})}},confirmButton={Button(onClick={onSave(LeaveDraft(employeeId,start,end,type,notes))}){Text("ثبت درخواست")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun AttendanceSummaryDialog(state: PersonnelUiState, onDismiss: () -> Unit, onLoad: (Long, Long, Long) -> Unit) {
    val active=state.employees.filter{it.isActive}; var employeeId by remember{mutableStateOf(active.firstOrNull()?.id?:0L)}; var expanded by remember{mutableStateOf(false)}; var from by remember{mutableLongStateOf(currentEpochDay()-30)}; var to by remember{mutableLongStateOf(currentEpochDay())}; val context=LocalContext.current
    AlertDialog(onDismissRequest=onDismiss,title={Text("گزارش حضور")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(active.firstOrNull{it.id==employeeId}?.name?:"انتخاب پرسنل")};DropdownMenu(expanded,{expanded=false}){active.forEach{e->DropdownMenuItem(text={Text(e.name)},onClick={employeeId=e.id;expanded=false})}};PersianDateField("از تاریخ",from,{from=it});PersianDateField("تا تاریخ",to,{to=it});state.attendanceSummary?.let{Text("حاضر: ${it.presentDays} • غیبت: ${it.absentDays} • مرخصی: ${it.leaveDays}\nکارکرد: ${it.workedMinutes} دقیقه • تأخیر: ${it.lateMinutes} • اضافه‌کاری: ${it.overtimeMinutes}",fontWeight=FontWeight.Bold);OutlinedButton(onClick={printAttendanceSummary(context,active.firstOrNull{employee->employee.id==employeeId}?.name?:"پرسنل",it)},modifier=Modifier.fillMaxWidth()){Text("چاپ گزارش حضور / PDF")}}}},confirmButton={Button(onClick={onLoad(employeeId,from,to)}){Text("محاسبه")}},dismissButton={TextButton(onClick=onDismiss){Text("بستن")}})
}

@Composable
private fun ContractDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (EmployeeContractDraft) -> Unit) {
    val id=state.selectedEmployeeId?:0L; var type by remember{mutableStateOf("تمام‌وقت")}; var start by remember{mutableLongStateOf(currentEpochDay())}; var end by remember{mutableStateOf<Long?>(null)}; var salary by remember{mutableStateOf(state.employees.firstOrNull{it.id==id}?.monthlySalaryRial?.let(::formatMoneyInputFromRial).orEmpty())}
    AlertDialog(onDismissRequest=onDismiss,title={Text("ثبت قرارداد")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){state.contracts.firstOrNull()?.let{Text("قرارداد فعلی: ${it.contractType} • ${formatMoney(it.baseSalaryRial)}")};OutlinedTextField(type,{type=it},label={Text("نوع قرارداد")});PersianDateField("تاریخ شروع",start,{start=it});OptionalPersianDateField("تاریخ پایان",end,{end=it},defaultEpochDay=start);MoneyField(salary,{salary=it},"حقوق قرارداد")}},confirmButton={Button(onClick={onSave(EmployeeContractDraft(id,type,start,end,parseMoneyInputOrZero(salary)))}){Text("ذخیره قرارداد")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun AdvanceDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSettle: (Long, Long, TreasuryChannel, Long) -> Unit, onSave: (EmployeeAdvanceDraft) -> Unit) {
    val id=state.selectedEmployeeId?:0L; var amount by remember{mutableStateOf("")}; var day by remember{mutableLongStateOf(currentEpochDay())}; var method by remember{mutableStateOf(TreasuryChannel.BANK)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("مساعده پرسنل")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){MoneyField(amount,{amount=it},"مبلغ مساعده (${currencyUnitLabel()})");PersianDateField("تاریخ مساعده",day,{day=it});Row{TextButton(onClick={method=TreasuryChannel.BANK}){Text(if(method==TreasuryChannel.BANK)"✓ بانکی" else "بانکی")};TextButton(onClick={method=TreasuryChannel.CASH}){Text(if(method==TreasuryChannel.CASH)"✓ نقدی" else "نقدی")}};Text("روش انتخاب‌شده برای پرداخت مساعده جدید یا دریافت بازپرداخت استفاده می‌شود.",style=MaterialTheme.typography.bodySmall);state.advances.forEach{a->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("مانده: ${formatMoney(a.remainingAmountRial)}");if(a.status=="OPEN")TextButton(onClick={onSettle(a.id,a.remainingAmountRial,method,currentEpochDay())}){Text("تسویه کامل")}}}}},confirmButton={Button(onClick={onSave(EmployeeAdvanceDraft(id,parseMoneyInputOrZero(amount),day,method))}){Text("ثبت مساعده")}},dismissButton={TextButton(onClick=onDismiss){Text("بستن")}})
}

@Composable
private fun MoneyField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(formatMoneyInput(it)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = modifier,
    )
}

@Composable
private fun ClockField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(normalizeClockInput(it)) },
        label = { Text("$label (HH:mm)") },
        supportingText = { Text("نمونه: 08:30") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
}
