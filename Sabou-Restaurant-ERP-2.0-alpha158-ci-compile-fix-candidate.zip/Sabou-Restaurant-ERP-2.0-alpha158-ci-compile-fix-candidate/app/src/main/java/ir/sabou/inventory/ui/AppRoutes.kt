package ir.sabou.inventory.ui

enum class AppRouteGroup {
    HOME,
    OPERATIONS,
    ACCOUNTING,
    WORKFORCE,
    MANAGEMENT,
    ADMIN,
}

enum class AppScreen(val group: AppRouteGroup) {
    DASHBOARD(AppRouteGroup.HOME),
    PURCHASES(AppRouteGroup.OPERATIONS),
    NEW_PURCHASE(AppRouteGroup.OPERATIONS),
    SUPPLIERS(AppRouteGroup.OPERATIONS),
    INVENTORY(AppRouteGroup.OPERATIONS),
    STOCK_MOVEMENTS(AppRouteGroup.OPERATIONS),
    SALES(AppRouteGroup.OPERATIONS),
    RECIPES(AppRouteGroup.OPERATIONS),
    ACCOUNTING(AppRouteGroup.ACCOUNTING),
    NEW_JOURNAL(AppRouteGroup.ACCOUNTING),
    AUDIT_LOG(AppRouteGroup.MANAGEMENT),
    SECURITY(AppRouteGroup.ADMIN),
    PERSONNEL(AppRouteGroup.WORKFORCE),
    ASSETS(AppRouteGroup.WORKFORCE),
    ALERTS(AppRouteGroup.MANAGEMENT),
    REPORTS(AppRouteGroup.MANAGEMENT),
    GLOBAL_SEARCH(AppRouteGroup.MANAGEMENT),
    SETTINGS(AppRouteGroup.ADMIN),
    MANAGEMENT_CONTROL(AppRouteGroup.MANAGEMENT),
}
