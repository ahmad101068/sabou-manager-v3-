package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "app_alerts",
    indices = [
        Index(value = ["sourceType", "sourceId"], unique = true),
        Index("severity"),
        Index("isRead"),
        Index("isDismissed"),
        Index("dueEpochDay"),
    ],
)
data class AppAlertEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceType: String,
    val sourceId: Long,
    val title: String,
    val message: String,
    val severity: String,
    val dueEpochDay: Long?,
    val isRead: Boolean = false,
    val isDismissed: Boolean = false,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

data class OverdueSaleAlertRow(
    val id: Long,
    val invoiceNo: String,
    val customerName: String,
    val dueEpochDay: Long,
    val outstandingRial: Long,
)

data class OverduePurchaseAlertRow(
    val id: Long,
    val invoiceNo: String,
    val supplierName: String,
    val dueEpochDay: Long,
    val outstandingRial: Long,
)
