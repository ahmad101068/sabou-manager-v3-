package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord

@Composable
internal fun ManagementRoutes(
    screen: AppScreen,
    dashboardState: DashboardSnapshot,
    operationsState: OperationsUiState,
    operations: OperationsViewModel,
    accountingState: AccountingUiState,
    accounting: AccountingViewModel,
    salesState: DailySalesUiState,
    sales: DailySalesViewModel,
    personnelState: PersonnelUiState,
    assetState: AssetUiState,
    managementState: ControlCenterUiState,
    management: ManagementControlViewModel,
    alertState: AlertUiState,
    alerts: AlertViewModel,
    currentUser: AppUserRecord?,
    notificationPermissionGranted: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onRequestEmployeeProfile: (Long?) -> Unit,
    navigate: (AppScreen) -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.AUDIT_LOG -> AuditLogScreen(state = operationsState, onBack = navigateBack)

        AppScreen.MANAGEMENT_CONTROL -> ManagementControlScreen(
            state = managementState,
            inventoryItems = operationsState.inventoryItems,
            employees = personnelState.employees,
            onSetRange = management::setRange,
            onFollowUp = management::followUp,
            onCreateLocation = management::createLocation,
            onRegisterLot = management::registerLot,
            onTransferLot = management::transferLot,
            onSaveBudget = management::saveBudget,
            onRecordSpend = management::recordSpend,
            onSaveLaborPolicy = management::saveLaborPolicy,
            onSaveAvailability = management::saveAvailability,
            onRequestShiftSwap = management::requestShiftSwap,
            onReviewShiftSwap = management::reviewShiftSwap,
            onRecordWorkBreak = management::recordWorkBreak,
            onCloseAccountingPeriod = management::closeAccountingPeriod,
            onReopenAccountingPeriod = management::reopenAccountingPeriod,
            onReconcileSalesCash = management::reconcileSalesCash,
            onBack = navigateBack,
        )

        AppScreen.ALERTS -> AlertCenterScreen(
            state = alertState,
            notificationPermissionGranted = notificationPermissionGranted,
            onRequestNotificationPermission = onRequestNotificationPermission,
            onRefresh = alerts::refresh,
            onRead = alerts::markRead,
            onDismiss = alerts::dismiss,
            onOpenSource = { sourceType, sourceId ->
                if (sourceType == "LOW_STOCK") {
                    operations.selectInventoryItem(sourceId)
                    navigate(AppScreen.INVENTORY)
                } else if (sourceType == "PURCHASE_PAYABLE") {
                    operations.selectPurchase(sourceId)
                    navigate(AppScreen.PURCHASES)
                }
            },
            onClearDismissed = alerts::clearDismissed,
            onBack = navigateBack,
        )

        AppScreen.REPORTS -> ReportsCenterScreen(
            dashboard = dashboardState,
            sales = salesState,
            accounting = accountingState,
            operations = operationsState,
            personnel = personnelState,
            assets = assetState,
            onOpenSales = { navigate(AppScreen.SALES) },
            onOpenAccounting = { navigate(AppScreen.ACCOUNTING) },
            onOpenInventory = { navigate(AppScreen.INVENTORY) },
            onOpenStockMovements = { navigate(AppScreen.STOCK_MOVEMENTS) },
            onOpenPersonnel = { navigate(AppScreen.PERSONNEL) },
            onSetReportRange = { from, to ->
                sales.setReportRange(from, to)
                accounting.setProfitLossRange(from, to)
            },
            onBack = navigateBack,
        )

        AppScreen.GLOBAL_SEARCH -> GlobalSearchScreen(
            currentUser = currentUser,
            operations = operationsState,
            accounting = accountingState,
            personnel = personnelState,
            onOpen = navigate,
            onOpenEntity = { target, key ->
                when {
                    key.startsWith("item-") -> {
                        operations.selectInventoryItem(key.removePrefix("item-").toLongOrNull())
                    }
                    key.startsWith("purchase-") -> {
                        operations.selectPurchase(key.removePrefix("purchase-").toLongOrNull())
                    }
                    key.startsWith("journal-") -> {
                        accounting.selectJournal(key.removePrefix("journal-").toLongOrNull())
                    }
                    key.startsWith("account-") -> accounting.selectLedger(key.removePrefix("account-"))
                    key.startsWith("employee-") -> {
                        onRequestEmployeeProfile(key.removePrefix("employee-").toLongOrNull())
                    }
                    key.startsWith("movement-") -> {
                        operations.selectInventoryItem(
                            key.removePrefix("movement-").substringBefore('-').toLongOrNull(),
                        )
                    }
                }
                navigate(target)
            },
            onBack = navigateBack,
        )

        else -> error("management_route_group_mismatch:${screen.name}")
    }
}
