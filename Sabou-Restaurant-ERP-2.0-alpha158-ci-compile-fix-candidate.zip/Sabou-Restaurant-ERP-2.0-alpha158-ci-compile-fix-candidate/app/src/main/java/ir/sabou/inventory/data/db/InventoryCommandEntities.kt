package ir.sabou.inventory.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import ir.sabou.inventory.core.GlobalId

/** Immutable business document that explains a WASTE stock movement. */
@Entity(
    tableName = "inventory_waste_documents",
    foreignKeys = [
        ForeignKey(
            entity = InventoryItemEntity::class,
            parentColumns = ["id"],
            childColumns = ["itemId"],
            onDelete = ForeignKey.RESTRICT,
        ),
        ForeignKey(
            entity = StorageLocationEntity::class,
            parentColumns = ["id"],
            childColumns = ["locationId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["globalId"], unique = true),
        Index(value = ["idempotencyKey"], unique = true),
        Index("itemId"),
        Index("locationId"),
        Index("wasteEpochDay"),
        Index("actorId"),
        Index("correlationId"),
    ],
)
data class InventoryWasteDocumentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    @ColumnInfo(defaultValue = "''") val globalId: String = GlobalId.new().value,
    val idempotencyKey: String,
    val correlationId: String,
    val itemId: Long,
    val locationId: Long,
    val quantityMicros: Long,
    val valueRial: Long,
    val wasteEpochDay: Long,
    val reason: String,
    val notes: String,
    val actorId: Long,
    val deviceId: String,
    val createdAtEpochMillis: Long,
)
