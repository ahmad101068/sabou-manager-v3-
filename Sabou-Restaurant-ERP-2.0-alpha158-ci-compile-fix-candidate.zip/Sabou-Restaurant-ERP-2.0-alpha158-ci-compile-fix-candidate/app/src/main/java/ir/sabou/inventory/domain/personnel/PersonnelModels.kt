package ir.sabou.inventory.domain.personnel

import ir.sabou.inventory.core.GlobalId
import kotlinx.coroutines.flow.Flow
import ir.sabou.inventory.domain.treasury.TreasuryChannel

data class EmployeeRecord(
    val id: Long,
    val name: String,
    val fatherName: String,
    val jobTitle: String,
    val phone: String,
    val monthlySalaryRial: Long,
    val isActive: Boolean,
    val nationalId: String? = null,
    val birthEpochDay: Long? = null,
    val hireEpochDay: Long? = null,
    val employeeCode: String? = null,
    val branchName: String = "",
    val insuranceNumber: String? = null,
    val bankCard: String? = null,
    val address: String = "",
    val emergencyContact: String = "",
)

data class EmployeeDraft(
    val name: String,
    val fatherName: String,
    val jobTitle: String,
    val phone: String,
    val monthlySalaryRial: Long,
    val nationalId: String = "",
    val birthEpochDay: Long? = null,
    val hireEpochDay: Long? = null,
    val employeeCode: String = "",
    val branchName: String = "",
    val insuranceNumber: String = "",
    val bankCard: String = "",
    val address: String = "",
    val emergencyContact: String = "",
) {
    fun validated(): EmployeeDraft {
        require(name.trim().length >= 2) { "نام پرسنل معتبر نیست." }
        require(jobTitle.trim().isNotEmpty()) { "عنوان شغلی الزامی است." }
        require(monthlySalaryRial >= 0) { "حقوق پایه نمی‌تواند منفی باشد." }
        require(nationalId.isBlank() || (nationalId.length == 10 && nationalId.all(Char::isDigit))) { "کد ملی باید ۱۰ رقم باشد." }
        require(birthEpochDay == null || birthEpochDay > 0) { "تاریخ تولد معتبر نیست." }
        require(hireEpochDay == null || hireEpochDay > 0) { "تاریخ استخدام معتبر نیست." }
        require(bankCard.isBlank() || (bankCard.length == 16 && bankCard.all(Char::isDigit))) { "شماره کارت باید ۱۶ رقم باشد." }
        return copy(
            name = name.trim(), fatherName = fatherName.trim(), jobTitle = jobTitle.trim(), phone = phone.trim(), nationalId = nationalId.trim(),
            employeeCode = employeeCode.trim(), branchName = branchName.trim(), insuranceNumber = insuranceNumber.trim(), bankCard = bankCard.trim(),
            address = address.trim(), emergencyContact = emergencyContact.trim(),
        )
    }
}


data class EmployeeContractRecord(
    val id: Long,
    val employeeId: Long,
    val contractType: String,
    val startEpochDay: Long,
    val endEpochDay: Long?,
    val baseSalaryRial: Long,
    val dailyWorkMinutes: Int,
    val weeklyWorkDays: Int,
    val status: String,
    val notes: String,
)

data class EmployeeContractDraft(
    val employeeId: Long,
    val contractType: String,
    val startEpochDay: Long,
    val endEpochDay: Long?,
    val baseSalaryRial: Long,
    val dailyWorkMinutes: Int = 480,
    val weeklyWorkDays: Int = 6,
    val notes: String = "",
) {
    fun validated(): EmployeeContractDraft {
        require(employeeId > 0) { "پرسنل انتخاب نشده است." }
        require(contractType.trim().isNotEmpty()) { "نوع قرارداد الزامی است." }
        require(startEpochDay > 0) { "تاریخ شروع قرارداد معتبر نیست." }
        require(endEpochDay == null || endEpochDay >= startEpochDay) { "تاریخ پایان قرارداد معتبر نیست." }
        require(baseSalaryRial >= 0) { "حقوق پایه نمی‌تواند منفی باشد." }
        require(dailyWorkMinutes in 1..1440) { "ساعت کار روزانه معتبر نیست." }
        require(weeklyWorkDays in 1..7) { "تعداد روز کاری هفتگی معتبر نیست." }
        return copy(contractType = contractType.trim(), notes = notes.trim())
    }
}

data class EmployeeAdvanceRecord(
    val id: Long,
    val employeeId: Long,
    val amountRial: Long,
    val settledAmountRial: Long,
    val remainingAmountRial: Long,
    val advanceEpochDay: Long,
    val paymentMethod: TreasuryChannel,
    val journalEntryId: Long,
    val status: String,
    val notes: String,
)

data class EmployeeAdvanceDraft(
    val employeeId: Long,
    val amountRial: Long,
    val advanceEpochDay: Long,
    val paymentMethod: TreasuryChannel,
    val notes: String = "",
) {
    fun validated(): EmployeeAdvanceDraft {
        require(employeeId > 0) { "پرسنل انتخاب نشده است." }
        require(amountRial > 0) { "مبلغ مساعده باید بیشتر از صفر باشد." }
        require(advanceEpochDay > 0) { "تاریخ مساعده معتبر نیست." }
        require(paymentMethod in setOf(TreasuryChannel.CASH, TreasuryChannel.BANK)) {
            "personnel_payment_channel_unsupported"
        }
        return copy(notes = notes.trim())
    }
}


data class AttendanceRecord(
    val id: Long,
    val employeeId: Long,
    val workEpochDay: Long,
    val status: String,
    val checkInMinute: Int?,
    val checkOutMinute: Int?,
    val workedMinutes: Int,
    val lateMinutes: Int,
    val overtimeMinutes: Int,
    val notes: String,
)

data class AttendanceDraft(
    val employeeId: Long,
    val workEpochDay: Long,
    val status: String = "PRESENT",
    val checkInMinute: Int? = null,
    val checkOutMinute: Int? = null,
    val scheduledStartMinute: Int = 8 * 60,
    val scheduledEndMinute: Int = 16 * 60,
    val notes: String = "",
) {
    fun validated(): AttendanceDraft {
        require(employeeId > 0) { "پرسنل انتخاب نشده است." }
        require(workEpochDay > 0) { "تاریخ حضور معتبر نیست." }
        require(status in setOf("PRESENT", "ABSENT", "LEAVE", "MISSION", "HOLIDAY")) { "وضعیت حضور معتبر نیست." }
        require(scheduledStartMinute in 0..1439 && scheduledEndMinute in 1..1440 && scheduledEndMinute > scheduledStartMinute) { "ساعت شیفت معتبر نیست." }
        checkInMinute?.let { require(it in 0..1439) { "زمان ورود معتبر نیست." } }
        checkOutMinute?.let { require(it in 1..1440) { "زمان خروج معتبر نیست." } }
        if (status == "PRESENT") {
            require(checkInMinute != null && checkOutMinute != null) { "برای حضور، زمان ورود و خروج الزامی است." }
            require(checkOutMinute > checkInMinute) { "زمان خروج باید بعد از ورود باشد." }
        }
        return copy(notes = notes.trim())
    }
}

data class AttendanceSummary(
    val employeeId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val presentDays: Int,
    val absentDays: Int,
    val leaveDays: Int,
    val missionDays: Int,
    val workedMinutes: Int,
    val lateMinutes: Int,
    val overtimeMinutes: Int,
)

data class LeaveDraft(
    val employeeId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val leaveType: String,
    val notes: String = "",
) {
    fun validated(): LeaveDraft {
        require(employeeId > 0) { "پرسنل انتخاب نشده است." }
        require(startEpochDay > 0 && endEpochDay >= startEpochDay) { "بازه مرخصی معتبر نیست." }
        require(leaveType in setOf("PAID", "UNPAID", "SICK", "HOURLY")) { "نوع مرخصی معتبر نیست." }
        return copy(notes = notes.trim())
    }
}


data class LeaveRecord(
    val id: Long,
    val employeeId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val daysMicros: Long,
    val leaveType: String,
    val status: String,
    val notes: String,
    val requestedBy: String,
    val reviewedBy: String?,
    val reviewNotes: String,
    val reviewedAtEpochMillis: Long?,
)

data class LeaveReviewDraft(
    val leaveId: Long,
    val decision: String,
    val reviewer: String,
    val notes: String = "",
) {
    fun validated(): LeaveReviewDraft {
        require(leaveId > 0) { "درخواست مرخصی معتبر نیست." }
        require(decision in setOf("APPROVE", "REJECT")) { "تصمیم بررسی معتبر نیست." }
        require(reviewer.trim().isNotEmpty()) { "نام تأییدکننده الزامی است." }
        return copy(reviewer = reviewer.trim(), notes = notes.trim())
    }
}

data class AttendancePayrollPolicy(
    val overtimeHourlyRateRial: Long,
    val absenceDailyDeductionRial: Long,
    val lateMinuteDeductionRial: Long = 0,
) {
    fun validated(): AttendancePayrollPolicy {
        require(overtimeHourlyRateRial >= 0) { "نرخ اضافه‌کاری معتبر نیست." }
        require(absenceDailyDeductionRial >= 0) { "نرخ کسر غیبت معتبر نیست." }
        require(lateMinuteDeductionRial >= 0) { "نرخ کسر تأخیر معتبر نیست." }
        return this
    }
}

data class PayrollPolicyRecord(
    val id: Long,
    val title: String,
    val effectiveFromEpochDay: Long,
    val effectiveToEpochDay: Long?,
    val overtimeHourlyRateRial: Long,
    val absenceDailyDeductionRial: Long,
    val lateMinuteDeductionRial: Long,
    val createdBy: String,
)

data class PayrollPolicyDraft(
    val title: String,
    val effectiveFromEpochDay: Long,
    val effectiveToEpochDay: Long? = null,
    val overtimeHourlyRateRial: Long,
    val absenceDailyDeductionRial: Long,
    val lateMinuteDeductionRial: Long = 0,
) {
    fun validated(): PayrollPolicyDraft {
        require(title.trim().length >= 2) { "عنوان سیاست حقوق معتبر نیست." }
        require(effectiveFromEpochDay > 0) { "تاریخ شروع سیاست معتبر نیست." }
        require(effectiveToEpochDay == null || effectiveToEpochDay >= effectiveFromEpochDay) { "بازه سیاست معتبر نیست." }
        AttendancePayrollPolicy(overtimeHourlyRateRial, absenceDailyDeductionRial, lateMinuteDeductionRial).validated()
        return copy(title = title.trim())
    }
}

data class AttendancePayrollAdjustment(
    val overtimeRial: Long,
    val absenceDeductionRial: Long,
    val lateDeductionRial: Long,
    val totalAttendanceDeductionRial: Long,
)

data class PayrollDraft(
    val employeeId: Long,
    val periodYear: Int,
    val periodMonth: Int,
    val overtimeRial: Long = 0,
    val bonusRial: Long = 0,
    val allowancesRial: Long = 0,
    val deductionsRial: Long = 0,
    val insuranceRial: Long = 0,
    val taxRial: Long = 0,
    val advanceDeductionRial: Long = 0,
    val periodStartEpochDay: Long = 0,
    val periodEndEpochDay: Long = 0,
    val paymentEpochDay: Long,
    val paymentMethod: TreasuryChannel,
    val notes: String = "",
    val commandId: String = GlobalId.new().value,
) {
    fun validated(): PayrollDraft {
        val normalizedCommandId = GlobalId.parse(commandId).value
        require(employeeId > 0) { "پرسنل انتخاب نشده است." }
        require(periodYear in 1300..1600) { "سال دوره معتبر نیست." }
        require(periodMonth in 1..12) { "ماه دوره معتبر نیست." }
        require(listOf(overtimeRial, bonusRial, allowancesRial, deductionsRial, insuranceRial, taxRial, advanceDeductionRial).all { it >= 0 }) {
            "مبالغ حقوق نمی‌توانند منفی باشند."
        }
        require(paymentEpochDay > 0) { "تاریخ پرداخت معتبر نیست." }
        require(paymentMethod in setOf(TreasuryChannel.CASH, TreasuryChannel.BANK)) {
            "payroll_payment_channel_unsupported"
        }
        require(
            (periodStartEpochDay == 0L && periodEndEpochDay == 0L) ||
                (periodStartEpochDay > 0L && periodEndEpochDay >= periodStartEpochDay),
        ) { "بازه حضور دوره حقوق معتبر نیست." }
        return copy(notes = notes.trim(), commandId = normalizedCommandId)
    }
}

data class PayrollCalculation(
    val baseSalaryRial: Long,
    val overtimeRial: Long,
    val bonusRial: Long,
    val allowancesRial: Long,
    val grossPayRial: Long,
    val deductionsRial: Long,
    val insuranceRial: Long,
    val taxRial: Long,
    val advanceDeductionRial: Long,
    val totalDeductionsRial: Long,
    val netPayRial: Long,
    val automaticOvertimeRial: Long = 0,
    val attendanceDeductionRial: Long = 0,
    val payrollPolicyId: Long? = null,
)

enum class PayrollStatus(val storedValue: String) {
    PENDING_APPROVAL("PENDING_APPROVAL"),
    PAID("PAID"),
    REVERSED("REVERSED"),
    LEGACY_UNKNOWN("LEGACY_UNKNOWN");

    companion object {
        fun fromStoredValue(value: String): PayrollStatus =
            entries.firstOrNull { it.storedValue == value } ?: LEGACY_UNKNOWN
    }
}

data class PayrollRecord(
    val id: Long,
    val employeeId: Long,
    val employeeName: String,
    val periodYear: Int,
    val periodMonth: Int,
    val revisionNo: Int,
    val grossPayRial: Long,
    val netPayRial: Long,
    val paymentEpochDay: Long,
    val paymentMethod: TreasuryChannel,
    val status: PayrollStatus,
    val reversalEpochDay: Long? = null,
    val reversalReason: String = "",
)

data class PayrollReversalDraft(
    val payrollId: Long,
    val reversalEpochDay: Long,
    val reason: String,
) {
    fun validated(paymentEpochDay: Long): PayrollReversalDraft {
        val normalized = reason.trim()
        require(payrollId > 0) { "فیش حقوق معتبر نیست." }
        require(reversalEpochDay >= paymentEpochDay) { "تاریخ ابطال نمی‌تواند قبل از تاریخ پرداخت باشد." }
        require(normalized.length in 3..200) { "دلیل ابطال باید بین ۳ تا ۲۰۰ نویسه باشد." }
        return copy(reason = normalized)
    }
}

interface PersonnelRepository {
    val employees: Flow<List<EmployeeRecord>>
    val payrolls: Flow<List<PayrollRecord>>
    val attendance: Flow<List<AttendanceRecord>>
    val leaves: Flow<List<LeaveRecord>>
    val pendingLeaves: Flow<List<LeaveRecord>>
    val payrollPolicies: Flow<List<PayrollPolicyRecord>>
    suspend fun saveEmployee(id: Long?, draft: EmployeeDraft): Long
    suspend fun deactivateEmployee(id: Long)
    fun contracts(employeeId: Long): Flow<List<EmployeeContractRecord>>
    fun advances(employeeId: Long): Flow<List<EmployeeAdvanceRecord>>
    val openAdvances: Flow<List<EmployeeAdvanceRecord>>
    suspend fun saveContract(id: Long?, draft: EmployeeContractDraft): Long
    suspend fun saveAttendance(id: Long?, draft: AttendanceDraft): Long
    suspend fun attendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long): AttendanceSummary
    suspend fun requestLeave(draft: LeaveDraft, requestedBy: String = "SYSTEM"): Long
    suspend fun reviewLeave(draft: LeaveReviewDraft)
    suspend fun cancelLeave(id: Long)
    suspend fun approveLeave(draft: LeaveDraft): Long
    suspend fun postAdvance(draft: EmployeeAdvanceDraft): Long
    suspend fun settleAdvance(
        id: Long,
        amountRial: Long,
        paymentMethod: TreasuryChannel,
        settlementEpochDay: Long,
    )
    suspend fun savePayrollPolicy(draft: PayrollPolicyDraft): Long
    suspend fun calculatePayroll(draft: PayrollDraft): PayrollCalculation
    suspend fun attendancePayrollAdjustment(employeeId: Long, startEpochDay: Long, endEpochDay: Long, policy: AttendancePayrollPolicy): AttendancePayrollAdjustment
    suspend fun postPayroll(draft: PayrollDraft): Long
    suspend fun approvePayroll(payrollId: Long)
    suspend fun reversePayroll(draft: PayrollReversalDraft)
}
