package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "fixed_assets", indices = [Index(value=["assetCode"], unique=true), Index("status")])
data class FixedAssetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val assetCode: String,
    val name: String,
    val category: String,
    val quantity: Int = 1,
    val purchaseEpochDay: Long,
    val purchaseCostRial: Long,
    val salvageValueRial: Long,
    val usefulLifeMonths: Int,
    val accumulatedDepreciationRial: Long = 0,
    val location: String = "",
    val status: String = "ACTIVE",
    val notes: String = "",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "asset_depreciations",
    foreignKeys=[ForeignKey(entity=FixedAssetEntity::class,parentColumns=["id"],childColumns=["assetId"],onDelete=ForeignKey.RESTRICT)],
    indices=[Index(value=["assetId","periodYear","periodMonth"], unique=true), Index("journalEntryId")],
)
data class AssetDepreciationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val assetId: Long,
    val periodYear: Int,
    val periodMonth: Int,
    val amountRial: Long,
    val journalEntryId: Long,
    val createdAtEpochMillis: Long,
)
