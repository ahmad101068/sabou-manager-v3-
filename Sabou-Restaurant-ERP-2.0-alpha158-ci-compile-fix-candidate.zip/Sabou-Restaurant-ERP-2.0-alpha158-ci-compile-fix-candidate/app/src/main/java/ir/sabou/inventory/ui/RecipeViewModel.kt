package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.recipe.RecipeCostProfile
import ir.sabou.inventory.domain.recipe.RecipeIngredientItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.recipe.RecipeRevision
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RecipeUiState(
    val menuItems: List<MenuItem> = emptyList(),
    val inventoryItems: List<InventoryItemRecord> = emptyList(),
    val selectedMenuItemId: Long? = null,
    val ingredients: List<RecipeIngredientItem> = emptyList(),
    val revisions: List<RecipeRevision> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class RecipeViewModel(
    private val recipeRepository: RecipeRepository,
    operationsRepository: OperationsRepository,
) : ViewModel() {
    private val selectedId = MutableStateFlow<Long?>(null)
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val ingredients = selectedId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else recipeRepository.observeIngredients(id)
    }
    private val revisions = selectedId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else recipeRepository.observeRevisions(id)
    }

    private data class RecipeBaseState(
        val menuItems: List<MenuItem>,
        val inventoryItems: List<InventoryItemRecord>,
        val selectedMenuItemId: Long?,
        val ingredients: List<RecipeIngredientItem>,
        val revisions: List<RecipeRevision>,
    )

    private val baseState = combine(
        recipeRepository.observeMenuItems(),
        operationsRepository.inventoryItems,
        selectedId,
        ingredients,
        revisions,
    ) { menu, inventory, selected, recipe, history ->
        RecipeBaseState(menu, inventory, selected, recipe, history)
    }

    val state: StateFlow<RecipeUiState> = combine(baseState, busy, message) { base, isBusy, msg ->
        RecipeUiState(
            menuItems = base.menuItems,
            inventoryItems = base.inventoryItems,
            selectedMenuItemId = base.selectedMenuItemId,
            ingredients = base.ingredients,
            revisions = base.revisions,
            busy = isBusy,
            message = msg,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RecipeUiState())

    fun select(id: Long?) { selectedId.value = id }
    fun clearMessage() { message.value = null }

    fun save(
        id: Long?,
        name: String,
        category: String,
        salePriceRial: Long,
        ingredients: List<RecipeIngredientInput>,
        costProfile: RecipeCostProfile,
        done: () -> Unit = {},
    ) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                val savedId = recipeRepository.saveMenuItem(id, name, category, salePriceRial, ingredients, costProfile)
                selectedId.value = savedId
                message.value = "محصول و رسپی ذخیره شد."
                done()
            } catch (e: Exception) {
                message.value = e.message ?: "ذخیره رسپی انجام نشد."
            } finally {
                busy.value = false
            }
        }
    }

    companion object {
        fun factory(recipeRepository: RecipeRepository, operationsRepository: OperationsRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    RecipeViewModel(recipeRepository, operationsRepository) as T
            }
    }
}
