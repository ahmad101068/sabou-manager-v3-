package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodCloseDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodClosureRecord
import ir.sabou.inventory.domain.operations.InventoryPeriodStatus
import ir.sabou.inventory.domain.purchase.PurchasePaymentStatus
import ir.sabou.inventory.domain.operations.StockMovementRecord
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.SupplierRecord
import ir.sabou.inventory.domain.operations.WasteDraft
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseLineDraft
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod

@Composable
fun InventoryScreen(
    state: OperationsUiState,
    onSave: (Long?, InventoryItemDraft, () -> Unit) -> Unit,
    onDeactivate: (Long) -> Unit,
    onCount: (InventoryCountDraft, String, () -> Unit) -> Unit,
    onWaste: (WasteDraft, () -> Unit) -> Unit,
    onClosePeriod: (InventoryPeriodCloseDraft, String, () -> Unit) -> Unit,
    onReopenPeriod: (Long, String, String, () -> Unit) -> Unit,
    onSelectClosure: (Long?) -> Unit,
    onSelectItem: (Long?) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var editorOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<InventoryItemRecord?>(null) }
    var deactivateTarget by remember { mutableStateOf<InventoryItemRecord?>(null) }
    var countTarget by remember { mutableStateOf<InventoryItemRecord?>(null) }
    var wasteTarget by remember { mutableStateOf<InventoryItemRecord?>(null) }
    var showPeriodClose by remember { mutableStateOf(false) }
    var reopenTarget by remember { mutableStateOf<InventoryPeriodClosureRecord?>(null) }
    var inventoryQuery by rememberSaveable { mutableStateOf("") }
    var inventoryFilter by rememberSaveable { mutableStateOf("ALL") }
    var inventorySort by rememberSaveable { mutableStateOf("NAME") }
    val totalValue = state.inventoryItems.sumOf { it.inventoryValueRial }
    val totalWaste = state.wasteRecords.sumOf { it.valueRial }
    val priceIncreases = state.supplierPriceInsights.count { it.changePercent >= 5 }
    val healthyCount = (state.inventoryItems.size - state.lowStockItems.size).coerceAtLeast(0)
    val lowStockIds = state.lowStockItems.mapTo(hashSetOf()) { it.id }
    val visibleInventoryItems = state.inventoryItems.asSequence()
        .filter { item -> businessTextMatches(inventoryQuery, item.name, item.category) }
        .filter { item -> when (inventoryFilter) { "LOW" -> item.id in lowStockIds; "OUT" -> item.stockMicros <= 0; else -> true } }
        .let { items -> when (inventorySort) { "VALUE" -> items.sortedByDescending { it.inventoryValueRial }; "STOCK" -> items.sortedBy { it.stockMicros }; else -> items.sortedBy { it.name } } }
        .toList()

    Scaffold(
        topBar = { ProfessionalTopBar("انبار", "موجودی، ارزش کالاها و هشدارهای تأمین", onBack, "کالای جدید") { selected = null; editorOpen = true } },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            state.message?.let { item { MessageCard(it) } }
            item {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("ارزش موجودی", color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = .72f), style = MaterialTheme.typography.labelLarge)
                        Text(formatMoney(totalValue), color = MaterialTheme.colorScheme.onSecondaryContainer, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile("کالای سالم", healthyCount.toString(), Modifier.weight(1f))
                            MetricTile("نیازمند تأمین", state.lowStockItems.size.toString(), Modifier.weight(1f))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile("ضایعات ثبت‌شده", formatMoney(totalWaste), Modifier.weight(1f))
                            MetricTile("افزایش قیمت", "$priceIncreases کالا", Modifier.weight(1f))
                        }
                    }
                }
            }
            if (state.inventoryItems.isNotEmpty()) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { printInventoryRegister(context, state.inventoryItems) }, modifier = Modifier.weight(1f)) { Text("چاپ دفتر") }
                        OutlinedButton(onClick = { showPeriodClose = true }, modifier = Modifier.weight(1f)) { Text("بستن دوره") }
                    }
                }
            }
            if (state.inventoryPeriodClosures.isNotEmpty()) {
                item { SectionHeading("کنترل دوره‌های انبار", "دوره بسته قفل است؛ بازگشایی فقط با حساب مالک") }
                items(state.inventoryPeriodClosures.take(5), key = { "closure-${it.id}" }) { closure ->
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${epochDayToPersian(closure.fromEpochDay).display()} تا ${epochDayToPersian(closure.toEpochDay).display()}", fontWeight = FontWeight.Bold)
                            CompactInfoRow("ارزش پایان شمارش‌شده", formatMoney(closure.countedClosingValueRial), true)
                            CompactInfoRow("مغایرت شمارش", formatMoney(closure.varianceValueRial), closure.varianceValueRial != 0L)
                            StatusPill(if (closure.status == InventoryPeriodStatus.CLOSED) "بسته · ویرایش ${closure.revisionNo}" else "بازگشایی‌شده")
                            Text("${closure.itemCount} کالا · بسته‌شده توسط ${closure.closedBy}", style = MaterialTheme.typography.bodySmall)
                            if (closure.status == InventoryPeriodStatus.REOPENED) Text("بازگشایی توسط ${closure.reopenedBy ?: "مالک"} · ${closure.reopenReason}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = { onSelectClosure(closure.id) }, modifier = Modifier.fillMaxWidth()) { Text("جزئیات و چاپ گزارش") }
                            if (closure.status == InventoryPeriodStatus.CLOSED) OutlinedButton(onClick = { reopenTarget = closure }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("بازگشایی کنترل‌شده") }
                        }
                    }
                }
            }
            item { SectionHeading("کالاها", "موجودی لحظه‌ای و عملیات انبارگردانی") }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    PremiumSearchField(inventoryQuery, { inventoryQuery = it }, "نام یا دسته‌بندی کالا")
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(inventoryFilter == "ALL", { inventoryFilter = "ALL" }, { Text("همه") })
                        FilterChip(inventoryFilter == "LOW", { inventoryFilter = "LOW" }, { Text("کمبود") })
                        FilterChip(inventoryFilter == "OUT", { inventoryFilter = "OUT" }, { Text("ناموجود") })
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(inventorySort == "NAME", { inventorySort = "NAME" }, { Text("نام") })
                        FilterChip(inventorySort == "VALUE", { inventorySort = "VALUE" }, { Text("بیشترین ارزش") })
                        FilterChip(inventorySort == "STOCK", { inventorySort = "STOCK" }, { Text("کمترین موجودی") })
                    }
                    Text("${visibleInventoryItems.size} کالا نمایش داده می‌شود", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (state.inventoryItems.isEmpty()) item { EmptyStatePanel("انبار خالی است", "اولین کالا را ثبت کنید و موجودی اولیه را وارد کنید.") }
            if (state.inventoryItems.isNotEmpty() && visibleInventoryItems.isEmpty()) item { EmptyStatePanel("کالایی با این فیلتر پیدا نشد", "فیلترها را پاک کنید یا عبارت دیگری بنویسید.") }
            items(visibleInventoryItems, key = { it.id }) { item ->
                val isLow = item.id in lowStockIds
                val usage = state.usageInsights.firstOrNull { it.itemId == item.id }
                val price = state.supplierPriceInsights.firstOrNull { it.itemId == item.id }
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1)
                                Text(item.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill(
                                if (isLow) "کمبود" else "موجود",
                                containerColor = if (isLow) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = if (isLow) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
                            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("موجودی", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("${formatQuantity(item.stockMicros)} ${item.unit}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                            }
                            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text("ارزش", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatMoney(item.inventoryValueRial), fontWeight = FontWeight.Bold)
                            }
                        }
                        if (item.alertEnabled) Text("حد هشدار: ${formatQuantity(item.alertThresholdMicros)} ${item.unit}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        usage?.takeIf { it.averageDailyUsageMicros > 0 }?.let {
                            CompactInfoRow("مصرف روزانه ۳۰روزه", "${formatQuantity(it.averageDailyUsageMicros)} ${item.unit}")
                        }
                        price?.takeIf { it.latestUnitCostRial > 0 }?.let {
                            CompactInfoRow(
                                "آخرین قیمت خرید",
                                "${formatMoney(it.latestUnitCostRial)}${if (it.changePercent == 0) "" else " · ${if (it.changePercent > 0) "+" else ""}${it.changePercent}%"}",
                                it.changePercent >= 5,
                            )
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { countTarget = item }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("انبارگردانی") }
                            OutlinedButton(onClick = { wasteTarget = item }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("ضایعات") }
                        }
                        OutlinedButton(onClick = { onSelectItem(item.id) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("جزئیات و گردش کالا") }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = { selected = item; editorOpen = true }) { Text("ویرایش") }
                            TextButton(onClick = { deactivateTarget = item }) { Text("غیرفعال", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }
    state.selectedInventoryItemId?.let { selectedId ->
        state.inventoryItems.firstOrNull { it.id == selectedId }?.let { item ->
            InventoryItemDetailDialog(item, state.selectedStockMovements) { onSelectItem(null) }
        }
    }
    if (editorOpen) InventoryEditorDialog(existing = selected, suppliers = state.suppliers, busy = state.busy, onDismiss = { editorOpen = false }, onSave = { draft -> onSave(selected?.id, draft) { editorOpen = false } })
    deactivateTarget?.let { target -> ConfirmDeactivateDialog("غیرفعال‌کردن کالا", "«${target.name}» از فهرست کالاهای فعال حذف می‌شود؛ گردش انبار قبلی باقی می‌ماند.", { deactivateTarget = null }) { deactivateTarget = null; onDeactivate(target.id) } }
    countTarget?.let { item -> InventoryCountDialog(item, state.busy, onDismiss = { countTarget = null }) { draft, pin -> onCount(draft, pin) { countTarget = null } } }
    wasteTarget?.let { item -> WasteDialog(item, state.busy, onDismiss = { wasteTarget = null }) { draft -> onWaste(draft) { wasteTarget = null } } }
    if (showPeriodClose) InventoryPeriodCloseDialog(
        lastClosureEnd = state.inventoryPeriodClosures.maxOfOrNull { it.toEpochDay },
        busy = state.busy,
        message = state.message,
        onDismiss = { showPeriodClose = false },
    ) { draft, pin -> onClosePeriod(draft, pin) { showPeriodClose = false } }
    reopenTarget?.let { closure ->
        ControlledReopenDialog(
        title = "بازگشایی دوره انبار",
        description = "این عملیات فقط با حساب مالک انجام می‌شود، قفل گردش دوره را باز می‌کند و در گزارش حسابرسی ثبت خواهد شد.",
        busy = state.busy,
        message = state.message,
            onDismiss = { reopenTarget = null },
        ) { reason, pin -> onReopenPeriod(closure.id, reason, pin) { reopenTarget = null } }
    }
    state.selectedInventoryClosureDetails?.let { details ->
        InventoryPeriodDetailsDialog(details, onDismiss = { onSelectClosure(null) })
    }
}

@Composable
fun StockMovementExplorerScreen(state: OperationsUiState, onSelectItem: (Long?) -> Unit, onBack: () -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var type by rememberSaveable { mutableStateOf("ALL") }
    val itemsById = state.inventoryItems.associateBy { it.id }
    val visible = state.recentStockMovements.filter { movement ->
        val item = itemsById[movement.itemId]
        businessTextMatches(query, item?.name, item?.category, movement.referenceType.storedValue, movement.notes) && when (type) {
            "IN" -> movement.quantityDeltaMicros > 0
            "OUT" -> movement.quantityDeltaMicros < 0
            "WASTE" -> movement.movementType == InventoryMovementType.WASTE
            "ADJUST" -> movement.movementType == InventoryMovementType.INVENTORY_COUNT
            else -> true
        }
    }
    Scaffold(topBar = { ProfessionalTopBar("دفتر گردش موجودی", "ردیابی متمرکز ورود، خروج، مصرف و اصلاح", onBack) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { PremiumSearchField(query, { query = it }, "کالا، دسته، مرجع یا توضیح") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(type == "ALL", { type = "ALL" }, { Text("همه") }); FilterChip(type == "IN", { type = "IN" }, { Text("ورودی") }); FilterChip(type == "OUT", { type = "OUT" }, { Text("خروجی") }); FilterChip(type == "WASTE", { type = "WASTE" }, { Text("ضایعات") })
            } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("گردش نمایش‌داده‌شده", visible.size.toString(), Modifier.weight(1f)); MetricTile("ارزش خالص", formatMoney(visible.sumOf { it.valueDeltaRial }), Modifier.weight(1f)) } }
            if (visible.isEmpty()) item { EmptyStatePanel("گردشی پیدا نشد", if (state.recentStockMovements.isEmpty()) "با ثبت خرید، فروش، شمارش یا ضایعات، گردش‌ها اینجا نمایش داده می‌شوند." else "جست‌وجو یا فیلتر را تغییر دهید.") }
            items(visible, key = { "movement-${it.id}" }) { movement ->
                val item = itemsById[movement.itemId]
                Card(onClick = { onSelectItem(movement.itemId) }, shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(item?.name ?: "کالای #${movement.itemId}", fontWeight = FontWeight.Black); StatusPill(stockMovementTitle(movement.movementType)) }
                        Text("${if (movement.quantityDeltaMicros > 0) "+" else ""}${formatQuantity(movement.quantityDeltaMicros)} ${item?.unit.orEmpty()} · ${formatMoney(movement.valueDeltaRial)}", fontWeight = FontWeight.Bold)
                        Text("${epochDayToPersian(movement.movementEpochDay).display()} · ${movement.referenceType.storedValue} #${movement.referenceId}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (movement.notes.isNotBlank()) Text(movement.notes, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
    state.selectedInventoryItemId?.let { id -> itemsById[id]?.let { item -> InventoryItemDetailDialog(item, state.selectedStockMovements) { onSelectItem(null) } } }
}

@Composable
private fun InventoryItemDetailDialog(item: InventoryItemRecord, movements: List<StockMovementRecord>, onDismiss: () -> Unit) {
    var movementFilter by rememberSaveable(item.id) { mutableStateOf("ALL") }
    val visible = movements.filter { movement -> when (movementFilter) { "IN" -> movement.quantityDeltaMicros > 0; "OUT" -> movement.quantityDeltaMicros < 0; "ADJUST" -> movement.movementType in setOf(InventoryMovementType.INVENTORY_COUNT, InventoryMovementType.WASTE); else -> true } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.name) },
        text = {
            Column(Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricTile("موجودی", "${formatQuantity(item.stockMicros)} ${item.unit}", Modifier.weight(1f))
                    MetricTile("ارزش", formatMoney(item.inventoryValueRial), Modifier.weight(1f))
                }
                CompactInfoRow("دسته‌بندی", item.category)
                if (item.alertEnabled) CompactInfoRow("حداقل موجودی", "${formatQuantity(item.alertThresholdMicros)} ${item.unit}", item.stockMicros <= item.alertThresholdMicros)
                Text("گردش موجودی", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(movementFilter == "ALL", { movementFilter = "ALL" }, { Text("همه") })
                    FilterChip(movementFilter == "IN", { movementFilter = "IN" }, { Text("ورودی") })
                    FilterChip(movementFilter == "OUT", { movementFilter = "OUT" }, { Text("خروجی") })
                    FilterChip(movementFilter == "ADJUST", { movementFilter = "ADJUST" }, { Text("اصلاح") })
                }
                if (visible.isEmpty()) Text("گردشی با این فیلتر ثبت نشده است.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                visible.take(100).forEach { movement ->
                    Surface(shape = RoundedCornerShape(14.dp), color = if (movement.quantityDeltaMicros >= 0) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant) {
                        Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(stockMovementTitle(movement.movementType), fontWeight = FontWeight.Bold)
                                Text(epochDayToPersian(movement.movementEpochDay).display())
                            }
                            Text("${if (movement.quantityDeltaMicros > 0) "+" else ""}${formatQuantity(movement.quantityDeltaMicros)} ${item.unit} · ارزش ${formatMoney(movement.valueDeltaRial)}")
                            Text("مرجع ${movement.referenceType.storedValue} #${movement.referenceId}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (movement.notes.isNotBlank()) Text(movement.notes, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}

private fun stockMovementTitle(type: InventoryMovementType): String = when (type) {
    InventoryMovementType.PURCHASE,
    InventoryMovementType.GOODS_RECEIPT,
    -> "ورود خرید"
    InventoryMovementType.PURCHASE_RETURN,
    InventoryMovementType.PURCHASE_REVERSAL,
    -> "برگشت خرید"
    InventoryMovementType.DAILY_SALES_CONSUMPTION,
    InventoryMovementType.LEGACY_SALE_CONSUMPTION,
    -> "مصرف فروش"
    InventoryMovementType.DAILY_SALES_REVERSAL -> "برگشت مصرف فروش"
    InventoryMovementType.INVENTORY_COUNT -> "اصلاح انبارگردانی"
    InventoryMovementType.WASTE -> "ضایعات"
    InventoryMovementType.TRANSFER_IN -> "انتقال ورودی"
    InventoryMovementType.TRANSFER_OUT -> "انتقال خروجی"
    InventoryMovementType.LEGACY_UNKNOWN -> "گردش قدیمی ناشناخته"
}

@Composable
private fun ControlledReopenDialog(title: String, description: String, busy: Boolean, message: String?, onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var reason by remember(title) { mutableStateOf("") }
    var pin by remember(title) { mutableStateOf("") }
    var submitted by remember(title) { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(description)
            OutlinedTextField(reason, { reason = it.take(300) }, label = { Text("دلیل اجباری بازگشایی") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            if (submitted) message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            SensitivePinField(pin, { pin = it })
            Text("حداقل ۵ نویسه؛ پس از اصلاح باید دوره دوباره بسته شود.", style = MaterialTheme.typography.bodySmall)
        } },
        confirmButton = { Button(enabled = !busy && reason.trim().length >= 5 && pin.length in 6..12, onClick = { val submittedPin = pin; pin = ""; submitted = true; onConfirm(reason.trim(), submittedPin) }) { Text("بازگشایی با ثبت رویداد") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun InventoryPeriodDetailsDialog(
    details: ir.sabou.inventory.domain.operations.InventoryPeriodClosureDetails,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("گزارش قطعی دوره انبار") },
        text = { LazyColumn(Modifier.fillMaxWidth().heightIn(max = 600.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            item { Text("${epochDayToPersian(details.closure.fromEpochDay).display()} تا ${epochDayToPersian(details.closure.toEpochDay).display()}", fontWeight = FontWeight.Bold) }
            item { Text("اول دوره ${formatMoney(details.closure.openingValueRial)} · خرید خالص ${formatMoney(details.closure.netPurchaseValueRial)}") }
            item { Text("پایان موردانتظار ${formatMoney(details.closure.expectedClosingValueRial)} · شمارش‌شده ${formatMoney(details.closure.countedClosingValueRial)}") }
            item { Text("مغایرت کل ${formatMoney(details.closure.varianceValueRial)}", color = if (details.closure.varianceValueRial == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, fontWeight = FontWeight.ExtraBold) }
            items(details.lines, key = { it.itemId }) { line ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(line.itemName, fontWeight = FontWeight.Bold)
                        Text("اول: ${formatQuantity(line.openingQuantityMicros)} ${line.unit} · خرید: ${formatQuantity(line.netPurchaseQuantityMicros)} · خروج: ${formatQuantity(line.recordedOutflowQuantityMicros)}", style = MaterialTheme.typography.bodySmall)
                        Text("انتظار: ${formatQuantity(line.expectedClosingQuantityMicros)} · شمارش: ${formatQuantity(line.countedClosingQuantityMicros)} · مغایرت: ${formatQuantity(line.varianceQuantityMicros)} ${line.unit}", style = MaterialTheme.typography.bodySmall)
                        Text("مغایرت ریالی: ${formatMoney(line.varianceValueRial)}", color = if (line.varianceValueRial == 0L) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    }
                }
            }
        } },
        confirmButton = { Button(onClick = { printInventoryPeriodClosure(context, details) }) { Text("چاپ / PDF") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}

@Composable
private fun InventoryPeriodCloseDialog(
    lastClosureEnd: Long?,
    busy: Boolean,
    message: String?,
    onDismiss: () -> Unit,
    onSave: (InventoryPeriodCloseDraft, String) -> Unit,
) {
    var from by remember(lastClosureEnd) { mutableLongStateOf(lastClosureEnd?.plus(1) ?: (currentEpochDay() - 30L)) }
    var to by remember { mutableLongStateOf(currentEpochDay()) }
    var note by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بستن قطعی دوره انبار") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                MessageCard("برای همه کالاهای فعال باید در تاریخ پایان دوره انبارگردانی ثبت شده باشد. پس از بستن، هیچ گردش انباری در این بازه قابل ثبت یا تغییر نیست.")
                error?.let { MessageCard(it, true) }
                if (submitted) message?.let { MessageCard(it, true) }
                PersianDateField("شروع دوره", from, { from = it })
                PersianDateField("پایان و تاریخ شمارش", to, { to = it })
                OutlinedTextField(note, { note = it.take(300) }, label = { Text("یادداشت بستن دوره") }, modifier = Modifier.fillMaxWidth())
                SensitivePinField(pin, { pin = it })
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching { InventoryPeriodCloseDraft(from, to, note).validated() }
                    .onSuccess { draft -> val submittedPin = pin; pin = ""; submitted = true; onSave(draft, submittedPin) }
                    .onFailure { error = it.message }
            }, enabled = !busy && pin.length in 6..12) { Text("بستن و قفل‌کردن") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun WasteDialog(item: InventoryItemRecord, busy: Boolean, onDismiss: () -> Unit, onSave: (WasteDraft) -> Unit) {
    val commandId = remember(item.id) { GlobalId.new().value }
    var quantity by remember { mutableStateOf("") }
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var reason by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت ضایعات ${item.name}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Text("موجودی فعلی: ${formatQuantity(item.stockMicros)} ${item.unit}")
                OutlinedTextField(
                    quantity,
                    { quantity = it.filter { char -> char.isDigit() || char == '.' } },
                    label = { Text("مقدار ضایعات") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                )
                PersianDateField("تاریخ ضایعات", day, { day = it })
                SelectionField(
                    label = "علت ضایعات",
                    selectedText = reason.ifBlank { null },
                    options = listOf("فساد مواد" , "خطای آماده‌سازی", "برگشت مشتری", "شکستگی یا آسیب", "کسری نامشخص").mapIndexed { index, value -> index.toLong() to value },
                    onSelected = { selectedId -> reason = listOf("فساد مواد", "خطای آماده‌سازی", "برگشت مشتری", "شکستگی یا آسیب", "کسری نامشخص")[selectedId.toInt()] },
                )
                OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    runCatching {
                        WasteDraft(item.id, parseQuantity(quantity).value, day, reason, notes, commandId).validated()
                    }.onSuccess(onSave).onFailure { error = it.message ?: "اطلاعات ضایعات معتبر نیست." }
                },
            ) { Text("ثبت و صدور سند") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun InventoryCountDialog(item: InventoryItemRecord, busy: Boolean, onDismiss: () -> Unit, onSave: (InventoryCountDraft, String) -> Unit) {
    val commandId = remember(item.id) { GlobalId.new().value }
    var quantity by remember { mutableStateOf(formatQuantity(item.stockMicros)) }
    var value by remember { mutableStateOf(item.inventoryValueRial.toString()) }
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var reason by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss, title={Text("انبارگردانی ${item.name}")}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("موجودی فعلی: ${formatQuantity(item.stockMicros)} ${item.unit}")
        OutlinedTextField(quantity,{quantity=it.filter{c->c.isDigit()||c=='.'}},label={Text("مقدار شمارش‌شده")})
        OutlinedTextField(value,{value=formatMoneyInput(it)},label={Text("ارزش کل موجودی (${currencyUnitLabel()})")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
        PersianDateField("تاریخ انبارگردانی",day,{day=it})
        OutlinedTextField(reason,{reason=it},label={Text("دلیل اصلاح")})
        SensitivePinField(pin, { pin = it })
    }}, confirmButton={Button(enabled=!busy && pin.length in 6..12,onClick={
        val micros = runCatching { parseQuantity(quantity).value }.getOrDefault(-1L)
        val submittedPin = pin
        pin = ""
        onSave(InventoryCountDraft(item.id,micros,runCatching { parseMoneyRial(value).value }.getOrDefault(-1),day,reason,commandId), submittedPin)
    }){Text("ثبت انبارگردانی")}}, dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun InventoryEditorDialog(
    existing: InventoryItemRecord?,
    suppliers: List<SupplierRecord>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (InventoryItemDraft) -> Unit,
) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var category by remember(existing?.id) { mutableStateOf(existing?.category.orEmpty()) }
    var unit by remember(existing?.id) { mutableStateOf(existing?.unit.orEmpty()) }
    var purchaseUnit by remember(existing?.id) { mutableStateOf(existing?.purchaseUnit ?: existing?.unit.orEmpty()) }
    var purchaseFactor by remember(existing?.id) { mutableStateOf(existing?.purchaseToStockNumerator?.toString() ?: "1") }
    var recipeUnit by remember(existing?.id) { mutableStateOf(existing?.recipeUnit ?: existing?.unit.orEmpty()) }
    var recipeFactor by remember(existing?.id) { mutableStateOf(existing?.recipeToStockNumerator?.toString() ?: "1") }
    var categoryExpanded by remember { mutableStateOf(false) }
    var unitExpanded by remember { mutableStateOf(false) }
    val categories = listOf("مواد اولیه", "پروتئین", "لبنیات", "نوشیدنی", "خشکبار و ادویه", "میوه و سبزی", "بسته‌بندی", "مواد شوینده", "ملزومات")
    val units = listOf("کیلوگرم", "گرم", "لیتر", "میلی‌لیتر", "عدد", "بسته", "کارتن", "قوطی", "بطری", "پرس")
    var supplierId by remember(existing?.id) { mutableStateOf(existing?.supplierId) }
    var alertEnabled by remember(existing?.id) { mutableStateOf(existing?.alertEnabled ?: true) }
    var threshold by remember(existing?.id) {
        mutableStateOf(existing?.let { formatQuantity(it.alertThresholdMicros) } ?: "5")
    }
    var error by remember(existing?.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "کالای جدید" else "ویرایش کالا") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedTextField(name, { name = it }, label = { Text("نام کالا") })
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category.ifBlank { "انتخاب دسته‌بندی کالا" }) }
                    DropdownMenu(categoryExpanded, { categoryExpanded = false }) { categories.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { category = value; categoryExpanded = false }) } }
                }
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { unitExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(unit.ifBlank { "انتخاب واحد کالا" }) }
                    DropdownMenu(unitExpanded, { unitExpanded = false }) { units.forEach { value -> DropdownMenuItem(text = { Text(value) }, onClick = { unit = value; unitExpanded = false }) } }
                }
                Text("تبدیل واحد", fontWeight = FontWeight.Bold)
                OutlinedTextField(purchaseUnit, { purchaseUnit = it }, label = { Text("واحد خرید") })
                OutlinedTextField(purchaseFactor, { purchaseFactor = it }, label = { Text("هر ۱ واحد خرید = چند واحد انبار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(recipeUnit, { recipeUnit = it }, label = { Text("واحد رسپی") })
                OutlinedTextField(recipeFactor, { recipeFactor = it }, label = { Text("هر ۱ واحد رسپی = چند واحد انبار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                SelectionField(
                    label = "تأمین‌کننده پیش‌فرض (اختیاری)",
                    selectedText = suppliers.firstOrNull { it.id == supplierId }?.name,
                    options = listOf(0L to "بدون تأمین‌کننده") + suppliers.map { it.id to it.name },
                    onSelected = { supplierId = it.takeIf { selectedId -> selectedId != 0L } },
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = alertEnabled, onCheckedChange = { alertEnabled = it })
                    Text("هشدار کمبود موجودی")
                }
                if (alertEnabled) {
                    OutlinedTextField(
                        threshold,
                        { threshold = it },
                        label = { Text("حد هشدار") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    )
                }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    try {
                        onSave(
                            InventoryItemDraft(
                                name = name,
                                category = category,
                                unit = unit,
                                purchaseUnit = purchaseUnit.ifBlank { unit },
                                purchaseToStockNumerator = purchaseFactor.toLongOrNull() ?: 1L,
                                purchaseToStockDenominator = 1L,
                                recipeUnit = recipeUnit.ifBlank { unit },
                                recipeToStockNumerator = recipeFactor.toLongOrNull() ?: 1L,
                                recipeToStockDenominator = 1L,
                                alertEnabled = alertEnabled,
                                alertThresholdMicros = if (alertEnabled) {
                                    parseQuantity(threshold).value
                                } else {
                                    0L
                                },
                                supplierId = supplierId,
                            ),
                        )
                    } catch (failure: Exception) {
                        error = failure.message ?: "اطلاعات کالا معتبر نیست."
                    }
                },
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

