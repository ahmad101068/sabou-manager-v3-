package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.FixedPointRatio
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryLotConsumptionEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.db.StockTransferEntity
import ir.sabou.inventory.data.db.StockTransferLineEntity
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.common.businessRequire
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryLedgerResult
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import java.util.UUID

/**
 * Authoritative command boundary for inventory quantity/value mutations.
 *
 * Every command owns a Room transaction. Nested calls participate in the caller's transaction, so a
 * cross-domain workflow (document + ledger + accounting + audit) either commits in full or rolls back.
 * `inventory_items.stockMicros/inventoryValueRial` is a compare-and-set projection cache; immutable
 * `stock_movements` remains the auditable history.
 */
class LocalInventoryCommandEngine(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    enum class LotIssuePolicy { NONE, FEFO_ALL, FEFO_ALLOCATED_ONLY }

    suspend fun receive(
        itemId: Long,
        quantityMicros: Long,
        valueRial: Long,
        movementType: InventoryMovementType,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
    ): InventoryLedgerResult = inventoryTransaction(movementEpochDay) {
        requireCommandIdentity(movementType, referenceType, referenceId)
        businessRequire(quantityMicros > 0) {
            BusinessError.InvalidInput("quantityMicros", "مقدار ورود موجودی باید مثبت باشد.")
        }
        businessRequire(valueRial >= 0) {
            BusinessError.InvalidInput("valueRial", "ارزش ورود موجودی نمی‌تواند منفی باشد.")
        }
        val resolved = resolveContext(context)
        val unitCost = unitCost(valueRial, quantityMicros)
        val expected = movement(
            itemId = itemId,
            movementType = movementType,
            quantityDeltaMicros = quantityMicros,
            valueDeltaRial = valueRial,
            referenceType = referenceType,
            referenceId = referenceId,
            movementEpochDay = movementEpochDay,
            context = resolved,
            unitCostRial = unitCost,
            notes = notes,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }

        val item = database.inventoryDao().activeById(itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", itemId).asViolation()
        val nextStock = (QuantityMicros.of(item.stockMicros) + QuantityMicros.of(quantityMicros)).value
        val nextValue = (MoneyRial.of(item.inventoryValueRial) + MoneyRial.of(valueRial)).value
        val now = clock()
        businessRequire(
            database.inventoryDao().compareAndSetValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = nextStock,
                nextInventoryValueRial = nextValue,
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        insert(expected.copy(createdAtEpochMillis = now))
    }

    suspend fun issue(
        itemId: Long,
        quantityMicros: Long,
        valueRial: Long,
        movementType: InventoryMovementType,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
        lotPolicy: LotIssuePolicy = LotIssuePolicy.FEFO_ALLOCATED_ONLY,
    ): InventoryLedgerResult = inventoryTransaction(movementEpochDay) {
        requireCommandIdentity(movementType, referenceType, referenceId)
        businessRequire(quantityMicros > 0) {
            BusinessError.InvalidInput("quantityMicros", "مقدار خروج موجودی باید مثبت باشد.")
        }
        businessRequire(valueRial >= 0) {
            BusinessError.InvalidInput("valueRial", "ارزش خروج موجودی نمی‌تواند منفی باشد.")
        }
        val resolved = resolveContext(context)
        val unitCost = unitCost(valueRial, quantityMicros)
        val expected = movement(
            itemId = itemId,
            movementType = movementType,
            quantityDeltaMicros = SignedLongMath.subtract(0L, quantityMicros),
            valueDeltaRial = SignedLongMath.subtract(0L, valueRial),
            referenceType = referenceType,
            referenceId = referenceId,
            movementEpochDay = movementEpochDay,
            context = resolved,
            unitCostRial = unitCost,
            notes = notes,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }

        val item = database.inventoryDao().activeById(itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", itemId).asViolation()
        businessRequire(item.stockMicros >= quantityMicros) {
            BusinessError.InsufficientStock(item.id, item.name, quantityMicros, item.stockMicros)
        }
        businessRequire(item.inventoryValueRial >= valueRial) {
            BusinessError.InsufficientInventoryValue(item.id, item.name, valueRial, item.inventoryValueRial)
        }
        val now = clock()
        businessRequire(
            database.inventoryDao().compareAndSetValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = SignedLongMath.subtract(item.stockMicros, quantityMicros),
                nextInventoryValueRial = SignedLongMath.subtract(item.inventoryValueRial, valueRial),
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        val result = insert(expected.copy(createdAtEpochMillis = now))
        when (lotPolicy) {
            LotIssuePolicy.NONE -> Unit
            LotIssuePolicy.FEFO_ALL -> consumeLotsFefo(
                itemId = item.id,
                quantityMicros = quantityMicros,
                movementId = result.movementId,
                movementEpochDay = movementEpochDay,
                allowExpired = movementType.canDisposeExpiredLots(),
                now = now,
            )
            LotIssuePolicy.FEFO_ALLOCATED_ONLY -> {
                val allocatedLots = database.managementControlDao().allocatedQuantity(item.id)
                val unallocatedStock = SignedLongMath.subtract(item.stockMicros, allocatedLots).coerceAtLeast(0L)
                consumeLotsFefo(
                    itemId = item.id,
                    quantityMicros = SignedLongMath.subtract(quantityMicros, unallocatedStock).coerceAtLeast(0L),
                    movementId = result.movementId,
                    movementEpochDay = movementEpochDay,
                    allowExpired = movementType.canDisposeExpiredLots(),
                    now = now,
                )
            }
        }
        result
    }

    suspend fun adjustToCount(
        itemId: Long,
        countedQuantityMicros: Long,
        countedValueRial: Long,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
    ): InventoryLedgerResult = inventoryTransaction(movementEpochDay) {
        businessRequire(countedQuantityMicros >= 0) {
            BusinessError.InvalidInput("countedQuantityMicros", "موجودی شمارش‌شده نمی‌تواند منفی باشد.")
        }
        businessRequire(countedValueRial >= 0) {
            BusinessError.InvalidInput("countedValueRial", "ارزش شمارش‌شده نمی‌تواند منفی باشد.")
        }
        businessRequire(referenceId > 0) {
            BusinessError.InvalidInput("referenceId", "شناسه سند شمارش معتبر نیست.")
        }
        val resolved = resolveContext(context)
        val item = database.inventoryDao().activeById(itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", itemId).asViolation()
        val quantityDelta = SignedLongMath.subtract(countedQuantityMicros, item.stockMicros)
        val valueDelta = SignedLongMath.subtract(countedValueRial, item.inventoryValueRial)
        businessRequire(quantityDelta != 0L || valueDelta != 0L) {
            BusinessError.InvalidBusinessState("INVENTORY_COUNT", "NO_VARIANCE")
        }
        val unitCost = if (quantityDelta == 0L) 0L else unitCost(absExact(valueDelta), absExact(quantityDelta))
        val expected = movement(
            itemId = item.id,
            movementType = InventoryMovementType.INVENTORY_COUNT,
            quantityDeltaMicros = quantityDelta,
            valueDeltaRial = valueDelta,
            referenceType = InventoryReferenceType.INVENTORY_COUNT,
            referenceId = referenceId,
            movementEpochDay = movementEpochDay,
            context = resolved,
            unitCostRial = unitCost,
            notes = notes,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }

        val now = clock()
        businessRequire(
            database.inventoryDao().compareAndSetValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = countedQuantityMicros,
                nextInventoryValueRial = countedValueRial,
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        val result = insert(expected.copy(createdAtEpochMillis = now))
        if (countedQuantityMicros < item.stockMicros) {
            val allocatedLots = database.managementControlDao().allocatedQuantity(item.id)
            val lotReduction = SignedLongMath.subtract(allocatedLots, countedQuantityMicros).coerceAtLeast(0L)
            consumeLotsFefo(
                itemId = item.id,
                quantityMicros = lotReduction,
                movementId = result.movementId,
                movementEpochDay = movementEpochDay,
                allowExpired = true,
                now = now,
            )
        }
        result
    }

    suspend fun transferLot(
        sourceLotId: Long,
        destinationLocationId: Long,
        quantityMicros: Long,
        transferEpochDay: Long,
        note: String,
        transferredBy: String,
        context: InventoryCommandContext,
    ): Long = inventoryTransaction(transferEpochDay) {
        businessRequire(quantityMicros > 0) {
            BusinessError.InvalidInput("quantityMicros", "مقدار انتقال باید مثبت باشد.")
        }
        val resolved = resolveContext(context, locationOverride = destinationLocationId)
        val dao = database.managementControlDao()
        val source = dao.lot(sourceLotId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_LOT", sourceLotId).asViolation()
        if (dao.activeLocation(source.locationId) == null) {
            throw BusinessError.EntityNotFound("STORAGE_LOCATION", source.locationId).asViolation()
        }
        dao.transferByIdempotencyKey(resolved.idempotencyKey)?.let { existing ->
            val line = dao.transferLines(existing.id).singleOrNull()
            val matches = line != null && existing.sourceLocationId == source.locationId &&
                existing.destinationLocationId == destinationLocationId &&
                existing.transferEpochDay == transferEpochDay &&
                existing.actorId == resolved.actorId &&
                existing.deviceId == resolved.deviceId &&
                existing.correlationId == resolved.correlationId &&
                existing.note == note.trim() &&
                existing.transferredBy == transferredBy.trim() &&
                line.itemId == source.itemId && line.lotCode == source.lotCode &&
                line.quantityMicros == quantityMicros
            if (!matches) throw BusinessError.IdempotencyConflict(resolved.idempotencyKey).asViolation()
            return@inventoryTransaction existing.id
        }

        businessRequire(source.quantityMicros >= quantityMicros) {
            BusinessError.InsufficientStock(source.itemId, source.lotCode, quantityMicros, source.quantityMicros)
        }
        businessRequire(source.locationId != destinationLocationId) {
            BusinessError.InvalidInput("destinationLocationId", "محل مبدأ و مقصد یکسان است.")
        }
        if (dao.activeLocation(destinationLocationId) == null) {
            throw BusinessError.EntityNotFound("STORAGE_LOCATION", destinationLocationId).asViolation()
        }
        val now = clock()
        check(
            dao.updateLot(
                source.copy(
                    quantityMicros = SignedLongMath.subtract(source.quantityMicros, quantityMicros),
                    updatedAtEpochMillis = now,
                ),
            ) == 1,
        ) { "کاهش موجودی لات انجام نشد." }
        val destination = dao.lotByNaturalKey(source.itemId, destinationLocationId, source.lotCode)
        if (destination == null) {
            dao.insertLot(
                source.copy(
                    id = 0,
                    locationId = destinationLocationId,
                    quantityMicros = quantityMicros,
                    updatedAtEpochMillis = now,
                ),
            )
        } else {
            check(
                dao.updateLot(
                    destination.copy(
                        quantityMicros = SignedLongMath.add(destination.quantityMicros, quantityMicros),
                        updatedAtEpochMillis = now,
                    ),
                ) == 1,
            ) { "افزایش موجودی لات مقصد انجام نشد." }
        }
        val transferId = dao.insertTransfer(
            StockTransferEntity(
                transferNo = "TR-${now}-${UUID.randomUUID().toString().take(4)}",
                sourceLocationId = source.locationId,
                destinationLocationId = destinationLocationId,
                transferEpochDay = transferEpochDay,
                note = note.trim(),
                transferredBy = transferredBy.trim(),
                createdAtEpochMillis = now,
                idempotencyKey = resolved.idempotencyKey,
                correlationId = resolved.correlationId,
                actorId = resolved.actorId,
                deviceId = resolved.deviceId,
            ),
        )
        dao.insertTransferLine(
            StockTransferLineEntity(
                transferId = transferId,
                itemId = source.itemId,
                lotCode = source.lotCode,
                quantityMicros = quantityMicros,
            ),
        )

        val transferValue = MoneyRial.of(source.unitCostRial).times(QuantityMicros.of(quantityMicros)).value
        val outContext = resolved.copy(
            idempotencyKey = "${resolved.idempotencyKey}:out",
            locationId = source.locationId,
        ).validated()
        val inContext = resolved.copy(
            idempotencyKey = "${resolved.idempotencyKey}:in",
            locationId = destinationLocationId,
        ).validated()
        insert(
            movement(
                itemId = source.itemId,
                movementType = InventoryMovementType.TRANSFER_OUT,
                quantityDeltaMicros = SignedLongMath.subtract(0L, quantityMicros),
                valueDeltaRial = SignedLongMath.subtract(0L, transferValue),
                referenceType = InventoryReferenceType.STOCK_TRANSFER,
                referenceId = transferId,
                movementEpochDay = transferEpochDay,
                context = outContext,
                unitCostRial = source.unitCostRial,
                notes = note,
            ).copy(createdAtEpochMillis = now),
        )
        insert(
            movement(
                itemId = source.itemId,
                movementType = InventoryMovementType.TRANSFER_IN,
                quantityDeltaMicros = quantityMicros,
                valueDeltaRial = transferValue,
                referenceType = InventoryReferenceType.STOCK_TRANSFER,
                referenceId = transferId,
                movementEpochDay = transferEpochDay,
                context = inContext,
                unitCostRial = source.unitCostRial,
                notes = note,
            ).copy(createdAtEpochMillis = now),
        )
        transferId
    }

    suspend fun restoreIssuedMovement(
        movement: StockMovementEntity,
        reversalMovementType: InventoryMovementType,
        reversalEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
    ): InventoryLedgerResult = inventoryTransaction(reversalEpochDay) {
        businessRequire(movement.quantityDeltaMicros < 0 && movement.valueDeltaRial <= 0) {
            BusinessError.InvalidBusinessState("STOCK_MOVEMENT", movement.movementType)
        }
        businessRequire(
            reversalMovementType !in setOf(
                InventoryMovementType.LEGACY_UNKNOWN,
                InventoryMovementType.LEGACY_SALE_CONSUMPTION,
            ),
        ) {
            BusinessError.InvalidInput("reversalMovementType", "نوع گردش برگشت معتبر نیست.")
        }
        val resolved = resolveContext(context)
        val restoredQuantity = absExact(movement.quantityDeltaMicros)
        val restoredValue = absExact(movement.valueDeltaRial)
        val expected = movement(
            itemId = movement.itemId,
            movementType = reversalMovementType,
            quantityDeltaMicros = restoredQuantity,
            valueDeltaRial = restoredValue,
            referenceType = InventoryReferenceType.fromStoredValue(movement.referenceType),
            referenceId = movement.referenceId,
            movementEpochDay = reversalEpochDay,
            context = resolved,
            unitCostRial = movement.unitCostRial,
            notes = notes,
            reversalOfMovementId = movement.id,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }
        database.stockMovementDao().reversalOf(movement.id)?.let {
            throw BusinessError.IdempotencyConflict(resolved.idempotencyKey).asViolation()
        }

        val item = database.inventoryDao().byId(movement.itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", movement.itemId).asViolation()
        val now = clock()
        businessRequire(
            database.inventoryDao().compareAndRestoreValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = SignedLongMath.add(item.stockMicros, restoredQuantity),
                nextInventoryValueRial = SignedLongMath.add(item.inventoryValueRial, restoredValue),
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }

        database.managementControlDao().lotConsumptions(movement.id).forEach { consumption ->
            val restoreToLot = SignedLongMath.subtract(consumption.quantityMicros, consumption.reversedQuantityMicros)
            if (restoreToLot > 0) {
                val lot = database.managementControlDao().lot(consumption.lotId)
                    ?: throw BusinessError.EntityNotFound("INVENTORY_LOT", consumption.lotId).asViolation()
                check(
                    database.managementControlDao().updateLot(
                        lot.copy(
                            quantityMicros = SignedLongMath.add(lot.quantityMicros, restoreToLot),
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "بازگردانی موجودی لات انجام نشد." }
                check(database.managementControlDao().markLotConsumptionReversed(consumption.id) == 1) {
                    "ثبت بازگشت مصرف لات انجام نشد."
                }
            }
        }
        insert(expected.copy(createdAtEpochMillis = now))
    }

    private suspend fun resolveContext(
        context: InventoryCommandContext,
        locationOverride: Long? = null,
    ): InventoryCommandContext {
        val valid = context.validated()
        val locationId = locationOverride ?: valid.locationId ?: database.managementControlDao().defaultLocationId()
            ?: throw BusinessError.EntityNotFound("DEFAULT_STORAGE_LOCATION", null).asViolation()
        if (database.managementControlDao().activeLocation(locationId) == null) {
            throw BusinessError.EntityNotFound("STORAGE_LOCATION", locationId).asViolation()
        }
        return valid.copy(locationId = locationId)
    }

    private fun requireCommandIdentity(
        movementType: InventoryMovementType,
        referenceType: InventoryReferenceType,
        referenceId: Long,
    ) {
        businessRequire(
            movementType !in setOf(
                InventoryMovementType.LEGACY_UNKNOWN,
                InventoryMovementType.LEGACY_SALE_CONSUMPTION,
            ),
        ) {
            BusinessError.InvalidInput("movementType", "نوع گردش موجودی معتبر نیست.")
        }
        businessRequire(referenceType != InventoryReferenceType.LEGACY_UNKNOWN) {
            BusinessError.InvalidInput("referenceType", "نوع مرجع موجودی معتبر نیست.")
        }
        businessRequire(referenceId > 0) {
            BusinessError.InvalidInput("referenceId", "شناسه مرجع موجودی معتبر نیست.")
        }
    }

    private fun movement(
        itemId: Long,
        movementType: InventoryMovementType,
        quantityDeltaMicros: Long,
        valueDeltaRial: Long,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        unitCostRial: Long,
        notes: String?,
        reversalOfMovementId: Long? = null,
    ): StockMovementEntity = StockMovementEntity(
        itemId = itemId,
        movementType = movementType.storedValue,
        quantityDeltaMicros = quantityDeltaMicros,
        valueDeltaRial = valueDeltaRial,
        referenceType = referenceType.storedValue,
        referenceId = referenceId,
        movementEpochDay = movementEpochDay,
        notes = notes?.trim().orEmpty().ifBlank { context.reason },
        createdAtEpochMillis = 0L,
        globalId = GlobalId.new().value,
        idempotencyKey = context.idempotencyKey,
        correlationId = context.correlationId,
        actorId = context.actorId,
        deviceId = context.deviceId,
        locationId = requireNotNull(context.locationId),
        unitCostRial = unitCostRial,
        reasonCode = context.reasonCode.storedValue,
        reversalOfMovementId = reversalOfMovementId,
    )

    private suspend fun replayOrConflict(expected: StockMovementEntity): InventoryLedgerResult? {
        val existing = database.stockMovementDao().byIdempotencyKey(expected.idempotencyKey) ?: return null
        val samePayload = existing.itemId == expected.itemId &&
            existing.movementType == expected.movementType &&
            existing.quantityDeltaMicros == expected.quantityDeltaMicros &&
            existing.valueDeltaRial == expected.valueDeltaRial &&
            existing.referenceType == expected.referenceType &&
            existing.referenceId == expected.referenceId &&
            existing.movementEpochDay == expected.movementEpochDay &&
            existing.notes == expected.notes &&
            existing.correlationId == expected.correlationId &&
            existing.actorId == expected.actorId &&
            existing.deviceId == expected.deviceId &&
            existing.locationId == expected.locationId &&
            existing.unitCostRial == expected.unitCostRial &&
            existing.reasonCode == expected.reasonCode &&
            existing.reversalOfMovementId == expected.reversalOfMovementId
        if (!samePayload) throw BusinessError.IdempotencyConflict(expected.idempotencyKey).asViolation()
        return InventoryLedgerResult(existing.id, existing.globalId, idempotentReplay = true)
    }

    private suspend fun insert(entity: StockMovementEntity): InventoryLedgerResult {
        val movementId = database.stockMovementDao().insert(entity)
        return InventoryLedgerResult(movementId, entity.globalId, idempotentReplay = false)
    }

    private suspend fun consumeLotsFefo(
        itemId: Long,
        quantityMicros: Long,
        movementId: Long,
        movementEpochDay: Long,
        allowExpired: Boolean,
        now: Long,
    ) {
        var remaining = quantityMicros
        if (remaining <= 0L) return
        for (lot in database.managementControlDao().availableLotsFefo(itemId)) {
            if (remaining == 0L) break
            if (!allowExpired && lot.expiryEpochDay != null && lot.expiryEpochDay < movementEpochDay) {
                throw BusinessError.LotExpired(lot.id, lot.expiryEpochDay).asViolation()
            }
            val consumed = minOf(remaining, lot.quantityMicros)
            check(
                database.managementControlDao().updateLot(
                    lot.copy(
                        quantityMicros = SignedLongMath.subtract(lot.quantityMicros, consumed),
                        updatedAtEpochMillis = now,
                    ),
                ) == 1,
            ) { "کاهش موجودی لات انجام نشد." }
            database.managementControlDao().insertLotConsumption(
                InventoryLotConsumptionEntity(
                    stockMovementId = movementId,
                    lotId = lot.id,
                    quantityMicros = consumed,
                ),
            )
            remaining = SignedLongMath.subtract(remaining, consumed)
        }
        businessRequire(remaining == 0L) {
            BusinessError.InsufficientStock(itemId, "lot allocation", quantityMicros, quantityMicros - remaining)
        }
    }

    private fun unitCost(valueRial: Long, quantityMicros: Long): Long =
        if (valueRial == 0L) 0L else FixedPointRatio.unitCostRial(valueRial, quantityMicros)

    private suspend fun <T> inventoryTransaction(
        businessEpochDay: Long,
        block: suspend () -> T,
    ): T = try {
        database.withTransaction { block() }
    } catch (error: Throwable) {
        throw mapDatabaseBusinessFailure(error, businessEpochDay)
    }

    private fun absExact(value: Long): Long {
        require(value != Long.MIN_VALUE) { "مقدار از محدوده امن خارج است." }
        return kotlin.math.abs(value)
    }

    private fun InventoryMovementType.canDisposeExpiredLots(): Boolean = this in setOf(
        InventoryMovementType.PURCHASE_REVERSAL,
        InventoryMovementType.PURCHASE_RETURN,
        InventoryMovementType.INVENTORY_COUNT,
        InventoryMovementType.WASTE,
    )
}
