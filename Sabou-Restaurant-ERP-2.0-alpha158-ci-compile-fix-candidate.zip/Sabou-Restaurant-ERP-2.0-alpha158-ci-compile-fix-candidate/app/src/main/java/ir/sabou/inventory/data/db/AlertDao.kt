package ir.sabou.inventory.data.db

import androidx.room.Dao
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
@Dao
interface AlertDao {
    @Query("SELECT * FROM app_alerts WHERE isDismissed=0 ORDER BY CASE severity WHEN 'HIGH' THEN 0 WHEN 'MEDIUM' THEN 1 ELSE 2 END, COALESCE(dueEpochDay, 9223372036854775807), updatedAtEpochMillis DESC")
    fun observeVisible(): Flow<List<AppAlertEntity>>

    @Query("""
        INSERT INTO app_alerts(sourceType,sourceId,title,message,severity,dueEpochDay,isRead,isDismissed,createdAtEpochMillis,updatedAtEpochMillis)
        VALUES(:sourceType,:sourceId,:title,:message,:severity,:dueEpochDay,0,0,:now,:now)
        ON CONFLICT(sourceType,sourceId) DO UPDATE SET
            title=excluded.title,
            message=excluded.message,
            severity=excluded.severity,
            dueEpochDay=excluded.dueEpochDay,
            updatedAtEpochMillis=excluded.updatedAtEpochMillis
    """)
    suspend fun upsertGenerated(sourceType: String, sourceId: Long, title: String, message: String, severity: String, dueEpochDay: Long?, now: Long)

    @Query("SELECT sourceType, sourceId FROM app_alerts")
    suspend fun generatedKeys(): List<AlertKeyRow>

    @Query("DELETE FROM app_alerts WHERE sourceType=:sourceType AND sourceId=:sourceId")
    suspend fun deleteGenerated(sourceType: String, sourceId: Long)

    @Query("UPDATE app_alerts SET isRead=1, updatedAtEpochMillis=:now WHERE id=:id")
    suspend fun markRead(id: Long, now: Long): Int

    @Query("UPDATE app_alerts SET isDismissed=1, updatedAtEpochMillis=:now WHERE id=:id")
    suspend fun dismiss(id: Long, now: Long): Int

    @Query("DELETE FROM app_alerts WHERE isDismissed=1")
    suspend fun clearDismissed(): Int

    @Query("""
        SELECT p.id, p.invoiceNo, sp.name AS supplierName, p.dueEpochDay,
               (p.totalRial-p.paidRial) AS outstandingRial
        FROM purchases p
        INNER JOIN suppliers sp ON sp.id=p.supplierId
        WHERE p.paymentStatus IN ('UNPAID','PARTIAL') AND p.dueEpochDay<=:todayEpochDay
        ORDER BY p.dueEpochDay
    """)
    suspend fun overduePurchases(todayEpochDay: Long): List<OverduePurchaseAlertRow>

    @Query("SELECT * FROM inventory_items WHERE isActive=1 AND alertEnabled=1 AND stockMicros<=alertThresholdMicros ORDER BY stockMicros, name")
    suspend fun lowStock(): List<InventoryItemEntity>
}

data class AlertKeyRow(val sourceType: String, val sourceId: Long)
data class OverdueFollowUpAlertRow(val id: Long, val title: String, val dueEpochDay: Long, val customerName: String)
