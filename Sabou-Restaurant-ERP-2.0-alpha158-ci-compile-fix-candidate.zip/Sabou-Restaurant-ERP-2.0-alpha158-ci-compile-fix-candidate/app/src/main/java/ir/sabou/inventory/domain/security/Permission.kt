package ir.sabou.inventory.domain.security

enum class Permission(val title: String) {
    PURCHASES("خرید"),
    SUPPLIERS("تأمین‌کنندگان"),
    INVENTORY("انبار"),
    RECIPES("رسپی"),
    SALES("فروش"),
    ACCOUNTING("حسابداری"),
    REPORTS("گزارش‌ها"),
    AUDIT("حسابرسی"),
    PERSONNEL("پرسنل"),
    ASSETS("دارایی ثابت"),
    BACKUP("پشتیبان و خروجی"),
    MANAGE_USERS("مدیریت کاربران"),
    INVENTORY_ADJUST("تأیید اصلاح موجودی"),
    INVENTORY_PERIOD_CLOSE("بستن دوره انبار"),
    PURCHASE_APPROVE("تأیید درخواست خرید"),
    PAYMENT_APPROVE("تأیید پرداخت"),
    PAYROLL_APPROVE("تأیید نهایی حقوق"),
    JOURNAL_REVERSE("برگشت سند حسابداری"),
    ACCOUNTING_PERIOD_CLOSE("بستن دوره مالی"),
    SALES_DAY_CLOSE("بستن روز فروش"),
    RESTORE("بازیابی اطلاعات"),
    EXPORT("خروجی اطلاعات"),
}

enum class UserRole(
    val title: String,
    private val grantedPermissions: Set<Permission>,
) {
    OWNER("مالک", Permission.entries.toSet()),
    MANAGER(
        "مدیر",
        setOf(
            Permission.PURCHASES,
            Permission.SUPPLIERS,
            Permission.INVENTORY,
            Permission.RECIPES,
            Permission.SALES,
            Permission.ACCOUNTING,
            Permission.REPORTS,
            Permission.AUDIT,
            Permission.PERSONNEL,
            Permission.ASSETS,
            Permission.INVENTORY_ADJUST,
            Permission.INVENTORY_PERIOD_CLOSE,
            Permission.PURCHASE_APPROVE,
            Permission.PAYMENT_APPROVE,
            Permission.JOURNAL_REVERSE,
            Permission.ACCOUNTING_PERIOD_CLOSE,
            Permission.SALES_DAY_CLOSE,
            Permission.EXPORT,
        ),
    ),
    CASHIER("صندوقدار", setOf(Permission.SALES, Permission.REPORTS)),
    INVENTORY("انبار", setOf(Permission.INVENTORY)),
    STOREKEEPER(
        "انباردار",
        setOf(
            Permission.PURCHASES,
            Permission.SUPPLIERS,
            Permission.INVENTORY,
            Permission.RECIPES,
            Permission.INVENTORY_ADJUST,
        ),
    ),
    ACCOUNTANT(
        "حسابدار",
        setOf(
            Permission.PURCHASES,
            Permission.SALES,
            Permission.ACCOUNTING,
            Permission.REPORTS,
            Permission.AUDIT,
            Permission.PERSONNEL,
            Permission.ASSETS,
            Permission.PAYMENT_APPROVE,
            Permission.JOURNAL_REVERSE,
            Permission.ACCOUNTING_PERIOD_CLOSE,
            Permission.EXPORT,
        ),
    ),
    LEGACY_RESTRICTED("نقش قدیمی محدود", emptySet());

    fun allows(permission: Permission): Boolean = permission in grantedPermissions

    companion object {
        fun fromStoredValue(value: String): UserRole =
            entries.firstOrNull { it.name == value.trim().uppercase() } ?: LEGACY_RESTRICTED
    }
}
