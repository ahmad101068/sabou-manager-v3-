package ir.sabou.inventory

import android.app.Application
import ir.sabou.inventory.data.AppContainer
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit
import ir.sabou.inventory.data.AutomaticBackupScheduler
import ir.sabou.inventory.data.BackupPolicyStore
import ir.sabou.inventory.domain.operations.SyncSafetyGate

class SabouApplication : Application() {
    val container: AppContainer by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppContainer(applicationContext)
    }
    override fun onCreate() {
        super.onCreate()
        val request = PeriodicWorkRequestBuilder<AlertRefreshWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("sabou-alert-refresh", ExistingPeriodicWorkPolicy.UPDATE, request)
        if (SyncSafetyGate.isProductionReady) {
            val syncRequest = PeriodicWorkRequestBuilder<CloudSyncWorker>(1, TimeUnit.HOURS).build()
            WorkManager.getInstance(this).enqueueUniquePeriodicWork("sabou-cloud-sync", ExistingPeriodicWorkPolicy.UPDATE, syncRequest)
        } else {
            // Cancel work left behind by older alpha builds. Upload-only sync
            // must never run in the background as if replication were complete.
            WorkManager.getInstance(this).cancelUniqueWork("sabou-cloud-sync")
        }
        AutomaticBackupScheduler.apply(this, BackupPolicyStore(this).load())
    }
}
