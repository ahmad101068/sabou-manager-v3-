package ir.sabou.inventory

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import ir.sabou.inventory.domain.operations.SyncRetryPolicy
import ir.sabou.inventory.domain.operations.SyncSafetyGate

class CloudSyncWorker(context:Context,params:WorkerParameters):CoroutineWorker(context,params){
    override suspend fun doWork():Result{if(!SyncSafetyGate.isProductionReady)return Result.success();val container=(applicationContext as SabouApplication).container;if(!container.syncConfig().enabled)return Result.success();val retry=SyncRetryPolicy.decide(runAttemptCount,System.currentTimeMillis(),0);if(!retry.canRetry&&runAttemptCount>=8)return Result.failure();return runCatching{container.runSync();Result.success()}.getOrElse{Result.retry()}}
}
