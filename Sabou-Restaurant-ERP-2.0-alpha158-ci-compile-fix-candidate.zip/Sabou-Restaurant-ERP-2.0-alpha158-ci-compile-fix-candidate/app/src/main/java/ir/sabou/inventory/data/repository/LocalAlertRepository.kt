package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppAlertEntity
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.domain.operations.AlertRepository

class LocalAlertRepository(private val db: AppDatabase) : AlertRepository {
    override fun alerts() = db.alertDao().observeVisible()

    override suspend fun refresh(todayEpochDay: Long) = db.withTransaction {
        val now = System.currentTimeMillis()
        val activeKeys = mutableSetOf<Pair<String, Long>>()

        db.alertDao().overduePurchases(todayEpochDay).forEach { row ->
            activeKeys += "PURCHASE_PAYABLE" to row.id
            db.alertDao().upsertGenerated(
                sourceType = "PURCHASE_PAYABLE",
                sourceId = row.id,
                title = "بدهی سررسیدشده تأمین‌کننده",
                message = "فاکتور ${row.invoiceNo} · ${row.supplierName} · مانده ${row.outstandingRial} ریال",
                severity = "HIGH",
                dueEpochDay = row.dueEpochDay,
                now = now,
            )
        }
        db.alertDao().lowStock().forEach { item ->
            activeKeys += "LOW_STOCK" to item.id
            db.alertDao().upsertGenerated(
                sourceType = "LOW_STOCK",
                sourceId = item.id,
                title = "هشدار کمبود موجودی",
                message = "${item.name}: موجودی به حد هشدار رسیده است",
                severity = "MEDIUM",
                dueEpochDay = null,
                now = now,
            )
        }

        db.alertDao().generatedKeys().forEach { key ->
            if ((key.sourceType to key.sourceId) !in activeKeys) {
                db.alertDao().deleteGenerated(key.sourceType, key.sourceId)
            }
        }
    }

    override suspend fun markRead(id: Long) {
        db.alertDao().markRead(id, System.currentTimeMillis())
    }

    override suspend fun dismiss(id: Long) {
        db.alertDao().dismiss(id, System.currentTimeMillis())
    }

    override suspend fun clearDismissed() {
        db.alertDao().clearDismissed()
    }
}
