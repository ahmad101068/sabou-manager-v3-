package ir.sabou.inventory.data

import ir.sabou.inventory.domain.security.Permission

import android.content.Context
import android.net.Uri
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.APP_DATABASE_SCHEMA_VERSION
import ir.sabou.inventory.data.db.AccountSeedCallback
import ir.sabou.inventory.data.db.clearAllTablesForFactoryReset
import ir.sabou.inventory.data.repository.DashboardRepository
import ir.sabou.inventory.data.repository.LocalAccountingRepository
import ir.sabou.inventory.data.repository.LocalOperationsRepository
import ir.sabou.inventory.data.repository.LocalPurchaseRepository
import ir.sabou.inventory.data.repository.LocalProcurementRepository
import ir.sabou.inventory.data.repository.LocalPersonnelRepository
import ir.sabou.inventory.data.repository.LocalPerformanceRepository
import ir.sabou.inventory.data.repository.LocalSyncRepository
import ir.sabou.inventory.data.repository.SyncRecorder
import ir.sabou.inventory.data.repository.LocalDailySalesRepository
import ir.sabou.inventory.data.repository.LocalSecurityRepository
import ir.sabou.inventory.data.repository.LocalAssetRepository
import ir.sabou.inventory.data.repository.LocalRecipeRepository
import ir.sabou.inventory.data.repository.LocalAlertRepository
import ir.sabou.inventory.data.repository.LocalManagementControlRepository
import ir.sabou.inventory.data.repository.LocalAccountingPostingEngine
import ir.sabou.inventory.data.repository.LocalAuditEventWriter
import ir.sabou.inventory.data.treasury.LegacyTreasuryAccountCatalog
import ir.sabou.inventory.data.security.DatabaseKeyProvider
import ir.sabou.inventory.data.security.SensitiveActionGate
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.accounting.AccountingRepository
import ir.sabou.inventory.domain.accounting.AccountingPostingService
import ir.sabou.inventory.domain.audit.AuditService
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.purchase.PurchaseRepository
import ir.sabou.inventory.domain.purchase.ProcurementRepository
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.sales.DailySalesRepository
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.SensitiveAction
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.operations.AlertRepository
import ir.sabou.inventory.domain.operations.CloudSyncConfig
import ir.sabou.inventory.domain.operations.SyncSafetyGate
import ir.sabou.inventory.domain.control.ManagementControlRepository
import ir.sabou.inventory.domain.security.AuthorizationService
import ir.sabou.inventory.domain.treasury.TreasuryAccountCatalog
import ir.sabou.inventory.data.repository.HttpsSyncTransport
import ir.sabou.inventory.data.repository.SyncCoordinator
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val keyProvider = DatabaseKeyProvider(appContext)
    private val sensitiveActionGate = SensitiveActionGate()
    private val deviceId: String by lazy {
        val preferences = context.getSharedPreferences("sync_identity", Context.MODE_PRIVATE)
        preferences.getString("device_id", null) ?: UUID.randomUUID().toString().also { generated ->
            check(preferences.edit().putString("device_id", generated).commit()) { "ذخیره شناسه دستگاه انجام نشد." }
        }
    }
    val backupManager = BackupManager(appContext, keyProvider) { deviceId }
    private val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        backupManager.applyPendingRestore()
        backupManager.preparePreMigrationRecovery(APP_DATABASE_SCHEMA_VERSION)
        var openedDatabase: AppDatabase? = null
        try {
            openedDatabase = openAndValidateDatabase()
            backupManager.markRestoreValidated()
            backupManager.markDatabaseSchemaValidated(APP_DATABASE_SCHEMA_VERSION)
            checkNotNull(openedDatabase)
        } catch (error: Throwable) {
            openedDatabase?.close()
            if (backupManager.rollbackLastRestore()) {
                val recoveredDatabase = openAndValidateDatabase()
                try {
                    backupManager.markRestoreValidated()
                    backupManager.markDatabaseSchemaValidated(APP_DATABASE_SCHEMA_VERSION)
                    recoveredDatabase
                } catch (recoveryError: Throwable) {
                    recoveredDatabase.close()
                    recoveryError.addSuppressed(error)
                    throw recoveryError
                }
            } else {
                runCatching { backupManager.rollbackPreMigrationRecovery() }
                    .exceptionOrNull()
                    ?.let(error::addSuppressed)
                throw error
            }
        }
    }

    private fun openAndValidateDatabase(): AppDatabase {
        val database = AppDatabase.create(appContext, keyProvider)
        try {
            val sqlite = database.openHelper.writableDatabase
            val cipherResults = sqlite.query("PRAGMA cipher_integrity_check").use { cursor ->
                buildList {
                    while (cursor.moveToNext()) add(cursor.getString(0))
                }
            }
            require(cipherResults.isEmpty() || cipherResults.all { it.equals("ok", ignoreCase = true) }) {
                "اعتبارسنجی پایگاه داده ناموفق بود."
            }
            sqlite.execSQL("DELETE FROM app_session")
            return database
        } catch (error: Throwable) {
            database.close()
            throw error
        }
    }
    private val authorizer by lazy { SessionAuthorizer(database) }
    val authorizationService: AuthorizationService by lazy { authorizer }
    val auditService: AuditService by lazy { LocalAuditEventWriter(database) }
    val accountingPostingService: AccountingPostingService by lazy {
        LocalAccountingPostingEngine(database)
    }
    val treasuryAccountCatalog: TreasuryAccountCatalog by lazy {
        LegacyTreasuryAccountCatalog()
    }

    /** Opens and validates the encrypted Room database. Call this from a background dispatcher. */
    fun initialize() {
        database.openHelper.writableDatabase
    }

    val purchaseRepository: PurchaseRepository by lazy {
        LocalPurchaseRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }

    val procurementRepository: ProcurementRepository by lazy {
        LocalProcurementRepository(database, authorizer, syncRecorder = syncRecorder)
    }

    val dailySalesRepository: DailySalesRepository by lazy {
        LocalDailySalesRepository(
            database,
            authorizer,
            syncRecorder = syncRecorder,
            sensitiveActionGate = sensitiveActionGate,
        )
    }

    val recipeRepository: RecipeRepository by lazy { LocalRecipeRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }

    val dashboardRepository: DashboardRepository by lazy {
        DashboardRepository(database)
    }

    val operationsRepository: OperationsRepository by lazy {
        LocalOperationsRepository(
            database,
            syncRecorder = syncRecorder,
            authorizer = authorizer,
            sensitiveActionGate = sensitiveActionGate,
        )
    }

    val securityRepository: SecurityRepository by lazy {
        LocalSecurityRepository(
            database,
            authorizer = authorizer,
            sensitiveActionGate = sensitiveActionGate,
            deviceIdProvider = { deviceId },
        )
    }

    val personnelRepository: PersonnelRepository by lazy { LocalPersonnelRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val performanceRepository by lazy { LocalPerformanceRepository(database, authorizer = authorizer, syncRecorder = syncRecorder) }
    val syncRepository by lazy { LocalSyncRepository(database) }
    private val syncPreferences by lazy { appContext.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE) }
    fun syncConfig(): CloudSyncConfig = CloudSyncConfig(
        endpoint = syncPreferences.getString("endpoint", "").orEmpty(),
        tenantId = syncPreferences.getString("tenant", "").orEmpty(),
        enabled = syncPreferences.getBoolean("enabled", false) && SyncSafetyGate.isProductionReady,
        accessToken = syncPreferences.getString("access_token_protected", null)?.let(keyProvider::unprotectSecret)
            ?: syncPreferences.getString("access_token", "").orEmpty(),
        refreshToken = syncPreferences.getString("refresh_token_protected", null)?.let(keyProvider::unprotectSecret)
            ?: syncPreferences.getString("refresh_token", "").orEmpty(),
        accessTokenExpiresAtEpochMillis = syncPreferences.getLong("access_expires_at", 0),
        deviceId = deviceId,
    )
    private fun persistSyncConfig(config: CloudSyncConfig) {
        check(
            syncPreferences.edit()
                .putString("endpoint", config.endpoint.trim())
                .putString("tenant", config.tenantId.trim())
                .putBoolean("enabled", config.enabled)
                .putString("access_token_protected", keyProvider.protectSecret(config.accessToken))
                .putString("refresh_token_protected", keyProvider.protectSecret(config.refreshToken))
                .remove("access_token")
                .remove("refresh_token")
                .putLong("access_expires_at", config.accessTokenExpiresAtEpochMillis)
                .commit(),
        )
    }
    suspend fun saveSyncConfig(config: CloudSyncConfig) { authorizer.require(Permission.BACKUP); if(config.enabled) SyncSafetyGate.requireProductionReady(); val normalized=config.copy(deviceId=deviceId,enabled=false); persistSyncConfig(normalized) }
    suspend fun runSync(): ir.sabou.inventory.data.repository.SyncRunResult { SyncSafetyGate.requireProductionReady(); var config=syncConfig(); if(config.enabled && config.accessTokenExpired){config=ir.sabou.inventory.data.repository.SyncTokenRefresher().refresh(config);persistSyncConfig(config)}; return SyncCoordinator(syncRepository,HttpsSyncTransport(config)).runOnce() }
    suspend fun runSyncAuthorized() = authorizer.require(Permission.BACKUP).let { runSync() }
    suspend fun resolveSyncIssueAuthorized(changeId:String,keepLocal:Boolean){authorizer.require(Permission.BACKUP);syncRepository.resolveIssue(changeId,keepLocal)}
    val syncRecorder by lazy { SyncRecorder(database, deviceId) }
    val assetRepository: AssetRepository by lazy { LocalAssetRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val alertRepository: AlertRepository by lazy { LocalAlertRepository(database) }
    val managementControlRepository: ManagementControlRepository by lazy {
        LocalManagementControlRepository(
            database,
            procurementRepository,
            authorizer,
            syncRecorder = syncRecorder,
            sensitiveActionGate = sensitiveActionGate,
        )
    }

    suspend fun createBackup(): String {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) {
            backupManager.create(database).also { backupManager.prune(BackupPolicyStore(appContext).load().maxFiles) }
        }
    }
    internal suspend fun createAutomaticBackup(maxFiles: Int): String = withContext(Dispatchers.IO) {
        backupManager.create(database).also { backupManager.prune(maxFiles) }
    }
    suspend fun factoryReset() {
        authorizer.require(Permission.MANAGE_USERS)
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.FACTORY_RESET)
        withContext(Dispatchers.IO) {
            database.clearAllTablesForFactoryReset()
            AccountSeedCallback.seedMissingAccounts(database.openHelper.writableDatabase)
            AccountSeedCallback.seedSystemLocations(database.openHelper.writableDatabase)
            backupManager.clearAll()
            listOf("cloud_sync", "sync_identity", "automatic_backup_policy").forEach { name ->
                check(appContext.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit()) {
                    "پاک‌سازی تنظیمات $name انجام نشد."
                }
            }
        }
    }
    suspend fun listBackups(): List<String> {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) { backupManager.list() }
    }
    suspend fun deleteBackup(name: String) {
        authorizer.require(Permission.BACKUP)
        withContext(Dispatchers.IO) { backupManager.delete(name) }
    }
    suspend fun scheduleRestore(name: String) {
        authorizer.require(Permission.BACKUP)
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.RESTORE_BACKUP)
        withContext(Dispatchers.IO) {
            require(backupManager.verify(name)) { "فایل پشتیبان معتبر نیست یا تغییر کرده است." }
            val recoveryName = backupManager.create(database)
            try {
                backupManager.scheduleRestore(name, recoveryName)
            } catch (error: Throwable) {
                runCatching { backupManager.delete(recoveryName) }
                throw error
            }
        }
    }
    suspend fun exportBackup(name: String, password: CharArray, destination: Uri) {
        authorizer.require(Permission.BACKUP)
        withContext(Dispatchers.IO) {
            val output = requireNotNull(appContext.contentResolver.openOutputStream(destination, "w")) {
                "امکان نوشتن فایل مقصد وجود ندارد."
            }
            output.use { backupManager.exportPortable(name, password, it) }
        }
    }
    suspend fun importBackup(source: Uri, password: CharArray): String {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) {
            val input = requireNotNull(appContext.contentResolver.openInputStream(source)) {
                "امکان خواندن فایل انتخاب‌شده وجود ندارد."
            }
            backupManager.importPortable(input, password).also { backupManager.prune(BackupPolicyStore(appContext).load().maxFiles) }
        }
    }

    val accountingRepository: AccountingRepository by lazy {
        LocalAccountingRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }
}
