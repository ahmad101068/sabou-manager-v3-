package ir.sabou.inventory.domain.operations

import ir.sabou.inventory.core.SignedLongMath

data class ReorderPolicy(
    val leadTimeDays: Int = 2,
    val safetyStockDays: Int = 1,
    val reviewHorizonDays: Int = 7,
) {
    fun validated(): ReorderPolicy {
        require(leadTimeDays in 0..365) { "زمان تأمین معتبر نیست." }
        require(safetyStockDays in 0..365) { "ذخیره ایمن معتبر نیست." }
        require(reviewHorizonDays in 1..365) { "افق سفارش معتبر نیست." }
        return this
    }
}

data class ReorderInput(
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val currentStockMicros: Long,
    val onOrderMicros: Long = 0,
    val averageDailyUsageMicros: Long,
    val minimumStockMicros: Long = 0,
    val policy: ReorderPolicy = ReorderPolicy(),
) {
    fun validated(): ReorderInput {
        require(itemId > 0 && itemName.isNotBlank() && unit.isNotBlank()) { "کالای سفارش معتبر نیست." }
        require(currentStockMicros >= 0 && onOrderMicros >= 0) { "موجودی نمی‌تواند منفی باشد." }
        require(averageDailyUsageMicros >= 0 && minimumStockMicros >= 0) { "مصرف یا حداقل موجودی معتبر نیست." }
        policy.validated()
        return this
    }
}

data class ReorderRecommendation(
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val projectedNeedMicros: Long,
    val availableMicros: Long,
    val recommendedOrderMicros: Long,
    val daysUntilStockout: Int?,
    val urgency: ReorderUrgency,
)

enum class ReorderUrgency { NONE, PLAN, SOON, CRITICAL }

object SmartReorderCalculator {
    fun recommend(input: ReorderInput): ReorderRecommendation {
        val value = input.validated()
        val horizon = value.policy.leadTimeDays + value.policy.safetyStockDays + value.policy.reviewHorizonDays
        val projectedNeed = SignedLongMath.multiply(value.averageDailyUsageMicros, horizon.toLong())
        val available = SignedLongMath.add(value.currentStockMicros, value.onOrderMicros)
        val target = maxOf(projectedNeed, value.minimumStockMicros)
        val order = (target - available).coerceAtLeast(0L)
        val daysUntilStockout = if (value.averageDailyUsageMicros > 0) (value.currentStockMicros / value.averageDailyUsageMicros).toInt() else null
        val urgency = when {
            order == 0L -> ReorderUrgency.NONE
            value.currentStockMicros <= value.minimumStockMicros -> ReorderUrgency.CRITICAL
            daysUntilStockout != null && daysUntilStockout <= value.policy.leadTimeDays -> ReorderUrgency.SOON
            else -> ReorderUrgency.PLAN
        }
        return ReorderRecommendation(value.itemId, value.itemName, value.unit, projectedNeed, available, order, daysUntilStockout, urgency)
    }
}
