package ir.sabou.inventory.domain.inventory

import ir.sabou.inventory.core.CorrelationId
import ir.sabou.inventory.core.GlobalId

enum class InventoryMovementType(val storedValue: String) {
    PURCHASE("PURCHASE"),
    PURCHASE_REVERSAL("PURCHASE_REVERSAL"),
    GOODS_RECEIPT("GOODS_RECEIPT"),
    PURCHASE_RETURN("PURCHASE_RETURN"),
    LEGACY_SALE_CONSUMPTION("SALE_CONSUMPTION"),
    DAILY_SALES_CONSUMPTION("DAILY_SALES_CONSUMPTION"),
    DAILY_SALES_REVERSAL("DAILY_SALES_REVERSAL"),
    INVENTORY_COUNT("INVENTORY_COUNT"),
    WASTE("WASTE"),
    TRANSFER_IN("TRANSFER_IN"),
    TRANSFER_OUT("TRANSFER_OUT"),
    LEGACY_UNKNOWN("LEGACY_UNKNOWN");

    companion object {
        fun fromStoredValue(value: String): InventoryMovementType =
            entries.firstOrNull { it.storedValue == value } ?: LEGACY_UNKNOWN
    }
}

enum class InventoryReferenceType(val storedValue: String) {
    PURCHASE("PURCHASE"),
    GOODS_RECEIPT("GOODS_RECEIPT"),
    PURCHASE_RETURN("PURCHASE_RETURN"),
    DAILY_SALES("DAILY_SALES"),
    INVENTORY_COUNT("INVENTORY_COUNT"),
    WASTE("WASTE"),
    STOCK_TRANSFER("STOCK_TRANSFER"),
    LEGACY_UNKNOWN("LEGACY_UNKNOWN");

    companion object {
        fun fromStoredValue(value: String): InventoryReferenceType =
            entries.firstOrNull { it.storedValue == value } ?: LEGACY_UNKNOWN
    }
}

enum class InventoryReasonCode(val storedValue: String) {
    PURCHASE_RECEIPT("PURCHASE_RECEIPT"),
    PURCHASE_REVERSAL("PURCHASE_REVERSAL"),
    GOODS_RECEIPT("GOODS_RECEIPT"),
    PURCHASE_RETURN("PURCHASE_RETURN"),
    SALES_CONSUMPTION("SALES_CONSUMPTION"),
    SALES_REVERSAL("SALES_REVERSAL"),
    PHYSICAL_COUNT("PHYSICAL_COUNT"),
    WASTE("WASTE"),
    STOCK_TRANSFER("STOCK_TRANSFER"),
}

data class InventoryCommandContext(
    val idempotencyKey: String,
    val correlationId: String,
    val actorId: Long,
    val deviceId: String,
    val locationId: Long?,
    val reasonCode: InventoryReasonCode,
    val reason: String,
) {
    fun validated(): InventoryCommandContext {
        val normalizedKey = idempotencyKey.trim()
        val normalizedCorrelation = CorrelationId.parse(correlationId).value
        val normalizedDevice = deviceId.trim()
        val normalizedReason = reason.trim()
        require(normalizedKey.matches(Regex("[A-Za-z0-9:_./-]{8,180}"))) {
            "کلید idempotency معتبر نیست."
        }
        require(actorId > 0) { "شناسه actor معتبر نیست." }
        require(normalizedDevice.length in 1..120) { "شناسه دستگاه معتبر نیست." }
        require(locationId == null || locationId > 0) { "شناسه مکان معتبر نیست." }
        require(normalizedReason.length in 2..500) { "دلیل عملیات موجودی الزامی است." }
        return copy(
            idempotencyKey = normalizedKey,
            correlationId = normalizedCorrelation,
            deviceId = normalizedDevice,
            reason = normalizedReason,
        )
    }

    companion object {
        fun local(
            referenceType: InventoryReferenceType,
            referenceId: Long,
            suffix: String,
            actorId: Long,
            reasonCode: InventoryReasonCode,
            reason: String,
            correlationId: String = "local:${GlobalId.new().value}",
            deviceId: String = "local-android",
            locationId: Long? = null,
        ): InventoryCommandContext {
            require(referenceId > 0) { "شناسه مرجع موجودی معتبر نیست." }
            val normalizedSuffix = suffix.trim().replace(' ', '_').take(80)
            require(normalizedSuffix.isNotBlank()) { "جزء کلید عملیات موجودی الزامی است." }
            val key = "${referenceType.storedValue}:$referenceId:$normalizedSuffix"
            return InventoryCommandContext(
                idempotencyKey = key,
                correlationId = correlationId,
                actorId = actorId,
                deviceId = deviceId,
                locationId = locationId,
                reasonCode = reasonCode,
                reason = reason,
            ).validated()
        }
    }
}

data class InventoryLedgerResult(
    val movementId: Long,
    val globalId: String,
    val idempotentReplay: Boolean,
)
