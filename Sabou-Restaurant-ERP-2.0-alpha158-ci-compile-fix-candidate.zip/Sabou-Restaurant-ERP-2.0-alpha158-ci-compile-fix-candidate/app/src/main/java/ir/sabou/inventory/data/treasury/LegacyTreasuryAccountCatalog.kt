package ir.sabou.inventory.data.treasury

import ir.sabou.inventory.domain.treasury.TreasuryAccount
import ir.sabou.inventory.domain.treasury.TreasuryAccountCatalog
import ir.sabou.inventory.domain.treasury.TreasuryAccountId
import ir.sabou.inventory.domain.treasury.TreasuryAccountKind
import ir.sabou.inventory.domain.treasury.TreasuryChannel

/**
 * Compatibility catalog for Alpha157. It exposes existing cash/bank concepts without claiming a
 * dedicated treasury table or creating a second balance source of truth.
 */
class LegacyTreasuryAccountCatalog : TreasuryAccountCatalog {
    private val accounts = listOf(
        TreasuryAccount(
            TreasuryAccountId.parse("cash_main"),
            "صندوق اصلی",
            TreasuryAccountKind.CASH,
            TreasuryChannel.CASH,
            isActive = true,
        ),
        TreasuryAccount(
            TreasuryAccountId.parse("bank_main"),
            "حساب بانکی اصلی",
            TreasuryAccountKind.BANK,
            TreasuryChannel.BANK,
            isActive = true,
        ),
        TreasuryAccount(
            TreasuryAccountId.parse("card_terminal"),
            "کارتخوان",
            TreasuryAccountKind.CARD_TERMINAL,
            TreasuryChannel.CARD,
            isActive = true,
        ),
        TreasuryAccount(
            TreasuryAccountId.parse("petty_cash"),
            "تنخواه",
            TreasuryAccountKind.PETTY_CASH,
            TreasuryChannel.CASH,
            isActive = true,
        ),
    )

    override fun activeAccounts(): List<TreasuryAccount> = accounts

    override fun account(id: TreasuryAccountId): TreasuryAccount? =
        accounts.firstOrNull { it.id == id }
}
