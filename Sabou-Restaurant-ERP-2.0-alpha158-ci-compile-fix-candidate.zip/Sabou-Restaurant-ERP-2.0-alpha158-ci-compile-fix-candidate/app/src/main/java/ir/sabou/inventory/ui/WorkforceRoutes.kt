package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable

@Composable
internal fun WorkforceRoutes(
    screen: AppScreen,
    personnelState: PersonnelUiState,
    personnel: PersonnelViewModel,
    performanceState: PerformanceUiState,
    performance: PerformanceViewModel,
    assetState: AssetUiState,
    assets: AssetViewModel,
    requestedEmployeeProfileId: Long?,
    onProfileRequestConsumed: () -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.PERSONNEL -> PersonnelScreen(
            state = personnelState,
            requestedProfileEmployeeId = requestedEmployeeProfileId,
            onProfileRequestConsumed = onProfileRequestConsumed,
            performanceState = performanceState,
            onSaveEmployee = personnel::saveEmployee,
            onDeactivate = personnel::deactivate,
            onSaveAttendance = personnel::saveAttendance,
            onPostPayroll = personnel::postPayroll,
            onApprovePayroll = personnel::approvePayroll,
            onReversePayroll = personnel::reversePayroll,
            onCalculatePayroll = personnel::calculatePayroll,
            onSavePayrollPolicy = personnel::savePayrollPolicy,
            onSelectEmployee = personnel::selectEmployee,
            onSaveContract = personnel::saveContract,
            onPostAdvance = personnel::postAdvance,
            onSettleAdvance = personnel::settleAdvance,
            onRequestLeave = personnel::requestLeave,
            onReviewLeave = personnel::reviewLeave,
            onCancelLeave = personnel::cancelLeave,
            onLoadAttendanceSummary = personnel::loadAttendanceSummary,
            onSavePerformanceGoal = { performance.saveGoal(null, it) },
            onDeactivatePerformanceGoal = performance::deactivateGoal,
            onSubmitPerformanceReview = performance::submitReview,
            onBack = navigateBack,
        )

        AppScreen.ASSETS -> AssetScreen(
            state = assetState,
            onSave = assets::save,
            onRecognize = assets::recognize,
            onDispose = assets::dispose,
            onDepreciate = assets::depreciate,
            onBack = navigateBack,
        )

        else -> error("workforce_route_group_mismatch:${screen.name}")
    }
}
