package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.FullCostCalculator
import ir.sabou.inventory.domain.recipe.RecipeCostProfile
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.recipe.RecipeIngredientItem
import ir.sabou.inventory.domain.recipe.RecipeRevision

private data class IngredientDraft(
    val inventoryItemId: Long? = null,
    val quantity: String = "",
)

@Composable
fun RecipeScreen(
    state: RecipeUiState,
    onSelect: (Long?) -> Unit,
    onSave: (Long?, String, String, Long, List<RecipeIngredientInput>, RecipeCostProfile, () -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var editorOpen by remember { mutableStateOf(false) }
    val categories = state.menuItems.map { it.category.ifBlank { "بدون دسته‌بندی" } }.distinct().size
    val costDataWarnings = state.menuItems.count {
        it.ingredientCount == 0 || it.costProfile.yieldMicros <= 0 || it.costProfile.note.contains("تبدیل‌شده از رسپی قبلی")
    }

    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = "تولید و رسپی",
                subtitle = "فرمول ساخت، مواد اولیه و قیمت فروش محصولات",
                onBack = onBack,
                actionLabel = "محصول جدید",
                onAction = {
                    onSelect(null)
                    editorOpen = true
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            state.message?.let { message -> item { MessageCard(message) } }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeading("نمای کلی تولید", "اطلاعات محصولات قابل فروش و ساخت")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        MetricTile("محصولات", state.menuItems.size.toString(), Modifier.weight(1f))
                        MetricTile("دسته‌ها", categories.toString(), Modifier.weight(1f))
                    }
                    if (costDataWarnings > 0) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                        ) {
                            Text(
                                "$costDataWarnings محصول نیازمند تکمیل/بازبینی داده بهای کامل است. محصول را باز کنید و نسخه هزینه جدید بسازید.",
                                Modifier.padding(12.dp),
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
            item { SectionHeading("محصولات و فرمول ساخت", "برای مشاهده یا ویرایش رسپی، محصول را انتخاب کنید") }
            if (state.menuItems.isEmpty()) {
                item {
                    EmptyStatePanel(
                        title = "هنوز محصولی تعریف نشده",
                        description = "اولین محصول را ایجاد و مواد اولیه مصرفی آن را مشخص کنید.",
                    )
                }
            } else {
                items(state.menuItems, key = { it.id }) { item ->
                    RecipeProductCard(
                        item = item,
                        ingredients = if (state.selectedMenuItemId == item.id) state.ingredients else emptyList(),
                        onClick = {
                            onSelect(item.id)
                            editorOpen = true
                        },
                    )
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (editorOpen) {
        RecipeEditorDialog(
            selected = state.menuItems.firstOrNull { it.id == state.selectedMenuItemId },
            inventory = state.inventoryItems,
            currentIngredients = state.ingredients,
            revisions = state.revisions,
            busy = state.busy,
            onDismiss = { editorOpen = false },
            onSave = onSave,
        )
    }
}

@Composable
private fun RecipeProductCard(
    item: MenuItem,
    ingredients: List<RecipeIngredientItem>,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = item.category.ifBlank { "بدون دسته‌بندی" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                StatusPill(
                    if (item.ingredientCount == 0) "رسپی ثبت نشده"
                    else if (item.costProfile.note.contains("تبدیل‌شده از رسپی قبلی")) "نیازمند پروفایل هزینه"
                    else "نسخه ${item.recipeRevisionNo} · ${item.ingredientCount} ماده",
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusPill("بازده ${formatQuantity(item.costProfile.yieldMicros)}")
                if (item.costProfile.portionWeightMicros > 0) StatusPill("پرس ${formatQuantity(item.costProfile.portionWeightMicros)}")
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("قیمت فروش", style = MaterialTheme.typography.labelMedium)
                    Text(formatMoney(item.salePriceRial), fontWeight = FontWeight.ExtraBold)
                }
            }
            if (ingredients.isNotEmpty()) {
                Text(
                    text = ingredients.joinToString("  •  ") {
                        "${it.inventoryName}: ${formatQuantity(it.quantityMicrosPerUnit)} ${it.unit}"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            } else if (item.ingredientCount == 0) {
                Text(
                    "برای این محصول هنوز مواد اولیه تعیین نشده است.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            } else Text("برای مشاهده جزئیات مواد، محصول را باز کنید.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RecipeEditorDialog(
    selected: MenuItem?,
    inventory: List<InventoryItemRecord>,
    currentIngredients: List<RecipeIngredientItem>,
    revisions: List<RecipeRevision>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (Long?, String, String, Long, List<RecipeIngredientInput>, RecipeCostProfile, () -> Unit) -> Unit,
) {
    val context = LocalContext.current
    var name by remember(selected?.id) { mutableStateOf(selected?.name.orEmpty()) }
    var category by remember(selected?.id) { mutableStateOf(selected?.category.orEmpty()) }
    var categoryExpanded by remember { mutableStateOf(false) }
    val productCategories = listOf("غذای اصلی", "پیش‌غذا", "سالاد", "نوشیدنی", "دسر", "صبحانه", "فست‌فود", "سرویس و افزودنی")
    var price by remember(selected?.id) { mutableStateOf(selected?.salePriceRial?.let(::formatMoneyInputFromRial).orEmpty()) }
    val existingProfile = selected?.costProfile ?: RecipeCostProfile()
    var productionYield by remember(selected?.id) { mutableStateOf(formatQuantity(existingProfile.yieldMicros)) }
    var portionWeight by remember(selected?.id) { mutableStateOf(if (existingProfile.portionWeightMicros == 0L) "" else formatQuantity(existingProfile.portionWeightMicros)) }
    var preparationWaste by remember(selected?.id) { mutableStateOf(formatBasisPointsInput(existingProfile.preparationWasteBasisPoints)) }
    var cookingWaste by remember(selected?.id) { mutableStateOf(formatBasisPointsInput(existingProfile.cookingWasteBasisPoints)) }
    var packagingCost by remember(selected?.id) { mutableStateOf(existingProfile.packagingCostRial.takeIf { it > 0 }?.let(::formatMoneyInputFromRial).orEmpty()) }
    var directLaborCost by remember(selected?.id) { mutableStateOf(existingProfile.directLaborCostRial.takeIf { it > 0 }?.let(::formatMoneyInputFromRial).orEmpty()) }
    var allocatedOverhead by remember(selected?.id) { mutableStateOf(existingProfile.allocatedOverheadRial.takeIf { it > 0 }?.let(::formatMoneyInputFromRial).orEmpty()) }
    var revisionNote by remember(selected?.id) { mutableStateOf(existingProfile.note) }
    var error by remember(selected?.id) { mutableStateOf<String?>(null) }
    var rows by remember(selected?.id, currentIngredients) {
        mutableStateOf(
            if (currentIngredients.isEmpty()) listOf(IngredientDraft())
            else currentIngredients.map { IngredientDraft(it.inventoryItemId, formatQuantity(it.quantityMicrosPerUnit)) },
        )
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = {
            Text(
                if (selected == null) "محصول و رسپی جدید"
                else "نسخه جدید رسپی ${selected.recipeRevisionNo + 1}",
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 570.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    FormSection("مشخصات محصول", "اطلاعات پایه محصول قابل فروش") {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it; error = null },
                            label = { Text("نام محصول") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Box(Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category.ifBlank { "انتخاب دسته‌بندی منو" }) }
                            androidx.compose.material3.DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                                productCategories.forEach { value -> androidx.compose.material3.DropdownMenuItem(text = { Text(value) }, onClick = { category = value; categoryExpanded = false }) }
                            }
                        }
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = formatMoneyInput(it); error = null },
                            label = { Text("قیمت فروش (${currencyUnitLabel()})") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                item { SectionHeading("مواد اولیه", "مقدار مصرف هر ماده برای تولید یک واحد") }
                itemsIndexed(rows) { index, row ->
                    IngredientEditorCard(
                        index = index,
                        row = row,
                        inventory = inventory,
                        removable = rows.size > 1,
                        onSelectItem = { itemId ->
                            rows = rows.toMutableList().also { it[index] = row.copy(inventoryItemId = itemId) }
                            error = null
                        },
                        onQuantityChange = { value ->
                            rows = rows.toMutableList().also { it[index] = row.copy(quantity = value) }
                            error = null
                        },
                        onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } },
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { rows = rows + IngredientDraft() },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("افزودن ماده اولیه") }
                }
                item {
                    FormSection("پروفایل تولید", "این مشخصات در نسخه رسپی قفل و تاریخی می‌شوند") {
                        OutlinedTextField(productionYield, { productionYield = it; error = null }, label = { Text("بازده تولید") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(portionWeight, { portionWeight = it; error = null }, label = { Text("وزن استاندارد هر پرس (اختیاری)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(preparationWaste, { preparationWaste = it; error = null }, label = { Text("ضایعات آماده‌سازی ٪") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                            OutlinedTextField(cookingWaste, { cookingWaste = it; error = null }, label = { Text("ضایعات پخت ٪") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.weight(1f))
                        }
                    }
                }
                if (revisions.isNotEmpty()) item {
                    FormSection("تاریخچه نسخه‌ها", "نسخه‌های قبلی فقط خواندنی هستند") {
                        revisions.take(6).forEachIndexed { index, revision ->
                            Text("نسخه ${revision.revisionNo} · ${epochDayToPersian(revision.effectiveFromEpochDay).display()} · ${revision.createdBy}", fontWeight = FontWeight.Bold)
                            Text(
                                "بسته‌بندی ${formatMoney(revision.costProfile.packagingCostRial)} · کار مستقیم ${formatMoney(revision.costProfile.directLaborCostRial)} · سربار ${formatMoney(revision.costProfile.allocatedOverheadRial)}",
                                style = MaterialTheme.typography.bodySmall,
                            )
                            if (index == 0 && revisions.size > 1) {
                                val previous = revisions[1].costProfile
                                Text(
                                    "تغییر نسبت به نسخه قبل: بسته‌بندی ${formatSignedMoney(ir.sabou.inventory.core.SignedLongMath.subtract(revision.costProfile.packagingCostRial, previous.packagingCostRial))} · کار ${formatSignedMoney(ir.sabou.inventory.core.SignedLongMath.subtract(revision.costProfile.directLaborCostRial, previous.directLaborCostRial))} · سربار ${formatSignedMoney(ir.sabou.inventory.core.SignedLongMath.subtract(revision.costProfile.allocatedOverheadRial, previous.allocatedOverheadRial))}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                            }
                            if (revision.costProfile.note.isNotBlank()) Text(revision.costProfile.note, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item {
                    FormSection("هزینه‌های مستقیم و تخصیصی", "مبلغ هر واحد فروش؛ مستقل از سند مصرف موجودی") {
                        OutlinedTextField(packagingCost, { packagingCost = formatMoneyInput(it); error = null }, label = { Text("بسته‌بندی (${currencyUnitLabel()})") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(directLaborCost, { directLaborCost = formatMoneyInput(it); error = null }, label = { Text("نیروی کار مستقیم (${currencyUnitLabel()})") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(allocatedOverhead, { allocatedOverhead = formatMoneyInput(it); error = null }, label = { Text("سربار تخصیصی (${currencyUnitLabel()})") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(revisionNote, { revisionNote = it.take(500); error = null }, label = { Text("یادداشت این بازنگری") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    }
                }
                item {
                    val estimatedCost = rows.fold(0L) { total, row ->
                        val stock = inventory.firstOrNull { it.id == row.inventoryItemId }
                        val lineCost = if (stock == null || stock.stockMicros <= 0) 0L else safeMulDiv(stock.inventoryValueRial, parseQuantityMicros(row.quantity), stock.stockMicros)
                        ir.sabou.inventory.core.SignedLongMath.add(total, lineCost)
                    }
                    val salePrice = parseMoneyInputOrNull(price) ?: 0L
                    val preview = runCatching { FullCostCalculator.calculate(FullCostCalculator.Input(estimatedCost, parseQuantityMicros(productionYield), parseBasisPoints(preparationWaste), parseBasisPoints(cookingWaste), parseMoneyInputOrNull(packagingCost) ?: 0L, parseMoneyInputOrNull(directLaborCost) ?: 0L, parseMoneyInputOrNull(allocatedOverhead) ?: 0L, salePrice)) }.getOrNull()
                    FormSection("تحلیل بهای کامل", "پیش‌نمایش مدیریتی؛ حاشیه بهای کامل سود خالص حسابداری نیست") {
                        CompactInfoRow("مواد اولیه", formatMoney(estimatedCost))
                        CompactInfoRow("اثر ضایعات", preview?.let { formatMoney(it.wasteImpactRial) } ?: "نامعتبر")
                        CompactInfoRow("بهای مواد پس از ضایعات", preview?.let { formatMoney(it.foodCostRial) } ?: "نامعتبر")
                        CompactInfoRow("بسته‌بندی", preview?.let { formatMoney(it.packagingCostRial) } ?: "—")
                        CompactInfoRow("نیروی مستقیم", preview?.let { formatMoney(it.directLaborCostRial) } ?: "—")
                        CompactInfoRow("سربار تخصیصی", preview?.let { formatMoney(it.allocatedOverheadRial) } ?: "—")
                        CompactInfoRow("بهای کامل", preview?.let { formatMoney(it.fullCostRial) } ?: "نامعتبر", preview?.fullMarginRial?.let { it < 0 } == true)
                        CompactInfoRow("حاشیه پس از هزینه مواد", preview?.let { "${formatMoney(it.foodMarginRial)} · ${formatBasisPoints(it.foodCostBasisPoints)} هزینه" } ?: "—")
                        CompactInfoRow("حاشیه پس از بهای کامل", preview?.let { "${formatMoney(it.fullMarginRial)} · ${formatBasisPoints(it.fullCostBasisPoints)} هزینه" } ?: "—", preview?.fullMarginRial?.let { it < 0 } == true)
                    }
                }
                error?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    val normalizedName = name.trim()
                    val salePrice = parseMoneyInputOrNull(price)
                    val validRows = rows.filter { it.inventoryItemId != null && parseQuantityMicros(it.quantity) > 0L }
                    val yieldMicros = parseQuantityMicros(productionYield)
                    val prepWaste = parseBasisPoints(preparationWaste)
                    val cookWaste = parseBasisPoints(cookingWaste)
                    val parsedPackaging = parseMoneyInputOrNull(packagingCost)
                    val parsedLabor = parseMoneyInputOrNull(directLaborCost)
                    val parsedOverhead = parseMoneyInputOrNull(allocatedOverhead)
                    error = when {
                        salePrice == null -> "قیمت فروش از محدوده مجاز خارج است."
                        normalizedName.length < 2 -> "نام محصول را کامل وارد کنید."
                        salePrice <= 0L -> "قیمت فروش باید بیشتر از صفر باشد."
                        validRows.isEmpty() -> "حداقل یک ماده اولیه و مقدار مصرف معتبر وارد کنید."
                        validRows.mapNotNull { it.inventoryItemId }.distinct().size != validRows.size -> "هر ماده اولیه فقط یک‌بار قابل انتخاب است."
                        yieldMicros <= 0L -> "بازده تولید باید بیشتر از صفر باشد."
                        prepWaste !in 0..FullCostCalculator.MAX_WASTE_BASIS_POINTS || cookWaste !in 0..FullCostCalculator.MAX_WASTE_BASIS_POINTS -> "درصد ضایعات باید بین صفر و کمتر از صد باشد."
                        packagingCost.isNotBlank() && parsedPackaging == null -> "هزینه بسته‌بندی از محدوده مجاز خارج است."
                        directLaborCost.isNotBlank() && parsedLabor == null -> "هزینه نیروی مستقیم از محدوده مجاز خارج است."
                        allocatedOverhead.isNotBlank() && parsedOverhead == null -> "سربار تخصیصی از محدوده مجاز خارج است."
                        else -> null
                    }
                    if (error == null) {
                        onSave(
                            selected?.id,
                            normalizedName,
                            category.trim(),
                            requireNotNull(salePrice),
                            validRows.map { row ->
                                RecipeIngredientInput(
                                    inventoryItemId = requireNotNull(row.inventoryItemId) {
                                        "ماده اولیه انتخاب نشده است."
                                    },
                                    quantityMicrosPerUnit = parseQuantityMicros(row.quantity),
                                )
                            },
                            RecipeCostProfile(
                                yieldMicros = yieldMicros,
                                portionWeightMicros = parseQuantityMicros(portionWeight),
                                preparationWasteBasisPoints = prepWaste,
                                cookingWasteBasisPoints = cookWaste,
                                packagingCostRial = parsedPackaging ?: 0L,
                                directLaborCostRial = parsedLabor ?: 0L,
                                allocatedOverheadRial = parsedOverhead ?: 0L,
                                note = revisionNote,
                            ),
                            onDismiss,
                        )
                    }
                },
            ) { Text(if (busy) "در حال ذخیره…" else "ذخیره") }
        },
        dismissButton = {
            Column(horizontalAlignment = Alignment.End) {
                if (selected != null && currentIngredients.isNotEmpty()) {
                    OutlinedButton(onClick = { printRecipeSheet(context, selected, currentIngredients) }) {
                        Text("چاپ برگه رسپی / PDF")
                    }
                }
                TextButton(enabled = !busy, onClick = onDismiss) { Text("انصراف") }
            }
        },
    )
}

private fun parseBasisPoints(value: String): Int = (parseQuantityMicros(value) / 10_000L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
private fun formatBasisPointsInput(value: Int): String = if (value == 0) "0" else if (value % 100 == 0) (value / 100).toString() else "%d.%02d".format(value / 100, value % 100)
private fun formatBasisPoints(value: Int?): String = value?.let { "%d.%02d٪".format(it / 100, kotlin.math.abs(it % 100)) } ?: "—"
private fun safeMulDiv(left: Long, right: Long, divisor: Long): Long {
    require(left >= 0 && right >= 0 && divisor > 0)
    val result = java.math.BigInteger.valueOf(left).multiply(java.math.BigInteger.valueOf(right)).divide(java.math.BigInteger.valueOf(divisor))
    require(result <= java.math.BigInteger.valueOf(Long.MAX_VALUE)) { "محاسبه هزینه از محدوده امن خارج است." }
    return result.toLong()
}
private fun formatSignedMoney(value: Long): String = (if (value > 0) "+" else "") + formatMoney(value)

@Composable
private fun IngredientEditorCard(
    index: Int,
    row: IngredientDraft,
    inventory: List<InventoryItemRecord>,
    removable: Boolean,
    onSelectItem: (Long) -> Unit,
    onQuantityChange: (String) -> Unit,
    onRemove: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ماده اولیه ${index + 1}", fontWeight = FontWeight.Bold)
                if (removable) TextButton(onClick = onRemove) { Text("حذف") }
            }
            if (inventory.isEmpty()) {
                Text("ابتدا در بخش انبار یک ماده اولیه ثبت کنید.", color = MaterialTheme.colorScheme.error)
            } else {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(inventory, key = { it.id }) { item ->
                        FilterChip(
                            selected = row.inventoryItemId == item.id,
                            onClick = { onSelectItem(item.id) },
                            label = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        )
                    }
                }
            }
            val selectedItem = inventory.firstOrNull { it.id == row.inventoryItemId }
            OutlinedTextField(
                value = row.quantity,
                onValueChange = { value -> onQuantityChange(value.filter { it.isDigit() || it == '.' }) },
                label = { Text("مصرف برای یک واحد${selectedItem?.unit?.let { " ($it)" }.orEmpty()}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

private fun parseQuantityMicros(value: String): Long = try {
    ir.sabou.inventory.core.QuantityMicros.parse(value).value
} catch (_: Exception) {
    0L
}
