package ir.sabou.inventory.data.repository

import ir.sabou.inventory.domain.security.Permission

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.DailySalesMenuLineEntity
import ir.sabou.inventory.data.db.DailySalesSummaryEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.SalesDayClosureEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.data.security.SensitiveActionGate
import ir.sabou.inventory.domain.operations.SensitiveAction
import ir.sabou.inventory.domain.recipe.MenuEngineeringCalculator
import ir.sabou.inventory.domain.recipe.FullCostCalculator
import ir.sabou.inventory.domain.recipe.MenuPerformanceInput
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.accounting.AccountingPostingContext
import ir.sabou.inventory.domain.accounting.BalancedJournalDraft
import ir.sabou.inventory.domain.accounting.JournalLineDraft
import ir.sabou.inventory.domain.sales.DailySalesDraft
import ir.sabou.inventory.domain.sales.DailySalesItem
import ir.sabou.inventory.domain.sales.DailySalesReport
import ir.sabou.inventory.domain.sales.DailySalesRepository
import ir.sabou.inventory.domain.sales.MenuProfitabilityResult
import ir.sabou.inventory.domain.sales.DailySalesProfitabilityLine
import ir.sabou.inventory.domain.sales.DailySalesReversalDraft
import ir.sabou.inventory.domain.sales.SalesDayClosureDraft
import ir.sabou.inventory.domain.sales.SalesDayReopenDraft
import ir.sabou.inventory.domain.sales.SalesDayClosureRecord
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReasonCode
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import java.math.BigInteger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class LocalDailySalesRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val syncRecorder: SyncRecorder? = null,
    private val clock: () -> Long = System::currentTimeMillis,
    private val sensitiveActionGate: SensitiveActionGate = SensitiveActionGate(),
) : DailySalesRepository {
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)
    private val inventoryCommands = LocalInventoryCommandEngine(database, clock = clock)
    private val auditWriter = LocalAuditEventWriter(database)
    override val dayClosures: Flow<List<SalesDayClosureRecord>> = database.dailySalesDao().observeDayClosures().map { rows ->
        rows.map { SalesDayClosureRecord(it.businessEpochDay, it.summaryId, it.grossSalesRial, it.netSalesRial, it.theoreticalCostRial, it.cashRial, it.cardRial, it.transferRial, it.status, it.revisionNo, it.closedBy, it.note, it.reopenedBy, it.reopenReason, it.createdAtEpochMillis) }
    }

    override suspend fun post(draft: DailySalesDraft): Long {
        val actor = authorizer.require(Permission.SALES)
        require(draft.businessEpochDay > 0) { "تاریخ فروش معتبر نیست." }
        require(draft.lines.isNotEmpty()) { "حداقل یک آیتم از منو وارد کنید." }
        require(draft.lines.all { it.menuItemId > 0 && it.quantityMicros > 0 && it.grossSalesRial >= 0 }) { "اطلاعات ردیف‌های فروش ناقص است." }
        require(draft.lines.map { it.menuItemId }.distinct().size == draft.lines.size) { "هر آیتم منو باید فقط یک‌بار در فروش روزانه ثبت شود." }
        require(listOf(draft.discountRial, draft.serviceRial, draft.taxRial, draft.cashRial, draft.cardRial, draft.transferRial).all { it >= 0 }) { "مبالغ نمی‌توانند منفی باشند." }
        val now = clock()
        return database.withTransaction {
            val gross = draft.lines.fold(0L) { total, line -> SignedLongMath.add(total, line.grossSalesRial) }
            require(gross > 0) { "فروش ناخالص باید بیشتر از صفر باشد." }
            require(draft.discountRial <= gross) { "تخفیف نمی‌تواند از فروش ناخالص بیشتر باشد." }
            val productRevenue = SignedLongMath.subtract(gross, draft.discountRial)
            val net = SignedLongMath.add(SignedLongMath.add(productRevenue, draft.serviceRial), draft.taxRial)
            val payments = SignedLongMath.add(SignedLongMath.add(draft.cashRial, draft.cardRial), draft.transferRial)
            require(payments == net) { "جمع روش‌های پرداخت باید دقیقاً با فروش خالص برابر باشد." }

            database.dailySalesDao().activeSummaryByDay(draft.businessEpochDay)?.let { existing ->
                val existingLines = database.dailySalesDao().lines(existing.id).associateBy { it.menuItemId }
                val sameLines = existingLines.size == draft.lines.size && draft.lines.all { line ->
                    existingLines[line.menuItemId]?.let { persisted ->
                        persisted.quantityMicros == line.quantityMicros &&
                            persisted.grossSalesRial == line.grossSalesRial
                    } == true
                }
                val samePayload = existing.grossSalesRial == gross &&
                    existing.discountRial == draft.discountRial &&
                    existing.serviceRial == draft.serviceRial &&
                    existing.taxRial == draft.taxRial &&
                    existing.netSalesRial == net &&
                    existing.cashRial == draft.cashRial &&
                    existing.cardRial == draft.cardRial &&
                    existing.transferRial == draft.transferRial &&
                    existing.notes == draft.notes.trim() &&
                    sameLines
                if (!samePayload) {
                    throw BusinessError.IdempotencyConflict(
                        "DAILY_SALES:${draft.businessEpochDay}",
                    ).asViolation()
                }
                return@withTransaction existing.id
            }
            require(!database.dailySalesDao().dayClosed(draft.businessEpochDay)) { "این روز فروش بسته و امضاشده است و قابل ثبت مجدد نیست." }

            data class Consumption(val item: InventoryItemEntity, val quantity: Long, val cost: Long)
            data class PreparedLine(
                val menuId: Long,
                val recipeVersionId: Long,
                val name: String,
                val quantity: Long,
                val gross: Long,
                val cost: Long,
                val foodCost: Long,
                val packagingCost: Long,
                val directLaborCost: Long,
                val allocatedOverhead: Long,
            )
            val consumptions = mutableListOf<Consumption>()
            val preparedLines = draft.lines.map { line ->
                val menu = database.recipeDao().activeMenuItem(line.menuItemId) ?: error("آیتم منوی انتخاب‌شده فعال نیست.")
                val recipeVersion = database.recipeDao().effectiveVersion(menu.id, draft.businessEpochDay)
                    ?: error("برای «${menu.name}» در تاریخ فروش، نسخه مؤثر رسپی وجود ندارد.")
                val ingredients = database.recipeDao().versionIngredients(recipeVersion.id)
                require(ingredients.isNotEmpty()) { "برای «${menu.name}» رسپی کامل ثبت نشده است." }
                var lineCost = 0L
                ingredients.forEach { ingredient ->
                    val item = database.inventoryDao().activeById(ingredient.inventoryItemId) ?: error("یکی از مواد اولیه «${menu.name}» فعال نیست.")
                    val needed = mulDiv(ingredient.quantityMicrosPerUnit, line.quantityMicros, 1_000_000L)
                    require(needed > 0) { "مصرف محاسبه‌شده برای ${item.name} نامعتبر است." }
                    val cost = if (item.stockMicros == 0L) 0L else mulDiv(item.inventoryValueRial, needed, item.stockMicros)
                    consumptions += Consumption(item, needed, cost)
                    lineCost = SignedLongMath.add(lineCost, cost)
                }
                val packaging = mulDiv(recipeVersion.packagingCostRial, line.quantityMicros, 1_000_000L)
                val labor = mulDiv(recipeVersion.directLaborCostRial, line.quantityMicros, 1_000_000L)
                val overhead = mulDiv(recipeVersion.allocatedOverheadRial, line.quantityMicros, 1_000_000L)
                val fullCost = FullCostCalculator.calculate(
                    FullCostCalculator.Input(
                        rawIngredientCostRial = lineCost,
                        yieldMicros = recipeVersion.yieldMicros,
                        preparationWasteBasisPoints = recipeVersion.preparationWasteBasisPoints,
                        cookingWasteBasisPoints = recipeVersion.cookingWasteBasisPoints,
                        packagingCostRial = packaging,
                        directLaborCostRial = labor,
                        allocatedOverheadRial = overhead,
                        salePriceRial = line.grossSalesRial,
                    ),
                )
                PreparedLine(menu.id, recipeVersion.id, menu.name, line.quantityMicros, line.grossSalesRial, lineCost, fullCost.foodCostRial, packaging, labor, overhead)
            }
            val aggregated = consumptions.groupBy { it.item.id }.map { (_, rows) ->
                val item = rows.first().item
                val quantity = rows.fold(0L) { total, row -> SignedLongMath.add(total, row.quantity) }
                val cost = rows.fold(0L) { total, row -> SignedLongMath.add(total, row.cost) }
                require(item.stockMicros >= quantity) { "موجودی ${item.name} برای فروش ثبت‌شده کافی نیست." }
                Triple(item, quantity, cost)
            }
            val totalCost = preparedLines.fold(0L) { total, line -> SignedLongMath.add(total, line.cost) }
            val summaryId = database.dailySalesDao().insertSummary(
                DailySalesSummaryEntity(
                    businessEpochDay = draft.businessEpochDay,
                    grossSalesRial = gross,
                    discountRial = draft.discountRial,
                    serviceRial = draft.serviceRial,
                    taxRial = draft.taxRial,
                    netSalesRial = net,
                    theoreticalCostRial = totalCost,
                    cashRial = draft.cashRial,
                    cardRial = draft.cardRial,
                    transferRial = draft.transferRial,
                    notes = draft.notes.trim(),
                    journalEntryId = null,
                    costJournalEntryId = null,
                    createdAtEpochMillis = now,
                ),
            )
            database.dailySalesDao().insertLines(preparedLines.map {
                DailySalesMenuLineEntity(
                    summaryId = summaryId,
                    menuItemId = it.menuId,
                    recipeVersionId = it.recipeVersionId,
                    menuItemNameSnapshot = it.name,
                    quantityMicros = it.quantity,
                    grossSalesRial = it.gross,
                    theoreticalCostRial = it.cost,
                    foodCostSnapshotRial = it.foodCost,
                    packagingCostSnapshotRial = it.packagingCost,
                    directLaborCostSnapshotRial = it.directLaborCost,
                    allocatedOverheadSnapshotRial = it.allocatedOverhead,
                )
            })
            aggregated.forEach { (item, quantity, cost) ->
                inventoryCommands.issue(
                    itemId = item.id,
                    quantityMicros = quantity,
                    valueRial = cost,
                    movementType = InventoryMovementType.DAILY_SALES_CONSUMPTION,
                    referenceType = InventoryReferenceType.DAILY_SALES,
                    referenceId = summaryId,
                    movementEpochDay = draft.businessEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.DAILY_SALES,
                        referenceId = summaryId,
                        suffix = "consume:${item.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.SALES_CONSUMPTION,
                        reason = "مصرف رسپی فروش روزانه",
                        correlationId = "daily_sales:$summaryId",
                    ),
                    notes = "مصرف رسپی فروش روزانه",
                    lotPolicy = LocalInventoryCommandEngine.LotIssuePolicy.FEFO_ALL,
                )
            }
            val revenueLines = buildList {
                if (draft.cashRial > 0) add(SemanticJournalLine(SemanticAccountRole.CASH, debit = MoneyRial.of(draft.cashRial)))
                if (draft.cardRial > 0) add(SemanticJournalLine(SemanticAccountRole.BANK, debit = MoneyRial.of(draft.cardRial), memo = "کارتخوان"))
                if (draft.transferRial > 0) add(SemanticJournalLine(SemanticAccountRole.BANK, debit = MoneyRial.of(draft.transferRial), memo = "حواله"))
                if (productRevenue > 0) add(SemanticJournalLine(SemanticAccountRole.SALES_REVENUE, credit = MoneyRial.of(productRevenue)))
                if (draft.serviceRial > 0) add(SemanticJournalLine(SemanticAccountRole.SERVICE_REVENUE, credit = MoneyRial.of(draft.serviceRial)))
                if (draft.taxRial > 0) add(SemanticJournalLine(SemanticAccountRole.TAX_PAYABLE, credit = MoneyRial.of(draft.taxRial)))
            }
            val journalId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "فر-$summaryId",
                    entryEpochDay = draft.businessEpochDay,
                    description = "فروش تجمیعی صندوق",
                    sourceType = "DAILY_SALES",
                    sourceId = summaryId,
                    lines = revenueLines,
                ),
                context = AccountingPostingContext.local(
                    sourceType = "DAILY_SALES",
                    sourceId = summaryId,
                    suffix = "revenue",
                    actorId = actor.id,
                    correlationId = "daily_sales:$summaryId",
                ),
            )
            val costJournalId = if (totalCost > 0) {
                accountingPosting.post(
                    draft = SemanticJournalDraft(
                        entryNo = "بفر-$summaryId",
                        entryEpochDay = draft.businessEpochDay,
                        description = "بهای تمام‌شده فروش تجمیعی",
                        sourceType = "DAILY_SALES_COGS",
                        sourceId = summaryId,
                        lines = listOf(
                            SemanticJournalLine(SemanticAccountRole.COGS, debit = MoneyRial.of(totalCost)),
                            SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, credit = MoneyRial.of(totalCost)),
                        ),
                    ),
                    context = AccountingPostingContext.local(
                        sourceType = "DAILY_SALES_COGS",
                        sourceId = summaryId,
                        suffix = "cogs",
                        actorId = actor.id,
                        correlationId = "daily_sales:$summaryId",
                    ),
                )
            } else null
            check(database.dailySalesDao().linkJournals(summaryId, journalId, costJournalId) == 1)
            syncRecorder?.record("DAILY_SALES", summaryId, "CREATE", now)
            audit("CREATE", summaryId, "ثبت فروش روز ${draft.businessEpochDay}؛ خالص=$net؛ بهای تمام‌شده=$totalCost؛ سند=$journalId", now)
            summaryId
        }
    }

    override suspend fun reverse(draft: DailySalesReversalDraft) {
        val actor = authorizer.require(Permission.SALES)
        database.withTransaction {
            val summary = database.dailySalesDao().summary(draft.summaryId)
                ?: error("فروش روزانه پیدا نشد.")
            val valid = draft.validated(summary.businessEpochDay)
            require(!summary.isLegacyArchive) {
                "فروش آرشیوی نسخه‌های قبل از این مسیر قابل برگشت نیست."
            }
            if (summary.reversedAtEpochDay != null) {
                if (
                    summary.reversedAtEpochDay != valid.reversalEpochDay ||
                    summary.reversalReason != valid.reason
                ) {
                    throw BusinessError.IdempotencyConflict(
                        "DAILY_SALES_REVERSAL:${summary.id}",
                    ).asViolation()
                }
                return@withTransaction
            }
            require(!database.dailySalesDao().dayClosed(summary.businessEpochDay)) { "این روز فروش بسته و امضاشده است و قابل برگشت نیست." }
            val movements = database.stockMovementDao().dailySalesConsumptions(summary.id)
            require(movements.isNotEmpty()) { "گردش موجودی فروش روزانه کامل نیست." }
            val now = clock()

            movements.forEach { movement ->
                require(movement.quantityDeltaMicros < 0 && movement.valueDeltaRial <= 0) {
                    "گردش مصرف فروش روزانه نامعتبر است."
                }
                inventoryCommands.restoreIssuedMovement(
                    movement = movement,
                    reversalMovementType = InventoryMovementType.DAILY_SALES_REVERSAL,
                    reversalEpochDay = valid.reversalEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.DAILY_SALES,
                        referenceId = summary.id,
                        suffix = "reverse:${movement.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.SALES_REVERSAL,
                        reason = valid.reason,
                        correlationId = "daily_sales_reversal:${summary.id}",
                    ),
                    notes = "برگشت فروش روزانه: ${valid.reason}",
                )
            }

            val revenueReversalId = reverseJournal(
                originalEntryId = summary.journalEntryId,
                summaryId = summary.id,
                epochDay = valid.reversalEpochDay,
                reason = valid.reason,
                originalSourceType = "DAILY_SALES",
                sourceType = "DAILY_SALES_REVERSAL",
                entryPrefix = "بفر",
                description = "برگشت فروش تجمیعی صندوق",
                now = now,
                actorId = actor.id,
            ) ?: error("سند درآمد فروش روزانه پیدا نشد.")
            val costReversalId = reverseJournal(
                originalEntryId = summary.costJournalEntryId,
                summaryId = summary.id,
                epochDay = valid.reversalEpochDay,
                reason = valid.reason,
                originalSourceType = "DAILY_SALES_COGS",
                sourceType = "DAILY_SALES_COGS_REVERSAL",
                entryPrefix = "ببفر",
                description = "برگشت بهای تمام‌شده فروش تجمیعی",
                now = now,
                actorId = actor.id,
            )
            check(
                database.dailySalesDao().markReversed(
                    summaryId = summary.id,
                    reversalEpochDay = valid.reversalEpochDay,
                    reason = valid.reason,
                    reversalJournalEntryId = revenueReversalId,
                    reversalCostJournalEntryId = costReversalId,
                ) == 1,
            ) { "وضعیت برگشت فروش روزانه ثبت نشد." }
            syncRecorder?.record("DAILY_SALES", summary.id, "REVERSAL", now)
            audit("REVERSE", summary.id, "برگشت فروش روز ${summary.businessEpochDay}؛ خالص=${summary.netSalesRial}؛ دلیل=${valid.reason}", now)
        }
    }

    override suspend fun closeDay(draft: SalesDayClosureDraft) {
        authorizer.require(Permission.SALES)
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.CLOSE_SALES_DAY)
        val valid = draft.validated()
        database.withTransaction {
            val dao = database.dailySalesDao()
            require(!dao.dayClosed(valid.businessEpochDay)) { "این روز قبلاً بسته شده است." }
            val summary = dao.activeSummaryByDay(valid.businessEpochDay) ?: error("برای این روز فروش فعال ثبت نشده است.")
            require(!summary.isLegacyArchive) { "روزهای آرشیوی باید از گردش کنترل مهاجرت بررسی شوند." }
            val actor = authorizer.actor()
            val now = clock()
            val previousClosure = dao.dayClosure(valid.businessEpochDay)
            val refreshed = SalesDayClosureEntity(
                businessEpochDay = summary.businessEpochDay, summaryId = summary.id,
                grossSalesRial = summary.grossSalesRial, netSalesRial = summary.netSalesRial,
                theoreticalCostRial = summary.theoreticalCostRial,
                cashRial = summary.cashRial, cardRial = summary.cardRial, transferRial = summary.transferRial,
                status = "CLOSED", revisionNo = (previousClosure?.revisionNo ?: 0) + 1,
                closedBy = actor, note = valid.note, createdAtEpochMillis = now,
            )
            if (previousClosure == null) dao.insertDayClosure(refreshed)
            else check(dao.updateDayClosure(refreshed) == 1) { "بستن مجدد روز فروش انجام نشد." }
            audit(
                action = "CLOSE",
                entityId = summary.id,
                description = "بستن روز فروش ${summary.businessEpochDay} به مبلغ ${summary.netSalesRial} ریال",
                now = now,
                entityType = "SALES_DAY",
                businessEpochDay = summary.businessEpochDay,
                reason = valid.note.ifBlank { "تأیید پایان روز فروش" },
                afterSnapshot = "status=CLOSED;netSalesRial=${summary.netSalesRial};revisionNo=${refreshed.revisionNo}",
            )
            syncRecorder?.record("SALES_DAY", summary.id, "CLOSE", now)
        }
    }

    override suspend fun reopenDay(draft: SalesDayReopenDraft) {
        authorizer.requireOwner()
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.REOPEN_SALES_DAY)
        val valid = draft.validated()
        database.withTransaction {
            val dao = database.dailySalesDao()
            val closure = dao.dayClosure(valid.businessEpochDay) ?: error("سند بستن روز فروش پیدا نشد.")
            require(closure.status == "CLOSED") { "این روز در وضعیت بسته نیست." }
            val actor = authorizer.actor()
            val now = clock()
            check(dao.updateDayClosure(closure.copy(status = "REOPENED", reopenedBy = actor, reopenReason = valid.reason, reopenedAtEpochMillis = now)) == 1) {
                "بازگشایی روز فروش انجام نشد."
            }
            audit(
                action = "REOPEN",
                entityId = closure.summaryId,
                description = "بازگشایی کنترل‌شده روز فروش ${closure.businessEpochDay}: ${valid.reason}",
                now = now,
                entityType = "SALES_DAY",
                businessEpochDay = closure.businessEpochDay,
                reason = valid.reason,
                beforeSnapshot = "status=CLOSED;revisionNo=${closure.revisionNo}",
                afterSnapshot = "status=REOPENED;reason=${valid.reason}",
            )
            syncRecorder?.record("SALES_DAY", closure.summaryId, "REOPEN", now)
        }
    }

    override fun observe(query: String): Flow<List<DailySalesItem>> = combine(
        database.dailySalesDao().observeSummaries(query.trim()),
        database.dailySalesDao().observeDayClosures(),
        database.dailySalesDao().observeSummaryProfitability(),
        database.dailySalesDao().observeAllLines(),
    ) { rows, closures, profitabilityRows, lineRows ->
        val byDay = closures.associateBy { it.businessEpochDay }
        val bySummary = profitabilityRows.associateBy { it.summaryId }
        val linesBySummary = lineRows.groupBy { it.summaryId }
        rows.map { row -> row.toDomain(byDay[row.businessEpochDay], bySummary[row.id], linesBySummary[row.id].orEmpty()) }
    }

    override fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<DailySalesReport> = combine(
        database.dailySalesDao().observeRange(fromEpochDay, toEpochDay),
        database.dailySalesDao().observeMenuPerformance(fromEpochDay, toEpochDay),
    ) { summaries, menuRows ->
        val performanceInputs = menuRows.mapNotNull { row ->
            row.menuItemId?.takeIf { id ->
                id > 0 && row.unitsSold > 0 && row.salesRial > 0 && row.costRial >= 0
            }?.let { MenuPerformanceInput(it, row.name, row.unitsSold, row.salesRial, row.costRial) }
        }
        val menuPerformance = if (performanceInputs.isEmpty()) emptyList() else MenuEngineeringCalculator.classify(performanceInputs)
        val profitability = menuRows.mapNotNull { row ->
            val id = row.menuItemId ?: return@mapNotNull null
            val complete = row.totalLineCount > 0 && row.fullCostLineCount == row.totalLineCount
            val fullCost = row.fullCostRial.takeIf { complete }
            MenuProfitabilityResult(
                menuItemId = id,
                name = row.name,
                unitsSold = row.unitsSold,
                salesRial = row.salesRial,
                foodCostRial = row.costRial,
                fullCostRial = fullCost,
                foodMarginRial = SignedLongMath.subtract(row.salesRial, row.costRial),
                fullMarginRial = fullCost?.let { SignedLongMath.subtract(row.salesRial, it) },
                fullCostBasisPoints = fullCost?.takeIf { row.salesRial > 0 }?.let { mulDiv(it, 10_000, row.salesRial).coerceAtMost(Int.MAX_VALUE.toLong()).toInt() },
                hasCompleteFullCost = complete,
            )
        }
        val sales = summaries.fold(0L) { total, summary ->
            val posted = if (summary.businessEpochDay in fromEpochDay..toEpochDay) summary.netSalesRial else 0
            val reversed = if (summary.reversedAtEpochDay?.let { it in fromEpochDay..toEpochDay } == true) summary.netSalesRial else 0
            SignedLongMath.add(total, SignedLongMath.subtract(posted, reversed))
        }
        val cost = summaries.fold(0L) { total, summary ->
            val posted = if (summary.businessEpochDay in fromEpochDay..toEpochDay) summary.theoreticalCostRial else 0
            val reversed = if (summary.reversedAtEpochDay?.let { it in fromEpochDay..toEpochDay } == true) summary.theoreticalCostRial else 0
            SignedLongMath.add(total, SignedLongMath.subtract(posted, reversed))
        }
        val eventDays = buildSet {
            summaries.forEach { summary ->
                if (summary.businessEpochDay in fromEpochDay..toEpochDay) add(summary.businessEpochDay)
                summary.reversedAtEpochDay?.takeIf { it in fromEpochDay..toEpochDay }?.let { add(it) }
            }
        }
        val coveredLines = menuRows.sumOf { it.fullCostLineCount }
        val totalLines = menuRows.sumOf { it.totalLineCount }
        val fullCost = menuRows.fold(0L) { total, row -> SignedLongMath.add(total, row.fullCostRial) }.takeIf { totalLines > 0 && coveredLines == totalLines }
        DailySalesReport(
            fromEpochDay,
            toEpochDay,
            eventDays.size,
            sales,
            cost,
            SignedLongMath.subtract(sales, cost),
            menuPerformance,
            fullCost,
            fullCost?.let { SignedLongMath.subtract(sales, it) },
            coveredLines,
            totalLines,
            profitability,
        )
    }

    private suspend fun reverseJournal(
        originalEntryId: Long?,
        summaryId: Long,
        epochDay: Long,
        reason: String,
        originalSourceType: String,
        sourceType: String,
        entryPrefix: String,
        description: String,
        now: Long,
        actorId: Long,
    ): Long? {
        if (originalEntryId == null) return null
        val original = database.accountingDao().entryById(originalEntryId)
            ?: error("سند حسابداری مبدأ پیدا نشد.")
        require(original.status == "POSTED") { "سند حسابداری مبدأ ثبت‌شده نیست." }
        require(original.sourceType == originalSourceType && original.sourceId == summaryId) {
            "سند حسابداری مبدأ با فروش روزانه تطابق ندارد."
        }
        val lines = database.accountingDao().linesByEntry(original.id)
        require(lines.size >= 2) { "آرتیکل‌های سند حسابداری مبدأ کامل نیستند." }
        val posted = accountingPosting.postBalanced(
            draft = BalancedJournalDraft(
                entryEpochDay = epochDay,
                description = "$description: $reason",
                sourceType = sourceType,
                sourceId = summaryId,
                lines = lines.map { line ->
                    JournalLineDraft(
                        accountCode = line.accountCode,
                        debit = MoneyRial.of(line.creditRial),
                        credit = MoneyRial.of(line.debitRial),
                        memo = reason,
                    )
                },
            ),
            context = AccountingPostingContext.local(
                sourceType = sourceType,
                sourceId = summaryId,
                suffix = "reverse:${original.id}",
                actorId = actorId,
                correlationId = "daily_sales_reversal:$summaryId",
                reversalOfEntryId = original.id,
            ),
            entryNoFactory = { id -> "$entryPrefix-$id" },
        )
        return posted.entryId
    }

    private fun DailySalesSummaryEntity.toDomain(
        closure: SalesDayClosureEntity? = null,
        profitability: ir.sabou.inventory.data.db.DailySalesProfitabilityRow? = null,
        lines: List<DailySalesMenuLineEntity> = emptyList(),
    ): DailySalesItem {
        val completeFullCost = profitability
            ?.takeIf { it.totalLineCount > 0 && it.coveredLineCount == it.totalLineCount }
            ?.fullCostRial
        return DailySalesItem(
            id = id,
            businessEpochDay = businessEpochDay,
            grossSalesRial = grossSalesRial,
            discountRial = discountRial,
            serviceRial = serviceRial,
            taxRial = taxRial,
            netSalesRial = netSalesRial,
            theoreticalCostRial = theoreticalCostRial,
            fullCostRial = completeFullCost,
            fullMarginRial = completeFullCost?.let { SignedLongMath.subtract(netSalesRial, it) },
            fullCostCoverageLineCount = profitability?.coveredLineCount ?: 0,
            totalLineCount = profitability?.totalLineCount ?: 0,
            profitabilityLines = lines.map { line ->
                DailySalesProfitabilityLine(
                    line.menuItemId,
                    line.recipeVersionId,
                    line.menuItemNameSnapshot,
                    line.quantityMicros,
                    line.grossSalesRial,
                    line.theoreticalCostRial,
                    line.foodCostSnapshotRial,
                    line.packagingCostSnapshotRial,
                    line.directLaborCostSnapshotRial,
                    line.allocatedOverheadSnapshotRial,
                )
            },
            cashRial = cashRial,
            cardRial = cardRial,
            transferRial = transferRial,
            notes = notes,
            isLegacyArchive = isLegacyArchive,
            reversedAtEpochDay = reversedAtEpochDay,
            reversalReason = reversalReason,
            isClosed = closure?.status == "CLOSED",
            closedBy = closure?.closedBy,
            closeNote = closure?.note.orEmpty(),
            closureStatus = closure?.status,
            closureRevisionNo = closure?.revisionNo ?: 0,
            reopenedBy = closure?.reopenedBy,
            reopenReason = closure?.reopenReason.orEmpty(),
        )
    }

    private suspend fun audit(
        action: String,
        entityId: Long,
        description: String,
        now: Long,
        entityType: String = "DAILY_SALES",
        businessEpochDay: Long? = null,
        reason: String = description,
        beforeSnapshot: String? = null,
        afterSnapshot: String? = null,
    ) {
        auditWriter.appendAuthorized(
            authorizer = authorizer,
            action = action,
            entityType = entityType,
            entityId = entityId,
            description = description,
            occurredAtEpochMillis = now,
            businessEpochDay = businessEpochDay,
            reason = reason,
            beforeSnapshot = beforeSnapshot,
            afterSnapshot = afterSnapshot,
            correlationId = "sales:$entityId:$action:$now",
        )
    }

    private fun mulDiv(a: Long, b: Long, divisor: Long): Long = BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(divisor)).longValueExact()
}
