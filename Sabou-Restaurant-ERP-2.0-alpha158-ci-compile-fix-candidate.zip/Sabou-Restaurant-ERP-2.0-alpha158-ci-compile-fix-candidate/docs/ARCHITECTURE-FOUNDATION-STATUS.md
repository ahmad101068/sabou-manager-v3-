# Sabou Restaurant ERP 2.0 — Architecture Foundation Status

Baseline: Alpha157 (`59ba238`)  
Candidate: Alpha158 Foundation Hardening  
Scope: TASK 01-B; no Inventory 2.0 feature or UX redesign

## Baseline verified

- `Daos.kt` was already removed in Alpha157. Seventeen `AppDatabase` accessors still resolve to one
  owner-oriented DAO declaration each. No DAO query or public DAO signature was rewritten in this task.
- Room schema remains version 42. No entity, column, foreign key, index, trigger, or stored value changed.
- SQLCipher, Keystore-backed key handling, session checks, PIN re-authentication, and
  `SensitiveActionGate` remain wired.
- Existing data-boundary and impact-map documents were preserved.

## God-object audit and result

| Area | Baseline LOC | Current LOC | Responsibilities / dependencies | Why it was large | Result / next boundary |
|---|---:|---:|---|---|---|
| `AppDatabase.kt` | 1,786 | 171 | Room entity/DAO registry, SQLCipher builder, migrations, callbacks | 41 migration implementations and lifecycle SQL lived beside wiring | DONE: migration registry plus legacy, operations, enterprise, integrity, and seed files |
| `LocalProcurementRepository.kt` | 1,259 (1,282 after receipt hardening) | 820 | Requisition, approval, order, sourcing, replenishment, receiving, return, match, scorecard; Room/auth/accounting/sync | Seven workflows shared one implementation | Receiving/return and three-way matching extracted; facade contract retained |
| `OperationsScreens.kt` | 1,342 | 399 | Supplier, inventory, stock ledger, audit, purchase entry and shared controls | Independent workflows and dialogs shared one file | Supplier, inventory and purchase screens extracted; shared/audit UI remains |
| `SabouApp.kt` | 1,121 | 337 | ViewModel construction, session guard, back stack, route dispatch, dashboard | Composition root, dashboard and all screen construction were co-located | Dashboard extracted; routes split into six owner groups; composition root retained |
| `AccountingScreens.kt` | 905 | 528 | Overview, journals, accounts, reports, ledger, manual entry, reversal | Multiple accounting workflows shared private helpers | Manual entry and report/ledger screens extracted |
| Management Control screen + VM | 483 | 484 | Procurement exceptions, lots, budget/KPI, workforce control, accounting period, cash reconciliation | Historical catch-all ownership | Ownership map completed; physical move deferred to domain tasks to avoid UX/schema churn |
| `AppContainer` | 272 | 287 | Encrypted DB, repositories, security, backup, boundary wiring | Application composition root | Acceptable composition-root role; exposes typed accounting/auth/audit/treasury contracts |
| Repository implementations | 5,599 | 7,283 | Local persistence and workflow boundaries | Large local-first domain surface | Added explicit services; remaining largest facade is 820 LOC, with stable public compatibility |

LOC growth across split files is primarily explicit imports, formatting, contracts and tests; the measured
criterion is ownership and dependency direction, not aggregate line reduction.

## Impact map

| Change | Files / contracts affected | Schema / migration | Regression surface | Safeguard |
|---|---|---|---|---|
| Migration extraction | `AppDatabase`, `data/db/migration/*`, `ALL_MIGRATIONS` | None; SQL preserved | Every supported upgrade edge | SQL-body parity, ordered registry test, full-chain test retained |
| Accounting boundary | `AccountingPosting.kt`, engine, DAO reversal lookup, container | None | Purchase, sales, payroll, assets, inventory controls, manual journals | balance/period/account/idempotency checks and audit run in Room transaction |
| Treasury foundation | Treasury models and legacy adapters/catalog | None | Payment method reads and workforce payment flows | typed mapping; unknown stored values are explicit failures |
| Authorization and audit | service contracts, session authorizer, audit writer, container | None | Sensitive commands and audit append | repository/application checks retained; audit exception propagates and rolls back |
| Correlation/failure foundation | core value object, command contexts, UI error mapper | None | All critical command errors | structured facts in domain; Persian messages only in presentation |
| Receipt idempotency | procurement DAO, receiving service, tests | None | PO status, stock, journal, audit | natural-key payload equivalence and conflict; integration rollback test |
| Typed states wave 1 | purchase/personnel/control/inventory read models and UI | None; String persistence retained | Legacy payment and movement display | explicit adapters and `LEGACY_UNKNOWN`; no silent payable/cash fallback |
| Procurement split | facade plus receiving and matching services | None | Procurement ViewModels and management-control consumer | original `ProcurementRepository` contract unchanged |
| Presentation/navigation split | operations/accounting screens, route groups, dashboard | None | all navigation and callback wiring | behavior copied without UX redesign; route ownership enum is single dispatch map |
| Verification | `scripts/verify-foundation.sh`, tests, reports | None | CI and future refactors | schema version read from source; complete migration edge check; architecture guards |

## Completion matrix

| Foundation item | Status | Evidence / limitation |
|---|---|---|
| DAO decomposition | DONE | Alpha157 split preserved; dynamic declaration/accessor parity check |
| AppDatabase decomposition | DONE | 171-line wiring file and ordered `ALL_MIGRATIONS` registry |
| Accounting boundary | DONE | `AccountingPostingService`; one local engine; append-only audited posting/reversal |
| Treasury boundary | PARTIAL | typed concepts, catalog and service contract exist; dedicated treasury ledger/implementation deferred |
| Authorization boundary | DONE | `AuthorizationService`; `SessionAuthorizer` enforces permission at command boundary |
| Audit boundary | DONE | `AuditService`; append-only writer; receipt/journal/period/payroll critical paths audited |
| Domain failures | PARTIAL | typed foundation and UI mapping complete; legacy `require/error` sites remain for incremental conversion |
| Typed states wave 1 | DONE | payment/channel, stock movement/reference and selected document control states typed |
| Transaction integrity | DONE | matrix complete; receipt P0 replay/rollback defect fixed; no partial-posting path found |
| Idempotency | PARTIAL | journal, receipt, settlement, sales, inventory count/waste and payroll covered; purchase return remains command-ID debt |
| Procurement decomposition | DONE | receiving/return and matching services; compatibility facade retained |
| Operations screen decomposition | DONE | supplier, inventory, purchase and shared/audit ownership files |
| Accounting screen decomposition | DONE | main, report/ledger and manual-entry ownership files |
| Navigation decomposition | DONE | six route groups; `SabouApp` is composition/session root |
| ManagementControl ownership | PARTIAL | target ownership documented; cross-domain physical moves deferred |
| Architecture verification | DONE | maintainable static script plus registry/parser/diff checks |
| Migration verification | PARTIAL | source parity/registry checks pass; Android migration tests not executable here |
| Build verification | BLOCKED | Gradle distribution/Android toolchain unavailable in the execution environment |

## Stop-condition assessment

No change requiring accounting corruption, inventory corruption, migration data loss, or security
regression was accepted. No destructive migration, schema shortcut, direct ledger deletion, permission
bypass, `GlobalScope`, floating-point money, or negative-stock bypass was introduced.

