# Sabou ERP 2.0 — Foundation Verification Report

Candidate: `3.0.0-alpha158.0-foundation-hardening`  
Room schema: 42 (unchanged)  
Date: 2026-08-09

## Verification levels

| Check | Status | Evidence / command |
|---|---|---|
| Baseline Git and DAO split | PASS | Alpha157 commit history inspected; `Daos.kt` absent; dynamic DAO/accessor parity |
| Migration source parity | PASS | 41 old/new migration bodies compared before extraction: `MISMATCH=0` |
| Migration registry chain | PASS (static) | complete unique edges 1→42 derived from the schema constant |
| Destructive migration guard | PASS | no `fallbackToDestructiveMigration` or ledger delete SQL |
| Architecture policy script | PASS | `bash scripts/verify-foundation.sh` |
| Kotlin syntax parse | PASS for task scope | tree-sitter parsed all 71 Kotlin files changed since Alpha157 with zero syntax errors |
| Whitespace/diff validation | PASS | `git diff --check` |
| Gradle task discovery / unit tests | NOT EXECUTED | wrapper attempted `https://services.gradle.org/distributions/gradle-8.13-bin.zip`; network was unreachable |
| KSP / Room schema processing | NOT EXECUTED | requires Gradle and Android SDK |
| Android migration/integration tests | NOT EXECUTED | requires Android test runtime/emulator |
| Lint | NOT EXECUTED | requires Android Gradle toolchain |
| `assembleDebug` / release build | NOT EXECUTED | requires Android Gradle toolchain |

Static verification is not presented as a build or test pass.

## Architecture checks enforced

- no `Double`/`Float` in core/domain fixed-point models;
- no direct DAO call, journal DAO mutation, or posting call from UI;
- no destructive Room migration fallback;
- no `GlobalScope`;
- inventory projection CAS only in `LocalInventoryCommandEngine` and its DAO declaration;
- posted journals, stock movements and audit history have no direct deletion path;
- direct draft-to-post transition is owned only by the accounting engine;
- direct `AuditLogEntity` construction is restricted to entity declaration and audit writer;
- no domain-to-presentation dependency;
- migration edge count, uniqueness and adjacency match `APP_DATABASE_SCHEMA_VERSION`;
- Room schema, version name/code, SQLCipher factory, manifest backup and cleartext policy are present;
- DAO declaration/accessor parity is discovered dynamically rather than hard-coded to Alpha157 counts.

## Tests added or strengthened

| Test | Layer | Business assertion |
|---|---|---|
| `AccountingPostingBoundaryTest` | Unit | source normalization, balanced fixed-point command and reversal reason |
| `AuthorizationBoundaryTest` | Unit | permission enforcement and actor identity |
| `DomainFailureMappingTest` | Unit | structured failures map to actionable Persian presentation text |
| `TypedStateMappingTest` | Unit | known mapping and explicit unknown handling for channels, movement and document states |
| `MigrationRegistryTest` | Unit | exactly one ordered migration edge for every version 1→current |
| `GoodsReceiptIdempotencyTest` | Unit | exact replay, payload conflict and finalization equivalence |
| `AccountingPostingIntegrationTest` updates | Room integration | posting/reversal audit, replay and audit-failure rollback |
| `GoodsReceiptTransactionIntegrationTest` | Room integration | facade compatibility, no duplicate effects, period-failure full rollback |

Existing full-chain migration tests and critical inventory/management transaction tests were retained;
none were deleted or weakened.

## Commands required in CI before merge

```bash
bash scripts/verify-foundation.sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
./gradlew --no-daemon assembleRelease
```

The repository workflow runs instrumentation on API 23 and API 35, then uploads the debug APK and
Room schemas. A merge or Inventory 2.0 branch must not treat this document as a substitute for those
results.

## Release gate

Current local gate: **BLOCKED — Gradle/Android tests not executed**.

Required evidence to clear the gate:

1. unit and lint tasks pass;
2. KSP/Room schema validation passes;
3. full migration chain and latest 41→42 data-preservation tests pass on emulator;
4. goods-receipt replay/rollback and accounting posting integration tests pass;
5. debug and release assembly complete without source or resource errors.
