# Sabou ERP 2.0 — Domain Boundaries

## Ownership map

| Domain | Owns | Source of truth / command boundary | Must not be bypassed |
|---|---|---|---|
| Core | fixed-point money/quantity, global and correlation identity | `MoneyRial`, `QuantityMicros`, `FixedPointRatio`, `GlobalId`, `CorrelationId` | `Double`/`Float`, ad-hoc random correlation strings |
| Inventory | stock movement ledger, projection CAS, count/waste/transfer rules | `LocalInventoryCommandEngine`; `stock_movements` is history, item totals are projection | direct stock projection writes, negative issue, mutable movement ledger |
| Procurement | requisition, approval, order, receiving/return, matching, sourcing | `ProcurementRepository` facade; `ProcurementReceivingService`; `ProcurementInvoiceMatchingService` | direct inventory/journal mutation; self-approval above policy |
| Sales | daily POS summary, recipe consumption, reversal and day closure | `DailySalesRepository` transaction | duplicate day effects, direct inventory decrement, journal mutation |
| Recipe / Production | recipes, versions and cost calculation | recipe repository/calculators | UI-side costing or quantity arithmetic |
| Accounting | chart, balanced posting, reversal, period checks | `AccountingPostingService`; `LocalAccountingPostingEngine` | balance manipulation, posted journal update/delete, domain-owned account codes |
| Treasury | accounts/channels, receipt/payment/transfer/settlement/reconciliation concepts | `TreasuryService` contract and `TreasuryAccountCatalog`; legacy adapter during transition | treating cash/bank fields as a second authoritative balance ledger |
| Workforce / Payroll | employee, attendance, advance, payroll lifecycle and SoD | personnel repository + payroll calculator + accounting boundary | creator approving own payroll; String payment channel in domain |
| Assets | asset recognition, depreciation, disposal | asset repository + accounting boundary | floating-point depreciation or direct accumulated balance update |
| Security | session identity, role/permission, sensitive re-auth | `AuthorizationService`, `SessionAuthorizer`, `SensitiveActionGate` | UI-only permission enforcement |
| Audit | append-only business event trail | `AuditService`, `LocalAuditEventWriter`, DB guards | silent audit failure or direct audit mutation |
| Sync | deterministic outbox payload/revision | `SyncRecorder` | LWW for inventory/accounting/payment |
| Analytics / Planning | derived KPI, budget and decision support | read models; no operational source of truth | writing inventory/account balances from dashboards |

## Cross-domain foundation contracts

### Accounting posting

`AccountingPostingService.post` and `reverse` receive typed commands with source, source ID, business
date, semantic lines, idempotency key, correlation ID and actor ID. The local engine guarantees:

- fixed-point debit and credit equality with overflow-safe aggregation;
- open accounting period and valid active accounts;
- one posting per idempotency key with exact-payload replay validation;
- draft + lines + posted transition in one Room transaction;
- append-only reversal linked through `reversalOfEntryId`;
- automatic audit in the same transaction.

No duplicate accounting engine was introduced. Existing repository calls continue through
`LocalAccountingPostingEngine`, which implements the new contract.

### Accounting posting-path audit

| Source domain | Trigger | Current path | Atomic | Idempotent | Period checked | Audit | Residual risk |
|---|---|---|---|---|---|---|---|
| Purchase | invoice post/reversal | purchase repo → posting engine | Yes | Posting yes; document create duplicate-safe only | Yes | Journal + document | initial invoice has no command replay result |
| Procurement | goods receipt / return / match | workflow service → `AccountingPostingService` | Yes | receipt and journal yes; return document no | Yes | receipt/journal; return via sync audit | return command ID absent |
| Sales | daily post/reversal | sales repo → posting engine | Yes | Yes | Yes | Yes | none P0 found |
| Inventory control | count/waste | operations repo → engine | Yes | Yes | Yes | Yes | period close/reopen is status-based, not command-keyed |
| Workforce | advance/payroll/approval/reversal | personnel repo → engine | Yes | payroll command and journal yes | Yes | Yes | some legacy failures still untyped |
| Assets | recognize/depreciate/dispose | asset repo → engine | Yes | uniqueness + journal key | Yes | via outbox/journal | dedicated command ID not uniform |
| Accounting | manual post/reversal | accounting repo → engine | Yes | journal key | Yes | automatic journal audit | manual draft error sites still use validation exceptions |

### Treasury

The foundation models `TreasuryAccount` kinds (`CASH`, `BANK`, `CARD_TERMINAL`, `PETTY_CASH`), typed
channel/direction/transaction kind, and commands for receipt, payment, internal transfer, settlement
and reconciliation. Alpha158 intentionally does not add a second treasury table or migrate all flows.
Existing cash/bank concepts are exposed through an explicit compatibility catalog. A persistent
treasury ledger and `TreasuryService` implementation remain a later treasury increment.

Financial channel audit:

| Current owner | Stored values | Domain state after wave 1 | Transition path |
|---|---|---|---|
| Purchase invoice | null, `نقدی`, `کارتخوان`, `حواله` | `PurchasePaymentMethod` | persistence adapter in purchase/operations repositories |
| Supplier settlement | `نقدی`, `کارتخوان`, `حواله` | `SettlementPaymentMethod` | explicit `fromStoredValue`; unknown is typed failure |
| Payroll / advance | `CASH`, `BANK` | `TreasuryChannel` | `LegacyTreasuryChannelAdapter` |
| Daily sales | cash/card/transfer amount columns | no payment-method string | future treasury adapter; current accounting post remains source of financial effect |
| Cash reconciliation | expected/actual channel columns | typed reconciliation status | management-control adapter; future treasury owner |

### Authorization

`AuthorizationService.can`, `require`, and `actorIdentity` separate command authorization from Compose.
Inventory adjustment/count, purchase commands, supplier payment, journal post/reversal, period
close/reopen, payroll approval, user management, backup/restore and export retain repository or
application-command enforcement. UI guards are convenience only. PIN re-authentication remains an
additional gate for designated sensitive actions.

### Audit and correlation

`AuditService.record` accepts an `AuditEventDraft` containing entity/action, actor, occurrence and
business timestamps, device, reference, reason, before/after snapshots and `CorrelationId`.
`LocalAuditEventWriter` never swallows persistence failures. Database triggers protect audit rows.
Snapshot coverage is strongest for new journal, receipt, payroll and period flows; converting every
legacy event from textual description to structured diff remains incremental debt.

### Domain failures

`DomainFailure` separates business results from technical exceptions. Structured failures cover
stock, closed periods, duplicates, invalid journals/money/quantity, permission, approval, state
transition, inactive supplier, concurrency and unknown persisted values. `BusinessRuleViolation`
exists only as the Room rollback adapter. Persian wording lives in `UiErrorHandler`, not failures.

## Management Control ownership transition

| Existing control | Target owner | Alpha158 action |
|---|---|---|
| Lot, location, FEFO, stock transfer | Inventory | route/document ownership recorded; physical DB/UI move deferred to Inventory 2.0 |
| PO exceptions and supplier follow-up | Procurement | procurement route/service owner established |
| Shift, availability, break and labor compliance | Workforce | target boundary documented; repository split deferred |
| Cash reconciliation | Treasury | typed status and treasury command concept created; ledger migration deferred |
| Accounting period management | Accounting | accounting authorization/posting guards retained; UI location deferred |
| Budget and KPI trace | Analytics / Planning | remain derived controls, never operational balance source |

Management Control should evolve into an exception-and-decision center that links to owner-domain
workflows. It must not become the write owner for these records.

