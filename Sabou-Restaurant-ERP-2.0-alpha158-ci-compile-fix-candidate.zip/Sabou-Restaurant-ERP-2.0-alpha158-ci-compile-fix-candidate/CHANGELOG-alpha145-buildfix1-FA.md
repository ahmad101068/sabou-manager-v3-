# اصلاح ساخت alpha145-buildfix1

- import تکراری `androidx.room.ColumnInfo` از `DailySalesEntities.kt` حذف شد.
- خطای `Conflicting import: imported name 'ColumnInfo' is ambiguous` برطرف شد.
- کنترل ساختاری برای جلوگیری از بازگشت همین خطا اضافه شد.
- `versionCode` به ۱۸۲ افزایش یافت؛ نسخه دیتابیس همچنان ۳۶ است.
