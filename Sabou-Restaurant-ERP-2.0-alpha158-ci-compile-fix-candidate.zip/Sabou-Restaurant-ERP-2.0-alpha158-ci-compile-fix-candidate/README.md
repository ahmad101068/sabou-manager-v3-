# Sabou Restaurant ERP 2.0

نسخه توسعه‌ای یک ERP محلی و فارسی برای عملیات رستوران، مبتنی بر Kotlin، Jetpack Compose،
Room، SQLCipher و WorkManager.

نسخه این بسته: `3.0.0-alpha158.0-foundation-hardening`

Schema پایگاه داده: `42`

> این نسخه یک Increment سخت‌سازی معماری و مسیرهای بحرانی است؛ هنوز مجوز استفاده به‌عنوان
> تنها مرجع مالی یا موجودی Production را ندارد. Merge و انتشار فقط پس از سبزشدن کامل CI،
> Migration روی یک کپی واقعی و آزمون دستگاه مجاز است.

## مهم‌ترین تغییر این Increment

- تفکیک DAOهای Alpha157 بدون تغییر قرارداد حفظ شد؛ Schema همچنان `42` است.
- Migrationهای ۱ تا ۴۲ از `AppDatabase` خارج و در Registry ترتیبی متمرکز شدند.
- Boundaryهای Accounting، Treasury، Authorization و Audit و مدل پایه Domain Failure تثبیت شدند.
- Payment channel، Stock Movement/Reference و وضعیت‌های کنترل منتخب در Domain type-safe شدند.
- Goods Receipt با کلید طبیعی و تطبیق payload، replay-safe و transactionally audited شد.
- Receiving/Return و Three-way Matching از facade بزرگ Procurement استخراج شدند.
- Screenهای Operations/Accounting و Navigation به ownershipهای feature-oriented تفکیک شدند.
- Accounting Posting Boundary تراکنشی و idempotent با چرخه `DRAFT → POSTED`
- غیرقابل‌ویرایش و غیرقابل‌حذف شدن Journal قطعی در سطح SQLite
- Stock Movement Ledger append-only با actor، location، unit cost، reference و correlation
- فرمان‌های idempotent دریافت/خروج/شمارش/ضایعات/انتقال/برگشت موجودی
- عملیات اتمیک ضایعات: سند عملیاتی + Lot + Projection + Ledger + Journal + Audit
- Audit envelope ساخت‌یافته و append-only؛ شکست Audit باعث Rollback عملیات می‌شود
- Permissionهای type-safe، نقش Legacy به‌صورت fail-closed و کنترل مجوز در Repository
- Separation of Duties برای تأیید خرید و حقوق
- Primitiveهای امن `GlobalId` و نسبت fixed-point بدون ضرب خام مستعد overflow
- Migration ترتیبی `41 → 42` و Full Migration Test پویا از `1 → current`
- پیام‌های فارسی متمرکز برای خطاهای Business و PIN مجدد برای اصلاح موجودی

## ساخت و کنترل کیفیت

پیش‌نیازها: JDK 17، Android SDK 36 و دسترسی Gradle Wrapper به Gradle 8.13.

```bash
bash scripts/verify-foundation.sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
./gradlew --no-daemon assembleRelease
```

Workflow گیت‌هاب همین مراحل را روی API 23 و API 35 اجرا می‌کند. محیط تولید این بسته به
Android SDK و Gradle distribution دسترسی نداشت؛ بنابراین نتیجه Build/Test Gradle عمداً
ادعا نشده و CI مرجع نهایی است.

## مستندات ERP 2.0

- [ممیزی و Impact Map](docs/ERP2-AUDIT-IMPACT-MAP-FA.md)
- [معماری هدف](docs/ERP2-TARGET-ARCHITECTURE-FA.md)
- [مشخصات Migration 41→42](docs/ERP2-MIGRATION-41-42-FA.md)
- [گزارش فنی فازهای A تا K](docs/ERP2-TECHNICAL-REPORT-FA.md)
- [Impact Map تفکیک Data Boundary](docs/ERP2-ALPHA157-DATA-BOUNDARY-IMPACT-MAP-FA.md)
- [گزارش Alpha157 Data Boundary](docs/ERP2-ALPHA157-DATA-BOUNDARY-REPORT-FA.md)
- [Changelog Alpha157](CHANGELOG-alpha157-FA.md)
- [وضعیت Foundation Alpha158](docs/ARCHITECTURE-FOUNDATION-STATUS.md)
- [مرزهای دامنه](docs/DOMAIN-BOUNDARIES.md)
- [ماتریس یکپارچگی تراکنش](docs/TRANSACTION-INTEGRITY-MATRIX.md)
- [فهرست Typed Stateها](docs/TYPED-STATE-INVENTORY.md)
- [گزارش Verification Foundation](docs/FOUNDATION-VERIFICATION-REPORT.md)
- [Changelog Alpha158](CHANGELOG-alpha158-FA.md)
- [Roadmap باقی‌مانده](docs/ERP2-REMAINING-ROADMAP-FA.md)
- [وضعیت جاری](STATUS-FA.md)

## مرز ادعا

فروش تجمیعی روزانه، خرید، انبار، رسپی، حسابداری، پرسنل/حقوق، دارایی، امنیت و پشتیبان در
سورس موجودند. POS سفارش‌محور کامل، KDS، Production/WIP، Treasury عملیاتی مستقل، Sync
دوطرفه و حل تعارض چندشعبه‌ای هنوز Done نیستند و وجود مدل یا Screen جای پیاده‌سازی واقعی را
نمی‌گیرد. Sync تا تکمیل protocol همچنان fail-closed باقی می‌ماند.
