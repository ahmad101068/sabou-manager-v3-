package ir.sabou.inventory.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord

enum class AppScreen {
    DASHBOARD,
    PURCHASES,
    NEW_PURCHASE,
    SUPPLIERS,
    INVENTORY,
    SALES,
    RECIPES,
    ACCOUNTING,
    NEW_JOURNAL,
    AUDIT_LOG,
    SECURITY,
    PERSONNEL,
    ASSETS,
    CRM,
    ALERTS,
    REPORTS,
    GLOBAL_SEARCH,
    SETTINGS,
}

private data class ModuleCard(val title: String, val screen: AppScreen?, val permission: String? = null)

private val modules = listOf(
    ModuleCard("خرید و فاکتورها", AppScreen.PURCHASES, "PURCHASES"),
    ModuleCard("تأمین‌کنندگان", AppScreen.SUPPLIERS, "SUPPLIERS"),
    ModuleCard("انبار و هشدار موجودی", AppScreen.INVENTORY, "INVENTORY"),
    ModuleCard("رسپی و بهای تمام‌شده", AppScreen.RECIPES, "RECIPES"),
    ModuleCard("فروش و مشتریان", AppScreen.SALES, "SALES"),
    ModuleCard("باشگاه مشتریان و CRM", AppScreen.CRM, "SALES"),
    ModuleCard("مرکز هشدارها", AppScreen.ALERTS, null),
    ModuleCard("حسابداری", AppScreen.ACCOUNTING, "ACCOUNTING"),
    ModuleCard("پرسنل و حقوق", AppScreen.PERSONNEL, "PERSONNEL"),
    ModuleCard("دارایی‌های رستوران", AppScreen.ASSETS, "ASSETS"),
    ModuleCard("گزارش و چاپ", AppScreen.REPORTS, "ACCOUNTING"),
    ModuleCard("لاگ عملیات و حسابرسی", AppScreen.AUDIT_LOG, "AUDIT"),
    ModuleCard("کاربران و پشتیبان", AppScreen.SECURITY, "BACKUP"),
)

@Composable
fun SabouApp(
    container: AppContainer,
    themePreference: ThemePreference,
    onThemePreferenceChange: (ThemePreference) -> Unit,
) {
    val dashboard: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(container.dashboardRepository),
    )
    val operations: OperationsViewModel = viewModel(
        factory = OperationsViewModel.factory(
            container.operationsRepository,
            container.purchaseRepository,
        ),
    )
    val accounting: AccountingViewModel = viewModel(
        factory = AccountingViewModel.factory(container.accountingRepository),
    )
    val sales: SalesViewModel = viewModel(
        factory = SalesViewModel.factory(container.salesRepository, container.recipeRepository),
    )
    val recipes: RecipeViewModel = viewModel(
        factory = RecipeViewModel.factory(container.recipeRepository, container.operationsRepository),
    )
    val personnel: PersonnelViewModel = viewModel(factory = PersonnelViewModel.factory(container.personnelRepository))
    val assets: AssetViewModel = viewModel(factory = AssetViewModel.factory(container.assetRepository))
    val crm: CrmViewModel = viewModel(factory = CrmViewModel.factory(container.crmRepository))
    val alerts: AlertViewModel = viewModel(factory = AlertViewModel.factory(container.alertRepository))
    val security: SecurityViewModel = viewModel(
        factory = SecurityViewModel.factory(container.securityRepository, container),
    )
    val dashboardState by dashboard.state.collectAsState()
    val operationsState by operations.state.collectAsState()
    val accountingState by accounting.state.collectAsState()
    val salesState by sales.state.collectAsState()
    val recipeState by recipes.state.collectAsState()
    val alertState by alerts.state.collectAsState()
    val securityState by security.state.collectAsState()
    val personnelState by personnel.state.collectAsState()
    val assetState by assets.state.collectAsState()
    val crmState by crm.state.collectAsState()
    var screen by remember { mutableStateOf(AppScreen.DASHBOARD) }

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        when (screen) {
            AppScreen.DASHBOARD -> DashboardScreen(
                state = dashboardState,
                operationsState = operationsState,
                currentUser = securityState.currentUser,
                onSearch = { screen = AppScreen.GLOBAL_SEARCH },
                onSettings = { screen = AppScreen.SETTINGS },
                onOpen = { target ->
                    if (target != null) screen = target
                    else operations.clearMessage()
                },
            )

            AppScreen.PURCHASES -> PurchasesScreen(
                state = operationsState,
                onSearch = operations::searchPurchases,
                onSelect = operations::selectPurchase,
                onSettle = operations::settlePurchase,
                onReverseSettlement = operations::reversePurchaseSettlement,
                onReverse = operations::reversePurchase,
                onAdd = { screen = AppScreen.NEW_PURCHASE },
                onBack = {
                    operations.selectPurchase(null)
                    screen = AppScreen.DASHBOARD
                },
            )

            AppScreen.NEW_PURCHASE -> PurchaseEntryScreen(
                state = operationsState,
                onPost = operations::postPurchase,
                onBack = { screen = AppScreen.PURCHASES },
            )

            AppScreen.SUPPLIERS -> SuppliersScreen(
                state = operationsState,
                onSave = operations::saveSupplier,
                onDeactivate = operations::deactivateSupplier,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.INVENTORY -> InventoryScreen(
                state = operationsState,
                onSave = operations::saveInventoryItem,
                onDeactivate = operations::deactivateInventoryItem,
                onCount = operations::postInventoryCount,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SALES -> SalesScreen(
                state = salesState,
                onSearch = sales::search,
                onSelect = sales::selectSale,
                onAddCustomer = sales::addCustomer,
                onPostSale = sales::postSale,
                onReceive = sales::receive,
                onReverse = sales::reverse,
                onReverseSale = sales::reverseSale,
                onReplaceSale = sales::replaceSale,
                onSetReportRange = sales::setReportRange,
                onBack = { sales.selectSale(null); screen = AppScreen.DASHBOARD },
            )

            AppScreen.RECIPES -> RecipeScreen(
                state = recipeState,
                onSelect = recipes::select,
                onSave = recipes::save,
                onBack = { recipes.select(null); screen = AppScreen.DASHBOARD },
            )

            AppScreen.ACCOUNTING -> AccountingScreen(
                state = accountingState,
                onSearch = accounting::searchJournals,
                onSelectJournal = accounting::selectJournal,
                onSelectLedger = accounting::selectLedger,
                onSaveAccount = accounting::saveAccount,
                onDeactivateAccount = accounting::deactivateAccount,
                onReverse = accounting::reverseManual,
                onAddJournal = { screen = AppScreen.NEW_JOURNAL },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.AUDIT_LOG -> AuditLogScreen(state = operationsState, onBack = { screen = AppScreen.DASHBOARD })

            AppScreen.PERSONNEL -> PersonnelScreen(
                state = personnelState,
                onSaveEmployee = personnel::saveEmployee,
                onDeactivate = personnel::deactivate,
                onPostPayroll = personnel::postPayroll,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SECURITY -> SecurityScreen(
                state = securityState,
                onSave = security::save,
                onDeactivate = security::deactivate,
                onSwitch = security::switchUser,
                onBackup = security::createBackup,
                onRestore = security::restore,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.ASSETS -> AssetScreen(
                state = assetState,
                onSave = assets::save,
                onDispose = assets::dispose,
                onDepreciate = assets::depreciate,
                onBack = { screen = AppScreen.DASHBOARD },
            )


            AppScreen.CRM -> CrmScreen(
                state = crmState,
                onAdjustPoints = crm::adjustPoints,
                onAddFollowUp = crm::addFollowUp,
                onComplete = crm::complete,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.ALERTS -> AlertCenterScreen(
                state = alertState,
                onRefresh = alerts::refresh,
                onRead = alerts::markRead,
                onDismiss = alerts::dismiss,
                onClearDismissed = alerts::clearDismissed,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.REPORTS -> ReportsCenterScreen(
                dashboard = dashboardState,
                sales = salesState,
                accounting = accountingState,
                operations = operationsState,
                onOpenSales = { screen = AppScreen.SALES },
                onOpenAccounting = { screen = AppScreen.ACCOUNTING },
                onOpenInventory = { screen = AppScreen.INVENTORY },
                onBack = { screen = AppScreen.DASHBOARD },
            )


            AppScreen.GLOBAL_SEARCH -> GlobalSearchScreen(
                currentUser = securityState.currentUser,
                onOpen = { screen = it },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SETTINGS -> SettingsScreen(
                themePreference = themePreference,
                onThemePreferenceChange = onThemePreferenceChange,
                onOpenSecurity = { screen = AppScreen.SECURITY },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.NEW_JOURNAL -> ManualJournalEntryScreen(
                state = accountingState,
                onPost = accounting::postManual,
                onBack = { screen = AppScreen.ACCOUNTING },
            )
        }
    }
}

@Composable
private fun DashboardScreen(
    state: DashboardSnapshot,
    operationsState: OperationsUiState,
    currentUser: AppUserRecord?,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (AppScreen?) -> Unit,
) {
    val visibleModules = modules.filter {
        it.permission == null || currentUser?.role?.allows(it.permission) == true
    }
    val totalLiquidity = state.cashBalanceRial + state.bankBalanceRial
    val urgentCount = operationsState.lowStockItems.size + operationsState.settlementAlerts.size

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            PremiumBottomBar(
                onHome = { },
                onOperations = { onOpen(AppScreen.SALES) },
                onReports = { onOpen(AppScreen.REPORTS) },
                onProfile = onSettings,
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(22.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 28.dp),
        ) {
            item {
                PremiumHeader(
                    userName = currentUser?.displayName ?: "کاربر سابو",
                    roleTitle = currentUser?.role?.title.orEmpty(),
                    onSearch = onSearch,
                    onSettings = onSettings,
                )
            }

            item {
                BalanceSpotlight(
                    totalLiquidity = totalLiquidity,
                    cash = state.cashBalanceRial,
                    bank = state.bankBalanceRial,
                    onOpenAccounting = { onOpen(AppScreen.ACCOUNTING) },
                )
            }

            item {
                PremiumSectionTitle(
                    title = "دسترسی سریع",
                    subtitle = "کارهای روزانه، فقط با یک لمس",
                    trailing = "همه عملیات",
                    onTrailing = { onOpen(AppScreen.GLOBAL_SEARCH) },
                )
                Spacer(Modifier.height(12.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
                ) {
                    item { PremiumQuickAction("ثبت فروش", "↗", "فاکتور جدید") { onOpen(AppScreen.SALES) } }
                    item { PremiumQuickAction("ثبت خرید", "+", "ورود کالا") { onOpen(AppScreen.NEW_PURCHASE) } }
                    item { PremiumQuickAction("موجودی", "□", "کنترل انبار") { onOpen(AppScreen.INVENTORY) } }
                    item { PremiumQuickAction("مشتریان", "◎", "پیگیری ارتباط") { onOpen(AppScreen.CRM) } }
                }
            }

            item {
                PremiumSectionTitle(
                    title = "نبض کسب‌وکار",
                    subtitle = "مهم‌ترین عددها در یک نگاه",
                )
                Spacer(Modifier.height(12.dp))
                Column(
                    modifier = Modifier.padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        PremiumMetric(
                            title = "ارزش موجودی",
                            value = formatMoney(state.inventoryValueRial),
                            hint = "ارزش فعلی انبار",
                            badge = "انبار",
                            modifier = Modifier.weight(1f),
                        )
                        PremiumMetric(
                            title = "بدهی تأمین‌کنندگان",
                            value = formatMoney(state.supplierPayablesRial),
                            hint = "مانده پرداختنی",
                            badge = "تعهدات",
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            item {
                AttentionCard(
                    lowStockCount = operationsState.lowStockItems.size,
                    settlementCount = operationsState.settlementAlerts.size,
                    urgentCount = urgentCount,
                    onInventory = { onOpen(AppScreen.INVENTORY) },
                    onPurchases = { onOpen(AppScreen.PURCHASES) },
                )
            }

            item {
                PremiumSectionTitle(
                    title = "فضاهای کاری",
                    subtitle = "همه ابزارهای مدیریت، با ساختاری ساده",
                )
            }

            items(visibleModules) { module ->
                PremiumModuleRow(
                    module = module,
                    modifier = Modifier.padding(horizontal = 20.dp),
                    onClick = { onOpen(module.screen) },
                )
            }
        }
    }
}

@Composable
private fun PremiumHeader(
    userName: String,
    roleTitle: String,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                modifier = Modifier.size(52.dp).clickable(onClick = onSettings),
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        userName.take(1).ifBlank { "س" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    "سلام، $userName",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                )
                Text(
                    roleTitle.ifBlank { "مدیریت مجموعه" },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            CircleTextButton("⌕", "جست‌وجو", onSearch)
            Spacer(Modifier.width(8.dp))
            CircleTextButton("•••", "تنظیمات", onSettings)
        }

        Text(
            "امروز چه چیزی را مدیریت می‌کنیم؟",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Black,
        )
    }
}

@Composable
private fun CircleTextButton(symbol: String, description: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.size(44.dp).clickable(onClick = onClick),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .7f)),
        shadowElevation = 2.dp,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(symbol, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
private fun BalanceSpotlight(
    totalLiquidity: Long,
    cash: Long,
    bank: Long,
    onOpenAccounting: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).clickable(onClick = onOpenAccounting),
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "نقدینگی در دسترس",
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .76f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        formatMoney(totalLiquidity),
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .14f),
                ) {
                    Text(
                        "مشاهده خزانه ←",
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BalanceMiniTile("صندوق", formatMoney(cash), Modifier.weight(1f))
                BalanceMiniTile("بانک", formatMoney(bank), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun BalanceMiniTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .10f),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .7f), style = MaterialTheme.typography.labelMedium)
            Text(value, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PremiumSectionTitle(
    title: String,
    subtitle: String,
    trailing: String? = null,
    onTrailing: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (trailing != null && onTrailing != null) {
            Surface(
                modifier = Modifier.clickable(onClick = onTrailing),
                shape = RoundedCornerShape(999.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .65f),
            ) {
                Text(trailing, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PremiumQuickAction(title: String, symbol: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.width(150.dp).height(132.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
                    Text(symbol, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Black)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun PremiumMetric(
    title: String,
    value: String,
    hint: String,
    badge: String,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.height(158.dp),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Surface(shape = RoundedCornerShape(999.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                Text(badge, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Bold)
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(hint, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AttentionCard(
    lowStockCount: Int,
    settlementCount: Int,
    urgentCount: Int,
    onInventory: () -> Unit,
    onPurchases: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f)),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = if (urgentCount > 0) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer) {
                    Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                        Text(if (urgentCount > 0) "!" else "✓", fontWeight = FontWeight.Black, color = if (urgentCount > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("نیازمند توجه", fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (urgentCount > 0) "$urgentCount مورد برای بررسی دارید" else "همه‌چیز مرتب است",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            if (urgentCount > 0) {
                if (lowStockCount > 0) AttentionRow("کمبود موجودی", "$lowStockCount کالا", onInventory)
                if (settlementCount > 0) AttentionRow("تسویه سررسید", "$settlementCount فاکتور", onPurchases)
            } else {
                Text("هشدار فوری یا سررسید عقب‌افتاده‌ای ثبت نشده است.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AttentionRow(title: String, count: String, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f),
    ) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Text(count, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(8.dp))
            Text("←", fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun PremiumModuleRow(module: ModuleCard, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val enabled = module.screen != null
    val symbol = when (module.screen) {
        AppScreen.PURCHASES, AppScreen.NEW_PURCHASE -> "+"
        AppScreen.SUPPLIERS -> "S"
        AppScreen.INVENTORY -> "□"
        AppScreen.RECIPES -> "R"
        AppScreen.SALES -> "↗"
        AppScreen.CRM -> "◎"
        AppScreen.ALERTS -> "!"
        AppScreen.ACCOUNTING -> "≡"
        AppScreen.PERSONNEL -> "P"
        AppScreen.ASSETS -> "A"
        AppScreen.REPORTS -> "↗"
        AppScreen.AUDIT_LOG -> "L"
        AppScreen.SECURITY -> "⚿"
        else -> "•"
    }
    Card(
        modifier = modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                    Text(symbol, color = MaterialTheme.colorScheme.onPrimaryContainer, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(module.title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (enabled) moduleSubtitle(module.screen) else "به‌زودی",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .65f)) {
                Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) {
                    Text("←", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

private fun moduleSubtitle(screen: AppScreen?): String = when (screen) {
    AppScreen.PURCHASES -> "فاکتورها، پرداخت‌ها و سررسیدها"
    AppScreen.SUPPLIERS -> "مدیریت تأمین‌کنندگان و مانده‌ها"
    AppScreen.INVENTORY -> "موجودی، شمارش و هشدار کالا"
    AppScreen.RECIPES -> "محصول، فرمول ساخت و بهای تمام‌شده"
    AppScreen.SALES -> "فروش، دریافت و مشتریان"
    AppScreen.CRM -> "وفاداری و پیگیری مشتری"
    AppScreen.ALERTS -> "هشدارهای مالی و عملیاتی"
    AppScreen.ACCOUNTING -> "اسناد، حساب‌ها و گزارش مالی"
    AppScreen.PERSONNEL -> "کارکنان، حقوق و پرداخت"
    AppScreen.ASSETS -> "دارایی‌ها و استهلاک"
    AppScreen.REPORTS -> "شاخص‌های مدیریتی و چاپ"
    AppScreen.AUDIT_LOG -> "ردیابی تغییرات و فعالیت کاربران"
    AppScreen.SECURITY -> "کاربران، دسترسی و پشتیبان‌گیری"
    else -> "مدیریت و مشاهده جزئیات"
}

@Composable
private fun PremiumBottomBar(
    onHome: () -> Unit,
    onOperations: () -> Unit,
    onReports: () -> Unit,
    onProfile: () -> Unit,
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 12.dp,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .45f)),
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
        ) {
            BottomDestination("خانه", "⌂", true, onHome)
            BottomDestination("عملیات", "+", false, onOperations)
            BottomDestination("گزارش‌ها", "↗", false, onReports)
            BottomDestination("حساب من", "○", false, onProfile)
        }
    }
}

@Composable
private fun BottomDestination(label: String, symbol: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Text(symbol, fontWeight = FontWeight.Black, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
            Text(label, style = MaterialTheme.typography.labelMedium, fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
