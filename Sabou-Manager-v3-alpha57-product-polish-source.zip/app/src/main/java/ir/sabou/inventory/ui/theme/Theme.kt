package ir.sabou.inventory.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowInsetsControllerCompat

/**
 * سیستم بصری alpha54: مدیریتی، آرام و حرفه‌ای.
 * رنگ اصلی سبز تیره برای اعتماد، کهربایی برای اقدام، و سطوح خنثی برای تمرکز روی داده‌ها.
 */
object SabouBrand {
    val Evergreen = Color(0xFF123F36)
    val EvergreenDark = Color(0xFF082A24)
    val Amber = Color(0xFFE2A12A)
    val AmberSoft = Color(0xFFFFE7B4)
    val Ink = Color(0xFF17201E)
    val Canvas = Color(0xFFF7F8F5)
    val Paper = Color(0xFFFFFFFF)
    val Mist = Color(0xFFE9EEEA)
    val Slate = Color(0xFF5E6A66)
}

private val SabouLightColors = lightColorScheme(
    primary = SabouBrand.Evergreen,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7E9E2),
    onPrimaryContainer = SabouBrand.EvergreenDark,
    secondary = Color(0xFF8A5B00),
    onSecondary = Color.White,
    secondaryContainer = SabouBrand.AmberSoft,
    onSecondaryContainer = Color(0xFF392400),
    tertiary = Color(0xFF335E8A),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFD6E8FF),
    onTertiaryContainer = Color(0xFF0B2B48),
    background = SabouBrand.Canvas,
    onBackground = SabouBrand.Ink,
    surface = SabouBrand.Paper,
    onSurface = SabouBrand.Ink,
    surfaceVariant = SabouBrand.Mist,
    onSurfaceVariant = SabouBrand.Slate,
    outline = Color(0xFF83908B),
    outlineVariant = Color(0xFFD9E0DC),
    error = Color(0xFFB3261E),
    errorContainer = Color(0xFFFFDAD6),
)

private val SabouDarkColors = darkColorScheme(
    primary = Color(0xFF9FD4C2),
    onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF185044),
    onPrimaryContainer = Color(0xFFBCEEDF),
    secondary = Color(0xFFFFC96B),
    onSecondary = Color(0xFF472A00),
    secondaryContainer = Color(0xFF654000),
    onSecondaryContainer = Color(0xFFFFDEA1),
    tertiary = Color(0xFFA8CAEF),
    onTertiary = Color(0xFF0A355C),
    tertiaryContainer = Color(0xFF294C70),
    onTertiaryContainer = Color(0xFFD3E5FF),
    background = Color(0xFF101513),
    onBackground = Color(0xFFE1E7E3),
    surface = Color(0xFF171D1A),
    onSurface = Color(0xFFE1E7E3),
    surfaceVariant = Color(0xFF3E4945),
    onSurfaceVariant = Color(0xFFBEC9C4),
    outline = Color(0xFF89948F),
    outlineVariant = Color(0xFF3E4945),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
)

private val SabouTypography = Typography(
    displaySmall = TextStyle(fontSize = 34.sp, lineHeight = 44.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.4).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 36.sp, fontWeight = FontWeight.ExtraBold),
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 31.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 19.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 27.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 19.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
)

private val SabouShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp),
)

@Composable
fun SabouTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) SabouDarkColors else SabouLightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.background.toArgb()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.navigationBarColor = colors.surface.toArgb()
            }
            WindowInsetsControllerCompat(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }
    MaterialTheme(
        colorScheme = colors,
        typography = SabouTypography,
        shapes = SabouShapes,
        content = content,
    )
}
