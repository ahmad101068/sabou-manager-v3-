package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.data.db.*
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.operations.*
import ir.sabou.inventory.domain.sales.*
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class LocalRestaurantOperationsRepository(
    private val db: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val salesRepository: SalesRepository,
    private val clock: () -> Long = System::currentTimeMillis,
) : RestaurantOperationsRepository {
    private val dao get() = db.restaurantOperationsDao()
    override val tables = dao.observeTables().map { rows -> rows.map { RestaurantTable(it.id,it.label,it.capacity,it.zone,TableStatus.valueOf(it.status),it.activeOrderId) } }
    override val reservations = dao.observeReservations().map { rows -> rows.map { Reservation(it.id,it.customerName,it.phone,it.tableId,it.startEpochMillis,it.endEpochMillis,it.partySize,it.notes) } }
    override val kitchenTickets = dao.observeKitchenTickets().map { rows -> KitchenQueue.prioritize(rows.map { KitchenTicket(it.id,it.orderNo,it.station,it.itemName,it.quantity,it.createdAtEpochMillis,KitchenTicketStatus.valueOf(it.status),it.priority) }) }
    override val shifts = dao.observeShifts().map { rows -> rows.map { PlannedShift(it.employeeId,it.employeeName,it.role,it.epochDay,it.startMinute,it.endMinute,it.id) } }
    override val approvals = dao.observeApprovals().map { rows -> rows.map { ApprovalRequest(it.id,it.requestType,it.entityId,it.amountRial,it.requestedBy,it.approver,ApprovalStatus.valueOf(it.status),it.note) } }
    override val openOrders = combine(dao.observeOpenOrders(), dao.observeActiveOrderLines(), dao.observeTables(), dao.observeCurrentBillSplits(), dao.observeBillSplitLines()) { orders, lines, tables, splits, splitLines ->
        val labels = tables.associate { it.id to it.label }
        orders.map { order ->
            val orderLines = lines.filter { it.orderId == order.id }
            val orderSplits = splits.filter { it.orderId == order.id }.map { split ->
                val lineIds = splitLines.filter { it.splitId == split.id }.map { it.orderLineId }.toSet()
                BillSplit(
                    id = split.id,
                    orderId = split.orderId,
                    label = split.label,
                    mode = BillSplitMode.valueOf(split.mode),
                    status = BillSplitStatus.valueOf(split.status),
                    saleId = split.saleId,
                    lines = orderLines.filter { it.id in lineIds }.map(::lineToDomain),
                )
            }
            order.toDomain(labels[order.tableId].orEmpty(), orderLines, orderSplits)
        }
    }
    override val cashShifts = dao.observeCashShifts().map { rows -> rows.map(::cashShiftToDomain) }

    override suspend fun addTable(label:String,capacity:Int,zone:String):Long { authorizer.require("SALES"); require(label.trim().isNotEmpty() && capacity in 1..100); val id=dao.insertTable(RestaurantTableEntity(label=label.trim(),capacity=capacity,zone=zone.trim()));audit("CREATE","TABLE",id,"ثبت میز ${label.trim()}");return id }
    override suspend fun transitionTable(id:Long,status:TableStatus,orderId:Long?) { authorizer.require("SALES"); val old=dao.table(id)?:error("میز پیدا نشد."); val next=RestaurantTable(old.id,old.label,old.capacity,old.zone,TableStatus.valueOf(old.status),old.activeOrderId).transition(status,orderId); check(dao.updateTable(old.copy(status=next.status.name,activeOrderId=next.activeOrderId))==1);audit("STATUS","TABLE",id,"${old.status} → ${next.status.name}") }
    override suspend fun addReservation(value: Reservation): Long {
        authorizer.require("SALES")
        val valid = value.validated()
        val table = dao.table(valid.tableId) ?: error("میز انتخاب‌شده پیدا نشد.")
        require(valid.partySize <= table.capacity) { "تعداد مهمان از ظرفیت میز ${table.label} بیشتر است." }
        val existing = dao.allReservations().map {
            Reservation(it.id, it.customerName, it.phone, it.tableId, it.startEpochMillis, it.endEpochMillis, it.partySize, it.notes)
        }
        require(!ReservationConflictChecker.conflicts(valid, existing)) { "زمان رزرو با رزرو دیگری تداخل دارد." }
        val id = dao.insertReservation(
            ReservationEntity(
                customerName = valid.customerName,
                phone = valid.phone,
                tableId = valid.tableId,
                startEpochMillis = valid.startEpochMillis,
                endEpochMillis = valid.endEpochMillis,
                partySize = valid.partySize,
                notes = valid.notes,
            ),
        )
        audit("CREATE", "RESERVATION", id, "رزرو ${valid.customerName} برای میز ${table.label}")
        return id
    }
    override suspend fun addKitchenTicket(orderNo:String,station:String,itemName:String,quantity:Int,priority:Int):Long { authorizer.require("KITCHEN"); require(orderNo.isNotBlank()&&station.isNotBlank()&&itemName.isNotBlank()&&quantity>0&&priority in 0..10); val id=dao.insertKitchenTicket(KitchenTicketEntity(orderNo=orderNo.trim(),station=station.trim(),itemName=itemName.trim(),quantity=quantity,createdAtEpochMillis=System.currentTimeMillis(),priority=priority));audit("CREATE","KITCHEN_TICKET",id,"سفارش $orderNo · $itemName");return id }
    override suspend fun transitionKitchenTicket(id:Long,status:KitchenTicketStatus) { authorizer.require("KITCHEN"); val old=dao.kitchenTicket(id)?:error("سفارش آشپزخانه پیدا نشد."); val next=KitchenTicket(old.id,old.orderNo,old.station,old.itemName,old.quantity,old.createdAtEpochMillis,KitchenTicketStatus.valueOf(old.status),old.priority).transition(status); check(dao.updateKitchenTicket(old.copy(status=next.status.name))==1);audit("STATUS","KITCHEN_TICKET",id,"${old.status} → ${next.status.name}") }
    override suspend fun planShift(demand:ShiftDemand,staff:List<StaffAvailability>):Int { authorizer.require("PERSONNEL"); val planned=ShiftPlanner.plan(demand,staff); dao.insertShifts(planned.map { PlannedShiftEntity(employeeId=it.employeeId,employeeName=it.employeeName,role=it.role,epochDay=it.epochDay,startMinute=it.startMinute,endMinute=it.endMinute) });audit("CREATE","SHIFT",null,"ثبت ${planned.size} شیفت");return planned.size }
    override suspend fun requestApproval(type:String,entityId:Long,amountRial:Long,requestedBy:String):Long { authorizer.require("AUDIT"); require(ApprovalPolicy.requiresApproval(type,amountRial,0)); val id=dao.insertApproval(ApprovalRequestEntity(requestType=type.trim(),entityId=entityId,amountRial=amountRial,requestedBy=requestedBy.trim()));audit("CREATE","APPROVAL",id,"درخواست تأیید $type");return id }
    override suspend fun reviewApproval(id:Long,approve:Boolean,by:String,note:String) { authorizer.require("AUDIT"); val old=dao.approval(id)?:error("درخواست تأیید پیدا نشد."); val request=ApprovalRequest(old.id,old.requestType,old.entityId,old.amountRial,old.requestedBy,old.approver,ApprovalStatus.valueOf(old.status),old.note); val next=if(approve) request.approve(by) else request.reject(by,note); check(dao.updateApproval(old.copy(approver=next.approver,status=next.status.name,note=next.note))==1);audit(next.status.name,"APPROVAL",id,"بررسی درخواست ${old.requestType}") }

    override suspend fun openTableOrder(draft: OpenTableOrderDraft): Long = db.withTransaction {
        authorizer.require("SALES")
        val valid = draft.validated()
        val table = dao.table(valid.tableId) ?: error("میز انتخاب‌شده پیدا نشد.")
        require(table.status == TableStatus.FREE.name || table.status == TableStatus.RESERVED.name) { "این میز آماده ثبت سفارش نیست." }
        require(table.activeOrderId == null && dao.openOrderForTable(table.id) == null) { "برای این میز سفارش باز وجود دارد." }
        require(valid.guestCount <= table.capacity) { "تعداد مهمان از ظرفیت میز ${table.label} بیشتر است." }
        val now = clock()
        val id = dao.insertOrder(
            TableOrderEntity(
                orderNo = "M-${now}-${table.id}",
                tableId = table.id,
                guestCount = valid.guestCount,
                waiterName = valid.waiterName,
                customerId = valid.customerId,
                customerName = valid.customerName,
                openedAtEpochMillis = now,
                notes = valid.notes,
            ),
        )
        check(dao.updateTable(table.copy(status = TableStatus.OCCUPIED.name, activeOrderId = id)) == 1)
        audit("OPEN", "TABLE_ORDER", id, "باز کردن سفارش برای میز ${table.label}")
        id
    }

    override suspend fun addTableOrderItem(orderId: Long, draft: TableOrderItemDraft): Long = db.withTransaction {
        authorizer.require("SALES")
        val valid = draft.validated()
        val order = dao.order(orderId) ?: error("سفارش میز پیدا نشد.")
        require(order.status == TableOrderStatus.OPEN.name) { "سفارش بسته شده است." }
        require(dao.openSplitCount(order.id) == 0 && dao.settledSplitCount(order.id) == 0) { "پس از ساخت صورتحساب تفکیکی، ابتدا آن را لغو یا تسویه کنید." }
        val table = dao.table(order.tableId) ?: error("میز سفارش پیدا نشد.")
        require(table.activeOrderId == order.id && table.status == TableStatus.OCCUPIED.name) { "ارتباط میز و سفارش معتبر نیست." }
        val menu = db.recipeDao().activeMenuItem(valid.menuItemId) ?: error("محصول منو فعال نیست.")
        val now = clock()
        val lineId = dao.insertOrderLine(
            TableOrderLineEntity(
                orderId = order.id,
                menuItemId = menu.id,
                itemName = menu.name,
                quantityMicros = valid.quantity.value,
                unitPriceRial = menu.salePriceRial,
                seatNo = valid.seatNo,
                courseNo = valid.courseNo,
                notes = valid.notes,
                sentToKitchenAtEpochMillis = now,
            ),
        )
        val kitchenQuantity = ((valid.quantity.value + QuantityMicros.SCALE - 1) / QuantityMicros.SCALE)
            .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        dao.insertKitchenTicket(
            KitchenTicketEntity(
                orderNo = order.orderNo,
                station = KitchenStationRouter.stationFor(menu.category),
                itemName = menu.name + valid.notes.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty(),
                quantity = kitchenQuantity,
                createdAtEpochMillis = now,
                priority = 2,
                orderLineId = lineId,
            ),
        )
        audit("ADD_ITEM", "TABLE_ORDER", order.id, "${menu.name} به سفارش ${order.orderNo} اضافه شد")
        lineId
    }

    override suspend fun transferTableOrder(orderId: Long, targetTableId: Long) = db.withTransaction {
        authorizer.require("SALES")
        val order = dao.order(orderId) ?: error("سفارش میز پیدا نشد.")
        require(order.status == TableOrderStatus.OPEN.name) { "فقط سفارش باز قابل انتقال است." }
        require(dao.openSplitCount(order.id) == 0 && dao.settledSplitCount(order.id) == 0) { "سفارش دارای صورتحساب تفکیکی قابل انتقال نیست." }
        val source = dao.table(order.tableId) ?: error("میز مبدأ پیدا نشد.")
        val target = dao.table(targetTableId) ?: error("میز مقصد پیدا نشد.")
        require(source.activeOrderId == order.id) { "ارتباط میز مبدأ و سفارش معتبر نیست." }
        require(source.id != target.id && target.status == TableStatus.FREE.name && target.activeOrderId == null) { "میز مقصد باید خالی باشد." }
        require(order.guestCount <= target.capacity) { "ظرفیت میز مقصد کافی نیست." }
        check(dao.updateOrder(order.copy(tableId = target.id)) == 1)
        check(dao.updateTable(source.copy(status = TableStatus.FREE.name, activeOrderId = null)) == 1)
        check(dao.updateTable(target.copy(status = TableStatus.OCCUPIED.name, activeOrderId = order.id)) == 1)
        audit("TRANSFER", "TABLE_ORDER", order.id, "انتقال از میز ${source.label} به ${target.label}")
    }

    override suspend fun mergeTableOrders(sourceOrderId: Long, targetOrderId: Long) = db.withTransaction {
        authorizer.require("SALES")
        require(sourceOrderId != targetOrderId) { "سفارش مبدأ و مقصد یکسان است." }
        val source = dao.order(sourceOrderId) ?: error("سفارش مبدأ پیدا نشد.")
        val target = dao.order(targetOrderId) ?: error("سفارش مقصد پیدا نشد.")
        require(source.status == TableOrderStatus.OPEN.name && target.status == TableOrderStatus.OPEN.name) { "هر دو سفارش باید باز باشند." }
        require(dao.openSplitCount(source.id) == 0 && dao.settledSplitCount(source.id) == 0 && dao.openSplitCount(target.id) == 0 && dao.settledSplitCount(target.id) == 0) { "سفارش دارای صورتحساب تفکیکی قابل ادغام نیست." }
        val sourceTable = dao.table(source.tableId) ?: error("میز مبدأ پیدا نشد.")
        val targetTable = dao.table(target.tableId) ?: error("میز مقصد پیدا نشد.")
        require(sourceTable.activeOrderId == source.id && targetTable.activeOrderId == target.id) { "ارتباط میزها و سفارش‌ها معتبر نیست." }
        val combinedGuests = source.guestCount + target.guestCount
        require(combinedGuests <= targetTable.capacity) { "ظرفیت میز مقصد برای ادغام دو سفارش کافی نیست." }
        dao.moveActiveOrderLines(source.id, target.id)
        check(dao.updateOrder(target.copy(guestCount = combinedGuests)) == 1)
        check(dao.updateOrder(source.copy(status = TableOrderStatus.MERGED.name, closedAtEpochMillis = clock(), mergedIntoOrderId = target.id)) == 1)
        check(dao.updateTable(sourceTable.copy(status = TableStatus.FREE.name, activeOrderId = null)) == 1)
        audit("MERGE", "TABLE_ORDER", source.id, "ادغام ${source.orderNo} در ${target.orderNo}")
    }

    override suspend fun checkoutTableOrder(orderId: Long, draft: TableCheckoutDraft): Long = db.withTransaction {
        authorizer.require("SALES")
        val orderEntity = dao.order(orderId) ?: error("سفارش میز پیدا نشد.")
        val table = dao.table(orderEntity.tableId) ?: error("میز سفارش پیدا نشد.")
        require(table.activeOrderId == orderEntity.id && table.status == TableStatus.OCCUPIED.name) { "ارتباط میز و سفارش معتبر نیست." }
        val lineEntities = dao.activeOrderLines(orderId)
        val order = orderEntity.toDomain(table.label, lineEntities)
        require(dao.openSplitCount(orderId) == 0 && dao.settledSplitCount(orderId) == 0) { "برای این سفارش صورتحساب تفکیکی ساخته شده است؛ سهم‌ها را جداگانه تسویه کنید." }
        val total = TableOrderRules.validateCheckout(order, draft)
        val posted = salesRepository.post(
            SaleDraft(
                invoiceNo = "${order.orderNo}-F",
                customerId = order.customerId,
                customerName = order.customerName,
                saleEpochDay = draft.saleEpochDay,
                dueEpochDay = draft.dueEpochDay,
                channel = "حضوری · میز ${order.tableLabel}",
                discount = draft.discount,
                delivery = draft.serviceCharge,
                paymentMethod = draft.payments.firstOrNull()?.method ?: SalePaymentMethod.RECEIVABLE,
                notes = "سفارش ${order.orderNo} · مسئول ${order.waiterName}" + order.notes.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty(),
                lines = order.lines.map { SaleLineDraft(it.menuItemId, it.itemName, it.quantity, it.unitPrice) },
                payments = draft.payments,
                skipKitchenDispatch = true,
            ),
        )
        val paid = MoneyRial.sum(draft.payments.map { it.amount })
        val nextTableStatus = if (paid.value == total.value) TableStatus.CLEANING else TableStatus.WAITING_PAYMENT
        check(dao.updateOrder(orderEntity.copy(status = TableOrderStatus.CHECKED_OUT.name, closedAtEpochMillis = clock(), saleId = posted.saleId)) == 1)
        check(dao.updateTable(table.copy(status = nextTableStatus.name, activeOrderId = null)) == 1)
        audit("CHECKOUT", "TABLE_ORDER", order.id, "تسویه ${order.orderNo} با فاکتور ${posted.saleId}")
        posted.saleId
    }

    override suspend fun transferTableOrderLine(lineId: Long, targetOrderId: Long) = db.withTransaction {
        authorizer.require("SALES")
        val line = dao.orderLine(lineId) ?: error("ردیف سفارش پیدا نشد.")
        require(line.status == "ACTIVE") { "ردیف فعال نیست." }
        require(dao.currentSplitAssignmentCount(line.id) == 0) { "ردیفی که وارد صورتحساب تفکیکی شده قابل انتقال نیست." }
        val source = dao.order(line.orderId) ?: error("سفارش مبدأ پیدا نشد.")
        val target = dao.order(targetOrderId) ?: error("سفارش مقصد پیدا نشد.")
        require(source.id != target.id && source.status == TableOrderStatus.OPEN.name && target.status == TableOrderStatus.OPEN.name) { "سفارش مبدأ یا مقصد معتبر نیست." }
        require(dao.table(source.tableId)?.activeOrderId == source.id && dao.table(target.tableId)?.activeOrderId == target.id) { "ارتباط میزها و سفارش‌ها معتبر نیست." }
        check(dao.moveOrderLine(line.id, source.id, target.id) == 1)
        dao.relabelKitchenTicketForOrderLine(line.id, target.orderNo)
        audit("TRANSFER_LINE", "TABLE_ORDER_LINE", line.id, "انتقال ${line.itemName} از ${source.orderNo} به ${target.orderNo}")
    }

    override suspend fun voidTableOrderLine(lineId: Long, draft: VoidOrderLineDraft) = db.withTransaction {
        authorizer.require("AUDIT")
        val valid = draft.validated()
        val approvedBy = authorizer.actor()
        val line = dao.orderLine(lineId) ?: error("ردیف سفارش پیدا نشد.")
        val order = dao.order(line.orderId) ?: error("سفارش ردیف پیدا نشد.")
        require(order.status == TableOrderStatus.OPEN.name && line.status == "ACTIVE") { "ردیف قابل ابطال نیست." }
        require(dao.currentSplitAssignmentCount(line.id) == 0) { "ردیفی که وارد صورتحساب تفکیکی شده قابل ابطال نیست." }
        val ticket = dao.kitchenTicketForOrderLine(line.id) ?: dao.legacyKitchenTicketForOrderLine(order.orderNo, line.itemName)
        require(ticket?.status != KitchenTicketStatus.READY.name && ticket?.status != KitchenTicketStatus.SERVED.name) { "غذای آماده یا سرو‌شده باید از مسیر ضایعات/برگشت مدیریت شود." }
        val now = clock()
        check(dao.voidOrderLine(line.id, valid.reason, approvedBy, now) == 1)
        if (ticket != null) {
            if (ticket.orderLineId != null) dao.cancelKitchenTicketForOrderLine(line.id)
            else if (ticket.status == KitchenTicketStatus.QUEUED.name || ticket.status == KitchenTicketStatus.PREPARING.name) check(dao.updateKitchenTicket(ticket.copy(status = KitchenTicketStatus.CANCELLED.name)) == 1)
        }
        audit("VOID", "TABLE_ORDER_LINE", line.id, "ابطال ${line.itemName} · ${valid.reason} · تأیید $approvedBy")
    }

    override suspend fun createBillSplits(orderId: Long, mode: BillSplitMode): Int = db.withTransaction {
        authorizer.require("SALES")
        val entity = dao.order(orderId) ?: error("سفارش پیدا نشد.")
        val table = dao.table(entity.tableId) ?: error("میز سفارش پیدا نشد.")
        val lines = dao.activeOrderLines(orderId)
        val order = entity.toDomain(table.label, lines)
        require(dao.settledSplitCount(orderId) == 0) { "بخشی از صورتحساب قبلاً تسویه شده و تقسیم مجدد مجاز نیست." }
        dao.cancelOpenBillSplits(orderId)
        val plans = BillSplitPlanner.create(order, mode)
        val now = clock()
        plans.forEach { plan ->
            val splitId = dao.insertBillSplit(BillSplitEntity(orderId = order.id, label = plan.label, mode = mode.name, createdAtEpochMillis = now))
            dao.insertBillSplitLines(plan.lineIds.map { BillSplitLineEntity(splitId = splitId, orderLineId = it) })
        }
        audit("SPLIT", "TABLE_ORDER", order.id, "تقسیم صورتحساب ${order.orderNo} به ${plans.size} سهم ${mode.name}")
        plans.size
    }

    override suspend fun checkoutBillSplit(splitId: Long, draft: TableCheckoutDraft): Long = db.withTransaction {
        authorizer.require("SALES")
        val split = dao.billSplit(splitId) ?: error("سهم صورتحساب پیدا نشد.")
        require(split.status == BillSplitStatus.OPEN.name) { "این سهم قبلاً تسویه یا لغو شده است." }
        val orderEntity = dao.order(split.orderId) ?: error("سفارش پیدا نشد.")
        val table = dao.table(orderEntity.tableId) ?: error("میز سفارش پیدا نشد.")
        require(orderEntity.status == TableOrderStatus.OPEN.name && table.activeOrderId == orderEntity.id) { "سفارش یا میز بسته شده است." }
        val splitLines = dao.linesForBillSplit(split.id)
        val splitOrder = orderEntity.toDomain(table.label, splitLines)
        val total = TableOrderRules.validateCheckout(splitOrder, draft)
        val posted = salesRepository.post(
            SaleDraft(
                invoiceNo = "${orderEntity.orderNo}-S${split.id}",
                customerId = orderEntity.customerId,
                customerName = orderEntity.customerName,
                saleEpochDay = draft.saleEpochDay,
                dueEpochDay = draft.dueEpochDay,
                channel = "حضوری · میز ${table.label} · ${split.label}",
                discount = draft.discount,
                delivery = draft.serviceCharge,
                paymentMethod = draft.payments.firstOrNull()?.method ?: SalePaymentMethod.RECEIVABLE,
                notes = "${split.label} از سفارش ${orderEntity.orderNo}",
                lines = splitOrder.lines.map { SaleLineDraft(it.menuItemId, it.itemName, it.quantity, it.unitPrice) },
                payments = draft.payments,
                skipKitchenDispatch = true,
            ),
        )
        check(dao.updateBillSplit(split.copy(status = BillSplitStatus.SETTLED.name, saleId = posted.saleId, settledAtEpochMillis = clock())) == 1)
        if (dao.openSplitCount(orderEntity.id) == 0) {
            val hasReceivable = dao.unsettledSaleCountForOrder(orderEntity.id) > 0
            check(dao.updateOrder(orderEntity.copy(status = TableOrderStatus.CHECKED_OUT.name, closedAtEpochMillis = clock(), saleId = posted.saleId)) == 1)
            check(dao.updateTable(table.copy(status = if (hasReceivable) TableStatus.WAITING_PAYMENT.name else TableStatus.CLEANING.name, activeOrderId = null)) == 1)
        }
        audit("CHECKOUT_SPLIT", "BILL_SPLIT", split.id, "تسویه ${split.label} · ${total.value} ریال")
        posted.saleId
    }

    override suspend fun openCashShift(openingFloat: MoneyRial, note: String): Long = db.withTransaction {
        authorizer.require("SALES")
        require(dao.activeCashShift() == null) { "یک شیفت صندوق باز وجود دارد." }
        val actor = authorizer.actor()
        val id = dao.insertCashShift(CashShiftEntity(openedAtEpochMillis = clock(), openingFloatRial = openingFloat.value, openedBy = actor, note = note.trim()))
        audit("OPEN", "CASH_SHIFT", id, "افتتاح صندوق با ${openingFloat.value} ریال")
        id
    }

    override suspend fun closeCashShift(countedCash: MoneyRial, note: String) = db.withTransaction {
        authorizer.require("SALES")
        val shift = dao.activeCashShift() ?: error("شیفت صندوق بازی وجود ندارد.")
        val expected = dao.expectedCashRial(shift.openedAtEpochMillis, shift.openingFloatRial)
        require(expected >= 0L) { "گردش نقدی شیفت نامعتبر است؛ برگشت‌های نقدی را بررسی کنید." }
        val variance = CashShiftReconciliation.variance(MoneyRial.of(expected), countedCash)
        check(dao.updateCashShift(shift.copy(closedAtEpochMillis = clock(), expectedCashRial = expected, countedCashRial = countedCash.value, varianceRial = variance, closedBy = authorizer.actor(), status = CashShiftStatus.CLOSED.name, note = note.trim().ifBlank { shift.note })) == 1)
        audit("CLOSE", "CASH_SHIFT", shift.id, "بستن صندوق · انتظار $expected · شمارش ${countedCash.value} · مغایرت $variance")
    }

    private fun TableOrderEntity.toDomain(tableLabel: String, lines: List<TableOrderLineEntity>, splits: List<BillSplit> = emptyList()) = TableOrder(
        id = id,
        orderNo = orderNo,
        tableId = tableId,
        tableLabel = tableLabel,
        guestCount = guestCount,
        waiterName = waiterName,
        customerId = customerId,
        customerName = customerName,
        status = TableOrderStatus.valueOf(status),
        openedAtEpochMillis = openedAtEpochMillis,
        notes = notes,
        lines = lines.map(::lineToDomain),
        billSplits = splits,
    )
    private fun lineToDomain(line: TableOrderLineEntity) = TableOrderLine(line.id,line.menuItemId,line.itemName,QuantityMicros.of(line.quantityMicros),MoneyRial.of(line.unitPriceRial),line.seatNo,line.courseNo,line.notes,line.sentToKitchenAtEpochMillis)
    private fun cashShiftToDomain(value:CashShiftEntity)=CashShift(value.id,value.openedAtEpochMillis,value.closedAtEpochMillis,MoneyRial.of(value.openingFloatRial),MoneyRial.of(value.expectedCashRial),value.countedCashRial?.let(MoneyRial::of),value.varianceRial,value.openedBy,value.closedBy,CashShiftStatus.valueOf(value.status),value.note)
    private suspend fun audit(action:String,type:String,id:Long?,description:String)=db.auditLogDao().insert(AuditLogEntity(action=action,entityType=type,entityId=id,description=description,actor=authorizer.actor(),createdAtEpochMillis=System.currentTimeMillis()))
}
