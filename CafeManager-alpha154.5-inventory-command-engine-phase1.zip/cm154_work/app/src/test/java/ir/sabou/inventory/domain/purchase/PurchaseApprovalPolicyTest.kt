package ir.sabou.inventory.domain.purchase

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PurchaseApprovalPolicyTest {
    @Test fun `small requisition needs one approval`() {
        val plan = PurchaseApprovalPolicy.plan(PurchaseApprovalPolicy.SECOND_APPROVAL_THRESHOLD_RIAL - 1)
        assertEquals(1, plan.requiredLevel)
        assertFalse(plan.requiresOwnerAtFinalLevel)
    }

    @Test fun `threshold requisition needs owner second approval`() {
        val plan = PurchaseApprovalPolicy.plan(PurchaseApprovalPolicy.SECOND_APPROVAL_THRESHOLD_RIAL)
        assertEquals(2, plan.requiredLevel)
        assertTrue(plan.requiresOwnerAtFinalLevel)
    }
}
