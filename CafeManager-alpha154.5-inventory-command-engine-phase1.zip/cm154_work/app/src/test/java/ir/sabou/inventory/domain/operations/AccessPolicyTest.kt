package ir.sabou.inventory.domain.operations

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AccessPolicyTest {
    @Test
    fun cashierCannotManageInventory() {
        assertFalse(UserRole.CASHIER.allows("INVENTORY"))
    }

    @Test
    fun ownerCanUseEveryPermission() {
        assertTrue(UserRole.OWNER.allows("MANAGE_USERS"))
        assertTrue(UserRole.OWNER.allows("BACKUP"))
    }

    @Test
    fun onlyOwnerCanExportOrRestoreBackups() {
        assertFalse(UserRole.MANAGER.allows("BACKUP"))
        assertFalse(UserRole.ACCOUNTANT.allows("BACKUP"))
    }
}
