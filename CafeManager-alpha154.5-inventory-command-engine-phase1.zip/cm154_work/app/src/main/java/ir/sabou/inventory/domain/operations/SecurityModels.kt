package ir.sabou.inventory.domain.operations

import kotlinx.coroutines.flow.Flow

data class AppUserRecord(
    val id: Long,
    val username: String,
    val displayName: String,
    val role: UserRole,
    val isActive: Boolean,
    val hasRecoveryCode: Boolean,
)
data class UserDraft(
    val username: String,
    val displayName: String,
    val pin: String,
    val role: UserRole,
    val recoveryCode: String = "",
)

/** High-impact commands that require the current user to prove their PIN again. */
enum class SensitiveAction(
    val title: String,
    val requiredPermission: String,
    val ownerOnly: Boolean = false,
) {
    RESTORE_BACKUP("بازیابی نسخه پشتیبان", "BACKUP", ownerOnly = true),
    FACTORY_RESET("بازنشانی کامل برنامه", "MANAGE_USERS", ownerOnly = true),
    CLOSE_INVENTORY_PERIOD("بستن دوره انبار", "INVENTORY"),
    REOPEN_INVENTORY_PERIOD("بازگشایی دوره انبار", "INVENTORY", ownerOnly = true),
    CLOSE_SALES_DAY("بستن روز فروش", "SALES"),
    REOPEN_SALES_DAY("بازگشایی روز فروش", "SALES", ownerOnly = true),
    CLOSE_ACCOUNTING_PERIOD("بستن دوره مالی", "ACCOUNTING"),
    REOPEN_ACCOUNTING_PERIOD("بازگشایی دوره مالی", "ACCOUNTING", ownerOnly = true),
}

interface SecurityRepository {
    val users: Flow<List<AppUserRecord>>
    val currentUser: Flow<AppUserRecord?>
    suspend fun save(id: Long?, draft: UserDraft): Long
    suspend fun deactivate(id: Long)
    suspend fun switchUser(id: Long, pin: String)
    suspend fun setRecoveryCode(id: Long, recoveryCode: String)
    suspend fun resetPinWithRecovery(id: Long, recoveryCode: String, newPin: String)
    suspend fun authorizeSensitiveAction(action: SensitiveAction, pin: String)
    suspend fun logout()
}
