package ir.sabou.inventory.domain.accounting

import ir.sabou.inventory.core.MoneyRial

/**
 * Stable business-facing account identities. Business domains depend on these roles rather than
 * concrete chart-of-account codes. The mapping to the current system chart belongs to accounting.
 */
enum class SemanticAccountRole {
    CASH,
    BANK,
    INVENTORY_ASSET,
    SUPPLIER_CREDIT_RECEIVABLE,
    EMPLOYEE_ADVANCE_RECEIVABLE,
    FIXED_ASSET,
    ACCUMULATED_DEPRECIATION,
    SUPPLIER_PAYABLE,
    GOODS_RECEIVED_NOT_INVOICED,
    PAYROLL_PAYABLE,
    TAX_PAYABLE,
    INSURANCE_PAYABLE,
    OWNER_CAPITAL,
    SALES_REVENUE,
    SERVICE_REVENUE,
    COGS,
    SALARY_EXPENSE,
    INVENTORY_WASTE_EXPENSE,
    PURCHASE_PRICE_VARIANCE,
    DEPRECIATION_EXPENSE,
    ASSET_DISPOSAL_LOSS,
}

interface SemanticAccountResolver {
    fun codeFor(role: SemanticAccountRole): String
}

/** Current alpha154.1 system chart mapping, centralized behind semantic roles. */
object SystemSemanticAccountResolver : SemanticAccountResolver {
    private val codes = mapOf(
        SemanticAccountRole.CASH to "1101",
        SemanticAccountRole.BANK to "1102",
        SemanticAccountRole.INVENTORY_ASSET to "1301",
        SemanticAccountRole.SUPPLIER_CREDIT_RECEIVABLE to "1203",
        SemanticAccountRole.EMPLOYEE_ADVANCE_RECEIVABLE to "1401",
        SemanticAccountRole.FIXED_ASSET to "1501",
        SemanticAccountRole.ACCUMULATED_DEPRECIATION to "1502",
        SemanticAccountRole.SUPPLIER_PAYABLE to "2101",
        SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED to "2105",
        SemanticAccountRole.PAYROLL_PAYABLE to "2102",
        SemanticAccountRole.TAX_PAYABLE to "2103",
        SemanticAccountRole.INSURANCE_PAYABLE to "2104",
        SemanticAccountRole.OWNER_CAPITAL to "3101",
        SemanticAccountRole.SALES_REVENUE to "4101",
        SemanticAccountRole.SERVICE_REVENUE to "4103",
        SemanticAccountRole.COGS to "5101",
        SemanticAccountRole.SALARY_EXPENSE to "6101",
        SemanticAccountRole.INVENTORY_WASTE_EXPENSE to "6104",
        SemanticAccountRole.PURCHASE_PRICE_VARIANCE to "6111",
        SemanticAccountRole.DEPRECIATION_EXPENSE to "6110",
        SemanticAccountRole.ASSET_DISPOSAL_LOSS to "6112",
    )

    override fun codeFor(role: SemanticAccountRole): String =
        codes[role] ?: error("برای نقش حسابداری ${role.name} حساب سیستمی تعریف نشده است.")
}

data class SemanticJournalLine(
    val role: SemanticAccountRole,
    val debit: MoneyRial = MoneyRial.ZERO,
    val credit: MoneyRial = MoneyRial.ZERO,
    val memo: String = "",
) {
    init {
        require((debit > MoneyRial.ZERO) xor (credit > MoneyRial.ZERO)) {
            "هر آرتیکل معنایی باید فقط بدهکار یا فقط بستانکار باشد."
        }
    }
}

data class SemanticJournalDraft(
    val entryNo: String,
    val description: String,
    val entryEpochDay: Long,
    val sourceType: String,
    val sourceId: Long,
    val status: String = "POSTED",
    val lines: List<SemanticJournalLine>,
) {
    init {
        require(entryNo.isNotBlank()) { "شماره سند الزامی است." }
        require(description.isNotBlank()) { "شرح سند الزامی است." }
        require(entryEpochDay > 0) { "تاریخ سند معتبر نیست." }
        require(sourceType.isNotBlank()) { "نوع منبع سند الزامی است." }
        require(sourceId >= 0) { "شناسه منبع سند معتبر نیست." }
        require(lines.size >= 2) { "سند باید حداقل دو آرتیکل داشته باشد." }
        require(MoneyRial.sum(lines.map { it.debit }) == MoneyRial.sum(lines.map { it.credit })) {
            "جمع بدهکار و بستانکار سند برابر نیست."
        }
    }
}
