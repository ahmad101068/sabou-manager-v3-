package ir.sabou.inventory.data.repository

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryLotConsumptionEntity
import ir.sabou.inventory.data.db.StockMovementEntity

/**
 * Single write boundary for authoritative inventory quantity/value movements.
 * Callers remain responsible for wrapping cross-domain workflows in Room.withTransaction.
 */
class LocalInventoryCommandEngine(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    enum class LotIssuePolicy { NONE, FEFO_ALL, FEFO_ALLOCATED_ONLY }

    suspend fun receive(
        itemId: Long,
        quantityMicros: Long,
        valueRial: Long,
        movementType: String,
        referenceType: String,
        referenceId: Long,
        movementEpochDay: Long,
        notes: String? = null,
    ): Long {
        require(quantityMicros > 0) { "مقدار ورود موجودی باید مثبت باشد." }
        require(valueRial >= 0) { "ارزش ورود موجودی نمی‌تواند منفی باشد." }
        val item = database.inventoryDao().activeById(itemId) ?: error("کالای فعال پیدا نشد.")
        val nextStock = (QuantityMicros.of(item.stockMicros) + QuantityMicros.of(quantityMicros)).value
        val nextValue = (MoneyRial.of(item.inventoryValueRial) + MoneyRial.of(valueRial)).value
        val now = clock()
        check(database.inventoryDao().updateValuation(item.id, nextStock, nextValue, now) == 1) {
            "به‌روزرسانی موجودی انجام نشد."
        }
        return database.stockMovementDao().insert(
            StockMovementEntity(
                itemId = item.id,
                movementType = movementType,
                quantityDeltaMicros = quantityMicros,
                valueDeltaRial = valueRial,
                referenceType = referenceType,
                referenceId = referenceId,
                movementEpochDay = movementEpochDay,
                notes = notes,
                createdAtEpochMillis = now,
            ),
        )
    }

    suspend fun issue(
        itemId: Long,
        quantityMicros: Long,
        valueRial: Long,
        movementType: String,
        referenceType: String,
        referenceId: Long,
        movementEpochDay: Long,
        notes: String? = null,
        lotPolicy: LotIssuePolicy = LotIssuePolicy.FEFO_ALLOCATED_ONLY,
    ): Long {
        require(quantityMicros > 0) { "مقدار خروج موجودی باید مثبت باشد." }
        require(valueRial >= 0) { "ارزش خروج موجودی نمی‌تواند منفی باشد." }
        val item = database.inventoryDao().activeById(itemId) ?: error("کالای فعال پیدا نشد.")
        require(item.stockMicros >= quantityMicros) { "موجودی ${item.name} کافی نیست." }
        require(item.inventoryValueRial >= valueRial) { "ارزش موجودی ${item.name} کافی نیست." }
        val now = clock()
        check(
            database.inventoryDao().updateValuation(
                itemId = item.id,
                stockMicros = SignedLongMath.subtract(item.stockMicros, quantityMicros),
                inventoryValueRial = SignedLongMath.subtract(item.inventoryValueRial, valueRial),
                updatedAtEpochMillis = now,
            ) == 1,
        ) { "کاهش موجودی انجام نشد." }
        val movementId = database.stockMovementDao().insert(
            StockMovementEntity(
                itemId = item.id,
                movementType = movementType,
                quantityDeltaMicros = -quantityMicros,
                valueDeltaRial = -valueRial,
                referenceType = referenceType,
                referenceId = referenceId,
                movementEpochDay = movementEpochDay,
                notes = notes,
                createdAtEpochMillis = now,
            ),
        )
        when (lotPolicy) {
            LotIssuePolicy.NONE -> Unit
            LotIssuePolicy.FEFO_ALL -> consumeLotsFefo(item.id, quantityMicros, movementId, now)
            LotIssuePolicy.FEFO_ALLOCATED_ONLY -> {
                val allocatedLots = database.managementControlDao().allocatedQuantity(item.id)
                val unallocatedStock = SignedLongMath.subtract(item.stockMicros, allocatedLots).coerceAtLeast(0L)
                consumeLotsFefo(item.id, SignedLongMath.subtract(quantityMicros, unallocatedStock).coerceAtLeast(0L), movementId, now)
            }
        }
        return movementId
    }

    suspend fun restoreIssuedMovement(
        movement: StockMovementEntity,
        reversalMovementType: String,
        reversalEpochDay: Long,
        notes: String? = null,
    ): Long {
        require(movement.quantityDeltaMicros < 0 && movement.valueDeltaRial <= 0) { "گردش خروج موجودی نامعتبر است." }
        val item = database.inventoryDao().byId(movement.itemId) ?: error("کالای گردش موجودی پیدا نشد.")
        val restoredQuantity = SignedLongMath.subtract(0, movement.quantityDeltaMicros)
        val restoredValue = SignedLongMath.subtract(0, movement.valueDeltaRial)
        val now = clock()
        check(
            database.inventoryDao().restoreValuation(
                itemId = item.id,
                stockMicros = SignedLongMath.add(item.stockMicros, restoredQuantity),
                inventoryValueRial = SignedLongMath.add(item.inventoryValueRial, restoredValue),
                updatedAtEpochMillis = now,
            ) == 1,
        ) { "بازگردانی موجودی ${item.name} انجام نشد." }

        database.managementControlDao().lotConsumptions(movement.id).forEach { consumption ->
            val restoreToLot = SignedLongMath.subtract(consumption.quantityMicros, consumption.reversedQuantityMicros)
            if (restoreToLot > 0) {
                val lot = database.managementControlDao().lot(consumption.lotId) ?: error("لات مصرف‌شده پیدا نشد.")
                check(database.managementControlDao().updateLot(lot.copy(
                    quantityMicros = SignedLongMath.add(lot.quantityMicros, restoreToLot),
                    updatedAtEpochMillis = now,
                )) == 1) { "بازگردانی موجودی لات انجام نشد." }
                check(database.managementControlDao().markLotConsumptionReversed(consumption.id) == 1) {
                    "ثبت بازگشت مصرف لات انجام نشد."
                }
            }
        }
        return database.stockMovementDao().insert(
            StockMovementEntity(
                itemId = item.id,
                movementType = reversalMovementType,
                quantityDeltaMicros = restoredQuantity,
                valueDeltaRial = restoredValue,
                referenceType = movement.referenceType,
                referenceId = movement.referenceId,
                movementEpochDay = reversalEpochDay,
                notes = notes,
                createdAtEpochMillis = now,
            ),
        )
    }

    private suspend fun consumeLotsFefo(itemId: Long, quantityMicros: Long, movementId: Long, now: Long) {
        var remaining = quantityMicros
        if (remaining <= 0) return
        for (lot in database.managementControlDao().availableLotsFefo(itemId)) {
            if (remaining == 0L) break
            val consumed = minOf(remaining, lot.quantityMicros)
            check(database.managementControlDao().updateLot(lot.copy(
                quantityMicros = SignedLongMath.subtract(lot.quantityMicros, consumed),
                updatedAtEpochMillis = now,
            )) == 1) { "کاهش موجودی لات انجام نشد." }
            database.managementControlDao().insertLotConsumption(
                InventoryLotConsumptionEntity(stockMovementId = movementId, lotId = lot.id, quantityMicros = consumed),
            )
            remaining = SignedLongMath.subtract(remaining, consumed)
        }
        require(remaining == 0L) { "پوشش لات برای خروج موجودی کافی نیست." }
    }
}
