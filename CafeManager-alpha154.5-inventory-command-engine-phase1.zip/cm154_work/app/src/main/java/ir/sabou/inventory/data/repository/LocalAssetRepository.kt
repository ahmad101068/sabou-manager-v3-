package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AssetDepreciationEntity
import ir.sabou.inventory.data.db.FixedAssetEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.assets.AssetAcquisitionSource
import ir.sabou.inventory.domain.assets.AssetRecord
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.assets.DepreciationDraft
import ir.sabou.inventory.domain.assets.DepreciationRecord
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.operations.SyncChangeType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalAssetRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : AssetRepository {
    private val dao get() = database.assetDao()
    private val accounting get() = database.accountingDao()
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)

    override val assets: Flow<List<AssetRecord>> = dao.observeAssets().map { rows ->
        rows.map { AssetRecord(it.id, it.assetCode, it.name, it.category, it.quantity, it.purchaseEpochDay, it.purchaseCostRial, it.salvageValueRial, it.accumulatedDepreciationRial, it.usefulLifeMonths, it.location, it.notes, it.status == "ACTIVE", it.isAccountingRecognized) }
    }
    override val depreciations: Flow<List<DepreciationRecord>> = dao.observeDepreciations().map { rows ->
        rows.map { DepreciationRecord(it.id, it.assetName, it.periodYear, it.periodMonth, it.amountRial) }
    }

    override suspend fun save(id: Long?, draft: AssetDraft): Long {
        authorizer.require("ASSETS")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            if (id == null) {
                val assetId = dao.insertAsset(FixedAssetEntity(assetCode = valid.assetCode, name = valid.name, category = valid.category, quantity = valid.quantity, purchaseEpochDay = valid.purchaseEpochDay, purchaseCostRial = valid.purchaseCostRial, salvageValueRial = valid.salvageValueRial, usefulLifeMonths = valid.usefulLifeMonths, location = valid.location, notes = valid.notes, createdAtEpochMillis = now, updatedAtEpochMillis = now))
                check(assetId > 0) { "ثبت دارایی انجام نشد." }
                postAcquisitionJournal(
                    asset = dao.assetById(assetId) ?: error("دارایی ثبت‌شده پیدا نشد."),
                    source = valid.acquisitionSource,
                    postingEpochDay = valid.purchaseEpochDay,
                    now = now,
                )
                syncRecorder?.record("ASSET", assetId, SyncChangeType.CREATE.name, now, valid.syncPayload())
                assetId
            } else {
                val current = dao.assetById(id) ?: error("دارایی پیدا نشد.")
                require(current.status == "ACTIVE") { "دارایی خارج‌شده قابل ویرایش نیست." }
                require(
                    current.assetCode == valid.assetCode &&
                        current.quantity == valid.quantity &&
                        current.purchaseEpochDay == valid.purchaseEpochDay &&
                        current.purchaseCostRial == valid.purchaseCostRial &&
                        current.salvageValueRial == valid.salvageValueRial &&
                        current.usefulLifeMonths == valid.usefulLifeMonths,
                ) {
                    "کد، تعداد، تاریخ و مبالغ مبنای دارایی پس از ثبت سند تحصیل قابل تغییر نیست؛ اصلاح مالی باید با سند اصلاحی انجام شود."
                }
                check(dao.updateAsset(current.copy(assetCode = valid.assetCode, name = valid.name, category = valid.category, quantity = valid.quantity, purchaseEpochDay = valid.purchaseEpochDay, purchaseCostRial = valid.purchaseCostRial, salvageValueRial = valid.salvageValueRial, usefulLifeMonths = valid.usefulLifeMonths, location = valid.location, notes = valid.notes, updatedAtEpochMillis = now)) == 1)
                syncRecorder?.record("ASSET", id, SyncChangeType.UPDATE.name, now, valid.syncPayload())
                id
            }
        }
    }

    override suspend fun recognizeLegacyAsset(id: Long): Long {
        authorizer.require("ASSETS")
        val now = clock()
        return database.withTransaction {
            val asset = dao.assetById(id) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "فقط دارایی فعال قابل تطبیق مالی است." }
            require(accounting.entryBySource("ASSET_ACQUISITION", asset.id) == null) {
                "سند تحصیل این دارایی قبلاً ثبت شده است."
            }
            postAcquisitionJournal(
                asset = asset,
                source = AssetAcquisitionSource.OWNER_CAPITAL,
                postingEpochDay = currentLocalEpochDay(),
                now = now,
                description = "ثبت مانده افتتاحیه دارایی قدیمی: ${asset.name}",
            ).also { entryId ->
                syncRecorder?.record(
                    "ASSET",
                    asset.id,
                    "RECOGNIZE_ACCOUNTING",
                    now,
                    mapOf("acquisitionSource" to AssetAcquisitionSource.OWNER_CAPITAL.name, "journalEntryId" to entryId.toString()),
                )
            }
        }
    }

    override suspend fun dispose(id: Long) {
        authorizer.require("ASSETS")
        val now = clock()
        database.withTransaction {
            val asset = dao.assetById(id) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "دارایی قبلاً از چرخه بهره‌برداری خارج شده است." }
            require(accounting.entryBySource("ASSET_ACQUISITION", asset.id) != null) {
                "دارایی قدیمی فاقد سند تحصیل است؛ ابتدا مانده افتتاحیه آن را در حسابداری تطبیق دهید."
            }
            val bookValue = SignedLongMath.subtract(asset.purchaseCostRial, asset.accumulatedDepreciationRial)
            require(bookValue >= 0) { "ارزش دفتری دارایی نامعتبر است." }
            val disposalLines = buildList {
                if (asset.accumulatedDepreciationRial > 0) add(SemanticJournalLine(SemanticAccountRole.ACCUMULATED_DEPRECIATION, debit = MoneyRial.of(asset.accumulatedDepreciationRial), memo = "بستن استهلاک انباشته"))
                if (bookValue > 0) add(SemanticJournalLine(SemanticAccountRole.ASSET_DISPOSAL_LOSS, debit = MoneyRial.of(bookValue), memo = "زیان خروج دارایی بدون عایدی"))
                add(SemanticJournalLine(SemanticAccountRole.FIXED_ASSET, credit = MoneyRial.of(asset.purchaseCostRial), memo = asset.assetCode))
            }
            val entryId = accountingPosting.post(
                SemanticJournalDraft(
                    entryNo = "خد-$id-$now",
                    entryEpochDay = currentLocalEpochDay(),
                    description = "خروج بدون عایدی دارایی ثابت: ${asset.name}",
                    sourceType = "ASSET_DISPOSAL",
                    sourceId = asset.id,
                    lines = disposalLines,
                ),
            )
            check(dao.disposeAsset(id, now) == 1) { "خروج دارایی انجام نشد." }
            syncRecorder?.record(
                "ASSET",
                id,
                SyncChangeType.DISPOSE.name,
                now,
                mapOf("bookValueRial" to bookValue.toString(), "disposalJournalEntryId" to entryId.toString()),
            )
        }
    }

    override suspend fun postDepreciation(draft: DepreciationDraft): Long {
        authorizer.require("ASSETS")
        val valid = draft.validated()
        return database.withTransaction {
            val asset = dao.assetById(valid.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "دارایی فعال نیست." }
            require(accounting.entryBySource("ASSET_ACQUISITION", asset.id) != null) {
                "برای این دارایی سند تحصیل ثبت نشده است؛ قبل از استهلاک، مانده افتتاحیه را تطبیق دهید."
            }
            require(!dao.depreciationExists(asset.id, valid.periodYear, valid.periodMonth)) { "استهلاک این دوره قبلاً ثبت شده است." }
            val depreciable = asset.purchaseCostRial - asset.salvageValueRial
            val monthly = depreciable / asset.usefulLifeMonths
            val remaining = depreciable - asset.accumulatedDepreciationRial
            val amount = minOf(monthly, remaining)
            require(amount > 0) { "دارایی کاملاً مستهلک شده است." }
            val now = clock()
            val entryId = accountingPosting.post(
                SemanticJournalDraft(
                    entryNo = "TMP-AST-$now", entryEpochDay = valid.postingEpochDay,
                    description = "استهلاک ${asset.name} ${valid.periodYear}/${valid.periodMonth}",
                    sourceType = "ASSET_DEPRECIATION", sourceId = 0,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.DEPRECIATION_EXPENSE, debit = MoneyRial.of(amount), memo = "هزینه استهلاک"),
                        SemanticJournalLine(SemanticAccountRole.ACCUMULATED_DEPRECIATION, credit = MoneyRial.of(amount), memo = "استهلاک انباشته"),
                    ),
                ),
            )
            check(dao.addDepreciation(asset.id, amount, now) == 1) { "ثبت استهلاک از ارزش مجاز بیشتر است." }
            val depreciationId = dao.insertDepreciation(AssetDepreciationEntity(assetId = asset.id, periodYear = valid.periodYear, periodMonth = valid.periodMonth, amountRial = amount, journalEntryId = entryId, createdAtEpochMillis = now))
            check(depreciationId > 0) { "ثبت سابقه استهلاک انجام نشد." }
            check(accounting.finalizeEntryIdentity(entryId, "د-$entryId", depreciationId) == 1) { "اتصال سند استهلاک انجام نشد." }
            syncRecorder?.record(
                "ASSET_DEPRECIATION",
                depreciationId,
                SyncChangeType.CREATE.name,
                now,
                mapOf(
                    "amountRial" to amount.toString(),
                    "assetId" to asset.id.toString(),
                    "journalEntryId" to entryId.toString(),
                    "periodMonth" to valid.periodMonth.toString(),
                    "periodYear" to valid.periodYear.toString(),
                ),
            )
            depreciationId
        }
    }

    private fun AssetDraft.syncPayload(): Map<String, String> = mapOf(
        "acquisitionSource" to acquisitionSource.name,
        "assetCode" to assetCode,
        "category" to category,
        "location" to location,
        "name" to name,
        "purchaseCostRial" to purchaseCostRial.toString(),
        "purchaseEpochDay" to purchaseEpochDay.toString(),
        "quantity" to quantity.toString(),
        "salvageValueRial" to salvageValueRial.toString(),
        "usefulLifeMonths" to usefulLifeMonths.toString(),
    )

    private suspend fun postAcquisitionJournal(
        asset: FixedAssetEntity,
        source: AssetAcquisitionSource,
        postingEpochDay: Long,
        now: Long,
        description: String = "تحصیل دارایی ثابت: ${asset.name}",
    ): Long {
        val sourceRole = when (source) {
            AssetAcquisitionSource.CASH -> SemanticAccountRole.CASH
            AssetAcquisitionSource.BANK -> SemanticAccountRole.BANK
            AssetAcquisitionSource.PAYABLE -> SemanticAccountRole.SUPPLIER_PAYABLE
            AssetAcquisitionSource.OWNER_CAPITAL -> SemanticAccountRole.OWNER_CAPITAL
        }
        return accountingPosting.post(
            SemanticJournalDraft(
                entryNo = "تد-${asset.id}",
                entryEpochDay = postingEpochDay,
                description = description,
                sourceType = "ASSET_ACQUISITION",
                sourceId = asset.id,
                lines = listOf(
                    SemanticJournalLine(SemanticAccountRole.FIXED_ASSET, debit = MoneyRial.of(asset.purchaseCostRial), memo = asset.assetCode),
                    SemanticJournalLine(sourceRole, credit = MoneyRial.of(asset.purchaseCostRial), memo = source.title),
                ),
            ),
        )
    }
}