package ir.sabou.inventory.ui

import ir.sabou.inventory.core.SafeErrorLog
import java.io.IOException
import kotlinx.coroutines.CancellationException

/** Centralizes UI-safe error reporting without writing business data into Logcat. */
object UiErrorHandler {
    fun message(tag: String, error: Throwable): String {
        if (error is CancellationException) throw error
        SafeErrorLog.record(tag, "operation_failure", error)
        return when (error) {
            is IllegalArgumentException, is IllegalStateException ->
                error.message?.takeIf { it.isNotBlank() } ?: "اطلاعات واردشده معتبر نیست."
            is IOException -> "دسترسی به فایل یا حافظه انجام نشد."
            else -> "خطای داخلی رخ داد. دوباره تلاش کنید."
        }
    }
}
