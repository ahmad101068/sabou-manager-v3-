package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.domain.accounting.SemanticAccountResolver
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SystemSemanticAccountResolver

/**
 * Accounting-owned journal construction boundary. Callers are expected to invoke this from their
 * existing Room transaction so cross-domain atomicity is preserved.
 */
class LocalAccountingPostingEngine(
    private val database: AppDatabase,
    private val resolver: SemanticAccountResolver = SystemSemanticAccountResolver,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    suspend fun post(draft: SemanticJournalDraft): Long {
        val dao = database.accountingDao()
        val resolved = draft.lines.map { line ->
            val code = resolver.codeFor(line.role)
            val account = dao.accountByCode(code)
                ?: error("حساب سیستمی نقش ${line.role.name} پیدا نشد.")
            require(account.isActive) { "حساب سیستمی نقش ${line.role.name} غیرفعال است." }
            JournalLineEntity(
                entryId = 0,
                accountCode = code,
                debitRial = line.debit.value,
                creditRial = line.credit.value,
                memo = line.memo,
            )
        }
        val entryId = dao.insertEntry(
            JournalEntryEntity(
                entryNo = draft.entryNo,
                entryEpochDay = draft.entryEpochDay,
                description = draft.description,
                sourceType = draft.sourceType,
                sourceId = draft.sourceId,
                status = draft.status,
                createdAtEpochMillis = clock(),
            ),
        )
        dao.insertLines(resolved.map { it.copy(entryId = entryId) })
        return entryId
    }
}
