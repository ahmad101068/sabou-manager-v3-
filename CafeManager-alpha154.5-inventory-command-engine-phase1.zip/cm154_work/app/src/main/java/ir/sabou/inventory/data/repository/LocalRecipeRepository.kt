package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AuditLogEntity
import ir.sabou.inventory.data.db.MenuItemEntity
import ir.sabou.inventory.data.db.RecipeVersionEntity
import ir.sabou.inventory.data.db.RecipeVersionIngredientEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeCostProfile
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.recipe.RecipeIngredientItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.recipe.RecipeRevision
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalRecipeRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
    private val epochDay: () -> Long = ::currentLocalEpochDay,
) : RecipeRepository {
    override suspend fun saveMenuItem(
        id: Long?,
        name: String,
        category: String,
        salePriceRial: Long,
        ingredients: List<RecipeIngredientInput>,
        costProfile: RecipeCostProfile,
    ): Long {
        authorizer.require("RECIPES")
        val normalized = name.trim()
        require(normalized.isNotEmpty()) { "نام محصول الزامی است." }
        require(salePriceRial >= 0) { "قیمت فروش نامعتبر است." }
        require(ingredients.isNotEmpty()) { "رسپی باید حداقل یک ماده اولیه داشته باشد." }
        require(ingredients.all { it.quantityMicrosPerUnit > 0 }) { "مقدار مصرف مواد باید بیشتر از صفر باشد." }
        require(ingredients.map { it.inventoryItemId }.distinct().size == ingredients.size) { "ماده اولیه تکراری است." }
        val validatedCostProfile = costProfile.validated()

        val now = clock()
        val effectiveFrom = epochDay()
        return database.withTransaction {
            ingredients.forEach {
                require(database.inventoryDao().activeById(it.inventoryItemId) != null) {
                    "ماده اولیه فعال پیدا نشد."
                }
            }
            val menuId = if (id == null) {
                database.recipeDao().insertMenuItem(
                    MenuItemEntity(
                        name = normalized,
                        category = category.trim(),
                        salePriceRial = salePriceRial,
                        createdAtEpochMillis = now,
                        updatedAtEpochMillis = now,
                    ),
                )
            } else {
                val old = database.recipeDao().activeMenuItem(id) ?: error("محصول منو پیدا نشد.")
                check(
                    database.recipeDao().updateMenuItem(
                        old.copy(
                            name = normalized,
                            category = category.trim(),
                            salePriceRial = salePriceRial,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                )
                id
            }

            val revisionNo = database.recipeDao().nextRevisionNo(menuId)
            val actor = authorizer.actor()
            val versionId = database.recipeDao().insertVersion(
                RecipeVersionEntity(
                    menuItemId = menuId,
                    revisionNo = revisionNo,
                    effectiveFromEpochDay = effectiveFrom,
                    yieldMicros = validatedCostProfile.yieldMicros,
                    portionWeightMicros = validatedCostProfile.portionWeightMicros,
                    preparationWasteBasisPoints = validatedCostProfile.preparationWasteBasisPoints,
                    cookingWasteBasisPoints = validatedCostProfile.cookingWasteBasisPoints,
                    packagingCostRial = validatedCostProfile.packagingCostRial,
                    directLaborCostRial = validatedCostProfile.directLaborCostRial,
                    allocatedOverheadRial = validatedCostProfile.allocatedOverheadRial,
                    note = validatedCostProfile.note,
                    createdBy = actor,
                    createdAtEpochMillis = now,
                ),
            )
            database.recipeDao().insertVersionIngredients(
                ingredients.map {
                    RecipeVersionIngredientEntity(
                        recipeVersionId = versionId,
                        inventoryItemId = it.inventoryItemId,
                        quantityMicrosPerUnit = it.quantityMicrosPerUnit,
                    )
                },
            )
            database.auditLogDao().insert(
                AuditLogEntity(
                    action = if (revisionNo == 1) "CREATE" else "REVISE",
                    entityType = "RECIPE_VERSION",
                    entityId = versionId,
                    description = "رسپی $normalized؛ نسخه $revisionNo؛ تاریخ اثر $effectiveFrom؛ ${ingredients.size} ماده اولیه؛ پروفایل بهای کامل ثبت شد",
                    actor = actor,
                    createdAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("MENU_ITEM", menuId, if (id == null) "CREATE" else "UPDATE", now)
            syncRecorder?.record("RECIPE_VERSION", versionId, "CREATE", now, recordAudit = false)
            menuId
        }
    }

    override fun observeMenuItems(): Flow<List<MenuItem>> {
        val today = epochDay()
        return database.recipeDao().observeActiveMenuItemsWithCoverage(today).map { rows ->
            rows.map {
                MenuItem(
                    id = it.id,
                    name = it.name,
                    category = it.category,
                    salePriceRial = it.salePriceRial,
                    ingredientCount = it.ingredientCount,
                    recipeRevisionNo = it.revisionNo,
                    recipeEffectiveFromEpochDay = it.effectiveFromEpochDay,
                    costProfile = RecipeCostProfile(
                        yieldMicros = it.yieldMicros,
                        portionWeightMicros = it.portionWeightMicros,
                        preparationWasteBasisPoints = it.preparationWasteBasisPoints,
                        cookingWasteBasisPoints = it.cookingWasteBasisPoints,
                        packagingCostRial = it.packagingCostRial,
                        directLaborCostRial = it.directLaborCostRial,
                        allocatedOverheadRial = it.allocatedOverheadRial,
                        note = it.note,
                    ),
                )
            }
        }
    }

    override fun observeIngredients(menuItemId: Long): Flow<List<RecipeIngredientItem>> {
        val today = epochDay()
        return database.recipeDao().observeIngredientRows(menuItemId, today).map { rows ->
            rows.map {
                RecipeIngredientItem(
                    inventoryItemId = it.inventoryItemId,
                    inventoryName = it.inventoryName,
                    unit = it.unit,
                    quantityMicrosPerUnit = it.quantityMicrosPerUnit,
                )
            }
        }
    }

    override fun observeRevisions(menuItemId: Long): Flow<List<RecipeRevision>> =
        database.recipeDao().observeVersions(menuItemId).map { versions ->
            versions.map { version ->
                RecipeRevision(
                    id = version.id,
                    revisionNo = version.revisionNo,
                    effectiveFromEpochDay = version.effectiveFromEpochDay,
                    costProfile = RecipeCostProfile(
                        version.yieldMicros,
                        version.portionWeightMicros,
                        version.preparationWasteBasisPoints,
                        version.cookingWasteBasisPoints,
                        version.packagingCostRial,
                        version.directLaborCostRial,
                        version.allocatedOverheadRial,
                        version.note,
                    ),
                    createdBy = version.createdBy,
                    createdAtEpochMillis = version.createdAtEpochMillis,
                )
            }
        }
}
