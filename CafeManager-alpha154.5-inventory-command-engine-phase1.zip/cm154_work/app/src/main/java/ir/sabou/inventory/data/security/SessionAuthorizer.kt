package ir.sabou.inventory.data.security

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.domain.operations.UserRole

class AuthenticationRequiredException : IllegalStateException("برای انجام این عملیات ابتدا وارد حساب کاربری شوید.")

class AccessDeniedException(permission: String) :
    IllegalStateException("کاربر جاری مجوز $permission را ندارد.")

/** Enforces authorization at the data-command boundary. UI filtering is not a security boundary. */
class SessionAuthorizer(private val database: AppDatabase) {
    suspend fun actor(): String = database.securityDao().currentUser()?.let { it.displayName.ifBlank { it.username } } ?: "SYSTEM"
    suspend fun require(permission: String) {
        val user = database.securityDao().currentUser() ?: throw AuthenticationRequiredException()
        if (!user.isActive) throw AuthenticationRequiredException()
        val role = runCatching { UserRole.valueOf(user.role) }.getOrDefault(UserRole.CASHIER)
        if (!role.allows(permission)) throw AccessDeniedException(permission)
    }

    suspend fun requireOwner() {
        val user = database.securityDao().currentUser() ?: throw AuthenticationRequiredException()
        if (!user.isActive) throw AuthenticationRequiredException()
        if (runCatching { UserRole.valueOf(user.role) }.getOrNull() != UserRole.OWNER) {
            throw AccessDeniedException("بازگشایی کنترل‌شده (فقط مالک)")
        }
    }

    internal suspend fun currentUserId(): Long {
        val user = database.securityDao().currentUser() ?: throw AuthenticationRequiredException()
        if (!user.isActive) throw AuthenticationRequiredException()
        return user.id
    }
}
