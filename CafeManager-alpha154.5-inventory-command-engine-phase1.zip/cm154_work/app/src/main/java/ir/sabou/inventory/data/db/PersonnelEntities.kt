package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo

@Entity(
    tableName = "employees",
    indices = [
        Index(value = ["nationalId"], unique = true),
        Index(value = ["employeeCode"], unique = true),
        Index("branchName"),
        Index("status"),
    ],
)
data class EmployeeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    @ColumnInfo(defaultValue = "''") val fatherName: String = "",
    val employeeCode: String? = null,
    val jobTitle: String,
    val branchName: String = "",
    val phone: String = "",
    val nationalId: String? = null,
    val birthEpochDay: Long? = null,
    val hireEpochDay: Long? = null,
    val insuranceNumber: String? = null,
    val bankCard: String? = null,
    val address: String = "",
    val emergencyContact: String = "",
    val monthlySalaryRial: Long,
    val leaveBalanceMicros: Long,
    val status: String = "ACTIVE",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "attendance",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["employeeId", "workEpochDay"], unique = true),
        Index("workEpochDay"),
    ],
)
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val workEpochDay: Long,
    val status: String,
    val checkInMinute: Int?,
    val checkOutMinute: Int?,
    val lateMinutes: Int,
    val overtimeMinutes: Int,
    val notes: String,
)

@Entity(
    tableName = "leaves",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("employeeId"), Index("startEpochDay"), Index("endEpochDay"), Index("status")],
)
data class LeaveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val daysMicros: Long,
    val leaveType: String,
    val status: String,
    val notes: String,
    val requestedBy: String = "SYSTEM",
    val reviewedBy: String? = null,
    val reviewNotes: String = "",
    val reviewedAtEpochMillis: Long? = null,
    val cancelledAtEpochMillis: Long? = null,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)


@Entity(
    tableName = "payroll_policies",
    indices = [Index("effectiveFromEpochDay"), Index("effectiveToEpochDay")],
)
data class PayrollPolicyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val effectiveFromEpochDay: Long,
    val effectiveToEpochDay: Long?,
    val overtimeHourlyRateRial: Long,
    val absenceDailyDeductionRial: Long,
    val lateMinuteDeductionRial: Long,
    val createdBy: String,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "payroll_runs",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["employeeId", "periodYear", "periodMonth", "revisionNo"], unique = true),
        Index("paymentEpochDay"),
        Index("journalEntryId"),
        Index("payrollPolicyId"),
    ],
)
data class PayrollRunEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val periodYear: Int,
    val periodMonth: Int,
    @ColumnInfo(defaultValue = "1") val revisionNo: Int = 1,
    val baseSalaryRial: Long,
    val overtimeRial: Long,
    val bonusRial: Long,
    val deductionsRial: Long,
    @ColumnInfo(defaultValue = "0") val advanceDeductionRial: Long = 0,
    @ColumnInfo(defaultValue = "0") val periodStartEpochDay: Long = 0,
    @ColumnInfo(defaultValue = "0") val periodEndEpochDay: Long = 0,
    val payrollPolicyId: Long? = null,
    @ColumnInfo(defaultValue = "0") val automaticOvertimeRial: Long = 0,
    @ColumnInfo(defaultValue = "0") val attendanceDeductionRial: Long = 0,
    val insuranceRial: Long,
    val taxRial: Long,
    val netPayRial: Long,
    val paymentEpochDay: Long,
    val paymentMethod: String,
    val journalEntryId: Long,
    val status: String = "PAID",
    val approvedBy: String? = null,
    val approvedAtEpochMillis: Long? = null,
    val reversalEpochDay: Long? = null,
    @ColumnInfo(defaultValue = "''") val reversalReason: String = "",
    val reversalJournalEntryId: Long? = null,
    val reversedBy: String? = null,
    val notes: String = "",
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "payroll_advance_allocations",
    primaryKeys = ["payrollId", "advanceId"],
    foreignKeys = [
        ForeignKey(entity = PayrollRunEntity::class, parentColumns = ["id"], childColumns = ["payrollId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = EmployeeAdvanceEntity::class, parentColumns = ["id"], childColumns = ["advanceId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("advanceId")],
)
data class PayrollAdvanceAllocationEntity(
    val payrollId: Long,
    val advanceId: Long,
    val amountRial: Long,
    val createdAtEpochMillis: Long,
)


@Entity(
    tableName = "employee_contracts",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("employeeId"),
        Index("startEpochDay"),
        Index("endEpochDay"),
        Index("status"),
    ],
)
data class EmployeeContractEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val contractType: String,
    val startEpochDay: Long,
    val endEpochDay: Long?,
    val baseSalaryRial: Long,
    val dailyWorkMinutes: Int,
    val weeklyWorkDays: Int,
    val status: String = "ACTIVE",
    val notes: String = "",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "employee_advances",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("employeeId"),
        Index("advanceEpochDay"),
        Index("journalEntryId"),
        Index("status"),
    ],
)
data class EmployeeAdvanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val amountRial: Long,
    val advanceEpochDay: Long,
    val paymentMethod: String,
    val journalEntryId: Long,
    val settledAmountRial: Long = 0,
    val status: String = "OPEN",
    val notes: String = "",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "performance_goals",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("employeeId"),
        Index("periodStartEpochDay"),
        Index("periodEndEpochDay"),
        Index("status"),
    ],
)
data class PerformanceGoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val title: String,
    val description: String = "",
    val weightPercent: Int,
    val targetValue: Double?,
    val unit: String = "",
    val periodStartEpochDay: Long,
    val periodEndEpochDay: Long,
    val status: String = "ACTIVE",
    val createdBy: String = "SYSTEM",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "performance_reviews",
    foreignKeys = [
        ForeignKey(
            entity = EmployeeEntity::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index("employeeId"),
        Index("periodStartEpochDay"),
        Index("periodEndEpochDay"),
        Index("status"),
    ],
)
data class PerformanceReviewEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: Long,
    val periodStartEpochDay: Long,
    val periodEndEpochDay: Long,
    val reviewerName: String,
    val finalScoreBasisPoints: Int = 0,
    val status: String = "DRAFT",
    val managerComment: String = "",
    val employeeComment: String = "",
    val submittedAtEpochMillis: Long? = null,
    val completedAtEpochMillis: Long? = null,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "performance_scores",
    foreignKeys = [
        ForeignKey(
            entity = PerformanceReviewEntity::class,
            parentColumns = ["id"],
            childColumns = ["reviewId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = PerformanceGoalEntity::class,
            parentColumns = ["id"],
            childColumns = ["goalId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [
        Index(value = ["reviewId", "goalId"], unique = true),
        Index("goalId"),
    ],
)
data class PerformanceScoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reviewId: Long,
    val goalId: Long,
    val achievedValue: Double?,
    val scoreBasisPoints: Int,
    val weightedScoreBasisPoints: Int,
    val notes: String = "",
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)
