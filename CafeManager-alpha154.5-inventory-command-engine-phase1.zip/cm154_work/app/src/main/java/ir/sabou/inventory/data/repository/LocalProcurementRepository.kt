package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.core.currentLocalEpochDay
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.GoodsReceiptEntity
import ir.sabou.inventory.data.db.GoodsReceiptLineEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryReplenishmentPolicyEntity
import ir.sabou.inventory.data.db.ProcurementDemandUsageRow
import ir.sabou.inventory.data.db.ProcurementLatestCostRow
import ir.sabou.inventory.data.db.ProcurementInvoiceLinkEntity
import ir.sabou.inventory.data.db.PurchaseEntity
import ir.sabou.inventory.data.db.PurchaseLineEntity
import ir.sabou.inventory.data.db.PurchaseOrderEntity
import ir.sabou.inventory.data.db.PurchaseOrderLineEntity
import ir.sabou.inventory.data.db.PurchaseReturnEntity
import ir.sabou.inventory.data.db.PurchaseReturnLineEntity
import ir.sabou.inventory.data.db.PurchaseRequisitionEntity
import ir.sabou.inventory.data.db.PurchaseRequisitionLineEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.db.SupplierCreditEntity
import ir.sabou.inventory.data.db.SupplierCreditRow
import ir.sabou.inventory.data.db.SupplierItemOfferEntity
import ir.sabou.inventory.data.db.SupplierItemOfferRow
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.purchase.GoodsReceiptDraft
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.ProcurementOverview
import ir.sabou.inventory.domain.purchase.ProcurementRepository
import ir.sabou.inventory.domain.purchase.PurchaseCalculator
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderLineRecord
import ir.sabou.inventory.domain.purchase.PurchaseOrderRecord
import ir.sabou.inventory.domain.purchase.PurchaseOrderStatus
import ir.sabou.inventory.domain.purchase.PurchaseOrderDispatchChannel
import ir.sabou.inventory.domain.purchase.PurchaseOrderAcknowledgementDraft
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod
import ir.sabou.inventory.domain.purchase.PurchaseReturnDraft
import ir.sabou.inventory.domain.purchase.PurchaseRequisitionDraft
import ir.sabou.inventory.domain.purchase.RequisitionRecord
import ir.sabou.inventory.domain.purchase.RequisitionStatus
import ir.sabou.inventory.domain.purchase.RequisitionLineDraft
import ir.sabou.inventory.domain.purchase.ReplenishmentInput
import ir.sabou.inventory.domain.purchase.ReplenishmentPlanner
import ir.sabou.inventory.domain.purchase.ReplenishmentPolicyDraft
import ir.sabou.inventory.domain.purchase.ReplenishmentPolicyRecord
import ir.sabou.inventory.domain.purchase.ThreeWayMatchResult
import ir.sabou.inventory.domain.purchase.ThreeWayMatchStatus
import ir.sabou.inventory.domain.purchase.SupplierCreditRecord
import ir.sabou.inventory.domain.purchase.SupplierOfferCandidate
import ir.sabou.inventory.domain.purchase.SupplierOfferDraft
import ir.sabou.inventory.domain.purchase.SupplierOfferRecord
import ir.sabou.inventory.domain.purchase.SupplierSourcingAdvisor
import ir.sabou.inventory.domain.purchase.SplitPurchaseOrdersDraft
import ir.sabou.inventory.domain.purchase.SplitPurchaseOrdersResult
import ir.sabou.inventory.domain.purchase.SupplierAssignedRequisitionLine
import ir.sabou.inventory.domain.purchase.SupplierOrderSplitter
import ir.sabou.inventory.domain.purchase.SupplierScorecard
import java.math.BigInteger
import java.util.UUID
import kotlin.math.abs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

private data class SupplierSignals(
    val receipts: List<GoodsReceiptEntity>,
    val receiptLines: List<GoodsReceiptLineEntity>,
    val returns: List<PurchaseReturnEntity>,
    val returnLines: List<PurchaseReturnLineEntity>,
    val invoiceLinks: List<ProcurementInvoiceLinkEntity>,
    val credits: List<SupplierCreditRow>,
)

private data class PreparedPurchaseReturnLine(
    val orderLine: PurchaseOrderLineEntity,
    val quantityMicros: Long,
    val inventoryUnitCostRial: Long,
    val supplierUnitCreditRial: Long,
    val inventoryValue: MoneyRial,
    val supplierCreditValue: MoneyRial,
    val reason: String,
)

private data class ReplenishmentSignals(
    val policies: List<InventoryReplenishmentPolicyEntity>,
    val inventory: List<InventoryItemEntity>,
    val usage: List<ProcurementDemandUsageRow>,
    val latestCosts: List<ProcurementLatestCostRow>,
    val offers: List<SupplierItemOfferRow>,
    val activeRequestedItemIds: Set<Long>,
)

private data class ProcurementCatalogSignals(
    val latestCosts: List<ProcurementLatestCostRow>,
    val offers: List<SupplierItemOfferRow>,
)

private fun toSupplierOfferRecord(row: SupplierItemOfferRow) = SupplierOfferRecord(
    id = row.id,
    supplierId = row.supplierId,
    supplierName = row.supplierName,
    itemId = row.itemId,
    itemName = row.itemName,
    supplierSku = row.supplierSku,
    unitCostRial = row.unitCostRial,
    minimumOrderMicros = row.minimumOrderMicros,
    orderMultipleMicros = row.orderMultipleMicros,
    leadTimeDays = row.leadTimeDays,
    validUntilEpochDay = row.validUntilEpochDay,
    isActive = row.isActive,
)

class LocalProcurementRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val todayEpochDay: () -> Long = ::currentLocalEpochDay,
) : ProcurementRepository {
    private val inventoryCommands = LocalInventoryCommandEngine(database, clock = clock)
    private val baseOverview: Flow<ProcurementOverview> = combine(
        database.procurementDao().observeRequisitions(),
        database.procurementDao().observeRequisitionLines(),
        database.procurementDao().observeOrders(),
        database.procurementDao().observeOrderLines(),
    ) { requisitions, requisitionLines, orders, lines ->
        ProcurementOverview(
            requisitions = requisitions.map {
                RequisitionRecord(
                    id = it.id,
                    requestNo = it.requestNo,
                    department = it.department,
                    requiredEpochDay = it.requiredEpochDay,
                    status = RequisitionStatus.valueOf(it.status),
                    requestedBy = it.requestedBy,
                    approvedBy = it.approvedBy,
                    estimatedTotalRial = MoneyRial.sum(
                        requisitionLines.filter { line -> line.requisitionId == it.id }.map { line ->
                            MoneyRial.of(line.estimatedUnitCostRial).times(QuantityMicros.of(line.requestedQtyMicros))
                        },
                    ).value,
                    lineCount = it.lineCount,
                    supplierGroupCount = requisitionLines.filter { line -> line.requisitionId == it.id }.mapNotNull { line -> line.recommendedSupplierId }.distinct().size,
                    unassignedLineCount = requisitionLines.count { line -> line.requisitionId == it.id && line.recommendedSupplierId == null },
                    requiredApprovalLevel = it.requiredApprovalLevel,
                    completedApprovalLevel = it.completedApprovalLevel,
                    firstApprovedBy = it.firstApprovedBy,
                    secondApprovedBy = it.secondApprovedBy,
                    committedBudgetId = it.committedBudgetId,
                    committedBudgetRial = it.committedBudgetRial,
                )
            },
            orders = orders.map { order ->
                PurchaseOrderRecord(
                    id = order.id,
                    orderNo = order.orderNo,
                    supplierId = order.supplierId,
                    supplierName = order.supplierName,
                    requisitionId = order.requisitionId,
                    orderEpochDay = order.orderEpochDay,
                    expectedEpochDay = order.expectedEpochDay,
                    sentAtEpochMillis = order.sentAtEpochMillis,
                    sentBy = order.sentBy,
                    dispatchChannel = order.dispatchChannel?.let { PurchaseOrderDispatchChannel.valueOf(it) },
                    acknowledgedAtEpochMillis = order.acknowledgedAtEpochMillis,
                    supplierConfirmationNo = order.supplierConfirmationNo,
                    confirmedExpectedEpochDay = order.confirmedExpectedEpochDay,
                    status = PurchaseOrderStatus.valueOf(order.status),
                    orderedValueRial = MoneyRial.sum(
                        lines.filter { it.purchaseOrderId == order.id }.map {
                            MoneyRial.of(it.unitCostRial).times(QuantityMicros.of(it.orderedQtyMicros))
                        },
                    ).value,
                    acceptedValueRial = MoneyRial.sum(
                        lines.filter { it.purchaseOrderId == order.id }.map {
                            MoneyRial.of(it.unitCostRial).times(QuantityMicros.of(it.receivedQtyMicros - it.returnedQtyMicros))
                        },
                    ).value,
                    receiptCount = order.receiptCount,
                    invoiceNo = order.invoiceNo,
                    lines = lines.filter { it.purchaseOrderId == order.id }.map {
                        PurchaseOrderLineRecord(
                            id = it.id,
                            itemId = it.itemId,
                            itemName = it.itemNameSnapshot,
                            supplierSku = it.supplierSkuSnapshot,
                            orderedQtyMicros = it.orderedQtyMicros,
                            receivedQtyMicros = it.receivedQtyMicros,
                            rejectedQtyMicros = it.rejectedQtyMicros,
                            returnedQtyMicros = it.returnedQtyMicros,
                            unitCostRial = it.unitCostRial,
                        )
                    },
                )
            },
        )
    }

    private val financialSignals = combine(
        database.procurementDao().observeInvoiceLinks(),
        database.procurementDao().observeSupplierCredits(),
    ) { links, credits -> links to credits }

    private val supplierSignals = combine(
        database.procurementDao().observeGoodsReceipts(),
        database.procurementDao().observeGoodsReceiptLines(),
        database.procurementDao().observePurchaseReturns(),
        database.procurementDao().observePurchaseReturnLines(),
        financialSignals,
    ) { receipts, receiptLines, returns, returnLines, financial ->
        SupplierSignals(receipts, receiptLines, returns, returnLines, financial.first, financial.second)
    }

    private val performanceOverview: Flow<ProcurementOverview> = combine(baseOverview, supplierSignals) { base, signals ->
        base.copy(
            supplierScorecards = buildSupplierScorecards(base.orders, signals),
            supplierCredits = signals.credits.map {
                SupplierCreditRecord(
                    id = it.id,
                    creditNo = it.creditNo,
                    supplierId = it.supplierId,
                    supplierName = it.supplierName,
                    amountRial = it.amountRial,
                    appliedRial = it.appliedRial,
                    status = it.status,
                    createdAtEpochMillis = it.createdAtEpochMillis,
                )
            },
        )
    }

    private val catalogSignals = combine(
        database.procurementDao().observeLatestPurchaseCosts(),
        database.procurementDao().observeSupplierItemOffers(),
    ) { costs, offers -> ProcurementCatalogSignals(costs, offers) }

    private val replenishmentSignals = combine(
        database.procurementDao().observeReplenishmentPolicies(),
        database.inventoryDao().observeActive(),
        database.procurementDao().observeDemandUsage(todayEpochDay() - 29),
        catalogSignals,
        database.procurementDao().observeActiveRequestedItemIds(),
    ) { policies, inventory, usage, catalog, requested ->
        ReplenishmentSignals(policies, inventory, usage, catalog.latestCosts, catalog.offers, requested.toSet())
    }

    override val overview: Flow<ProcurementOverview> = combine(performanceOverview, replenishmentSignals) { base, signals ->
        val policies = signals.policies.map {
            ReplenishmentPolicyRecord(
                itemId = it.itemId,
                preferredSupplierId = it.preferredSupplierId,
                targetCoverDays = it.targetCoverDays,
                leadTimeDays = it.leadTimeDays,
                safetyStockMicros = it.safetyStockMicros,
                orderMultipleMicros = it.orderMultipleMicros,
                isEnabled = it.isEnabled,
            )
        }
        val usageByItem = signals.usage.associateBy { it.itemId }
        val latestCostByItem = signals.latestCosts.associateBy { it.itemId }
        val offerRecords = signals.offers.map(::toSupplierOfferRecord)
        val policyByItem = policies.associateBy { it.itemId }
        val suggestions = signals.inventory.mapNotNull { item ->
            val policy = policyByItem[item.id] ?: return@mapNotNull null
            val openOrderQty = safeSum(
                base.orders.filter { it.status in setOf(PurchaseOrderStatus.OPEN, PurchaseOrderStatus.PARTIALLY_RECEIVED) }
                    .flatMap { it.lines }
                    .filter { it.itemId == item.id }
                    .map { it.remainingQtyMicros },
            )
            val latestCost = latestCostByItem[item.id]?.unitCostRial
                ?: base.orders.asSequence().flatMap { it.lines.asSequence() }
                    .firstOrNull { it.itemId == item.id }?.unitCostRial
                ?: 0
            val suggestion = ReplenishmentPlanner.suggest(
                ReplenishmentInput(
                    itemId = item.id,
                    itemName = item.name,
                    currentStockMicros = item.stockMicros,
                    openPurchaseOrderMicros = openOrderQty,
                    usage30DaysMicros = usageByItem[item.id]?.usageMicros ?: 0,
                    estimatedUnitCostRial = latestCost,
                    policy = policy,
                    hasPendingRequest = item.id in signals.activeRequestedItemIds,
                    preferredSupplierScore = policy.preferredSupplierId?.let { supplierId ->
                        base.supplierScorecards.firstOrNull { it.supplierId == supplierId }?.score
                    },
                ),
            ) ?: return@mapNotNull null
            val sourcing = SupplierSourcingAdvisor.choose(
                candidates = offerRecords.filter { it.itemId == item.id && it.isActive && (it.validUntilEpochDay == null || it.validUntilEpochDay >= todayEpochDay()) }.map { offer ->
                    SupplierOfferCandidate(offer, base.supplierScorecards.firstOrNull { it.supplierId == offer.supplierId }?.score)
                },
                requiredQuantityMicros = suggestion.suggestedOrderMicros,
                baselineUnitCostRial = suggestion.estimatedUnitCostRial,
                preferredSupplierId = policy.preferredSupplierId,
            )
            if (sourcing == null) suggestion else suggestion.copy(
                suggestedOrderMicros = sourcing.orderQuantityMicros,
                estimatedUnitCostRial = sourcing.offer.unitCostRial,
                estimatedOrderValueRial = sourcing.orderValueRial,
                recommendedSupplierId = sourcing.offer.supplierId,
                recommendedSupplierName = sourcing.offer.supplierName,
                recommendedSupplierSku = sourcing.offer.supplierSku,
                comparedOfferCount = sourcing.comparedOfferCount,
                recommendedLeadTimeDays = sourcing.offer.leadTimeDays,
                offerValidUntilEpochDay = sourcing.offer.validUntilEpochDay,
                estimatedSavingsRial = sourcing.estimatedSavingsRial,
            )
        }.sortedWith(
            compareBy<ir.sabou.inventory.domain.purchase.ReplenishmentSuggestion> { it.risk.ordinal }
                .thenByDescending { it.estimatedOrderValueRial },
        )
        base.copy(replenishmentPolicies = policies, replenishmentSuggestions = suggestions, supplierOffers = offerRecords)
    }

    override suspend fun submitRequisition(draft: PurchaseRequisitionDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        val actor = authorizer.actor()
        return database.withTransaction {
            val id = database.procurementDao().insertRequisition(
                PurchaseRequisitionEntity(
                    requestNo = "PR-${now}-${UUID.randomUUID().toString().take(4)}",
                    department = valid.department,
                    requiredEpochDay = valid.requiredEpochDay,
                    status = RequisitionStatus.SUBMITTED.name,
                    requestedBy = actor,
                    approvedBy = null,
                    note = valid.note,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            database.procurementDao().insertRequisitionLines(valid.lines.map { line ->
                val item = database.inventoryDao().activeById(line.itemId)
                    ?: error("یکی از کالاهای درخواست فعال نیست.")
                PurchaseRequisitionLineEntity(
                    requisitionId = id,
                    itemId = item.id,
                    itemNameSnapshot = item.name,
                    requestedQtyMicros = line.quantityMicros,
                    estimatedUnitCostRial = line.estimatedUnitCostRial,
                    recommendedSupplierId = line.recommendedSupplierId,
                    supplierSkuSnapshot = line.supplierSku,
                    recommendedLeadTimeDays = line.recommendedLeadTimeDays,
                    note = line.note,
                )
            })
            syncRecorder?.record("PURCHASE_REQUISITION", id, "SUBMIT", now)
            id
        }
    }

    override suspend fun reviewRequisition(requisitionId: Long, approve: Boolean, note: String) {
        authorizer.require("AUDIT")
        require(note.trim().length <= 300) { "توضیحات بررسی بیش از حد طولانی است." }
        val now = clock()
        val actor = authorizer.actor()
        database.withTransaction {
            val current = database.procurementDao().requisitionById(requisitionId)
                ?: error("درخواست خرید پیدا نشد.")
            require(current.status in setOf(RequisitionStatus.SUBMITTED.name, RequisitionStatus.PENDING_SECOND_APPROVAL.name)) { "درخواست قبلاً بررسی شده است." }
            val lines = database.procurementDao().requisitionLines(current.id)
            val total = lines.fold(0L) { sum, line ->
                SignedLongMath.add(sum, MoneyRial.of(line.estimatedUnitCostRial).times(QuantityMicros.of(line.requestedQtyMicros)).value)
            }
            val requiredLevel = ir.sabou.inventory.domain.purchase.PurchaseApprovalPolicy.plan(total).requiredLevel
            if (!approve) {
                check(database.procurementDao().recordRequisitionApproval(current.id, current.status, RequisitionStatus.REJECTED.name, requiredLevel, current.completedApprovalLevel, actor, note.trim().ifBlank { current.note }, now) == 1)
                syncRecorder?.record("PURCHASE_REQUISITION", current.id, "REJECT", now)
                return@withTransaction
            }
            val nextLevel = current.completedApprovalLevel + 1
            if (nextLevel == 2) authorizer.requireOwner()
            require(nextLevel <= requiredLevel) { "سطح تأیید این درخواست کامل شده است." }
            val finalApproval = nextLevel == requiredLevel
            val newStatus = if (finalApproval) RequisitionStatus.APPROVED.name else RequisitionStatus.PENDING_SECOND_APPROVAL.name
            check(database.procurementDao().recordRequisitionApproval(current.id, current.status, newStatus, requiredLevel, nextLevel, actor, note.trim().ifBlank { current.note }, now) == 1) { "درخواست هم‌زمان تغییر کرده است." }
            if (finalApproval && total > 0) {
                val budget = database.managementControlDao().activePurchaseBudget(current.requiredEpochDay, current.department)
                    ?: error("برای این تاریخ و مرکز هزینه، بودجه خرید فعال تعریف نشده است.")
                val committed = database.managementControlDao().committedAmount(budget.id)
                val actual = database.managementControlDao().actualBudgetSpend(budget.id)
                require(SignedLongMath.add(SignedLongMath.add(actual, committed), total) <= budget.limitRial) { "بودجه قابل‌تعهد با احتساب مصرف واقعی کافی نیست." }
                database.managementControlDao().insertBudgetCommitment(ir.sabou.inventory.data.db.BudgetCommitmentEntity(budgetId=budget.id,referenceType="PURCHASE_REQUISITION",referenceId=current.id,amountRial=total,actor=actor,createdAtEpochMillis=now,updatedAtEpochMillis=now))
                check(database.procurementDao().linkRequisitionBudget(current.id, budget.id, total) == 1)
            }
            syncRecorder?.record("PURCHASE_REQUISITION", current.id, if (finalApproval) "FINAL_APPROVE" else "LEVEL1_APPROVE", now)
        }
    }

    override suspend fun createOrder(draft: PurchaseOrderDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        val actor = authorizer.actor()
        return database.withTransaction {
            val request = database.procurementDao().requisitionById(valid.requisitionId)
                ?: error("درخواست خرید پیدا نشد.")
            require(request.status == RequisitionStatus.APPROVED.name) { "فقط درخواست تأییدشده قابل تبدیل به سفارش است." }
            val supplier = database.supplierDao().activeById(valid.supplierId)
                ?: error("تأمین‌کننده فعال پیدا نشد.")
            val requestLines = database.procurementDao().requisitionLines(request.id)
            require(requestLines.isNotEmpty()) { "ردیف‌های درخواست پیدا نشدند." }
            val assignedSuppliers = requestLines.mapNotNull { it.recommendedSupplierId }.distinct()
            require(assignedSuppliers.isEmpty() || (assignedSuppliers.size == 1 && assignedSuppliers.single() == supplier.id && requestLines.none { it.recommendedSupplierId == null })) {
                "این درخواست برای چند تأمین‌کننده تخصیص یافته است؛ از ساخت سفارش‌های تفکیک‌شده استفاده کنید."
            }
            val orderId = database.procurementDao().insertOrder(
                PurchaseOrderEntity(
                    orderNo = "PO-${now}-${UUID.randomUUID().toString().take(4)}",
                    supplierId = supplier.id,
                    supplierNameSnapshot = supplier.name,
                    requisitionId = request.id,
                    orderEpochDay = valid.orderEpochDay,
                    expectedEpochDay = valid.expectedEpochDay,
                    sentAtEpochMillis = null,
                    sentBy = null,
                    dispatchChannel = null,
                    acknowledgedAtEpochMillis = null,
                    supplierConfirmationNo = null,
                    confirmedExpectedEpochDay = null,
                    status = PurchaseOrderStatus.OPEN.name,
                    note = valid.note,
                    createdBy = actor,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            database.procurementDao().insertOrderLines(requestLines.map {
                PurchaseOrderLineEntity(
                    purchaseOrderId = orderId,
                    itemId = it.itemId,
                    itemNameSnapshot = it.itemNameSnapshot,
                    supplierSkuSnapshot = it.supplierSkuSnapshot,
                    orderedQtyMicros = it.requestedQtyMicros,
                    unitCostRial = it.estimatedUnitCostRial,
                    receivedQtyMicros = 0,
                    rejectedQtyMicros = 0,
                )
            })
            check(database.procurementDao().transitionRequisition(
                id = request.id,
                expectedStatus = RequisitionStatus.APPROVED.name,
                newStatus = RequisitionStatus.CONVERTED.name,
                approvedBy = request.approvedBy,
                note = request.note,
                updatedAtEpochMillis = now,
            ) == 1) { "درخواست هم‌زمان تغییر کرده است." }
            syncRecorder?.record("PURCHASE_ORDER", orderId, "CREATE", now)
            orderId
        }
    }

    override suspend fun createSplitOrders(draft: SplitPurchaseOrdersDraft): SplitPurchaseOrdersResult {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        val actor = authorizer.actor()
        return database.withTransaction {
            val request = database.procurementDao().requisitionById(valid.requisitionId)
                ?: error("درخواست خرید پیدا نشد.")
            require(request.status == RequisitionStatus.APPROVED.name) { "فقط درخواست تأییدشده قابل تبدیل به سفارش است." }
            val requestLines = database.procurementDao().requisitionLines(request.id)
            require(requestLines.isNotEmpty()) { "ردیف‌های درخواست پیدا نشدند." }
            val linesById = requestLines.associateBy { it.id }
            val groups = SupplierOrderSplitter.split(
                lines = requestLines.map { SupplierAssignedRequisitionLine(it.id, it.recommendedSupplierId, it.recommendedLeadTimeDays) },
                orderEpochDay = valid.orderEpochDay,
                fallbackSupplierId = valid.fallbackSupplierId,
            )
            require(groups.size <= 100) { "تعداد گروه‌های تأمین‌کننده معتبر نیست." }
            val orderIds = groups.map { group ->
                val supplier = database.supplierDao().activeById(group.supplierId)
                    ?: error("یکی از تأمین‌کنندگان تخصیص‌یافته فعال نیست.")
                val orderId = database.procurementDao().insertOrder(
                    PurchaseOrderEntity(
                        orderNo = "PO-${now}-${UUID.randomUUID().toString().take(6)}",
                        supplierId = supplier.id,
                        supplierNameSnapshot = supplier.name,
                        requisitionId = request.id,
                        orderEpochDay = valid.orderEpochDay,
                        expectedEpochDay = group.expectedEpochDay,
                        sentAtEpochMillis = null,
                        sentBy = null,
                        dispatchChannel = null,
                        acknowledgedAtEpochMillis = null,
                        supplierConfirmationNo = null,
                        confirmedExpectedEpochDay = null,
                        status = PurchaseOrderStatus.OPEN.name,
                        note = valid.note.ifBlank { "سفارش تفکیک‌شده خودکار از ${request.requestNo}" },
                        createdBy = actor,
                        createdAtEpochMillis = now,
                        updatedAtEpochMillis = now,
                    ),
                )
                database.procurementDao().insertOrderLines(group.lineIds.map { lineId ->
                    val line = linesById.getValue(lineId)
                    PurchaseOrderLineEntity(
                        purchaseOrderId = orderId,
                        itemId = line.itemId,
                        itemNameSnapshot = line.itemNameSnapshot,
                        supplierSkuSnapshot = line.supplierSkuSnapshot,
                        orderedQtyMicros = line.requestedQtyMicros,
                        unitCostRial = line.estimatedUnitCostRial,
                        receivedQtyMicros = 0,
                        rejectedQtyMicros = 0,
                    )
                })
                syncRecorder?.record("PURCHASE_ORDER", orderId, "CREATE_SPLIT", now)
                orderId
            }
            check(database.procurementDao().transitionRequisition(
                id = request.id,
                expectedStatus = RequisitionStatus.APPROVED.name,
                newStatus = RequisitionStatus.CONVERTED.name,
                approvedBy = request.approvedBy,
                note = request.note,
                updatedAtEpochMillis = now,
            ) == 1) { "درخواست هم‌زمان تغییر کرده است." }
            SplitPurchaseOrdersResult(orderIds, groups.size, requestLines.size)
        }
    }

    override suspend fun markOrderSent(orderId: Long, channel: PurchaseOrderDispatchChannel) {
        authorizer.require("PURCHASES")
        require(orderId > 0) { "سفارش خرید معتبر نیست." }
        val now = clock()
        database.withTransaction {
            val order = database.procurementDao().orderById(orderId) ?: error("سفارش خرید پیدا نشد.")
            require(order.status == PurchaseOrderStatus.OPEN.name) { "فقط سفارش باز قابل ارسال است." }
            require(order.sentAtEpochMillis == null) { "ارسال این سفارش قبلاً ثبت شده است." }
            check(database.procurementDao().markOrderSent(order.id, now, authorizer.actor(), channel.name) == 1) {
                "وضعیت ارسال سفارش هم‌زمان تغییر کرده است."
            }
            syncRecorder?.record("PURCHASE_ORDER", order.id, "DISPATCH_${channel.name}", now)
        }
    }

    override suspend fun acknowledgeOrder(draft: PurchaseOrderAcknowledgementDraft) {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        database.withTransaction {
            val order = database.procurementDao().orderById(valid.purchaseOrderId) ?: error("سفارش خرید پیدا نشد.")
            require(order.sentAtEpochMillis != null) { "ابتدا ارسال سفارش را ثبت کنید." }
            require(order.acknowledgedAtEpochMillis == null) { "تأیید تأمین‌کننده قبلاً ثبت شده است." }
            require(valid.confirmedExpectedEpochDay >= order.orderEpochDay) { "موعد قطعی نمی‌تواند قبل از تاریخ سفارش باشد." }
            val latestReceipt = database.procurementDao().latestReceiptEpochDay(order.id)
            require(latestReceipt == null || valid.confirmedExpectedEpochDay >= latestReceipt) { "موعد قطعی نمی‌تواند قبل از دریافت ثبت‌شده باشد." }
            check(database.procurementDao().acknowledgeOrder(order.id, now, valid.supplierConfirmationNo, valid.confirmedExpectedEpochDay) == 1) {
                "وضعیت تأیید سفارش هم‌زمان تغییر کرده است."
            }
            syncRecorder?.record("PURCHASE_ORDER", order.id, "SUPPLIER_ACKNOWLEDGE", now)
        }
    }

    override suspend fun postGoodsReceipt(draft: GoodsReceiptDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(valid.purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(order.status in setOf(PurchaseOrderStatus.OPEN.name, PurchaseOrderStatus.PARTIALLY_RECEIVED.name)) {
                "این سفارش قابل دریافت نیست."
            }
            require(valid.receiptEpochDay >= order.orderEpochDay) { "تاریخ دریافت نمی‌تواند قبل از سفارش باشد." }
            val receiptNo = "GR-${now}-${UUID.randomUUID().toString().take(4)}"
            require(!database.procurementDao().receiptNoExists(receiptNo)) { "شماره رسید تکراری است." }
            require(!database.procurementDao().deliveryNoteExists(order.id, valid.deliveryNoteNo)) {
                "این شماره حواله قبلاً برای سفارش ثبت شده است."
            }
            val receiptId = database.procurementDao().insertReceipt(
                GoodsReceiptEntity(
                    receiptNo = receiptNo,
                    purchaseOrderId = order.id,
                    receiptEpochDay = valid.receiptEpochDay,
                    deliveryNoteNo = valid.deliveryNoteNo,
                    receivedBy = authorizer.actor(),
                    note = valid.note,
                    createdAtEpochMillis = now,
                ),
            )
            val orderLines = database.procurementDao().orderLines(order.id).associateBy { it.id }
            var acceptedTotal = MoneyRial.ZERO
            val receiptLines = valid.lines.map { received ->
                val orderLine = orderLines[received.purchaseOrderLineId]
                    ?: error("ردیف تحویل متعلق به این سفارش نیست.")
                val remaining = orderLine.orderedQtyMicros - orderLine.receivedQtyMicros
                require(received.deliveredQtyMicros <= remaining) { "تحویل «${orderLine.itemNameSnapshot}» از مانده سفارش بیشتر است." }
                val rejected = if (valid.finalizeOrder) {
                    remaining - received.acceptedQtyMicros
                } else {
                    received.deliveredQtyMicros - received.acceptedQtyMicros
                }
                require(rejected == 0L || received.rejectionReason.length >= 3) {
                    "برای کسری یا رد «${orderLine.itemNameSnapshot}» دلیل ثبت کنید."
                }
                check(database.procurementDao().addReceiptQuantities(
                    lineId = orderLine.id,
                    purchaseOrderId = order.id,
                    acceptedQtyMicros = received.acceptedQtyMicros,
                    rejectedQtyMicros = rejected,
                ) == 1) { "مقدار دریافت هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
                val acceptedValue = MoneyRial.of(orderLine.unitCostRial).times(QuantityMicros.of(received.acceptedQtyMicros))
                acceptedTotal += acceptedValue
                if (received.acceptedQtyMicros > 0) {
                    inventoryCommands.receive(
                        itemId = orderLine.itemId,
                        quantityMicros = received.acceptedQtyMicros,
                        valueRial = acceptedValue.value,
                        movementType = "GOODS_RECEIPT",
                        referenceType = "GOODS_RECEIPT",
                        referenceId = receiptId,
                        movementEpochDay = valid.receiptEpochDay,
                        notes = "${order.orderNo} / ${valid.deliveryNoteNo}",
                    )
                }
                GoodsReceiptLineEntity(
                    goodsReceiptId = receiptId,
                    purchaseOrderLineId = orderLine.id,
                    itemId = orderLine.itemId,
                    deliveredQtyMicros = received.deliveredQtyMicros,
                    acceptedQtyMicros = received.acceptedQtyMicros,
                    rejectedQtyMicros = rejected,
                    rejectionReason = received.rejectionReason,
                    acceptedValueRial = acceptedValue.value,
                )
            }
            database.procurementDao().insertReceiptLines(receiptLines)
            if (acceptedTotal > MoneyRial.ZERO) postJournal(
                entryNo = "رس-$receiptId",
                epochDay = valid.receiptEpochDay,
                description = "دریافت کالا برای ${order.orderNo}",
                sourceType = "GOODS_RECEIPT",
                sourceId = receiptId,
                lines = listOf(
                    SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, debit = acceptedTotal),
                    SemanticJournalLine(SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED, credit = acceptedTotal),
                ),
                now = now,
            )
            val refreshed = database.procurementDao().orderLines(order.id)
            val status = if (valid.finalizeOrder || refreshed.all { it.receivedQtyMicros == it.orderedQtyMicros }) {
                PurchaseOrderStatus.RECEIVED
            } else {
                PurchaseOrderStatus.PARTIALLY_RECEIVED
            }
            check(database.procurementDao().updateOrderStatus(order.id, status.name, now) == 1) { "وضعیت سفارش تغییر نکرد." }
            syncRecorder?.record("GOODS_RECEIPT", receiptId, "POST", now)
            receiptId
        }
    }

    override suspend fun postPurchaseReturn(draft: PurchaseReturnDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(valid.purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(order.status in setOf(
                PurchaseOrderStatus.PARTIALLY_RECEIVED.name,
                PurchaseOrderStatus.RECEIVED.name,
                PurchaseOrderStatus.CLOSED.name,
            )) { "این سفارش کالای قابل مرجوعی ندارد." }
            val latestReceiptDay = database.procurementDao().latestReceiptEpochDay(order.id)
                ?: error("برای این سفارش رسید کالایی ثبت نشده است.")
            require(valid.returnEpochDay >= latestReceiptDay) { "تاریخ مرجوعی نمی‌تواند قبل از آخرین رسید کالا باشد." }

            val invoiceLink = database.procurementDao().invoiceLinkForOrder(order.id)
            val orderLines = database.procurementDao().orderLines(order.id).associateBy { it.id }
            val preparedLines = valid.lines.map { returned ->
                val orderLine = orderLines[returned.purchaseOrderLineId]
                    ?: error("ردیف مرجوعی متعلق به این سفارش نیست.")
                val returnable = orderLine.receivedQtyMicros - orderLine.returnedQtyMicros
                require(returned.quantityMicros <= returnable) {
                    "مقدار مرجوعی «${orderLine.itemNameSnapshot}» از مقدار قابل مرجوع بیشتر است."
                }
                val supplierUnitCredit = invoiceLink?.let { link ->
                    database.procurementDao().purchaseLineForItem(link.purchaseId, orderLine.itemId)?.unitCostRial
                        ?: error("ردیف فاکتور متناظر با «${orderLine.itemNameSnapshot}» پیدا نشد.")
                } ?: orderLine.unitCostRial
                val quantity = QuantityMicros.of(returned.quantityMicros)
                PreparedPurchaseReturnLine(
                    orderLine = orderLine,
                    quantityMicros = returned.quantityMicros,
                    inventoryUnitCostRial = orderLine.unitCostRial,
                    supplierUnitCreditRial = supplierUnitCredit,
                    inventoryValue = MoneyRial.of(orderLine.unitCostRial).times(quantity),
                    supplierCreditValue = if (invoiceLink == null) MoneyRial.ZERO else MoneyRial.of(supplierUnitCredit).times(quantity),
                    reason = returned.reason,
                )
            }
            val inventoryTotal = MoneyRial.sum(preparedLines.map { it.inventoryValue })
            val supplierCreditTotal = MoneyRial.sum(preparedLines.map { it.supplierCreditValue })
            val returnId = database.procurementDao().insertPurchaseReturn(
                PurchaseReturnEntity(
                    returnNo = "RT-${now}-${UUID.randomUUID().toString().take(4)}",
                    purchaseOrderId = order.id,
                    purchaseId = invoiceLink?.purchaseId,
                    supplierId = order.supplierId,
                    returnEpochDay = valid.returnEpochDay,
                    reason = valid.reason,
                    returnedBy = authorizer.actor(),
                    inventoryValueRial = inventoryTotal.value,
                    supplierCreditValueRial = supplierCreditTotal.value,
                    createdAtEpochMillis = now,
                ),
            )

            preparedLines.forEach { line ->
                check(database.procurementDao().addReturnedQuantity(
                    lineId = line.orderLine.id,
                    purchaseOrderId = order.id,
                    quantityMicros = line.quantityMicros,
                ) == 1) { "مقدار قابل مرجوع هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
                val item = database.inventoryDao().activeById(line.orderLine.itemId)
                    ?: error("کالای «${line.orderLine.itemNameSnapshot}» فعال نیست.")
                require(item.stockMicros >= line.quantityMicros) {
                    "موجودی «${line.orderLine.itemNameSnapshot}» برای مرجوعی کافی نیست."
                }
                require(item.inventoryValueRial >= line.inventoryValue.value) {
                    "ارزش موجودی «${line.orderLine.itemNameSnapshot}» برای مرجوعی کافی نیست."
                }
                inventoryCommands.issue(
                    itemId = item.id,
                    quantityMicros = line.quantityMicros,
                    valueRial = line.inventoryValue.value,
                    movementType = "PURCHASE_RETURN",
                    referenceType = "PURCHASE_RETURN",
                    referenceId = returnId,
                    movementEpochDay = valid.returnEpochDay,
                    notes = "${order.orderNo} · ${line.reason}",
                    lotPolicy = LocalInventoryCommandEngine.LotIssuePolicy.FEFO_ALLOCATED_ONLY,
                )
            }
            database.procurementDao().insertPurchaseReturnLines(preparedLines.map { line ->
                PurchaseReturnLineEntity(
                    purchaseReturnId = returnId,
                    purchaseOrderLineId = line.orderLine.id,
                    itemId = line.orderLine.itemId,
                    quantityMicros = line.quantityMicros,
                    inventoryUnitCostRial = line.inventoryUnitCostRial,
                    supplierUnitCreditRial = line.supplierUnitCreditRial,
                    inventoryValueRial = line.inventoryValue.value,
                    supplierCreditValueRial = line.supplierCreditValue.value,
                    reason = line.reason,
                )
            })

            if (invoiceLink == null) {
                postJournal(
                    entryNo = "مر-$returnId",
                    epochDay = valid.returnEpochDay,
                    description = "مرجوعی پیش از فاکتور ${order.orderNo}",
                    sourceType = "PURCHASE_RETURN",
                    sourceId = returnId,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED, debit = inventoryTotal),
                        SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, credit = inventoryTotal),
                    ),
                    now = now,
                )
            } else {
                val purchase = database.purchaseDao().byId(invoiceLink.purchaseId)
                    ?: error("فاکتور تطبیق‌شده پیدا نشد.")
                val outstanding = (purchase.totalRial - purchase.paidRial).coerceAtLeast(0)
                val applied = supplierCreditTotal.value.coerceAtMost(outstanding)
                val openCredit = supplierCreditTotal.value - applied
                if (applied > 0) {
                    val newPaid = purchase.paidRial + applied
                    val paidInFull = newPaid == purchase.totalRial
                    check(database.purchaseDao().updateSettlementState(
                        purchaseId = purchase.id,
                        expectedPaidRial = purchase.paidRial,
                        newPaidRial = newPaid,
                        paymentStatus = if (paidInFull) "PAID" else "PARTIAL",
                        reminderEnabled = !paidInFull && purchase.reminderEnabled,
                        reminderEpochDay = if (paidInFull) null else purchase.reminderEpochDay,
                    ) == 1) { "مانده فاکتور هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
                }
                database.procurementDao().insertSupplierCredit(
                    SupplierCreditEntity(
                        creditNo = "SC-$returnId",
                        supplierId = order.supplierId,
                        sourceReturnId = returnId,
                        appliedPurchaseId = purchase.id.takeIf { applied > 0 },
                        amountRial = supplierCreditTotal.value,
                        appliedRial = applied,
                        status = when {
                            applied == supplierCreditTotal.value -> "APPLIED"
                            applied > 0 -> "PARTIAL"
                            else -> "OPEN"
                        },
                        createdAtEpochMillis = now,
                    ),
                )
                val journalLines = buildList {
                    if (applied > 0) add(SemanticJournalLine(SemanticAccountRole.SUPPLIER_PAYABLE, debit = MoneyRial.of(applied)))
                    if (openCredit > 0) add(SemanticJournalLine(SemanticAccountRole.SUPPLIER_CREDIT_RECEIVABLE, debit = MoneyRial.of(openCredit)))
                    if (inventoryTotal.value > supplierCreditTotal.value) {
                        add(SemanticJournalLine(SemanticAccountRole.PURCHASE_PRICE_VARIANCE, debit = MoneyRial.of(inventoryTotal.value - supplierCreditTotal.value)))
                    }
                    add(SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, credit = inventoryTotal))
                    if (supplierCreditTotal.value > inventoryTotal.value) {
                        add(SemanticJournalLine(SemanticAccountRole.PURCHASE_PRICE_VARIANCE, credit = MoneyRial.of(supplierCreditTotal.value - inventoryTotal.value)))
                    }
                }
                postJournal(
                    entryNo = "مر-$returnId",
                    epochDay = valid.returnEpochDay,
                    description = "مرجوعی خرید و اعتبار تأمین‌کننده ${order.orderNo}",
                    sourceType = "PURCHASE_RETURN",
                    sourceId = returnId,
                    lines = journalLines,
                    now = now,
                )
            }
            syncRecorder?.record("PURCHASE_RETURN", returnId, "POST", now)
            returnId
        }
    }

    override suspend fun saveReplenishmentPolicy(draft: ReplenishmentPolicyDraft) {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        database.withTransaction {
            database.inventoryDao().activeById(valid.itemId)
                ?: error("کالای فعال پیدا نشد.")
            valid.preferredSupplierId?.let { supplierId ->
                database.supplierDao().activeById(supplierId)
                    ?: error("تأمین‌کننده ترجیحی فعال نیست.")
            }
            val now = clock()
            database.procurementDao().upsertReplenishmentPolicy(
                InventoryReplenishmentPolicyEntity(
                    itemId = valid.itemId,
                    preferredSupplierId = valid.preferredSupplierId,
                    targetCoverDays = valid.targetCoverDays,
                    leadTimeDays = valid.leadTimeDays,
                    safetyStockMicros = valid.safetyStockMicros,
                    orderMultipleMicros = valid.orderMultipleMicros,
                    isEnabled = valid.isEnabled,
                    updatedBy = authorizer.actor(),
                    updatedAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("REPLENISHMENT_POLICY", valid.itemId, "UPSERT", now)
        }
    }

    override suspend fun saveSupplierOffer(draft: SupplierOfferDraft) {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        database.withTransaction {
            database.inventoryDao().activeById(valid.itemId) ?: error("کالای فعال پیدا نشد.")
            database.supplierDao().activeById(valid.supplierId) ?: error("تأمین‌کننده فعال پیدا نشد.")
            val now = clock()
            val id = database.procurementDao().upsertSupplierItemOffer(
                SupplierItemOfferEntity(
                    supplierId = valid.supplierId,
                    itemId = valid.itemId,
                    supplierSku = valid.supplierSku,
                    unitCostRial = valid.unitCostRial,
                    minimumOrderMicros = valid.minimumOrderMicros,
                    orderMultipleMicros = valid.orderMultipleMicros,
                    leadTimeDays = valid.leadTimeDays,
                    validUntilEpochDay = valid.validUntilEpochDay,
                    isActive = valid.isActive,
                    updatedBy = authorizer.actor(),
                    updatedAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("SUPPLIER_ITEM_OFFER", id, "UPSERT", now)
        }
    }

    override suspend fun submitSuggestedRequisition(itemIds: List<Long>): Long {
        authorizer.require("PURCHASES")
        val selected = itemIds.distinct()
        require(selected.isNotEmpty() && selected.size <= 100) { "بین ۱ تا ۱۰۰ پیشنهاد را انتخاب کنید." }
        val today = todayEpochDay()
        return database.withTransaction {
            val prepared = selected.map { itemId ->
                val policyEntity = database.procurementDao().replenishmentPolicy(itemId)
                    ?: error("سیاست تأمین یکی از کالاها پیدا نشد.")
                require(policyEntity.isEnabled) { "سیاست تأمین یکی از کالاها غیرفعال است." }
                require(!database.procurementDao().activeRequestExistsForItem(itemId)) {
                    "برای یکی از کالاها درخواست خرید فعال وجود دارد."
                }
                val item = database.inventoryDao().activeById(itemId)
                    ?: error("یکی از کالاها فعال نیست.")
                val policy = ReplenishmentPolicyRecord(
                    itemId = policyEntity.itemId,
                    preferredSupplierId = policyEntity.preferredSupplierId,
                    targetCoverDays = policyEntity.targetCoverDays,
                    leadTimeDays = policyEntity.leadTimeDays,
                    safetyStockMicros = policyEntity.safetyStockMicros,
                    orderMultipleMicros = policyEntity.orderMultipleMicros,
                    isEnabled = policyEntity.isEnabled,
                )
                val latestCost = database.procurementDao().latestPurchaseUnitCostRial(itemId) ?: 0
                val baseSuggestion = ReplenishmentPlanner.suggest(
                    ReplenishmentInput(
                        itemId = item.id,
                        itemName = item.name,
                        currentStockMicros = item.stockMicros,
                        openPurchaseOrderMicros = database.procurementDao().openPurchaseOrderQtyMicros(item.id),
                        usage30DaysMicros = database.procurementDao().demandUsageMicros(item.id, today - 29),
                        estimatedUnitCostRial = latestCost,
                        policy = policy,
                        hasPendingRequest = false,
                        preferredSupplierScore = null,
                    ),
                ) ?: error("یکی از کالاهای انتخاب‌شده دیگر نیاز به سفارش ندارد.")
                val candidates = database.procurementDao().validSupplierItemOffers(item.id, today).map { offer ->
                    val supplier = database.supplierDao().activeById(offer.supplierId)
                        ?: error("یکی از تأمین‌کنندگان پیشنهاد قیمت فعال نیست.")
                    SupplierOfferCandidate(
                        SupplierOfferRecord(
                            id = offer.id,
                            supplierId = offer.supplierId,
                            supplierName = supplier.name,
                            itemId = offer.itemId,
                            itemName = item.name,
                            supplierSku = offer.supplierSku,
                            unitCostRial = offer.unitCostRial,
                            minimumOrderMicros = offer.minimumOrderMicros,
                            orderMultipleMicros = offer.orderMultipleMicros,
                            leadTimeDays = offer.leadTimeDays,
                            validUntilEpochDay = offer.validUntilEpochDay,
                            isActive = offer.isActive,
                        ),
                        supplierScore = null,
                    )
                }
                val sourcing = SupplierSourcingAdvisor.choose(candidates, baseSuggestion.suggestedOrderMicros, latestCost, policy.preferredSupplierId)
                val suggestion = if (sourcing == null) baseSuggestion else baseSuggestion.copy(
                    suggestedOrderMicros = sourcing.orderQuantityMicros,
                    estimatedUnitCostRial = sourcing.offer.unitCostRial,
                    estimatedOrderValueRial = sourcing.orderValueRial,
                    recommendedSupplierId = sourcing.offer.supplierId,
                    recommendedSupplierName = sourcing.offer.supplierName,
                    recommendedSupplierSku = sourcing.offer.supplierSku,
                    comparedOfferCount = sourcing.comparedOfferCount,
                    recommendedLeadTimeDays = sourcing.offer.leadTimeDays,
                    offerValidUntilEpochDay = sourcing.offer.validUntilEpochDay,
                    estimatedSavingsRial = sourcing.estimatedSavingsRial,
                )
                suggestion to (suggestion.recommendedLeadTimeDays ?: policy.leadTimeDays)
            }
            submitRequisition(
                PurchaseRequisitionDraft(
                    department = "انبار / تأمین هوشمند",
                    requiredEpochDay = today + prepared.minOf { it.second }.toLong(),
                    note = "ایجاد خودکار بر اساس مصرف ۳۰روزه، ذخیره اطمینان و سفارش‌های باز",
                    lines = prepared.map { (suggestion, _) ->
                        RequisitionLineDraft(
                            itemId = suggestion.itemId,
                            quantityMicros = suggestion.suggestedOrderMicros,
                            estimatedUnitCostRial = suggestion.estimatedUnitCostRial,
                            recommendedSupplierId = suggestion.recommendedSupplierId,
                            supplierSku = suggestion.recommendedSupplierSku,
                            recommendedLeadTimeDays = suggestion.recommendedLeadTimeDays,
                            note = suggestion.recommendedSupplierName?.let { supplier ->
                                "تأمین پیشنهادی: $supplier؛ انتخاب‌شده از ${suggestion.comparedOfferCount} پیشنهاد معتبر"
                            } ?: "پوشش هدف و زمان تأمین محاسبه‌شده توسط موتور پیشنهاد سفارش",
                        )
                    },
                ),
            )
        }
    }

    override suspend fun previewThreeWayMatch(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
    ): ThreeWayMatchResult = database.withTransaction { calculateMatch(purchaseOrderId, invoice) }

    override suspend fun postMatchedInvoice(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
        approvePriceVariance: Boolean,
    ): PostedPurchase {
        authorizer.require("PURCHASES")
        val prepared = PurchaseCalculator.prepare(invoice)
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(order.status == PurchaseOrderStatus.RECEIVED.name) { "برای تطبیق فاکتور، دریافت سفارش باید کامل باشد." }
            require(order.supplierId == prepared.draft.supplierId) { "تأمین‌کننده فاکتور با سفارش یکسان نیست." }
            require(prepared.draft.purchaseEpochDay >= order.orderEpochDay) { "تاریخ فاکتور نمی‌تواند قبل از سفارش خرید باشد." }
            require(!database.procurementDao().orderHasInvoice(order.id)) { "برای این سفارش قبلاً فاکتور ثبت شده است." }
            require(!database.purchaseDao().invoiceExists(prepared.draft.invoiceNo)) { "شماره فاکتور خرید تکراری است." }
            val match = calculateMatch(order.id, prepared.draft)
            require(match.status != ThreeWayMatchStatus.QUANTITY_VARIANCE) { "مقدار فاکتور با کالای پذیرفته‌شده یکسان نیست." }
            val requiresApproval = match.status == ThreeWayMatchStatus.PRICE_VARIANCE && match.priceVarianceBasisPoints > 500
            if (requiresApproval) {
                require(approvePriceVariance) { "مغایرت قیمت بیش از ۵٪ است و تأیید مدیر لازم دارد." }
                authorizer.require("AUDIT")
            }
            val paid = prepared.draft.paymentMethod != PurchasePaymentMethod.PAYABLE
            val purchaseId = database.purchaseDao().insert(
                PurchaseEntity(
                    invoiceNo = prepared.draft.invoiceNo,
                    supplierId = order.supplierId,
                    purchaseEpochDay = prepared.draft.purchaseEpochDay,
                    dueEpochDay = prepared.draft.dueEpochDay,
                    totalRial = prepared.total.value,
                    paidRial = if (paid) prepared.total.value else 0,
                    paymentStatus = if (paid) "PAID" else "UNPAID",
                    paymentMethod = prepared.draft.paymentMethod.storedValue,
                    reminderEnabled = !paid && prepared.draft.reminderEnabled,
                    reminderEpochDay = if (!paid && prepared.draft.reminderEnabled) prepared.draft.reminderEpochDay else null,
                    createdAtEpochMillis = now,
                ),
            )
            val items = database.procurementDao().orderLines(order.id).associateBy { it.itemId }
            database.purchaseDao().insertLines(prepared.lines.map { line ->
                val ordered = items[line.itemId] ?: error("کالای فاکتور در سفارش وجود ندارد.")
                PurchaseLineEntity(
                    purchaseId = purchaseId,
                    itemId = line.itemId,
                    itemNameSnapshot = ordered.itemNameSnapshot,
                    quantityMicros = line.quantityMicros,
                    unitCostRial = line.unitCostRial,
                    lineTotalRial = line.total.value,
                )
            })
            val journalLines = buildList {
                add(SemanticJournalLine(SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED, debit = MoneyRial.of(match.acceptedValueRial)))
                if (match.priceVarianceRial > 0) {
                    add(SemanticJournalLine(SemanticAccountRole.PURCHASE_PRICE_VARIANCE, debit = MoneyRial.of(match.priceVarianceRial)))
                } else if (match.priceVarianceRial < 0) {
                    add(SemanticJournalLine(SemanticAccountRole.PURCHASE_PRICE_VARIANCE, credit = MoneyRial.of(-match.priceVarianceRial)))
                }
                add(SemanticJournalLine(
                    role = prepared.draft.paymentMethod.settlementRole,
                    credit = prepared.total,
                ))
            }
            val journalId = postJournal(
                entryNo = "تخ-$purchaseId",
                epochDay = prepared.draft.purchaseEpochDay,
                description = "تطبیق فاکتور ${prepared.draft.invoiceNo} با ${order.orderNo}",
                sourceType = "PROCUREMENT_INVOICE",
                sourceId = purchaseId,
                lines = journalLines,
                now = now,
            )
            database.procurementDao().insertInvoiceLink(
                ProcurementInvoiceLinkEntity(
                    purchaseOrderId = order.id,
                    purchaseId = purchaseId,
                    matchStatus = match.status.name,
                    acceptedValueRial = match.acceptedValueRial,
                    invoiceValueRial = match.invoiceValueRial,
                    priceVarianceRial = match.priceVarianceRial,
                    varianceApprovedBy = if (requiresApproval) authorizer.actor() else null,
                    matchedAtEpochMillis = now,
                ),
            )
            check(database.procurementDao().updateOrderStatus(order.id, PurchaseOrderStatus.CLOSED.name, now) == 1) {
                "بستن سفارش انجام نشد."
            }
            database.managementControlDao().transitionCommitment(
                referenceType = "PURCHASE_REQUISITION",
                referenceId = order.requisitionId,
                status = "CONSUMED",
                now = now,
            )
            syncRecorder?.record("PURCHASE", purchaseId, "THREE_WAY_MATCH", now)
            PostedPurchase(purchaseId, journalId, prepared.total)
        }
    }

    private suspend fun calculateMatch(purchaseOrderId: Long, invoice: PurchaseDraft): ThreeWayMatchResult {
        val prepared = PurchaseCalculator.prepare(invoice)
        val accepted = database.procurementDao().orderLines(purchaseOrderId)
        require(accepted.isNotEmpty()) { "ردیف‌های سفارش پیدا نشدند." }
        val invoiceQty = prepared.lines.associate { it.itemId to it.quantityMicros }
        val acceptedQty = accepted
            .map { it.itemId to (it.receivedQtyMicros - it.returnedQtyMicros) }
            .filter { it.second > 0 }
            .toMap()
        val quantityMatches = invoiceQty == acceptedQty
        val acceptedValue = MoneyRial.sum(accepted.map {
            MoneyRial.of(it.unitCostRial).times(QuantityMicros.of(it.receivedQtyMicros - it.returnedQtyMicros))
        }).value
        val variance = prepared.total.value - acceptedValue
        val basisPoints = if (acceptedValue == 0L) 0L else {
            java.math.BigInteger.valueOf(abs(variance))
                .multiply(java.math.BigInteger.valueOf(10_000))
                .divide(java.math.BigInteger.valueOf(acceptedValue))
                .longValueExact()
        }
        val status = when {
            !quantityMatches -> ThreeWayMatchStatus.QUANTITY_VARIANCE
            variance != 0L -> ThreeWayMatchStatus.PRICE_VARIANCE
            else -> ThreeWayMatchStatus.MATCHED
        }
        return ThreeWayMatchResult(status, acceptedValue, prepared.total.value, variance, basisPoints)
    }

    private fun buildSupplierScorecards(
        orders: List<PurchaseOrderRecord>,
        signals: SupplierSignals,
    ): List<SupplierScorecard> {
        val receiptById = signals.receipts.associateBy { it.id }
        return orders.groupBy { it.supplierId }.map { (supplierId, supplierOrders) ->
            val orderIds = supplierOrders.map { it.id }.toSet()
            val completed = supplierOrders.filter { it.status in setOf(PurchaseOrderStatus.RECEIVED, PurchaseOrderStatus.CLOSED) }
            val onTimeCount = completed.count { order ->
                signals.receipts.filter { it.purchaseOrderId == order.id }
                    .maxOfOrNull { it.receiptEpochDay }
                    ?.let { it <= order.expectedEpochDay } == true
            }
            val relevantReceiptLines = signals.receiptLines.filter { line ->
                receiptById[line.goodsReceiptId]?.purchaseOrderId?.let(orderIds::contains) == true
            }
            val acceptedQty = safeSum(relevantReceiptLines.map { it.acceptedQtyMicros })
            val evaluatedQty = safeSum(relevantReceiptLines.map { it.acceptedQtyMicros + it.rejectedQtyMicros })
            val returnIds = signals.returns.filter { it.supplierId == supplierId }.map { it.id }.toSet()
            val returnedQty = safeSum(signals.returnLines.filter { it.purchaseReturnId in returnIds }.map { it.quantityMicros })
            val relevantLinks = signals.invoiceLinks.filter { link -> link.purchaseOrderId in orderIds }
            val acceptedValue = safeSum(relevantLinks.map { it.acceptedValueRial })
            val absolutePriceVariance = safeSum(relevantLinks.map { abs(it.priceVarianceRial) })
            val onTime = ratioBasisPoints(onTimeCount.toLong(), completed.size.toLong())
            val acceptance = ratioBasisPoints(acceptedQty, evaluatedQty)
            val returns = ratioBasisPoints(returnedQty, acceptedQty)
            val priceVariance = ratioBasisPoints(absolutePriceVariance, acceptedValue)
            val score = if (completed.isEmpty()) 0 else {
                val deliveryScore = onTime * 350 / 10_000
                val qualityScore = acceptance * 300 / 10_000
                val returnScore = (10_000 - returns.coerceAtMost(10_000)) * 150 / 10_000
                val priceScore = (10_000 - priceVariance.coerceAtMost(10_000)) * 200 / 10_000
                (deliveryScore + qualityScore + returnScore + priceScore).toInt()
            }
            SupplierScorecard(
                supplierId = supplierId,
                supplierName = supplierOrders.first().supplierName,
                completedOrders = completed.size,
                onTimeBasisPoints = onTime,
                acceptanceBasisPoints = acceptance,
                returnBasisPoints = returns,
                priceVarianceBasisPoints = priceVariance,
                openCreditRial = safeSum(signals.credits.filter { it.supplierId == supplierId }.map { it.amountRial - it.appliedRial }),
                score = score,
            )
        }.filter { it.completedOrders > 0 }
            .sortedWith(compareByDescending<SupplierScorecard> { it.score }.thenBy { it.supplierName })
    }

    private fun ratioBasisPoints(numerator: Long, denominator: Long): Long {
        if (numerator <= 0 || denominator <= 0) return 0
        return BigInteger.valueOf(numerator)
            .multiply(BigInteger.valueOf(10_000))
            .divide(BigInteger.valueOf(denominator))
            .longValueExact()
    }

    private fun safeSum(values: Iterable<Long>): Long = values.fold(BigInteger.ZERO) { total, value ->
        require(value >= 0) { "مقدار تجمیعی نمی‌تواند منفی باشد." }
        total + BigInteger.valueOf(value)
    }.also {
        require(it <= BigInteger.valueOf(Long.MAX_VALUE)) { "جمع شاخص عملکرد از محدوده امن خارج می‌شود." }
    }.longValueExact()

    private suspend fun postJournal(
        entryNo: String,
        epochDay: Long,
        description: String,
        sourceType: String,
        sourceId: Long,
        lines: List<SemanticJournalLine>,
        now: Long,
    ): Long = LocalAccountingPostingEngine(database, clock = { now }).post(
        SemanticJournalDraft(
            entryNo = entryNo,
            entryEpochDay = epochDay,
            description = description,
            sourceType = sourceType,
            sourceId = sourceId,
            lines = lines,
        ),
    )
}
