package ir.sabou.inventory.data.db

import android.content.Context
import androidx.room.Room
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Builds the real exported version-1 schema, runs every production migration,
 * and lets Room validate the result against the current entity model.
 */
@RunWith(AndroidJUnit4::class)
class FullMigration1To40Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "full-migration-1-39.db"

    @After
    fun cleanUp() {
        context.deleteDatabase(databaseName)
    }

    @Test
    fun migratesVersionOneWithoutDestructiveFallback() {
        createVersionOneDatabase()

        Room.databaseBuilder(context, AppDatabase::class.java, databaseName)
            .addMigrations(*ALL_MIGRATIONS)
            .build()
            .use { database ->
                val sqlite = database.openHelper.writableDatabase
                assertEquals(40, sqlite.version)
                sqlite.query("PRAGMA foreign_key_check").use { cursor ->
                    assertEquals("مهاجرت نباید کلید خارجی شکسته بسازد.", 0, cursor.count)
                }
                sqlite.query("SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='accounting_period_locks'").use { cursor ->
                    cursor.moveToFirst()
                    assertEquals(1, cursor.getInt(0))
                }
            }
    }

    private fun createVersionOneDatabase() {
        val root = context.assets
            .open("ir.sabou.inventory.data.db.AppDatabase/1.json")
            .bufferedReader()
            .use { JSONObject(it.readText()).getJSONObject("database") }

        val callback = object : SupportSQLiteOpenHelper.Callback(1) {
            override fun onCreate(db: SupportSQLiteDatabase) {
                val entities = root.getJSONArray("entities")
                for (index in 0 until entities.length()) {
                    val entity = entities.getJSONObject(index)
                    val tableName = entity.getString("tableName")
                    db.execSQL(entity.getString("createSql").replace("${'$'}{TABLE_NAME}", tableName))
                    val indices = entity.optJSONArray("indices") ?: continue
                    for (indexPosition in 0 until indices.length()) {
                        db.execSQL(
                            indices.getJSONObject(indexPosition)
                                .getString("createSql")
                                .replace("${'$'}{TABLE_NAME}", tableName),
                        )
                    }
                }
                val setupQueries = root.getJSONArray("setupQueries")
                for (index in 0 until setupQueries.length()) db.execSQL(setupQueries.getString(index))
            }

            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit
        }

        FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context)
                .name(databaseName)
                .callback(callback)
                .build(),
        ).use { it.writableDatabase }
    }
}
