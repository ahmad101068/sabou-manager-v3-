package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.recipe.RecipeIngredientItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RecipeUiState(
    val menuItems: List<MenuItem> = emptyList(),
    val inventoryItems: List<InventoryItemRecord> = emptyList(),
    val selectedMenuItemId: Long? = null,
    val ingredients: List<RecipeIngredientItem> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
)

@OptIn(ExperimentalCoroutinesApi::class)
class RecipeViewModel(
    private val recipeRepository: RecipeRepository,
    operationsRepository: OperationsRepository,
) : ViewModel() {
    private val selectedId = MutableStateFlow<Long?>(null)
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val ingredients = selectedId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else recipeRepository.observeIngredients(id)
    }

    val state: StateFlow<RecipeUiState> = combine(
        recipeRepository.observeMenuItems(),
        operationsRepository.inventoryItems,
        selectedId,
        ingredients,
        busy,
        message,
    ) { menu, inventory, selected, recipe, isBusy, msg ->
        RecipeUiState(menu, inventory, selected, recipe, isBusy, msg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), RecipeUiState())

    fun select(id: Long?) { selectedId.value = id }

    fun save(
        id: Long?,
        name: String,
        category: String,
        salePriceRial: Long,
        ingredients: List<RecipeIngredientInput>,
        done: () -> Unit = {},
    ) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                val savedId = recipeRepository.saveMenuItem(id, name, category, salePriceRial, ingredients)
                selectedId.value = savedId
                message.value = "محصول و رسپی ذخیره شد."
                done()
            } catch (e: Exception) {
                message.value = e.message ?: "ذخیره رسپی انجام نشد."
            } finally {
                busy.value = false
            }
        }
    }

    companion object {
        fun factory(recipeRepository: RecipeRepository, operationsRepository: OperationsRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    RecipeViewModel(recipeRepository, operationsRepository) as T
            }
    }
}
