package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole

@Composable
fun SecurityScreen(state: SecurityUiState, onSave: (Long?, UserDraft, () -> Unit) -> Unit, onDeactivate: (Long) -> Unit, onSwitch: (Long, String, () -> Unit) -> Unit, onBackup: () -> Unit, onRestore: (String) -> Unit, onBack: () -> Unit) {
    var showNew by remember { mutableStateOf(false) }
    var switchId by remember { mutableStateOf<Long?>(null) }
    Scaffold(topBar = { TopAppBar(title={ Text("کاربران و پشتیبان‌گیری") }, navigationIcon={ TextButton(onClick=onBack){ Text("بازگشت") } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Text("کاربر فعال: ${state.currentUser?.displayName ?: "نامشخص"} · ${state.currentUser?.role?.title ?: ""}") }
            if (state.message != null) item { Text(state.message, color=MaterialTheme.colorScheme.primary) }
            item { Button(onClick={showNew=true}, enabled=!state.busy){ Text("افزودن کاربر") } }
            items(state.users, key={it.id}) { user ->
                Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Text("${user.displayName} (${user.username})")
                    Text("نقش: ${user.role.title} · ${if(user.isActive) "فعال" else "غیرفعال"}")
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        if(user.isActive) OutlinedButton(onClick={switchId=user.id}) { Text("ورود") }
                        if(user.role != UserRole.OWNER && user.isActive) TextButton(onClick={onDeactivate(user.id)}) { Text("غیرفعال") }
                    }
                } }
            }
            item { HorizontalDivider(); Text("پشتیبان‌گیری محلی") }
            item { Button(onClick=onBackup, enabled=!state.busy){ Text("ساخت نسخه پشتیبان رمزگذاری‌شده") } }
            items(state.backups) { name -> Card { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement=Arrangement.SpaceBetween) { Text(name, Modifier.weight(1f)); TextButton(onClick={onRestore(name)}){Text("بازیابی") } } } }
        }
    }
    if(showNew) UserEditorDialog(onDismiss={showNew=false}, onSave={draft -> onSave(null,draft){showNew=false}})
    switchId?.let { id -> PinDialog(onDismiss={switchId=null}, onConfirm={pin -> onSwitch(id,pin){switchId=null}}) }
}

@Composable private fun UserEditorDialog(onDismiss:()->Unit,onSave:(UserDraft)->Unit) {
    var username by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var pin by remember { mutableStateOf("") }; var role by remember { mutableStateOf(UserRole.CASHIER) }; var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest=onDismiss, title={Text("کاربر جدید")}, text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(username,{username=it},label={Text("نام کاربری")}); OutlinedTextField(name,{name=it},label={Text("نام نمایشی")}); OutlinedTextField(pin,{pin=it.filter(Char::isDigit)},label={Text("رمز عددی")})
        Box { OutlinedButton(onClick={expanded=true}){Text("نقش: ${role.title}")}; DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { UserRole.entries.forEach { DropdownMenuItem(text={Text(it.title)},onClick={role=it;expanded=false}) } } }
    }}, confirmButton={Button(onClick={onSave(UserDraft(username,name,pin,role))}){Text("ذخیره")}}, dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable private fun PinDialog(onDismiss:()->Unit,onConfirm:(String)->Unit) { var pin by remember { mutableStateOf("") }; AlertDialog(onDismissRequest=onDismiss,title={Text("رمز ورود")},text={OutlinedTextField(pin,{pin=it.filter(Char::isDigit)},label={Text("PIN")})},confirmButton={Button(onClick={onConfirm(pin)}){Text("ورود")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}}) }
