package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.CustomerFollowUpEntity
import ir.sabou.inventory.data.db.LoyaltyTransactionEntity
import ir.sabou.inventory.domain.crm.CrmRepository

class LocalCrmRepository(private val db: AppDatabase) : CrmRepository {
    override fun customers() = db.crmDao().observeCustomerSummaries()
    override fun followUps() = db.crmDao().observeFollowUps()
    override fun transactions(customerId: Long) = db.crmDao().observeTransactions(customerId)
    override suspend fun adjustPoints(customerId: Long, delta: Long, reason: String) {
        require(delta != 0) { "تغییر امتیاز نمی‌تواند صفر باشد" }
        require(reason.isNotBlank()) { "دلیل تغییر امتیاز الزامی است" }
        db.crmDao().insertTransaction(LoyaltyTransactionEntity(customerId=customerId, pointsDelta=delta, reason=reason.trim(), createdAtEpochMillis=System.currentTimeMillis()))
    }
    override suspend fun addFollowUp(customerId: Long, title: String, dueEpochDay: Long, notes: String) {
        require(title.isNotBlank()) { "عنوان پیگیری الزامی است" }
        db.crmDao().insertFollowUp(CustomerFollowUpEntity(customerId=customerId, title=title.trim(), dueEpochDay=dueEpochDay, notes=notes.trim(), createdAtEpochMillis=System.currentTimeMillis()))
    }
    override suspend fun completeFollowUp(id: Long) { check(db.crmDao().completeFollowUp(id, System.currentTimeMillis()) == 1) { "پیگیری قبلاً انجام شده است" } }
}
