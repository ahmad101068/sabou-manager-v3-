package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AppSessionEntity
import ir.sabou.inventory.data.db.AppUserEntity
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import java.security.MessageDigest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalSecurityRepository(private val db: AppDatabase, private val clock: () -> Long = System::currentTimeMillis) : SecurityRepository {
    override val users: Flow<List<AppUserRecord>> = db.securityDao().observeUsers().map { list -> list.map(AppUserEntity::toRecord) }
    override val currentUser: Flow<AppUserRecord?> = db.securityDao().observeCurrentUser().map { it?.toRecord() }

    override suspend fun save(id: Long?, draft: UserDraft): Long {
        val username = draft.username.trim().lowercase()
        val displayName = draft.displayName.trim()
        require(username.length >= 3) { "نام کاربری باید حداقل ۳ حرف باشد." }
        require(displayName.isNotBlank()) { "نام نمایشی الزامی است." }
        require(draft.pin.length >= 4 && draft.pin.all(Char::isDigit)) { "رمز باید حداقل ۴ رقم باشد." }
        val now = clock()
        return db.withTransaction {
            val duplicate = db.securityDao().byUsername(username)
            require(duplicate == null || duplicate.id == id) { "این نام کاربری قبلاً ثبت شده است." }
            if (id == null) db.securityDao().insert(AppUserEntity(username=username, displayName=displayName, pinHash=hashPin(draft.pin), role=draft.role.name, createdAtEpochMillis=now, updatedAtEpochMillis=now))
            else {
                val current = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
                check(db.securityDao().update(current.copy(username=username, displayName=displayName, pinHash=hashPin(draft.pin), role=draft.role.name, isActive=true, updatedAtEpochMillis=now)) == 1)
                id
            }
        }
    }

    override suspend fun deactivate(id: Long) {
        check(db.securityDao().deactivate(id, clock()) == 1) { "کاربر مالک قابل غیرفعال‌سازی نیست یا کاربر پیدا نشد." }
    }

    override suspend fun switchUser(id: Long, pin: String) {
        val user = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
        require(user.isActive) { "این کاربر غیرفعال است." }
        require(user.pinHash == hashPin(pin)) { "رمز ورود نادرست است." }
        db.securityDao().setSession(AppSessionEntity(currentUserId=id, updatedAtEpochMillis=clock()))
    }

    private fun AppUserEntity.toRecord() = AppUserRecord(id, username, displayName, runCatching { UserRole.valueOf(role) }.getOrDefault(UserRole.CASHIER), isActive)
    private fun hashPin(pin: String): String = MessageDigest.getInstance("SHA-256").digest(("sabou-v3:" + pin).toByteArray()).joinToString("") { "%02x".format(it) }
}
