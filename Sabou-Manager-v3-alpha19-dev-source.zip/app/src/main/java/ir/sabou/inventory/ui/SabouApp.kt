package ir.sabou.inventory.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord

enum class AppScreen {
    DASHBOARD,
    PURCHASES,
    NEW_PURCHASE,
    SUPPLIERS,
    INVENTORY,
    SALES,
    RECIPES,
    ACCOUNTING,
    NEW_JOURNAL,
    AUDIT_LOG,
    SECURITY,
    PERSONNEL,
    ASSETS,
    CRM,
    ALERTS,
}

private data class ModuleCard(val title: String, val screen: AppScreen?, val permission: String? = null)

private val modules = listOf(
    ModuleCard("خرید و فاکتورها", AppScreen.PURCHASES, "PURCHASES"),
    ModuleCard("تأمین‌کنندگان", AppScreen.SUPPLIERS, "SUPPLIERS"),
    ModuleCard("انبار و هشدار موجودی", AppScreen.INVENTORY, "INVENTORY"),
    ModuleCard("رسپی و بهای تمام‌شده", AppScreen.RECIPES, "RECIPES"),
    ModuleCard("فروش و مشتریان", AppScreen.SALES, "SALES"),
    ModuleCard("باشگاه مشتریان و CRM", AppScreen.CRM, "SALES"),
    ModuleCard("مرکز هشدارها", AppScreen.ALERTS, null),
    ModuleCard("حسابداری", AppScreen.ACCOUNTING, "ACCOUNTING"),
    ModuleCard("پرسنل و حقوق", AppScreen.PERSONNEL, "PERSONNEL"),
    ModuleCard("دارایی‌های رستوران", AppScreen.ASSETS, "ASSETS"),
    ModuleCard("گزارش و چاپ", null),
    ModuleCard("لاگ عملیات و حسابرسی", AppScreen.AUDIT_LOG, "AUDIT"),
    ModuleCard("کاربران و پشتیبان", AppScreen.SECURITY, "BACKUP"),
)

@Composable
fun SabouApp(container: AppContainer) {
    val dashboard: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(container.dashboardRepository),
    )
    val operations: OperationsViewModel = viewModel(
        factory = OperationsViewModel.factory(
            container.operationsRepository,
            container.purchaseRepository,
        ),
    )
    val accounting: AccountingViewModel = viewModel(
        factory = AccountingViewModel.factory(container.accountingRepository),
    )
    val sales: SalesViewModel = viewModel(
        factory = SalesViewModel.factory(container.salesRepository, container.recipeRepository),
    )
    val recipes: RecipeViewModel = viewModel(
        factory = RecipeViewModel.factory(container.recipeRepository, container.operationsRepository),
    )
    val personnel: PersonnelViewModel = viewModel(factory = PersonnelViewModel.factory(container.personnelRepository))
    val assets: AssetViewModel = viewModel(factory = AssetViewModel.factory(container.assetRepository))
    val crm: CrmViewModel = viewModel(factory = CrmViewModel.factory(container.crmRepository))
    val alerts: AlertViewModel = viewModel(factory = AlertViewModel.factory(container.alertRepository))
    val security: SecurityViewModel = viewModel(
        factory = SecurityViewModel.factory(container.securityRepository, container),
    )
    val dashboardState by dashboard.state.collectAsState()
    val operationsState by operations.state.collectAsState()
    val accountingState by accounting.state.collectAsState()
    val salesState by sales.state.collectAsState()
    val recipeState by recipes.state.collectAsState()
    val alertState by alerts.state.collectAsState()
    val securityState by security.state.collectAsState()
    val personnelState by personnel.state.collectAsState()
    val assetState by assets.state.collectAsState()
    val crmState by crm.state.collectAsState()
    var screen by remember { mutableStateOf(AppScreen.DASHBOARD) }

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        when (screen) {
            AppScreen.DASHBOARD -> DashboardScreen(
                state = dashboardState,
                operationsState = operationsState,
                currentUser = securityState.currentUser,
                onOpen = { target ->
                    if (target != null) screen = target
                    else operations.clearMessage()
                },
            )

            AppScreen.PURCHASES -> PurchasesScreen(
                state = operationsState,
                onSearch = operations::searchPurchases,
                onSelect = operations::selectPurchase,
                onSettle = operations::settlePurchase,
                onReverseSettlement = operations::reversePurchaseSettlement,
                onReverse = operations::reversePurchase,
                onAdd = { screen = AppScreen.NEW_PURCHASE },
                onBack = {
                    operations.selectPurchase(null)
                    screen = AppScreen.DASHBOARD
                },
            )

            AppScreen.NEW_PURCHASE -> PurchaseEntryScreen(
                state = operationsState,
                onPost = operations::postPurchase,
                onBack = { screen = AppScreen.PURCHASES },
            )

            AppScreen.SUPPLIERS -> SuppliersScreen(
                state = operationsState,
                onSave = operations::saveSupplier,
                onDeactivate = operations::deactivateSupplier,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.INVENTORY -> InventoryScreen(
                state = operationsState,
                onSave = operations::saveInventoryItem,
                onDeactivate = operations::deactivateInventoryItem,
                onCount = operations::postInventoryCount,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SALES -> SalesScreen(
                state = salesState,
                onSearch = sales::search,
                onSelect = sales::selectSale,
                onAddCustomer = sales::addCustomer,
                onPostSale = sales::postSale,
                onReceive = sales::receive,
                onReverse = sales::reverse,
                onReverseSale = sales::reverseSale,
                onReplaceSale = sales::replaceSale,
                onSetReportRange = sales::setReportRange,
                onBack = { sales.selectSale(null); screen = AppScreen.DASHBOARD },
            )

            AppScreen.RECIPES -> RecipeScreen(
                state = recipeState,
                onSelect = recipes::select,
                onSave = recipes::save,
                onBack = { recipes.select(null); screen = AppScreen.DASHBOARD },
            )

            AppScreen.ACCOUNTING -> AccountingScreen(
                state = accountingState,
                onSearch = accounting::searchJournals,
                onSelectJournal = accounting::selectJournal,
                onSelectLedger = accounting::selectLedger,
                onSaveAccount = accounting::saveAccount,
                onDeactivateAccount = accounting::deactivateAccount,
                onReverse = accounting::reverseManual,
                onAddJournal = { screen = AppScreen.NEW_JOURNAL },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.AUDIT_LOG -> AuditLogScreen(state = operationsState, onBack = { screen = AppScreen.DASHBOARD })

            AppScreen.PERSONNEL -> PersonnelScreen(
                state = personnelState,
                onSaveEmployee = personnel::saveEmployee,
                onDeactivate = personnel::deactivate,
                onPostPayroll = personnel::postPayroll,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SECURITY -> SecurityScreen(
                state = securityState,
                onSave = security::save,
                onDeactivate = security::deactivate,
                onSwitch = security::switchUser,
                onBackup = security::createBackup,
                onRestore = security::restore,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.ASSETS -> AssetScreen(
                state = assetState,
                onSave = assets::save,
                onDispose = assets::dispose,
                onDepreciate = assets::depreciate,
                onBack = { screen = AppScreen.DASHBOARD },
            )


            AppScreen.CRM -> CrmScreen(
                state = crmState,
                onAdjustPoints = crm::adjustPoints,
                onAddFollowUp = crm::addFollowUp,
                onComplete = crm::complete,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.ALERTS -> AlertCenterScreen(
                state = alertState,
                onRefresh = alerts::refresh,
                onRead = alerts::markRead,
                onDismiss = alerts::dismiss,
                onClearDismissed = alerts::clearDismissed,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.NEW_JOURNAL -> ManualJournalEntryScreen(
                state = accountingState,
                onPost = accounting::postManual,
                onBack = { screen = AppScreen.ACCOUNTING },
            )
        }
    }
}

@Composable
private fun DashboardScreen(
    state: DashboardSnapshot,
    operationsState: OperationsUiState,
    currentUser: AppUserRecord?,
    onOpen: (AppScreen?) -> Unit,
) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(horizontal = 18.dp),
        ) {
            Spacer(Modifier.height(22.dp))
            Text(
                text = "مدیریت رستوران",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
            )
            Text(
                text = "${currentUser?.displayName ?: "کاربر"} · ${currentUser?.role?.title ?: ""}",
                color = MaterialTheme.colorScheme.primary,
            )
            Text(
                text = "نسخه ۳ · آفلاین، امن و حسابداری‌محور",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
            )
            if (operationsState.lowStockItems.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Card(
                    onClick = { onOpen(AppScreen.INVENTORY) },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer,
                    ),
                ) {
                    Text(
                        text = "${operationsState.lowStockItems.size} کالا به حد هشدار موجودی رسیده است.",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            if (operationsState.settlementAlerts.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Card(
                    onClick = { onOpen(AppScreen.PURCHASES) },
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                    ),
                ) {
                    Text(
                        text = "${operationsState.settlementAlerts.size} یادآور تسویه تأمین‌کننده سررسید شده است.",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        color = MaterialTheme.colorScheme.onTertiaryContainer,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Spacer(Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                MetricCard(
                    title = "ارزش انبار",
                    value = formatMoney(state.inventoryValueRial),
                    modifier = Modifier.weight(1f),
                )
                MetricCard(
                    title = "بدهی تأمین‌کننده",
                    value = formatMoney(state.supplierPayablesRial),
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                MetricCard(
                    title = "صندوق",
                    value = formatMoney(state.cashBalanceRial),
                    modifier = Modifier.weight(1f),
                )
                MetricCard(
                    title = "بانک",
                    value = formatMoney(state.bankBalanceRial),
                    modifier = Modifier.weight(1f),
                )
            }
            Spacer(Modifier.height(22.dp))
            Text("ماژول‌ها", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(modules.filter { it.permission == null || currentUser?.role?.allows(it.permission) == true }) { module ->
                    Card(
                        onClick = { onOpen(module.screen) },
                        enabled = module.screen != null,
                        colors = CardDefaults.cardColors(
                            containerColor = if (module.screen == null) {
                                MaterialTheme.colorScheme.surfaceVariant
                            } else {
                                MaterialTheme.colorScheme.surface
                            },
                        ),
                    ) {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 18.dp)) {
                            Text(module.title, fontWeight = FontWeight.SemiBold)
                            if (module.screen == null) {
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "در حال بازسازی",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
            Spacer(Modifier.height(8.dp))
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}
