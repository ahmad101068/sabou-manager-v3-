package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.sales.CustomerDraft
import ir.sabou.inventory.domain.sales.CustomerRecord
import ir.sabou.inventory.domain.sales.ProfessionalSalesDayClosureRecord
import ir.sabou.inventory.domain.sales.SalesHoldDraft
import ir.sabou.inventory.domain.sales.SalesInvoiceDetails
import ir.sabou.inventory.domain.sales.SalesInvoiceDraft
import ir.sabou.inventory.domain.sales.SalesInvoiceStatus
import ir.sabou.inventory.domain.sales.SalesLineDraft
import ir.sabou.inventory.domain.sales.SalesPaymentDraft
import ir.sabou.inventory.domain.sales.SalesPaymentMethod
import ir.sabou.inventory.domain.sales.SalesReturnDraft
import ir.sabou.inventory.domain.sales.SalesReturnLineDraft

@Composable
internal fun ProfessionalSalesScreen(
    state: SalesPosUiState,
    onSearch: (String) -> Unit,
    onPost: (SalesInvoiceDraft, () -> Unit) -> Unit,
    onReturn: (SalesReturnDraft, () -> Unit) -> Unit,
    onVoid: (Long, Long, String, () -> Unit) -> Unit,
    onPrint: (Long, () -> Unit) -> Unit,
    onSaveCustomer: (Long?, CustomerDraft, () -> Unit) -> Unit,
    onDeactivateCustomer: (Long) -> Unit,
    onHold: (SalesHoldDraft, () -> Unit) -> Unit,
    onRetrieveHold: (Long, () -> Unit) -> Unit,
    onDeleteHold: (Long) -> Unit,
    onSelectInvoice: (Long?) -> Unit,
    onResumeConsumed: () -> Unit,
    onCloseDay: (Long, String, () -> Unit) -> Unit,
    onReopenDay: (Long, String, () -> Unit) -> Unit,
    onOpenDailyControl: () -> Unit,
    onBack: () -> Unit,
) {
    var search by remember { mutableStateOf("") }
    var showSale by remember { mutableStateOf(false) }
    var showCustomers by remember { mutableStateOf(false) }
    var showHolds by remember { mutableStateOf(false) }
    var showDayControl by remember { mutableStateOf(false) }

    LaunchedEffect(state.resumeDraft) {
        if (state.resumeDraft != null) showSale = true
    }

    Scaffold(
        topBar = { ScreenHeader("صندوق فروش حرفه‌ای", "فروش جدید", { showSale = true }, onBack) },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            state.message?.let { MessageCard(it) }
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("POS تراکنشی Alpha161", fontWeight = FontWeight.Bold)
                    Text("فاکتور، پرداخت، رسپی، COGS، موجودی، حسابداری و Audit در یک تراکنش ثبت می‌شوند.", style = MaterialTheme.typography.bodySmall)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ showCustomers = true }, Modifier.weight(1f)) { Text("مشتریان") }
                OutlinedButton({ showHolds = true }, Modifier.weight(1f)) { Text("Hold / Resume") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ showDayControl = true }, Modifier.weight(1f)) { Text("بستن روز POS") }
                OutlinedButton(onClick = onOpenDailyControl, modifier = Modifier.weight(1f)) {
                    Text("کنترل Legacy")
                }
            }
            OutlinedTextField(
                value = search,
                onValueChange = { search = it; onSearch(it) },
                label = { Text("جست‌وجوی شماره فاکتور / مشتری / توضیحات") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            if (state.invoices.isEmpty()) {
                MessageCard("هنوز فاکتور حرفه‌ای ثبت نشده است. از «فروش جدید» شروع کنید.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                    items(state.invoices, key = { it.id }) { invoice ->
                        Card(onClick = { onSelectInvoice(invoice.id) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(invoice.invoiceNo, fontWeight = FontWeight.Bold)
                                    Text(statusTitle(invoice.status))
                                }
                                Text(invoice.customerName ?: "مشتری نقدی")
                                Text("خالص: ${formatMoney(invoice.netRial)} · بهای تمام‌شده: ${formatMoney(invoice.theoreticalCostRial)}")
                                Text(epochDayToPersian(invoice.businessEpochDay).display(), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSale) {
        NewProfessionalSaleDialog(
            menuItems = state.menuItems,
            customers = state.customers.filter { it.isActive },
            initialHold = state.resumeDraft,
            busy = state.busy,
            onDismiss = {
                showSale = false
                if (state.resumeDraft != null) onResumeConsumed()
            },
            onPost = { draft -> onPost(draft) { showSale = false; onResumeConsumed() } },
            onHold = { hold -> onHold(hold) { showSale = false; onResumeConsumed() } },
        )
    }
    if (showCustomers) {
        CustomerManagementDialog(
            customers = state.customers,
            busy = state.busy,
            onDismiss = { showCustomers = false },
            onSave = onSaveCustomer,
            onDeactivate = onDeactivateCustomer,
        )
    }
    if (showHolds) {
        HoldsDialog(
            state = state,
            onDismiss = { showHolds = false },
            onRetrieve = { id -> onRetrieveHold(id) { showHolds = false; showSale = true } },
            onDelete = onDeleteHold,
        )
    }
    if (showDayControl) {
        ProfessionalSalesDayControlDialog(
            closures = state.dayClosures,
            busy = state.busy,
            onDismiss = { showDayControl = false },
            onCloseDay = { day, note -> onCloseDay(day, note) { showDayControl = false } },
            onReopenDay = { day, reason -> onReopenDay(day, reason) { showDayControl = false } },
        )
    }
    val context = LocalContext.current
    state.selectedInvoice?.let { details ->
        SalesInvoiceDetailsDialog(
            details = details,
            busy = state.busy,
            onDismiss = { onSelectInvoice(null) },
            onReturn = { draft -> onReturn(draft) { onSelectInvoice(null) } },
            onVoid = { day, reason -> onVoid(details.invoice.id, day, reason) { onSelectInvoice(null) } },
            onPrint = { onPrint(details.invoice.id) { printSalesInvoice(context, details) } },
        )
    }
}

private data class PosLineForm(
    val rowId: Int,
    val menuItemId: Long? = null,
    val quantity: String = "1",
    val lineDiscount: String = "",
)

@Composable
private fun NewProfessionalSaleDialog(
    menuItems: List<MenuItem>,
    customers: List<CustomerRecord>,
    initialHold: SalesHoldDraft?,
    busy: Boolean,
    onDismiss: () -> Unit,
    onPost: (SalesInvoiceDraft) -> Unit,
    onHold: (SalesHoldDraft) -> Unit,
) {
    val today = remember { currentEpochDay() }
    var customerId by remember(initialHold?.commandId) { mutableStateOf(initialHold?.customerId) }
    var businessDay by remember(initialHold?.commandId) { mutableLongStateOf(today) }
    var dueDay by remember(initialHold?.commandId) { mutableLongStateOf(today) }
    var orderDiscount by remember(initialHold?.commandId) { mutableStateOf(initialHold?.orderDiscount?.value?.let(::formatMoneyInputFromRial).orEmpty()) }
    var service by remember(initialHold?.commandId) { mutableStateOf(initialHold?.service?.value?.let(::formatMoneyInputFromRial).orEmpty()) }
    var tax by remember(initialHold?.commandId) { mutableStateOf(initialHold?.tax?.value?.let(::formatMoneyInputFromRial).orEmpty()) }
    var notes by remember(initialHold?.commandId) { mutableStateOf(initialHold?.notes.orEmpty()) }
    var cash by remember(initialHold?.commandId) { mutableStateOf("") }
    var card by remember(initialHold?.commandId) { mutableStateOf("") }
    var transfer by remember(initialHold?.commandId) { mutableStateOf("") }
    var credit by remember(initialHold?.commandId) { mutableStateOf("") }
    var nextId by remember { mutableIntStateOf((initialHold?.lines?.size ?: 0) + 2) }
    var lines by remember(initialHold?.commandId) {
        mutableStateOf(
            initialHold?.lines?.mapIndexed { index, line ->
                PosLineForm(index + 1, line.menuItemId, formatQuantity(line.quantity.value), formatMoneyInputFromRial(line.lineDiscount.value))
            } ?: listOf(PosLineForm(1)),
        )
    }
    var localError by remember { mutableStateOf<String?>(null) }

    val lineDrafts = remember(lines, menuItems) {
        runCatching {
            lines.map { form ->
                val menu = menuItems.firstOrNull { it.id == form.menuItemId } ?: error("یک آیتم منو انتخاب نشده است.")
                SalesLineDraft(
                    menuItemId = menu.id,
                    quantity = parseQuantity(form.quantity),
                    unitPrice = MoneyRial.of(menu.salePriceRial),
                    lineDiscount = MoneyRial.of(parseMoneyInputOrZero(form.lineDiscount)),
                )
            }
        }.getOrNull()
    }
    val netPreview = remember(lineDrafts, orderDiscount, service, tax) {
        runCatching {
            val subtotal = lineDrafts.orEmpty().fold(0L) { total, line ->
                SignedLongMath.add(total, SignedLongMath.subtract(line.unitPrice.times(line.quantity).value, line.lineDiscount.value))
            }
            SignedLongMath.add(
                SignedLongMath.subtract(subtotal, parseMoneyInputOrZero(orderDiscount)),
                SignedLongMath.add(parseMoneyInputOrZero(service), parseMoneyInputOrZero(tax)),
            )
        }.getOrNull()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initialHold == null) "فروش جدید" else "ادامه سفارش نگه‌داشته‌شده") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                localError?.let { MessageCard(it, true) }
                CustomerPicker(customers, customerId, { customerId = it }, allowNone = true)
                PersianDateField("تاریخ فروش", businessDay, { businessDay = it })
                lines.forEachIndexed { index, form ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ردیف ${index + 1}", fontWeight = FontWeight.Bold)
                            MenuPicker(menuItems, form.menuItemId) { selected ->
                                lines = lines.map { if (it.rowId == form.rowId) it.copy(menuItemId = selected) else it }
                            }
                            OutlinedTextField(
                                form.quantity,
                                { value -> lines = lines.map { if (it.rowId == form.rowId) it.copy(quantity = normalizeNumberInput(value).take(16)) else it } },
                                label = { Text("تعداد") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            OutlinedTextField(
                                form.lineDiscount,
                                { value -> lines = lines.map { if (it.rowId == form.rowId) it.copy(lineDiscount = formatMoneyInput(value)) else it } },
                                label = { Text("تخفیف ردیف (${currencyUnitLabel()})") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                            if (lines.size > 1) TextButton(onClick = { lines = lines.filterNot { it.rowId == form.rowId } }) { Text("حذف ردیف") }
                        }
                    }
                }
                OutlinedButton(
                    onClick = { lines = lines + PosLineForm(nextId); nextId += 1 },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = lines.size < 50,
                ) { Text("افزودن ردیف") }
                MoneyInput(orderDiscount, { orderDiscount = it }, "تخفیف کل")
                MoneyInput(service, { service = it }, "سرویس")
                MoneyInput(tax, { tax = it }, "مالیات / عوارض")
                netPreview?.let { Text("مبلغ قابل پرداخت: ${formatMoney(it)}", fontWeight = FontWeight.Bold) }
                Text("تخصیص پرداخت", fontWeight = FontWeight.Bold)
                MoneyInput(cash, { cash = it }, "نقد")
                MoneyInput(card, { card = it }, "کارتخوان")
                MoneyInput(transfer, { transfer = it }, "حواله بانکی")
                MoneyInput(credit, { credit = it }, "اعتباری")
                if (parseMoneyInputOrZero(credit) > 0) PersianDateField("سررسید اعتبار", dueDay, { dueDay = it })
                OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                enabled = !busy && lineDrafts != null,
                onClick = {
                    try {
                        val finalLines = requireNotNull(lineDrafts)
                        val payments = buildList {
                            fun add(method: SalesPaymentMethod, raw: String) {
                                val amount = parseMoneyInputOrZero(raw)
                                if (amount > 0) add(SalesPaymentDraft(method, MoneyRial.of(amount)))
                            }
                            add(SalesPaymentMethod.CASH, cash)
                            add(SalesPaymentMethod.CARD, card)
                            add(SalesPaymentMethod.TRANSFER, transfer)
                            add(SalesPaymentMethod.CREDIT, credit)
                        }
                        onPost(
                            SalesInvoiceDraft(
                                businessEpochDay = businessDay,
                                customerId = customerId,
                                dueEpochDay = dueDay.takeIf { parseMoneyInputOrZero(credit) > 0 },
                                orderDiscount = MoneyRial.of(parseMoneyInputOrZero(orderDiscount)),
                                service = MoneyRial.of(parseMoneyInputOrZero(service)),
                                tax = MoneyRial.of(parseMoneyInputOrZero(tax)),
                                notes = notes,
                                lines = finalLines,
                                payments = payments,
                            ),
                        )
                    } catch (error: Exception) {
                        localError = error.message ?: "اطلاعات فروش کامل نیست."
                    }
                },
            ) { Text("ثبت قطعی") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDismiss) { Text("انصراف") }
                TextButton(
                    enabled = !busy && lineDrafts != null,
                    onClick = {
                        try {
                            onHold(
                                SalesHoldDraft(
                                    customerId = customerId,
                                    orderDiscount = MoneyRial.of(parseMoneyInputOrZero(orderDiscount)),
                                    service = MoneyRial.of(parseMoneyInputOrZero(service)),
                                    tax = MoneyRial.of(parseMoneyInputOrZero(tax)),
                                    notes = notes,
                                    lines = requireNotNull(lineDrafts),
                                ),
                            )
                        } catch (error: Exception) {
                            localError = error.message ?: "نگهداری سفارش انجام نشد."
                        }
                    },
                ) { Text("Hold") }
            }
        },
    )
}

@Composable
private fun CustomerManagementDialog(
    customers: List<CustomerRecord>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (Long?, CustomerDraft, () -> Unit) -> Unit,
    onDeactivate: (Long) -> Unit,
) {
    var editing by remember { mutableStateOf<CustomerRecord?>(null) }
    var name by remember(editing?.id) { mutableStateOf(editing?.name.orEmpty()) }
    var phone by remember(editing?.id) { mutableStateOf(editing?.phone.orEmpty()) }
    var nationalId by remember(editing?.id) { mutableStateOf(editing?.nationalId.orEmpty()) }
    var creditLimit by remember(editing?.id) { mutableStateOf(editing?.creditLimitRial?.let(::formatMoneyInputFromRial).orEmpty()) }
    var notes by remember(editing?.id) { mutableStateOf(editing?.notes.orEmpty()) }
    var error by remember { mutableStateOf<String?>(null) }

    fun reset() { editing = null; name = ""; phone = ""; nationalId = ""; creditLimit = ""; notes = ""; error = null }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مشتریان و اعتبار") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 600.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                error?.let { MessageCard(it, true) }
                OutlinedTextField(name, { name = it.take(120) }, label = { Text("نام مشتری") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = normalizeNumberInput(it).filter(Char::isDigit).take(15) }, label = { Text("تلفن") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(nationalId, { nationalId = normalizeNumberInput(it).filter(Char::isDigit).take(12) }, label = { Text("کد ملی / شناسه") }, modifier = Modifier.fillMaxWidth())
                MoneyInput(creditLimit, { creditLimit = it }, "سقف اعتبار")
                OutlinedTextField(notes, { notes = it.take(500) }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = !busy, onClick = {
                        try {
                            onSave(editing?.id, CustomerDraft(name, phone, nationalId, parseMoneyInputOrZero(creditLimit), notes)) { reset() }
                        } catch (e: Exception) { error = e.message }
                    }) { Text(if (editing == null) "ثبت مشتری" else "ذخیره ویرایش") }
                    if (editing != null) TextButton(onClick = { reset() }) { Text("لغو ویرایش") }
                }
                Spacer(Modifier.height(4.dp))
                customers.forEach { customer ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text("${customer.customerCode} · ${customer.name}", fontWeight = FontWeight.Bold)
                            Text("مانده: ${formatMoney(customer.outstandingRial)} · سقف: ${formatMoney(customer.creditLimitRial)}")
                            Row {
                                TextButton(onClick = { editing = customer; name = customer.name; phone = customer.phone; nationalId = customer.nationalId; creditLimit = formatMoneyInputFromRial(customer.creditLimitRial); notes = customer.notes }) { Text("ویرایش") }
                                if (customer.isActive) TextButton(onClick = { onDeactivate(customer.id) }) { Text("غیرفعال") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}

@Composable
private fun HoldsDialog(
    state: SalesPosUiState,
    onDismiss: () -> Unit,
    onRetrieve: (Long) -> Unit,
    onDelete: (Long) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("سفارش‌های نگه‌داشته‌شده") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.holds.isEmpty()) Text("سفارش Hold شده‌ای وجود ندارد.")
                state.holds.forEach { hold ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp)) {
                            Text(hold.holdNo, fontWeight = FontWeight.Bold)
                            Text("${hold.customerName ?: "بدون مشتری"} · ${hold.lineCount} ردیف · ${formatMoney(hold.grossRial)}")
                            Row {
                                TextButton(enabled = !state.busy, onClick = { onRetrieve(hold.id) }) { Text("بازیابی") }
                                TextButton(enabled = !state.busy, onClick = { onDelete(hold.id) }) { Text("حذف") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}

@Composable
private fun SalesInvoiceDetailsDialog(
    details: SalesInvoiceDetails,
    busy: Boolean,
    onDismiss: () -> Unit,
    onReturn: (SalesReturnDraft) -> Unit,
    onVoid: (Long, String) -> Unit,
    onPrint: () -> Unit,
) {
    var returnMode by remember(details.invoice.id) { mutableStateOf(false) }
    var voidMode by remember(details.invoice.id) { mutableStateOf(false) }
    var returnDay by remember { mutableLongStateOf(currentEpochDay()) }
    var reason by remember { mutableStateOf("") }
    var refundMethod by remember { mutableStateOf(SalesPaymentMethod.CASH) }
    var refundExpanded by remember { mutableStateOf(false) }
    var quantities by remember(details.invoice.id) {
        mutableStateOf(details.lines.associate { it.id to "" })
    }
    var localError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("فاکتور ${details.invoice.invoiceNo}") },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                localError?.let { MessageCard(it, true) }
                Text("وضعیت: ${statusTitle(details.invoice.status)}")
                Text("مشتری: ${details.invoice.customerName ?: "مشتری نقدی"}")
                Text("ناخالص: ${formatMoney(details.invoice.grossRial)}")
                Text("تخفیف: ${formatMoney(details.invoice.discountRial)} · سرویس: ${formatMoney(details.invoice.serviceRial)} · مالیات: ${formatMoney(details.invoice.taxRial)}")
                Text("خالص: ${formatMoney(details.invoice.netRial)}", fontWeight = FontWeight.Bold)
                Text("COGS snapshot: ${formatMoney(details.invoice.theoreticalCostRial)}")
                details.payments.forEach { Text("${it.method.title}: ${formatMoney(it.amountRial)} ${it.referenceNo}") }
                details.lines.forEach { line ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(8.dp)) {
                            Text(line.name, fontWeight = FontWeight.Bold)
                            Text("تعداد ${formatQuantity(line.quantityMicros)} · برگشتی ${formatQuantity(line.returnedQuantityMicros)} · خالص ${formatMoney(line.netRial)}")
                            if (returnMode && line.returnedQuantityMicros < line.quantityMicros) {
                                OutlinedTextField(
                                    value = quantities[line.id].orEmpty(),
                                    onValueChange = { value -> quantities = quantities + (line.id to normalizeNumberInput(value).take(16)) },
                                    label = { Text("مقدار برگشت (حداکثر ${formatQuantity(line.quantityMicros - line.returnedQuantityMicros)})") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.fillMaxWidth(),
                                )
                            }
                        }
                    }
                }
                if (returnMode || voidMode) {
                    PersianDateField(if (returnMode) "تاریخ مرجوعی" else "تاریخ ابطال", returnDay, { returnDay = it })
                    OutlinedTextField(reason, { reason = it.take(300) }, label = { Text("دلیل الزامی") }, modifier = Modifier.fillMaxWidth())
                }
                if (returnMode) {
                    Box(Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { refundExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text("روش استرداد: ${refundMethod.title}") }
                        DropdownMenu(refundExpanded, { refundExpanded = false }) {
                            SalesPaymentMethod.entries.forEach { method ->
                                DropdownMenuItem(text = { Text(method.title) }, onClick = { refundMethod = method; refundExpanded = false })
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            when {
                returnMode -> Button(enabled = !busy, onClick = {
                    try {
                        val lines = details.lines.mapNotNull { line ->
                            val raw = quantities[line.id].orEmpty()
                            if (raw.isBlank()) null else SalesReturnLineDraft(line.id, parseQuantity(raw))
                        }
                        onReturn(SalesReturnDraft(details.invoice.id, returnDay, refundMethod, reason, lines))
                    } catch (e: Exception) { localError = e.message }
                }) { Text("ثبت مرجوعی") }
                voidMode -> Button(enabled = !busy, onClick = { onVoid(returnDay, reason) }) { Text("تأیید ابطال") }
                else -> TextButton(onClick = onDismiss) { Text("بستن") }
            }
        },
        dismissButton = {
            if (!returnMode && !voidMode) {
                Row {
                    TextButton(onClick = onPrint, enabled = !busy) { Text("چاپ / چاپ مجدد") }
                    if (details.canReturn) TextButton(onClick = { returnMode = true; reason = "" }) { Text("مرجوعی جزئی/کامل") }
                    if (details.canVoid) TextButton(onClick = { voidMode = true; reason = "" }) { Text("ابطال") }
                }
            } else TextButton(onClick = { returnMode = false; voidMode = false; localError = null }) { Text("بازگشت") }
        },
    )
}

@Composable
private fun ProfessionalSalesDayControlDialog(
    closures: List<ProfessionalSalesDayClosureRecord>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onCloseDay: (Long, String) -> Unit,
    onReopenDay: (Long, String) -> Unit,
) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var note by remember { mutableStateOf("") }
    val closure = closures.firstOrNull { it.businessEpochDay == day }
    val isClosed = closure?.status == "CLOSED"
    val isReopened = closure?.status == "REOPENED"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("کنترل پایان روز POS") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PersianDateField("روز کاری", day, { day = it })
                closure?.let {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("وضعیت: ${if (isClosed) "بسته" else "بازگشایی‌شده"} · بازبینی ${it.revisionNo}", fontWeight = FontWeight.Bold)
                            Text("خالص ${formatMoney(it.netSalesRial)} · COGS ${formatMoney(it.cogsRial)}")
                            Text("نقد ${formatMoney(it.cashRial)} · کارت ${formatMoney(it.cardRial)} · انتقال ${formatMoney(it.transferRial)} · اعتباری ${formatMoney(it.creditRial)}")
                            Text("فاکتور ${it.invoiceCount} · مرجوعی ${it.returnCount}", style = MaterialTheme.typography.bodySmall)
                            if (it.reopenReason.isNotBlank()) Text("دلیل بازگشایی: ${it.reopenReason}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(300) },
                    label = { Text(if (isClosed) "دلیل بازگشایی (الزامی)" else "یادداشت بستن روز") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
                if (isReopened) {
                    Text("پس از اصلاحات مجاز، دوباره «بستن روز» را بزنید؛ revision جدید و snapshot جدید ثبت می‌شود.", style = MaterialTheme.typography.bodySmall)
                }
                Text("بازگشایی فقط برای مالک سامانه مجاز است و در Audit ثبت می‌شود.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            if (isClosed) {
                Button(enabled = !busy && note.trim().length in 3..300, onClick = { onReopenDay(day, note) }) { Text("بازگشایی کنترل‌شده") }
            } else {
                Button(enabled = !busy, onClick = { onCloseDay(day, note) }) { Text(if (isReopened) "بستن مجدد روز" else "بستن روز") }
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun MenuPicker(menuItems: List<MenuItem>, selectedId: Long?, onSelected: (Long) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(menuItems.firstOrNull { it.id == selectedId }?.let { "${it.name} · ${formatMoney(it.salePriceRial)}" } ?: "انتخاب آیتم منو")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            menuItems.forEach { menu ->
                DropdownMenuItem(text = { Text("${menu.name} · ${formatMoney(menu.salePriceRial)}") }, onClick = { expanded = false; onSelected(menu.id) })
            }
        }
    }
}

@Composable
private fun CustomerPicker(customers: List<CustomerRecord>, selectedId: Long?, onSelected: (Long?) -> Unit, allowNone: Boolean) {
    var expanded by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(customers.firstOrNull { it.id == selectedId }?.name ?: "مشتری نقدی / بدون مشتری")
        }
        DropdownMenu(expanded, { expanded = false }) {
            if (allowNone) DropdownMenuItem(text = { Text("مشتری نقدی / بدون مشتری") }, onClick = { expanded = false; onSelected(null) })
            customers.forEach { customer ->
                DropdownMenuItem(
                    text = { Text("${customer.name} · مانده ${formatMoney(customer.outstandingRial)}") },
                    onClick = { expanded = false; onSelected(customer.id) },
                )
            }
        }
    }
}

@Composable
private fun MoneyInput(value: String, onValue: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValue(formatMoneyInput(it)) },
        label = { Text("$label (${currencyUnitLabel()})") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
}

private fun statusTitle(status: SalesInvoiceStatus): String = when (status) {
    SalesInvoiceStatus.POSTED -> "ثبت‌شده"
    SalesInvoiceStatus.PARTIALLY_RETURNED -> "مرجوعی جزئی"
    SalesInvoiceStatus.RETURNED -> "مرجوع کامل"
    SalesInvoiceStatus.VOIDED -> "باطل‌شده"
    SalesInvoiceStatus.LEGACY_UNKNOWN -> "نامشخص"
}
