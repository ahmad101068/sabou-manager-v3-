# تغییرات Alpha160.1 — Runtime Crash Repair

- نسخه: `3.0.0-alpha160.1-runtime-crash-repair`
- `versionCode`: 204
- Room schema: 44 (بدون تغییر ساختار یا مهاجرت تخریبی)

## اصلاح اصلی

کلید خارجی `stock_transfer_lines.transferId` در زنجیره مهاجرت قدیمی اکنون به
جدول نهایی `stock_transfers` اشاره می‌کند، نه نام موقت
`stock_transfers_v43`. این اصلاح خطای واقعی Room با پیام
`Migration didn't properly handle: stock_transfer_lines` را برطرف می‌کند.

## تست‌های Runtime

- تست ورود احراز هویت‌شده و زنده‌ماندن صفحه اصلی Compose اضافه شد.
- ارتقای واقعی APK/دیتابیس Alpha159 به Alpha160 بدون پاک‌کردن داده تست شد.
- Flowهای دوره حقوق، Batch، تاریخچه Payslip و Timeline پس از Migration خوانده شدند.
- تست مهاجرت کامل 1→44 با اعتبارسنجی واقعی Room اصلاح و اجرا شد.
- وابستگی `AndroidJUnitRunner` به‌صورت صریح به test APK اضافه شد.

جزئیات و محدودیت تأیید دستگاه فیزیکی در
`ALPHA160-RUNTIME-CRASH-REPORT.md` ثبت شده است.
