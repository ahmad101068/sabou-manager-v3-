# Alpha160 Runtime Crash Diagnosis and Repair

Date: 2026-08-09  
Candidate: `3.0.0-alpha160.1-runtime-crash-repair` (`versionCode=204`, Room schema 44)  
Application ID: `ir.sabou.inventory`

## Reproduction Result

| Case | Environment | Result after repair |
|---|---|---|
| Clean install, owner creation, authenticated entry | Android emulator API 35, Pixel 5 profile | PASS |
| Genuine Alpha159 app/database upgraded in place to Alpha160 | Android emulator API 35, Pixel 5 profile | PASS |
| Full production migration chain 1 to 44 with Room validation | Android emulator API 35 | PASS |

The clean-entry smoke test launched `MainActivity`, verified a rendered
`AndroidComposeView`, and kept the activity in the resumed state for an additional
eight-second stability window. The upgrade test first ran the real Alpha159 APK,
created representative employee, contract, attendance, advance and payroll data,
then installed Alpha160 with `adb install -r` without clearing application data.
It opened the production SQLCipher/Room container, collected payroll periods,
batches, employee payslips and employee timeline, and entered the main Compose UI.

## Exact Runtime Evidence

The clean and direct 43-to-44 paths did not reproduce a fatal exception. Exercising
the full supported migration chain did reproduce a deterministic Room runtime
validation exception:

```text
java.lang.IllegalStateException: Migration didn't properly handle:
stock_transfer_lines(ir.sabou.inventory.data.db.StockTransferLineEntity)
Expected foreign key: transferId -> stock_transfers(id)
Found foreign key:    transferId -> stock_transfers_v43(id)
at ir.sabou.inventory.data.db.FullMigration1ToCurrentTest
    .migratesVersionOneWithoutDestructiveFallback(FullMigration1ToCurrentTest.kt:41)
```

The project-owned defect was in
`EnterpriseMigrations.upgradeStockTransfersToV43`: the replacement child table was
created with a foreign key to the temporary parent table name
`stock_transfers_v43`. SQLite retained that parent name after the parent table was
renamed, so Room schema validation rejected the database.

Root-cause classification: **A. ROOM_SCHEMA_VALIDATION**.

No physical-phone Logcat was available. Therefore this report does not assert that
the user's unseen phone exception had an identical stack. It records the exact
runtime defect reproduced on Android and the clean/upgrade paths verified after the
repair.

## Exact Fix

The migration now creates `stock_transfer_lines_v43.transferId` with a foreign key
to the final table name `stock_transfers(id)`. No schema downgrade, destructive
migration, validation suppression, database deletion, or exception swallowing was
introduced.

The Android test runner is now an explicit `androidTestImplementation` dependency.
This fixes the diagnostic infrastructure failure in which the test APK declared
`AndroidJUnitRunner` but did not package the runner class.

`FullMigration1ToCurrentTest` now reads exported schema JSON from the instrumentation
APK's assets, which is where Gradle packages the test assets. The upgrade smoke test
is fixture-gated during a generic connected-test run and is explicitly enabled only
by the external Alpha159 seed/upgrade gate.

## Database, Migration, and Legacy Data Impact

- Room schema remains version 44; entity shape is unchanged.
- Failed migrations remain transactional and can be retried with the corrected SQL.
- Existing employee, contract, attendance, advance and payroll rows are preserved.
- Direct 43-to-44 migration and its deterministic legacy payroll projections pass.
- The full 1-to-44 migration now matches Room's expected foreign-key metadata.
- No fake payroll components or destructive fallback were added.

## HR Runtime Impact

Both empty and migrated HR states can collect:

- payroll periods;
- payroll batches;
- employee payroll history;
- employee timeline.

The authenticated dashboard remains rendered after eager ViewModel/service
construction. No broad Flow exception suppression or lazy-loading workaround was
used.

## Why Existing CI Missed It

Previous CI compiled, assembled and ran JVM tests but did not execute the installed
application and full migration chain through Android Room validation. In addition,
the first diagnostic command relied on `adb shell am instrument`'s shell exit code;
that command can return zero even when JUnit reports `FAILURES!!!`. The runtime gate
now parses instrumentation output for `OK (...)` and rejects failures or process
crashes explicitly.

## Tests Added or Repaired

- `Alpha160CleanEntryRuntimeSmokeTest`
- `Alpha160UpgradeEntryRuntimeSmokeTest`
- `FullMigration1ToCurrentTest` Android asset-context correction
- explicit AndroidX test-runner packaging

## Verification Evidence

GitHub Actions diagnostic run `31328597301` on Android API 35 passed:

- clean authenticated entry: `OK (1 test)`;
- `HrPayrollMigration43To44Test`: `OK (1 test)`;
- `FullMigration1ToCurrentTest`: `OK (1 test)`;
- genuine Alpha159 seed: `OK (1 test)`;
- production Alpha159-to-Alpha160 upgrade and HR/UI smoke: `OK (1 test)`;
- Alpha159 and Alpha160 app/test APK assembly: PASS.

Host-side foundation, HR migration, JVM and complete connected-test gates must be
recorded against the final packaged candidate; their final status belongs in the
delivery report rather than being inferred from the diagnostic run.

## Remaining Risk

The user's physical-device exception chain and device/API details were not supplied.
The repaired candidate must still be installed on that phone as the final field
confirmation. If it exits there again, capture unfiltered Logcat including the full
`Caused by` chain before making any further patch.
