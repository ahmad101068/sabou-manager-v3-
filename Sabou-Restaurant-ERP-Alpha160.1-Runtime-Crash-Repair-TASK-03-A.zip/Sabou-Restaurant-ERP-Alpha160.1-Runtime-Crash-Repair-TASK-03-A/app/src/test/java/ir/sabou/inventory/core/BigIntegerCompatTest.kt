package ir.sabou.inventory.core

import java.math.BigInteger
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class BigIntegerCompatTest {
    @Test
    fun exactLongConversionPreservesBoundsAndRejectsOverflow() {
        assertEquals(Long.MIN_VALUE, BigInteger.valueOf(Long.MIN_VALUE).toLongExactCompat())
        assertEquals(Long.MAX_VALUE, BigInteger.valueOf(Long.MAX_VALUE).toLongExactCompat())
        assertEquals(0L, BigInteger.ZERO.toLongExactCompat())

        assertThrows(ArithmeticException::class.java) {
            BigInteger.valueOf(Long.MAX_VALUE).add(BigInteger.ONE).toLongExactCompat()
        }
        assertThrows(ArithmeticException::class.java) {
            BigInteger.valueOf(Long.MIN_VALUE).subtract(BigInteger.ONE).toLongExactCompat()
        }
    }
}
