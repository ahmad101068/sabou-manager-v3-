package ir.sabou.inventory.ui

import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.personnel.PayrollStatus

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import android.app.Activity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.data.BackupPolicy
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.ui.theme.SabouBrand
import ir.sabou.inventory.organizationDisplayTitle
import kotlinx.coroutines.delay

@Composable
fun SabouApp(
    container: AppContainer,
    organizationName: String,
    onOrganizationNameChange: (String) -> Unit,
    themePreference: ThemePreference,
    currencyUnit: CurrencyUnit,
    fontScalePreference: FontScalePreference,
    backupPolicy: BackupPolicy,
    notificationPermissionGranted: Boolean,
    onRequestNotificationPermission: () -> Unit,
    onThemePreferenceChange: (ThemePreference) -> Unit,
    onCurrencyUnitChange: (CurrencyUnit) -> Unit,
    onFontScalePreferenceChange: (FontScalePreference) -> Unit,
    onBackupPolicyChange: (BackupPolicy) -> Unit,
    onAppPreferencesReset: () -> Unit,
) {
    val dashboard: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(container.dashboardRepository),
    )
    val operations: OperationsViewModel = viewModel(
        factory = OperationsViewModel.factory(
            container.operationsRepository,
            container.purchaseRepository,
            container.procurementRepository,
            container.securityRepository,
        ),
    )
    val inventory: InventoryWorkspaceViewModel = viewModel(
        factory = InventoryWorkspaceViewModel.factory(
            container.inventoryRepository,
            container.inventoryReadService,
            container.inventoryLotService,
            container.inventoryCountService,
            container.inventoryWasteService,
            container.inventoryTransferService,
            container.inventoryReplenishmentService,
            container.procurementRepository,
            container.securityRepository,
        ),
    )
    val accounting: AccountingViewModel = viewModel(
        factory = AccountingViewModel.factory(container.accountingRepository),
    )
    val sales: DailySalesViewModel = viewModel(
        factory = DailySalesViewModel.factory(
            container.dailySalesRepository,
            container.recipeRepository,
            container.securityRepository,
        ),
    )
    val recipes: RecipeViewModel = viewModel(
        factory = RecipeViewModel.factory(container.recipeRepository, container.operationsRepository),
    )
    val personnel: PersonnelViewModel = viewModel(
        factory = PersonnelViewModel.factory(container.personnelRepository, container.hrPayrollService),
    )
    val performance: PerformanceViewModel = viewModel(factory = PerformanceViewModel.factory(container.performanceRepository))
    val sync: SyncViewModel = viewModel(factory = SyncViewModel.factory(container.syncRepository, container))
    val managementControl: ManagementControlViewModel = viewModel(
        factory = ManagementControlViewModel.factory(
            container.managementControlRepository,
            container.securityRepository,
        ),
    )
    val assets: AssetViewModel = viewModel(factory = AssetViewModel.factory(container.assetRepository))
    val alerts: AlertViewModel = viewModel(factory = AlertViewModel.factory(container.alertRepository))
    val security: SecurityViewModel = viewModel(
        factory = SecurityViewModel.factory(container.securityRepository, container),
    )
    val dashboardState by dashboard.state.collectAsStateWithLifecycle()
    val operationsState by operations.state.collectAsStateWithLifecycle()
    val inventoryState by inventory.state.collectAsStateWithLifecycle()
    val accountingState by accounting.state.collectAsStateWithLifecycle()
    val salesState by sales.state.collectAsStateWithLifecycle()
    val recipeState by recipes.state.collectAsStateWithLifecycle()
    val alertState by alerts.state.collectAsStateWithLifecycle()
    val securityState by security.state.collectAsStateWithLifecycle()
    val personnelState by personnel.state.collectAsStateWithLifecycle()
    val hrPayrollState by personnel.hrState.collectAsStateWithLifecycle()
    val performanceState by performance.state.collectAsStateWithLifecycle()
    val syncState by sync.state.collectAsStateWithLifecycle()
    val managementControlState by managementControl.state.collectAsStateWithLifecycle()
    val assetState by assets.state.collectAsStateWithLifecycle()
    AutoClearMessage(operationsState.message, operations::clearMessage)
    AutoClearMessage(inventoryState.message, inventory::clearMessage)
    AutoClearMessage(accountingState.message, accounting::clearMessage)
    AutoClearMessage(salesState.message, sales::clearMessage)
    AutoClearMessage(recipeState.message, recipes::clearMessage)
    AutoClearMessage(alertState.message, alerts::clearMessage)
    AutoClearMessage(securityState.message, security::clearMessage)
    AutoClearMessage(personnelState.message, personnel::clearMessage)
    AutoClearMessage(performanceState.message, performance::clearMessage)
    AutoClearMessage(syncState.message, sync::clearMessage)
    AutoClearMessage(managementControlState.message, managementControl::clearMessage)
    AutoClearMessage(assetState.message, assets::clearMessage)
    var routeStack by rememberSaveable { mutableStateOf(listOf(AppScreen.SECURITY.name)) }
    var requestedEmployeeProfileId by rememberSaveable { mutableStateOf<Long?>(null) }
    val screen = AppScreen.valueOf(routeStack.last())
    var showExitConfirmation by rememberSaveable { mutableStateOf(false) }
    val activity = LocalContext.current as? Activity

    fun navigate(target: AppScreen) {
        if (target != screen && canOpenScreen(securityState.currentUser, target)) {
            routeStack = routeStack + target.name
        }
    }

    fun navigateBack() {
        if (routeStack.size > 1) {
            routeStack = routeStack.dropLast(1)
        } else {
            showExitConfirmation = true
        }
    }

    BackHandler {
        if (screen == AppScreen.DASHBOARD || routeStack.size == 1) {
            showExitConfirmation = true
        } else {
            navigateBack()
        }
    }

    if (showExitConfirmation) {
        AlertDialog(
            onDismissRequest = { showExitConfirmation = false },
            title = { Text("خروج از برنامه") },
            text = { Text("آیا می‌خواهید از برنامه خارج شوید؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showExitConfirmation = false
                        activity?.finish()
                    },
                ) {
                    Text("خروج")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirmation = false }) {
                    Text("انصراف")
                }
            },
        )
    }

    LaunchedEffect(securityState.currentUser, securityState.users.size) {
        if (securityState.currentUser == null) {
            if (screen != AppScreen.SECURITY || routeStack.size != 1) {
                routeStack = listOf(AppScreen.SECURITY.name)
            }
        } else if (!canOpenScreen(securityState.currentUser, screen)) {
            routeStack = listOf(AppScreen.DASHBOARD.name)
        } else if (screen == AppScreen.SECURITY && routeStack.size == 1) {
            routeStack = listOf(AppScreen.DASHBOARD.name)
        }
    }

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        when (screen.group) {
            AppRouteGroup.HOME -> DashboardScreen(
                state = dashboardState,
                operationsState = operationsState,
                accountingState = accountingState,
                salesState = salesState,
                personnelState = personnelState,
                currentUser = securityState.currentUser,
                organizationName = organizationName,
                onSearch = { navigate(AppScreen.GLOBAL_SEARCH) },
                onSettings = { navigate(AppScreen.SETTINGS) },
                onOpen = { target ->
                    if (target != null) navigate(target) else operations.clearMessage()
                },
            )

            AppRouteGroup.OPERATIONS -> OperationsRoutes(
                screen = screen,
                operationsState = operationsState,
                operations = operations,
                inventoryState = inventoryState,
                inventory = inventory,
                salesState = salesState,
                sales = sales,
                recipeState = recipeState,
                recipes = recipes,
                accounting = accounting,
                navigate = { navigate(it) },
                navigateBack = { navigateBack() },
            )

            AppRouteGroup.ACCOUNTING -> AccountingRoutes(
                screen = screen,
                state = accountingState,
                accounting = accounting,
                sales = sales,
                navigate = { navigate(it) },
                navigateBack = { navigateBack() },
            )

            AppRouteGroup.WORKFORCE -> WorkforceRoutes(
                screen = screen,
                personnelState = personnelState,
                hrPayrollState = hrPayrollState,
                personnel = personnel,
                performanceState = performanceState,
                performance = performance,
                assetState = assetState,
                assets = assets,
                workforceControlState = managementControlState,
                workforceControl = managementControl,
                requestedEmployeeProfileId = requestedEmployeeProfileId,
                onProfileRequestConsumed = { requestedEmployeeProfileId = null },
                navigateBack = { navigateBack() },
            )

            AppRouteGroup.MANAGEMENT -> ManagementRoutes(
                screen = screen,
                dashboardState = dashboardState,
                operationsState = operationsState,
                operations = operations,
                inventory = inventory,
                accountingState = accountingState,
                accounting = accounting,
                salesState = salesState,
                sales = sales,
                personnelState = personnelState,
                assetState = assetState,
                managementState = managementControlState,
                management = managementControl,
                alertState = alertState,
                alerts = alerts,
                currentUser = securityState.currentUser,
                notificationPermissionGranted = notificationPermissionGranted,
                onRequestNotificationPermission = onRequestNotificationPermission,
                onRequestEmployeeProfile = { requestedEmployeeProfileId = it },
                navigate = { navigate(it) },
                navigateBack = { navigateBack() },
            )

            AppRouteGroup.ADMIN -> AdminRoutes(
                screen = screen,
                securityState = securityState,
                security = security,
                syncState = syncState,
                sync = sync,
                organizationName = organizationName,
                onOrganizationNameChange = onOrganizationNameChange,
                themePreference = themePreference,
                currencyUnit = currencyUnit,
                fontScalePreference = fontScalePreference,
                backupPolicy = backupPolicy,
                onThemePreferenceChange = onThemePreferenceChange,
                onCurrencyUnitChange = onCurrencyUnitChange,
                onFontScalePreferenceChange = onFontScalePreferenceChange,
                onBackupPolicyChange = onBackupPolicyChange,
                onAppPreferencesReset = onAppPreferencesReset,
                navigate = { navigate(it) },
                navigateBack = { navigateBack() },
            )
        }
    }

}

@Composable
private fun AutoClearMessage(message: String?, onClear: () -> Unit) {
    LaunchedEffect(message) {
        if (message != null) {
            delay(2_500L)
            onClear()
        }
    }
}
