package ir.sabou.inventory.data.repository

import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.security.SegregationOfDuties

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.CorrelationId
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.EmployeeEntity
import ir.sabou.inventory.data.db.EmployeePrivateProfileEntity
import ir.sabou.inventory.data.db.EmploymentAssignmentEntity
import ir.sabou.inventory.data.db.EmploymentContractVersionEntity
import ir.sabou.inventory.data.db.AttendanceEventEntity
import ir.sabou.inventory.data.db.AttendanceCorrectionEntity
import ir.sabou.inventory.data.db.LeaveLedgerEntryEntity
import ir.sabou.inventory.data.db.EmployeeAdvanceEntity
import ir.sabou.inventory.data.db.EmployeeContractEntity
import ir.sabou.inventory.data.db.AttendanceEntity
import ir.sabou.inventory.data.db.LeaveEntity
import ir.sabou.inventory.data.db.PayrollRunEntity
import ir.sabou.inventory.data.db.PayrollAdvanceAllocationEntity
import ir.sabou.inventory.data.db.PayrollPolicyEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.data.treasury.LegacyTreasuryChannelAdapter
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractRecord
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.EmployeePrivateProfile
import ir.sabou.inventory.domain.personnel.EmploymentAssignment
import ir.sabou.inventory.domain.personnel.EmploymentContractVersion
import ir.sabou.inventory.domain.personnel.EmploymentContractType
import ir.sabou.inventory.domain.personnel.EmploymentContractStatus
import ir.sabou.inventory.domain.personnel.EmploymentStatus
import ir.sabou.inventory.domain.personnel.EmploymentStatusTransitionValidator
import ir.sabou.inventory.domain.personnel.EffectiveContractResolver
import ir.sabou.inventory.domain.personnel.AttendanceEvent
import ir.sabou.inventory.domain.personnel.AttendanceEventType
import ir.sabou.inventory.domain.personnel.AttendanceSource
import ir.sabou.inventory.domain.personnel.AttendanceEventAggregator
import ir.sabou.inventory.domain.personnel.AttendanceAggregationPolicy
import ir.sabou.inventory.domain.personnel.AttendanceCorrectionCodec
import ir.sabou.inventory.domain.personnel.AttendanceCorrectionSnapshot
import ir.sabou.inventory.domain.personnel.DailyAttendanceStatus
import ir.sabou.inventory.domain.personnel.DailyAttendanceSummaryV2
import ir.sabou.inventory.domain.personnel.LeaveType
import ir.sabou.inventory.domain.personnel.LeaveStatus
import ir.sabou.inventory.domain.personnel.LeaveGrantDraft
import ir.sabou.inventory.domain.personnel.LeaveBalance
import ir.sabou.inventory.domain.personnel.LeaveBalanceCalculator
import ir.sabou.inventory.domain.personnel.LeaveLedgerEntry
import ir.sabou.inventory.domain.personnel.LeaveLedgerEntryType
import ir.sabou.inventory.domain.personnel.PendingLeaveUsage
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.AttendanceCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollPolicy
import ir.sabou.inventory.domain.personnel.AttendancePayrollAdjustment
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveRecord
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollCalculation
import ir.sabou.inventory.domain.personnel.PayrollCalculator
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PayrollStatus
import ir.sabou.inventory.domain.personnel.PayrollPolicyDraft
import ir.sabou.inventory.domain.personnel.PayrollPolicyRecord
import ir.sabou.inventory.domain.personnel.PayrollReversalDraft
import ir.sabou.inventory.domain.personnel.AdvanceDeductionAllocator
import ir.sabou.inventory.domain.personnel.OpenAdvanceBalance
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.accounting.JournalStatus
import ir.sabou.inventory.domain.accounting.AccountingPostingContext
import ir.sabou.inventory.domain.accounting.BalancedJournalDraft
import ir.sabou.inventory.domain.accounting.JournalLineDraft
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.treasury.TreasuryChannel
import java.security.MessageDigest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class LocalPersonnelRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : PersonnelRepository {
    private val personnel get() = database.personnelDao()
    private val hr get() = database.hrPayrollDao()
    private val accounting get() = database.accountingDao()
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)
    private val auditWriter = LocalAuditEventWriter(database)

    override val employees: Flow<List<EmployeeRecord>> = combine(
        personnel.observeEmployees(),
        hr.observePrivateProfiles(),
        hr.observeLatestContractStatuses(),
    ) { rows, privateProfiles, contractStatuses ->
        val privateByEmployee = privateProfiles.associateBy { it.employeeId }
        val contractStatusByEmployee = contractStatuses.associate { row ->
            row.employeeId to EmploymentContractStatus.fromStoredValue(row.status)
        }
        rows.map {
            val privateProfile = privateByEmployee[it.id]
            EmployeeRecord(
                id = it.id, name = it.name, fatherName = it.fatherName, jobTitle = it.jobTitle, phone = it.phone,
                monthlySalaryRial = it.monthlySalaryRial, isActive = EmploymentStatus.fromStoredValue(it.status) == EmploymentStatus.ACTIVE, nationalId = null,
                birthEpochDay = it.birthEpochDay, hireEpochDay = it.hireEpochDay, employeeCode = it.employeeCode,
                branchName = it.branchName, insuranceNumber = null, bankCard = null,
                address = it.address, emergencyContact = it.emergencyContact,
                firstName = it.firstName, lastName = it.lastName, displayName = it.displayName.ifBlank { it.name },
                email = it.email, department = it.department, locationId = it.locationId, managerId = it.managerId,
                employmentStatus = EmploymentStatus.fromStoredValue(it.status), terminationEpochDay = it.terminationEpochDay,
                notes = it.notes,
                maskedBankAccount = (privateProfile?.bankAccountLast4 ?: privateProfile?.ibanLast4 ?: it.bankCard).maskedLastFour(),
                contractStatus = contractStatusByEmployee[it.id],
            )
        }
    }

    override val payrolls: Flow<List<PayrollRecord>> = personnel.observePayrolls().map { rows ->
        rows.map {
            PayrollRecord(
                it.id,
                it.employeeId,
                it.employeeName,
                it.periodYear,
                it.periodMonth,
                it.revisionNo,
                it.grossPayRial,
                it.netPayRial,
                it.paymentEpochDay,
                LegacyTreasuryChannelAdapter.fromPersonnelStoredValue(it.paymentMethod),
                PayrollStatus.fromStoredValue(it.status),
                it.reversalEpochDay,
                it.reversalReason,
            )
        }
    }

    override val attendance: Flow<List<AttendanceRecord>> = personnel.observeAttendance().map { rows ->
        rows.map { it.toRecord() }
    }

    override val leaves: Flow<List<LeaveRecord>> = personnel.observeLeaves().map { rows -> rows.map { it.toRecord() } }
    override val pendingLeaves: Flow<List<LeaveRecord>> = personnel.observePendingLeaves().map { rows -> rows.map { it.toRecord() } }
    override val payrollPolicies: Flow<List<PayrollPolicyRecord>> = personnel.observePayrollPolicies().map { rows ->
        rows.map { PayrollPolicyRecord(
            it.id, it.title, it.effectiveFromEpochDay, it.effectiveToEpochDay, it.overtimeHourlyRateRial,
            it.absenceDailyDeductionRial, it.lateMinuteDeductionRial, it.createdBy, it.versionNo,
            it.overtimeMultiplierBasisPoints, it.insuranceBasisPoints, it.taxBasisPoints,
        ) }
    }

    override suspend fun savePayrollPolicy(draft: PayrollPolicyDraft): Long {
        val actor = authorizer.require(Permission.PAYROLL_CREATE)
        val valid = draft.validated()
        return database.withTransaction {
            personnel.openPayrollPolicyBefore(valid.effectiveFromEpochDay)?.let { previous ->
                check(personnel.closeOpenPayrollPolicy(previous.id, valid.effectiveFromEpochDay - 1L) == 1) {
                    "بستن نسخه قبلی سیاست حقوق انجام نشد."
                }
            }
            require(!personnel.payrollPolicyOverlaps(valid.effectiveFromEpochDay, valid.effectiveToEpochDay ?: Long.MAX_VALUE)) {
                "بازه این سیاست با سیاست حقوق دیگری هم‌پوشانی دارد."
            }
            val now = clock()
            personnel.insertPayrollPolicy(PayrollPolicyEntity(
                title = valid.title, effectiveFromEpochDay = valid.effectiveFromEpochDay,
                effectiveToEpochDay = valid.effectiveToEpochDay, overtimeHourlyRateRial = valid.overtimeHourlyRateRial,
                absenceDailyDeductionRial = valid.absenceDailyDeductionRial, lateMinuteDeductionRial = valid.lateMinuteDeductionRial,
                versionNo = 1, overtimeMultiplierBasisPoints = valid.overtimeMultiplierBasisPoints,
                insuranceBasisPoints = valid.insuranceBasisPoints, taxBasisPoints = valid.taxBasisPoints,
                createdBy = actor.displayName, createdByActorId = actor.id, createdAtEpochMillis = now,
                correlationId = "payroll_policy:${GlobalId.new().value}",
            )).also { syncRecorder?.record("PAYROLL_POLICY", it, "CREATE", now) }
        }
    }

    override suspend fun saveEmployee(id: Long?, draft: EmployeeDraft): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            if (id == null) {
                if (valid.nationalId.isNotBlank() || valid.insuranceNumber.isNotBlank() || valid.bankCard.isNotBlank()) {
                    authorizer.require(Permission.EMPLOYEE_SENSITIVE_EDIT)
                }
                val employeeCode = valid.employeeCode.ifBlank { newEmployeeCode() }
                val employeeId = personnel.insertEmployee(EmployeeEntity(name = valid.name, firstName = valid.firstName, lastName = valid.lastName,
                    displayName = valid.displayName.ifBlank { valid.name }, fatherName = valid.fatherName, employeeCode = employeeCode,
                    jobTitle = valid.jobTitle, department = valid.department.ifBlank { "UNASSIGNED" }, branchName = valid.branchName,
                    locationId = valid.locationId, managerId = valid.managerId, phone = valid.phone, email = valid.email.takeIf { it.isNotBlank() },
                    nationalId = null, birthEpochDay = valid.birthEpochDay, hireEpochDay = valid.hireEpochDay,
                    terminationEpochDay = valid.terminationEpochDay, insuranceNumber = null,
                    bankCard = null, address = valid.address, emergencyContact = valid.emergencyContact,
                    notes = valid.notes, monthlySalaryRial = valid.monthlySalaryRial, leaveBalanceMicros = 0,
                    status = valid.employmentStatus.storedValue, createdAtEpochMillis = now, updatedAtEpochMillis = now,
                    createdByActorId = actor.id, updatedByActorId = actor.id))
                savePrivateProfile(employeeId, valid, now, actor.id, null)
                valid.hireEpochDay?.let { hireDay ->
                    hr.insertAssignment(
                        EmploymentAssignmentEntity(
                            employeeId = employeeId, effectiveFromEpochDay = hireDay, effectiveToEpochDay = null,
                            jobTitle = valid.jobTitle, department = valid.department.ifBlank { "UNASSIGNED" }, branchName = valid.branchName,
                            locationId = valid.locationId, managerId = valid.managerId, reason = "EMPLOYEE_CREATED",
                            createdAtEpochMillis = now, createdByActorId = actor.id,
                            correlationId = "employee:$employeeId:create",
                        ),
                    )
                }
                auditWriter.appendAuthorized(
                    authorizer, "CREATE", "EMPLOYEE", employeeId, "ایجاد پروفایل پرسنل ${valid.displayName.ifBlank { valid.name }}",
                    now, valid.hireEpochDay, "ایجاد پرسنل", null,
                    "employeeCode=$employeeCode;status=${valid.employmentStatus.storedValue}", "employee:$employeeId:create",
                )
                syncRecorder?.record("EMPLOYEE", employeeId, "CREATE", now)
                employeeId
            } else {
                val current = personnel.employeeById(id) ?: error("پرسنل پیدا نشد.")
                val fromStatus = EmploymentStatus.fromStoredValue(current.status)
                EmploymentStatusTransitionValidator.requireAllowed(fromStatus, valid.employmentStatus, valid.terminationEpochDay)
                val employeeCode = current.employeeCode ?: valid.employeeCode.ifBlank { newEmployeeCode() }
                require(valid.employeeCode.isBlank() || valid.employeeCode == employeeCode) { "کد پرسنلی پس از ایجاد قابل تغییر نیست." }
                val privateChanged = valid.nationalId.isNotBlank() || valid.insuranceNumber.isNotBlank() || valid.bankCard.isNotBlank()
                if (privateChanged) authorizer.require(Permission.EMPLOYEE_SENSITIVE_EDIT)
                val assignmentChanged = current.jobTitle != valid.jobTitle || current.department != valid.department.ifBlank { "UNASSIGNED" } ||
                    current.branchName != valid.branchName || current.locationId != valid.locationId || current.managerId != valid.managerId
                if (assignmentChanged) {
                    val effectiveDay = requireNotNull(valid.assignmentEffectiveEpochDay) { "تاریخ اثر تغییر شغلی الزامی است." }
                    hr.openAssignment(id)?.let { assignment ->
                        require(effectiveDay > assignment.effectiveFromEpochDay) { "تاریخ اثر باید بعد از شروع انتساب فعلی باشد." }
                        check(hr.closeAssignment(assignment.id, effectiveDay - 1) == 1) { "بستن انتساب قبلی انجام نشد." }
                    }
                    hr.insertAssignment(
                        EmploymentAssignmentEntity(
                            employeeId = id, effectiveFromEpochDay = effectiveDay, effectiveToEpochDay = null,
                            jobTitle = valid.jobTitle, department = valid.department.ifBlank { "UNASSIGNED" }, branchName = valid.branchName,
                            locationId = valid.locationId, managerId = valid.managerId, reason = "EMPLOYMENT_CHANGE",
                            createdAtEpochMillis = now, createdByActorId = actor.id,
                            correlationId = "employee:$id:assignment:$effectiveDay",
                        ),
                    )
                }
                check(personnel.updateEmployee(current.copy(name=valid.name, firstName=valid.firstName, lastName=valid.lastName,
                    displayName=valid.displayName.ifBlank { valid.name }, fatherName=valid.fatherName, employeeCode=employeeCode,
                    jobTitle=valid.jobTitle, department=valid.department.ifBlank { "UNASSIGNED" }, branchName=valid.branchName,
                    locationId=valid.locationId, managerId=valid.managerId, phone=valid.phone, email=valid.email.takeIf { it.isNotBlank() },
                    nationalId=null, birthEpochDay=valid.birthEpochDay, hireEpochDay=valid.hireEpochDay,
                    terminationEpochDay=valid.terminationEpochDay, insuranceNumber=null,
                    bankCard=null, address=valid.address, emergencyContact=valid.emergencyContact,
                    notes=valid.notes, monthlySalaryRial=valid.monthlySalaryRial, status=valid.employmentStatus.storedValue,
                    updatedAtEpochMillis=now, updatedByActorId=actor.id)) == 1)
                savePrivateProfile(id, valid, now, actor.id, current)
                auditWriter.appendAuthorized(
                    authorizer, "UPDATE", "EMPLOYEE", id, "ویرایش پروفایل پرسنل ${valid.displayName.ifBlank { valid.name }}",
                    now, valid.assignmentEffectiveEpochDay, "ویرایش پرسنل",
                    "employeeCode=${current.employeeCode};status=${current.status};jobTitle=${current.jobTitle}",
                    "employeeCode=$employeeCode;status=${valid.employmentStatus.storedValue};jobTitle=${valid.jobTitle}",
                    "employee:$id:update:$now",
                )
                syncRecorder?.record("EMPLOYEE", id, "UPDATE", now)
                id
            }
        }
    }

    override suspend fun transitionEmploymentStatus(id: Long, to: EmploymentStatus, terminationEpochDay: Long?) {
        val actor = authorizer.require(Permission.PERSONNEL)
        database.withTransaction {
            val current = personnel.employeeById(id) ?: error("پرسنل پیدا نشد.")
            val from = EmploymentStatus.fromStoredValue(current.status)
            EmploymentStatusTransitionValidator.requireAllowed(from, to, terminationEpochDay)
            if (from == to) return@withTransaction
            val now = clock()
            check(personnel.transitionEmployeeStatus(id, from.storedValue, to.storedValue, terminationEpochDay, now, actor.id) == 1) {
                "تغییر وضعیت پرسنل به علت تغییر هم‌زمان انجام نشد."
            }
            auditWriter.appendAuthorized(
                authorizer, "STATUS_CHANGE", "EMPLOYEE", id, "تغییر وضعیت استخدام",
                now, terminationEpochDay, "تغییر کنترل‌شده وضعیت", "status=${from.storedValue}",
                "status=${to.storedValue};terminationEpochDay=$terminationEpochDay", "employee:$id:status:$now",
            )
        }
    }

    override suspend fun privateProfile(employeeId: Long): EmployeePrivateProfile? {
        authorizer.require(Permission.EMPLOYEE_SENSITIVE_EDIT)
        return hr.privateProfile(employeeId)?.toDomain()
    }

    override fun assignments(employeeId: Long): Flow<List<EmploymentAssignment>> =
        hr.observeAssignments(employeeId).map { rows -> rows.map { it.toDomain() } }

    override suspend fun deactivateEmployee(id: Long) {
        transitionEmploymentStatus(id, EmploymentStatus.ARCHIVED)
        syncRecorder?.record("EMPLOYEE", id, "ARCHIVE", clock())
    }

    override fun contracts(employeeId: Long): Flow<List<EmployeeContractRecord>> =
        hr.observeContractVersions(employeeId).map { rows ->
            rows.map { it.toRecord() }
        }

    override fun advances(employeeId: Long): Flow<List<EmployeeAdvanceRecord>> =
        personnel.observeAdvances(employeeId).map { rows -> rows.map { it.toRecord() } }

    override val openAdvances: Flow<List<EmployeeAdvanceRecord>> =
        personnel.observeOpenAdvances().map { rows -> rows.map { it.toRecord() } }

    override suspend fun saveContract(id: Long?, draft: EmployeeContractDraft): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            val employeeStatus = EmploymentStatus.fromStoredValue(employee.status)
            require(employeeStatus in setOf(EmploymentStatus.ACTIVE, EmploymentStatus.ON_LEAVE)) { "برای این وضعیت استخدام نمی‌توان قرارداد ثبت کرد." }
            val previous = id?.let { hr.contractVersion(it) ?: error("قرارداد پیدا نشد.") }
            require(previous == null || previous.employeeId == valid.employeeId) { "پرسنل قرارداد قابل تغییر نیست." }
            require(previous == null || previous.status !in setOf(
                EmploymentContractStatus.SUPERSEDED.storedValue,
                EmploymentContractStatus.CANCELLED.storedValue,
            )) { "نسخه منقضی یا جانشین‌شده مبنای اصلاح جدید نیست." }
            if (previous != null) require(valid.correctionReason.length >= 3) { "دلیل اصلاح نسخه قرارداد الزامی است." }
            val versionNo = (previous?.versionNo ?: 0) + 1
            val contractNumber = when {
                valid.contractNumber.isNotBlank() -> valid.contractNumber
                previous != null -> "${previous.contractNumber}-R$versionNo"
                else -> "CTR-${employee.employeeCode ?: employee.id}-${GlobalId.new().value.take(8).uppercase()}"
            }
            require(hr.contractByNumber(contractNumber) == null) { "شماره قرارداد تکراری است." }
            val conflicts = hr.overlappingContracts(
                valid.employeeId, valid.startEpochDay, valid.endEpochDay ?: Long.MAX_VALUE, previous?.id ?: 0,
            )
            require(conflicts.isEmpty()) { "بازه قرارداد با قرارداد دیگری هم‌پوشانی دارد." }
            val type = valid.contractType.toContractType()
            val contractId = hr.insertContractVersion(
                EmploymentContractVersionEntity(
                    employeeId = valid.employeeId, contractNumber = contractNumber, versionNo = versionNo,
                    replacesContractId = previous?.id, contractType = type.storedValue,
                    effectiveFromEpochDay = valid.startEpochDay, effectiveToEpochDay = valid.endEpochDay,
                    baseSalaryRial = valid.baseSalaryRial, standardDailyMinutes = valid.dailyWorkMinutes,
                    standardWeeklyMinutes = Math.multiplyExact(valid.dailyWorkMinutes, valid.weeklyWorkDays),
                    overtimePolicyId = valid.overtimePolicyId, payrollPolicyId = valid.payrollPolicyId,
                    jobTitleSnapshot = valid.jobTitleSnapshot.ifBlank { employee.jobTitle },
                    departmentSnapshot = valid.departmentSnapshot.ifBlank { employee.department },
                    branchSnapshot = valid.branchSnapshot.ifBlank { employee.branchName },
                    status = EmploymentContractStatus.PENDING_APPROVAL.storedValue,
                    notes = listOf(valid.notes, valid.correctionReason.takeIf { it.isNotBlank() }?.let { "اصلاح: $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" | "),
                    createdAtEpochMillis = now, createdByActorId = actor.id, approvedAtEpochMillis = null,
                    approvedByActorId = null, correlationId = "contract:${valid.employeeId}:$contractNumber",
                    source = "NATIVE",
                ),
            )
            auditWriter.appendAuthorized(
                authorizer, if (previous == null) "CREATE" else "REVISE", "EMPLOYMENT_CONTRACT", contractId,
                if (previous == null) "ایجاد قرارداد $contractNumber" else "نسخه جدید قرارداد $contractNumber",
                now, valid.startEpochDay, valid.correctionReason.ifBlank { "ایجاد قرارداد" },
                previous?.let { "contractId=${it.id};version=${it.versionNo};status=${it.status}" },
                "contractId=$contractId;version=$versionNo;status=PENDING_APPROVAL", "contract:${valid.employeeId}:$contractNumber",
            )
            contractId
        }
    }

    override suspend fun approveContract(id: Long) {
        val actor = authorizer.require(Permission.CONTRACT_APPROVE)
        database.withTransaction {
            val contract = hr.contractVersion(id) ?: error("قرارداد پیدا نشد.")
            if (contract.status == EmploymentContractStatus.APPROVED.storedValue) return@withTransaction
            require(contract.status == EmploymentContractStatus.PENDING_APPROVAL.storedValue) { "قرارداد در انتظار تأیید نیست." }
            contract.createdByActorId?.let {
                SegregationOfDuties.requireDifferentActors("CONTRACT_APPROVAL", it, actor.id)
            }
            val conflicts = hr.overlappingContracts(
                contract.employeeId, contract.effectiveFromEpochDay,
                contract.effectiveToEpochDay ?: Long.MAX_VALUE, contract.id,
            ).filter { it.id != contract.replacesContractId }
            require(conflicts.isEmpty()) { "قرارداد با نسخه فعال دیگری هم‌پوشانی دارد." }
            val now = clock()
            contract.replacesContractId?.let { predecessorId ->
                check(hr.markContractSuperseded(predecessorId) == 1) { "نسخه قبلی قرارداد قابل جانشینی نیست." }
            }
            check(hr.approveContract(id, now, actor.id) == 1) { "تأیید قرارداد انجام نشد." }
            auditWriter.appendAuthorized(
                authorizer, "APPROVE", "EMPLOYMENT_CONTRACT", id, "تأیید قرارداد ${contract.contractNumber}",
                now, contract.effectiveFromEpochDay, "تأیید قرارداد توسط actor مستقل",
                "status=${contract.status};createdBy=${contract.createdByActorId}",
                "status=APPROVED;approvedBy=${actor.id}", contract.correlationId,
            )
        }
    }

    override suspend fun effectiveContract(employeeId: Long, businessEpochDay: Long): EmploymentContractVersion =
        EffectiveContractResolver.resolve(
            employeeId,
            businessEpochDay,
            hr.effectiveContractCandidates(employeeId, businessEpochDay).map { it.toDomain() },
        )

    override suspend fun saveAttendance(id: Long?, draft: AttendanceDraft): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val calculated = AttendanceCalculator.calculate(valid)
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            val employeeStatus = EmploymentStatus.fromStoredValue(employee.status)
            require(employeeStatus in setOf(EmploymentStatus.ACTIVE, EmploymentStatus.ON_LEAVE)) { "برای این وضعیت استخدام نمی‌توان حضور ثبت کرد." }
            require(employee.hireEpochDay == null || valid.workEpochDay >= employee.hireEpochDay) { "تاریخ حضور قبل از شروع همکاری است." }
            require(employee.terminationEpochDay == null || valid.workEpochDay <= employee.terminationEpochDay) { "تاریخ حضور بعد از خاتمه همکاری است." }
            require(!personnel.attendanceDayLocked(valid.employeeId, valid.workEpochDay)) {
                "دوره حقوق این روز نهایی شده و حضور و غیاب آن قفل است."
            }
            if (valid.status != "LEAVE") {
                require(!personnel.hasApprovedLeave(valid.employeeId, valid.workEpochDay)) { "برای این روز مرخصی تأییدشده وجود دارد." }
            }
            val correlation = CorrelationId.forCommand("attendance", GlobalId.parse(valid.commandId)).value
            val baseKey = "attendance:${valid.commandId}:primary"
            hr.attendanceEventByIdempotencyKey(baseKey)?.let { replay ->
                val existing = personnel.attendanceByEmployeeDay(replay.employeeId, replay.businessEpochDay)
                    ?: error("Projection حضور برای فرمان تکراری پیدا نشد.")
                return@withTransaction existing.id
            }
            val entity = AttendanceEntity(
                id = id ?: 0, employeeId = valid.employeeId, workEpochDay = valid.workEpochDay,
                status = valid.status, checkInMinute = valid.checkInMinute, checkOutMinute = valid.checkOutMinute,
                lateMinutes = calculated.lateMinutes, overtimeMinutes = calculated.overtimeMinutes, notes = valid.notes,
            )
            if (id == null) {
                val attendanceId = personnel.insertAttendance(entity)
                appendAttendanceInputEvents(valid, actor.id, correlation, baseKey)
                auditWriter.appendAuthorized(
                    authorizer, "CREATE", "ATTENDANCE", attendanceId, "ثبت حضور و غیاب روزانه",
                    clock(), valid.workEpochDay, valid.notes.ifBlank { "ثبت حضور" }, null,
                    attendanceSnapshot(entity), correlation,
                )
                attendanceId
            } else {
                authorizer.require(Permission.ATTENDANCE_CORRECT)
                val current = personnel.attendanceById(id) ?: error("رکورد حضور پیدا نشد.")
                require(current.employeeId == valid.employeeId) { "پرسنل رکورد حضور قابل تغییر نیست." }
                require(valid.correctionReason.length >= 3) { "دلیل اصلاح حضور و غیاب الزامی است." }
                val before = attendanceSnapshot(current)
                val after = attendanceSnapshot(entity)
                val now = clock()
                val correctionId = hr.insertAttendanceCorrection(
                    AttendanceCorrectionEntity(
                        employeeId = valid.employeeId, businessEpochDay = valid.workEpochDay,
                        idempotencyKey = "attendance_correction:${valid.commandId}", beforeSnapshot = before,
                        afterSnapshot = after, reason = valid.correctionReason,
                        status = if (valid.requiresApproval) "SUBMITTED" else "APPROVED",
                        requestedByActorId = actor.id, approvedByActorId = actor.id.takeUnless { valid.requiresApproval },
                        requestedAtEpochMillis = now, approvedAtEpochMillis = now.takeUnless { valid.requiresApproval },
                        correlationId = correlation,
                    ),
                )
                if (!valid.requiresApproval) {
                    check(personnel.updateAttendance(entity) == 1) { "اعمال Projection اصلاح حضور انجام نشد." }
                }
                hr.insertAttendanceEvent(
                    AttendanceEventEntity(
                        globalId = GlobalId.new().value, idempotencyKey = baseKey,
                        employeeId = valid.employeeId, eventType = AttendanceEventType.MANUAL_ADJUSTMENT.storedValue,
                        businessEpochDay = valid.workEpochDay, timestampEpochMillis = now,
                        minuteOfDay = valid.checkInMinute ?: 0, source = AttendanceSource.MANUAL.storedValue,
                        deviceId = null, locationId = employee.locationId, createdByActorId = actor.id,
                        reason = valid.correctionReason, correlationId = correlation,
                    ),
                )
                auditWriter.appendAuthorized(
                    authorizer, if (valid.requiresApproval) "CORRECTION_SUBMIT" else "CORRECT", "ATTENDANCE", id,
                    "اصلاح حضور و غیاب", now, valid.workEpochDay, valid.correctionReason,
                    before, after, correlation, "ATTENDANCE_CORRECTION", correctionId,
                )
                id
            }
        }
    }

    override suspend fun attendanceSummaryV2(employeeId: Long, businessEpochDay: Long): DailyAttendanceSummaryV2 {
        authorizer.require(Permission.PERSONNEL)
        val employee = personnel.employeeById(employeeId) ?: error("پرسنل پیدا نشد.")
        hr.latestApprovedAttendanceCorrection(employeeId, businessEpochDay)?.let { correction ->
            return correction.toDailySummary()
        }
        val events = hr.attendanceEventsForDay(employeeId, businessEpochDay)
        if (events.isEmpty()) {
            val legacy = personnel.attendanceByEmployeeDay(employeeId, businessEpochDay)
            if (legacy != null) return legacy.toDailySummaryV2()
        }
        val contract = hr.effectiveContractCandidates(employeeId, businessEpochDay).singleOrNull()
        val startMinute = 8 * 60
        val endMinute = (startMinute + (contract?.standardDailyMinutes ?: 8 * 60)).coerceAtMost(24 * 60)
        return AttendanceEventAggregator.summarize(
            employeeId = employeeId,
            businessEpochDay = businessEpochDay,
            events = events.map { it.toDomain() },
            policy = AttendanceAggregationPolicy(startMinute, endMinute),
            employmentFromEpochDay = employee.hireEpochDay ?: 1,
            employmentToEpochDay = employee.terminationEpochDay,
        )
    }

    override suspend fun approveAttendanceCorrection(correctionId: Long) {
        val actor = authorizer.require(Permission.ATTENDANCE_CORRECT)
        database.withTransaction {
            val correction = hr.attendanceCorrection(correctionId) ?: error("درخواست اصلاح حضور پیدا نشد.")
            if (correction.status == "APPROVED") return@withTransaction
            require(correction.status == "SUBMITTED") { "درخواست اصلاح در انتظار تأیید نیست." }
            SegregationOfDuties.requireDifferentActors(
                "ATTENDANCE_CORRECTION_APPROVAL", correction.requestedByActorId, actor.id,
            )
            val now = clock()
            require(!personnel.attendanceDayLocked(correction.employeeId, correction.businessEpochDay)) {
                "دوره حقوق این روز نهایی شده و اصلاح باید از مسیر revision حقوق انجام شود."
            }
            check(hr.approveAttendanceCorrection(correction.id, actor.id, now) == 1) { "تأیید اصلاح انجام نشد." }
            val snapshot = AttendanceCorrectionCodec.decode(correction.afterSnapshot)
            personnel.attendanceByEmployeeDay(correction.employeeId, correction.businessEpochDay)?.let { current ->
                check(
                    personnel.updateAttendance(
                        current.copy(
                            status = snapshot.status.toLegacyAttendanceStatus(),
                            checkInMinute = snapshot.firstInMinute,
                            checkOutMinute = snapshot.lastOutMinute,
                            lateMinutes = snapshot.lateMinutes,
                            overtimeMinutes = snapshot.overtimeMinutes,
                            notes = "اصلاح تأییدشده: ${correction.reason}",
                        ),
                    ) == 1,
                ) { "به‌روزرسانی Projection حضور پس از تأیید انجام نشد." }
            }
            auditWriter.appendAuthorized(
                authorizer, "CORRECTION_APPROVE", "ATTENDANCE", null, "تأیید اصلاح حضور و غیاب",
                now, correction.businessEpochDay, correction.reason, correction.beforeSnapshot,
                correction.afterSnapshot, correction.correlationId, "ATTENDANCE_CORRECTION", correction.id,
            )
        }
    }

    override suspend fun attendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long): AttendanceSummary {
        authorizer.require(Permission.PERSONNEL)
        require(employeeId > 0 && startEpochDay > 0 && endEpochDay >= startEpochDay) { "بازه گزارش معتبر نیست." }
        val rows = personnel.attendanceInRange(employeeId, startEpochDay, endEpochDay)
        return AttendanceSummary(
            employeeId, startEpochDay, endEpochDay,
            presentDays = rows.count { it.status == "PRESENT" },
            absentDays = rows.count { it.status == "ABSENT" },
            leaveDays = rows.count { it.status == "LEAVE" },
            missionDays = rows.count { it.status == "MISSION" },
            workedMinutes = rows.sumOf { row -> if (row.checkInMinute != null && row.checkOutMinute != null) row.checkOutMinute - row.checkInMinute else 0 },
            lateMinutes = rows.sumOf { it.lateMinutes },
            overtimeMinutes = rows.sumOf { it.overtimeMinutes },
        )
    }

    override suspend fun attendancePayrollAdjustment(
        employeeId: Long,
        startEpochDay: Long,
        endEpochDay: Long,
        policy: AttendancePayrollPolicy,
    ): AttendancePayrollAdjustment {
        authorizer.require(Permission.PERSONNEL)
        return AttendancePayrollCalculator.calculate(
            attendanceSummary(employeeId, startEpochDay, endEpochDay),
            policy,
        )
    }

    override suspend fun requestLeave(draft: LeaveDraft, requestedBy: String): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        require(requestedBy.trim().isNotEmpty()) { "ثبت‌کننده درخواست مشخص نیست." }
        return database.withTransaction {
            val idempotencyKey = "leave_request:${valid.commandId}"
            personnel.leaveByIdempotencyKey(idempotencyKey)?.let { existing ->
                if (
                    existing.employeeId != valid.employeeId || existing.startEpochDay != valid.startEpochDay ||
                    existing.endEpochDay != valid.endEpochDay || existing.leaveType != valid.leaveType
                ) {
                    throw BusinessError.IdempotencyConflict(idempotencyKey).asViolation()
                }
                return@withTransaction existing.id
            }
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            val employeeStatus = EmploymentStatus.fromStoredValue(employee.status)
            require(employeeStatus in setOf(EmploymentStatus.ACTIVE, EmploymentStatus.ON_LEAVE)) { "پرسنل در وضعیت قابل مرخصی نیست." }
            require(!personnel.hasLeaveOverlap(valid.employeeId, valid.startEpochDay, valid.endEpochDay)) { "این درخواست با مرخصی دیگری هم‌پوشانی دارد." }
            val now = clock()
            val correlation = CorrelationId.forCommand("leave_request", GlobalId.parse(valid.commandId)).value
            val leaveId = personnel.insertLeave(LeaveEntity(
                employeeId = valid.employeeId, globalId = valid.commandId, idempotencyKey = idempotencyKey,
                startEpochDay = valid.startEpochDay, endEpochDay = valid.endEpochDay,
                daysMicros = SignedLongMath.multiply(
                    SignedLongMath.add(SignedLongMath.subtract(valid.endEpochDay, valid.startEpochDay), 1L),
                    1_000_000L,
                ),
                leaveType = valid.leaveType, status = LeaveStatus.SUBMITTED.storedValue, notes = valid.notes,
                requestedBy = actor.displayName, requestedByActorId = actor.id,
                createdAtEpochMillis = now, updatedAtEpochMillis = now, correlationId = correlation,
            ))
            auditWriter.appendAuthorized(
                authorizer, "SUBMIT", "LEAVE", leaveId, "ثبت درخواست مرخصی",
                now, valid.startEpochDay, valid.notes.ifBlank { "درخواست مرخصی" }, null,
                "status=SUBMITTED;type=${valid.leaveType};from=${valid.startEpochDay};to=${valid.endEpochDay}", correlation,
            )
            leaveId
        }
    }

    override suspend fun grantLeave(draft: LeaveGrantDraft): Long {
        val actor = authorizer.require(Permission.LEAVE_APPROVE)
        val valid = draft.validated()
        return database.withTransaction {
            val key = "leave_grant:${valid.commandId}"
            hr.leaveLedgerByIdempotencyKey(key)?.let { existing ->
                if (
                    existing.employeeId != valid.employeeId || existing.leaveType != valid.leaveType.storedValue ||
                    existing.amountMicros != valid.amountMicros
                ) throw BusinessError.IdempotencyConflict(key).asViolation()
                return@withTransaction existing.id
            }
            personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            val now = clock()
            val correlation = CorrelationId.forCommand("leave_grant", GlobalId.parse(valid.commandId)).value
            val id = hr.insertLeaveLedgerEntry(
                LeaveLedgerEntryEntity(
                    globalId = valid.commandId, idempotencyKey = key, employeeId = valid.employeeId,
                    leaveType = valid.leaveType.storedValue, entryType = LeaveLedgerEntryType.GRANT.name,
                    amountMicros = valid.amountMicros, leaveId = null, businessEpochDay = valid.businessEpochDay,
                    reason = valid.reason, createdByActorId = actor.id, createdAtEpochMillis = now,
                    correlationId = correlation,
                ),
            )
            auditWriter.appendAuthorized(
                authorizer, "GRANT", "LEAVE_BALANCE", id, "اعطای سهمیه مرخصی",
                now, valid.businessEpochDay, valid.reason, null,
                "employeeId=${valid.employeeId};type=${valid.leaveType.storedValue};amountMicros=${valid.amountMicros}", correlation,
            )
            id
        }
    }

    override suspend fun leaveBalance(employeeId: Long, leaveType: LeaveType): LeaveBalance {
        authorizer.require(Permission.PERSONNEL)
        val ledger = hr.leaveLedger(employeeId, leaveType.storedValue).map { row ->
            LeaveLedgerEntry(
                id = row.id, employeeId = row.employeeId, leaveType = LeaveType.fromStoredValue(row.leaveType),
                entryType = LeaveLedgerEntryType.valueOf(row.entryType), amountMicros = row.amountMicros,
                leaveId = row.leaveId,
            )
        }
        val pending = personnel.pendingLeavesForBalance(employeeId, leaveType.storedValue).map { row ->
            PendingLeaveUsage(row.employeeId, leaveType, row.daysMicros)
        }
        return LeaveBalanceCalculator.calculate(employeeId, leaveType, ledger, pending)
    }

    override suspend fun reviewLeave(draft: LeaveReviewDraft) {
        val actor = authorizer.require(Permission.LEAVE_APPROVE)
        val valid = draft.validated()
        database.withTransaction {
            val current = personnel.leaveById(valid.leaveId) ?: error("درخواست مرخصی پیدا نشد.")
            require(LeaveStatus.fromStoredValue(current.status) == LeaveStatus.SUBMITTED) { "فقط درخواست در انتظار قابل بررسی است." }
            current.requestedByActorId?.let {
                SegregationOfDuties.requireDifferentActors("LEAVE_APPROVAL", it, actor.id)
            }
            val now = clock()
            if (valid.decision == "APPROVE") {
                require(!personnel.attendanceRangeLocked(current.employeeId, current.startEpochDay, current.endEpochDay)) {
                    "بخشی از بازه مرخصی در دوره حقوق نهایی‌شده قرار دارد و قابل تغییر نیست."
                }
                require(!personnel.hasAttendanceConflict(current.employeeId, current.startEpochDay, current.endEpochDay)) { "در بازه مرخصی، رکورد حضور متعارض وجود دارد." }
                val leaveType = LeaveType.fromStoredValue(current.leaveType)
                if (leaveType in setOf(LeaveType.PAID, LeaveType.ANNUAL, LeaveType.HOURLY)) {
                    val balance = leaveBalance(current.employeeId, leaveType)
                    require(balance.remainingMicros >= 0) { "مانده مرخصی برای تأیید کافی نیست." }
                }
                for (day in current.startEpochDay..current.endEpochDay) {
                    val existing = personnel.attendanceByEmployeeDay(current.employeeId, day)
                    if (existing == null) {
                        personnel.insertAttendance(AttendanceEntity(employeeId=current.employeeId, workEpochDay=day, status="LEAVE", checkInMinute=null, checkOutMinute=null, lateMinutes=0, overtimeMinutes=0, notes="ثبت خودکار از گردش کار مرخصی"))
                    }
                }
                val leaveLedgerKey = "leave_use:${current.id}"
                if (hr.leaveLedgerByIdempotencyKey(leaveLedgerKey) == null) {
                    hr.insertLeaveLedgerEntry(
                        LeaveLedgerEntryEntity(
                            globalId = GlobalId.new().value, idempotencyKey = leaveLedgerKey,
                            employeeId = current.employeeId, leaveType = current.leaveType,
                            entryType = LeaveLedgerEntryType.USE.name, amountMicros = current.daysMicros,
                            leaveId = current.id, businessEpochDay = current.startEpochDay,
                            reason = valid.notes.ifBlank { "تأیید مرخصی" }, createdByActorId = actor.id,
                            createdAtEpochMillis = now, correlationId = current.correlationId,
                        ),
                    )
                }
            }
            check(personnel.updateLeave(current.copy(
                status = if (valid.decision == "APPROVE") LeaveStatus.APPROVED.storedValue else LeaveStatus.REJECTED.storedValue,
                reviewedBy = actor.displayName, reviewedByActorId = actor.id,
                reviewNotes = valid.notes, reviewedAtEpochMillis = now, updatedAtEpochMillis = now,
            )) == 1) { "ثبت نتیجه بررسی مرخصی انجام نشد." }
            auditWriter.appendAuthorized(
                authorizer, if (valid.decision == "APPROVE") "APPROVE" else "REJECT", "LEAVE", current.id,
                if (valid.decision == "APPROVE") "تأیید درخواست مرخصی" else "رد درخواست مرخصی",
                now, current.startEpochDay, valid.notes.ifBlank { "بررسی مرخصی" },
                "status=${current.status};requestedByActorId=${current.requestedByActorId}",
                "status=${if (valid.decision == "APPROVE") "APPROVED" else "REJECTED"};reviewedByActorId=${actor.id}",
                current.correlationId,
            )
        }
    }

    override suspend fun cancelLeave(id: Long) {
        authorizer.require(Permission.PERSONNEL)
        database.withTransaction {
            val current = personnel.leaveById(id) ?: error("درخواست مرخصی پیدا نشد.")
            require(LeaveStatus.fromStoredValue(current.status) == LeaveStatus.SUBMITTED) { "فقط درخواست در انتظار قابل لغو است." }
            val now = clock()
            check(personnel.updateLeave(current.copy(status=LeaveStatus.CANCELLED.storedValue, cancelledAtEpochMillis=now, updatedAtEpochMillis=now)) == 1) { "لغو درخواست انجام نشد." }
            auditWriter.appendAuthorized(
                authorizer, "CANCEL", "LEAVE", id, "لغو درخواست مرخصی", now,
                current.startEpochDay, "لغو درخواست", "status=${current.status}", "status=CANCELLED", current.correlationId,
            )
        }
    }

    override suspend fun approveLeave(draft: LeaveDraft): Long {
        throw BusinessError.ApprovalRequired("LEAVE_APPROVAL", 1).asViolation()
    }

    override suspend fun postAdvance(draft: EmployeeAdvanceDraft): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان مساعده ثبت کرد." }
            val paymentRole = valid.paymentMethod.personnelLedgerRole()
            val now = clock()
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "م-${employee.id}-$now", entryEpochDay = valid.advanceEpochDay,
                    description = "مساعده پرسنل: ${employee.name}", sourceType = "EMPLOYEE_ADVANCE", sourceId = employee.id,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.EMPLOYEE_ADVANCE_RECEIVABLE, debit = MoneyRial.of(valid.amountRial), memo = "مساعده ${employee.name}"),
                        SemanticJournalLine(paymentRole, credit = MoneyRial.of(valid.amountRial), memo = "پرداخت مساعده"),
                    ),
                ),
                context = AccountingPostingContext.local(
                    sourceType = "EMPLOYEE_ADVANCE",
                    sourceId = employee.id,
                    suffix = "post:$now",
                    actorId = actor.id,
                    correlationId = "employee_advance:${employee.id}:$now",
                ),
            )
            personnel.insertAdvance(
                EmployeeAdvanceEntity(
                    employeeId = employee.id,
                    amountRial = valid.amountRial,
                    advanceEpochDay = valid.advanceEpochDay,
                    paymentMethod = LegacyTreasuryChannelAdapter.toPersonnelStoredValue(valid.paymentMethod),
                    journalEntryId = entryId,
                    notes = valid.notes,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
        }
    }

    override suspend fun settleAdvance(
        id: Long,
        amountRial: Long,
        paymentMethod: TreasuryChannel,
        settlementEpochDay: Long,
    ) {
        val actor = authorizer.require(Permission.PERSONNEL)
        require(amountRial > 0) { "مبلغ تسویه باید بیشتر از صفر باشد." }
        require(paymentMethod in setOf(TreasuryChannel.CASH, TreasuryChannel.BANK)) {
            "advance_settlement_channel_unsupported"
        }
        require(settlementEpochDay > 0) { "تاریخ تسویه مساعده معتبر نیست." }
        database.withTransaction {
            val current = personnel.advanceById(id) ?: error("مساعده پیدا نشد.")
            require(current.status == "OPEN") { "این مساعده قبلاً تسویه شده است." }
            val employee = personnel.employeeById(current.employeeId) ?: error("پرسنل پیدا نشد.")
            val newSettled = SignedLongMath.add(current.settledAmountRial, amountRial)
            require(newSettled <= current.amountRial) { "مبلغ تسویه بیشتر از مانده مساعده است." }
            val receiptRole = paymentMethod.personnelLedgerRole()
            val now = clock()
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "م‌ت-${current.id}-$now", entryEpochDay = settlementEpochDay,
                    description = "بازپرداخت مساعده: ${employee.name}", sourceType = "EMPLOYEE_ADVANCE_SETTLEMENT", sourceId = current.id,
                    lines = listOf(
                        SemanticJournalLine(receiptRole, debit = MoneyRial.of(amountRial), memo = "دریافت بازپرداخت مساعده"),
                        SemanticJournalLine(SemanticAccountRole.EMPLOYEE_ADVANCE_RECEIVABLE, credit = MoneyRial.of(amountRial), memo = "کاهش مطالبات مساعده"),
                    ),
                ),
                context = AccountingPostingContext.local(
                    sourceType = "EMPLOYEE_ADVANCE_SETTLEMENT",
                    sourceId = current.id,
                    suffix = "settle:$now",
                    actorId = actor.id,
                    correlationId = "employee_advance_settlement:${current.id}:$now",
                ),
            )
            check(
                personnel.updateAdvance(
                    current.copy(
                        settledAmountRial = newSettled,
                        status = if (newSettled == current.amountRial) "SETTLED" else "OPEN",
                        updatedAtEpochMillis = now,
                    ),
                ) == 1,
            ) { "تسویه مساعده انجام نشد." }
        }
    }

    @Deprecated("Use HrPayrollCommandService.calculateBatch; legacy payroll writes are intentionally disabled.")
    override suspend fun calculatePayroll(draft: PayrollDraft): PayrollCalculation =
        throw BusinessError.UnsupportedDomainOperation(
            ownerDomain = "hr_payroll_v2",
            operation = "legacy_calculate_payroll",
        ).asViolation()

    @Deprecated("Use HrPayrollCommandService.createBatch/calculateBatch; legacy payroll writes are intentionally disabled.")
    override suspend fun postPayroll(draft: PayrollDraft): Long =
        throw BusinessError.UnsupportedDomainOperation(
            ownerDomain = "hr_payroll_v2",
            operation = "legacy_post_payroll",
        ).asViolation()

    @Deprecated("Use HrPayrollCommandService.approveBatch; legacy payroll writes are intentionally disabled.")
    override suspend fun approvePayroll(payrollId: Long): Unit =
        throw BusinessError.UnsupportedDomainOperation(
            ownerDomain = "hr_payroll_v2",
            operation = "legacy_approve_payroll",
        ).asViolation()

    @Deprecated("Use HrPayrollCommandService.reversePayslip/reversePayment; legacy payroll writes are intentionally disabled.")
    override suspend fun reversePayroll(draft: PayrollReversalDraft): Unit =
        throw BusinessError.UnsupportedDomainOperation(
            ownerDomain = "hr_payroll_v2",
            operation = "legacy_reverse_payroll",
        ).asViolation()

    private suspend fun prepareAttendancePayroll(valid: PayrollDraft): PreparedPayroll {
        if (valid.periodStartEpochDay == 0L) return PreparedPayroll(valid, null, null)
        val policy = personnel.payrollPolicyForRange(valid.periodStartEpochDay, valid.periodEndEpochDay)
            ?: error("برای کل بازه این دوره، سیاست فعال حقوق تعریف نشده است.")
        val summary = attendanceSummary(valid.employeeId, valid.periodStartEpochDay, valid.periodEndEpochDay)
        val adjustment = AttendancePayrollCalculator.calculate(
            summary,
            AttendancePayrollPolicy(policy.overtimeHourlyRateRial, policy.absenceDailyDeductionRial, policy.lateMinuteDeductionRial),
        )
        return PreparedPayroll(
            valid.copy(
                overtimeRial = SignedLongMath.add(valid.overtimeRial, adjustment.overtimeRial),
                deductionsRial = SignedLongMath.add(valid.deductionsRial, adjustment.totalAttendanceDeductionRial),
            ),
            adjustment,
            policy.id,
        )
    }

    private suspend fun savePrivateProfile(
        employeeId: Long,
        draft: EmployeeDraft,
        now: Long,
        actorId: Long,
        legacyCurrent: EmployeeEntity?,
    ) {
        val current = hr.privateProfile(employeeId)
        hr.upsertPrivateProfile(
            EmployeePrivateProfileEntity(
                employeeId = employeeId,
                nationalId = draft.nationalId.takeIf { it.isNotBlank() } ?: current?.nationalId ?: legacyCurrent?.nationalId,
                insuranceNumber = draft.insuranceNumber.takeIf { it.isNotBlank() } ?: current?.insuranceNumber ?: legacyCurrent?.insuranceNumber,
                bankName = current?.bankName,
                bankAccountLast4 = draft.bankCard.takeIf { it.isNotBlank() }?.takeLast(4)
                    ?: current?.bankAccountLast4
                    ?: legacyCurrent?.bankCard?.takeLast(4),
                ibanLast4 = current?.ibanLast4,
                accountHolder = current?.accountHolder,
                emergencyContact = draft.emergencyContact,
                createdAtEpochMillis = current?.createdAtEpochMillis ?: now,
                updatedAtEpochMillis = now,
                updatedByActorId = actorId,
            ),
        )
    }

    /**
     * Human-readable identity allocated inside the employee creation transaction. The unique
     * database index remains the final concurrency safeguard; scanning forward also avoids a
     * collision with an administrator-supplied code in the reserved legacy format.
     */
    private suspend fun newEmployeeCode(): String {
        var sequence = personnel.nextEmployeeSequence().coerceAtLeast(1L)
        repeat(1_000) {
            val candidate = "EMP-${sequence.toString().padStart(6, '0')}"
            if (!personnel.employeeCodeExists(candidate)) return candidate
            sequence = Math.addExact(sequence, 1L)
        }
        throw BusinessError.InvalidInput(
            field = "employeeCode",
            reason = "employee_code_sequence_exhausted",
        ).asViolation()
    }

    private suspend fun appendAttendanceInputEvents(
        draft: AttendanceDraft,
        actorId: Long,
        correlationId: String,
        baseIdempotencyKey: String,
    ) {
        suspend fun append(
            type: AttendanceEventType,
            minuteOfDay: Int,
            key: String,
            globalId: String,
        ) {
            hr.insertAttendanceEvent(
                AttendanceEventEntity(
                    globalId = globalId,
                    idempotencyKey = key,
                    employeeId = draft.employeeId,
                    eventType = type.storedValue,
                    businessEpochDay = draft.workEpochDay,
                    timestampEpochMillis = attendanceEventEpochMillis(draft.workEpochDay, minuteOfDay),
                    minuteOfDay = minuteOfDay,
                    source = draft.source.storedValue,
                    deviceId = null,
                    locationId = null,
                    createdByActorId = actorId,
                    reason = draft.notes.takeIf { it.isNotBlank() },
                    correlationId = correlationId,
                ),
            )
        }
        when (draft.status) {
            "PRESENT" -> {
                append(
                    AttendanceEventType.CLOCK_IN,
                    requireNotNull(draft.checkInMinute),
                    baseIdempotencyKey,
                    draft.commandId,
                )
                append(
                    AttendanceEventType.CLOCK_OUT,
                    requireNotNull(draft.checkOutMinute),
                    "$baseIdempotencyKey:clock_out",
                    GlobalId.new().value,
                )
            }

            "ABSENT" -> append(
                AttendanceEventType.ABSENCE_MARK,
                0,
                baseIdempotencyKey,
                draft.commandId,
            )

            "LEAVE", "MISSION", "HOLIDAY" -> append(
                AttendanceEventType.MANUAL_ADJUSTMENT,
                draft.checkInMinute ?: 0,
                baseIdempotencyKey,
                draft.commandId,
            )

            else -> error("attendance_status_not_exhaustive:${draft.status}")
        }
    }
}

private fun PayrollDraft.commandCorrelation(): String {
    val encodedPayload = listOf(
        employeeId,
        periodYear,
        periodMonth,
        overtimeRial,
        bonusRial,
        allowancesRial,
        deductionsRial,
        insuranceRial,
        taxRial,
        advanceDeductionRial,
        periodStartEpochDay,
        periodEndEpochDay,
        paymentEpochDay,
        paymentMethod,
        notes,
    ).joinToString(separator = "|") { value ->
        val text = value.toString()
        "${text.length}:$text"
    }
    val fingerprint = MessageDigest.getInstance("SHA-256")
        .digest(encodedPayload.toByteArray(Charsets.UTF_8))
        .take(16)
        .joinToString("") { byte -> "%02x".format(byte) }
    return "payroll:$commandId:$fingerprint"
}

private data class PreparedPayroll(val draft: PayrollDraft, val adjustment: AttendancePayrollAdjustment?, val policyId: Long?)

private fun EmployeeContractEntity.toRecord() = EmployeeContractRecord(
    id = id,
    employeeId = employeeId,
    contractType = contractType,
    startEpochDay = startEpochDay,
    endEpochDay = endEpochDay,
    baseSalaryRial = baseSalaryRial,
    dailyWorkMinutes = dailyWorkMinutes,
    weeklyWorkDays = weeklyWorkDays,
    status = status,
    notes = notes,
)

private fun EmploymentContractVersionEntity.toRecord() = EmployeeContractRecord(
    id = id,
    employeeId = employeeId,
    contractType = contractType,
    startEpochDay = effectiveFromEpochDay,
    endEpochDay = effectiveToEpochDay,
    baseSalaryRial = baseSalaryRial,
    dailyWorkMinutes = standardDailyMinutes,
    weeklyWorkDays = if (standardDailyMinutes > 0) standardWeeklyMinutes / standardDailyMinutes else 0,
    status = status,
    notes = notes,
    contractNumber = contractNumber,
    versionNo = versionNo,
    replacesContractId = replacesContractId,
    payrollPolicyId = payrollPolicyId,
    jobTitleSnapshot = jobTitleSnapshot,
    departmentSnapshot = departmentSnapshot,
    branchSnapshot = branchSnapshot,
    typedStatus = EmploymentContractStatus.fromStoredValue(status),
)

private fun EmploymentContractVersionEntity.toDomain() = EmploymentContractVersion(
    id = id,
    employeeId = employeeId,
    contractNumber = contractNumber,
    versionNo = versionNo,
    replacesContractId = replacesContractId,
    contractType = EmploymentContractType.fromStoredValue(contractType),
    effectiveFromEpochDay = effectiveFromEpochDay,
    effectiveToEpochDay = effectiveToEpochDay,
    baseSalary = MoneyRial.of(baseSalaryRial),
    standardDailyMinutes = standardDailyMinutes,
    standardWeeklyMinutes = standardWeeklyMinutes,
    overtimePolicyId = overtimePolicyId,
    payrollPolicyId = payrollPolicyId,
    jobTitleSnapshot = jobTitleSnapshot,
    departmentSnapshot = departmentSnapshot,
    branchSnapshot = branchSnapshot,
    status = EmploymentContractStatus.fromStoredValue(status),
    createdAtEpochMillis = createdAtEpochMillis,
    createdByActorId = createdByActorId,
    approvedAtEpochMillis = approvedAtEpochMillis,
    approvedByActorId = approvedByActorId,
)

private fun EmploymentAssignmentEntity.toDomain() = EmploymentAssignment(
    id = id,
    employeeId = employeeId,
    effectiveFromEpochDay = effectiveFromEpochDay,
    effectiveToEpochDay = effectiveToEpochDay,
    jobTitle = jobTitle,
    department = department,
    branchName = branchName,
    locationId = locationId,
    managerId = managerId,
    createdByActorId = createdByActorId,
)

private fun EmployeePrivateProfileEntity.toDomain() = EmployeePrivateProfile(
    employeeId = employeeId,
    nationalId = nationalId,
    insuranceNumber = insuranceNumber,
    bankName = bankName,
    bankAccountLast4 = bankAccountLast4,
    ibanLast4 = ibanLast4,
    accountHolder = accountHolder,
    emergencyContact = emergencyContact,
)

private fun String.toContractType(): EmploymentContractType = when (trim().uppercase()) {
    "PERMANENT", "FULL_TIME", "دائم" -> EmploymentContractType.PERMANENT
    "FIXED_TERM", "TEMPORARY", "موقت" -> EmploymentContractType.FIXED_TERM
    "PART_TIME", "پاره‌وقت" -> EmploymentContractType.PART_TIME
    "HOURLY", "ساعتی" -> EmploymentContractType.HOURLY
    "PROBATION", "آزمایشی" -> EmploymentContractType.PROBATION
    "OTHER", "سایر" -> EmploymentContractType.OTHER
    else -> EmploymentContractType.OTHER
}

private fun String?.maskedLastFour(): String =
    this?.filter(Char::isDigit)?.takeLast(4)?.takeIf { it.length == 4 }?.let { "••••$it" }.orEmpty()

private fun EmployeeAdvanceEntity.toRecord(): EmployeeAdvanceRecord {
    val remaining = SignedLongMath.subtract(amountRial, settledAmountRial)
    return EmployeeAdvanceRecord(
        id = id,
        employeeId = employeeId,
        amountRial = amountRial,
        settledAmountRial = settledAmountRial,
        remainingAmountRial = remaining,
        advanceEpochDay = advanceEpochDay,
        paymentMethod = LegacyTreasuryChannelAdapter.fromPersonnelStoredValue(paymentMethod),
        journalEntryId = journalEntryId,
        status = status,
        notes = notes,
    )
}


private fun AttendanceEntity.toRecord() = AttendanceRecord(
    id = id, employeeId = employeeId, workEpochDay = workEpochDay, status = status,
    checkInMinute = checkInMinute, checkOutMinute = checkOutMinute,
    workedMinutes = if (checkInMinute != null && checkOutMinute != null) checkOutMinute - checkInMinute else 0,
    lateMinutes = lateMinutes, overtimeMinutes = overtimeMinutes, notes = notes,
)

private fun AttendanceEventEntity.toDomain() = AttendanceEvent(
    id = id,
    employeeId = employeeId,
    eventType = AttendanceEventType.fromStoredValue(eventType),
    businessEpochDay = businessEpochDay,
    timestampEpochMillis = timestampEpochMillis,
    minuteOfDay = minuteOfDay,
    source = AttendanceSource.fromStoredValue(source),
    deviceId = deviceId,
    locationId = locationId,
    createdByActorId = createdByActorId,
    reason = reason,
    correlationId = CorrelationId.parse(correlationId),
)

private fun AttendanceCorrectionEntity.toDailySummary(): DailyAttendanceSummaryV2 {
    val snapshot = AttendanceCorrectionCodec.decode(afterSnapshot)
    return DailyAttendanceSummaryV2(
        employeeId = employeeId,
        businessEpochDay = businessEpochDay,
        firstInMinute = snapshot.firstInMinute,
        lastOutMinute = snapshot.lastOutMinute,
        workedMinutes = snapshot.workedMinutes,
        breakMinutes = snapshot.breakMinutes,
        lateMinutes = snapshot.lateMinutes,
        earlyLeaveMinutes = snapshot.earlyLeaveMinutes,
        overtimeMinutes = snapshot.overtimeMinutes,
        absenceMinutes = snapshot.absenceMinutes,
        paidLeaveMinutes = 0,
        unpaidLeaveMinutes = 0,
        status = snapshot.status,
        anomalies = emptyList(),
        source = AttendanceSource.MANUAL,
    )
}

private fun AttendanceEntity.toDailySummaryV2(): DailyAttendanceSummaryV2 {
    val worked = if (checkInMinute != null && checkOutMinute != null) checkOutMinute - checkInMinute else 0
    val typedStatus = when (status) {
        "PRESENT" -> DailyAttendanceStatus.PRESENT
        "ABSENT" -> DailyAttendanceStatus.ABSENT
        "MISSION" -> DailyAttendanceStatus.MISSION
        "HOLIDAY" -> DailyAttendanceStatus.HOLIDAY
        "LEAVE" -> DailyAttendanceStatus.INCOMPLETE
        else -> DailyAttendanceStatus.INCOMPLETE
    }
    return DailyAttendanceSummaryV2(
        employeeId = employeeId,
        businessEpochDay = workEpochDay,
        firstInMinute = checkInMinute,
        lastOutMinute = checkOutMinute,
        workedMinutes = worked,
        breakMinutes = 0,
        lateMinutes = lateMinutes,
        earlyLeaveMinutes = 0,
        overtimeMinutes = overtimeMinutes,
        absenceMinutes = if (typedStatus == DailyAttendanceStatus.ABSENT) 8 * 60 else 0,
        paidLeaveMinutes = 0,
        unpaidLeaveMinutes = 0,
        status = typedStatus,
        anomalies = emptyList(),
        source = AttendanceSource.LEGACY,
    )
}

private fun attendanceSnapshot(entity: AttendanceEntity): String = AttendanceCorrectionCodec.encode(
    AttendanceCorrectionSnapshot(
        firstInMinute = entity.checkInMinute,
        lastOutMinute = entity.checkOutMinute,
        workedMinutes = if (entity.checkInMinute != null && entity.checkOutMinute != null) entity.checkOutMinute - entity.checkInMinute else 0,
        breakMinutes = 0,
        lateMinutes = entity.lateMinutes,
        earlyLeaveMinutes = 0,
        overtimeMinutes = entity.overtimeMinutes,
        absenceMinutes = if (entity.status == "ABSENT") 8 * 60 else 0,
        status = when (entity.status) {
            "PRESENT" -> DailyAttendanceStatus.PRESENT
            "ABSENT" -> DailyAttendanceStatus.ABSENT
            "MISSION" -> DailyAttendanceStatus.MISSION
            "HOLIDAY" -> DailyAttendanceStatus.HOLIDAY
            "LEAVE" -> DailyAttendanceStatus.INCOMPLETE
            else -> DailyAttendanceStatus.INCOMPLETE
        },
    ),
)

private fun DailyAttendanceStatus.toLegacyAttendanceStatus(): String = when (this) {
    DailyAttendanceStatus.PRESENT -> "PRESENT"
    DailyAttendanceStatus.ABSENT -> "ABSENT"
    DailyAttendanceStatus.PAID_LEAVE, DailyAttendanceStatus.UNPAID_LEAVE -> "LEAVE"
    DailyAttendanceStatus.MISSION -> "MISSION"
    DailyAttendanceStatus.HOLIDAY -> "HOLIDAY"
    DailyAttendanceStatus.INCOMPLETE, DailyAttendanceStatus.ANOMALY -> "PRESENT"
}

private fun attendanceEventEpochMillis(epochDay: Long, minuteOfDay: Int): Long = SignedLongMath.add(
    SignedLongMath.multiply(epochDay, 86_400_000L),
    SignedLongMath.multiply(minuteOfDay.toLong(), 60_000L),
)

private fun TreasuryChannel.personnelLedgerRole(): SemanticAccountRole = when (this) {
    TreasuryChannel.CASH -> SemanticAccountRole.CASH
    TreasuryChannel.BANK -> SemanticAccountRole.BANK
    TreasuryChannel.CARD,
    TreasuryChannel.TRANSFER,
    -> throw BusinessError.UnsupportedDomainOperation(
        ownerDomain = "workforce",
        operation = "ledger_role_${storedValue.lowercase()}",
    ).asViolation()
}


private fun LeaveEntity.toRecord() = LeaveRecord(
    id=id, employeeId=employeeId, startEpochDay=startEpochDay, endEpochDay=endEpochDay, daysMicros=daysMicros,
    leaveType=leaveType, status=status, notes=notes, requestedBy=requestedBy, reviewedBy=reviewedBy,
    reviewNotes=reviewNotes, reviewedAtEpochMillis=reviewedAtEpochMillis,
    typedStatus=LeaveStatus.fromStoredValue(status), typedLeaveType=LeaveType.fromStoredValue(leaveType),
    correlationId=correlationId,
)
