package ir.sabou.inventory.data.treasury

import ir.sabou.inventory.domain.accounting.AccountingPostingCommand
import ir.sabou.inventory.domain.accounting.AccountingPostingService
import ir.sabou.inventory.domain.accounting.AccountingReversalCommand
import ir.sabou.inventory.domain.accounting.JournalStatus
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.security.AuthorizationService
import ir.sabou.inventory.domain.treasury.TreasuryAccountCatalog
import ir.sabou.inventory.domain.treasury.TreasuryChannel
import ir.sabou.inventory.domain.treasury.TreasuryCommand
import ir.sabou.inventory.domain.treasury.TreasuryReversalCommand
import ir.sabou.inventory.domain.treasury.TreasuryService
import ir.sabou.inventory.domain.treasury.TreasuryTransaction
import ir.sabou.inventory.domain.treasury.TreasuryTransactionKind
import ir.sabou.inventory.domain.treasury.validated

/**
 * Boundary adapter for the current accounting-backed cash/bank foundation. It deliberately does
 * not create a second treasury balance source of truth; the accounting journal remains authoritative
 * until Treasury 2.0 introduces its own ledger.
 */
class LocalTreasuryServiceAdapter(
    private val accountingPosting: AccountingPostingService,
    private val authorizer: AuthorizationService,
    private val accountCatalog: TreasuryAccountCatalog = LegacyTreasuryAccountCatalog(),
) : TreasuryService {
    override suspend fun execute(command: TreasuryCommand): TreasuryTransaction {
        val valid = command.validated()
        return when (valid) {
            is TreasuryCommand.Payment -> postPayrollPayment(valid)
            is TreasuryCommand.Settlement -> throw unsupported(valid.sourceType, "settlement")
            is TreasuryCommand.Receipt -> throw unsupported(valid.sourceType, "receipt")
            is TreasuryCommand.InternalTransfer -> throw unsupported(valid.sourceType, "internal_transfer")
            is TreasuryCommand.Reconciliation -> throw unsupported(valid.sourceType, "reconciliation")
        }
    }

    override suspend fun reverse(command: TreasuryReversalCommand): TreasuryTransaction {
        val valid = command.validated()
        require(valid.sourceType == "PAYROLL_PAYMENT_REVERSAL") { "treasury_reversal_source_unsupported" }
        val account = accountCatalog.account(valid.accountId)
            ?: throw BusinessError.EntityNotFound("TREASURY_ACCOUNT", null).asViolation()
        require(account.isActive && account.channel == valid.channel) { "treasury_account_channel_mismatch" }
        val actor = authorizer.actorIdentity()
        val result = accountingPosting.reverse(
            AccountingReversalCommand(
                originalEntryId = valid.originalJournalEntryId,
                entryNo = "خز-ب-${valid.commandId.value.take(8)}",
                sourceType = valid.sourceType,
                sourceId = valid.sourceId,
                businessEpochDay = valid.businessEpochDay,
                reason = valid.reason,
                idempotencyKey = "TREASURY_REVERSAL:${valid.commandId.value}",
                correlationId = valid.correlationId,
                actorId = actor.id,
            ),
        )
        return TreasuryTransaction(
            id = valid.commandId.value,
            kind = TreasuryTransactionKind.PAYMENT,
            businessEpochDay = valid.businessEpochDay,
            correlationId = valid.correlationId,
            sourceType = valid.sourceType,
            sourceId = valid.sourceId,
            amount = valid.amount,
            journalEntryId = result.entryId,
            idempotentReplay = result.idempotentReplay,
        )
    }

    private suspend fun postPayrollPayment(command: TreasuryCommand.Payment): TreasuryTransaction {
        require(command.sourceType == "PAYROLL_PAYMENT") { "treasury_payment_source_unsupported" }
        val account = accountCatalog.account(command.accountId)
            ?: throw BusinessError.EntityNotFound("TREASURY_ACCOUNT", null).asViolation()
        require(account.isActive && account.channel == command.channel) { "treasury_account_channel_mismatch" }
        val actor = authorizer.actorIdentity()
        val cashRole = when (command.channel) {
            TreasuryChannel.CASH -> SemanticAccountRole.CASH
            TreasuryChannel.BANK -> SemanticAccountRole.BANK
            TreasuryChannel.CARD, TreasuryChannel.TRANSFER -> throw unsupported(command.sourceType, command.channel.storedValue)
        }
        val result = accountingPosting.post(
            AccountingPostingCommand(
                entryNo = "خز-${command.commandId.value.take(8)}",
                sourceType = command.sourceType,
                sourceId = command.sourceId,
                businessEpochDay = command.businessEpochDay,
                description = command.reason,
                lines = listOf(
                    SemanticJournalLine(
                        SemanticAccountRole.PAYROLL_PAYABLE,
                        debit = command.amount,
                        memo = "تسویه بدهی حقوق",
                    ),
                    SemanticJournalLine(
                        cashRole,
                        credit = command.amount,
                        memo = "پرداخت از ${account.name}",
                    ),
                ),
                idempotencyKey = "TREASURY:${command.commandId.value}",
                correlationId = command.correlationId,
                actorId = actor.id,
                status = JournalStatus.POSTED,
            ),
        )
        return TreasuryTransaction(
            id = command.commandId.value,
            kind = TreasuryTransactionKind.PAYMENT,
            businessEpochDay = command.businessEpochDay,
            correlationId = command.correlationId,
            sourceType = command.sourceType,
            sourceId = command.sourceId,
            amount = command.amount,
            journalEntryId = result.entryId,
            idempotentReplay = result.idempotentReplay,
        )
    }

    private fun unsupported(sourceType: String, operation: String) =
        BusinessError.UnsupportedDomainOperation("treasury_adapter:$sourceType", operation).asViolation()
}

