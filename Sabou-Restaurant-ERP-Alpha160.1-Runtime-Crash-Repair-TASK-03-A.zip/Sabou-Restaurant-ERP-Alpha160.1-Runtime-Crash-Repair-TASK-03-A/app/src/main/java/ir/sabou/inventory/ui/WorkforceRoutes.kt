package ir.sabou.inventory.ui

import androidx.compose.runtime.Composable

@Composable
internal fun WorkforceRoutes(
    screen: AppScreen,
    personnelState: PersonnelUiState,
    hrPayrollState: HrPayrollUiState,
    personnel: PersonnelViewModel,
    performanceState: PerformanceUiState,
    performance: PerformanceViewModel,
    assetState: AssetUiState,
    assets: AssetViewModel,
    workforceControlState: ControlCenterUiState,
    workforceControl: ManagementControlViewModel,
    requestedEmployeeProfileId: Long?,
    onProfileRequestConsumed: () -> Unit,
    navigateBack: () -> Unit,
) {
    when (screen) {
        AppScreen.PERSONNEL -> HrPayrollWorkspaceScreen(
            personnelState = personnelState,
            hrState = hrPayrollState,
            requestedProfileEmployeeId = requestedEmployeeProfileId,
            onProfileRequestConsumed = onProfileRequestConsumed,
            performanceState = performanceState,
            workforceState = workforceControlState,
            personnel = personnel,
            performance = performance,
            workforce = workforceControl,
            onBack = navigateBack,
        )

        AppScreen.ASSETS -> AssetScreen(
            state = assetState,
            onSave = assets::save,
            onRecognize = assets::recognize,
            onDispose = assets::dispose,
            onDepreciate = assets::depreciate,
            onBack = navigateBack,
        )

        else -> error("workforce_route_group_mismatch:${screen.name}")
    }
}
