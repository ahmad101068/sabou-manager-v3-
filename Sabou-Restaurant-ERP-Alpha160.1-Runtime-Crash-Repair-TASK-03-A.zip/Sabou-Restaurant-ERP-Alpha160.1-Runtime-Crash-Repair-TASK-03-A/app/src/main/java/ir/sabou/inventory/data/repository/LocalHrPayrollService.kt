package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.CorrelationId
import ir.sabou.inventory.core.FixedPointRatio
import ir.sabou.inventory.core.FixedPointRounding
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AttendanceCorrectionEntity
import ir.sabou.inventory.data.db.AttendanceEntity
import ir.sabou.inventory.data.db.AttendanceEventEntity
import ir.sabou.inventory.data.db.EmployeeAdvanceEntity
import ir.sabou.inventory.data.db.EmployeeEntity
import ir.sabou.inventory.data.db.EmploymentContractVersionEntity
import ir.sabou.inventory.data.db.HrPayrollCommandReceiptEntity
import ir.sabou.inventory.data.db.LeaveEntity
import ir.sabou.inventory.data.db.PayrollAdvanceAllocationV2Entity
import ir.sabou.inventory.data.db.PayrollApprovalEventEntity
import ir.sabou.inventory.data.db.PayrollBatchEntity
import ir.sabou.inventory.data.db.PayrollBatchDashboardRow
import ir.sabou.inventory.data.db.EmployeeTimelineRow
import ir.sabou.inventory.data.db.PayrollComponentEntity
import ir.sabou.inventory.data.db.PayrollExceptionEntity
import ir.sabou.inventory.data.db.PayrollManualAdjustmentEntity
import ir.sabou.inventory.data.db.PayrollPaymentEntity
import ir.sabou.inventory.data.db.PayrollPayslipEntity
import ir.sabou.inventory.data.db.PayrollPeriodEntity
import ir.sabou.inventory.data.db.PayrollPolicyEntity
import ir.sabou.inventory.data.db.PayrollSnapshotEntity
import ir.sabou.inventory.domain.accounting.AccountingPostingCommand
import ir.sabou.inventory.domain.accounting.AccountingPostingService
import ir.sabou.inventory.domain.accounting.AccountingReversalCommand
import ir.sabou.inventory.domain.accounting.JournalStatus
import ir.sabou.inventory.domain.audit.AuditAction
import ir.sabou.inventory.domain.audit.AuditEntityType
import ir.sabou.inventory.domain.audit.AuditEventDraft
import ir.sabou.inventory.domain.audit.AuditService
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.BusinessRuleViolation
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.personnel.AdvanceDeductionAllocation
import ir.sabou.inventory.domain.personnel.AdvanceDeductionAllocator
import ir.sabou.inventory.domain.personnel.ApproveManualAdjustmentCommand
import ir.sabou.inventory.domain.personnel.ApprovePayrollBatchCommand
import ir.sabou.inventory.domain.personnel.AttendanceAggregationPolicy
import ir.sabou.inventory.domain.personnel.AttendanceAnomaly
import ir.sabou.inventory.domain.personnel.AttendanceCorrectionCodec
import ir.sabou.inventory.domain.personnel.AttendanceEvent
import ir.sabou.inventory.domain.personnel.AttendanceEventAggregator
import ir.sabou.inventory.domain.personnel.AttendanceEventType
import ir.sabou.inventory.domain.personnel.AttendanceSource
import ir.sabou.inventory.domain.personnel.CalculatePayrollBatchCommand
import ir.sabou.inventory.domain.personnel.ClosePayrollPeriodCommand
import ir.sabou.inventory.domain.personnel.DailyAttendanceStatus
import ir.sabou.inventory.domain.personnel.EffectiveContractResolver
import ir.sabou.inventory.domain.personnel.EmploymentContractStatus
import ir.sabou.inventory.domain.personnel.EmploymentContractType
import ir.sabou.inventory.domain.personnel.EmploymentContractVersion
import ir.sabou.inventory.domain.personnel.EmploymentStatus
import ir.sabou.inventory.domain.personnel.EmployeeTimelineItem
import ir.sabou.inventory.domain.personnel.HrPayrollCommandService
import ir.sabou.inventory.domain.personnel.LeaveType
import ir.sabou.inventory.domain.personnel.ManualAdjustmentStatus
import ir.sabou.inventory.domain.personnel.ManualPayrollAdjustmentCommand
import ir.sabou.inventory.domain.personnel.ManualPayrollAdjustmentRecordV2
import ir.sabou.inventory.domain.personnel.OpenAdvanceBalance
import ir.sabou.inventory.domain.personnel.PayPayslipCommand
import ir.sabou.inventory.domain.personnel.PayrollAccountingPlanner
import ir.sabou.inventory.domain.personnel.PayrollApprovalRecordV2
import ir.sabou.inventory.domain.personnel.PayrollBatchCalculationOutcome
import ir.sabou.inventory.domain.personnel.PayrollBatchDraftV2
import ir.sabou.inventory.domain.personnel.PayrollBatchRecordV2
import ir.sabou.inventory.domain.personnel.PayrollBatchStateMachine
import ir.sabou.inventory.domain.personnel.PayrollBatchStatus
import ir.sabou.inventory.domain.personnel.PayrollCalculationCommand
import ir.sabou.inventory.domain.personnel.PayrollCalculationResultV2
import ir.sabou.inventory.domain.personnel.PayrollCalculationService
import ir.sabou.inventory.domain.personnel.PayrollComponentDirection
import ir.sabou.inventory.domain.personnel.PayrollComponentDraftV2
import ir.sabou.inventory.domain.personnel.PayrollComponentSourceType
import ir.sabou.inventory.domain.personnel.PayrollComponentType
import ir.sabou.inventory.domain.personnel.PayrollDocumentSource
import ir.sabou.inventory.domain.personnel.PayrollExceptionRecord
import ir.sabou.inventory.domain.personnel.PayrollInputSnapshot
import ir.sabou.inventory.domain.personnel.PayrollPaymentRecordV2
import ir.sabou.inventory.domain.personnel.PayrollPaymentLedger
import ir.sabou.inventory.domain.personnel.PayrollPaymentLedgerEntry
import ir.sabou.inventory.domain.personnel.PayrollPaymentStatus
import ir.sabou.inventory.domain.personnel.PayrollPayslipDetailV2
import ir.sabou.inventory.domain.personnel.PayrollPayslipRecordV2
import ir.sabou.inventory.domain.personnel.PayrollPayslipStateMachine
import ir.sabou.inventory.domain.personnel.PayrollPayslipStatus
import ir.sabou.inventory.domain.personnel.PayrollPeriodDraftV2
import ir.sabou.inventory.domain.personnel.PayrollPeriodRecordV2
import ir.sabou.inventory.domain.personnel.PayrollPeriodStateMachine
import ir.sabou.inventory.domain.personnel.PayrollPeriodStatus
import ir.sabou.inventory.domain.personnel.ReopenPayrollPeriodCommand
import ir.sabou.inventory.domain.personnel.ReversePayrollPaymentCommand
import ir.sabou.inventory.domain.personnel.ReversePayslipCommandV2
import ir.sabou.inventory.domain.personnel.ReviewPayrollBatchCommand
import ir.sabou.inventory.domain.security.AuthorizationService
import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.security.SegregationOfDuties
import ir.sabou.inventory.domain.treasury.TreasuryAccountId
import ir.sabou.inventory.domain.treasury.TreasuryCommand
import ir.sabou.inventory.domain.treasury.TreasuryReversalCommand
import ir.sabou.inventory.domain.treasury.TreasuryService
import java.security.MessageDigest
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

/**
 * Transactional HR/Payroll 2.0 application service. Mutable HR records are read only while a new
 * document is being calculated; every approved financial fact is then served from its snapshot and
 * append-only ledgers.
 */
class LocalHrPayrollService(
    private val database: AppDatabase,
    private val authorizer: AuthorizationService,
    private val accountingPosting: AccountingPostingService,
    private val treasury: TreasuryService,
    private val audit: AuditService = LocalAuditEventWriter(database),
    private val clock: () -> Long = System::currentTimeMillis,
) : HrPayrollCommandService {
    private val hr = database.hrPayrollDao()
    private val personnel = database.personnelDao()

    override val periods: Flow<List<PayrollPeriodRecordV2>> = authorizedFlow(Permission.PAYROLL_VIEW_ALL) {
        hr.observePayrollPeriods().map { rows -> rows.map(PayrollPeriodEntity::toRecord) }
    }

    override val batches: Flow<List<PayrollBatchRecordV2>> = authorizedFlow(Permission.PAYROLL_VIEW_ALL) {
        hr.observePayrollBatchDashboard().map { rows -> rows.map(PayrollBatchDashboardRow::toRecord) }
    }

    override fun employeePayslips(employeeId: Long, limit: Int, offset: Int): Flow<List<PayrollPayslipRecordV2>> {
        require(employeeId > 0 && limit in 1..200 && offset >= 0)
        return authorizedFlow(Permission.PAYROLL_VIEW_ALL) {
            hr.observeEmployeePayslipPage(employeeId, limit, offset).map { rows -> rows.map(PayrollPayslipEntity::toRecord) }
        }
    }

    override fun employeeTimeline(employeeId: Long, limit: Int, offset: Int): Flow<List<EmployeeTimelineItem>> {
        require(employeeId > 0 && limit in 1..200 && offset >= 0)
        return authorizedFlow(Permission.PAYROLL_VIEW_ALL) {
            hr.observeEmployeeTimeline(employeeId, limit, offset).map { rows -> rows.map(EmployeeTimelineRow::toDomain) }
        }
    }

    override suspend fun payslipDetail(payslipId: Long): PayrollPayslipDetailV2 {
        authorizer.require(Permission.PAYROLL_VIEW_ALL)
        return database.withTransaction {
            val payslip = hr.payrollPayslip(payslipId) ?: missing("PAYROLL_PAYSLIP", payslipId)
            val period = hr.payrollPeriod(payslip.periodId) ?: missing("PAYROLL_PERIOD", payslip.periodId)
            val batch = hr.payrollBatch(payslip.batchId) ?: missing("PAYROLL_BATCH", payslip.batchId)
            val snapshot = hr.payrollSnapshot(payslip.id)?.toDomainOrNull()
            val components = hr.payrollComponents(payslip.id).map(PayrollComponentEntity::toDraft)
            val payments = hr.payrollPayments(payslip.id).map(PayrollPaymentEntity::toRecord)
            val approvals = hr.payrollApprovalHistory(payslip.id, payslip.batchId).map {
                PayrollApprovalRecordV2(
                    id = it.id,
                    eventType = it.eventType,
                    fromStatus = it.fromStatus,
                    toStatus = it.toStatus,
                    actorId = it.actorId,
                    reason = it.reason,
                    createdAtEpochMillis = it.createdAtEpochMillis,
                )
            }
            val allocations = hr.payslipAdvanceAllocations(payslip.id)
                .filter { it.status == "ALLOCATED" }
                .map { AdvanceDeductionAllocation(it.advanceId, it.amountRial) }
            PayrollPayslipDetailV2(
                payslip = payslip.toRecord(),
                period = period.toRecord(),
                batch = batch.toRecord(),
                snapshot = snapshot,
                components = components,
                payments = payments,
                approvalHistory = approvals,
                advanceAllocations = allocations,
                accrualJournalEntryId = payslip.accrualJournalEntryId,
                reversalJournalEntryId = payslip.reversalJournalEntryId,
            )
        }
    }

    override suspend fun manualAdjustments(periodId: Long): List<ManualPayrollAdjustmentRecordV2> {
        authorizer.require(Permission.PAYROLL_VIEW_ALL)
        require(periodId > 0)
        return hr.manualAdjustmentsForPeriod(periodId).map(PayrollManualAdjustmentEntity::toRecord)
    }

    override suspend fun openPeriod(draft: PayrollPeriodDraftV2): Long {
        val actor = authorizer.require(Permission.PAYROLL_CREATE)
        val valid = draft.validated()
        val key = receiptKey("OPEN_PERIOD", valid.commandId)
        val payload = hash("${valid.periodKey}|${valid.startEpochDay}|${valid.endEpochDay}|${valid.paymentDueEpochDay}")
        val correlation = correlation("payroll_period", valid.commandId)
        return database.withTransaction {
            replay(key, "OPEN_PERIOD", payload)?.let { return@withTransaction it.resultEntityId }
            hr.payrollPeriodByKey(valid.periodKey)?.let {
                throw BusinessError.DuplicateDocument("PAYROLL_PERIOD", valid.periodKey).asViolation()
            }
            val now = clock()
            val id = hr.insertPayrollPeriod(
                PayrollPeriodEntity(
                    periodKey = valid.periodKey,
                    startEpochDay = valid.startEpochDay,
                    endEpochDay = valid.endEpochDay,
                    paymentDueEpochDay = valid.paymentDueEpochDay,
                    status = PayrollPeriodStatus.OPEN.storedValue,
                    openedByActorId = actor.id,
                    openedAtEpochMillis = now,
                    closedAtEpochMillis = null,
                    reopenedAtEpochMillis = null,
                    rowVersion = 0,
                    source = PayrollDocumentSource.NATIVE.storedValue,
                ),
            )
            recordAudit(
                actor.id,
                actor.displayName,
                "OPEN",
                "PAYROLL_PERIOD",
                id,
                valid.startEpochDay,
                "ایجاد دوره حقوق ${valid.periodKey}",
                "ایجاد دوره حقوق",
                correlation.value,
                null,
                "status=OPEN;periodKey=${valid.periodKey}",
            )
            receipt(key, "OPEN_PERIOD", payload, "PAYROLL_PERIOD", id, "OPEN", actor.id, now, correlation.value)
            id
        }
    }

    override suspend fun closePeriod(command: ClosePayrollPeriodCommand) {
        val actor = authorizer.require(Permission.PAYROLL_APPROVE)
        val valid = command.validated()
        val key = receiptKey("CLOSE_PERIOD", valid.commandId)
        val payload = hash("${valid.periodId}|${valid.reason}")
        val correlation = correlation("payroll_period_close", valid.commandId)
        database.withTransaction {
            replay(key, "CLOSE_PERIOD", payload)?.let { return@withTransaction }
            val period = hr.payrollPeriod(valid.periodId) ?: missing("PAYROLL_PERIOD", valid.periodId)
            val from = PayrollPeriodStatus.fromStoredValue(period.status)
            val batches = hr.payrollBatchesForPeriod(period.id)
            val nonTerminal = batches.filter {
                PayrollBatchStatus.fromStoredValue(it.status) !in setOf(
                    PayrollBatchStatus.PAID,
                    PayrollBatchStatus.REVERSED,
                    PayrollBatchStatus.CANCELLED,
                    PayrollBatchStatus.LEGACY,
                )
            }
            if (nonTerminal.isNotEmpty()) {
                throw BusinessError.InvalidBusinessState("PAYROLL_PERIOD", "UNSETTLED_BATCHES").asViolation()
            }
            PayrollPeriodStateMachine.requireTransition(from, PayrollPeriodStatus.CLOSED)
            val now = clock()
            optimistic(
                hr.transitionPayrollPeriod(
                    period.id,
                    from.storedValue,
                    PayrollPeriodStatus.CLOSED.storedValue,
                    period.rowVersion,
                    now,
                    null,
                ),
                "PAYROLL_PERIOD",
                period.id,
            )
            recordAudit(actor.id, actor.displayName, "CLOSE", "PAYROLL_PERIOD", period.id, period.endEpochDay, valid.reason, valid.reason, correlation.value, "status=${from.storedValue}", "status=CLOSED")
            receipt(key, "CLOSE_PERIOD", payload, "PAYROLL_PERIOD", period.id, "CLOSED", actor.id, now, correlation.value)
        }
    }

    override suspend fun reopenPeriod(command: ReopenPayrollPeriodCommand) {
        val actor = authorizer.require(Permission.PAYROLL_APPROVE)
        val valid = command.validated()
        val key = receiptKey("REOPEN_PERIOD", valid.commandId)
        val payload = hash("${valid.periodId}|${valid.reason}")
        val correlation = correlation("payroll_period_reopen", valid.commandId)
        database.withTransaction {
            replay(key, "REOPEN_PERIOD", payload)?.let { return@withTransaction }
            val period = hr.payrollPeriod(valid.periodId) ?: missing("PAYROLL_PERIOD", valid.periodId)
            val from = PayrollPeriodStatus.fromStoredValue(period.status)
            PayrollPeriodStateMachine.requireTransition(from, PayrollPeriodStatus.REOPENED)
            val now = clock()
            optimistic(
                hr.transitionPayrollPeriod(
                    period.id,
                    from.storedValue,
                    PayrollPeriodStatus.REOPENED.storedValue,
                    period.rowVersion,
                    null,
                    now,
                ),
                "PAYROLL_PERIOD",
                period.id,
            )
            recordAudit(actor.id, actor.displayName, "REOPEN", "PAYROLL_PERIOD", period.id, period.endEpochDay, valid.reason, valid.reason, correlation.value, "status=CLOSED", "status=REOPENED")
            receipt(key, "REOPEN_PERIOD", payload, "PAYROLL_PERIOD", period.id, "REOPENED", actor.id, now, correlation.value)
        }
    }

    override suspend fun createBatch(draft: PayrollBatchDraftV2): Long {
        val actor = authorizer.require(Permission.PAYROLL_CREATE)
        val valid = draft.validated()
        val key = receiptKey("CREATE_BATCH", valid.commandId)
        val payload = hash("${valid.periodId}|${valid.scope}|${valid.branchName}|${valid.department}|${valid.notes}")
        val correlation = correlation("payroll_batch", valid.commandId)
        return database.withTransaction {
            replay(key, "CREATE_BATCH", payload)?.let { return@withTransaction it.resultEntityId }
            val period = hr.payrollPeriod(valid.periodId) ?: missing("PAYROLL_PERIOD", valid.periodId)
            val periodStatus = PayrollPeriodStatus.fromStoredValue(period.status)
            if (periodStatus !in setOf(PayrollPeriodStatus.OPEN, PayrollPeriodStatus.REOPENED, PayrollPeriodStatus.CALCULATING)) {
                throw BusinessError.PayrollPeriodClosed(period.id).asViolation()
            }
            val now = clock()
            val documentNumber = "PAY-${period.periodKey}-${valid.commandId.take(8).uppercase()}"
            val id = hr.insertPayrollBatch(
                PayrollBatchEntity(
                    documentNumber = documentNumber,
                    idempotencyKey = key,
                    periodId = period.id,
                    scope = valid.scope,
                    branchName = valid.branchName,
                    department = valid.department,
                    status = PayrollBatchStatus.DRAFT.storedValue,
                    createdByActorId = actor.id,
                    calculatedByActorId = null,
                    calculatedAtEpochMillis = null,
                    reviewedByActorId = null,
                    reviewedAtEpochMillis = null,
                    approvedByActorId = null,
                    approvedAtEpochMillis = null,
                    correlationId = correlation.value,
                    notes = valid.notes,
                    rowVersion = 0,
                    accrualJournalEntryId = null,
                    reversalJournalEntryId = null,
                    source = PayrollDocumentSource.NATIVE.storedValue,
                ),
            )
            recordAudit(actor.id, actor.displayName, "CREATE", "PAYROLL_BATCH", id, period.endEpochDay, valid.notes.ifBlank { "ایجاد دسته حقوق" }, "ایجاد دسته حقوق $documentNumber", correlation.value, null, "status=DRAFT;scope=${valid.scope}")
            receipt(key, "CREATE_BATCH", payload, "PAYROLL_BATCH", id, "DRAFT", actor.id, now, correlation.value)
            id
        }
    }

    override suspend fun calculateBatch(command: CalculatePayrollBatchCommand): PayrollBatchCalculationOutcome {
        val actor = authorizer.require(Permission.PAYROLL_CALCULATE)
        val valid = command.validated()
        val key = receiptKey("CALCULATE_BATCH", valid.commandId)
        val payload = hash(calculatePayload(valid))
        val correlation = correlation("payroll_calculate", valid.commandId)
        return database.withTransaction {
            replay(key, "CALCULATE_BATCH", payload)?.let {
                return@withTransaction PayrollBatchCalculationOutcome(
                    batchId = valid.batchId,
                    payslipIds = hr.batchPayslips(valid.batchId).map { row -> row.id },
                    exceptions = hr.unresolvedPayrollExceptions(valid.batchId).map(PayrollExceptionEntity::toRecord),
                    idempotentReplay = true,
                )
            }
            val batch = hr.payrollBatch(valid.batchId) ?: missing("PAYROLL_BATCH", valid.batchId)
            if (PayrollBatchStatus.fromStoredValue(batch.status) != PayrollBatchStatus.DRAFT) {
                throw BusinessError.PayrollAlreadyCalculated(batch.id).asViolation()
            }
            val period = hr.payrollPeriod(batch.periodId) ?: missing("PAYROLL_PERIOD", batch.periodId)
            val periodStatus = PayrollPeriodStatus.fromStoredValue(period.status)
            if (periodStatus !in setOf(PayrollPeriodStatus.OPEN, PayrollPeriodStatus.REOPENED, PayrollPeriodStatus.CALCULATING)) {
                throw BusinessError.PayrollPeriodClosed(period.id).asViolation()
            }

            val loaded = loadCalculationInputs(valid.employeeIds, period)
            val preparation = prepareBatch(valid, batch, period, loaded, actor.id)
            val now = clock()
            hr.clearUnresolvedPayrollExceptions(batch.id)
            if (preparation.exceptions.isNotEmpty()) {
                hr.insertPayrollExceptions(preparation.exceptions.map { it.toEntity(batch.id, now) })
            }
            if (preparation.exceptions.any { it.blocking }) {
                recordAudit(actor.id, actor.displayName, "CALCULATE_BLOCKED", "PAYROLL_BATCH", batch.id, period.endEpochDay, "وجود خطاهای مسدودکننده", "محاسبه دسته حقوق متوقف شد", correlation.value, "status=DRAFT", "exceptions=${preparation.exceptions.size}")
                receipt(key, "CALCULATE_BATCH", payload, "PAYROLL_BATCH", batch.id, "BLOCKED", actor.id, now, correlation.value)
                return@withTransaction PayrollBatchCalculationOutcome(batch.id, emptyList(), preparation.exceptions, false)
            }

            val payslipIds = preparation.payslips.map { prepared ->
                val payslipCorrelation = CorrelationId.parse("${correlation.value}:employee:${prepared.employee.id}")
                val payslipId = hr.insertPayrollPayslip(
                    PayrollPayslipEntity(
                        globalId = GlobalId.new().value,
                        batchId = batch.id,
                        periodId = period.id,
                        employeeId = prepared.employee.id,
                        employeeCodeSnapshot = requireNotNull(prepared.employee.employeeCode).trim(),
                        employeeNameSnapshot = prepared.employee.displayName.ifBlank { prepared.employee.name },
                        revisionNo = prepared.revisionNo,
                        replacesPayslipId = prepared.replacesPayslipId,
                        legacyPayrollRunId = null,
                        contractId = prepared.contract.id,
                        status = PayrollPayslipStatus.CALCULATED.storedValue,
                        grossPayRial = prepared.result.grossPayRial,
                        totalDeductionsRial = prepared.result.totalDeductionsRial,
                        netPayRial = prepared.result.netPayRial,
                        paidAmountRial = 0,
                        remainingAmountRial = prepared.result.netPayRial,
                        componentDetailComplete = true,
                        calculatedAtEpochMillis = now,
                        approvedAtEpochMillis = null,
                        paidAtEpochMillis = null,
                        correlationId = payslipCorrelation.value,
                        source = PayrollDocumentSource.NATIVE.storedValue,
                        rowVersion = 0,
                        accrualJournalEntryId = null,
                        reversalJournalEntryId = null,
                        reversalReason = null,
                        reversalEpochDay = null,
                        reversedAtEpochMillis = null,
                    ),
                )
                val snapshotHash = snapshotHash(
                    prepared.result.snapshot,
                    prepared.result.components,
                    prepared.traceParameters,
                    prepared.result.grossPayRial,
                    prepared.result.totalDeductionsRial,
                    prepared.result.netPayRial,
                )
                hr.insertPayrollSnapshot(prepared.toSnapshotEntity(payslipId, snapshotHash, now))
                hr.insertPayrollComponents(
                    prepared.result.components.map { component -> component.toEntity(payslipId, now) },
                )
                if (prepared.manualAdjustmentIds.isNotEmpty()) {
                    optimistic(
                        hr.consumeManualAdjustments(prepared.manualAdjustmentIds, payslipId)
                            .takeIf { it == prepared.manualAdjustmentIds.size }
                            ?: 0,
                        "PAYROLL_MANUAL_ADJUSTMENT",
                        payslipId,
                    )
                }
                payslipId
            }
            optimistic(
                hr.transitionPayrollBatch(
                    id = batch.id,
                    fromStatus = PayrollBatchStatus.DRAFT.storedValue,
                    toStatus = PayrollBatchStatus.CALCULATED.storedValue,
                    expectedVersion = batch.rowVersion,
                    calculatedBy = actor.id,
                    calculatedAt = now,
                ),
                "PAYROLL_BATCH",
                batch.id,
            )
            if (periodStatus in setOf(PayrollPeriodStatus.OPEN, PayrollPeriodStatus.REOPENED)) {
                PayrollPeriodStateMachine.requireTransition(periodStatus, PayrollPeriodStatus.CALCULATING)
                optimistic(
                    hr.transitionPayrollPeriod(
                        period.id,
                        periodStatus.storedValue,
                        PayrollPeriodStatus.CALCULATING.storedValue,
                        period.rowVersion,
                        null,
                        null,
                    ),
                    "PAYROLL_PERIOD",
                    period.id,
                )
            }
            hr.insertApprovalEvent(
                approvalEvent(batch.id, null, "CALCULATE", "DRAFT", "CALCULATED", actor.id, "محاسبه قطعی Snapshot", null, now, correlation.value),
            )
            recordAudit(actor.id, actor.displayName, "CALCULATE", "PAYROLL_BATCH", batch.id, period.endEpochDay, "محاسبه حقوق", "محاسبه ${payslipIds.size} فیش حقوق", correlation.value, "status=DRAFT", "status=CALCULATED;payslips=${payslipIds.size}")
            receipt(key, "CALCULATE_BATCH", payload, "PAYROLL_BATCH", batch.id, payslipIds.joinToString(","), actor.id, now, correlation.value)
            PayrollBatchCalculationOutcome(batch.id, payslipIds, preparation.exceptions, false)
        }
    }

    override suspend fun submitBatchForReview(command: ReviewPayrollBatchCommand) {
        val actor = authorizer.require(Permission.PAYROLL_REVIEW)
        val valid = command.validated()
        val key = receiptKey("REVIEW_BATCH", valid.commandId)
        val payload = hash("${valid.batchId}|${valid.note}")
        val correlation = correlation("payroll_review", valid.commandId)
        database.withTransaction {
            replay(key, "REVIEW_BATCH", payload)?.let { return@withTransaction }
            val batch = hr.payrollBatch(valid.batchId) ?: missing("PAYROLL_BATCH", valid.batchId)
            val from = PayrollBatchStatus.fromStoredValue(batch.status)
            PayrollBatchStateMachine.requireTransition(from, PayrollBatchStatus.UNDER_REVIEW)
            val payslips = hr.batchPayslips(batch.id)
            require(payslips.isNotEmpty()) { "payroll_batch_has_no_payslips" }
            val now = clock()
            payslips.forEach { payslip ->
                val payslipFrom = PayrollPayslipStatus.fromStoredValue(payslip.status)
                PayrollPayslipStateMachine.requireTransition(payslipFrom, PayrollPayslipStatus.UNDER_REVIEW)
                optimistic(
                    hr.transitionPayrollPayslip(payslip.id, payslipFrom.storedValue, PayrollPayslipStatus.UNDER_REVIEW.storedValue, payslip.rowVersion),
                    "PAYROLL_PAYSLIP",
                    payslip.id,
                )
            }
            optimistic(
                hr.transitionPayrollBatch(
                    batch.id,
                    from.storedValue,
                    PayrollBatchStatus.UNDER_REVIEW.storedValue,
                    batch.rowVersion,
                    reviewedBy = actor.id,
                    reviewedAt = now,
                ),
                "PAYROLL_BATCH",
                batch.id,
            )
            val period = hr.payrollPeriod(batch.periodId) ?: missing("PAYROLL_PERIOD", batch.periodId)
            val periodFrom = PayrollPeriodStatus.fromStoredValue(period.status)
            if (periodFrom == PayrollPeriodStatus.CALCULATING) {
                PayrollPeriodStateMachine.requireTransition(periodFrom, PayrollPeriodStatus.REVIEW)
                optimistic(hr.transitionPayrollPeriod(period.id, periodFrom.storedValue, PayrollPeriodStatus.REVIEW.storedValue, period.rowVersion, null, null), "PAYROLL_PERIOD", period.id)
            }
            hr.insertApprovalEvent(approvalEvent(batch.id, null, "REVIEW", from.storedValue, "UNDER_REVIEW", actor.id, valid.note, null, now, correlation.value))
            recordAudit(actor.id, actor.displayName, "REVIEW", "PAYROLL_BATCH", batch.id, period.endEpochDay, valid.note, "ارسال دسته حقوق برای تأیید", correlation.value, "status=${from.storedValue}", "status=UNDER_REVIEW")
            receipt(key, "REVIEW_BATCH", payload, "PAYROLL_BATCH", batch.id, "UNDER_REVIEW", actor.id, now, correlation.value)
        }
    }

    override suspend fun approveBatch(command: ApprovePayrollBatchCommand) {
        val actor = authorizer.require(Permission.PAYROLL_APPROVE)
        val valid = command.validated()
        val key = receiptKey("APPROVE_BATCH", valid.commandId)
        val payload = hash("${valid.batchId}|${valid.reason}")
        val correlation = correlation("payroll_approve", valid.commandId)
        database.withTransaction {
            replay(key, "APPROVE_BATCH", payload)?.let { return@withTransaction }
            val batch = hr.payrollBatch(valid.batchId) ?: missing("PAYROLL_BATCH", valid.batchId)
            val batchFrom = PayrollBatchStatus.fromStoredValue(batch.status)
            if (batchFrom in setOf(PayrollBatchStatus.APPROVED, PayrollBatchStatus.PAYMENT_PENDING, PayrollBatchStatus.PARTIALLY_PAID, PayrollBatchStatus.PAID)) {
                throw BusinessError.PayrollAlreadyApproved(batch.id).asViolation()
            }
            PayrollBatchStateMachine.requireTransition(batchFrom, PayrollBatchStatus.APPROVED)
            batch.createdByActorId?.let { SegregationOfDuties.requireDifferentActors("PAYROLL_CREATOR_APPROVAL", it, actor.id) }
            batch.calculatedByActorId?.let { SegregationOfDuties.requireDifferentActors("PAYROLL_CALCULATOR_APPROVAL", it, actor.id) }
            if (hr.unresolvedPayrollExceptions(batch.id).any { it.blocking }) {
                throw BusinessError.ApprovalRequired("PAYROLL_EXCEPTIONS", 1).asViolation()
            }
            val period = hr.payrollPeriod(batch.periodId) ?: missing("PAYROLL_PERIOD", batch.periodId)
            if (PayrollPeriodStatus.fromStoredValue(period.status) != PayrollPeriodStatus.REVIEW) {
                throw BusinessError.InvalidBusinessState("PAYROLL_PERIOD", period.status).asViolation()
            }
            val payslips = hr.batchPayslips(batch.id)
            require(payslips.isNotEmpty()) { "payroll_batch_has_no_payslips" }
            val snapshots = hr.payrollSnapshotsForBatch(batch.id).associateBy { it.payslipId }
            val componentsByPayslip = hr.payrollComponentsForBatch(batch.id).groupBy { it.payslipId }
            val includedEmployeeIds = payslips.map { it.employeeId }.toSet()
            val submittedAdjustments = hr.manualAdjustmentsForPeriod(period.id).filter {
                it.employeeId in includedEmployeeIds && it.status == ManualAdjustmentStatus.SUBMITTED.storedValue
            }
            if (submittedAdjustments.isNotEmpty()) {
                throw BusinessError.ApprovalRequired("MANUAL_ADJUSTMENT_NOT_APPROVED", 1).asViolation()
            }
            val unconsumedAdjustments = loadApprovedAdjustments(payslips.map { it.employeeId }, period.id)
            if (unconsumedAdjustments.isNotEmpty()) {
                throw BusinessError.ApprovalRequired("UNCONSUMED_MANUAL_ADJUSTMENT", 1).asViolation()
            }
            payslips.forEach { payslip ->
                require(PayrollPayslipStatus.fromStoredValue(payslip.status) == PayrollPayslipStatus.UNDER_REVIEW) {
                    "payslip_not_under_review:${payslip.id}"
                }
                val snapshot = snapshots[payslip.id] ?: throw BusinessError.InvalidBusinessState("PAYROLL_SNAPSHOT", "MISSING").asViolation()
                require(snapshot.detailComplete && payslip.componentDetailComplete) { "payroll_snapshot_incomplete:${payslip.id}" }
                val components = componentsByPayslip[payslip.id].orEmpty()
                require(components.isNotEmpty() || payslip.grossPayRial == 0L) { "payroll_components_missing:${payslip.id}" }
                val actualHash = snapshotHash(
                    snapshot.toDomainRequired(),
                    components.map(PayrollComponentEntity::toDraft),
                    snapshot.calculationParameters,
                    snapshot.grossPayRial,
                    snapshot.totalDeductionsRial,
                    snapshot.netPayRial,
                )
                require(actualHash == snapshot.snapshotHash) { "payroll_snapshot_hash_mismatch:${payslip.id}" }
            }

            val now = clock()
            val journalIds = mutableListOf<Long>()
            payslips.forEach { original ->
                val components = componentsByPayslip.getValue(original.id).map(PayrollComponentEntity::toDraft)
                allocatePayslipAdvances(original, components, actor.id, now)
                val lines = PayrollAccountingPlanner.accrualLines(components, original.netPayRial)
                var expectedVersion = original.rowVersion
                if (lines.isNotEmpty()) {
                    val posting = accountingPosting.post(
                        AccountingPostingCommand(
                            entryNo = "PAY-${period.periodKey}-${original.employeeCodeSnapshot}-R${original.revisionNo}",
                            sourceType = "PAYROLL_ACCRUAL",
                            sourceId = original.id,
                            businessEpochDay = period.endEpochDay,
                            description = "شناسایی تعهد حقوق ${original.employeeNameSnapshot}",
                            lines = lines,
                            idempotencyKey = "PAYROLL_ACCRUAL:${original.globalId}",
                            correlationId = CorrelationId.parse(original.correlationId),
                            actorId = actor.id,
                            status = JournalStatus.POSTED,
                        ),
                    )
                    optimistic(hr.attachPayslipAccrualJournal(original.id, posting.entryId, expectedVersion), "PAYROLL_PAYSLIP", original.id)
                    expectedVersion += 1
                    journalIds += posting.entryId
                }
                optimistic(
                    hr.transitionPayrollPayslip(
                        original.id,
                        PayrollPayslipStatus.UNDER_REVIEW.storedValue,
                        PayrollPayslipStatus.APPROVED.storedValue,
                        expectedVersion,
                        approvedAt = now,
                    ),
                    "PAYROLL_PAYSLIP",
                    original.id,
                )
                expectedVersion += 1
                val settlement = PayrollPaymentLedger.derive(original.netPayRial, emptyList())
                optimistic(
                    hr.transitionPayrollPayslip(
                        original.id,
                        PayrollPayslipStatus.APPROVED.storedValue,
                        PayrollPayslipStatus.PAYMENT_PENDING.storedValue,
                        expectedVersion,
                    ),
                    "PAYROLL_PAYSLIP",
                    original.id,
                )
                expectedVersion += 1
                if (settlement.status == PayrollPayslipStatus.PAID) {
                    optimistic(
                        hr.transitionPayrollPayslip(
                            original.id,
                            PayrollPayslipStatus.PAYMENT_PENDING.storedValue,
                            PayrollPayslipStatus.PAID.storedValue,
                            expectedVersion,
                            paidAt = now,
                        ),
                        "PAYROLL_PAYSLIP",
                        original.id,
                    )
                }
                val snapshotHash = snapshots.getValue(original.id).snapshotHash
                hr.insertApprovalEvent(approvalEvent(batch.id, original.id, "APPROVE", "UNDER_REVIEW", settlement.status.storedValue, actor.id, valid.reason, snapshotHash, now, original.correlationId))
            }
            optimistic(
                hr.transitionPayrollBatch(
                    batch.id,
                    batchFrom.storedValue,
                    PayrollBatchStatus.APPROVED.storedValue,
                    batch.rowVersion,
                    approvedBy = actor.id,
                    approvedAt = now,
                    accrualJournalId = journalIds.firstOrNull(),
                ),
                "PAYROLL_BATCH",
                batch.id,
            )
            val batchSettledWithoutPayment = payslips.all { it.netPayRial == 0L }
            optimistic(
                hr.transitionPayrollBatch(
                    batch.id,
                    PayrollBatchStatus.APPROVED.storedValue,
                    PayrollBatchStatus.PAYMENT_PENDING.storedValue,
                    batch.rowVersion + 1,
                ),
                "PAYROLL_BATCH",
                batch.id,
            )
            if (batchSettledWithoutPayment) {
                optimistic(
                    hr.transitionPayrollBatch(
                        batch.id,
                        PayrollBatchStatus.PAYMENT_PENDING.storedValue,
                        PayrollBatchStatus.PAID.storedValue,
                        batch.rowVersion + 2,
                    ),
                    "PAYROLL_BATCH",
                    batch.id,
                )
            }
            val siblingBatches = hr.payrollBatchesForPeriod(period.id)
            val allReadyForPayment = siblingBatches.all {
                it.id == batch.id || PayrollBatchStatus.fromStoredValue(it.status) in setOf(
                    PayrollBatchStatus.PAYMENT_PENDING,
                    PayrollBatchStatus.PARTIALLY_PAID,
                    PayrollBatchStatus.PAID,
                    PayrollBatchStatus.REVERSED,
                    PayrollBatchStatus.CANCELLED,
                    PayrollBatchStatus.LEGACY,
                )
            }
            if (allReadyForPayment) {
                PayrollPeriodStateMachine.requireTransition(PayrollPeriodStatus.REVIEW, PayrollPeriodStatus.APPROVED)
                optimistic(hr.transitionPayrollPeriod(period.id, "REVIEW", "APPROVED", period.rowVersion, null, null), "PAYROLL_PERIOD", period.id)
                PayrollPeriodStateMachine.requireTransition(PayrollPeriodStatus.APPROVED, PayrollPeriodStatus.PAYMENT)
                optimistic(hr.transitionPayrollPeriod(period.id, "APPROVED", "PAYMENT", period.rowVersion + 1, null, null), "PAYROLL_PERIOD", period.id)
            }
            val finalBatchStatus = if (batchSettledWithoutPayment) PayrollBatchStatus.PAID else PayrollBatchStatus.PAYMENT_PENDING
            hr.insertApprovalEvent(approvalEvent(batch.id, null, "FINAL_APPROVAL", batchFrom.storedValue, finalBatchStatus.storedValue, actor.id, valid.reason, null, now, correlation.value))
            recordAudit(actor.id, actor.displayName, "APPROVE", "PAYROLL_BATCH", batch.id, period.endEpochDay, valid.reason, "تأیید نهایی و ثبت تعهد حقوق", correlation.value, "status=${batchFrom.storedValue}", "status=${finalBatchStatus.storedValue};journals=${journalIds.size}")
            receipt(key, "APPROVE_BATCH", payload, "PAYROLL_BATCH", batch.id, finalBatchStatus.storedValue, actor.id, now, correlation.value)
        }
    }

    override suspend fun submitManualAdjustment(command: ManualPayrollAdjustmentCommand): Long {
        val actor = authorizer.require(Permission.PAYROLL_CREATE)
        val valid = command.validated()
        val key = receiptKey("MANUAL_ADJUSTMENT", valid.commandId)
        val payload = hash("${valid.employeeId}|${valid.periodId}|${valid.componentType}|${valid.direction}|${valid.amountRial}|${valid.reason}|${valid.attachmentMetadata}")
        val correlation = correlation("payroll_adjustment", valid.commandId)
        return database.withTransaction {
            replay(key, "MANUAL_ADJUSTMENT", payload)?.let { return@withTransaction it.resultEntityId }
            personnel.employeeById(valid.employeeId) ?: missing("EMPLOYEE", valid.employeeId)
            val period = hr.payrollPeriod(valid.periodId) ?: missing("PAYROLL_PERIOD", valid.periodId)
            if (PayrollPeriodStatus.fromStoredValue(period.status) !in setOf(PayrollPeriodStatus.OPEN, PayrollPeriodStatus.REOPENED, PayrollPeriodStatus.CALCULATING, PayrollPeriodStatus.REVIEW)) {
                throw BusinessError.PayrollPeriodClosed(period.id).asViolation()
            }
            val now = clock()
            val id = hr.insertManualAdjustment(
                PayrollManualAdjustmentEntity(
                    globalId = valid.commandId,
                    idempotencyKey = key,
                    employeeId = valid.employeeId,
                    periodId = valid.periodId,
                    componentType = valid.componentType.storedValue,
                    direction = valid.direction.storedValue,
                    amountRial = valid.amountRial,
                    reason = valid.reason,
                    attachmentMetadata = valid.attachmentMetadata,
                    status = ManualAdjustmentStatus.SUBMITTED.storedValue,
                    createdByActorId = actor.id,
                    approvedByActorId = null,
                    createdAtEpochMillis = now,
                    approvedAtEpochMillis = null,
                    consumedByPayslipId = null,
                    correlationId = correlation.value,
                ),
            )
            recordAudit(actor.id, actor.displayName, "SUBMIT", "PAYROLL_ADJUSTMENT", id, period.endEpochDay, valid.reason, "ثبت تعدیل دستی حقوق", correlation.value, null, "status=SUBMITTED;type=${valid.componentType.storedValue}")
            receipt(key, "MANUAL_ADJUSTMENT", payload, "PAYROLL_ADJUSTMENT", id, "SUBMITTED", actor.id, now, correlation.value)
            id
        }
    }

    override suspend fun approveManualAdjustment(command: ApproveManualAdjustmentCommand) {
        val actor = authorizer.require(Permission.PAYROLL_REVIEW)
        val valid = command.validated()
        val key = receiptKey("APPROVE_ADJUSTMENT", valid.commandId)
        val payload = hash(valid.adjustmentId.toString())
        val correlation = correlation("payroll_adjustment_approve", valid.commandId)
        database.withTransaction {
            replay(key, "APPROVE_ADJUSTMENT", payload)?.let { return@withTransaction }
            val adjustment = hr.manualAdjustment(valid.adjustmentId) ?: missing("PAYROLL_ADJUSTMENT", valid.adjustmentId)
            SegregationOfDuties.requireDifferentActors("PAYROLL_MANUAL_ADJUSTMENT_APPROVAL", adjustment.createdByActorId, actor.id)
            val now = clock()
            optimistic(hr.approveManualAdjustment(adjustment.id, actor.id, now), "PAYROLL_ADJUSTMENT", adjustment.id)
            val period = hr.payrollPeriod(adjustment.periodId) ?: missing("PAYROLL_PERIOD", adjustment.periodId)
            recordAudit(actor.id, actor.displayName, "APPROVE", "PAYROLL_ADJUSTMENT", adjustment.id, period.endEpochDay, adjustment.reason, "تأیید تعدیل دستی حقوق", correlation.value, "status=${adjustment.status}", "status=APPROVED")
            receipt(key, "APPROVE_ADJUSTMENT", payload, "PAYROLL_ADJUSTMENT", adjustment.id, "APPROVED", actor.id, now, correlation.value)
        }
    }

    override suspend fun payPayslip(command: PayPayslipCommand): Long {
        val actor = authorizer.require(Permission.PAYROLL_PAY)
        val valid = command.validated()
        val key = receiptKey("PAY_PAYSLIP", valid.commandId)
        val payload = hash("${valid.payslipId}|${valid.amountRial}|${valid.treasuryAccountId}|${valid.channel}|${valid.paymentEpochDay}|${valid.paymentReference}")
        val correlation = correlation("payroll_payment", valid.commandId)
        return database.withTransaction {
            hr.payrollPaymentByKey(key)?.let { existing ->
                val existingPayload = hash("${existing.payslipId}|${existing.amountRial}|${existing.treasuryAccountId}|${existing.channel}|${existing.paymentEpochDay}|${existing.paymentReference}")
                if (existingPayload != payload) throw BusinessError.IdempotencyConflict(key).asViolation()
                return@withTransaction existing.id
            }
            val payslip = hr.payrollPayslip(valid.payslipId) ?: missing("PAYROLL_PAYSLIP", valid.payslipId)
            val currentStatus = PayrollPayslipStatus.fromStoredValue(payslip.status)
            if (currentStatus !in setOf(PayrollPayslipStatus.PAYMENT_PENDING, PayrollPayslipStatus.PARTIALLY_PAID)) {
                if (currentStatus == PayrollPayslipStatus.PAID) throw BusinessError.PayrollAlreadyPaid(payslip.id).asViolation()
                throw BusinessError.InvalidBusinessState("PAYROLL_PAYSLIP", payslip.status).asViolation()
            }
            val period = hr.payrollPeriod(payslip.periodId) ?: missing("PAYROLL_PERIOD", payslip.periodId)
            if (PayrollPeriodStatus.fromStoredValue(period.status) == PayrollPeriodStatus.CLOSED) {
                throw BusinessError.PayrollPeriodClosed(period.id).asViolation()
            }
            if (valid.amountRial > payslip.remainingAmountRial) {
                throw BusinessError.InvalidInput("amountRial", "payroll_overpayment").asViolation()
            }
            val treasuryResult = treasury.execute(
                TreasuryCommand.Payment(
                    commandId = GlobalId.parse(valid.commandId),
                    businessEpochDay = valid.paymentEpochDay,
                    correlationId = correlation,
                    sourceType = "PAYROLL_PAYMENT",
                    sourceId = payslip.id,
                    reason = "پرداخت حقوق ${valid.paymentReference}",
                    accountId = TreasuryAccountId.parse(valid.treasuryAccountId),
                    channel = valid.channel,
                    amount = MoneyRial.of(valid.amountRial),
                ),
            )
            val now = clock()
            val paymentId = hr.insertPayrollPayment(
                PayrollPaymentEntity(
                    globalId = valid.commandId,
                    idempotencyKey = key,
                    payslipId = payslip.id,
                    amountRial = valid.amountRial,
                    treasuryAccountId = valid.treasuryAccountId,
                    channel = valid.channel.storedValue,
                    paymentEpochDay = valid.paymentEpochDay,
                    paymentReference = valid.paymentReference,
                    status = PayrollPaymentStatus.POSTED.storedValue,
                    treasuryTransactionId = treasuryResult.id,
                    journalEntryId = treasuryResult.journalEntryId,
                    reversalOfPaymentId = null,
                    createdByActorId = actor.id,
                    createdAtEpochMillis = now,
                    reversedAtEpochMillis = null,
                    reversalReason = null,
                    correlationId = correlation.value,
                ),
            )
            val projection = paymentProjection(payslip.id, payslip.netPayRial)
            val paid = projection.paidAmountRial
            val remaining = projection.remainingAmountRial
            val target = projection.status
            PayrollPayslipStateMachine.requireTransition(currentStatus, target)
            optimistic(hr.updatePayslipPaymentProjection(payslip.id, paid, remaining, target.storedValue, now.takeIf { remaining == 0L }, payslip.rowVersion), "PAYROLL_PAYSLIP", payslip.id)
            refreshBatchPaymentStatus(payslip.batchId)
            hr.insertApprovalEvent(approvalEvent(payslip.batchId, payslip.id, "PAYMENT", currentStatus.storedValue, target.storedValue, actor.id, valid.paymentReference, null, now, correlation.value))
            recordAudit(actor.id, actor.displayName, "PAY", "PAYROLL_PAYMENT", paymentId, valid.paymentEpochDay, valid.paymentReference, "ثبت پرداخت حقوق", correlation.value, null, "status=POSTED;payslipId=${payslip.id}")
            receipt(key, "PAY_PAYSLIP", payload, "PAYROLL_PAYMENT", paymentId, target.storedValue, actor.id, now, correlation.value)
            paymentId
        }
    }

    override suspend fun reversePayment(command: ReversePayrollPaymentCommand): Long {
        val actor = authorizer.require(Permission.PAYROLL_REVERSE)
        val valid = command.validated()
        val key = receiptKey("REVERSE_PAYMENT", valid.commandId)
        val payload = hash("${valid.paymentId}|${valid.reversalEpochDay}|${valid.reason}")
        val correlation = correlation("payroll_payment_reverse", valid.commandId)
        return database.withTransaction {
            replay(key, "REVERSE_PAYMENT", payload)?.let { return@withTransaction it.resultEntityId }
            val payment = hr.payrollPayment(valid.paymentId) ?: missing("PAYROLL_PAYMENT", valid.paymentId)
            require(payment.status == PayrollPaymentStatus.POSTED.storedValue && payment.reversalOfPaymentId == null) { "payroll_payment_not_reversible" }
            val payslip = hr.payrollPayslip(payment.payslipId) ?: missing("PAYROLL_PAYSLIP", payment.payslipId)
            val period = hr.payrollPeriod(payslip.periodId) ?: missing("PAYROLL_PERIOD", payslip.periodId)
            if (PayrollPeriodStatus.fromStoredValue(period.status) == PayrollPeriodStatus.CLOSED) {
                throw BusinessError.PayrollPeriodClosed(period.id).asViolation()
            }
            val originalJournal = payment.journalEntryId ?: throw BusinessError.InvalidBusinessState("PAYROLL_PAYMENT", "MISSING_JOURNAL").asViolation()
            val treasuryResult = treasury.reverse(
                TreasuryReversalCommand(
                    commandId = GlobalId.parse(valid.commandId),
                    originalTransactionId = payment.treasuryTransactionId,
                    originalJournalEntryId = originalJournal,
                    businessEpochDay = valid.reversalEpochDay,
                    correlationId = correlation,
                    sourceType = "PAYROLL_PAYMENT_REVERSAL",
                    sourceId = payment.id,
                    reason = valid.reason,
                    accountId = TreasuryAccountId.parse(payment.treasuryAccountId),
                    channel = ir.sabou.inventory.domain.treasury.TreasuryChannel.fromStoredValue(payment.channel),
                    amount = MoneyRial.of(payment.amountRial),
                ),
            )
            val now = clock()
            optimistic(hr.markPaymentReversed(payment.id, now, valid.reason), "PAYROLL_PAYMENT", payment.id)
            val reversalId = hr.insertPayrollPayment(
                payment.copy(
                    id = 0,
                    globalId = valid.commandId,
                    idempotencyKey = key,
                    paymentEpochDay = valid.reversalEpochDay,
                    paymentReference = "REV:${payment.paymentReference}",
                    status = PayrollPaymentStatus.REVERSED.storedValue,
                    treasuryTransactionId = treasuryResult.id,
                    journalEntryId = treasuryResult.journalEntryId,
                    reversalOfPaymentId = payment.id,
                    createdByActorId = actor.id,
                    createdAtEpochMillis = now,
                    reversedAtEpochMillis = now,
                    reversalReason = valid.reason,
                    correlationId = correlation.value,
                ),
            )
            val refreshed = hr.payrollPayslip(payslip.id) ?: missing("PAYROLL_PAYSLIP", payslip.id)
            val projection = paymentProjection(payslip.id, refreshed.netPayRial)
            val paid = projection.paidAmountRial
            val remaining = projection.remainingAmountRial
            val target = projection.status
            val from = PayrollPayslipStatus.fromStoredValue(refreshed.status)
            PayrollPayslipStateMachine.requireTransition(from, target)
            optimistic(hr.updatePayslipPaymentProjection(refreshed.id, paid, remaining, target.storedValue, null, refreshed.rowVersion), "PAYROLL_PAYSLIP", refreshed.id)
            refreshBatchPaymentStatus(refreshed.batchId)
            hr.insertApprovalEvent(approvalEvent(refreshed.batchId, refreshed.id, "PAYMENT_REVERSAL", from.storedValue, target.storedValue, actor.id, valid.reason, null, now, correlation.value))
            recordAudit(actor.id, actor.displayName, "REVERSE", "PAYROLL_PAYMENT", reversalId, valid.reversalEpochDay, valid.reason, "برگشت پرداخت حقوق", correlation.value, "paymentId=${payment.id};status=POSTED", "paymentId=$reversalId;status=REVERSED")
            receipt(key, "REVERSE_PAYMENT", payload, "PAYROLL_PAYMENT", reversalId, "REVERSED", actor.id, now, correlation.value)
            reversalId
        }
    }

    override suspend fun reversePayslip(command: ReversePayslipCommandV2) {
        val actor = authorizer.require(Permission.PAYROLL_REVERSE)
        val valid = command.validated()
        val key = receiptKey("REVERSE_PAYSLIP", valid.commandId)
        val payload = hash("${valid.payslipId}|${valid.reversalEpochDay}|${valid.reason}")
        val correlation = correlation("payroll_reverse", valid.commandId)
        database.withTransaction {
            replay(key, "REVERSE_PAYSLIP", payload)?.let { return@withTransaction }
            val payslip = hr.payrollPayslip(valid.payslipId) ?: missing("PAYROLL_PAYSLIP", valid.payslipId)
            val from = PayrollPayslipStatus.fromStoredValue(payslip.status)
            PayrollPayslipStateMachine.requireTransition(from, PayrollPayslipStatus.REVERSED)
            if (hr.payrollPayments(payslip.id).any { it.status == PayrollPaymentStatus.POSTED.storedValue && it.reversalOfPaymentId == null }) {
                throw BusinessError.ApprovalRequired("REVERSE_PAYROLL_PAYMENT_FIRST", 1).asViolation()
            }
            val period = hr.payrollPeriod(payslip.periodId) ?: missing("PAYROLL_PERIOD", payslip.periodId)
            if (PayrollPeriodStatus.fromStoredValue(period.status) == PayrollPeriodStatus.CLOSED) {
                throw BusinessError.PayrollPeriodClosed(period.id).asViolation()
            }
            val now = clock()
            var expectedVersion = payslip.rowVersion
            val originalJournal = payslip.accrualJournalEntryId
            var reversalJournalId: Long? = null
            if (originalJournal != null) {
                val result = accountingPosting.reverse(
                    AccountingReversalCommand(
                        originalEntryId = originalJournal,
                        entryNo = "REV-PAY-${payslip.globalId.take(8)}",
                        sourceType = "PAYROLL_REVERSAL",
                        sourceId = payslip.id,
                        businessEpochDay = valid.reversalEpochDay,
                        reason = valid.reason,
                        idempotencyKey = "PAYROLL_REVERSAL:${valid.commandId}",
                        correlationId = correlation,
                        actorId = actor.id,
                    ),
                )
                reversalJournalId = result.entryId
                optimistic(hr.attachPayslipReversalJournal(payslip.id, result.entryId, expectedVersion), "PAYROLL_PAYSLIP", payslip.id)
                expectedVersion += 1
            } else if (payslip.grossPayRial > 0) {
                throw BusinessError.InvalidBusinessState("PAYROLL_PAYSLIP", "MISSING_ACCRUAL_JOURNAL").asViolation()
            }
            hr.payslipAdvanceAllocations(payslip.id).filter { it.status == "ALLOCATED" }.forEach { allocation ->
                optimistic(hr.reverseAdvanceAllocation(allocation.id, now, valid.reason), "PAYROLL_ADVANCE_ALLOCATION", allocation.id)
                optimistic(personnel.restoreAdvanceAllocation(allocation.advanceId, allocation.amountRial, now), "EMPLOYEE_ADVANCE", allocation.advanceId)
                recordAudit(actor.id, actor.displayName, "REVERSE", "PAYROLL_ADVANCE_ALLOCATION", allocation.id, valid.reversalEpochDay, valid.reason, "برگشت تخصیص مساعده", correlation.value, "status=ALLOCATED", "status=REVERSED")
            }
            optimistic(
                hr.transitionPayrollPayslip(
                    payslip.id,
                    from.storedValue,
                    PayrollPayslipStatus.REVERSED.storedValue,
                    expectedVersion,
                    reversalReason = valid.reason,
                    reversalEpochDay = valid.reversalEpochDay,
                    reversedAt = now,
                ),
                "PAYROLL_PAYSLIP",
                payslip.id,
            )
            hr.insertApprovalEvent(approvalEvent(payslip.batchId, payslip.id, "REVERSAL", from.storedValue, "REVERSED", actor.id, valid.reason, null, now, correlation.value))
            val batch = hr.payrollBatch(payslip.batchId) ?: missing("PAYROLL_BATCH", payslip.batchId)
            val activeAfter = hr.batchPayslips(batch.id).any { it.id != payslip.id && PayrollPayslipStatus.fromStoredValue(it.status) != PayrollPayslipStatus.REVERSED }
            if (!activeAfter) {
                val batchFrom = PayrollBatchStatus.fromStoredValue(batch.status)
                PayrollBatchStateMachine.requireTransition(batchFrom, PayrollBatchStatus.REVERSED)
                optimistic(hr.transitionPayrollBatch(batch.id, batchFrom.storedValue, "REVERSED", batch.rowVersion, reversalJournalId = reversalJournalId), "PAYROLL_BATCH", batch.id)
            }
            recordAudit(actor.id, actor.displayName, "REVERSE", "PAYROLL_PAYSLIP", payslip.id, valid.reversalEpochDay, valid.reason, "برگشت فیش حقوق", correlation.value, "status=${from.storedValue}", "status=REVERSED;revision=${payslip.revisionNo}")
            receipt(key, "REVERSE_PAYSLIP", payload, "PAYROLL_PAYSLIP", payslip.id, "REVERSED", actor.id, now, correlation.value)
        }
    }

    private suspend fun loadCalculationInputs(
        employeeIds: List<Long>,
        period: PayrollPeriodEntity,
    ): CalculationInputs {
        val employees = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap { personnel.employeesByIds(it) }
        val contracts = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap {
            hr.contractVersionsForEmployeesInRange(it, period.startEpochDay, period.endEpochDay)
        }
        val events = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap {
            hr.attendanceEventsForEmployeesInRange(it, period.startEpochDay, period.endEpochDay)
        }
        val corrections = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap {
            hr.approvedAttendanceCorrectionsForEmployeesInRange(it, period.startEpochDay, period.endEpochDay)
        }
        val legacyAttendance = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap {
            personnel.attendanceForEmployeesInRange(it, period.startEpochDay, period.endEpochDay)
        }
        val leaves = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap {
            personnel.approvedLeavesForEmployeesInRange(it, period.startEpochDay, period.endEpochDay)
        }
        val adjustments = loadApprovedAdjustments(employeeIds, period.id)
        val submittedAdjustments = employeeIds.distinct().chunked(SQLITE_IN_CHUNK).flatMap {
            hr.submittedManualAdjustmentsForEmployees(it, period.id)
        }
        val advances = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap { personnel.openAdvancesForEmployees(it) }
        val oldPayslips = employeeIds.chunked(SQLITE_IN_CHUNK).flatMap { hr.payslipsForEmployeesPeriod(it, period.id) }
        return CalculationInputs(
            employees = employees.associateBy { it.id },
            contracts = contracts.groupBy { it.employeeId },
            events = events.groupBy { it.employeeId to it.businessEpochDay },
            corrections = corrections.groupBy { it.employeeId to it.businessEpochDay }.mapValues { (_, rows) -> rows.first() },
            legacyAttendance = legacyAttendance.associateBy { it.employeeId to it.workEpochDay },
            leaves = leaves.groupBy { it.employeeId },
            policies = personnel.payrollPolicySnapshot(),
            adjustments = adjustments.groupBy { it.employeeId },
            submittedAdjustments = submittedAdjustments.groupBy { it.employeeId },
            advances = advances.groupBy { it.employeeId },
            oldPayslips = oldPayslips.groupBy { it.employeeId },
        )
    }

    private suspend fun loadApprovedAdjustments(employeeIds: List<Long>, periodId: Long): List<PayrollManualAdjustmentEntity> =
        employeeIds.distinct().chunked(SQLITE_IN_CHUNK).flatMap {
            hr.approvedManualAdjustmentsForEmployees(it, periodId)
        }

    private fun prepareBatch(
        command: CalculatePayrollBatchCommand,
        batch: PayrollBatchEntity,
        period: PayrollPeriodEntity,
        loaded: CalculationInputs,
        actorId: Long,
    ): BatchPreparation {
        val exceptions = mutableListOf<PayrollExceptionRecord>()
        val prepared = mutableListOf<PreparedPayslip>()
        command.employeeIds.forEach { employeeId ->
            val employee = loaded.employees[employeeId]
            if (employee == null) {
                exceptions += exception("EMPLOYEE_NOT_FOUND", employeeId, true, "employee_missing")
                return@forEach
            }
            val employeeExceptions = mutableListOf<PayrollExceptionRecord>()
            validateBatchScope(batch, employee, employeeExceptions)
            val status = EmploymentStatus.fromStoredValue(employee.status)
            if (status !in setOf(EmploymentStatus.ACTIVE, EmploymentStatus.ON_LEAVE, EmploymentStatus.SUSPENDED, EmploymentStatus.TERMINATED)) {
                employeeExceptions += exception("EMPLOYEE_NOT_ACTIVE", employee.id, true, status.storedValue)
            } else if (status == EmploymentStatus.SUSPENDED) {
                employeeExceptions += exception("EMPLOYEE_SUSPENDED", employee.id, false, "suspended_employee_included")
            }
            val hireDate = employee.hireEpochDay
            if (hireDate == null || hireDate <= 0) {
                employeeExceptions += exception("MISSING_HIRE_DATE", employee.id, true, "hire_date_required_for_proration")
            }
            val eligibleStart = maxOf(period.startEpochDay, hireDate ?: period.startEpochDay)
            val eligibleEnd = minOf(period.endEpochDay, employee.terminationEpochDay ?: period.endEpochDay)
            if (eligibleEnd < eligibleStart) {
                employeeExceptions += exception("OUTSIDE_EMPLOYMENT_PERIOD", employee.id, true, "employee_not_employed_in_period")
            }
            val code = employee.employeeCode?.trim()
            if (code.isNullOrEmpty()) employeeExceptions += exception("MISSING_EMPLOYEE_CODE", employee.id, true, "stable_employee_code_required")

            val contracts = loaded.contracts[employee.id].orEmpty()
            val contract = if (eligibleEnd >= eligibleStart) {
                resolvePeriodContract(employee.id, eligibleStart, eligibleEnd, contracts, employeeExceptions)
            } else {
                null
            }
            val policy = contract?.let { resolvePolicy(it, eligibleStart, eligibleEnd, loaded.policies, employeeExceptions) }
            val oldRows = loaded.oldPayslips[employee.id].orEmpty()
            val replacement = command.replacements.firstOrNull { it.employeeId == employee.id }
            val latest = oldRows.maxWithOrNull(compareBy<PayrollPayslipEntity> { it.revisionNo }.thenBy { it.id })
            if (replacement == null && latest != null) {
                employeeExceptions += exception("PAYSLIP_REVISION_LINK_REQUIRED", employee.id, true, "existing_payslip_id=${latest.id}")
            }
            if (replacement != null) {
                val replaced = oldRows.firstOrNull { it.id == replacement.replacesPayslipId }
                if (replaced == null || PayrollPayslipStatus.fromStoredValue(replaced.status) != PayrollPayslipStatus.REVERSED) {
                    employeeExceptions += exception("INVALID_REPLACED_PAYSLIP", employee.id, true, "replaced_payslip_must_be_reversed")
                }
            }
            val advanceRequest = command.advanceDeductions.firstOrNull { it.employeeId == employee.id }?.amountRial ?: 0L
            loaded.submittedAdjustments[employee.id].orEmpty().forEach { adjustment ->
                employeeExceptions += exception(
                    "MANUAL_ADJUSTMENT_NOT_APPROVED",
                    employee.id,
                    true,
                    "adjustmentId=${adjustment.id}",
                )
            }
            val availableAdvance = loaded.advances[employee.id].orEmpty().fold(0L) { total, advance ->
                SignedLongMath.add(total, SignedLongMath.subtract(advance.amountRial, advance.settledAmountRial))
            }
            if (advanceRequest > availableAdvance) {
                employeeExceptions += exception("ADVANCE_OVER_ALLOCATION", employee.id, true, "requested=$advanceRequest;outstanding=$availableAdvance")
            }
            if (employeeExceptions.any { it.blocking } || contract == null || policy == null || code == null) {
                exceptions += employeeExceptions
                return@forEach
            }

            val weeklyWorkDays = (contract.standardWeeklyMinutes / contract.standardDailyMinutes).coerceIn(1, 7)
            val periodWorkDays = scheduledEpochDays(period.startEpochDay, period.endEpochDay, weeklyWorkDays)
            val eligibleWorkDays = scheduledEpochDays(eligibleStart, eligibleEnd, weeklyWorkDays).toSet()
            val totals = AttendanceTotals()
            val traceEventIds = mutableListOf<Long>()
            val traceLegacyIds = mutableListOf<Long>()
            val traceCorrectionIds = mutableListOf<Long>()
            val traceLeaveIds = mutableSetOf<Long>()
            periodWorkDays.filter { it in eligibleWorkDays }.forEach { businessDay ->
                val dayEvents = loaded.events[employee.id to businessDay].orEmpty()
                val correction = loaded.corrections[employee.id to businessDay]
                val legacy = loaded.legacyAttendance[employee.id to businessDay]
                val dayLeaves = loaded.leaves[employee.id].orEmpty().filter { businessDay in it.startEpochDay..it.endEpochDay }
                val day = summarizeDay(
                    employee = employee,
                    contract = contract,
                    businessDay = businessDay,
                    events = dayEvents,
                    correction = correction,
                    legacy = legacy,
                    leaves = dayLeaves,
                )
                totals.add(day)
                traceEventIds += dayEvents.map { it.id }
                if (legacy != null) traceLegacyIds += legacy.id
                if (correction != null) traceCorrectionIds += correction.id
                traceLeaveIds += dayLeaves.map { it.id }
                employeeExceptions += day.exceptions
            }
            val standardPeriodMinutes = Math.multiplyExact(periodWorkDays.size, contract.standardDailyMinutes)
            val eligiblePeriodMinutes = Math.multiplyExact(eligibleWorkDays.size, contract.standardDailyMinutes)
            if (standardPeriodMinutes <= 0) {
                employeeExceptions += exception("INVALID_STANDARD_WORK_MINUTES", employee.id, true, "standard_period_minutes=$standardPeriodMinutes")
            }
            if (employeeExceptions.any { it.blocking }) {
                exceptions += employeeExceptions
                return@forEach
            }
            val adjustments = loaded.adjustments[employee.id].orEmpty()
            val manualComponents = adjustments.map { adjustment ->
                PayrollComponentDraftV2(
                    componentType = PayrollComponentType.fromStoredValue(adjustment.componentType),
                    description = adjustment.reason,
                    quantity = null,
                    rateRial = null,
                    amountRial = adjustment.amountRial,
                    direction = PayrollComponentDirection.valueOf(adjustment.direction),
                    sourceType = PayrollComponentSourceType.MANUAL_ADJUSTMENT,
                    sourceId = adjustment.id,
                    manualOverride = true,
                    overrideReason = adjustment.reason,
                    createdByActorId = adjustment.createdByActorId,
                ).validated()
            }
            val snapshot = PayrollInputSnapshot(
                employeeId = employee.id,
                employeeCode = code,
                employeeDisplayName = employee.displayName.ifBlank { employee.name },
                contractId = contract.id,
                contractVersionNo = contract.versionNo,
                baseSalaryRial = contract.baseSalaryRial,
                standardPeriodMinutes = standardPeriodMinutes,
                eligiblePeriodMinutes = eligiblePeriodMinutes,
                actualWorkMinutes = totals.workedMinutes,
                overtimeMinutes = totals.overtimeMinutes,
                absenceMinutes = totals.absenceMinutes,
                lateMinutes = totals.lateMinutes,
                paidLeaveMinutes = totals.paidLeaveMinutes,
                unpaidLeaveMinutes = totals.unpaidLeaveMinutes,
                payrollPolicyId = policy.id,
                payrollPolicyVersion = policy.versionNo,
                overtimeRateRialPerHour = policy.overtimeHourlyRateRial,
                overtimeMultiplierBasisPoints = policy.overtimeMultiplierBasisPoints,
                insuranceBasisPoints = policy.insuranceBasisPoints,
                taxBasisPoints = policy.taxBasisPoints,
                calculationVersion = CALCULATION_VERSION,
            ).validated()
            val result = try {
                PayrollCalculationService.calculate(
                    PayrollCalculationCommand(
                        commandId = GlobalId.parse(command.commandId),
                        batchId = batch.id,
                        snapshot = snapshot,
                        approvedManualComponents = manualComponents,
                        approvedAdvanceDeductionRial = advanceRequest,
                    ),
                )
            } catch (error: BusinessRuleViolation) {
                if (error.error is BusinessError.NegativeNetPay) {
                    employeeExceptions += exception("NEGATIVE_NET_PAY", employee.id, true, "deductions_exceed_earnings")
                    exceptions += employeeExceptions
                    return@forEach
                }
                throw error
            }
            employeeExceptions += result.warnings.map { warning -> exception(warning, employee.id, false, warning.lowercase()) }
            val trace = listOf(
                "attendanceEventIds=${traceEventIds.distinct().sorted().joinToString(",")}",
                "legacyAttendanceIds=${traceLegacyIds.distinct().sorted().joinToString(",")}",
                "attendanceCorrectionIds=${traceCorrectionIds.distinct().sorted().joinToString(",")}",
                "leaveIds=${traceLeaveIds.sorted().joinToString(",")}",
                "manualAdjustmentIds=${adjustments.map { it.id }.sorted().joinToString(",")}",
                "advanceRequestedRial=$advanceRequest",
                "rounding=HALF_UP",
            ).joinToString(";")
            prepared += PreparedPayslip(
                employee = employee,
                contract = contract,
                policy = policy,
                result = result,
                revisionNo = (latest?.revisionNo ?: 0) + 1,
                replacesPayslipId = replacement?.replacesPayslipId,
                manualAdjustmentIds = adjustments.map { it.id },
                traceParameters = trace,
            )
            exceptions += employeeExceptions
        }
        return BatchPreparation(prepared, exceptions.distinctBy { Triple(it.code, it.employeeId, it.detail) })
    }

    private fun resolvePeriodContract(
        employeeId: Long,
        eligibleStart: Long,
        eligibleEnd: Long,
        entities: List<EmploymentContractVersionEntity>,
        exceptions: MutableList<PayrollExceptionRecord>,
    ): EmploymentContractVersionEntity? {
        val domains = entities.map(EmploymentContractVersionEntity::toDomain)
        val intersecting = domains.filter { contract ->
            contract.status in setOf(
                EmploymentContractStatus.APPROVED,
                EmploymentContractStatus.ACTIVE,
                EmploymentContractStatus.SUPERSEDED,
                EmploymentContractStatus.LEGACY,
            ) &&
                contract.effectiveFromEpochDay <= eligibleEnd &&
                (contract.effectiveToEpochDay ?: Long.MAX_VALUE) >= eligibleStart
        }
        val conflicting = intersecting.flatMapIndexed { index, left ->
            intersecting.drop(index + 1).filter { right ->
                !versionRelated(left, right, domains) &&
                maxOf(left.effectiveFromEpochDay, right.effectiveFromEpochDay, eligibleStart) <=
                    minOf(left.effectiveToEpochDay ?: Long.MAX_VALUE, right.effectiveToEpochDay ?: Long.MAX_VALUE, eligibleEnd)
            }.flatMap { right -> listOf(left.id, right.id) }
        }.distinct().sorted()
        if (conflicting.isNotEmpty()) {
            exceptions += exception("CONFLICTING_CONTRACTS", employeeId, true, "contractIds=${conflicting.joinToString(",")}")
            return null
        }
        return try {
            val start = EffectiveContractResolver.resolve(employeeId, eligibleStart, domains)
            val end = EffectiveContractResolver.resolve(employeeId, eligibleEnd, domains)
            if (start.id != end.id) {
                exceptions += exception("CONTRACT_CHANGE_WITHIN_PERIOD", employeeId, true, "start=${start.id};end=${end.id}")
                null
            } else {
                entities.first { it.id == start.id }
            }
        } catch (error: BusinessRuleViolation) {
            when (val failure = error.error) {
                is BusinessError.NoEffectiveContract -> exceptions += exception("NO_EFFECTIVE_CONTRACT", employeeId, true, "businessDay=${failure.businessEpochDay}")
                is BusinessError.ConflictingContracts -> exceptions += exception("CONFLICTING_CONTRACTS", employeeId, true, "contractIds=${failure.contractIds.joinToString(",")}")
                else -> throw error
            }
            null
        }
    }

    private fun versionRelated(
        left: EmploymentContractVersion,
        right: EmploymentContractVersion,
        contracts: List<EmploymentContractVersion>,
    ): Boolean {
        val byId = contracts.associateBy { it.id }
        fun replaces(descendant: EmploymentContractVersion, ancestorId: Long): Boolean {
            val visited = mutableSetOf<Long>()
            var predecessorId = descendant.replacesContractId
            while (predecessorId != null && visited.add(predecessorId)) {
                if (predecessorId == ancestorId) return true
                predecessorId = byId[predecessorId]?.replacesContractId
            }
            return false
        }
        return replaces(left, right.id) || replaces(right, left.id)
    }

    private fun resolvePolicy(
        contract: EmploymentContractVersionEntity,
        from: Long,
        to: Long,
        policies: List<PayrollPolicyEntity>,
        exceptions: MutableList<PayrollExceptionRecord>,
    ): PayrollPolicyEntity? {
        val candidates = if (contract.payrollPolicyId != null) {
            policies.filter { it.id == contract.payrollPolicyId }
        } else {
            policies.filter {
                it.effectiveFromEpochDay <= from && (it.effectiveToEpochDay ?: Long.MAX_VALUE) >= to && it.status == "ACTIVE"
            }
        }
        val policy = candidates.singleOrNull()
        if (policy == null || policy.effectiveFromEpochDay > from || (policy.effectiveToEpochDay ?: Long.MAX_VALUE) < to || policy.status != "ACTIVE") {
            exceptions += exception("MISSING_OR_CONFLICTING_PAYROLL_POLICY", contract.employeeId, true, "contractId=${contract.id};policyId=${contract.payrollPolicyId}")
            return null
        }
        return policy
    }

    private fun summarizeDay(
        employee: EmployeeEntity,
        contract: EmploymentContractVersionEntity,
        businessDay: Long,
        events: List<AttendanceEventEntity>,
        correction: AttendanceCorrectionEntity?,
        legacy: AttendanceEntity?,
        leaves: List<LeaveEntity>,
    ): DayTotals {
        val exceptions = mutableListOf<PayrollExceptionRecord>()
        if (leaves.size > 1) {
            exceptions += exception("OVERLAPPING_APPROVED_LEAVE", employee.id, true, "businessDay=$businessDay;leaveIds=${leaves.map { it.id }}")
        }
        val leave = leaves.firstOrNull()
        if (leave != null) {
            val type = LeaveType.fromStoredValue(leave.leaveType)
            val rangeDays = Math.addExact(Math.subtractExact(leave.endEpochDay, leave.startEpochDay), 1L)
            val dailyLeaveMicros = leave.daysMicros / rangeDays
            val leaveMinutes = FixedPointRatio.multiplyDivide(
                value = contract.standardDailyMinutes.toLong(),
                multiplier = dailyLeaveMicros.coerceIn(0L, LEAVE_DAY_MICROS),
                divisor = LEAVE_DAY_MICROS,
                rounding = FixedPointRounding.HALF_UP,
            ).toInt()
            val hasWorkedInput = events.any { it.eventType in setOf("CLOCK_IN", "CLOCK_OUT") } || legacy?.status == "PRESENT"
            if (hasWorkedInput && leaveMinutes < contract.standardDailyMinutes) {
                val attendancePart = summarizeDay(
                    employee = employee,
                    contract = contract,
                    businessDay = businessDay,
                    events = events,
                    correction = correction,
                    legacy = legacy,
                    leaves = emptyList(),
                )
                return attendancePart.copy(
                    absenceMinutes = (attendancePart.absenceMinutes - leaveMinutes).coerceAtLeast(0),
                    paidLeaveMinutes = leaveMinutes.takeIf { type.paid } ?: 0,
                    unpaidLeaveMinutes = leaveMinutes.takeIf { !type.paid } ?: 0,
                    exceptions = exceptions + attendancePart.exceptions,
                )
            }
            if (hasWorkedInput) {
                exceptions += exception("LEAVE_ATTENDANCE_CONFLICT", employee.id, true, "businessDay=$businessDay;leaveId=${leave.id}")
            }
            return DayTotals(
                paidLeaveMinutes = leaveMinutes.takeIf { type.paid } ?: 0,
                unpaidLeaveMinutes = leaveMinutes.takeIf { !type.paid } ?: 0,
                absenceMinutes = (contract.standardDailyMinutes - leaveMinutes).coerceAtLeast(0),
                exceptions = exceptions,
            )
        }
        if (correction != null) {
            val snapshot = AttendanceCorrectionCodec.decode(correction.afterSnapshot)
            return DayTotals(
                workedMinutes = snapshot.workedMinutes,
                overtimeMinutes = snapshot.overtimeMinutes,
                absenceMinutes = Math.addExact(snapshot.absenceMinutes, snapshot.earlyLeaveMinutes),
                lateMinutes = snapshot.lateMinutes,
                paidLeaveMinutes = contract.standardDailyMinutes.takeIf { snapshot.status == DailyAttendanceStatus.PAID_LEAVE } ?: 0,
                unpaidLeaveMinutes = contract.standardDailyMinutes.takeIf { snapshot.status == DailyAttendanceStatus.UNPAID_LEAVE } ?: 0,
                exceptions = exceptions,
            )
        }
        val hasEventFacts = events.any { it.eventType != AttendanceEventType.MANUAL_ADJUSTMENT.storedValue }
        if (hasEventFacts) {
            val summary = AttendanceEventAggregator.summarize(
                employeeId = employee.id,
                businessEpochDay = businessDay,
                events = events.map(AttendanceEventEntity::toDomain),
                policy = AttendanceAggregationPolicy(
                    scheduledStartMinute = minOf(DEFAULT_SHIFT_START_MINUTE, 1440 - contract.standardDailyMinutes),
                    scheduledEndMinute = minOf(DEFAULT_SHIFT_START_MINUTE, 1440 - contract.standardDailyMinutes) + contract.standardDailyMinutes,
                    maximumWorkedMinutes = MAXIMUM_DAILY_WORK_MINUTES,
                ),
                employmentFromEpochDay = employee.hireEpochDay ?: businessDay,
                employmentToEpochDay = employee.terminationEpochDay,
            )
            exceptions += summary.anomalies.map { it.toException(employee.id, businessDay) }
            return DayTotals(
                workedMinutes = summary.workedMinutes,
                overtimeMinutes = summary.overtimeMinutes,
                absenceMinutes = Math.addExact(summary.absenceMinutes, summary.earlyLeaveMinutes),
                lateMinutes = summary.lateMinutes,
                exceptions = exceptions,
            )
        }
        if (legacy != null) {
            return when (legacy.status) {
                "PRESENT" -> DayTotals(
                    workedMinutes = if (legacy.checkInMinute != null && legacy.checkOutMinute != null) {
                        (legacy.checkOutMinute - legacy.checkInMinute).coerceAtLeast(0)
                    } else {
                        0
                    },
                    overtimeMinutes = legacy.overtimeMinutes,
                    lateMinutes = legacy.lateMinutes,
                    exceptions = exceptions,
                )
                "ABSENT" -> DayTotals(absenceMinutes = contract.standardDailyMinutes, exceptions = exceptions)
                "LEAVE" -> DayTotals(exceptions = exceptions + exception("LEGACY_LEAVE_PAY_STATUS_UNKNOWN", employee.id, false, "businessDay=$businessDay"))
                "MISSION", "HOLIDAY" -> DayTotals(exceptions = exceptions)
                else -> DayTotals(
                    absenceMinutes = contract.standardDailyMinutes,
                    exceptions = exceptions + exception("UNKNOWN_LEGACY_ATTENDANCE", employee.id, true, "businessDay=$businessDay;status=${legacy.status}"),
                )
            }
        }
        return DayTotals(absenceMinutes = contract.standardDailyMinutes, exceptions = exceptions)
    }

    private suspend fun allocatePayslipAdvances(
        payslip: PayrollPayslipEntity,
        components: List<PayrollComponentDraftV2>,
        actorId: Long,
        now: Long,
    ) {
        val requested = components.filter { it.componentType == PayrollComponentType.ADVANCE_DEDUCTION }
            .fold(0L) { total, component -> SignedLongMath.add(total, component.amountRial) }
        if (requested == 0L) return
        val open = personnel.openAdvancesByEmployee(payslip.employeeId)
        val balances = open.map { advance ->
            OpenAdvanceBalance(advance.id, SignedLongMath.subtract(advance.amountRial, advance.settledAmountRial))
        }
        val available = balances.fold(0L) { total, item -> SignedLongMath.add(total, item.remainingRial) }
        if (requested > available) {
            throw BusinessError.AdvanceOverAllocation(open.firstOrNull()?.id ?: 0, requested, available).asViolation()
        }
        AdvanceDeductionAllocator.allocate(requested, balances).forEach { allocation ->
            optimistic(personnel.allocateAdvance(allocation.advanceId, allocation.amountRial, now), "EMPLOYEE_ADVANCE", allocation.advanceId)
            val allocationId = hr.insertAdvanceAllocation(
                PayrollAdvanceAllocationV2Entity(
                    idempotencyKey = "advance-allocation:${payslip.globalId}:${allocation.advanceId}",
                    payslipId = payslip.id,
                    advanceId = allocation.advanceId,
                    amountRial = allocation.amountRial,
                    status = "ALLOCATED",
                    createdByActorId = actorId,
                    createdAtEpochMillis = now,
                    reversedAtEpochMillis = null,
                    reversalReason = null,
                    correlationId = payslip.correlationId,
                ),
            )
            val actor = authorizer.actorIdentity()
            recordAudit(actorId, actor.displayName, "ALLOCATE", "PAYROLL_ADVANCE_ALLOCATION", allocationId, null, "تخصیص مساعده به فیش", "تخصیص مساعده", payslip.correlationId, null, "status=ALLOCATED;advanceId=${allocation.advanceId}")
        }
    }

    private suspend fun refreshBatchPaymentStatus(batchId: Long) {
        val batch = hr.payrollBatch(batchId) ?: missing("PAYROLL_BATCH", batchId)
        val payslips = hr.batchPayslips(batchId)
        val active = payslips.filter { PayrollPayslipStatus.fromStoredValue(it.status) != PayrollPayslipStatus.REVERSED }
        val target = when {
            active.isEmpty() -> PayrollBatchStatus.REVERSED
            active.all { it.remainingAmountRial == 0L } -> PayrollBatchStatus.PAID
            active.any { it.paidAmountRial > 0L } -> PayrollBatchStatus.PARTIALLY_PAID
            else -> PayrollBatchStatus.PAYMENT_PENDING
        }
        val from = PayrollBatchStatus.fromStoredValue(batch.status)
        if (from == target) return
        PayrollBatchStateMachine.requireTransition(from, target)
        optimistic(hr.transitionPayrollBatch(batch.id, from.storedValue, target.storedValue, batch.rowVersion), "PAYROLL_BATCH", batch.id)
    }

    private suspend fun paymentProjection(payslipId: Long, netPayRial: Long) =
        PayrollPaymentLedger.derive(
            netPayRial = netPayRial,
            entries = hr.payrollPayments(payslipId).map { payment ->
                PayrollPaymentLedgerEntry(
                    id = payment.id,
                    amountRial = payment.amountRial,
                    status = PayrollPaymentStatus.fromStoredValue(payment.status),
                    reversalOfPaymentId = payment.reversalOfPaymentId,
                )
            },
        )

    private fun validateBatchScope(
        batch: PayrollBatchEntity,
        employee: EmployeeEntity,
        exceptions: MutableList<PayrollExceptionRecord>,
    ) {
        when (batch.scope) {
            "ALL", "SELECTED" -> Unit
            "BRANCH" -> if (employee.branchName != batch.branchName) exceptions += exception("BATCH_SCOPE_MISMATCH", employee.id, true, "branch=${employee.branchName}")
            "DEPARTMENT" -> if (employee.department != batch.department) exceptions += exception("BATCH_SCOPE_MISMATCH", employee.id, true, "department=${employee.department}")
            else -> exceptions += exception("UNKNOWN_BATCH_SCOPE", employee.id, true, batch.scope)
        }
    }

    private fun scheduledEpochDays(from: Long, to: Long, weeklyWorkDays: Int): List<Long> {
        require(from > 0 && to >= from)
        require(weeklyWorkDays in 1..7)
        return (from..to).filter { epochDay -> isoDayOfWeek(epochDay) <= weeklyWorkDays }
    }

    /** ISO-8601 day of week (Monday=1..Sunday=7); Unix epoch day zero was Thursday. */
    private fun isoDayOfWeek(epochDay: Long): Int =
        ((epochDay % 7L + 3L) % 7L + 1L).toInt()

    private fun PayrollExceptionRecord.toEntity(batchId: Long, now: Long) = PayrollExceptionEntity(
        batchId = batchId,
        payslipId = null,
        employeeId = employeeId,
        code = code,
        blocking = blocking,
        detail = detail.take(1_000),
        createdAtEpochMillis = now,
        resolvedAtEpochMillis = null,
        resolvedByActorId = null,
        resolutionNote = null,
    )

    private fun PreparedPayslip.toSnapshotEntity(payslipId: Long, snapshotHash: String, now: Long): PayrollSnapshotEntity {
        val input = result.snapshot
        return PayrollSnapshotEntity(
            payslipId = payslipId,
            employeeId = input.employeeId,
            employeeCode = input.employeeCode,
            employeeDisplayName = input.employeeDisplayName,
            contractId = contract.id,
            contractNumber = contract.contractNumber,
            contractVersionNo = contract.versionNo,
            baseSalaryRial = input.baseSalaryRial,
            standardPeriodMinutes = input.standardPeriodMinutes,
            eligiblePeriodMinutes = input.eligiblePeriodMinutes,
            actualWorkMinutes = input.actualWorkMinutes,
            overtimeMinutes = input.overtimeMinutes,
            absenceMinutes = input.absenceMinutes,
            lateMinutes = input.lateMinutes,
            paidLeaveMinutes = input.paidLeaveMinutes,
            unpaidLeaveMinutes = input.unpaidLeaveMinutes,
            payrollPolicyId = policy.id,
            payrollPolicyVersion = policy.versionNo,
            overtimeRateRialPerHour = input.overtimeRateRialPerHour,
            overtimeMultiplierBasisPoints = input.overtimeMultiplierBasisPoints,
            insuranceBasisPoints = input.insuranceBasisPoints,
            taxBasisPoints = input.taxBasisPoints,
            grossPayRial = result.grossPayRial,
            totalDeductionsRial = result.totalDeductionsRial,
            netPayRial = result.netPayRial,
            calculationVersion = input.calculationVersion,
            calculationParameters = traceParameters,
            snapshotHash = snapshotHash,
            capturedAtEpochMillis = now,
            detailComplete = true,
        )
    }

    private fun PayrollComponentDraftV2.toEntity(payslipId: Long, now: Long) = PayrollComponentEntity(
        payslipId = payslipId,
        componentType = componentType.storedValue,
        description = description,
        quantity = quantity,
        rateRial = rateRial,
        amountRial = amountRial,
        direction = direction.storedValue,
        sourceType = sourceType.storedValue,
        sourceId = sourceId,
        manualOverride = manualOverride,
        overrideReason = overrideReason,
        createdByActorId = createdByActorId,
        createdAtEpochMillis = now,
    )

    private fun snapshotHash(
        snapshot: PayrollInputSnapshot,
        components: List<PayrollComponentDraftV2>,
        traceParameters: String,
        grossPayRial: Long,
        totalDeductionsRial: Long,
        netPayRial: Long,
    ): String = hash(
        listOf(
            snapshot.employeeId,
            snapshot.employeeCode,
            snapshot.employeeDisplayName,
            snapshot.contractId,
            snapshot.contractVersionNo,
            snapshot.baseSalaryRial,
            snapshot.standardPeriodMinutes,
            snapshot.eligiblePeriodMinutes,
            snapshot.actualWorkMinutes,
            snapshot.overtimeMinutes,
            snapshot.absenceMinutes,
            snapshot.lateMinutes,
            snapshot.paidLeaveMinutes,
            snapshot.unpaidLeaveMinutes,
            snapshot.payrollPolicyId,
            snapshot.payrollPolicyVersion,
            snapshot.overtimeRateRialPerHour,
            snapshot.overtimeMultiplierBasisPoints,
            snapshot.insuranceBasisPoints,
            snapshot.taxBasisPoints,
            snapshot.calculationVersion,
            grossPayRial,
            totalDeductionsRial,
            netPayRial,
            traceParameters,
            components.joinToString("||") { component ->
                listOf(
                    component.componentType.storedValue,
                    component.description,
                    component.quantity,
                    component.rateRial,
                    component.amountRial,
                    component.direction.storedValue,
                    component.sourceType.storedValue,
                    component.sourceId,
                    component.manualOverride,
                    component.overrideReason,
                    component.createdByActorId,
                ).joinToString("|")
            },
        ).joinToString("\u001f"),
    )

    private fun calculatePayload(command: CalculatePayrollBatchCommand): String = listOf(
        command.batchId,
        command.employeeIds.joinToString(","),
        command.advanceDeductions.joinToString(",") { "${it.employeeId}:${it.amountRial}" },
        command.replacements.joinToString(",") { "${it.employeeId}:${it.replacesPayslipId}" },
    ).joinToString("|")

    private suspend fun recordAudit(
        actorId: Long,
        actorName: String,
        action: String,
        entityType: String,
        entityId: Long,
        businessEpochDay: Long?,
        reason: String,
        description: String,
        correlationId: String,
        before: String?,
        after: String?,
    ) {
        audit.record(
            AuditEventDraft(
                action = AuditAction.of(action),
                entityType = AuditEntityType.of(entityType),
                entityId = entityId,
                actorId = actorId,
                actorDisplayName = actorName,
                occurredAtEpochMillis = clock(),
                businessEpochDay = businessEpochDay,
                deviceId = "local-android",
                referenceType = entityType,
                referenceId = entityId,
                reason = reason,
                beforeSnapshot = before,
                afterSnapshot = after,
                correlationId = correlationId,
                description = description,
            ),
        )
    }

    private suspend fun replay(
        key: String,
        commandType: String,
        payloadHash: String,
    ): HrPayrollCommandReceiptEntity? = hr.commandReceipt(key)?.also { receipt ->
        if (receipt.commandType != commandType || receipt.payloadHash != payloadHash) {
            throw BusinessError.IdempotencyConflict(key).asViolation()
        }
    }

    private suspend fun receipt(
        key: String,
        commandType: String,
        payloadHash: String,
        resultEntityType: String,
        resultEntityId: Long,
        resultDetail: String,
        actorId: Long,
        now: Long,
        correlationId: String,
    ) {
        hr.insertCommandReceipt(
            HrPayrollCommandReceiptEntity(
                idempotencyKey = key,
                commandType = commandType,
                payloadHash = payloadHash,
                resultEntityType = resultEntityType,
                resultEntityId = resultEntityId,
                resultDetail = resultDetail.take(4_000),
                actorId = actorId,
                createdAtEpochMillis = now,
                correlationId = correlationId,
            ),
        )
    }

    private fun approvalEvent(
        batchId: Long,
        payslipId: Long?,
        eventType: String,
        fromStatus: String,
        toStatus: String,
        actorId: Long,
        reason: String,
        snapshotHash: String?,
        now: Long,
        correlationId: String,
    ) = PayrollApprovalEventEntity(
        batchId = batchId,
        payslipId = payslipId,
        eventType = eventType,
        fromStatus = fromStatus,
        toStatus = toStatus,
        actorId = actorId,
        reason = reason,
        snapshotHash = snapshotHash,
        createdAtEpochMillis = now,
        correlationId = correlationId,
    )

    private fun optimistic(result: Int, entityType: String, entityId: Long) {
        if (result != 1) throw BusinessError.ConcurrentModification(entityType, entityId).asViolation()
    }

    private fun missing(entityType: String, id: Long): Nothing =
        throw BusinessError.EntityNotFound(entityType, id).asViolation()

    private fun receiptKey(type: String, commandId: String): String = "HRPAY:$type:$commandId"

    private fun correlation(operation: String, commandId: String): CorrelationId =
        CorrelationId.forCommand(operation, GlobalId.parse(commandId))

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { byte -> "%02x".format(byte) }

    private fun exception(code: String, employeeId: Long?, blocking: Boolean, detail: String) =
        PayrollExceptionRecord(code, employeeId, blocking, detail)

    private fun <T> authorizedFlow(permission: Permission, upstream: () -> Flow<T>): Flow<T> = flow {
        authorizer.require(permission)
        emitAll(upstream())
    }

    private data class CalculationInputs(
        val employees: Map<Long, EmployeeEntity>,
        val contracts: Map<Long, List<EmploymentContractVersionEntity>>,
        val events: Map<Pair<Long, Long>, List<AttendanceEventEntity>>,
        val corrections: Map<Pair<Long, Long>, AttendanceCorrectionEntity>,
        val legacyAttendance: Map<Pair<Long, Long>, AttendanceEntity>,
        val leaves: Map<Long, List<LeaveEntity>>,
        val policies: List<PayrollPolicyEntity>,
        val adjustments: Map<Long, List<PayrollManualAdjustmentEntity>>,
        val submittedAdjustments: Map<Long, List<PayrollManualAdjustmentEntity>>,
        val advances: Map<Long, List<EmployeeAdvanceEntity>>,
        val oldPayslips: Map<Long, List<PayrollPayslipEntity>>,
    )

    private data class PreparedPayslip(
        val employee: EmployeeEntity,
        val contract: EmploymentContractVersionEntity,
        val policy: PayrollPolicyEntity,
        val result: PayrollCalculationResultV2,
        val revisionNo: Int,
        val replacesPayslipId: Long?,
        val manualAdjustmentIds: List<Long>,
        val traceParameters: String,
    )

    private data class BatchPreparation(
        val payslips: List<PreparedPayslip>,
        val exceptions: List<PayrollExceptionRecord>,
    )

    private data class DayTotals(
        val workedMinutes: Int = 0,
        val overtimeMinutes: Int = 0,
        val absenceMinutes: Int = 0,
        val lateMinutes: Int = 0,
        val paidLeaveMinutes: Int = 0,
        val unpaidLeaveMinutes: Int = 0,
        val exceptions: List<PayrollExceptionRecord> = emptyList(),
    )

    private class AttendanceTotals {
        var workedMinutes: Int = 0
            private set
        var overtimeMinutes: Int = 0
            private set
        var absenceMinutes: Int = 0
            private set
        var lateMinutes: Int = 0
            private set
        var paidLeaveMinutes: Int = 0
            private set
        var unpaidLeaveMinutes: Int = 0
            private set

        fun add(day: DayTotals) {
            workedMinutes = Math.addExact(workedMinutes, day.workedMinutes)
            overtimeMinutes = Math.addExact(overtimeMinutes, day.overtimeMinutes)
            absenceMinutes = Math.addExact(absenceMinutes, day.absenceMinutes)
            lateMinutes = Math.addExact(lateMinutes, day.lateMinutes)
            paidLeaveMinutes = Math.addExact(paidLeaveMinutes, day.paidLeaveMinutes)
            unpaidLeaveMinutes = Math.addExact(unpaidLeaveMinutes, day.unpaidLeaveMinutes)
        }
    }

    private companion object {
        const val SQLITE_IN_CHUNK = 800
        const val CALCULATION_VERSION = "HRPAY-2.0.0"
        const val DEFAULT_SHIFT_START_MINUTE = 8 * 60
        const val MAXIMUM_DAILY_WORK_MINUTES = 16 * 60
        const val LEAVE_DAY_MICROS = 1_000_000L
    }
}

private fun PayrollPeriodEntity.toRecord() = PayrollPeriodRecordV2(
    id = id,
    periodKey = periodKey,
    startEpochDay = startEpochDay,
    endEpochDay = endEpochDay,
    paymentDueEpochDay = paymentDueEpochDay,
    status = PayrollPeriodStatus.fromStoredValue(status),
)

private fun PayrollBatchEntity.toRecord() = PayrollBatchRecordV2(
    id = id,
    documentNumber = documentNumber,
    periodId = periodId,
    status = PayrollBatchStatus.fromStoredValue(status),
    branchName = branchName,
    department = department,
    createdByActorId = createdByActorId,
    calculatedByActorId = calculatedByActorId,
    calculatedAtEpochMillis = calculatedAtEpochMillis,
    reviewedByActorId = reviewedByActorId,
    approvedByActorId = approvedByActorId,
    approvedAtEpochMillis = approvedAtEpochMillis,
    correlationId = CorrelationId.parse(correlationId),
    source = PayrollDocumentSource.entries.firstOrNull { it.storedValue == source } ?: PayrollDocumentSource.LEGACY_MIGRATION,
)

private fun PayrollBatchDashboardRow.toRecord() = batch.toRecord().copy(
    employeesIncluded = employeesIncluded,
    grossPayrollRial = grossPayrollRial,
    deductionsRial = deductionsRial,
    netPayrollRial = netPayrollRial,
    paidRial = paidRial,
    remainingRial = remainingRial,
    exceptionCount = exceptionCount,
)

private fun PayrollPayslipEntity.toRecord() = PayrollPayslipRecordV2(
    id = id,
    batchId = batchId,
    periodId = periodId,
    employeeId = employeeId,
    employeeCodeSnapshot = employeeCodeSnapshot,
    employeeNameSnapshot = employeeNameSnapshot,
    revisionNo = revisionNo,
    replacesPayslipId = replacesPayslipId,
    contractId = contractId,
    status = PayrollPayslipStatus.fromStoredValue(status),
    grossPay = MoneyRial.of(grossPayRial),
    totalDeductions = MoneyRial.of(totalDeductionsRial),
    netPay = MoneyRial.of(netPayRial),
    paidAmount = MoneyRial.of(paidAmountRial),
    remainingAmount = MoneyRial.of(remainingAmountRial),
    componentDetailComplete = componentDetailComplete,
    source = PayrollDocumentSource.entries.firstOrNull { it.storedValue == source } ?: PayrollDocumentSource.LEGACY_MIGRATION,
    calculatedAtEpochMillis = calculatedAtEpochMillis,
    approvedAtEpochMillis = approvedAtEpochMillis,
    paidAtEpochMillis = paidAtEpochMillis,
    accrualJournalEntryId = accrualJournalEntryId,
    reversalJournalEntryId = reversalJournalEntryId,
    reversalEpochDay = reversalEpochDay,
    correlationId = CorrelationId.parse(correlationId),
)

private fun PayrollSnapshotEntity.toDomainOrNull(): PayrollInputSnapshot? {
    if (!detailComplete) return null
    return toDomainRequired()
}

private fun PayrollSnapshotEntity.toDomainRequired() = PayrollInputSnapshot(
    employeeId = employeeId,
    employeeCode = employeeCode,
    employeeDisplayName = employeeDisplayName,
    contractId = requireNotNull(contractId),
    contractVersionNo = requireNotNull(contractVersionNo),
    baseSalaryRial = requireNotNull(baseSalaryRial),
    standardPeriodMinutes = requireNotNull(standardPeriodMinutes),
    eligiblePeriodMinutes = requireNotNull(eligiblePeriodMinutes),
    actualWorkMinutes = requireNotNull(actualWorkMinutes),
    overtimeMinutes = requireNotNull(overtimeMinutes),
    absenceMinutes = requireNotNull(absenceMinutes),
    lateMinutes = requireNotNull(lateMinutes),
    paidLeaveMinutes = requireNotNull(paidLeaveMinutes),
    unpaidLeaveMinutes = requireNotNull(unpaidLeaveMinutes),
    payrollPolicyId = requireNotNull(payrollPolicyId),
    payrollPolicyVersion = requireNotNull(payrollPolicyVersion),
    overtimeRateRialPerHour = requireNotNull(overtimeRateRialPerHour),
    overtimeMultiplierBasisPoints = requireNotNull(overtimeMultiplierBasisPoints),
    insuranceBasisPoints = requireNotNull(insuranceBasisPoints),
    taxBasisPoints = requireNotNull(taxBasisPoints),
    calculationVersion = requireNotNull(calculationVersion),
).validated()

private fun PayrollComponentEntity.toDraft() = PayrollComponentDraftV2(
    componentType = PayrollComponentType.fromStoredValue(componentType),
    description = description,
    quantity = quantity,
    rateRial = rateRial,
    amountRial = amountRial,
    direction = PayrollComponentDirection.valueOf(direction),
    sourceType = PayrollComponentSourceType.valueOf(sourceType),
    sourceId = sourceId,
    manualOverride = manualOverride,
    overrideReason = overrideReason,
    createdByActorId = createdByActorId,
)

private fun PayrollPaymentEntity.toRecord() = PayrollPaymentRecordV2(
    id = id,
    payslipId = payslipId,
    amountRial = amountRial,
    treasuryAccountId = treasuryAccountId,
    paymentEpochDay = paymentEpochDay,
    paymentReference = paymentReference,
    status = PayrollPaymentStatus.fromStoredValue(status),
    journalEntryId = journalEntryId,
    reversalOfPaymentId = reversalOfPaymentId,
    correlationId = correlationId,
)

private fun PayrollManualAdjustmentEntity.toRecord() = ManualPayrollAdjustmentRecordV2(
    id = id,
    employeeId = employeeId,
    periodId = periodId,
    componentType = PayrollComponentType.fromStoredValue(componentType),
    direction = PayrollComponentDirection.valueOf(direction),
    amountRial = amountRial,
    reason = reason,
    status = ManualAdjustmentStatus.entries.firstOrNull { it.storedValue == status }
        ?: ManualAdjustmentStatus.REJECTED,
    createdByActorId = createdByActorId,
    approvedByActorId = approvedByActorId,
)

private fun PayrollExceptionEntity.toRecord() = PayrollExceptionRecord(code, employeeId, blocking, detail)

private fun EmploymentContractVersionEntity.toDomain() = EmploymentContractVersion(
    id = id,
    employeeId = employeeId,
    contractNumber = contractNumber,
    versionNo = versionNo,
    replacesContractId = replacesContractId,
    contractType = EmploymentContractType.fromStoredValue(contractType),
    effectiveFromEpochDay = effectiveFromEpochDay,
    effectiveToEpochDay = effectiveToEpochDay,
    baseSalary = MoneyRial.of(baseSalaryRial),
    standardDailyMinutes = standardDailyMinutes,
    standardWeeklyMinutes = standardWeeklyMinutes,
    overtimePolicyId = overtimePolicyId,
    payrollPolicyId = payrollPolicyId,
    jobTitleSnapshot = jobTitleSnapshot,
    departmentSnapshot = departmentSnapshot,
    branchSnapshot = branchSnapshot,
    status = EmploymentContractStatus.fromStoredValue(status),
    createdAtEpochMillis = createdAtEpochMillis,
    createdByActorId = createdByActorId,
    approvedAtEpochMillis = approvedAtEpochMillis,
    approvedByActorId = approvedByActorId,
)

private fun AttendanceEventEntity.toDomain() = AttendanceEvent(
    id = id,
    employeeId = employeeId,
    eventType = AttendanceEventType.fromStoredValue(eventType),
    businessEpochDay = businessEpochDay,
    timestampEpochMillis = timestampEpochMillis,
    minuteOfDay = minuteOfDay,
    source = AttendanceSource.fromStoredValue(source),
    deviceId = deviceId,
    locationId = locationId,
    createdByActorId = createdByActorId,
    reason = reason,
    correlationId = CorrelationId.parse(correlationId),
)

private fun EmployeeTimelineRow.toDomain() = EmployeeTimelineItem(
    stableKey = stableKey,
    employeeId = employeeId,
    businessEpochDay = businessEpochDay,
    occurredAtEpochMillis = occurredAtEpochMillis,
    eventType = eventType,
    title = title,
    referenceType = referenceType,
    referenceId = referenceId,
)

private fun AttendanceAnomaly.toException(employeeId: Long, businessDay: Long) = PayrollExceptionRecord(
    code = "ATTENDANCE_${type.name}",
    employeeId = employeeId,
    blocking = true,
    detail = "businessDay=$businessDay;eventIds=${eventIds.joinToString(",")};detail=$detail",
)
