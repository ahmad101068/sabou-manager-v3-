package ir.sabou.inventory.core

import java.math.BigInteger

private val LONG_MIN_BIG_INTEGER: BigInteger = BigInteger.valueOf(Long.MIN_VALUE)
private val LONG_MAX_BIG_INTEGER: BigInteger = BigInteger.valueOf(Long.MAX_VALUE)

/**
 * API-23-compatible equivalent of BigInteger.longValueExact().
 *
 * Android exposes longValueExact only from API 31, while Sabou supports API 23.
 * Keep the exact overflow contract instead of silently truncating through toLong().
 */
internal fun BigInteger.toLongExactCompat(): Long {
    if (this < LONG_MIN_BIG_INTEGER || this > LONG_MAX_BIG_INTEGER) {
        throw ArithmeticException("BigInteger does not fit in Long")
    }
    return toLong()
}
