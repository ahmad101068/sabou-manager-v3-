package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.EmployeeTimelineItem
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveRecord
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft
import ir.sabou.inventory.domain.personnel.LeaveGrantDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollCalculation
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PayrollPolicyDraft
import ir.sabou.inventory.domain.personnel.PayrollPolicyRecord
import ir.sabou.inventory.domain.personnel.PayrollReversalDraft
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.personnel.ApproveManualAdjustmentCommand
import ir.sabou.inventory.domain.personnel.ApprovePayrollBatchCommand
import ir.sabou.inventory.domain.personnel.CalculatePayrollBatchCommand
import ir.sabou.inventory.domain.personnel.ClosePayrollPeriodCommand
import ir.sabou.inventory.domain.personnel.HrPayrollCommandService
import ir.sabou.inventory.domain.personnel.ManualPayrollAdjustmentCommand
import ir.sabou.inventory.domain.personnel.ManualPayrollAdjustmentRecordV2
import ir.sabou.inventory.domain.personnel.PayPayslipCommand
import ir.sabou.inventory.domain.personnel.PayrollBatchDraftV2
import ir.sabou.inventory.domain.personnel.PayrollBatchRecordV2
import ir.sabou.inventory.domain.personnel.PayrollExceptionRecord
import ir.sabou.inventory.domain.personnel.PayrollPayslipDetailV2
import ir.sabou.inventory.domain.personnel.PayrollPayslipRecordV2
import ir.sabou.inventory.domain.personnel.PayrollPeriodDraftV2
import ir.sabou.inventory.domain.personnel.PayrollPeriodRecordV2
import ir.sabou.inventory.domain.personnel.ReopenPayrollPeriodCommand
import ir.sabou.inventory.domain.personnel.ReversePayrollPaymentCommand
import ir.sabou.inventory.domain.personnel.ReversePayslipCommandV2
import ir.sabou.inventory.domain.personnel.ReviewPayrollBatchCommand
import ir.sabou.inventory.domain.treasury.TreasuryChannel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.ExperimentalCoroutinesApi

data class PersonnelUiState(val employees: List<EmployeeRecord> = emptyList(), val payrolls: List<PayrollRecord> = emptyList(), val attendance: List<AttendanceRecord> = emptyList(), val leaves: List<LeaveRecord> = emptyList(), val pendingLeaves: List<LeaveRecord> = emptyList(), val payrollPreview: PayrollCalculation? = null, val attendanceSummary: AttendanceSummary? = null, val contracts: List<ir.sabou.inventory.domain.personnel.EmployeeContractRecord> = emptyList(), val advances: List<ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord> = emptyList(), val openAdvances: List<ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord> = emptyList(), val payrollPolicies: List<PayrollPolicyRecord> = emptyList(), val selectedEmployeeId: Long? = null, val message: String? = null)

data class HrPayrollUiState(
    val periods: List<PayrollPeriodRecordV2> = emptyList(),
    val batches: List<PayrollBatchRecordV2> = emptyList(),
    val employeePayslips: List<PayrollPayslipRecordV2> = emptyList(),
    val payslipDetail: PayrollPayslipDetailV2? = null,
    val calculationExceptions: List<PayrollExceptionRecord> = emptyList(),
    val manualAdjustments: List<ManualPayrollAdjustmentRecordV2> = emptyList(),
    val employeeTimeline: List<EmployeeTimelineItem> = emptyList(),
    val busy: Boolean = false,
)

@OptIn(ExperimentalCoroutinesApi::class)
class PersonnelViewModel(
    private val repository: PersonnelRepository,
    private val payroll: HrPayrollCommandService,
) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    private val payrollPreview = MutableStateFlow<PayrollCalculation?>(null)
    private val attendanceSummary = MutableStateFlow<AttendanceSummary?>(null)
    private val selectedEmployeeId = MutableStateFlow<Long?>(null)
    private val payslipDetail = MutableStateFlow<PayrollPayslipDetailV2?>(null)
    private val calculationExceptions = MutableStateFlow<List<PayrollExceptionRecord>>(emptyList())
    private val manualAdjustments = MutableStateFlow<List<ManualPayrollAdjustmentRecordV2>>(emptyList())
    private val hrBusy = MutableStateFlow(false)
    private val contracts = selectedEmployeeId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.contracts(id) }
    private val advances = selectedEmployeeId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.advances(id) }
    private val coreState = combine(repository.employees, repository.payrolls, repository.attendance, repository.leaves, repository.pendingLeaves) { e, p, a, l, pending -> arrayOf(e, p, a, l, pending) }
    private data class EmployeeDetails(val contracts: List<ir.sabou.inventory.domain.personnel.EmployeeContractRecord>, val advances: List<ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord>, val openAdvances: List<ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord>, val payrollPolicies: List<PayrollPolicyRecord>, val employeeId: Long?)
    private data class Transient(val preview: PayrollCalculation?, val summary: AttendanceSummary?, val details: EmployeeDetails, val message: String?)
    private val employeeDetails = combine(contracts, advances, repository.openAdvances, repository.payrollPolicies, selectedEmployeeId) { c, a, open, policies, id -> EmployeeDetails(c, a, open, policies, id) }
    private val transientState = combine(payrollPreview, attendanceSummary, employeeDetails, message) { preview, summary, details, m -> Transient(preview, summary, details, m) }
    val state: StateFlow<PersonnelUiState> = combine(coreState, transientState) { core, transient ->
        @Suppress("UNCHECKED_CAST")
        PersonnelUiState(
            employees = core[0] as List<EmployeeRecord>, payrolls = core[1] as List<PayrollRecord>, attendance = core[2] as List<AttendanceRecord>,
            leaves = core[3] as List<LeaveRecord>, pendingLeaves = core[4] as List<LeaveRecord>, payrollPreview = transient.preview,
            attendanceSummary = transient.summary, contracts = transient.details.contracts, advances = transient.details.advances,
            openAdvances = transient.details.openAdvances, payrollPolicies = transient.details.payrollPolicies,
            selectedEmployeeId = transient.details.employeeId, message = transient.message,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersonnelUiState())

    private val employeePayslips = selectedEmployeeId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else payroll.employeePayslips(id)
    }
    private val employeeTimeline = selectedEmployeeId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else payroll.employeeTimeline(id)
    }
    private data class HrCore(
        val periods: List<PayrollPeriodRecordV2>,
        val batches: List<PayrollBatchRecordV2>,
        val payslips: List<PayrollPayslipRecordV2>,
        val timeline: List<EmployeeTimelineItem>,
    )
    val hrState: StateFlow<HrPayrollUiState> = combine(
        combine(payroll.periods, payroll.batches, employeePayslips, employeeTimeline) { periods, batches, payslips, timeline ->
            HrCore(periods, batches, payslips, timeline)
        },
        payslipDetail,
        calculationExceptions,
        manualAdjustments,
        hrBusy,
    ) { core, detail, exceptions, adjustments, busy ->
        HrPayrollUiState(
            periods = core.periods,
            batches = core.batches,
            employeePayslips = core.payslips,
            payslipDetail = detail,
            calculationExceptions = exceptions,
            manualAdjustments = adjustments,
            employeeTimeline = core.timeline,
            busy = busy,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HrPayrollUiState())

    fun saveEmployee(id: Long?, draft: EmployeeDraft) = launch("پرسنل ذخیره شد.") { repository.saveEmployee(id, draft) }
    fun deactivate(id: Long) = launch("پرسنل غیرفعال شد.") { repository.deactivateEmployee(id) }
    fun saveAttendance(id: Long?, draft: AttendanceDraft) = launch("حضور و غیاب ذخیره شد.") { repository.saveAttendance(id, draft) }
    fun requestLeave(draft: LeaveDraft, requestedBy: String = "SYSTEM") = launch("درخواست مرخصی ثبت شد.") { repository.requestLeave(draft, requestedBy) }
    fun reviewLeave(draft: LeaveReviewDraft) = launch("نتیجه بررسی مرخصی ثبت شد.") { repository.reviewLeave(draft) }
    fun cancelLeave(id: Long) = launch("درخواست مرخصی لغو شد.") { repository.cancelLeave(id) }
    fun approveLeave(draft: LeaveDraft) = launch("مرخصی تأیید شد.") { repository.approveLeave(draft) }
    fun loadAttendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long) = viewModelScope.launch {
        runCatching { repository.attendanceSummary(employeeId, startEpochDay, endEpochDay) }
            .onSuccess { attendanceSummary.value = it }
            .onFailure { message.value = UiErrorHandler.message("PersonnelViewModel.attendance", it) }
    }
    fun saveContract(id: Long?, draft: EmployeeContractDraft) = launch("قرارداد ذخیره شد.") { repository.saveContract(id, draft) }
    fun approveContract(id: Long) = launch("قرارداد تأیید شد.") { repository.approveContract(id) }
    fun approveAttendanceCorrection(id: Long) = launch("اصلاح حضور و غیاب تأیید شد.") { repository.approveAttendanceCorrection(id) }
    fun grantLeave(draft: LeaveGrantDraft) = launch("سهمیه مرخصی در دفتر مرخصی ثبت شد.") { repository.grantLeave(draft) }
    fun postAdvance(draft: EmployeeAdvanceDraft) = launch("مساعده ثبت و سند حسابداری صادر شد.") { repository.postAdvance(draft) }
    fun settleAdvance(
        id: Long,
        amountRial: Long,
        paymentMethod: TreasuryChannel,
        settlementEpochDay: Long,
    ) = launch("تسویه مساعده و سند دریافت ثبت شد.") {
        repository.settleAdvance(id, amountRial, paymentMethod, settlementEpochDay)
    }
    fun calculatePayroll(draft: PayrollDraft) = viewModelScope.launch {
        runCatching { repository.calculatePayroll(draft) }
            .onSuccess { payrollPreview.value = it; message.value = "محاسبه حقوق انجام شد." }
            .onFailure { message.value = UiErrorHandler.message("PersonnelViewModel.payroll", it) }
    }
    fun postPayroll(draft: PayrollDraft) = launch("فیش حقوق برای تأیید مالک ثبت شد.") { repository.postPayroll(draft); payrollPreview.value = null }
    fun approvePayroll(payrollId: Long) = launch("حقوق توسط مالک تأیید و سند آن قطعی شد.") { repository.approvePayroll(payrollId) }
    fun reversePayroll(draft: PayrollReversalDraft) = launch("فیش حقوق ابطال و سند معکوس صادر شد؛ دوره حضور برای اصلاح باز شد.") { repository.reversePayroll(draft) }
    fun savePayrollPolicy(draft: PayrollPolicyDraft) = launch("سیاست نسخه‌دار حقوق ذخیره شد.") { repository.savePayrollPolicy(draft) }
    fun openPayrollPeriod(draft: PayrollPeriodDraftV2) = launchHr("دوره حقوق باز شد.") { payroll.openPeriod(draft) }
    fun closePayrollPeriod(command: ClosePayrollPeriodCommand) = launchHr("دوره حقوق بسته شد.") { payroll.closePeriod(command) }
    fun reopenPayrollPeriod(command: ReopenPayrollPeriodCommand) = launchHr("دوره حقوق برای اصلاح بازگشایی شد.") { payroll.reopenPeriod(command) }
    fun createPayrollBatch(draft: PayrollBatchDraftV2) = launchHr("دسته حقوق ایجاد شد.") { payroll.createBatch(draft) }
    fun calculatePayrollBatch(command: CalculatePayrollBatchCommand) = viewModelScope.launch {
        hrBusy.value = true
        runCatching { payroll.calculateBatch(command) }
            .onSuccess { outcome ->
                calculationExceptions.value = outcome.exceptions
                message.value = if (outcome.hasBlockingExceptions) {
                    "محاسبه به‌دلیل ${outcome.exceptions.count { it.blocking }} استثنای مسدودکننده متوقف شد."
                } else {
                    "${outcome.payslipIds.size} فیش حقوق با Snapshot ثابت محاسبه شد."
                }
            }
            .onFailure { message.value = UiErrorHandler.message("PersonnelViewModel.payrollV2.calculate", it) }
        hrBusy.value = false
    }
    fun reviewPayrollBatch(command: ReviewPayrollBatchCommand) = launchHr("دسته حقوق برای بازبینی ثبت شد.") { payroll.submitBatchForReview(command) }
    fun approvePayrollBatch(command: ApprovePayrollBatchCommand) = launchHr("تعهد حقوق تأیید و اسناد تعهد ثبت شد.") { payroll.approveBatch(command) }
    fun submitManualAdjustment(command: ManualPayrollAdjustmentCommand) = launchHr("تعدیل حقوق برای تأیید ارسال شد.") { payroll.submitManualAdjustment(command) }
    fun approveManualAdjustment(command: ApproveManualAdjustmentCommand) = launchHr("تعدیل حقوق تأیید شد.") { payroll.approveManualAdjustment(command) }
    fun loadManualAdjustments(periodId: Long) = viewModelScope.launch {
        runCatching { payroll.manualAdjustments(periodId) }
            .onSuccess { manualAdjustments.value = it }
            .onFailure { message.value = UiErrorHandler.message("PersonnelViewModel.payrollV2.adjustments", it) }
    }
    fun payPayslip(command: PayPayslipCommand) = launchHr("پرداخت حقوق در دفتر پرداخت ثبت شد.") { payroll.payPayslip(command) }
    fun reversePayrollPayment(command: ReversePayrollPaymentCommand) = launchHr("پرداخت با تراکنش جبرانی برگشت خورد.") { payroll.reversePayment(command) }
    fun reversePayslipV2(command: ReversePayslipCommandV2) = launchHr("فیش حقوق برگشت خورد؛ اصلاح فقط با Revision جدید ممکن است.") { payroll.reversePayslip(command) }
    fun loadPayslipDetail(id: Long) = viewModelScope.launch {
        hrBusy.value = true
        runCatching { payroll.payslipDetail(id) }
            .onSuccess { payslipDetail.value = it }
            .onFailure { message.value = UiErrorHandler.message("PersonnelViewModel.payrollV2.detail", it) }
        hrBusy.value = false
    }
    fun clearPayslipDetail() { payslipDetail.value = null }
    fun clearMessage() { message.value = null }
    fun selectEmployee(id: Long?) { selectedEmployeeId.value = id; attendanceSummary.value = null; payslipDetail.value = null }
    private fun launch(success: String, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }.onSuccess { message.value = success }.onFailure { message.value = UiErrorHandler.message("PersonnelViewModel", it) }
    }
    private fun launchHr(success: String, block: suspend () -> Unit) = viewModelScope.launch {
        hrBusy.value = true
        runCatching { block() }
            .onSuccess { message.value = success }
            .onFailure { message.value = UiErrorHandler.message("PersonnelViewModel.payrollV2", it) }
        hrBusy.value = false
    }
    companion object { fun factory(repo: PersonnelRepository, payroll: HrPayrollCommandService) = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = PersonnelViewModel(repo, payroll) as T
    } }
}
