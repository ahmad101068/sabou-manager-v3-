package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.FixedPointRatio
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryBalanceEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryLotConsumptionEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.common.businessRequire
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryCommandService
import ir.sabou.inventory.domain.inventory.ReceiveInventoryCommand
import ir.sabou.inventory.domain.inventory.IssueInventoryCommand
import ir.sabou.inventory.domain.inventory.AdjustInventoryCommand
import ir.sabou.inventory.domain.inventory.ReverseInventoryCommand
import ir.sabou.inventory.domain.inventory.InventoryLedgerResult
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import ir.sabou.inventory.domain.inventory.InventoryReceiptLot
import ir.sabou.inventory.domain.inventory.FefoLotAllocator
import ir.sabou.inventory.domain.inventory.InventoryLotStatus
import ir.sabou.inventory.domain.inventory.LotAllocationCandidate
import ir.sabou.inventory.domain.inventory.LotAllocationPurpose
import ir.sabou.inventory.domain.inventory.LotAllocationRequest
import ir.sabou.inventory.domain.inventory.WeightedAverageInventoryValuationService

/**
 * Authoritative command boundary for inventory quantity/value mutations.
 *
 * Every command owns a Room transaction. Nested calls participate in the caller's transaction, so a
 * cross-domain workflow (document + ledger + accounting + audit) either commits in full or rolls back.
 * `inventory_items.stockMicros/inventoryValueRial` is a compare-and-set projection cache; immutable
 * `stock_movements` remains the auditable history.
 */
class LocalInventoryCommandEngine(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) : InventoryCommandService {
    enum class LotIssuePolicy { NONE, FEFO_ALL, FEFO_ALLOCATED_ONLY }

    override suspend fun receive(command: ReceiveInventoryCommand): InventoryLedgerResult = receive(
        itemId = command.itemId,
        quantityMicros = command.quantityMicros,
        valueRial = command.valueRial,
        movementType = command.movementType,
        referenceType = command.referenceType,
        referenceId = command.referenceId,
        movementEpochDay = command.businessEpochDay,
        context = command.context,
        notes = command.notes,
        lot = command.lot,
        enforceLotPolicy = true,
    )

    override suspend fun issue(command: IssueInventoryCommand): InventoryLedgerResult = issue(
        itemId = command.itemId,
        quantityMicros = command.quantityMicros,
        valueRial = command.valueRial,
        movementType = command.movementType,
        referenceType = command.referenceType,
        referenceId = command.referenceId,
        movementEpochDay = command.businessEpochDay,
        context = command.context,
        notes = command.notes,
        lotPolicy = if (command.allocateTrackedLots) LotIssuePolicy.FEFO_ALL else LotIssuePolicy.NONE,
        requestedLotId = command.lotId,
    )

    override suspend fun adjust(command: AdjustInventoryCommand): InventoryLedgerResult = adjustToCount(
        itemId = command.itemId,
        countedQuantityMicros = command.countedQuantityMicros,
        countedValueRial = command.countedValueRial,
        referenceId = command.referenceId,
        movementEpochDay = command.businessEpochDay,
        context = command.context,
        notes = command.notes,
    )

    override suspend fun reverse(command: ReverseInventoryCommand): InventoryLedgerResult {
        val original = database.stockMovementDao().byId(command.originalMovementId)
            ?: throw BusinessError.EntityNotFound("STOCK_MOVEMENT", command.originalMovementId).asViolation()
        return restoreIssuedMovement(
            movement = original,
            reversalMovementType = command.reversalMovementType,
            reversalEpochDay = command.businessEpochDay,
            context = command.context,
            notes = command.notes,
        )
    }

    suspend fun receive(
        itemId: Long,
        quantityMicros: Long,
        valueRial: Long,
        movementType: InventoryMovementType,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
        lot: InventoryReceiptLot? = null,
        enforceLotPolicy: Boolean = false,
    ): InventoryLedgerResult = inventoryTransaction(movementEpochDay) {
        requireCommandIdentity(movementType, referenceType, referenceId)
        businessRequire(quantityMicros > 0) {
            BusinessError.InvalidInput("quantityMicros", "مقدار ورود موجودی باید مثبت باشد.")
        }
        businessRequire(valueRial >= 0) {
            BusinessError.InvalidInput("valueRial", "ارزش ورود موجودی نمی‌تواند منفی باشد.")
        }
        val resolved = resolveContext(context)
        val unitCost = unitCost(valueRial, quantityMicros)
        val expected = movement(
            itemId = itemId,
            movementType = movementType,
            quantityDeltaMicros = quantityMicros,
            valueDeltaRial = valueRial,
            referenceType = referenceType,
            referenceId = referenceId,
            movementEpochDay = movementEpochDay,
            context = resolved,
            unitCostRial = unitCost,
            notes = notes,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }

        val item = database.inventoryDao().activeById(itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", itemId).asViolation()
        val validLot = when {
            item.trackLot && lot != null -> lot.validated(movementEpochDay, item.trackExpiry)
            item.trackLot && enforceLotPolicy -> throw BusinessError.InvalidLot(null, "LOT_REQUIRED").asViolation()
            lot != null -> throw BusinessError.InvalidBusinessState("INVENTORY_ITEM", "LOT_TRACKING_DISABLED").asViolation()
            else -> null
        }
        val locationId = requireNotNull(resolved.locationId)
        val balance = balanceForCommand(item, locationId)
        val nextStock = (QuantityMicros.of(item.stockMicros) + QuantityMicros.of(quantityMicros)).value
        val nextValue = (MoneyRial.of(item.inventoryValueRial) + MoneyRial.of(valueRial)).value
        val nextLocationStock = (QuantityMicros.of(balance.onHandMicros) + QuantityMicros.of(quantityMicros)).value
        val nextLocationValue = (MoneyRial.of(balance.inventoryValueRial) + MoneyRial.of(valueRial)).value
        val now = clock()
        val result = insert(expected.copy(createdAtEpochMillis = now))
        businessRequire(
            database.inventoryDao().compareAndSetValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = nextStock,
                nextInventoryValueRial = nextValue,
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        updateBalance(
            balance = balance,
            nextOnHandMicros = nextLocationStock,
            nextInventoryValueRial = nextLocationValue,
            now = now,
        )
        validLot?.let { receivedLot ->
            applyReceivedLot(
                item = item,
                locationId = locationId,
                quantityMicros = quantityMicros,
                unitCostRial = unitCost,
                receivedEpochDay = movementEpochDay,
                referenceType = referenceType,
                referenceId = referenceId,
                context = resolved,
                lot = receivedLot,
                now = now,
            )
        }
        result
    }

    suspend fun issue(
        itemId: Long,
        quantityMicros: Long,
        valueRial: Long,
        movementType: InventoryMovementType,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
        lotPolicy: LotIssuePolicy = LotIssuePolicy.FEFO_ALLOCATED_ONLY,
        requestedLotId: Long? = null,
    ): InventoryLedgerResult = inventoryTransaction(movementEpochDay) {
        requireCommandIdentity(movementType, referenceType, referenceId)
        businessRequire(quantityMicros > 0) {
            BusinessError.InvalidInput("quantityMicros", "مقدار خروج موجودی باید مثبت باشد.")
        }
        businessRequire(valueRial >= 0) {
            BusinessError.InvalidInput("valueRial", "ارزش خروج موجودی نمی‌تواند منفی باشد.")
        }
        val resolved = resolveContext(context)
        val unitCost = unitCost(valueRial, quantityMicros)
        val expected = movement(
            itemId = itemId,
            movementType = movementType,
            quantityDeltaMicros = SignedLongMath.subtract(0L, quantityMicros),
            valueDeltaRial = SignedLongMath.subtract(0L, valueRial),
            referenceType = referenceType,
            referenceId = referenceId,
            movementEpochDay = movementEpochDay,
            context = resolved,
            unitCostRial = unitCost,
            notes = notes,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }

        val item = database.inventoryDao().activeById(itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", itemId).asViolation()
        val locationId = requireNotNull(resolved.locationId)
        val balance = balanceForCommand(item, locationId)
        val available = if (
            movementType in setOf(
                InventoryMovementType.WASTE,
                InventoryMovementType.INVENTORY_COUNT,
                InventoryMovementType.COUNT_VARIANCE,
            )
        ) {
            SignedLongMath.subtract(balance.onHandMicros, balance.reservedMicros)
        } else {
            availableMicros(balance)
        }
        businessRequire(available >= quantityMicros) {
            BusinessError.InsufficientStock(item.id, item.name, quantityMicros, available)
        }
        val lotPlan = planLotIssue(
            item = item,
            locationId = locationId,
            quantityMicros = quantityMicros,
            movementEpochDay = movementEpochDay,
            movementType = movementType,
            lotPolicy = lotPolicy,
            balance = balance,
            requestedLotId = requestedLotId,
        )
        businessRequire(balance.inventoryValueRial >= valueRial) {
            BusinessError.InsufficientInventoryValue(item.id, item.name, valueRial, balance.inventoryValueRial)
        }
        businessRequire(item.stockMicros >= quantityMicros && item.inventoryValueRial >= valueRial) {
            BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id)
        }
        val now = clock()
        val result = insert(expected.copy(createdAtEpochMillis = now))
        businessRequire(
            database.inventoryDao().compareAndSetValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = SignedLongMath.subtract(item.stockMicros, quantityMicros),
                nextInventoryValueRial = SignedLongMath.subtract(item.inventoryValueRial, valueRial),
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        updateBalance(
            balance = balance,
            nextOnHandMicros = SignedLongMath.subtract(balance.onHandMicros, quantityMicros),
            nextInventoryValueRial = SignedLongMath.subtract(balance.inventoryValueRial, valueRial),
            nextQuarantinedMicros = SignedLongMath.subtract(
                balance.quarantinedMicros,
                lotPlan.unavailableQuantityMicros,
            ),
            now = now,
        )
        applyLotIssue(lotPlan.allocations, result.movementId, now)
        result
    }

    suspend fun adjustToCount(
        itemId: Long,
        countedQuantityMicros: Long,
        countedValueRial: Long,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
    ): InventoryLedgerResult = inventoryTransaction(movementEpochDay) {
        businessRequire(countedQuantityMicros >= 0) {
            BusinessError.InvalidInput("countedQuantityMicros", "موجودی شمارش‌شده نمی‌تواند منفی باشد.")
        }
        businessRequire(countedValueRial >= 0) {
            BusinessError.InvalidInput("countedValueRial", "ارزش شمارش‌شده نمی‌تواند منفی باشد.")
        }
        businessRequire(referenceId > 0) {
            BusinessError.InvalidInput("referenceId", "شناسه سند شمارش معتبر نیست.")
        }
        val resolved = resolveContext(context)
        val item = database.inventoryDao().activeById(itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", itemId).asViolation()
        val locationId = requireNotNull(resolved.locationId)
        val balance = balanceForCommand(item, locationId)
        val quantityDelta = SignedLongMath.subtract(countedQuantityMicros, balance.onHandMicros)
        val valueDelta = SignedLongMath.subtract(countedValueRial, balance.inventoryValueRial)
        businessRequire(quantityDelta != 0L || valueDelta != 0L) {
            BusinessError.InvalidBusinessState("INVENTORY_COUNT", "NO_VARIANCE")
        }
        val unitCost = if (quantityDelta == 0L) 0L else unitCost(absExact(valueDelta), absExact(quantityDelta))
        val expected = movement(
            itemId = item.id,
            movementType = InventoryMovementType.INVENTORY_COUNT,
            quantityDeltaMicros = quantityDelta,
            valueDeltaRial = valueDelta,
            referenceType = InventoryReferenceType.INVENTORY_COUNT,
            referenceId = referenceId,
            movementEpochDay = movementEpochDay,
            context = resolved,
            unitCostRial = unitCost,
            notes = notes,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }

        val now = clock()
        val nextAggregateStock = SignedLongMath.add(item.stockMicros, quantityDelta)
        val nextAggregateValue = SignedLongMath.add(item.inventoryValueRial, valueDelta)
        businessRequire(nextAggregateStock >= 0 && nextAggregateValue >= 0) {
            BusinessError.InvalidBusinessState("INVENTORY_COUNT", "NEGATIVE_AGGREGATE")
        }
        val lotPlan = if (quantityDelta < 0L) {
            planLotIssue(
                item = item,
                locationId = locationId,
                quantityMicros = absExact(quantityDelta),
                movementEpochDay = movementEpochDay,
                movementType = InventoryMovementType.INVENTORY_COUNT,
                lotPolicy = LotIssuePolicy.FEFO_ALLOCATED_ONLY,
                balance = balance,
            )
        } else {
            LotIssuePlan.EMPTY
        }
        val result = insert(expected.copy(createdAtEpochMillis = now))
        businessRequire(
            database.inventoryDao().compareAndSetValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = nextAggregateStock,
                nextInventoryValueRial = nextAggregateValue,
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        updateBalance(
            balance = balance,
            nextOnHandMicros = countedQuantityMicros,
            nextInventoryValueRial = countedValueRial,
            nextQuarantinedMicros = SignedLongMath.subtract(
                balance.quarantinedMicros,
                lotPlan.unavailableQuantityMicros,
            ),
            now = now,
        )
        applyLotIssue(lotPlan.allocations, result.movementId, now)
        result
    }

    suspend fun issueTransferDocument(
        transferId: Long,
        businessEpochDay: Long,
        context: InventoryCommandContext,
    ) = inventoryTransaction(businessEpochDay) {
        val transferDao = database.inventoryTransferDao()
        val transfer = transferDao.transfer(transferId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_TRANSFER", transferId).asViolation()
        businessRequire(transfer.status == "APPROVED") {
            BusinessError.TransferNotApproved(transfer.id)
        }
        val resolved = resolveContext(context, locationOverride = transfer.sourceLocationId)
        val lines = transferDao.lines(transfer.id)
        businessRequire(lines.isNotEmpty()) {
            BusinessError.InvalidBusinessState("INVENTORY_TRANSFER", "NO_LINES")
        }
        val now = clock()
        lines.forEach { line ->
            val item = database.inventoryDao().activeById(line.itemId)
                ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", line.itemId).asViolation()
            val quantity = line.requestedQuantityMicros
            val sourceBalance = balanceForCommand(item, transfer.sourceLocationId)
            val destinationBalance = balanceForCommand(item, transfer.destinationLocationId)
            val sourceLot = line.lotId?.let { lotId ->
                database.inventoryLotDao().byId(lotId)
                    ?: throw BusinessError.InvalidLot(lotId, "LOT_NOT_FOUND").asViolation()
            }
            if (item.trackLot && sourceLot == null) {
                throw BusinessError.InvalidLot(null, "LOT_REQUIRED").asViolation()
            }
            if (sourceLot != null) {
                businessRequire(
                    sourceLot.itemId == item.id && sourceLot.locationId == transfer.sourceLocationId &&
                        InventoryLotStatus.requireKnown(sourceLot.status) == InventoryLotStatus.ACTIVE,
                ) { BusinessError.InvalidLot(sourceLot.id, "LOT_NOT_TRANSFERABLE") }
                if (sourceLot.expiryEpochDay != null && sourceLot.expiryEpochDay < businessEpochDay) {
                    throw BusinessError.LotExpired(sourceLot.id, sourceLot.expiryEpochDay).asViolation()
                }
                businessRequire(sourceLot.quantityMicros >= quantity) {
                    BusinessError.InsufficientStock(item.id, item.name, quantity, sourceLot.quantityMicros)
                }
            }
            val value = if (sourceLot != null) {
                WeightedAverageInventoryValuationService.transferValue(sourceLot.unitCostRial, quantity)
            } else {
                WeightedAverageInventoryValuationService.issueValue(
                    sourceBalance.onHandMicros,
                    sourceBalance.inventoryValueRial,
                    quantity,
                )
            }
            val unitCost = sourceLot?.unitCostRial ?: unitCost(value, quantity)
            businessRequire(availableMicros(sourceBalance) >= quantity) {
                BusinessError.InsufficientStock(item.id, item.name, quantity, availableMicros(sourceBalance))
            }
            businessRequire(sourceBalance.inventoryValueRial >= value) {
                BusinessError.InsufficientInventoryValue(item.id, item.name, value, sourceBalance.inventoryValueRial)
            }
            val lineContext = resolved.copy(
                idempotencyKey = "${resolved.idempotencyKey}:line:${line.id}:out",
                locationId = transfer.sourceLocationId,
            ).validated()
            val movementId = insert(
                movement(
                    itemId = item.id,
                    movementType = InventoryMovementType.TRANSFER_OUT,
                    quantityDeltaMicros = SignedLongMath.subtract(0L, quantity),
                    valueDeltaRial = SignedLongMath.subtract(0L, value),
                    referenceType = InventoryReferenceType.STOCK_TRANSFER,
                    referenceId = transfer.id,
                    movementEpochDay = businessEpochDay,
                    context = lineContext,
                    unitCostRial = unitCost,
                    notes = transfer.note,
                ).copy(createdAtEpochMillis = now),
            ).movementId
            updateBalance(
                balance = sourceBalance,
                nextOnHandMicros = SignedLongMath.subtract(sourceBalance.onHandMicros, quantity),
                nextInventoryValueRial = SignedLongMath.subtract(sourceBalance.inventoryValueRial, value),
                now = now,
            )
            businessRequire(
                database.inventoryBalanceDao().compareAndSetInTransit(
                    itemId = item.id,
                    locationId = transfer.destinationLocationId,
                    expectedInTransitMicros = destinationBalance.inTransitMicros,
                    nextInTransitMicros = SignedLongMath.add(destinationBalance.inTransitMicros, quantity),
                    updatedAtEpochMillis = now,
                ) == 1,
            ) { BusinessError.ConcurrencyConflict("INVENTORY_BALANCE", item.id) }
            if (sourceLot != null) {
                applyLotIssue(
                    listOf(
                        PlannedLotIssue(
                            lotId = sourceLot.id,
                            quantityMicros = quantity,
                            expectedQuantityMicros = sourceLot.quantityMicros,
                            unitCostRial = sourceLot.unitCostRial,
                            status = InventoryLotStatus.ACTIVE,
                        ),
                    ),
                    movementId,
                    now,
                )
            }
            businessRequire(
                transferDao.markLineIssued(transfer.id, line.id, quantity, unitCost, value, now) == 1,
            ) { BusinessError.ConcurrencyConflict("INVENTORY_TRANSFER_LINE", line.id) }
        }
    }

    suspend fun receiveTransferDocument(
        transferId: Long,
        receivedQuantityByLineId: Map<Long, Long>,
        businessEpochDay: Long,
        context: InventoryCommandContext,
    ) = inventoryTransaction(businessEpochDay) {
        val transferDao = database.inventoryTransferDao()
        val transfer = transferDao.transfer(transferId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_TRANSFER", transferId).asViolation()
        businessRequire(transfer.status == "IN_TRANSIT") {
            BusinessError.InvalidBusinessState("INVENTORY_TRANSFER", transfer.status)
        }
        val resolved = resolveContext(context, locationOverride = transfer.destinationLocationId)
        val lines = transferDao.lines(transfer.id)
        val now = clock()
        lines.forEach { line ->
            val issued = line.issuedQuantityMicros
                ?: throw BusinessError.InvalidBusinessState("INVENTORY_TRANSFER_LINE", "NOT_ISSUED").asViolation()
            val received = receivedQuantityByLineId[line.id]
                ?: throw BusinessError.InvalidInput("receivedQuantityByLineId", "مقدار دریافت همه ردیف‌ها الزامی است.").asViolation()
            if (received != issued) {
                throw BusinessError.TransferVarianceRequiresApproval(transfer.id, line.id, issued, received).asViolation()
            }
            val value = requireNotNull(line.valueRial)
            val unitCost = requireNotNull(line.unitCostRial)
            val item = database.inventoryDao().activeById(line.itemId)
                ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", line.itemId).asViolation()
            val destinationBalance = balanceForCommand(item, transfer.destinationLocationId)
            businessRequire(destinationBalance.inTransitMicros >= received) {
                BusinessError.ConcurrencyConflict("INVENTORY_TRANSFER_IN_TRANSIT", line.id)
            }
            val lineContext = resolved.copy(
                idempotencyKey = "${resolved.idempotencyKey}:line:${line.id}:in",
                locationId = transfer.destinationLocationId,
            ).validated()
            insert(
                movement(
                    itemId = item.id,
                    movementType = InventoryMovementType.TRANSFER_IN,
                    quantityDeltaMicros = received,
                    valueDeltaRial = value,
                    referenceType = InventoryReferenceType.STOCK_TRANSFER,
                    referenceId = transfer.id,
                    movementEpochDay = businessEpochDay,
                    context = lineContext,
                    unitCostRial = unitCost,
                    notes = transfer.note,
                ).copy(createdAtEpochMillis = now),
            )
            businessRequire(
                database.inventoryBalanceDao().compareAndSetTransferReceipt(
                    itemId = item.id,
                    locationId = transfer.destinationLocationId,
                    expectedOnHandMicros = destinationBalance.onHandMicros,
                    expectedInventoryValueRial = destinationBalance.inventoryValueRial,
                    expectedInTransitMicros = destinationBalance.inTransitMicros,
                    nextOnHandMicros = SignedLongMath.add(destinationBalance.onHandMicros, received),
                    nextInventoryValueRial = SignedLongMath.add(destinationBalance.inventoryValueRial, value),
                    nextInTransitMicros = SignedLongMath.subtract(destinationBalance.inTransitMicros, received),
                    updatedAtEpochMillis = now,
                ) == 1,
            ) { BusinessError.ConcurrencyConflict("INVENTORY_BALANCE", item.id) }
            line.lotId?.let { sourceLotId ->
                val sourceLot = database.inventoryLotDao().byId(sourceLotId)
                    ?: throw BusinessError.InvalidLot(sourceLotId, "LOT_NOT_FOUND").asViolation()
                val destinationLot = database.inventoryLotDao().byNaturalKey(
                    item.id,
                    transfer.destinationLocationId,
                    sourceLot.lotCode,
                )
                if (destinationLot == null) {
                    database.inventoryLotDao().insert(
                        sourceLot.copy(
                            id = 0,
                            globalId = GlobalId.new().value,
                            locationId = transfer.destinationLocationId,
                            quantityMicros = received,
                            initialQuantityMicros = received,
                            status = InventoryLotStatus.ACTIVE.storedValue,
                            correlationId = transfer.correlationId,
                            createdByActorId = resolved.actorId,
                            createdAtEpochMillis = now,
                            updatedAtEpochMillis = now,
                        ),
                    )
                } else {
                    businessRequire(
                        database.inventoryLotDao().addTransferredQuantity(
                            id = destinationLot.id,
                            expectedQuantityMicros = destinationLot.quantityMicros,
                            quantityMicros = received,
                            updatedAtEpochMillis = now,
                        ) == 1,
                    ) { BusinessError.ConcurrencyConflict("INVENTORY_LOT", destinationLot.id) }
                }
            }
            businessRequire(
                transferDao.markLineReceived(transfer.id, line.id, received, 0, now) == 1,
            ) { BusinessError.ConcurrencyConflict("INVENTORY_TRANSFER_LINE", line.id) }
        }
    }

    suspend fun restoreIssuedMovement(
        movement: StockMovementEntity,
        reversalMovementType: InventoryMovementType,
        reversalEpochDay: Long,
        context: InventoryCommandContext,
        notes: String? = null,
    ): InventoryLedgerResult = inventoryTransaction(reversalEpochDay) {
        businessRequire(movement.quantityDeltaMicros < 0 && movement.valueDeltaRial <= 0) {
            BusinessError.InvalidBusinessState("STOCK_MOVEMENT", movement.movementType)
        }
        businessRequire(
            reversalMovementType !in setOf(
                InventoryMovementType.LEGACY_UNKNOWN,
                InventoryMovementType.LEGACY_SALE_CONSUMPTION,
            ),
        ) {
            BusinessError.InvalidInput("reversalMovementType", "نوع گردش برگشت معتبر نیست.")
        }
        val resolved = resolveContext(context, locationOverride = movement.locationId)
        val restoredQuantity = absExact(movement.quantityDeltaMicros)
        val restoredValue = absExact(movement.valueDeltaRial)
        val expected = movement(
            itemId = movement.itemId,
            movementType = reversalMovementType,
            quantityDeltaMicros = restoredQuantity,
            valueDeltaRial = restoredValue,
            referenceType = InventoryReferenceType.fromStoredValue(movement.referenceType),
            referenceId = movement.referenceId,
            movementEpochDay = reversalEpochDay,
            context = resolved,
            unitCostRial = movement.unitCostRial,
            notes = notes,
            reversalOfMovementId = movement.id,
        )
        replayOrConflict(expected)?.let { return@inventoryTransaction it }
        database.stockMovementDao().reversalOf(movement.id)?.let {
            throw BusinessError.IdempotencyConflict(resolved.idempotencyKey).asViolation()
        }

        val item = database.inventoryDao().byId(movement.itemId)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", movement.itemId).asViolation()
        val balance = balanceForCommand(item, requireNotNull(resolved.locationId))
        val lotConsumptions = database.inventoryLotDao().consumptions(movement.id)
        val unavailableRestore = lotConsumptions.fold(0L) { total, consumption ->
            val remaining = SignedLongMath.subtract(consumption.quantityMicros, consumption.reversedQuantityMicros)
            val status = InventoryLotStatus.requireKnown(consumption.lotStatusSnapshot)
            if (status.isUnavailable) SignedLongMath.add(total, remaining) else total
        }
        val now = clock()
        val result = insert(expected.copy(createdAtEpochMillis = now))
        businessRequire(
            database.inventoryDao().compareAndRestoreValuation(
                itemId = item.id,
                expectedStockMicros = item.stockMicros,
                expectedInventoryValueRial = item.inventoryValueRial,
                nextStockMicros = SignedLongMath.add(item.stockMicros, restoredQuantity),
                nextInventoryValueRial = SignedLongMath.add(item.inventoryValueRial, restoredValue),
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrentModification("INVENTORY_ITEM", item.id) }
        updateBalance(
            balance = balance,
            nextOnHandMicros = SignedLongMath.add(balance.onHandMicros, restoredQuantity),
            nextInventoryValueRial = SignedLongMath.add(balance.inventoryValueRial, restoredValue),
            nextQuarantinedMicros = SignedLongMath.add(balance.quarantinedMicros, unavailableRestore),
            now = now,
        )

        lotConsumptions.forEach { consumption ->
            val restoreToLot = SignedLongMath.subtract(consumption.quantityMicros, consumption.reversedQuantityMicros)
            if (restoreToLot > 0) {
                val lot = database.inventoryLotDao().byId(consumption.lotId)
                    ?: throw BusinessError.EntityNotFound("INVENTORY_LOT", consumption.lotId).asViolation()
                check(
                    database.inventoryLotDao().restoreConsumedQuantity(
                        id = lot.id,
                        expectedQuantityMicros = lot.quantityMicros,
                        nextQuantityMicros = SignedLongMath.add(lot.quantityMicros, restoreToLot),
                        nextStatus = InventoryLotStatus.requireKnown(consumption.lotStatusSnapshot).storedValue,
                        updatedAtEpochMillis = now,
                    ) == 1,
                ) { "بازگردانی موجودی لات انجام نشد." }
                check(database.inventoryLotDao().markConsumptionReversed(consumption.id) == 1) {
                    "ثبت بازگشت مصرف لات انجام نشد."
                }
            }
        }
        result
    }

    private suspend fun resolveContext(
        context: InventoryCommandContext,
        locationOverride: Long? = null,
    ): InventoryCommandContext {
        val valid = context.validated()
        val locationId = locationOverride ?: valid.locationId ?: database.managementControlDao().defaultLocationId()
            ?: throw BusinessError.EntityNotFound("DEFAULT_STORAGE_LOCATION", null).asViolation()
        if (database.managementControlDao().activeLocation(locationId) == null) {
            throw BusinessError.EntityNotFound("STORAGE_LOCATION", locationId).asViolation()
        }
        return valid.copy(locationId = locationId)
    }

    private suspend fun balanceForCommand(
        item: InventoryItemEntity,
        locationId: Long,
    ): InventoryBalanceEntity {
        val dao = database.inventoryBalanceDao()
        dao.byKey(item.id, locationId)?.let { return it }
        val now = clock()
        if (dao.countForItem(item.id) == 0) {
            val defaultLocationId = database.inventoryLocationDao().defaultLocationId()
                ?: throw BusinessError.EntityNotFound("DEFAULT_STORAGE_LOCATION", null).asViolation()
            dao.initialize(
                InventoryBalanceEntity(
                    itemId = item.id,
                    locationId = defaultLocationId,
                    onHandMicros = item.stockMicros,
                    inventoryValueRial = item.inventoryValueRial,
                    updatedAtEpochMillis = now,
                ),
            )
        }
        dao.initialize(
            InventoryBalanceEntity(
                itemId = item.id,
                locationId = locationId,
                onHandMicros = 0,
                inventoryValueRial = 0,
                updatedAtEpochMillis = now,
            ),
        )
        return dao.byKey(item.id, locationId)
            ?: throw BusinessError.ConcurrencyConflict("INVENTORY_BALANCE", item.id).asViolation()
    }

    private suspend fun updateBalance(
        balance: InventoryBalanceEntity,
        nextOnHandMicros: Long,
        nextInventoryValueRial: Long,
        nextQuarantinedMicros: Long = balance.quarantinedMicros,
        now: Long,
    ) {
        businessRequire(
            database.inventoryBalanceDao().compareAndSetOnHand(
                itemId = balance.itemId,
                locationId = balance.locationId,
                expectedOnHandMicros = balance.onHandMicros,
                expectedInventoryValueRial = balance.inventoryValueRial,
                expectedQuarantinedMicros = balance.quarantinedMicros,
                nextOnHandMicros = nextOnHandMicros,
                nextInventoryValueRial = nextInventoryValueRial,
                nextQuarantinedMicros = nextQuarantinedMicros,
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrencyConflict("INVENTORY_BALANCE", balance.itemId) }
    }

    private fun availableMicros(balance: InventoryBalanceEntity): Long = SignedLongMath.subtract(
        SignedLongMath.subtract(
            SignedLongMath.subtract(balance.onHandMicros, balance.reservedMicros),
            balance.damagedMicros,
        ),
        balance.quarantinedMicros,
    )

    private fun requireCommandIdentity(
        movementType: InventoryMovementType,
        referenceType: InventoryReferenceType,
        referenceId: Long,
    ) {
        businessRequire(
            movementType !in setOf(
                InventoryMovementType.LEGACY_UNKNOWN,
                InventoryMovementType.LEGACY_SALE_CONSUMPTION,
            ),
        ) {
            BusinessError.InvalidInput("movementType", "نوع گردش موجودی معتبر نیست.")
        }
        businessRequire(referenceType != InventoryReferenceType.LEGACY_UNKNOWN) {
            BusinessError.InvalidInput("referenceType", "نوع مرجع موجودی معتبر نیست.")
        }
        businessRequire(referenceId > 0) {
            BusinessError.InvalidInput("referenceId", "شناسه مرجع موجودی معتبر نیست.")
        }
    }

    private fun movement(
        itemId: Long,
        movementType: InventoryMovementType,
        quantityDeltaMicros: Long,
        valueDeltaRial: Long,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        movementEpochDay: Long,
        context: InventoryCommandContext,
        unitCostRial: Long,
        notes: String?,
        reversalOfMovementId: Long? = null,
    ): StockMovementEntity = StockMovementEntity(
        itemId = itemId,
        movementType = movementType.storedValue,
        quantityDeltaMicros = quantityDeltaMicros,
        valueDeltaRial = valueDeltaRial,
        referenceType = referenceType.storedValue,
        referenceId = referenceId,
        movementEpochDay = movementEpochDay,
        notes = notes?.trim().orEmpty().ifBlank { context.reason },
        createdAtEpochMillis = 0L,
        globalId = GlobalId.new().value,
        idempotencyKey = context.idempotencyKey,
        correlationId = context.correlationId,
        actorId = context.actorId,
        deviceId = context.deviceId,
        locationId = requireNotNull(context.locationId),
        unitCostRial = unitCostRial,
        reasonCode = context.reasonCode.storedValue,
        reversalOfMovementId = reversalOfMovementId,
    )

    private suspend fun replayOrConflict(expected: StockMovementEntity): InventoryLedgerResult? {
        val existing = database.stockMovementDao().byIdempotencyKey(expected.idempotencyKey) ?: return null
        val samePayload = existing.itemId == expected.itemId &&
            existing.movementType == expected.movementType &&
            existing.quantityDeltaMicros == expected.quantityDeltaMicros &&
            existing.valueDeltaRial == expected.valueDeltaRial &&
            existing.referenceType == expected.referenceType &&
            existing.referenceId == expected.referenceId &&
            existing.movementEpochDay == expected.movementEpochDay &&
            existing.notes == expected.notes &&
            existing.correlationId == expected.correlationId &&
            existing.actorId == expected.actorId &&
            existing.deviceId == expected.deviceId &&
            existing.locationId == expected.locationId &&
            existing.unitCostRial == expected.unitCostRial &&
            existing.reasonCode == expected.reasonCode &&
            existing.reversalOfMovementId == expected.reversalOfMovementId
        if (!samePayload) throw BusinessError.IdempotencyConflict(expected.idempotencyKey).asViolation()
        return InventoryLedgerResult(existing.id, existing.globalId, idempotentReplay = true)
    }

    private suspend fun insert(entity: StockMovementEntity): InventoryLedgerResult {
        val movementId = database.stockMovementDao().insert(entity)
        return InventoryLedgerResult(movementId, entity.globalId, idempotentReplay = false)
    }

    private data class PlannedLotIssue(
        val lotId: Long,
        val quantityMicros: Long,
        val expectedQuantityMicros: Long,
        val unitCostRial: Long,
        val status: InventoryLotStatus,
    )

    private data class LotIssuePlan(
        val allocations: List<PlannedLotIssue>,
        val unavailableQuantityMicros: Long,
    ) {
        companion object {
            val EMPTY = LotIssuePlan(emptyList(), 0)
        }
    }

    private suspend fun planLotIssue(
        item: InventoryItemEntity,
        locationId: Long,
        quantityMicros: Long,
        movementEpochDay: Long,
        movementType: InventoryMovementType,
        lotPolicy: LotIssuePolicy,
        balance: InventoryBalanceEntity,
        requestedLotId: Long? = null,
    ): LotIssuePlan {
        if (!item.trackLot || lotPolicy == LotIssuePolicy.NONE || quantityMicros == 0L) return LotIssuePlan.EMPTY
        val lotDao = database.inventoryLotDao()
        val lotQuantity = lotDao.allocatedQuantityAtLocation(item.id, locationId)
        val unallocatedStock = SignedLongMath.subtract(balance.onHandMicros, lotQuantity).coerceAtLeast(0L)
        val requiredFromLots = when (lotPolicy) {
            LotIssuePolicy.NONE -> 0L
            LotIssuePolicy.FEFO_ALL -> quantityMicros
            LotIssuePolicy.FEFO_ALLOCATED_ONLY ->
                SignedLongMath.subtract(quantityMicros, unallocatedStock).coerceAtLeast(0L)
        }
        if (requiredFromLots == 0L) return LotIssuePlan.EMPTY
        val entities = if (requestedLotId == null) {
            lotDao.allocationCandidates(item.id, locationId)
        } else {
            val requested = lotDao.byId(requestedLotId)
                ?: throw BusinessError.InvalidLot(requestedLotId, "LOT_NOT_FOUND").asViolation()
            businessRequire(requested.itemId == item.id && requested.locationId == locationId) {
                BusinessError.InvalidLot(requestedLotId, "LOT_ITEM_LOCATION_MISMATCH")
            }
            listOf(requested)
        }
        val purpose = when (movementType) {
            InventoryMovementType.WASTE, InventoryMovementType.INVENTORY_COUNT,
            InventoryMovementType.COUNT_VARIANCE -> LotAllocationPurpose.DISPOSAL
            InventoryMovementType.PURCHASE_RETURN, InventoryMovementType.PURCHASE_REVERSAL ->
                LotAllocationPurpose.SUPPLIER_RETURN
            else -> LotAllocationPurpose.NORMAL_CONSUMPTION
        }
        val result = FefoLotAllocator.allocate(
            LotAllocationRequest(
                itemId = item.id,
                locationId = locationId,
                requiredQuantityMicros = requiredFromLots,
                businessEpochDay = movementEpochDay,
                trackExpiry = item.trackExpiry,
                purpose = purpose,
            ),
            entities.map { lot ->
                LotAllocationCandidate(
                    lotId = lot.id,
                    locationId = lot.locationId,
                    receivedEpochDay = lot.receivedEpochDay,
                    expiryEpochDay = lot.expiryEpochDay,
                    availableQuantityMicros = lot.quantityMicros,
                    unitCostRial = lot.unitCostRial,
                    status = InventoryLotStatus.fromStoredValue(lot.status),
                )
            },
        )
        businessRequire(result.isComplete) {
            BusinessError.InsufficientStock(item.id, item.name, requiredFromLots, result.allocatedQuantityMicros)
        }
        val byId = entities.associateBy { it.id }
        val planned = result.allocations.map { allocation ->
            val lot = requireNotNull(byId[allocation.lotId])
            PlannedLotIssue(
                lotId = lot.id,
                quantityMicros = allocation.quantityMicros,
                expectedQuantityMicros = lot.quantityMicros,
                unitCostRial = lot.unitCostRial,
                status = InventoryLotStatus.fromStoredValue(lot.status),
            )
        }
        val unavailable = planned.filter { it.status.isUnavailable }.fold(0L) { total, lot ->
            SignedLongMath.add(total, lot.quantityMicros)
        }
        return LotIssuePlan(planned, unavailable)
    }

    private suspend fun applyLotIssue(
        allocations: List<PlannedLotIssue>,
        movementId: Long,
        now: Long,
    ) {
        allocations.forEach { allocation ->
            check(
                database.inventoryLotDao().compareAndSetQuantity(
                    id = allocation.lotId,
                    expectedQuantityMicros = allocation.expectedQuantityMicros,
                    expectedStatus = allocation.status.storedValue,
                    nextQuantityMicros = SignedLongMath.subtract(
                        allocation.expectedQuantityMicros,
                        allocation.quantityMicros,
                    ),
                    updatedAtEpochMillis = now,
                ) == 1,
            ) { "کاهش موجودی لات انجام نشد." }
            database.inventoryLotDao().insertConsumption(
                InventoryLotConsumptionEntity(
                    stockMovementId = movementId,
                    lotId = allocation.lotId,
                    quantityMicros = allocation.quantityMicros,
                    unitCostRial = allocation.unitCostRial,
                    lotStatusSnapshot = allocation.status.storedValue,
                ),
            )
        }
    }

    private suspend fun applyReceivedLot(
        item: InventoryItemEntity,
        locationId: Long,
        quantityMicros: Long,
        unitCostRial: Long,
        receivedEpochDay: Long,
        referenceType: InventoryReferenceType,
        referenceId: Long,
        context: InventoryCommandContext,
        lot: InventoryReceiptLot,
        now: Long,
    ) {
        val dao = database.inventoryLotDao()
        val existing = dao.byNaturalKey(item.id, locationId, lot.lotNumber)
        if (existing == null) {
            dao.insert(
                ir.sabou.inventory.data.db.InventoryLotEntity(
                    globalId = GlobalId.new().value,
                    itemId = item.id,
                    locationId = locationId,
                    lotCode = lot.lotNumber,
                    supplierLotNumber = lot.supplierLotNumber,
                    receivedEpochDay = receivedEpochDay,
                    productionEpochDay = lot.productionEpochDay,
                    expiryEpochDay = lot.expiryEpochDay,
                    quantityMicros = quantityMicros,
                    initialQuantityMicros = quantityMicros,
                    unitCostRial = unitCostRial,
                    status = InventoryLotStatus.ACTIVE.storedValue,
                    barcode = lot.barcode,
                    sourceReceiptId = referenceId.takeIf { referenceType == InventoryReferenceType.GOODS_RECEIPT },
                    correlationId = context.correlationId,
                    createdByActorId = context.actorId,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            return
        }
        val status = InventoryLotStatus.requireKnown(existing.status)
        val sameIdentity = existing.supplierLotNumber == lot.supplierLotNumber &&
            existing.productionEpochDay == lot.productionEpochDay &&
            existing.expiryEpochDay == lot.expiryEpochDay &&
            existing.barcode == lot.barcode && existing.unitCostRial == unitCostRial
        businessRequire(sameIdentity && status in setOf(InventoryLotStatus.ACTIVE, InventoryLotStatus.DEPLETED)) {
            BusinessError.InvalidLot(existing.id, "LOT_IDENTITY_CONFLICT")
        }
        businessRequire(
            dao.addTransferredQuantity(
                id = existing.id,
                expectedQuantityMicros = existing.quantityMicros,
                quantityMicros = quantityMicros,
                updatedAtEpochMillis = now,
            ) == 1,
        ) { BusinessError.ConcurrencyConflict("INVENTORY_LOT", existing.id) }
    }

    private fun unitCost(valueRial: Long, quantityMicros: Long): Long =
        if (valueRial == 0L) 0L else FixedPointRatio.unitCostRial(valueRial, quantityMicros)

    private suspend fun <T> inventoryTransaction(
        businessEpochDay: Long,
        block: suspend () -> T,
    ): T = try {
        database.withTransaction { block() }
    } catch (error: Throwable) {
        throw mapDatabaseBusinessFailure(error, businessEpochDay)
    }

    private fun absExact(value: Long): Long {
        require(value != Long.MIN_VALUE) { "مقدار از محدوده امن خارج است." }
        return kotlin.math.abs(value)
    }

    private fun InventoryMovementType.canDisposeExpiredLots(): Boolean = this in setOf(
        InventoryMovementType.PURCHASE_REVERSAL,
        InventoryMovementType.PURCHASE_RETURN,
        InventoryMovementType.INVENTORY_COUNT,
        InventoryMovementType.WASTE,
    )
}
