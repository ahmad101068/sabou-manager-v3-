package ir.sabou.inventory.ui

import ir.sabou.inventory.BuildConfig

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowOutward
import androidx.compose.material.icons.outlined.ColorLens
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.data.AutomaticBackupFrequency
import ir.sabou.inventory.data.BackupPolicy
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.operations.SyncSafetyGate

enum class ThemePreference(val title: String, val description: String) {
    SYSTEM("مطابق گوشی", "حالت روشن یا تیره را از تنظیمات دستگاه بگیر"),
    LIGHT("روشن", "پس‌زمینه روشن برای محیط‌های پرنور"),
    DARK("تیره", "نمای تیره برای استفاده شبانه"),
}

enum class FontScalePreference(val title: String, val multiplier: Float) {
    NORMAL("معمولی", 1f),
    LARGE("بزرگ", 1.15f),
    EXTRA_LARGE("خیلی بزرگ", 1.3f),
}

private enum class SettingsSection { GENERAL, APPEARANCE, DATA }

internal data class NavigationDestination(
    val title: String,
    val subtitle: String,
    val keywords: String,
    val screen: AppScreen,
)

internal val navigationDestinations = listOf(
    NavigationDestination("خرید و فاکتورها", "ثبت، جست‌وجو و تسویه خرید", "خرید فاکتور تامین کننده پرداخت", AppScreen.PURCHASES),
    NavigationDestination("ثبت خرید جدید", "ایجاد فاکتور خرید", "خرید جدید فاکتور", AppScreen.NEW_PURCHASE),
    NavigationDestination("تأمین‌کنندگان", "مدیریت فروشندگان و مانده‌ها", "تامین کننده فروشنده", AppScreen.SUPPLIERS),
    NavigationDestination("انبار", "کالا، موجودی و انبارگردانی", "انبار کالا موجودی شمارش", AppScreen.INVENTORY),
    NavigationDestination("دفتر گردش موجودی", "ورود، خروج، مصرف، ضایعات و اصلاح", "گردش موجودی ورود خروج مصرف ضایعات", AppScreen.STOCK_MOVEMENTS),
    NavigationDestination("فروش روزانه صندوق", "ورود دستی آمار POS و صدور خودکار سند", "فروش روزانه صندوق پوز آمار", AppScreen.SALES),
    NavigationDestination("تولید و رسپی", "محصول و مواد اولیه", "رسپی تولید محصول مواد اولیه", AppScreen.RECIPES),
    NavigationDestination("حسابداری", "اسناد، حساب‌ها و گزارش‌های مالی", "حسابداری سند حساب دفتر تراز سود", AppScreen.ACCOUNTING),
    NavigationDestination("ثبت سند جدید", "سند دستی حسابداری", "سند جدید حسابداری", AppScreen.NEW_JOURNAL),
    NavigationDestination("پرسنل و حقوق", "کارکنان و پرداخت حقوق", "پرسنل کارمند حقوق", AppScreen.PERSONNEL),
    NavigationDestination("دارایی‌های ثابت", "اموال و استهلاک", "دارایی اموال استهلاک", AppScreen.ASSETS),
    NavigationDestination("مرکز هشدارها", "هشدارهای عملیاتی و مالی", "هشدار سررسید موجودی", AppScreen.ALERTS),
    NavigationDestination("گزارش‌های مدیریتی", "شاخص‌های کلیدی کسب‌وکار", "گزارش فروش سود موجودی", AppScreen.REPORTS),
    NavigationDestination("لاگ عملیات", "ردیابی تغییرات و حسابرسی", "لاگ حسابرسی عملیات", AppScreen.AUDIT_LOG),
    NavigationDestination("کاربران و پشتیبان", "امنیت، کاربران و نسخه پشتیبان", "کاربر امنیت بکاپ پشتیبان", AppScreen.SECURITY),
    NavigationDestination("تنظیمات برنامه", "ظاهر و تجربه کاربری", "تنظیمات ظاهر تم", AppScreen.SETTINGS),
)

@Composable
internal fun GlobalSearchScreen(
    currentUser: ir.sabou.inventory.domain.operations.AppUserRecord?,
    operations: OperationsUiState,
    accounting: AccountingUiState,
    personnel: PersonnelUiState,
    onOpen: (AppScreen) -> Unit,
    onOpenEntity: (AppScreen, String) -> Unit,
    onBack: () -> Unit,
) {
    var query by rememberSaveable { mutableStateOf("") }
    val allowed = navigationDestinations.filter { destination ->
        canOpenScreen(currentUser, destination.screen)
    }
    val normalized = query.trim()
    val destinations = if (normalized.isBlank()) allowed else allowed.filter {
        it.title.contains(normalized, ignoreCase = true) ||
            it.subtitle.contains(normalized, ignoreCase = true) ||
            it.keywords.contains(normalized, ignoreCase = true)
    }
    data class EntityResult(val group: String, val title: String, val subtitle: String, val screen: AppScreen, val key: String)
    val entityResults = if (normalized.length < 2) emptyList() else buildList {
        if (canOpenScreen(currentUser, AppScreen.INVENTORY)) operations.inventoryItems.filter {
            businessTextMatches(normalized, it.name, it.category)
        }.take(8).forEach { add(EntityResult("کالاها", it.name, "${it.category} · ${formatQuantity(it.stockMicros)} ${it.unit} · ${formatMoney(it.inventoryValueRial)}", AppScreen.INVENTORY, "item-${it.id}")) }
        if (canOpenScreen(currentUser, AppScreen.STOCK_MOVEMENTS)) operations.recentStockMovements.filter { movement ->
            val item = operations.inventoryItems.firstOrNull { it.id == movement.itemId }
            businessTextMatches(
                normalized,
                item?.name,
                movement.referenceType.storedValue,
                movement.notes,
                movement.movementType.storedValue,
            )
        }.take(8).forEach { movement ->
            val item = operations.inventoryItems.firstOrNull { it.id == movement.itemId }
            add(EntityResult("گردش موجودی", item?.name ?: "کالا #${movement.itemId}", "${stockMovementSearchTitle(movement.movementType)} · ${formatQuantity(movement.quantityDeltaMicros)} ${item?.unit.orEmpty()} · ${epochDayToPersian(movement.movementEpochDay).display()}", AppScreen.STOCK_MOVEMENTS, "movement-${movement.itemId}-${movement.id}"))
        }
        if (canOpenScreen(currentUser, AppScreen.PURCHASES)) operations.purchases.filter {
            businessTextMatches(normalized, it.invoiceNo, it.supplierName)
        }.take(8).forEach { add(EntityResult("فاکتورهای خرید", it.invoiceNo, "${it.supplierName} · مانده ${formatMoney(it.outstandingRial)}", AppScreen.PURCHASES, "purchase-${it.id}")) }
        if (canOpenScreen(currentUser, AppScreen.ACCOUNTING)) accounting.accounts.filter {
            businessTextMatches(normalized, it.code, it.name)
        }.take(8).forEach { add(EntityResult("حساب‌ها", "${it.code} — ${it.name}", "مانده بدهکار ${formatMoney(it.debitBalanceRial)} · بستانکار ${formatMoney(it.creditBalanceRial)}", AppScreen.ACCOUNTING, "account-${it.code}")) }
        if (canOpenScreen(currentUser, AppScreen.ACCOUNTING)) accounting.journals.filter {
            businessTextMatches(normalized, it.entryNo, it.description)
        }.take(8).forEach { add(EntityResult("اسناد حسابداری", it.entryNo, "${it.description} · ${formatMoney(it.totalDebitRial)}", AppScreen.ACCOUNTING, "journal-${it.id}")) }
        if (canOpenScreen(currentUser, AppScreen.PERSONNEL)) personnel.employees.filter {
            businessTextMatches(normalized, it.name, it.jobTitle, it.employeeCode)
        }.take(8).forEach { add(EntityResult("پرسنل", it.name, "${it.jobTitle} · ${if (it.isActive) "فعال" else "غیرفعال"}", AppScreen.PERSONNEL, "employee-${it.id}")) }
    }

    Scaffold(topBar = { ProfessionalTopBar("جست‌وجوی سراسری", "دسترسی سریع به همه بخش‌های مجاز", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نام بخش یا عملیات") },
                    placeholder = { Text("مثلاً انبار، حقوق یا سند") },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                )
            }
            item {
                Text(
                    if (query.isBlank()) "همه میان‌برها" else "${destinations.size + entityResults.size} نتیجه در بخش‌ها و داده‌ها",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (destinations.isEmpty() && entityResults.isEmpty()) {
                item { EmptyStatePanel("نتیجه‌ای پیدا نشد", "عبارت کوتاه‌تری وارد کنید یا نام بخش را تغییر دهید.") }
            } else {
                if (entityResults.isNotEmpty()) {
                    val grouped = entityResults.groupBy { it.group }
                    grouped.forEach { (group, groupResults) ->
                        item(key = "group-$group") { SectionHeading(group, "${groupResults.size} نتیجه مرتبط") }
                        items(groupResults, key = { it.key }) { result ->
                            Card(modifier = Modifier.fillMaxWidth().clickable { onOpenEntity(result.screen, result.key) }, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .25f))) {
                                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(result.title, fontWeight = FontWeight.ExtraBold)
                                    Text(result.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                if (destinations.isNotEmpty()) item { SectionHeading("میان‌برها", "بخش‌های مرتبط با عبارت جست‌وجو") }
                items(destinations, key = { "destination-${it.screen.name}" }) { destination ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(destination.screen) },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                androidx.compose.material3.Icon(
                                    Icons.Outlined.ArrowOutward,
                                    contentDescription = null,
                                    modifier = Modifier.padding(10.dp).size(20.dp),
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(destination.title, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(destination.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

private fun stockMovementSearchTitle(type: InventoryMovementType): String = when (type) {
    InventoryMovementType.PURCHASE,
    InventoryMovementType.GOODS_RECEIPT,
    -> "ورود خرید"
    InventoryMovementType.PURCHASE_RETURN,
    InventoryMovementType.PURCHASE_REVERSAL,
    -> "برگشت خرید"
    InventoryMovementType.DAILY_SALES_CONSUMPTION,
    InventoryMovementType.LEGACY_SALE_CONSUMPTION,
    -> "مصرف فروش"
    InventoryMovementType.DAILY_SALES_REVERSAL -> "برگشت مصرف فروش"
    InventoryMovementType.RECIPE_CONSUMPTION -> "مصرف رسپی"
    InventoryMovementType.PRODUCTION_OUTPUT -> "خروجی تولید"
    InventoryMovementType.WASTE -> "ضایعات"
    InventoryMovementType.INVENTORY_COUNT -> "اصلاح شمارش"
    InventoryMovementType.COUNT_VARIANCE -> "مغایرت شمارش"
    InventoryMovementType.INVENTORY_ADJUSTMENT -> "اصلاح موجودی"
    InventoryMovementType.TRANSFER_IN -> "انتقال ورودی"
    InventoryMovementType.TRANSFER_OUT -> "انتقال خروجی"
    InventoryMovementType.OPENING_BALANCE -> "مانده افتتاحیه"
    InventoryMovementType.REVERSAL -> "برگشت گردش"
    InventoryMovementType.LEGACY_UNKNOWN -> "گردش قدیمی ناشناخته"
}

@Composable
internal fun SettingsScreen(
    organizationName: String,
    onOrganizationNameChange: (String) -> Unit,
    themePreference: ThemePreference,
    currencyUnit: CurrencyUnit,
    fontScalePreference: FontScalePreference,
    backupPolicy: BackupPolicy,
    syncState: SyncUiState,
    onSaveSync: (String, String, Boolean, String, String) -> Unit,
    onRunSync: () -> Unit,
    onRequeueSync: () -> Unit,
    onResolveSyncIssue: (String, Boolean) -> Unit,
    onThemePreferenceChange: (ThemePreference) -> Unit,
    onCurrencyUnitChange: (CurrencyUnit) -> Unit,
    onFontScalePreferenceChange: (FontScalePreference) -> Unit,
    onBackupPolicyChange: (BackupPolicy) -> Unit,
    onFactoryReset: (String) -> Unit,
    sensitiveActionBusy: Boolean,
    sensitiveActionMessage: String?,
    onOpenSecurity: () -> Unit,
    showSensitiveSettings: Boolean,
    canFactoryReset: Boolean,
    onBack: () -> Unit,
) {
    var organizationNameDraft by remember(organizationName) { mutableStateOf(organizationName) }
    var showResetConfirmation by remember { mutableStateOf(false) }
    var selectedSection by remember { mutableStateOf(SettingsSection.GENERAL) }
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(syncState.message, sensitiveActionMessage) {
        (sensitiveActionMessage ?: syncState.message)?.let {
            snackbarHostState.showSnackbar(it, withDismissAction = true)
        }
    }
    Scaffold(
        topBar = { ProfessionalTopBar("تنظیمات برنامه", "ظاهر، امنیت و اطلاعات نسخه", onBack) },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 14.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                SettingsSectionSelector(selectedSection) { selectedSection = it }
            }
            if (selectedSection == SettingsSection.GENERAL) {
            item {
                BrandStatementCard(
                    title = "هویت مجموعه",
                    description = "نام رستوران، کافه یا مجموعه خود را وارد کنید تا در داشبورد، اعلان‌ها و چاپ‌ها نمایش داده شود.",
                )
            }
            item {
                FormSection("نام مجموعه", "اگر این قسمت خالی باشد، عنوان عمومی «مدیریت کافه رستوران» نمایش داده می‌شود") {
                    OutlinedTextField(
                        value = organizationNameDraft,
                        onValueChange = { organizationNameDraft = it.take(80) },
                        label = { Text("نام رستوران یا مجموعه") },
                        placeholder = { Text("مثلاً رستوران نمونه") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = { onOrganizationNameChange(organizationNameDraft.trim()) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("ذخیره نام مجموعه") }
                }
            }
            }
            if (selectedSection == SettingsSection.APPEARANCE) {
            item {
                FormSection("ظاهر برنامه", "انتخاب شما بلافاصله اعمال و روی دستگاه ذخیره می‌شود") {
                    ThemePreference.entries.forEach { preference ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onThemePreferenceChange(preference) },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (themePreference == preference) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            ),
                            border = BorderStroke(1.dp, if (themePreference == preference) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(preference.title, fontWeight = FontWeight.Bold)
                                    Text(preference.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (themePreference == preference) "●" else "○", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    Text("اندازه نوشته‌ها", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FontScalePreference.entries.forEach { preference ->
                            OutlinedButton(
                                onClick = { onFontScalePreferenceChange(preference) },
                                modifier = Modifier.weight(1f),
                            ) { Text(if (fontScalePreference == preference) "✓ ${preference.title}" else preference.title) }
                        }
                    }
                }
            }
            item {
                FormSection("واحد پول", "مبالغ در دیتابیس به‌صورت ریال ذخیره می‌شوند و فقط ورود و نمایش تغییر می‌کند") {
                    CurrencyUnit.entries.forEach { unit ->
                        OutlinedButton(
                            onClick = { onCurrencyUnitChange(unit) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (currencyUnit == unit) "✓ ${currencyUnitLabel(unit)}" else currencyUnitLabel(unit)) }
                    }
                }
            }
            }
            if (selectedSection == SettingsSection.DATA) {
            if (showSensitiveSettings) {
                item {
                    FormSection("پشتیبان‌گیری خودکار محلی", "نسخه‌های خودکار فقط داخل فضای برنامه روی همین دستگاه نگهداری می‌شوند") {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .5f))) {
                        Text(
                            "هشدار: خرابی، گم‌شدن یا بازنشانی گوشی می‌تواند دیتابیس و همه پشتیبان‌های محلی را هم‌زمان حذف کند. مرتب یک فایل رمزگذاری‌شده در مقصدی خارج از گوشی صادر کنید.",
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    AutomaticBackupFrequency.entries.forEach { frequency ->
                        OutlinedButton(
                            onClick = { onBackupPolicyChange(backupPolicy.copy(frequency = frequency)) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (backupPolicy.frequency == frequency) "✓ ${frequency.title}" else frequency.title) }
                    }
                    Text("حداکثر فایل‌های پشتیبان", fontWeight = FontWeight.Bold)
                    listOf(10, 25, 50, 100).chunked(2).forEach { rowCounts ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowCounts.forEach { count ->
                                OutlinedButton(
                                    onClick = { onBackupPolicyChange(backupPolicy.copy(maxFiles = count)) },
                                    modifier = Modifier.weight(1f),
                                ) { Text(if (backupPolicy.maxFiles == count) "✓ $count" else count.toString()) }
                            }
                        }
                    }
                    Text("صدور به Google Drive یا یک دستگاه دیگر از بخش کاربران و پشتیبان و با انتخاب مقصد انجام می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (showSensitiveSettings) {
                item { SyncHealthPanel(syncState) }
                item { SyncConfigurationPanel(syncState, onSaveSync, onRunSync, onRequeueSync, onResolveSyncIssue) }
            }
            item {
                FormSection("امنیت و داده‌ها", "مدیریت کاربران، پشتیبان‌گیری و بازیابی") {
                    TextButton(onClick = onOpenSecurity, modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.Icon(Icons.Outlined.Security, null, modifier = Modifier.size(20.dp))
                        Text("باز کردن کاربران و پشتیبان", modifier = Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold)
                    }
                    if (canFactoryReset) {
                        OutlinedButton(onClick = { showResetConfirmation = true }, enabled = !sensitiveActionBusy, modifier = Modifier.fillMaxWidth()) {
                            Text("بازنشانی کامل اطلاعات برنامه", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            }
            if (selectedSection == SettingsSection.GENERAL) {
            item {
                FormSection("درباره برنامه") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("نسخه")
                        Text(BuildConfig.VERSION_NAME, fontWeight = FontWeight.Bold)
                    }
                    Text("مدیریت کافه رستوران", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    Text("مدیریت یکپارچه خرید، فروش، انبار، حسابداری و عملیات مجموعه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
    if (showResetConfirmation) {
        SensitiveActionConfirmationDialog(
            title = "بازنشانی کامل برنامه",
            description = "همه اطلاعات، کاربران، تنظیمات اتصال و فایل‌های پشتیبان محلی پاک می‌شوند. این عملیات قابل بازگشت نیست.",
            confirmLabel = "پاک‌کردن همه اطلاعات",
            busy = sensitiveActionBusy,
            message = sensitiveActionMessage,
            onDismiss = { showResetConfirmation = false },
            onConfirm = { pin ->
                showResetConfirmation = false
                onFactoryReset(pin)
            },
        )
    }
}

@Composable
private fun SettingsSectionSelector(
    selected: SettingsSection,
    onSelected: (SettingsSection) -> Unit,
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            listOf(
                SettingsSection.GENERAL to "عمومی",
                SettingsSection.APPEARANCE to "ظاهر",
                SettingsSection.DATA to "داده و امنیت",
            ).forEach { (section, title) ->
                FilterChip(
                    selected = selected == section,
                    onClick = { onSelected(section) },
                    label = { Text(title, maxLines = 1) },
                    modifier = Modifier.weight(1f),
                )
            }
        }
    }
}

@Composable
private fun SyncConfigurationPanel(
    state: SyncUiState,
    onSave: (String, String, Boolean, String, String) -> Unit,
    onRun: () -> Unit,
    onRequeue: () -> Unit,
    onResolveIssue: (String, Boolean) -> Unit,
) {
    var endpoint by remember(state.config.endpoint) { mutableStateOf(state.config.endpoint) }
    var tenant by remember(state.config.tenantId) { mutableStateOf(state.config.tenantId) }
    var accessToken by remember(state.config.accessToken) { mutableStateOf(state.config.accessToken) }
    var refreshToken by remember(state.config.refreshToken) { mutableStateOf(state.config.refreshToken) }
    FormSection("همگام‌سازی آزمایشی", "این قابلیت تا تکمیل دریافت و اعمال دادهٔ سرور برای استفاده عملیاتی مسدود است") {
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .55f))) {
            Text(
                SyncSafetyGate.blockedReason,
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                color = MaterialTheme.colorScheme.onErrorContainer,
                style = MaterialTheme.typography.bodySmall,
            )
        }
        OutlinedTextField(endpoint, { endpoint = it }, label = { Text("نشانی سرویس") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(tenant, { tenant = it }, label = { Text("شناسه مجموعه") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            accessToken,
            { accessToken = it },
            label = { Text("Access token") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
        )
        OutlinedTextField(
            refreshToken,
            { refreshToken = it },
            label = { Text("Refresh token") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
        )
        Text("شناسه دستگاه: ${state.config.deviceId.ifBlank { "پس از ذخیره ساخته می‌شود" }}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("فعال‌سازی همگام‌سازی")
            Switch(checked = false, onCheckedChange = null, enabled = false)
        }
        Button(onClick = { onSave(endpoint, tenant, false, accessToken, refreshToken) }, modifier = Modifier.fillMaxWidth()) { Text("ذخیره تنظیمات غیرفعال") }
        OutlinedButton(onClick = onRun, enabled = false, modifier = Modifier.fillMaxWidth()) {
            Text(if (state.running) "در حال اجرا…" else "همگام‌سازی اکنون")
        }
        if (state.queue.deadLetters > 0) OutlinedButton(onClick = onRequeue, enabled = !state.running, modifier = Modifier.fillMaxWidth()) {
            Text("بازگردانی ${state.queue.deadLetters} پیام Dead-letter")
        }
        state.issues.forEach { issue ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = .45f))) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("${issue.entityType} #${issue.entityId}", fontWeight = FontWeight.Bold)
                    Text("وضعیت: ${issue.state.name} · بازبینی ${issue.revision}", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { onResolveIssue(issue.changeId, true) }, modifier = Modifier.fillMaxWidth()) { Text("نگهداری نسخه محلی در صف") }
                }
            }
        }
    }
}

@Composable
private fun SyncHealthPanel(state: SyncUiState) {
    val summary = state.summary
    val (title, color) = when (summary.health) {
        ir.sabou.inventory.domain.operations.SyncHealth.HEALTHY -> "همگام‌سازی سالم" to MaterialTheme.colorScheme.primary
        ir.sabou.inventory.domain.operations.SyncHealth.PENDING_WORK -> "تغییر در انتظار همگام‌سازی" to MaterialTheme.colorScheme.secondary
        ir.sabou.inventory.domain.operations.SyncHealth.NEEDS_ATTENTION -> "نیازمند بررسی تعارض" to MaterialTheme.colorScheme.error
    }
    FormSection("وضعیت همگام‌سازی", "پایش صف تغییرات آفلاین دستگاه") {
        StatusPill(title, containerColor = color.copy(alpha = .14f), contentColor = color)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CompactInfoRow("کل تغییرات", summary.total.toString())
            CompactInfoRow("در انتظار", summary.pending.toString())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CompactInfoRow("همگام‌شده", summary.synced.toString())
            CompactInfoRow("تعارض", summary.conflicts.toString())
        }
        if (state.queue.deadLetters > 0) CompactInfoRow("Dead-letter", state.queue.deadLetters.toString(), true)
    }
}
