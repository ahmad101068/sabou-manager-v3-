# Sabou Restaurant ERP 2.0

نسخه توسعه‌ای یک ERP محلی و فارسی برای عملیات رستوران، مبتنی بر Kotlin، Jetpack Compose،
Room، SQLCipher و WorkManager.

نسخه این بسته: `3.0.0-alpha159.0-inventory-2`

Schema پایگاه داده: `43`

> این نسخه Increment بازطراحی Inventory 2.0 روی Foundation تثبیت‌شده Alpha158 است؛ هنوز مجوز استفاده به‌عنوان
> تنها مرجع مالی یا موجودی Production را ندارد. Merge و انتشار فقط پس از سبزشدن کامل CI،
> Migration روی یک کپی واقعی و آزمون دستگاه مجاز است.

## مهم‌ترین تغییر این Increment

- Ledger تغییرناپذیر به‌عنوان مرجع تاریخی موجودی و projection بازسازی‌پذیر کالا/محل
- Item Master 2.0 با SKU یکتا، Barcode اصلی، نوع کالا، واحدهای تبدیل و Policyهای تأمین
- Location، Lot، Expiry و FEFO به‌عنوان مالکیت مستقیم دامنه Inventory
- انبارگردانی سندمحور با Blind Count، Recount، Approval، SoD و ثبت اتمیک مغایرت
- ضایعات نوع‌دار، هزینه‌محور، قابل‌تأیید و متصل به Accounting Posting Boundary
- انتقال سندمحور با Issue، In-Transit، Receive، Variance، idempotency و Audit
- Replenishment بر پایه available/on-order/in-transit/usage/lead-time/safety-stock
- Integrity checker برای Ledger/Projection/Lot/Location/Transfer و موجودی منفی
- Workspace تصمیم‌محور فارسی شامل کالا، انقضا، گردش، شمارش، ضایعات، انتقال و تأمین
- Permissionهای ریزدانه Inventory در Boundary سرویس‌ها؛ UI تنها لایه نمایش/سهولت است
- Migration حفظ‌داده `42 → 43` با MAIN location و opening reconciliation غیرتکراری
- Foundation Alpha158، SQLCipher، Accounting و Registry ترتیبی Migration حفظ شده‌اند

## ساخت و کنترل کیفیت

پیش‌نیازها: JDK 17، Android SDK 36 و دسترسی Gradle Wrapper به Gradle 8.13.

```bash
bash scripts/verify-foundation.sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
./gradlew --no-daemon assembleRelease
```

Workflow گیت‌هاب همین مراحل را روی API 23 و API 35 اجرا می‌کند. محیط تولید این بسته به
Android SDK و Gradle distribution دسترسی نداشت؛ بنابراین نتیجه Build/Test Gradle عمداً
ادعا نشده و CI مرجع نهایی است.

## مستندات ERP 2.0

- [ممیزی و Impact Map](docs/ERP2-AUDIT-IMPACT-MAP-FA.md)
- [معماری هدف](docs/ERP2-TARGET-ARCHITECTURE-FA.md)
- [مشخصات Migration 41→42](docs/ERP2-MIGRATION-41-42-FA.md)
- [گزارش فنی فازهای A تا K](docs/ERP2-TECHNICAL-REPORT-FA.md)
- [Impact Map تفکیک Data Boundary](docs/ERP2-ALPHA157-DATA-BOUNDARY-IMPACT-MAP-FA.md)
- [گزارش Alpha157 Data Boundary](docs/ERP2-ALPHA157-DATA-BOUNDARY-REPORT-FA.md)
- [Changelog Alpha157](CHANGELOG-alpha157-FA.md)
- [وضعیت Foundation Alpha158](docs/ARCHITECTURE-FOUNDATION-STATUS.md)
- [مرزهای دامنه](docs/DOMAIN-BOUNDARIES.md)
- [ماتریس یکپارچگی تراکنش](docs/TRANSACTION-INTEGRITY-MATRIX.md)
- [فهرست Typed Stateها](docs/TYPED-STATE-INVENTORY.md)
- [گزارش Verification Foundation](docs/FOUNDATION-VERIFICATION-REPORT.md)
- [Changelog Alpha158](CHANGELOG-alpha158-FA.md)
- [معماری Inventory 2.0](docs/INVENTORY-2-ARCHITECTURE.md)
- [طراحی Ledger](docs/INVENTORY-LEDGER-DESIGN.md)
- [ماتریس تراکنش Inventory](docs/INVENTORY-TRANSACTION-MATRIX.md)
- [گزارش Migration Inventory](docs/INVENTORY-MIGRATION-REPORT.md)
- [گزارش تست Inventory](docs/INVENTORY-TEST-REPORT.md)
- [نقشه UX انبار](docs/INVENTORY-UX-MAP.md)
- [Changelog Alpha159](CHANGELOG-alpha159-INVENTORY-2-FA.md)
- [Roadmap باقی‌مانده](docs/ERP2-REMAINING-ROADMAP-FA.md)
- [وضعیت جاری](STATUS-FA.md)

## مرز ادعا

فروش تجمیعی روزانه، خرید، انبار، رسپی، حسابداری، پرسنل/حقوق، دارایی، امنیت و پشتیبان در
سورس موجودند. POS سفارش‌محور کامل، KDS، Production/WIP، Treasury عملیاتی مستقل، Sync
دوطرفه و حل تعارض چندشعبه‌ای هنوز Done نیستند و وجود مدل یا Screen جای پیاده‌سازی واقعی را
نمی‌گیرد. Sync تا تکمیل protocol همچنان fail-closed باقی می‌ماند.
