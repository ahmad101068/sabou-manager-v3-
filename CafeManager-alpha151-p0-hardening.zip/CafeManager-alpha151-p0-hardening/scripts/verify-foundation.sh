#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

required_files=(
  "app/src/main/AndroidManifest.xml"
  "app/src/main/java/ir/sabou/inventory/core/MoneyRial.kt"
  "app/src/main/java/ir/sabou/inventory/core/QuantityMicros.kt"
  "app/src/main/java/ir/sabou/inventory/core/SignedLongMath.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/JournalIntegrity.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/DailySalesEntities.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/DailySalesDao.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalAccountingRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/security/DatabaseKeyProvider.kt"
  "app/src/main/java/ir/sabou/inventory/data/security/PortableBackupCodec.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/InventoryClosingEntities.kt"
  "app/src/main/java/ir/sabou/inventory/domain/operations/InventoryPeriodCalculator.kt"
  "app/src/main/java/ir/sabou/inventory/domain/accounting/AccountingModels.kt"
  "app/src/main/java/ir/sabou/inventory/ui/AccountingScreens.kt"
  "app/src/main/java/ir/sabou/inventory/ui/AccountingViewModel.kt"
  "app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
  "app/src/main/java/ir/sabou/inventory/ui/PurchaseManagementDialogs.kt"
  "app/src/main/java/ir/sabou/inventory/ui/PersianDate.kt"
  "app/src/main/java/ir/sabou/inventory/ui/AssetListKeys.kt"
  "app/src/main/java/ir/sabou/inventory/ui/ModuleListKeys.kt"
  "app/src/main/java/ir/sabou/inventory/ui/ClockInput.kt"
  "app/src/main/java/ir/sabou/inventory/ui/InputParsers.kt"
  "app/src/main/java/ir/sabou/inventory/OrganizationIdentity.kt"
  "app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
  "app/src/test/java/ir/sabou/inventory/core/MoneyRialTest.kt"
  "app/src/test/java/ir/sabou/inventory/core/SignedLongMathTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/accounting/AccountingModelsTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/PurchaseManagementTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/ProcurementModelsTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/SupplierPerformanceTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/ReplenishmentPlannerTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/SupplierSourcingAdvisorTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/SupplierOrderSplitterTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/PurchaseOrderDispatchTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/PersonnelListKeysTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/AssetListKeysTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/ModuleListKeysTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/ClockInputTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/InputParsersTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/AppScreenAccessTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/operations/SyncModelsTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/personnel/EmployeeDraftTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/sales/DailySalesModelsTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/personnel/AdvanceDeductionAllocatorTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/personnel/AttendancePayrollCalculatorTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/personnel/PayrollReversalDraftTest.kt"
  "app/src/test/java/ir/sabou/inventory/data/security/PortableBackupCodecTest.kt"
  "app/src/test/java/ir/sabou/inventory/data/db/JournalIntegrityTest.kt"
  "app/src/test/java/ir/sabou/inventory/data/db/MigrationChainContractTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/operations/InventoryPeriodCalculatorTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/operations/InventoryPeriodClosureDetailsTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/operations/ControlledReopenDraftTest.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/db/ControlledReopenMigration35To36Test.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/PurchaseApprovalPolicyTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/control/EnterpriseControlDraftsTest.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/db/EnterpriseControlsMigration36To37Test.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/db/JournalGuardsMigration37To38Test.kt"
  "app/src/androidTest/java/ir/sabou/inventory/data/db/FullMigration1To38Test.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/SyncTokenRefresher.kt"
  "app/src/test/java/ir/sabou/inventory/OrganizationIdentityTest.kt"
)

for relative in "${required_files[@]}"; do
  test -s "$ROOT/$relative"
done

rg -q 'android:allowBackup="false"' "$ROOT/app/src/main/AndroidManifest.xml"
rg -q 'android:usesCleartextTraffic="false"' "$ROOT/app/src/main/AndroidManifest.xml"
rg -q 'android.permission.INTERNET' "$ROOT/app/src/main/AndroidManifest.xml"
rg -q 'HttpsSyncTransport' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -q 'applicationId = "ir.sabou.inventory"' "$ROOT/app/build.gradle.kts"
rg -q 'minSdk = 23' "$ROOT/app/build.gradle.kts"
rg -q 'SupportOpenHelperFactory' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'version = 38' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -Fq 'versionCode = 184' "$ROOT/app/build.gradle.kts"
rg -Fq 'versionName = "3.0.0-alpha151-p0-hardening"' "$ROOT/app/build.gradle.kts"
test "$(rg -c '^import androidx.room.ColumnInfo$' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/DailySalesEntities.kt")" -eq 1
rg -Fq '.statusBarsPadding()' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/DesignComponents.kt"
rg -Fq '.statusBarsPadding()' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'isAppearanceLightStatusBars = false' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/theme/Theme.kt"
rg -Fq 'SnackbarHost(snackbarHostState)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'SnackbarHost(snackbarHostState)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'SecuritySectionSelector(' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'SettingsSectionSelector(' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -q 'MIGRATION_30_31' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_31_32' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_32_33' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_33_34' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_34_35' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_35_36' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_36_37' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_37_38' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'installJournalLineGuards' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'PurchaseApprovalPolicy' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'budget_commitments' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'prevent_closed_accounting_insert' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'PENDING_APPROVAL' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
rg -q 'access_token_protected' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -q 'Authorization.*Bearer' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/HttpsSyncTransport.kt"
rg -q 'requireOwner' "$ROOT/app/src/main/java/ir/sabou/inventory/data/security/SessionAuthorizer.kt"
rg -q 'reopenInventoryPeriod' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
rg -q 'reopenDay' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt"
rg -q 'DEAD_LETTER' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/SyncModels.kt"
rg -q 'idempotencyKey' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/SyncEntities.kt"
rg -q 'prevent_closed_inventory_movement_insert' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'prevent_closed_sales_day_update' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'prevent_closed_sales_line_update' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'prevent_closed_sales_stock_update' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'PAYROLL_REVERSAL' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
rg -q 'printInventoryPeriodClosure' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt"
rg -q 'attendanceDayLocked' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -q 'attendanceRangeLocked' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt"
rg -q 'payroll_advance_allocations' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'INVENTORY_COUNT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/ManagementControlDao.kt"
rg -q 'ManagementControlScreen' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -q 'MIGRATION_16_17' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_17_18' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_18_19' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_19_20' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_20_21' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_21_22' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_22_23' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_23_24' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_24_25' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_25_26' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_26_27' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_27_28' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_28_29' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'ThreeWayMatchStatus' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'GOODS_RECEIPT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt"
rg -q 'PURCHASE_RETURN' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt"
rg -q 'SupplierScorecard' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'ReplenishmentPlanner' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'SupplierSourcingAdvisor' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'SupplierOrderSplitter' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'PurchaseOrderAcknowledgementDraft' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'fun printPurchaseOrder' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt"
rg -q 'SyncPayloadCodec.sha256' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/SyncRecorder.kt"
rg -q 'suspend fun maxRevision' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/SyncDao.kt"
rg -q 'createInMemory' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/repository/SecurityIntegrationTest.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/repository/AssetOutboxIntegrationTest.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/BackupManagerDeleteTest.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/RestaurantOperationsMigration18To19Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/CoreIdentityMigration19To20Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/AssetQuantityMigration20To21Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/TableOrdersMigration21To22Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/RestaurantSettlementMigration22To23Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/ReplenishmentMigration25To26Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/SupplierCatalogMigration26To27Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/SupplierSplitMigration27To28Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/OrderDispatchMigration28To29Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/DailySalesMigration30To31Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/DailySalesMigration31To32Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/PayrollAdvanceMigration32To33Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/AdvancedControlsMigration33To34Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/FinancialClosuresMigration34To35Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/repository/DailySalesReversalIntegrationTest.kt"
test -s "$ROOT/app/src/test/java/ir/sabou/inventory/domain/operations/AccessPolicyTest.kt"
rg -q 'connectedDebugAndroidTest' "$ROOT/.github/workflows/build-apk.yml"
rg -q 'api-level: 23' "$ROOT/.github/workflows/build-apk.yml"
rg -q 'CURRENT_ALGORITHM = "PBKDF2WithHmacSHA1"' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSecurityRepository.kt"
rg -q 'SessionAuthorizer' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -q 'SyncChangeType.DISPOSE' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalAssetRepository.kt"
rg -q 'SyncChangeClassifier.classify' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/SyncRecorder.kt"
rg -Fq '"action" to normalizedAction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/SyncRecorder.kt"
rg -q 'suspend fun reverse' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/sales/DailySalesModels.kt"
rg -q 'DAILY_SALES_REVERSAL' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt"
rg -q 'observeProfitLoss' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -q 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalAssetRepository.kt"
rg -q 'cipher_integrity_check' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'testImplementation(kotlin("test"))' "$ROOT/app/build.gradle.kts"
rg -Fq 'return name' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'fun exportPortable(name: String, password: CharArray, destination: OutputStream)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'fun importPortable(source: InputStream, password: CharArray)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'ActivityResultContracts.CreateDocument' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'import androidx.compose.runtime.LaunchedEffect' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'fun initialize()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'withContext(Dispatchers.IO)' "$ROOT/app/src/main/java/ir/sabou/inventory/MainActivity.kt"
rg -Fq 'StartupFailure(' "$ROOT/app/src/main/java/ir/sabou/inventory/MainActivity.kt"
rg -Fq 'Build.VERSION.SDK_INT >= Build.VERSION_CODES.O' "$ROOT/app/src/main/java/ir/sabou/inventory/AlertRefreshWorker.kt"
if rg -n 'java\.time\.' "$ROOT/app/src/main/java"; then
  echo "java.time بدون desugaring در کد سازگار با API 23 باقی مانده است." >&2
  exit 1
fi
rg -Fq 'mutableStateOf(listOf(AppScreen.SECURITY.name))' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'require(integrityErrors.isEmpty())' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'if (bootstrap)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSecurityRepository.kt"
rg -Fq 'AppSessionEntity(currentUserId = savedId' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSecurityRepository.kt"
rg -Fq 'suspend fun logout()' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/SecurityModels.kt"
rg -Fq 'suspend fun clearSession()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'canOpenScreen(securityState.currentUser, target)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'DailySalesScreen' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'DAILY_SALES_CONSUMPTION' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt"
rg -Fq 'sourceType = "DAILY_SALES"' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt"
rg -Fq 'ORDER BY salesRial DESC' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/DailySalesDao.kt"
rg -Fq '"customers",' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -Fq '"restaurant_tables",' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
if rg -n 'abstract fun (salesDao|crmDao|restaurantOperationsDao)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"; then
  echo "DAO یکی از ماژول‌های حذف‌شده دوباره فعال شده است." >&2
  exit 1
fi
if rg -n 'AppScreen\.(CRM|RESTAURANT_OPERATIONS)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui"; then
  echo "ماژول مشتری یا عملیات رستوران دوباره وارد ناوبری شده است." >&2
  exit 1
fi
rg -Fq 'personnelEmployeeListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'personnelPayrollListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'assetRecordListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'assetDepreciationListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'label = { Text("تعداد") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'Text("ویرایش")' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
if rg -n 'items\(state\.(employees|payrolls), key = \{ it\.id \}\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"; then
  echo "کلید خام و مشترک پرسنل/حقوق دوباره وارد فهرست شده است." >&2
  exit 1
fi
if rg -n 'items\(state\.(assets|depreciations), key = \{ it\.id \}\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"; then
  echo "کلید خام و مشترک دارایی/استهلاک دوباره وارد فهرست شده است." >&2
  exit 1
fi
if rg -n '\bnow\.toEpochDay\(\)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"; then
  echo "ارجاع حذف‌شده now در فرم حقوق باقی مانده است." >&2
  exit 1
fi
rg -Fq 'screen == AppScreen.DASHBOARD || routeStack.size == 1' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"

if rg -Fq 'cursor.moveToFirst() && cursor.getString(0).equals("ok"' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"; then
  echo "تفسیر قدیمی و نادرست cipher_integrity_check باقی مانده است." >&2
  exit 1
fi

if rg -n '\b(OperationGuard|Permission\.MANAGE_)\b' "$ROOT/app/src"; then
  echo "ارجاع به مدل مجوز حذف‌شده در سورس باقی مانده است." >&2
  exit 1
fi

if rg -n 'payloadHash\s*=\s*"local-' "$ROOT/app/src/main"; then
  echo "هش ساختگی payload وارد outbox شده است." >&2
  exit 1
fi
rg -q 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -q 'BalancedJournalDraft' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -Fq 'fun observeSearch(query: String)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'fun observeLowStock()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'PersianDatePickerDialog' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Uq 'internal fun PersianDateField\(\n[[:space:]]*label: String,\n[[:space:]]*epochDay: Long,\n[[:space:]]*onSelected: \(Long\) -> Unit,\n\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Fq 'OptionalPersianDateField' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Fq 'printPayrollSlip' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'printJournal' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AccountingScreens.kt"
rg -Fq 'printManagementSummary' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportsScreens.kt"
rg -Fq 'backupToDrive' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityViewModel.kt"
rg -Fq 'CreateDocument("application/octet-stream")' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'fun delete(name: String)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'onDeleteBackup = security::deleteBackup' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'Text("حذف این نسخه"' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'suspend fun resetPinWithRecovery' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/SecurityModels.kt"
rg -Fq 'رمز را فراموش کرده‌ام' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'recoveryCodeHash TEXT NOT NULL DEFAULT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -Fq 'val fatherName: String' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/personnel/PersonnelModels.kt"
rg -Fq 'label = { Text("نام پدر") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'ClockField(checkIn' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'ClockField(checkOut' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'fun formatMoneyInput' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/InputParsers.kt"
rg -Fq 'onValueChange = { amount = formatMoneyInput(it) }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PurchaseManagementDialogs.kt"
rg -Fq 'label = { Text("نام رستوران یا مجموعه") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'FormSection("واحد پول"' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'FormSection("پشتیبان‌گیری خودکار محلی"' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'SyncSafetyGate.requireProductionReady()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'FontScalePreference.entries' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'import androidx.compose.material3.AlertDialog' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'AutomaticBackupWorker' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupScheduling.kt"
rg -Fq 'suspend fun factoryReset()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'مجموع حقوق پرداخت‌شده' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'val employeeCode: String?' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/personnel/PersonnelModels.kt"
rg -Fq 'label = { Text("شماره کارت بانکی (۱۶ رقم)") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'AutoClearMessage(operationsState.message' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'organizationDisplayTitle(organizationName)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'applicationContext.organizationDisplayName()' "$ROOT/app/src/main/java/ir/sabou/inventory/AlertRefreshWorker.kt"
rg -Fq 'context.organizationDisplayName().html()' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt"
if rg -n 'SABOU  ·|خروج از سابو|کاربر سابو|هویت سابو|سابو منیجر|سبو مدیر' \
  "$ROOT/app/src/main"; then
  echo "نام تجاری قبلی دوباره وارد رابط کاربری شده است." >&2
  exit 1
fi
if rg -n 'Text\("(روز سیستم|روز فروش|از روز|تا روز|تاریخ تولد \(روز عددی\)|تاریخ استخدام \(روز عددی\))"' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui"; then
  echo "ورودی تاریخ عددی قدیمی دوباره وارد رابط شده است." >&2
  exit 1
fi
rg -Fq 'PurchasePaymentMethod.TRANSFER' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Fq 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
rg -Fq 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalAccountingRepository.kt"
rg -Fq 'fun observeJournals(query: String)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'fun observeJournalDetails(entryId: Long)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'fun observeAccountBalances()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'suspend fun reverseManual' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/accounting/AccountingModels.kt"
rg -Fq 'AppScreen.ACCOUNTING' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'suspend fun settle' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/PurchaseModels.kt"
rg -Fq 'suspend fun reverse' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/PurchaseModels.kt"
rg -Fq 'PURCHASE_SETTLEMENT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -Fq 'PURCHASE_REVERSAL' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -Fq 'expectedPaidRial' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'suspend fun saleConsumptions(saleId: Long)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"

if rg -n 'DELETE FROM (journal_entries|journal_lines)' "$ROOT/app/src/main"; then
  echo "حذف مستقیم اسناد مالی ممنوع است." >&2
  exit 1
fi

if rg -n '\b(Double|Float)\b' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/core" \
  "$ROOT/app/src/main/java/ir/sabou/inventory/domain"; then
  echo "نوع اعشاری وارد هسته مالی شده است." >&2
  exit 1
fi

if rg -n 'Math\.(addExact|subtractExact|multiplyExact|negateExact)' \
  "$ROOT/app/src/main/java"; then
  echo "توابع عددی ناسازگار با Android API 23 وارد کد شده‌اند." >&2
  exit 1
fi

if rg -n 'fallbackToDestructiveMigration' "$ROOT/app/src/main"; then
  echo "مهاجرت تخریبی خودکار ممنوع است." >&2
  exit 1
fi

echo "Cafe Restaurant Manager foundation checks passed."
