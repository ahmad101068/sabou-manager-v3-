package ir.sabou.inventory.domain.operations

/**
 * Production sync is deliberately fail-closed until the protocol supports a
 * full push/pull cycle and applies remote entity payloads transactionally.
 *
 * The outbox remains available as a durable change log, but it must not be
 * presented as a completed multi-device replication feature.
 */
object SyncSafetyGate {
    const val isProductionReady: Boolean = false
    const val blockedReason: String =
        "همگام‌سازی چنددستگاهی این نسخه آزمایشی است و تا تکمیل دریافت و اعمال امن داده‌های سرور غیرفعال می‌ماند."

    fun requireProductionReady() {
        check(isProductionReady) { blockedReason }
    }
}

data class CloudSyncConfig(val endpoint: String, val tenantId: String, val enabled: Boolean = false, val accessToken: String = "", val refreshToken: String = "", val accessTokenExpiresAtEpochMillis: Long = 0, val deviceId: String = "") {
    val accessTokenExpired: Boolean get() = accessTokenExpiresAtEpochMillis <= System.currentTimeMillis() + 30_000L
    fun validated(): CloudSyncConfig { require(endpoint.startsWith("https://")); require(tenantId.isNotBlank()); require(deviceId.isNotBlank()); require(accessToken.isNotBlank() && !accessTokenExpired) { "توکن دسترسی Sync معتبر یا فعال نیست." }; return this }
}
