package ir.sabou.inventory.data

import android.content.Context
import android.system.Os
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.security.DatabaseKeyProvider
import ir.sabou.inventory.data.security.PortableBackupCodec
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.security.MessageDigest
import java.util.Date
import java.util.Locale

class BackupManager(
    private val context: Context,
    private val keyProvider: DatabaseKeyProvider = DatabaseKeyProvider(context),
) {
    private val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("backup_state", Context.MODE_PRIVATE)

    fun applyPendingRestore() {
        val pending = prefs.getString("pending_restore", null) ?: return
        val source = resolveBackup(pending)
        if (source.isFile) {
            require(verify(pending)) { "فایل پشتیبان ناقص است یا اثرانگشت آن مطابقت ندارد." }
            if (prefs.getString("restore_database_applied", null) != pending) {
                context.getDatabasePath("sabou_manager_v3.db").also { target ->
                    target.parentFile?.mkdirs()
                    val staged = File(target.parentFile, "${target.name}.restore")
                    source.copyTo(staged, overwrite = true)
                    require(staged.length() == source.length()) { "کپی فایل پشتیبان کامل نشد." }
                    if (target.exists() && prefs.getString("last_restore_recovery", null) == null) {
                        val recovery = File(backupDir, "pre-restore-${System.currentTimeMillis()}.db")
                        target.copyTo(recovery, overwrite = false)
                        writeChecksum(recovery)
                        keyFile(recovery).writeText(keyProvider.protectPassphrase(keyProvider.getOrCreatePassphrase()))
                        check(prefs.edit().putString("last_restore_recovery", recovery.name).commit()) {
                            "ثبت نسخه ایمنی سازگار با بازیابی قدیمی انجام نشد."
                        }
                    }
                    replaceDatabaseAtomically(staged, target)
                }
                context.getDatabasePath("sabou_manager_v3.db-wal").delete()
                context.getDatabasePath("sabou_manager_v3.db-shm").delete()
                check(prefs.edit().putString("restore_database_applied", pending).commit()) {
                    "ثبت وضعیت بازیابی انجام نشد."
                }
            }
            keyProvider.activateStagedRestorePassphrase()
        }
        check(prefs.edit().remove("pending_restore").commit()) { "نهایی‌سازی برنامه بازیابی انجام نشد." }
    }

    fun create(database: AppDatabase): String {
        val name = "restaurant-manager-backup-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}-${System.currentTimeMillis() % 1_000L}.db"
        val source = context.getDatabasePath("sabou_manager_v3.db")
        val destination = File(backupDir, name)
        database.openHelper.writableDatabase.execSQL("VACUUM INTO ?", arrayOf(destination.absolutePath))
        require(destination.length() >= MIN_DATABASE_BYTES && source.length() >= MIN_DATABASE_BYTES) {
            destination.delete()
            "ساخت نسخه پشتیبان کامل نشد."
        }
        writeChecksum(destination)
        keyFile(destination).writeText(keyProvider.protectPassphrase(keyProvider.getOrCreatePassphrase()))
        return name
    }

    fun markRestoreValidated() {
        prefs.getString("last_restore_recovery", null)?.let { name ->
            runCatching { resolveBackup(name) }.getOrNull()?.let { recovery ->
                checksumFile(recovery).delete()
                keyFile(recovery).delete()
                recovery.delete()
            }
        }
        check(prefs.edit().remove("last_restore_recovery").remove("restore_database_applied").commit()) {
            "پاک‌سازی وضعیت بازیابی انجام نشد."
        }
        keyProvider.commitRestorePassphrase()
    }

    fun rollbackLastRestore(): Boolean {
        val recoveryName = prefs.getString("last_restore_recovery", null) ?: return false
        val recovery = resolveBackup(recoveryName)
        val target = context.getDatabasePath("sabou_manager_v3.db")
        if (!recovery.isFile || !verify(recoveryName)) return false
        val staged = File(target.parentFile, "${target.name}.rollback")
        recovery.copyTo(staged, overwrite = true)
        require(staged.length() == recovery.length()) { "آماده‌سازی بازگشت بازیابی کامل نشد." }
        replaceDatabaseAtomically(staged, target)
        context.getDatabasePath("sabou_manager_v3.db-wal").delete()
        context.getDatabasePath("sabou_manager_v3.db-shm").delete()
        keyProvider.rollbackRestorePassphrase()
        prefs.edit().remove("last_restore_recovery").remove("restore_database_applied").remove("pending_restore").commit()
        checksumFile(recovery).delete()
        keyFile(recovery).delete()
        recovery.delete()
        return true
    }

    fun list(): List<String> {
        val protectedRecovery = prefs.getString("last_restore_recovery", null)
        return backupDir.listFiles()
            ?.filter { it.isFile && it.extension == "db" && it.name != protectedRecovery && !it.name.startsWith("pre-restore-") }
            ?.sortedByDescending { it.lastModified() }
            ?.map { it.name }
            .orEmpty()
    }

    fun describe(): List<BackupDescriptor> = backupDir.listFiles().orEmpty()
        .filter { it.isFile && it.extension == "db" }
        .sortedByDescending { it.lastModified() }
        .map { BackupDescriptor(it.name, it.length(), it.lastModified(), verify(it.name)) }

    fun verify(name: String): Boolean {
        val source = resolveBackup(name)
        if (!source.isFile || source.length() < MIN_DATABASE_BYTES || source.length() % DATABASE_PAGE_BYTES != 0L) return false
        val checksum = checksumFile(source)
        if (!checksum.isFile || !keyFile(source).isFile) return false
        val expected = checksum.readText().trim()
        return expected.matches(Regex("[0-9a-f]{64}")) && expected == sha256(source)
    }

    fun prune(maxFiles: Int) {
        val keep = maxFiles.coerceIn(1, 200)
        val protectedNames = setOfNotNull(
            prefs.getString("pending_restore", null),
            prefs.getString("last_restore_recovery", null),
        )
        backupDir.listFiles()
            .orEmpty()
            .filter { it.isFile && it.extension == "db" && it.name !in protectedNames && !it.name.startsWith("pre-restore-") }
            .sortedByDescending { it.lastModified() }
            .drop(keep)
            .forEach { file -> checksumFile(file).delete(); keyFile(file).delete(); file.delete() }
    }

    fun clearAll() {
        backupDir.listFiles().orEmpty().filter { it.isFile }.forEach { it.delete() }
        check(prefs.edit().clear().commit()) { "پاک‌سازی وضعیت پشتیبان انجام نشد." }
    }

    fun delete(name: String) {
        require(prefs.getString("pending_restore", null) != name) {
            "نسخه انتخاب‌شده برای بازیابی تا پایان یا لغو بازیابی قابل حذف نیست."
        }
        require(prefs.getString("last_restore_recovery", null) != name) {
            "نسخه ایمنی قبل از بازیابی تا پایان بازیابی قابل حذف نیست."
        }
        val backup = resolveBackup(name)
        require(backup.isFile) { "فایل پشتیبان پیدا نشد." }
        checksumFile(backup).delete()
        keyFile(backup).delete()
        check(backup.delete()) { "حذف فایل پشتیبان انجام نشد." }
    }

    fun exportPortable(name: String, password: CharArray, destination: OutputStream): Long {
        val source = resolveBackup(name)
        require(verify(name)) { "فایل پشتیبان معتبر نیست یا اثرانگشت آن مطابقت ندارد." }
        val passphrase = keyFile(source).takeIf(File::isFile)?.readText()?.let(keyProvider::unprotectPassphrase)
            ?: keyProvider.getOrCreatePassphrase()
        return try {
            source.inputStream().use { input -> PortableBackupCodec.encrypt(passphrase, input, password, destination) }
                .also { require(it == source.length()) { "صدور فایل پشتیبان کامل نشد." } }
                .also {
                    check(prefs.edit().putLong(KEY_LAST_PORTABLE_EXPORT_AT, System.currentTimeMillis()).commit()) {
                        "ثبت زمان صدور پشتیبان انجام نشد."
                    }
                }
        } finally {
            passphrase.fill(0)
            password.fill('\u0000')
        }
    }

    fun importPortable(source: InputStream, password: CharArray): String {
        val timestamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "restaurant-manager-import-$timestamp-${System.currentTimeMillis() % 1_000L}.db"
        val staged = File(backupDir, "$name.import")
        val destination = File(backupDir, name)
        var restoredPassphrase: ByteArray? = null
        try {
            restoredPassphrase = source.use { input -> staged.outputStream().use { output -> PortableBackupCodec.decrypt(input, password, output) } }
            require(staged.length() >= MIN_DATABASE_BYTES && staged.length() % DATABASE_PAGE_BYTES == 0L) {
                "فایل انتخاب‌شده ساختار قابل‌قبول پشتیبان را ندارد."
            }
            require(staged.renameTo(destination)) { "ذخیره فایل واردشده انجام نشد." }
            writeChecksum(destination)
            keyFile(destination).writeText(keyProvider.protectPassphrase(requireNotNull(restoredPassphrase)))
            return name
        } catch (error: Throwable) {
            staged.delete()
            destination.delete()
            checksumFile(destination).delete()
            keyFile(destination).delete()
            throw error
        } finally {
            restoredPassphrase?.fill(0)
            password.fill('\u0000')
        }
    }

    fun scheduleRestore(name: String, recoveryName: String) {
        require(verify(name)) { "فایل پشتیبان معتبر نیست یا تغییر کرده است." }
        require(name != recoveryName && verify(recoveryName)) { "نسخه ایمنی قبل از بازیابی معتبر نیست." }
        val backup = resolveBackup(name)
        val protectedKey = keyFile(backup).takeIf(File::isFile)?.readText()
            ?: error("کلید این نسخه پشتیبان موجود نیست؛ آن را دوباره از فایل قابل‌انتقال وارد کنید.")
        val passphrase = keyProvider.unprotectPassphrase(protectedKey)
        try {
            keyProvider.stageRestorePassphrase(passphrase)
        } finally {
            passphrase.fill(0)
        }
        check(
            prefs.edit()
                .putString("pending_restore", name)
                .putString("last_restore_recovery", recoveryName)
                .commit(),
        ) { "زمان‌بندی بازیابی انجام نشد." }
    }

    fun lastPortableExportAtEpochMillis(): Long = prefs.getLong(KEY_LAST_PORTABLE_EXPORT_AT, 0L)

    private fun writeChecksum(file: File) {
        checksumFile(file).writeText(sha256(file))
    }

    private fun checksumFile(file: File) = File(file.parentFile, "${file.name}.sha256")
    private fun keyFile(file: File) = File(file.parentFile, "${file.name}.key")

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun resolveBackup(name: String): File {
        require(name == File(name).name && name.endsWith(".db")) { "نام فایل پشتیبان معتبر نیست." }
        val candidate = File(backupDir, name).canonicalFile
        require(candidate.parentFile == backupDir.canonicalFile) { "مسیر فایل پشتیبان معتبر نیست." }
        return candidate
    }

    private fun replaceDatabaseAtomically(staged: File, target: File) {
        require(staged.parentFile?.canonicalFile == target.parentFile?.canonicalFile) {
            "فایل مرحله‌ای بازیابی باید کنار پایگاه داده باشد."
        }
        try {
            // POSIX rename replaces the destination atomically on the same
            // filesystem. A partial database is never exposed to the app.
            Os.rename(staged.absolutePath, target.absolutePath)
        } catch (error: Throwable) {
            staged.delete()
            throw IllegalStateException("جایگزینی اتمی پایگاه داده انجام نشد.", error)
        }
    }

    private companion object {
        const val MIN_DATABASE_BYTES = 4_096L
        const val DATABASE_PAGE_BYTES = 4_096L
        const val KEY_LAST_PORTABLE_EXPORT_AT = "last_portable_export_at"
    }
}

data class BackupDescriptor(val name: String, val sizeBytes: Long, val modifiedAtEpochMillis: Long, val integrityVerified: Boolean)
