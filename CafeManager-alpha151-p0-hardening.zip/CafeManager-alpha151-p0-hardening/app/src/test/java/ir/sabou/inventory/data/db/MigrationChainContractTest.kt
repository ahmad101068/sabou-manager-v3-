package ir.sabou.inventory.data.db

import kotlin.test.Test
import kotlin.test.assertEquals

class MigrationChainContractTest {
    @Test
    fun declaresEverySequentialUpgradeFromOneToCurrentVersion() {
        val edges = ALL_MIGRATIONS.map { it.startVersion to it.endVersion }
        assertEquals((1 until 38).map { it to it + 1 }, edges)
    }
}
