package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class TableOrderRulesTest {
    private val order = TableOrder(
        id = 1,
        orderNo = "M-1",
        tableId = 2,
        tableLabel = "۲",
        guestCount = 2,
        waiterName = "گارسون",
        customerId = 9,
        customerName = "مشتری",
        status = TableOrderStatus.OPEN,
        openedAtEpochMillis = 1,
        notes = "",
        lines = listOf(TableOrderLine(1, 3, "قهوه", QuantityMicros.parse("2"), MoneyRial.of(100_000))),
    )

    @Test
    fun supportsSplitPaymentAndServiceCharge() {
        val total = TableOrderRules.validateCheckout(
            order,
            TableCheckoutDraft(
                discount = MoneyRial.of(20_000),
                serviceCharge = MoneyRial.of(10_000),
                payments = listOf(
                    SalePaymentAllocation(SalePaymentMethod.CASH, MoneyRial.of(50_000)),
                    SalePaymentAllocation(SalePaymentMethod.CARD, MoneyRial.of(140_000)),
                ),
                saleEpochDay = 100,
            ),
        )
        assertEquals(190_000, total.value)
    }

    @Test
    fun rejectsOverpayment() {
        assertFailsWith<IllegalArgumentException> {
            TableOrderRules.validateCheckout(
                order,
                TableCheckoutDraft(
                    payments = listOf(SalePaymentAllocation(SalePaymentMethod.CASH, MoneyRial.of(200_001))),
                    saleEpochDay = 100,
                ),
            )
        }
    }

    @Test
    fun requiresDueDateForOutstandingBalance() {
        assertFailsWith<IllegalArgumentException> {
            TableOrderRules.validateCheckout(
                order,
                TableCheckoutDraft(
                    payments = listOf(SalePaymentAllocation(SalePaymentMethod.CARD, MoneyRial.of(100_000))),
                    saleEpochDay = 100,
                ),
            )
        }
    }
}
