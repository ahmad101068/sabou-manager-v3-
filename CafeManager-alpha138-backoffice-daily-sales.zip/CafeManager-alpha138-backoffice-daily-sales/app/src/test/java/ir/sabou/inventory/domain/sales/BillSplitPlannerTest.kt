package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import kotlin.test.Test
import kotlin.test.assertEquals

class BillSplitPlannerTest {
    private val order = TableOrder(
        id = 1,
        orderNo = "M-1",
        tableId = 1,
        tableLabel = "1",
        guestCount = 2,
        waiterName = "کاربر",
        customerId = null,
        customerName = "متفرقه",
        status = TableOrderStatus.OPEN,
        openedAtEpochMillis = 1,
        notes = "",
        lines = listOf(
            TableOrderLine(10, 1, "غذای اول", QuantityMicros.parse("1"), MoneyRial.of(100), seatNo = 1),
            TableOrderLine(11, 2, "غذای دوم", QuantityMicros.parse("1"), MoneyRial.of(200), seatNo = 2),
            TableOrderLine(12, 3, "سالاد", QuantityMicros.parse("1"), MoneyRial.of(50), seatNo = 0),
        ),
    )

    @Test
    fun splitsByGuestAndKeepsSharedItemsSeparate() {
        val result = BillSplitPlanner.create(order, BillSplitMode.BY_GUEST)
        assertEquals(listOf("اقلام مشترک", "مهمان 1", "مهمان 2"), result.map { it.label })
        assertEquals(listOf(12L), result.first().lineIds)
    }

    @Test
    fun createsOneShareForEveryItem() {
        val result = BillSplitPlanner.create(order, BillSplitMode.BY_ITEM)
        assertEquals(3, result.size)
        assertEquals(listOf(10L, 11L, 12L), result.flatMap { it.lineIds })
    }

    @Test
    fun cashVarianceUsesSignedDifference() {
        assertEquals(-20L, CashShiftReconciliation.variance(MoneyRial.of(100), MoneyRial.of(80)))
        assertEquals(25L, CashShiftReconciliation.variance(MoneyRial.of(100), MoneyRial.of(125)))
    }
}
