package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFailsWith

class SalesCalculatorTest {
    @Test fun `normalizes invoice and calculates discount and delivery`() {
        val result = SalesCalculator.prepare(
            SaleDraft("  S-1  ", null, "مشتری نقدی", 100, null, "حضوری", MoneyRial.of(10), MoneyRial.of(5), SalePaymentMethod.CASH,
                lines = listOf(SaleLineDraft(null, "چلوکباب", QuantityMicros.of(2_000_000), MoneyRial.of(100))))
        )
        assertEquals("S-1", result.draft.invoiceNo)
        assertEquals(195, result.total.value)
    }

    @Test
    fun supportsMultiplePaymentsWithNoOutstandingBalance() {
        val result = SalesCalculator.prepare(
            SaleDraft(
                invoiceNo = "S-SPLIT",
                customerId = null,
                customerName = "مشتری نقدی",
                saleEpochDay = 100,
                dueEpochDay = null,
                channel = "حضوری",
                discount = MoneyRial.ZERO,
                delivery = MoneyRial.ZERO,
                paymentMethod = SalePaymentMethod.CASH,
                lines = listOf(SaleLineDraft(null, "محصول", QuantityMicros.parse("1"), MoneyRial.of(100))),
                payments = listOf(
                    SalePaymentAllocation(SalePaymentMethod.CASH, MoneyRial.of(40)),
                    SalePaymentAllocation(SalePaymentMethod.CARD, MoneyRial.of(60)),
                ),
            ),
        )
        assertEquals(100, result.total.value)
    }

    @Test fun `credit sale requires registered customer and due date`() {
        assertFailsWith<IllegalArgumentException> {
            SalesCalculator.prepare(
                SaleDraft("S-2", null, "شرکت", 100, null, "شرکتی", MoneyRial.ZERO, MoneyRial.ZERO, SalePaymentMethod.RECEIVABLE,
                    lines = listOf(SaleLineDraft(null, "غذا", QuantityMicros.of(1_000_000), MoneyRial.of(100))))
            )
        }
    }
}
