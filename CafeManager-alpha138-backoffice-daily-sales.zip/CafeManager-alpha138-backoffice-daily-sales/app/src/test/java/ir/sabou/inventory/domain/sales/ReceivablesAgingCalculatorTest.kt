package ir.sabou.inventory.domain.sales

import org.junit.Assert.assertEquals
import org.junit.Test

class ReceivablesAgingCalculatorTest {
    @Test
    fun groupsOverdueBalancesByAge() {
        val result = ReceivablesAgingCalculator.buckets(100, listOf(ReceivableInput(1, "شرکت الف", 95, 500), ReceivableInput(2, "شرکت ب", 60, 700)))
        assertEquals(500L, result[1].totalRial)
        assertEquals(700L, result[3].totalRial)
    }
}
