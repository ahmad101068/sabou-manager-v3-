package ir.sabou.inventory.domain.operations

import org.junit.Assert.assertEquals
import org.junit.Test

class KitchenQueueTest {
    @Test fun highPriorityTicketComesFirst() {
        val items = listOf(KitchenTicket(1, "A", "گریل", "برگر", 1, 2, priority = 0), KitchenTicket(2, "B", "گریل", "استیک", 1, 1, priority = 2))
        assertEquals(2L, KitchenQueue.prioritize(items).first().id)
    }
}
