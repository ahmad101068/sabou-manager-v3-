package ir.sabou.inventory.domain.operations

import org.junit.Assert.assertEquals
import org.junit.Test

class KitchenStationRouterTest {
    @Test fun routesRestaurantCategoriesToPreparationStations() {
        assertEquals("گریل و کباب", KitchenStationRouter.stationFor("کباب‌ها"))
        assertEquals("نوشیدنی و دسر", KitchenStationRouter.stationFor("نوشیدنی"))
        assertEquals("آماده‌سازی سرد", KitchenStationRouter.stationFor("سالاد و پیش‌غذا"))
        assertEquals("آشپزخانه گرم", KitchenStationRouter.stationFor("چلو و خورش"))
        assertEquals("آشپزخانه اصلی", KitchenStationRouter.stationFor("سایر"))
    }
}
