package ir.sabou.inventory.domain.sales

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RestaurantFloorModelsTest {
    @Test fun overlappingReservationsConflict() {
        val a = Reservation(1, "علی", "", 2, 100, 200, 3)
        val b = Reservation(2, "رضا", "", 2, 150, 250, 2)
        assertTrue(ReservationConflictChecker.conflicts(b, listOf(a)))
    }
    @Test fun differentTablesDoNotConflict() {
        val a = Reservation(1, "علی", "", 2, 100, 200, 3)
        val b = Reservation(2, "رضا", "", 3, 150, 250, 2)
        assertFalse(ReservationConflictChecker.conflicts(b, listOf(a)))
    }
}
