package ir.sabou.inventory.domain.sales

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CorporateCreditCalculatorTest {
    @Test fun overdueBlocksCorporateSale() {
        val result = CorporateCreditCalculator.decide(CorporateCreditPolicy(1, 1_000_000), 100_000, 100_000, 50_000)
        assertFalse(result.allowed)
    }
    @Test fun saleWithinTwelveDayCreditIsAllowed() {
        val result = CorporateCreditCalculator.decide(CorporateCreditPolicy(1, 1_000_000), 100_000, 100_000, 0)
        assertTrue(result.allowed)
    }
}
