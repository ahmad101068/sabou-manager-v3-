package ir.sabou.inventory.domain.crm

import org.junit.Assert.assertEquals
import org.junit.Test

class CustomerSegmentationTest {
    @Test fun prioritizesChurnRiskBeforeValueTier() {
        assertEquals(CustomerSegment.AT_RISK, CustomerSegmentation.classify(12, 200_000_000, 50, 100))
        assertEquals(CustomerSegment.VIP, CustomerSegmentation.classify(12, 200_000_000, 95, 100))
        assertEquals(CustomerSegment.LOYAL, CustomerSegmentation.classify(5, 20_000_000, 95, 100))
        assertEquals(CustomerSegment.NEW, CustomerSegmentation.classify(0, 0, 0, 100))
    }
}
