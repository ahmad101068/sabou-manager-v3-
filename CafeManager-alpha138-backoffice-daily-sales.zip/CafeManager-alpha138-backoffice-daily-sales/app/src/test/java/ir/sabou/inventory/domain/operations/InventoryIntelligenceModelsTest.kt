package ir.sabou.inventory.domain.operations

import kotlin.test.assertEquals
import kotlin.test.assertFailsWith
import org.junit.Test

class InventoryIntelligenceModelsTest {
    @Test fun calculatesSupplierPriceChange() {
        val insight = SupplierPriceInsight(1, "گوشت", "تأمین‌کننده", 1_250_000, 1_000_000)
        assertEquals(25, insight.changePercent)
    }

    @Test fun validatesWasteInput() {
        val value = WasteDraft(1, 500_000, 20_000, "فساد مواد", "کنترل دما").validated()
        assertEquals("فساد مواد", value.reason)
        assertFailsWith<IllegalArgumentException> { value.copy(quantityMicros = 0).validated() }
    }
}
