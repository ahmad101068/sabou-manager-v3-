package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.sales.DailyMenuSaleDraft
import ir.sabou.inventory.domain.sales.DailySalesDraft
import ir.sabou.inventory.domain.sales.DailySalesItem
import ir.sabou.inventory.domain.sales.DailySalesReport
import ir.sabou.inventory.domain.sales.DailySalesRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DailySalesUiState(
    val sales: List<DailySalesItem> = emptyList(),
    val menuItems: List<MenuItem> = emptyList(),
    val report: DailySalesReport? = null,
    val reportFromEpochDay: Long = currentEpochDay() - 29,
    val reportToEpochDay: Long = currentEpochDay(),
    val busy: Boolean = false,
    val message: String? = null,
) {
    val activeSalesRial: Long get() = report?.salesRial ?: 0
    val grossProfitRial: Long get() = report?.grossProfitRial ?: 0
    val receivablesRial: Long get() = 0
}

@OptIn(ExperimentalCoroutinesApi::class)
class DailySalesViewModel(
    private val repository: DailySalesRepository,
    recipeRepository: RecipeRepository,
) : ViewModel() {
    private val query = MutableStateFlow("")
    private val range = MutableStateFlow((currentEpochDay() - 29) to currentEpochDay())
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val sales = query.flatMapLatest(repository::observe)
    private val report = range.flatMapLatest { repository.observeReport(it.first, it.second) }

    private data class Content(
        val sales: List<DailySalesItem>,
        val menuItems: List<MenuItem>,
        val report: DailySalesReport,
        val range: Pair<Long, Long>,
    )

    private val content = combine(
        sales, recipeRepository.observeMenuItems(), report, range,
    ) { saleRows, menuRows, currentReport, currentRange ->
        Content(saleRows, menuRows, currentReport, currentRange)
    }

    val state: StateFlow<DailySalesUiState> = combine(content, busy, message) { base, isBusy, currentMessage ->
        DailySalesUiState(
            sales = base.sales,
            menuItems = base.menuItems,
            report = base.report,
            reportFromEpochDay = base.range.first,
            reportToEpochDay = base.range.second,
            busy = isBusy,
            message = currentMessage,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DailySalesUiState())

    fun search(value: String) { query.value = value }
    fun setReportRange(from: Long, to: Long) { if (from > 0 && to >= from) range.value = from to to }
    fun clearMessage() { message.value = null }

    fun post(
        epochDay: Long,
        discountRial: Long,
        serviceRial: Long,
        taxRial: Long,
        cashRial: Long,
        cardRial: Long,
        transferRial: Long,
        notes: String,
        lines: List<DailyMenuSaleDraft>,
        done: () -> Unit = {},
    ) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true
            message.value = null
            try {
                repository.post(DailySalesDraft(epochDay, discountRial, serviceRial, taxRial, cashRial, cardRial, transferRial, notes, lines))
                message.value = "فروش روزانه ثبت شد؛ موجودی و اسناد حسابداری به‌روزرسانی شدند."
                done()
            } catch (error: Exception) {
                message.value = error.message ?: "ثبت فروش روزانه انجام نشد."
            } finally {
                busy.value = false
            }
        }
    }

    companion object {
        fun factory(repository: DailySalesRepository, recipeRepository: RecipeRepository): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = DailySalesViewModel(repository, recipeRepository) as T
        }
    }
}
