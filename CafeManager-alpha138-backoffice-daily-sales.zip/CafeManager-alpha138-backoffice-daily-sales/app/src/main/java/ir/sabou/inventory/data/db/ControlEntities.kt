package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "inventory_counts",
    foreignKeys = [ForeignKey(entity = InventoryItemEntity::class, parentColumns = ["id"], childColumns = ["itemId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("itemId"), Index("countEpochDay")],
)
data class InventoryCountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val previousQuantityMicros: Long,
    val countedQuantityMicros: Long,
    val previousValueRial: Long,
    val countedValueRial: Long,
    val countEpochDay: Long,
    val reason: String,
    val createdAtEpochMillis: Long,
)

@Entity(tableName = "audit_logs", indices = [Index("createdAtEpochMillis"), Index(value=["entityType", "entityId"])])
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val entityType: String,
    val entityId: Long?,
    val description: String,
    val actor: String,
    val createdAtEpochMillis: Long,
)
