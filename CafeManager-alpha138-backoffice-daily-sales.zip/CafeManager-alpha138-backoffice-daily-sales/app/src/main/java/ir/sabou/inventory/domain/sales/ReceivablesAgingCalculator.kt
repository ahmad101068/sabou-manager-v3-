package ir.sabou.inventory.domain.sales

data class ReceivableInput(val saleId: Long, val customerName: String, val dueEpochDay: Long?, val outstandingRial: Long)
data class AgingBucket(val title: String, val totalRial: Long, val invoiceCount: Int)

object ReceivablesAgingCalculator {
    fun buckets(todayEpochDay: Long, items: List<ReceivableInput>): List<AgingBucket> {
        require(todayEpochDay > 0) { "تاریخ گزارش معتبر نیست." }
        require(items.all { it.saleId > 0 && it.customerName.isNotBlank() && it.outstandingRial >= 0 }) { "مطالبه معتبر نیست." }
        val groups = items.filter { it.outstandingRial > 0 }.groupBy { item ->
            val days = (todayEpochDay - (item.dueEpochDay ?: todayEpochDay)).coerceAtLeast(0)
            when {
                item.dueEpochDay == null || days == 0L -> "جاری"
                days <= 7 -> "۱ تا ۷ روز"
                days <= 30 -> "۸ تا ۳۰ روز"
                days <= 60 -> "۳۱ تا ۶۰ روز"
                else -> "بیش از ۶۰ روز"
            }
        }
        return listOf("جاری", "۱ تا ۷ روز", "۸ تا ۳۰ روز", "۳۱ تا ۶۰ روز", "بیش از ۶۰ روز").map { title ->
            val rows = groups[title].orEmpty()
            AgingBucket(title, rows.sumOf { it.outstandingRial }, rows.size)
        }
    }
}
