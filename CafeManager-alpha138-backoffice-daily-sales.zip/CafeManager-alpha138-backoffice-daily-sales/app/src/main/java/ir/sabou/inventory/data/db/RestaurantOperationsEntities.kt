package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "restaurant_tables", indices = [Index(value = ["label"], unique = true)])
data class RestaurantTableEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val label: String, val capacity: Int, val zone: String, val status: String = "FREE", val activeOrderId: Long? = null)

@Entity(tableName = "reservations", indices = [Index("tableId"), Index("startEpochMillis")])
data class ReservationEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val customerName: String, val phone: String, val tableId: Long, val startEpochMillis: Long, val endEpochMillis: Long, val partySize: Int, val notes: String = "")

@Entity(tableName = "kitchen_tickets", indices = [Index("status"), Index("createdAtEpochMillis")])
data class KitchenTicketEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val orderNo: String, val station: String, val itemName: String, val quantity: Int, val createdAtEpochMillis: Long, val status: String = "QUEUED", val priority: Int = 0, val orderLineId: Long? = null)

@Entity(tableName = "planned_shifts", indices = [Index("employeeId"), Index("epochDay")])
data class PlannedShiftEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val employeeId: Long, val employeeName: String, val role: String, val epochDay: Long, val startMinute: Int, val endMinute: Int)

@Entity(tableName = "approval_requests", indices = [Index("status"), Index(value = ["requestType", "entityId"])])
data class ApprovalRequestEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val requestType: String, val entityId: Long, val amountRial: Long, val requestedBy: String, val approver: String? = null, val status: String = "PENDING", val note: String = "")

@Entity(
    tableName = "table_orders",
    indices = [Index(value = ["orderNo"], unique = true), Index("tableId"), Index("status"), Index("openedAtEpochMillis")],
)
data class TableOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderNo: String,
    val tableId: Long,
    val guestCount: Int,
    val waiterName: String,
    val customerId: Long? = null,
    val customerName: String = "مشتری متفرقه",
    val status: String = "OPEN",
    val openedAtEpochMillis: Long,
    val closedAtEpochMillis: Long? = null,
    val mergedIntoOrderId: Long? = null,
    val saleId: Long? = null,
    val notes: String = "",
)

@Entity(
    tableName = "table_order_lines",
    foreignKeys = [
        ForeignKey(
            entity = TableOrderEntity::class,
            parentColumns = ["id"],
            childColumns = ["orderId"],
            onDelete = ForeignKey.RESTRICT,
        ),
    ],
    indices = [Index("orderId"), Index("menuItemId"), Index("status")],
)
data class TableOrderLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val menuItemId: Long,
    val itemName: String,
    val quantityMicros: Long,
    val unitPriceRial: Long,
    val seatNo: Int = 0,
    val courseNo: Int = 1,
    val notes: String = "",
    val status: String = "ACTIVE",
    val sentToKitchenAtEpochMillis: Long? = null,
    val voidReason: String? = null,
    val voidedBy: String? = null,
    val voidedAtEpochMillis: Long? = null,
)

@Entity(tableName = "bill_splits", indices = [Index("orderId"), Index("status"), Index("saleId")])
data class BillSplitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val label: String,
    val mode: String,
    val status: String = "OPEN",
    val saleId: Long? = null,
    val createdAtEpochMillis: Long,
    val settledAtEpochMillis: Long? = null,
)

@Entity(
    tableName = "bill_split_lines",
    foreignKeys = [
        ForeignKey(entity = BillSplitEntity::class, parentColumns = ["id"], childColumns = ["splitId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = TableOrderLineEntity::class, parentColumns = ["id"], childColumns = ["orderLineId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("splitId"), Index("orderLineId")],
)
data class BillSplitLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val splitId: Long,
    val orderLineId: Long,
)

@Entity(tableName = "cash_shifts", indices = [Index("status"), Index("openedAtEpochMillis")])
data class CashShiftEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val openedAtEpochMillis: Long,
    val closedAtEpochMillis: Long? = null,
    val openingFloatRial: Long,
    val expectedCashRial: Long = 0,
    val countedCashRial: Long? = null,
    val varianceRial: Long? = null,
    val openedBy: String,
    val closedBy: String? = null,
    val status: String = "OPEN",
    val note: String = "",
)
