package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveRecord
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollCalculation
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

data class PersonnelUiState(val employees: List<EmployeeRecord> = emptyList(), val payrolls: List<PayrollRecord> = emptyList(), val attendance: List<AttendanceRecord> = emptyList(), val leaves: List<LeaveRecord> = emptyList(), val pendingLeaves: List<LeaveRecord> = emptyList(), val payrollPreview: PayrollCalculation? = null, val attendanceSummary: AttendanceSummary? = null, val contracts: List<ir.sabou.inventory.domain.personnel.EmployeeContractRecord> = emptyList(), val advances: List<ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord> = emptyList(), val selectedEmployeeId: Long? = null, val message: String? = null)

class PersonnelViewModel(private val repository: PersonnelRepository) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    private val payrollPreview = MutableStateFlow<PayrollCalculation?>(null)
    private val attendanceSummary = MutableStateFlow<AttendanceSummary?>(null)
    private val selectedEmployeeId = MutableStateFlow<Long?>(null)
    private val contracts = selectedEmployeeId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.contracts(id) }
    private val advances = selectedEmployeeId.flatMapLatest { id -> if (id == null) flowOf(emptyList()) else repository.advances(id) }
    private val coreState = combine(repository.employees, repository.payrolls, repository.attendance, repository.leaves, repository.pendingLeaves) { e, p, a, l, pending -> arrayOf(e, p, a, l, pending) }
    private data class Transient(val preview: PayrollCalculation?, val summary: AttendanceSummary?, val contracts: List<ir.sabou.inventory.domain.personnel.EmployeeContractRecord>, val advances: List<ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord>, val employeeId: Long?, val message: String?)
    private val employeeDetails = combine(contracts, advances, selectedEmployeeId) { c, a, id -> Triple(c, a, id) }
    private val transientState = combine(payrollPreview, attendanceSummary, employeeDetails, message) { preview, summary, details, m -> Transient(preview, summary, details.first, details.second, details.third, m) }
    val state: StateFlow<PersonnelUiState> = combine(coreState, transientState) { core, transient ->
        @Suppress("UNCHECKED_CAST")
        PersonnelUiState(core[0] as List<EmployeeRecord>, core[1] as List<PayrollRecord>, core[2] as List<AttendanceRecord>, core[3] as List<LeaveRecord>, core[4] as List<LeaveRecord>, transient.preview, transient.summary, transient.contracts, transient.advances, transient.employeeId, transient.message)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersonnelUiState())

    fun saveEmployee(id: Long?, draft: EmployeeDraft) = launch("پرسنل ذخیره شد.") { repository.saveEmployee(id, draft) }
    fun deactivate(id: Long) = launch("پرسنل غیرفعال شد.") { repository.deactivateEmployee(id) }
    fun saveAttendance(id: Long?, draft: AttendanceDraft) = launch("حضور و غیاب ذخیره شد.") { repository.saveAttendance(id, draft) }
    fun requestLeave(draft: LeaveDraft, requestedBy: String = "SYSTEM") = launch("درخواست مرخصی ثبت شد.") { repository.requestLeave(draft, requestedBy) }
    fun reviewLeave(draft: LeaveReviewDraft) = launch("نتیجه بررسی مرخصی ثبت شد.") { repository.reviewLeave(draft) }
    fun cancelLeave(id: Long) = launch("درخواست مرخصی لغو شد.") { repository.cancelLeave(id) }
    fun approveLeave(draft: LeaveDraft) = launch("مرخصی تأیید شد.") { repository.approveLeave(draft) }
    fun loadAttendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long) = viewModelScope.launch {
        runCatching { repository.attendanceSummary(employeeId, startEpochDay, endEpochDay) }
            .onSuccess { attendanceSummary.value = it }
            .onFailure { message.value = it.message ?: "خطا در گزارش حضور" }
    }
    fun saveContract(id: Long?, draft: EmployeeContractDraft) = launch("قرارداد ذخیره شد.") { repository.saveContract(id, draft) }
    fun postAdvance(draft: EmployeeAdvanceDraft) = launch("مساعده ثبت و سند حسابداری صادر شد.") { repository.postAdvance(draft) }
    fun settleAdvance(id: Long, amountRial: Long) = launch("تسویه مساعده ثبت شد.") { repository.settleAdvance(id, amountRial) }
    fun calculatePayroll(draft: PayrollDraft) = viewModelScope.launch {
        runCatching { repository.calculatePayroll(draft) }
            .onSuccess { payrollPreview.value = it; message.value = "محاسبه حقوق انجام شد." }
            .onFailure { message.value = it.message ?: "خطا در محاسبه حقوق" }
    }
    fun postPayroll(draft: PayrollDraft) = launch("حقوق ثبت و سند حسابداری صادر شد.") { repository.postPayroll(draft); payrollPreview.value = null }
    fun clearMessage() { message.value = null }
    fun selectEmployee(id: Long?) { selectedEmployeeId.value = id; attendanceSummary.value = null }
    private fun launch(success: String, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }.onSuccess { message.value = success }.onFailure { message.value = it.message ?: "خطا" }
    }
    companion object { fun factory(repo: PersonnelRepository) = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = PersonnelViewModel(repo) as T
    } }
}
