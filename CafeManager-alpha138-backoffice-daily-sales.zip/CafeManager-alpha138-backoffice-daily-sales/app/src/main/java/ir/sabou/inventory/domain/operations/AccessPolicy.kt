package ir.sabou.inventory.domain.operations

enum class UserRole(val title: String, val permissions: Set<String>) {
    OWNER("مالک", setOf("*")),
    MANAGER("مدیر", setOf("PURCHASES", "SUPPLIERS", "INVENTORY", "RECIPES", "SALES", "ACCOUNTING", "REPORTS", "AUDIT", "BACKUP", "PERSONNEL", "ASSETS")),
    CASHIER("صندوقدار", setOf("SALES", "REPORTS")),
    KITCHEN("نقش قدیمی", emptySet()),
    INVENTORY("انبار", setOf("INVENTORY")),
    STOREKEEPER("انباردار", setOf("PURCHASES", "SUPPLIERS", "INVENTORY", "RECIPES")),
    ACCOUNTANT("حسابدار", setOf("PURCHASES", "SALES", "ACCOUNTING", "REPORTS", "AUDIT", "PERSONNEL", "ASSETS"));
    fun allows(permission: String): Boolean = "*" in permissions || permission in permissions
}
