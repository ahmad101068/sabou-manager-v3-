package ir.sabou.inventory.domain.crm

import ir.sabou.inventory.data.db.CrmCustomerRow
import ir.sabou.inventory.data.db.CrmFollowUpRow
import ir.sabou.inventory.data.db.LoyaltyTransactionEntity
import kotlinx.coroutines.flow.Flow

interface CrmRepository {
    fun customers(): Flow<List<CrmCustomerRow>>
    fun followUps(): Flow<List<CrmFollowUpRow>>
    fun transactions(customerId: Long): Flow<List<LoyaltyTransactionEntity>>
    suspend fun adjustPoints(customerId: Long, delta: Long, reason: String)
    suspend fun addFollowUp(customerId: Long, title: String, dueEpochDay: Long, notes: String)
    suspend fun completeFollowUp(id: Long)
}
