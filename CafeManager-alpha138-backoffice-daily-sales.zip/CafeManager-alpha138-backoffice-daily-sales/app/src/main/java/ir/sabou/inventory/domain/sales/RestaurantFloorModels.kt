package ir.sabou.inventory.domain.sales

enum class TableStatus { FREE, RESERVED, OCCUPIED, WAITING_PAYMENT, CLEANING }

data class RestaurantTable(
    val id: Long,
    val label: String,
    val capacity: Int,
    val zone: String,
    val status: TableStatus = TableStatus.FREE,
    val activeOrderId: Long? = null,
) {
    fun transition(next: TableStatus, orderId: Long? = activeOrderId): RestaurantTable {
        val valid = when (status) {
            TableStatus.FREE -> next == TableStatus.RESERVED || next == TableStatus.OCCUPIED
            TableStatus.RESERVED -> next == TableStatus.OCCUPIED || next == TableStatus.FREE
            TableStatus.OCCUPIED -> next == TableStatus.WAITING_PAYMENT || next == TableStatus.CLEANING
            TableStatus.WAITING_PAYMENT -> next == TableStatus.CLEANING
            TableStatus.CLEANING -> next == TableStatus.FREE
        }
        require(valid) { "تغییر وضعیت میز مجاز نیست." }
        if (next == TableStatus.OCCUPIED) require(orderId != null && orderId > 0) { "برای میز اشغال‌شده سفارش لازم است." }
        return copy(status = next, activeOrderId = if (next == TableStatus.FREE) null else orderId)
    }
}

data class Reservation(
    val id: Long,
    val customerName: String,
    val phone: String,
    val tableId: Long,
    val startEpochMillis: Long,
    val endEpochMillis: Long,
    val partySize: Int,
    val notes: String = "",
) {
    fun validated(): Reservation {
        require(id >= 0 && customerName.trim().length >= 2) { "اطلاعات رزرو معتبر نیست." }
        require(tableId > 0 && startEpochMillis > 0 && endEpochMillis > startEpochMillis) { "زمان رزرو معتبر نیست." }
        require(partySize in 1..100) { "تعداد مهمان معتبر نیست." }
        return copy(customerName = customerName.trim(), phone = phone.trim(), notes = notes.trim())
    }
}

object ReservationConflictChecker {
    fun conflicts(candidate: Reservation, existing: List<Reservation>): Boolean {
        candidate.validated()
        return existing.any { current -> current.tableId == candidate.tableId && current.id != candidate.id && candidate.startEpochMillis < current.endEpochMillis && current.startEpochMillis < candidate.endEpochMillis }
    }
}
