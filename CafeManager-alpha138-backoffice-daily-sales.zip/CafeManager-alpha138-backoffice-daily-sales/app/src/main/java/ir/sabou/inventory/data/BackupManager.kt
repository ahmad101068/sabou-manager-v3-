package ir.sabou.inventory.data

import android.content.Context
import ir.sabou.inventory.data.db.AppDatabase
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.security.MessageDigest
import java.util.Date
import java.util.Locale

class BackupManager(private val context: Context) {
    private val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("backup_state", Context.MODE_PRIVATE)

    fun applyPendingRestore() {
        val pending = prefs.getString("pending_restore", null) ?: return
        val source = resolveBackup(pending)
        if (source.isFile) {
            require(verify(pending)) { "فایل پشتیبان ناقص است یا اثرانگشت آن مطابقت ندارد." }
            context.getDatabasePath("sabou_manager_v3.db").also { target ->
                target.parentFile?.mkdirs()
                val staged = File(target.parentFile, "${target.name}.restore")
                source.copyTo(staged, overwrite = true)
                require(staged.length() == source.length()) { "کپی فایل پشتیبان کامل نشد." }
                if (target.exists()) {
                    val recovery = File(backupDir, "pre-restore-${System.currentTimeMillis()}.db")
                    target.copyTo(recovery, overwrite = false)
                    prefs.edit().putString("last_restore_recovery", recovery.name).commit()
                }
                require(staged.renameTo(target) || runCatching { staged.copyTo(target, overwrite = true); staged.delete(); true }.getOrDefault(false)) {
                    "جایگزینی پایگاه داده انجام نشد."
                }
            }
            context.getDatabasePath("sabou_manager_v3.db-wal").delete()
            context.getDatabasePath("sabou_manager_v3.db-shm").delete()
        }
        prefs.edit().remove("pending_restore").commit()
    }

    fun create(database: AppDatabase): String {
        val name = "restaurant-manager-backup-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}-${System.currentTimeMillis() % 1_000L}.db"
        val source = context.getDatabasePath("sabou_manager_v3.db")
        val destination = File(backupDir, name)
        database.openHelper.writableDatabase.execSQL("VACUUM INTO ?", arrayOf(destination.absolutePath))
        require(destination.length() >= MIN_DATABASE_BYTES && source.length() >= MIN_DATABASE_BYTES) {
            destination.delete()
            "ساخت نسخه پشتیبان کامل نشد."
        }
        writeChecksum(destination)
        return name
    }

    fun markRestoreValidated() {
        prefs.edit().remove("last_restore_recovery").commit()
    }

    fun rollbackLastRestore(): Boolean {
        val recoveryName = prefs.getString("last_restore_recovery", null) ?: return false
        val recovery = resolveBackup(recoveryName)
        val target = context.getDatabasePath("sabou_manager_v3.db")
        if (!recovery.isFile) return false
        recovery.copyTo(target, overwrite = true)
        context.getDatabasePath("sabou_manager_v3.db-wal").delete()
        context.getDatabasePath("sabou_manager_v3.db-shm").delete()
        prefs.edit().remove("last_restore_recovery").commit()
        return true
    }

    fun list(): List<String> = backupDir.listFiles()?.filter { it.isFile && it.extension == "db" }?.sortedByDescending { it.lastModified() }?.map { it.name }.orEmpty()

    fun describe(): List<BackupDescriptor> = backupDir.listFiles().orEmpty()
        .filter { it.isFile && it.extension == "db" }
        .sortedByDescending { it.lastModified() }
        .map { BackupDescriptor(it.name, it.length(), it.lastModified(), verify(it.name)) }

    fun verify(name: String): Boolean {
        val source = resolveBackup(name)
        if (!source.isFile || source.length() < MIN_DATABASE_BYTES || source.length() % DATABASE_PAGE_BYTES != 0L) return false
        val checksum = checksumFile(source)
        if (!checksum.isFile) return true
        val expected = checksum.readText().trim()
        return expected.matches(Regex("[0-9a-f]{64}")) && expected == sha256(source)
    }

    fun prune(maxFiles: Int) {
        val keep = maxFiles.coerceIn(1, 200)
        backupDir.listFiles()
            .orEmpty()
            .filter { it.isFile && it.extension == "db" && !it.name.startsWith("pre-restore-") }
            .sortedByDescending { it.lastModified() }
            .drop(keep)
            .forEach { file -> checksumFile(file).delete(); file.delete() }
    }

    fun clearAll() {
        backupDir.listFiles().orEmpty().filter { it.isFile }.forEach { it.delete() }
        check(prefs.edit().clear().commit()) { "پاک‌سازی وضعیت پشتیبان انجام نشد." }
    }

    fun delete(name: String) {
        val backup = resolveBackup(name)
        require(backup.isFile) { "فایل پشتیبان پیدا نشد." }
        checksumFile(backup).delete()
        check(backup.delete()) { "حذف فایل پشتیبان انجام نشد." }
        val editor = prefs.edit()
        if (prefs.getString("pending_restore", null) == name) editor.remove("pending_restore")
        if (prefs.getString("last_restore_recovery", null) == name) editor.remove("last_restore_recovery")
        check(editor.commit()) { "به‌روزرسانی وضعیت پشتیبان انجام نشد." }
    }

    fun export(name: String, destination: OutputStream): Long {
        val source = resolveBackup(name)
        require(source.isFile && source.length() >= MIN_DATABASE_BYTES) { "فایل پشتیبان معتبر نیست." }
        val copied = source.inputStream().use { input -> destination.use { output -> input.copyTo(output) } }
        require(copied == source.length()) { "صدور فایل پشتیبان کامل نشد." }
        return copied
    }

    fun importFrom(source: InputStream): String {
        val timestamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val name = "restaurant-manager-import-$timestamp-${System.currentTimeMillis() % 1_000L}.db"
        val staged = File(backupDir, "$name.import")
        val destination = File(backupDir, name)
        try {
            val copied = source.use { input -> staged.outputStream().use { output -> input.copyTo(output) } }
            require(copied >= MIN_DATABASE_BYTES && copied % DATABASE_PAGE_BYTES == 0L) {
                "فایل انتخاب‌شده ساختار قابل‌قبول پشتیبان را ندارد."
            }
            require(staged.renameTo(destination)) { "ذخیره فایل واردشده انجام نشد." }
            writeChecksum(destination)
            return name
        } catch (error: Throwable) {
            staged.delete()
            destination.delete()
            throw error
        }
    }

    fun scheduleRestore(name: String) {
        require(verify(name)) { "فایل پشتیبان معتبر نیست یا تغییر کرده است." }
        prefs.edit().putString("pending_restore", name).apply()
    }

    private fun writeChecksum(file: File) {
        checksumFile(file).writeText(sha256(file))
    }

    private fun checksumFile(file: File) = File(file.parentFile, "${file.name}.sha256")

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    private fun resolveBackup(name: String): File {
        require(name == File(name).name && name.endsWith(".db")) { "نام فایل پشتیبان معتبر نیست." }
        val candidate = File(backupDir, name).canonicalFile
        require(candidate.parentFile == backupDir.canonicalFile) { "مسیر فایل پشتیبان معتبر نیست." }
        return candidate
    }

    private companion object {
        const val MIN_DATABASE_BYTES = 4_096L
        const val DATABASE_PAGE_BYTES = 4_096L
    }
}

data class BackupDescriptor(val name: String, val sizeBytes: Long, val modifiedAtEpochMillis: Long, val integrityVerified: Boolean)
