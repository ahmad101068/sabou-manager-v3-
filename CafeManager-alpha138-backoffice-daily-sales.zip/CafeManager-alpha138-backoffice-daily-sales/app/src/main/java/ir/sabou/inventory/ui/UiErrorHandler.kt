package ir.sabou.inventory.ui

import android.util.Log
import java.io.IOException
import kotlinx.coroutines.CancellationException

/** Centralizes UI-safe error reporting without hiding programming defects in logs. */
object UiErrorHandler {
    fun message(tag: String, error: Throwable): String {
        if (error is CancellationException) throw error
        Log.e(tag, "Unhandled operation failure", error)
        return when (error) {
            is IllegalArgumentException, is IllegalStateException ->
                error.message?.takeIf { it.isNotBlank() } ?: "اطلاعات واردشده معتبر نیست."
            is IOException -> "دسترسی به فایل یا حافظه انجام نشد."
            else -> "خطای داخلی رخ داد. دوباره تلاش کنید."
        }
    }
}
