package ir.sabou.inventory.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun byName(name: String): SupplierEntity?

    @Query("SELECT * FROM suppliers WHERE id = :id AND isActive = 1")
    suspend fun activeById(id: Long): SupplierEntity?

    @Query("SELECT * FROM suppliers WHERE isActive = 1 ORDER BY name")
    fun observeActive(): Flow<List<SupplierEntity>>

    @Insert
    suspend fun insert(entity: SupplierEntity): Long

    @Update
    suspend fun update(entity: SupplierEntity): Int

    @Query(
        """
        UPDATE suppliers
        SET isActive = 0, updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id AND isActive = 1
        """,
    )
    suspend fun deactivate(id: Long, updatedAtEpochMillis: Long): Int
}

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items WHERE name = :name COLLATE NOCASE LIMIT 1")
    suspend fun byName(name: String): InventoryItemEntity?

    @Query("SELECT * FROM inventory_items WHERE id = :id LIMIT 1")
    suspend fun byId(id: Long): InventoryItemEntity?

    @Query("SELECT * FROM inventory_items WHERE id = :id AND isActive = 1")
    suspend fun activeById(id: Long): InventoryItemEntity?

    @Query(
        """
        UPDATE inventory_items
        SET stockMicros = :stockMicros,
            inventoryValueRial = :inventoryValueRial,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :itemId AND isActive = 1
        """,
    )
    suspend fun updateValuation(
        itemId: Long,
        stockMicros: Long,
        inventoryValueRial: Long,
        updatedAtEpochMillis: Long,
    ): Int

    @Query("SELECT * FROM inventory_items WHERE isActive = 1 ORDER BY name")
    fun observeActive(): Flow<List<InventoryItemEntity>>

    @Query(
        """
        SELECT COALESCE(SUM(inventoryValueRial), 0)
        FROM inventory_items
        WHERE isActive = 1
        """,
    )
    fun observeInventoryValueRial(): Flow<Long>

    @Insert
    suspend fun insert(entity: InventoryItemEntity): Long

    @Update
    suspend fun update(entity: InventoryItemEntity): Int

    @Query(
        """
        UPDATE inventory_items
        SET isActive = 0, updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id
          AND isActive = 1
          AND stockMicros = 0
          AND inventoryValueRial = 0
        """,
    )
    suspend fun deactivate(id: Long, updatedAtEpochMillis: Long): Int

    @Query(
        """
        UPDATE inventory_items
        SET supplierId = NULL, updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE supplierId = :supplierId
        """,
    )
    suspend fun clearSupplierReference(supplierId: Long, updatedAtEpochMillis: Long): Int

    @Query(
        """
        SELECT * FROM inventory_items
        WHERE isActive = 1
          AND alertEnabled = 1
          AND stockMicros <= alertThresholdMicros
        ORDER BY stockMicros ASC, name ASC
        """,
    )
    fun observeLowStock(): Flow<List<InventoryItemEntity>>
}

@Dao
interface PurchaseDao {
    @Query("SELECT EXISTS(SELECT 1 FROM purchases WHERE invoiceNo = :invoiceNo)")
    suspend fun invoiceExists(invoiceNo: String): Boolean

    @Insert
    suspend fun insert(entity: PurchaseEntity): Long

    @Insert
    suspend fun insertLines(lines: List<PurchaseLineEntity>)

    @Query("SELECT * FROM purchases WHERE id = :purchaseId LIMIT 1")
    suspend fun byId(purchaseId: Long): PurchaseEntity?

    @Query("SELECT * FROM purchase_lines WHERE purchaseId = :purchaseId ORDER BY id")
    suspend fun linesByPurchase(purchaseId: Long): List<PurchaseLineEntity>

    @Query(
        """
        SELECT
            p.id AS purchaseId,
            p.invoiceNo AS invoiceNo,
            s.name AS supplierName,
            p.purchaseEpochDay AS purchaseEpochDay,
            p.dueEpochDay AS dueEpochDay,
            p.totalRial AS totalRial,
            p.paidRial AS paidRial,
            p.paymentStatus AS paymentStatus,
            p.paymentMethod AS paymentMethod,
            p.reminderEnabled AS reminderEnabled,
            p.reminderEpochDay AS reminderEpochDay
        FROM purchases p
        INNER JOIN suppliers s ON s.id = p.supplierId
        WHERE p.id = :purchaseId
        LIMIT 1
        """,
    )
    fun observeHeader(purchaseId: Long): Flow<PurchaseHeaderRow?>

    @Query(
        """
        SELECT
            pl.itemId AS itemId,
            pl.itemNameSnapshot AS itemName,
            i.unit AS unit,
            pl.quantityMicros AS quantityMicros,
            pl.unitCostRial AS unitCostRial,
            pl.lineTotalRial AS lineTotalRial
        FROM purchase_lines pl
        INNER JOIN inventory_items i ON i.id = pl.itemId
        WHERE pl.purchaseId = :purchaseId
        ORDER BY pl.id
        """,
    )
    fun observeDetailLines(purchaseId: Long): Flow<List<PurchaseLineDetailRow>>

    @Query(
        """
        UPDATE purchases
        SET paidRial = :newPaidRial,
            paymentStatus = :paymentStatus,
            reminderEnabled = :reminderEnabled,
            reminderEpochDay = :reminderEpochDay
        WHERE id = :purchaseId
          AND paidRial = :expectedPaidRial
          AND paymentStatus IN ('UNPAID', 'PARTIAL')
        """,
    )
    suspend fun updateSettlementState(
        purchaseId: Long,
        expectedPaidRial: Long,
        newPaidRial: Long,
        paymentStatus: String,
        reminderEnabled: Boolean,
        reminderEpochDay: Long?,
    ): Int

    @Query(
        """
        UPDATE purchases
        SET paymentStatus = 'REVERSED',
            reminderEnabled = 0,
            reminderEpochDay = NULL
        WHERE id = :purchaseId
          AND paymentStatus != 'REVERSED'
        """,
    )
    suspend fun markReversed(purchaseId: Long): Int

    @Query("SELECT * FROM purchases ORDER BY purchaseEpochDay DESC, id DESC")
    fun observeAll(): Flow<List<PurchaseEntity>>

    @Query(
        """
        SELECT i.id AS itemId,
               i.name AS itemName,
               COALESCE((
                   SELECT s.name
                   FROM purchase_lines latestLine
                   INNER JOIN purchases latestPurchase ON latestPurchase.id = latestLine.purchaseId
                   INNER JOIN suppliers s ON s.id = latestPurchase.supplierId
                   WHERE latestLine.itemId = i.id AND latestPurchase.paymentStatus != 'REVERSED'
                   ORDER BY latestPurchase.purchaseEpochDay DESC, latestLine.id DESC
                   LIMIT 1
               ), '') AS supplierName,
               COALESCE((
                   SELECT latestLine.unitCostRial
                   FROM purchase_lines latestLine
                   INNER JOIN purchases latestPurchase ON latestPurchase.id = latestLine.purchaseId
                   WHERE latestLine.itemId = i.id AND latestPurchase.paymentStatus != 'REVERSED'
                   ORDER BY latestPurchase.purchaseEpochDay DESC, latestLine.id DESC
                   LIMIT 1
               ), 0) AS latestUnitCostRial,
               COALESCE((
                   SELECT previousLine.unitCostRial
                   FROM purchase_lines previousLine
                   INNER JOIN purchases previousPurchase ON previousPurchase.id = previousLine.purchaseId
                   WHERE previousLine.itemId = i.id AND previousPurchase.paymentStatus != 'REVERSED'
                   ORDER BY previousPurchase.purchaseEpochDay DESC, previousLine.id DESC
                   LIMIT 1 OFFSET 1
               ), 0) AS previousUnitCostRial
        FROM inventory_items i
        WHERE i.isActive = 1
        ORDER BY i.name
        """,
    )
    fun observeSupplierPriceInsights(): Flow<List<SupplierPriceInsightRow>>

    @Query(
        """
        SELECT
            p.id AS purchaseId,
            p.invoiceNo AS invoiceNo,
            s.name AS supplierName,
            p.purchaseEpochDay AS purchaseEpochDay,
            p.dueEpochDay AS dueEpochDay,
            p.totalRial AS totalRial,
            p.paidRial AS paidRial,
            p.paymentStatus AS paymentStatus,
            p.paymentMethod AS paymentMethod,
            p.reminderEnabled AS reminderEnabled,
            p.reminderEpochDay AS reminderEpochDay
        FROM purchases p
        INNER JOIN suppliers s ON s.id = p.supplierId
        WHERE :query = ''
           OR p.invoiceNo LIKE '%' || :query || '%'
           OR s.name LIKE '%' || :query || '%'
        ORDER BY p.purchaseEpochDay DESC, p.id DESC
        """,
    )
    fun observeSearch(query: String): Flow<List<PurchaseListRow>>

    @Query(
        """
        SELECT COALESCE(SUM(totalRial - paidRial), 0)
        FROM purchases
        WHERE paymentStatus IN ('UNPAID', 'PARTIAL')
        """,
    )
    fun observePayablesRial(): Flow<Long>

    @Query("SELECT EXISTS(SELECT 1 FROM procurement_invoice_links WHERE purchaseId = :purchaseId)")
    suspend fun isProcurementInvoice(purchaseId: Long): Boolean
}

@Dao
interface ProcurementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSupplierItemOffer(entity: SupplierItemOfferEntity): Long

    @Query("SELECT o.*, s.name AS supplierName, i.name AS itemName FROM supplier_item_offers o INNER JOIN suppliers s ON s.id = o.supplierId INNER JOIN inventory_items i ON i.id = o.itemId ORDER BY i.name, o.unitCostRial")
    fun observeSupplierItemOffers(): Flow<List<SupplierItemOfferRow>>

    @Query("SELECT * FROM supplier_item_offers WHERE itemId = :itemId AND isActive = 1 AND (validUntilEpochDay IS NULL OR validUntilEpochDay >= :todayEpochDay) ORDER BY unitCostRial")
    suspend fun validSupplierItemOffers(itemId: Long, todayEpochDay: Long): List<SupplierItemOfferEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReplenishmentPolicy(entity: InventoryReplenishmentPolicyEntity)

    @Query("SELECT * FROM inventory_replenishment_policies WHERE itemId = :itemId LIMIT 1")
    suspend fun replenishmentPolicy(itemId: Long): InventoryReplenishmentPolicyEntity?

    @Query("SELECT * FROM inventory_replenishment_policies ORDER BY itemId")
    fun observeReplenishmentPolicies(): Flow<List<InventoryReplenishmentPolicyEntity>>

    @Query(
        """
        SELECT itemId, COALESCE(SUM(-quantityDeltaMicros), 0) AS usageMicros
        FROM stock_movements
        WHERE movementEpochDay >= :fromEpochDay
          AND quantityDeltaMicros < 0
          AND movementType IN ('SALE_CONSUMPTION', 'DAILY_SALES_CONSUMPTION', 'WASTE')
        GROUP BY itemId
        """,
    )
    fun observeDemandUsage(fromEpochDay: Long): Flow<List<ProcurementDemandUsageRow>>

    @Query(
        """
        SELECT pl.itemId AS itemId, pl.unitCostRial AS unitCostRial
        FROM purchase_lines pl
        INNER JOIN purchases p ON p.id = pl.purchaseId
        WHERE p.paymentStatus != 'REVERSED'
          AND pl.id = (
              SELECT latestLine.id
              FROM purchase_lines latestLine
              INNER JOIN purchases latestPurchase ON latestPurchase.id = latestLine.purchaseId
              WHERE latestLine.itemId = pl.itemId AND latestPurchase.paymentStatus != 'REVERSED'
              ORDER BY latestPurchase.purchaseEpochDay DESC, latestLine.id DESC
              LIMIT 1
          )
        """,
    )
    fun observeLatestPurchaseCosts(): Flow<List<ProcurementLatestCostRow>>

    @Query(
        """
        SELECT COALESCE(SUM(-quantityDeltaMicros), 0)
        FROM stock_movements
        WHERE itemId = :itemId
          AND movementEpochDay >= :fromEpochDay
          AND quantityDeltaMicros < 0
          AND movementType IN ('SALE_CONSUMPTION', 'DAILY_SALES_CONSUMPTION', 'WASTE')
        """,
    )
    suspend fun demandUsageMicros(itemId: Long, fromEpochDay: Long): Long

    @Query(
        """
        SELECT COALESCE(SUM(pol.orderedQtyMicros - pol.receivedQtyMicros), 0)
        FROM purchase_order_lines pol
        INNER JOIN purchase_orders po ON po.id = pol.purchaseOrderId
        WHERE pol.itemId = :itemId
          AND po.status IN ('OPEN', 'PARTIALLY_RECEIVED')
        """,
    )
    suspend fun openPurchaseOrderQtyMicros(itemId: Long): Long

    @Query(
        """
        SELECT pl.unitCostRial
        FROM purchase_lines pl
        INNER JOIN purchases p ON p.id = pl.purchaseId
        WHERE pl.itemId = :itemId AND p.paymentStatus != 'REVERSED'
        ORDER BY p.purchaseEpochDay DESC, pl.id DESC
        LIMIT 1
        """,
    )
    suspend fun latestPurchaseUnitCostRial(itemId: Long): Long?

    @Query(
        """
        SELECT DISTINCT prl.itemId
        FROM purchase_requisition_lines prl
        INNER JOIN purchase_requisitions pr ON pr.id = prl.requisitionId
        WHERE pr.status IN ('SUBMITTED', 'APPROVED')
        """,
    )
    fun observeActiveRequestedItemIds(): Flow<List<Long>>

    @Query(
        """
        SELECT EXISTS(
            SELECT 1 FROM purchase_requisition_lines prl
            INNER JOIN purchase_requisitions pr ON pr.id = prl.requisitionId
            WHERE prl.itemId = :itemId AND pr.status IN ('SUBMITTED', 'APPROVED')
        )
        """,
    )
    suspend fun activeRequestExistsForItem(itemId: Long): Boolean

    @Insert
    suspend fun insertRequisition(entity: PurchaseRequisitionEntity): Long

    @Insert
    suspend fun insertRequisitionLines(lines: List<PurchaseRequisitionLineEntity>)

    @Query("SELECT * FROM purchase_requisitions WHERE id = :id LIMIT 1")
    suspend fun requisitionById(id: Long): PurchaseRequisitionEntity?

    @Query("SELECT * FROM purchase_requisition_lines WHERE requisitionId = :requisitionId ORDER BY id")
    suspend fun requisitionLines(requisitionId: Long): List<PurchaseRequisitionLineEntity>

    @Query(
        """
        UPDATE purchase_requisitions
        SET status = :newStatus, approvedBy = :approvedBy, note = :note,
            updatedAtEpochMillis = :updatedAtEpochMillis
        WHERE id = :id AND status = :expectedStatus
        """,
    )
    suspend fun transitionRequisition(
        id: Long,
        expectedStatus: String,
        newStatus: String,
        approvedBy: String?,
        note: String,
        updatedAtEpochMillis: Long,
    ): Int

    @Insert
    suspend fun insertOrder(entity: PurchaseOrderEntity): Long

    @Insert
    suspend fun insertOrderLines(lines: List<PurchaseOrderLineEntity>)

    @Query("SELECT * FROM purchase_orders WHERE id = :id LIMIT 1")
    suspend fun orderById(id: Long): PurchaseOrderEntity?

    @Query("SELECT * FROM purchase_order_lines WHERE purchaseOrderId = :purchaseOrderId ORDER BY id")
    suspend fun orderLines(purchaseOrderId: Long): List<PurchaseOrderLineEntity>

    @Query("SELECT * FROM procurement_invoice_links WHERE purchaseOrderId = :purchaseOrderId LIMIT 1")
    suspend fun invoiceLinkForOrder(purchaseOrderId: Long): ProcurementInvoiceLinkEntity?

    @Query("SELECT * FROM purchase_lines WHERE purchaseId = :purchaseId AND itemId = :itemId LIMIT 1")
    suspend fun purchaseLineForItem(purchaseId: Long, itemId: Long): PurchaseLineEntity?

    @Insert
    suspend fun insertReceipt(entity: GoodsReceiptEntity): Long

    @Insert
    suspend fun insertReceiptLines(lines: List<GoodsReceiptLineEntity>)

    @Query("SELECT EXISTS(SELECT 1 FROM goods_receipts WHERE receiptNo = :receiptNo)")
    suspend fun receiptNoExists(receiptNo: String): Boolean

    @Query("SELECT EXISTS(SELECT 1 FROM goods_receipts WHERE purchaseOrderId = :purchaseOrderId AND deliveryNoteNo = :deliveryNoteNo)")
    suspend fun deliveryNoteExists(purchaseOrderId: Long, deliveryNoteNo: String): Boolean

    @Query("SELECT MAX(receiptEpochDay) FROM goods_receipts WHERE purchaseOrderId = :purchaseOrderId")
    suspend fun latestReceiptEpochDay(purchaseOrderId: Long): Long?

    @Query(
        """
        UPDATE purchase_order_lines
        SET receivedQtyMicros = receivedQtyMicros + :acceptedQtyMicros,
            rejectedQtyMicros = rejectedQtyMicros + :rejectedQtyMicros
        WHERE id = :lineId
          AND purchaseOrderId = :purchaseOrderId
          AND receivedQtyMicros + :acceptedQtyMicros <= orderedQtyMicros
        """,
    )
    suspend fun addReceiptQuantities(
        lineId: Long,
        purchaseOrderId: Long,
        acceptedQtyMicros: Long,
        rejectedQtyMicros: Long,
    ): Int

    @Query(
        """
        UPDATE purchase_order_lines
        SET returnedQtyMicros = returnedQtyMicros + :quantityMicros
        WHERE id = :lineId
          AND purchaseOrderId = :purchaseOrderId
          AND returnedQtyMicros + :quantityMicros <= receivedQtyMicros
        """,
    )
    suspend fun addReturnedQuantity(
        lineId: Long,
        purchaseOrderId: Long,
        quantityMicros: Long,
    ): Int

    @Query("UPDATE purchase_orders SET status = :status, updatedAtEpochMillis = :updatedAt WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: Long, status: String, updatedAt: Long): Int

    @Query("UPDATE purchase_orders SET sentAtEpochMillis = :sentAt, sentBy = :sentBy, dispatchChannel = :channel, updatedAtEpochMillis = :sentAt WHERE id = :orderId AND status = 'OPEN' AND sentAtEpochMillis IS NULL")
    suspend fun markOrderSent(orderId: Long, sentAt: Long, sentBy: String, channel: String): Int

    @Query("UPDATE purchase_orders SET acknowledgedAtEpochMillis = :acknowledgedAt, supplierConfirmationNo = :confirmationNo, confirmedExpectedEpochDay = :confirmedExpectedDay, expectedEpochDay = :confirmedExpectedDay, updatedAtEpochMillis = :acknowledgedAt WHERE id = :orderId AND status IN ('OPEN', 'PARTIALLY_RECEIVED') AND sentAtEpochMillis IS NOT NULL AND acknowledgedAtEpochMillis IS NULL")
    suspend fun acknowledgeOrder(orderId: Long, acknowledgedAt: Long, confirmationNo: String, confirmedExpectedDay: Long): Int

    @Query("SELECT EXISTS(SELECT 1 FROM procurement_invoice_links WHERE purchaseOrderId = :purchaseOrderId)")
    suspend fun orderHasInvoice(purchaseOrderId: Long): Boolean

    @Insert
    suspend fun insertInvoiceLink(entity: ProcurementInvoiceLinkEntity): Long

    @Insert
    suspend fun insertPurchaseReturn(entity: PurchaseReturnEntity): Long

    @Insert
    suspend fun insertPurchaseReturnLines(lines: List<PurchaseReturnLineEntity>)

    @Insert
    suspend fun insertSupplierCredit(entity: SupplierCreditEntity): Long

    @Query(
        """
        SELECT r.id, r.requestNo, r.department, r.requiredEpochDay, r.status,
               r.requestedBy, r.approvedBy,
               COUNT(rl.id) AS lineCount
        FROM purchase_requisitions r
        LEFT JOIN purchase_requisition_lines rl ON rl.requisitionId = r.id
        GROUP BY r.id
        ORDER BY r.createdAtEpochMillis DESC
        """,
    )
    fun observeRequisitions(): Flow<List<ProcurementRequisitionRow>>

    @Query("SELECT * FROM purchase_requisition_lines ORDER BY requisitionId, id")
    fun observeRequisitionLines(): Flow<List<PurchaseRequisitionLineEntity>>

    @Query(
        """
        SELECT po.id, po.orderNo, po.supplierId, po.supplierNameSnapshot AS supplierName,
               po.requisitionId, po.orderEpochDay, po.expectedEpochDay,
               po.sentAtEpochMillis, po.sentBy, po.dispatchChannel,
               po.acknowledgedAtEpochMillis, po.supplierConfirmationNo, po.confirmedExpectedEpochDay,
               po.status,
               (SELECT COUNT(*) FROM goods_receipts gr WHERE gr.purchaseOrderId = po.id) AS receiptCount,
               (SELECT p.invoiceNo FROM procurement_invoice_links pil
                   INNER JOIN purchases p ON p.id = pil.purchaseId
                   WHERE pil.purchaseOrderId = po.id LIMIT 1) AS invoiceNo
        FROM purchase_orders po
        ORDER BY po.createdAtEpochMillis DESC
        """,
    )
    fun observeOrders(): Flow<List<ProcurementOrderRow>>

    @Query("SELECT * FROM purchase_order_lines ORDER BY purchaseOrderId, id")
    fun observeOrderLines(): Flow<List<PurchaseOrderLineEntity>>

    @Query("SELECT * FROM goods_receipts ORDER BY receiptEpochDay DESC, id DESC")
    fun observeGoodsReceipts(): Flow<List<GoodsReceiptEntity>>

    @Query("SELECT * FROM goods_receipt_lines ORDER BY goodsReceiptId, id")
    fun observeGoodsReceiptLines(): Flow<List<GoodsReceiptLineEntity>>

    @Query("SELECT * FROM purchase_returns ORDER BY returnEpochDay DESC, id DESC")
    fun observePurchaseReturns(): Flow<List<PurchaseReturnEntity>>

    @Query("SELECT * FROM purchase_return_lines ORDER BY purchaseReturnId, id")
    fun observePurchaseReturnLines(): Flow<List<PurchaseReturnLineEntity>>

    @Query("SELECT * FROM procurement_invoice_links ORDER BY matchedAtEpochMillis DESC")
    fun observeInvoiceLinks(): Flow<List<ProcurementInvoiceLinkEntity>>

    @Query(
        """
        SELECT sc.id, sc.creditNo, sc.supplierId, s.name AS supplierName,
               sc.amountRial, sc.appliedRial, sc.status, sc.createdAtEpochMillis
        FROM supplier_credits sc
        INNER JOIN suppliers s ON s.id = sc.supplierId
        ORDER BY sc.createdAtEpochMillis DESC
        """,
    )
    fun observeSupplierCredits(): Flow<List<SupplierCreditRow>>
}

data class ProcurementDemandUsageRow(
    val itemId: Long,
    val usageMicros: Long,
)

data class ProcurementLatestCostRow(
    val itemId: Long,
    val unitCostRial: Long,
)

data class SupplierItemOfferRow(
    val id: Long,
    val supplierId: Long,
    val supplierName: String,
    val itemId: Long,
    val itemName: String,
    val supplierSku: String,
    val unitCostRial: Long,
    val minimumOrderMicros: Long,
    val orderMultipleMicros: Long,
    val leadTimeDays: Int,
    val validUntilEpochDay: Long?,
    val isActive: Boolean,
    val updatedBy: String,
    val updatedAtEpochMillis: Long,
)

data class SupplierCreditRow(
    val id: Long,
    val creditNo: String,
    val supplierId: Long,
    val supplierName: String,
    val amountRial: Long,
    val appliedRial: Long,
    val status: String,
    val createdAtEpochMillis: Long,
)

data class ProcurementRequisitionRow(
    val id: Long,
    val requestNo: String,
    val department: String,
    val requiredEpochDay: Long,
    val status: String,
    val requestedBy: String,
    val approvedBy: String?,
    val lineCount: Int,
)

data class ProcurementOrderRow(
    val id: Long,
    val orderNo: String,
    val supplierId: Long,
    val supplierName: String,
    val requisitionId: Long,
    val orderEpochDay: Long,
    val expectedEpochDay: Long,
    val sentAtEpochMillis: Long?,
    val sentBy: String?,
    val dispatchChannel: String?,
    val acknowledgedAtEpochMillis: Long?,
    val supplierConfirmationNo: String?,
    val confirmedExpectedEpochDay: Long?,
    val status: String,
    val receiptCount: Int,
    val invoiceNo: String?,
)

data class SupplierPriceInsightRow(
    val itemId: Long,
    val itemName: String,
    val supplierName: String,
    val latestUnitCostRial: Long,
    val previousUnitCostRial: Long,
)

data class PurchaseListRow(
    val purchaseId: Long,
    val invoiceNo: String,
    val supplierName: String,
    val purchaseEpochDay: Long,
    val dueEpochDay: Long,
    val totalRial: Long,
    val paidRial: Long,
    val paymentStatus: String,
    val paymentMethod: String?,
    val reminderEnabled: Boolean,
    val reminderEpochDay: Long?,
)

data class PurchaseHeaderRow(
    val purchaseId: Long,
    val invoiceNo: String,
    val supplierName: String,
    val purchaseEpochDay: Long,
    val dueEpochDay: Long,
    val totalRial: Long,
    val paidRial: Long,
    val paymentStatus: String,
    val paymentMethod: String?,
    val reminderEnabled: Boolean,
    val reminderEpochDay: Long?,
)

data class PurchaseLineDetailRow(
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val quantityMicros: Long,
    val unitCostRial: Long,
    val lineTotalRial: Long,
)

@Dao
interface StockMovementDao {
    @Insert
    suspend fun insert(entity: StockMovementEntity): Long

    @Query(
        """
        SELECT *
        FROM stock_movements
        WHERE referenceType = 'SALE'
          AND referenceId = :saleId
          AND movementType IN ('SALE_CONSUMPTION', 'DAILY_SALES_CONSUMPTION')
        ORDER BY id
        """,
    )
    suspend fun saleConsumptions(saleId: Long): List<StockMovementEntity>

    @Query(
        """
        SELECT i.id AS itemId, i.name AS itemName, i.unit AS unit,
               COALESCE(SUM(-sm.quantityDeltaMicros), 0) AS usageMicros
        FROM inventory_items i
        LEFT JOIN stock_movements sm
          ON sm.itemId = i.id
         AND sm.movementEpochDay >= :fromEpochDay
         AND sm.quantityDeltaMicros < 0
         AND sm.movementType IN ('SALE_CONSUMPTION', 'DAILY_SALES_CONSUMPTION', 'WASTE')
        WHERE i.isActive = 1
        GROUP BY i.id, i.name, i.unit
        ORDER BY usageMicros DESC, i.name
        """,
    )
    fun observeUsageSince(fromEpochDay: Long): Flow<List<InventoryUsageRow>>

    @Query(
        """
        SELECT sm.id AS id, sm.itemId AS itemId, i.name AS itemName, i.unit AS unit,
               -sm.quantityDeltaMicros AS quantityMicros,
               -sm.valueDeltaRial AS valueRial,
               sm.movementEpochDay AS wasteEpochDay,
               sm.notes AS reason
        FROM stock_movements sm
        INNER JOIN inventory_items i ON i.id = sm.itemId
        WHERE sm.movementType = 'WASTE'
        ORDER BY sm.movementEpochDay DESC, sm.id DESC
        LIMIT 200
        """,
    )
    fun observeWasteRecords(): Flow<List<WasteRow>>
}

data class InventoryUsageRow(
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val usageMicros: Long,
)

data class WasteRow(
    val id: Long,
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val quantityMicros: Long,
    val valueRial: Long,
    val wasteEpochDay: Long,
    val reason: String,
)

@Dao
interface AccountingDao {
    @Query("SELECT * FROM accounts WHERE code = :code LIMIT 1")
    suspend fun accountByCode(code: String): AccountEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAccount(entity: AccountEntity)

    @Update
    suspend fun updateAccount(entity: AccountEntity): Int

    @Query(
        """
        SELECT COUNT(*)
        FROM journal_lines
        WHERE accountCode = :accountCode
        """,
    )
    suspend fun accountUsageCount(accountCode: String): Long

    @Query(
        """
        SELECT COALESCE(SUM(jl.debitRial - jl.creditRial), 0)
        FROM journal_lines jl
        INNER JOIN journal_entries je ON je.id = jl.entryId
        WHERE jl.accountCode = :accountCode
          AND je.status = 'POSTED'
        """,
    )
    suspend fun accountBalanceRial(accountCode: String): Long

    @Query(
        """
        SELECT
            a.code AS code,
            a.name AS name,
            a.type AS type,
            a.isSystem AS isSystem,
            COALESCE(SUM(
                CASE WHEN je.status = 'POSTED' THEN jl.debitRial ELSE 0 END
            ), 0) AS debitTurnoverRial,
            COALESCE(SUM(
                CASE WHEN je.status = 'POSTED' THEN jl.creditRial ELSE 0 END
            ), 0) AS creditTurnoverRial
        FROM accounts a
        LEFT JOIN journal_lines jl ON jl.accountCode = a.code
        LEFT JOIN journal_entries je ON je.id = jl.entryId
        WHERE a.isActive = 1
        GROUP BY a.code, a.name, a.type, a.isSystem
        ORDER BY a.code
        """,
    )
    fun observeAccountBalances(): Flow<List<AccountBalanceRow>>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertEntry(entity: JournalEntryEntity): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertLines(lines: List<JournalLineEntity>)

    @Query(
        """
        UPDATE journal_entries
        SET entryNo = :entryNo, sourceId = :sourceId
        WHERE id = :entryId
        """,
    )
    suspend fun finalizeEntryIdentity(
        entryId: Long,
        entryNo: String,
        sourceId: Long,
    ): Int

    @Query("SELECT * FROM journal_entries WHERE id = :entryId LIMIT 1")
    suspend fun entryById(entryId: Long): JournalEntryEntity?

    @Query(
        """
        SELECT *
        FROM journal_lines
        WHERE entryId = :entryId
        ORDER BY id
        """,
    )
    suspend fun linesByEntry(entryId: Long): List<JournalLineEntity>

    @Query(
        """
        SELECT * FROM journal_entries
        WHERE sourceType = :sourceType
          AND sourceId = :sourceId
          AND status = 'POSTED'
        ORDER BY id
        LIMIT 1
        """,
    )
    suspend fun entryBySource(sourceType: String, sourceId: Long): JournalEntryEntity?

    @Query(
        """
        SELECT EXISTS(
            SELECT 1 FROM journal_entries
            WHERE sourceType = 'PURCHASE_REVERSAL'
              AND sourceId = :purchaseId
              AND status = 'POSTED'
        )
        """,
    )
    suspend fun hasPurchaseReversal(purchaseId: Long): Boolean

    @Query(
        """
        SELECT
            je.id AS journalEntryId,
            je.entryNo AS entryNo,
            je.entryEpochDay AS settlementEpochDay,
            debitLine.debitRial AS amountRial,
            CASE creditLine.accountCode
                WHEN '1101' THEN 'نقدی'
                ELSE CASE
                    WHEN je.description LIKE '%حواله%' THEN 'حواله'
                    ELSE 'کارتخوان'
                END
            END AS paymentMethod,
            creditLine.memo AS referenceNo,
            debitLine.memo AS notes,
            EXISTS(
                SELECT 1
                FROM journal_entries reversal
                WHERE reversal.sourceType = 'PURCHASE_SETTLEMENT_REVERSAL'
                  AND reversal.sourceId = je.id
                  AND reversal.status = 'POSTED'
            ) AS isReversed
        FROM journal_entries je
        INNER JOIN journal_lines debitLine
            ON debitLine.entryId = je.id
           AND debitLine.accountCode = '2101'
           AND debitLine.debitRial > 0
        INNER JOIN journal_lines creditLine
            ON creditLine.entryId = je.id
           AND creditLine.creditRial > 0
        WHERE je.sourceType = 'PURCHASE_SETTLEMENT'
          AND je.sourceId = :purchaseId
          AND je.status = 'POSTED'
        ORDER BY je.entryEpochDay DESC, je.id DESC
        """,
    )
    fun observePurchaseSettlements(purchaseId: Long): Flow<List<PurchaseSettlementRow>>

    @Query(
        """
        SELECT EXISTS(
            SELECT 1 FROM journal_entries
            WHERE sourceType = 'PURCHASE_SETTLEMENT_REVERSAL'
              AND sourceId = :settlementEntryId
              AND status = 'POSTED'
        )
        """,
    )
    suspend fun hasSettlementReversal(settlementEntryId: Long): Boolean

    @Query("SELECT EXISTS(SELECT 1 FROM accounts WHERE code = :code AND isActive = 1)")
    suspend fun activeAccountExists(code: String): Boolean

    @Query(
        """
        SELECT EXISTS(
            SELECT 1
            FROM journal_entries
            WHERE sourceType = 'REVERSAL'
              AND sourceId = :entryId
              AND status = 'POSTED'
        )
        """,
    )
    suspend fun hasPostedReversal(entryId: Long): Boolean

    @Query(
        """
        SELECT
            je.id AS id,
            je.entryNo AS entryNo,
            je.entryEpochDay AS entryEpochDay,
            je.description AS description,
            je.sourceType AS sourceType,
            COALESCE(SUM(jl.debitRial), 0) AS totalDebitRial,
            COALESCE(SUM(jl.creditRial), 0) AS totalCreditRial,
            EXISTS(
                SELECT 1
                FROM journal_entries reversal
                WHERE reversal.sourceType = 'REVERSAL'
                  AND reversal.sourceId = je.id
                  AND reversal.status = 'POSTED'
            ) AS isReversed
        FROM journal_entries je
        LEFT JOIN journal_lines jl ON jl.entryId = je.id
        WHERE :query = ''
           OR je.entryNo LIKE '%' || :query || '%'
           OR je.description LIKE '%' || :query || '%'
           OR EXISTS(
                SELECT 1
                FROM journal_lines searchedLine
                INNER JOIN accounts searchedAccount
                    ON searchedAccount.code = searchedLine.accountCode
                WHERE searchedLine.entryId = je.id
                  AND (
                    searchedLine.accountCode LIKE '%' || :query || '%'
                    OR searchedAccount.name LIKE '%' || :query || '%'
                  )
           )
        GROUP BY
            je.id,
            je.entryNo,
            je.entryEpochDay,
            je.description,
            je.sourceType
        ORDER BY je.entryEpochDay DESC, je.id DESC
        """,
    )
    fun observeJournals(query: String): Flow<List<JournalListRow>>

    @Query(
        """
        SELECT
            je.id AS entryId,
            je.entryNo AS entryNo,
            je.entryEpochDay AS entryEpochDay,
            je.description AS entryDescription,
            je.sourceType AS sourceType,
            je.sourceId AS sourceId,
            jl.id AS lineId,
            jl.accountCode AS accountCode,
            a.name AS accountName,
            jl.debitRial AS debitRial,
            jl.creditRial AS creditRial,
            jl.memo AS memo,
            EXISTS(
                SELECT 1
                FROM journal_entries reversal
                WHERE reversal.sourceType = 'REVERSAL'
                  AND reversal.sourceId = je.id
                  AND reversal.status = 'POSTED'
            ) AS isReversed
        FROM journal_entries je
        INNER JOIN journal_lines jl ON jl.entryId = je.id
        INNER JOIN accounts a ON a.code = jl.accountCode
        WHERE je.id = :entryId
        ORDER BY jl.id
        """,
    )
    fun observeJournalDetails(entryId: Long): Flow<List<JournalDetailRow>>

    @Query(
        """
        SELECT
            jl.id AS lineId,
            je.id AS entryId,
            je.entryNo AS entryNo,
            je.entryEpochDay AS entryEpochDay,
            je.description AS description,
            jl.debitRial AS debitRial,
            jl.creditRial AS creditRial
        FROM journal_lines jl
        INNER JOIN journal_entries je ON je.id = jl.entryId
        WHERE jl.accountCode = :accountCode
          AND je.status = 'POSTED'
        ORDER BY je.entryEpochDay, je.id, jl.id
        """,
    )
    fun observeLedger(accountCode: String): Flow<List<AccountLedgerRow>>

    @Query(
        """
        SELECT COALESCE(SUM(jl.debitRial - jl.creditRial), 0)
        FROM journal_lines jl
        INNER JOIN journal_entries je ON je.id = jl.entryId
        WHERE jl.accountCode = :accountCode AND je.status = 'POSTED'
        """,
    )
    fun observeBalanceRial(accountCode: String): Flow<Long>
}

data class AccountBalanceRow(
    val code: String,
    val name: String,
    val type: String,
    val isSystem: Boolean,
    val debitTurnoverRial: Long,
    val creditTurnoverRial: Long,
)

data class JournalListRow(
    val id: Long,
    val entryNo: String,
    val entryEpochDay: Long,
    val description: String,
    val sourceType: String,
    val totalDebitRial: Long,
    val totalCreditRial: Long,
    val isReversed: Boolean,
)

data class JournalDetailRow(
    val entryId: Long,
    val entryNo: String,
    val entryEpochDay: Long,
    val entryDescription: String,
    val sourceType: String,
    val sourceId: Long,
    val lineId: Long,
    val accountCode: String,
    val accountName: String,
    val debitRial: Long,
    val creditRial: Long,
    val memo: String,
    val isReversed: Boolean,
)

data class AccountLedgerRow(
    val lineId: Long,
    val entryId: Long,
    val entryNo: String,
    val entryEpochDay: Long,
    val description: String,
    val debitRial: Long,
    val creditRial: Long,
)

data class PurchaseSettlementRow(
    val journalEntryId: Long,
    val entryNo: String,
    val settlementEpochDay: Long,
    val amountRial: Long,
    val paymentMethod: String,
    val referenceNo: String,
    val notes: String,
    val isReversed: Boolean,
)

@Dao
interface PersonnelDao {
    @Insert
    suspend fun insertEmployee(entity: EmployeeEntity): Long

    @Update
    suspend fun updateEmployee(entity: EmployeeEntity): Int

    @Query("SELECT * FROM employees WHERE id = :id LIMIT 1")
    suspend fun employeeById(id: Long): EmployeeEntity?

    @Query("SELECT * FROM employees ORDER BY status, name")
    fun observeEmployees(): Flow<List<EmployeeEntity>>

    @Query("SELECT * FROM attendance ORDER BY workEpochDay DESC, id DESC")
    fun observeAttendance(): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE id = :id LIMIT 1")
    suspend fun attendanceById(id: Long): AttendanceEntity?

    @Insert
    suspend fun insertAttendance(entity: AttendanceEntity): Long

    @Update
    suspend fun updateAttendance(entity: AttendanceEntity): Int

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND workEpochDay BETWEEN :startEpochDay AND :endEpochDay ORDER BY workEpochDay")
    suspend fun attendanceInRange(employeeId: Long, startEpochDay: Long, endEpochDay: Long): List<AttendanceEntity>

    @Insert
    suspend fun insertLeave(entity: LeaveEntity): Long

    @Update
    suspend fun updateLeave(entity: LeaveEntity): Int

    @Query("SELECT * FROM leaves WHERE id = :id LIMIT 1")
    suspend fun leaveById(id: Long): LeaveEntity?

    @Query("SELECT * FROM leaves ORDER BY createdAtEpochMillis DESC, id DESC")
    fun observeLeaves(): Flow<List<LeaveEntity>>

    @Query("SELECT * FROM leaves WHERE status = 'PENDING' ORDER BY createdAtEpochMillis, id")
    fun observePendingLeaves(): Flow<List<LeaveEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM leaves WHERE employeeId = :employeeId AND status IN ('PENDING','APPROVED') AND id != :excludeId AND startEpochDay <= :endEpochDay AND endEpochDay >= :startEpochDay)")
    suspend fun hasLeaveOverlap(employeeId: Long, startEpochDay: Long, endEpochDay: Long, excludeId: Long = 0): Boolean

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId AND workEpochDay = :workEpochDay LIMIT 1")
    suspend fun attendanceByEmployeeDay(employeeId: Long, workEpochDay: Long): AttendanceEntity?

    @Query("SELECT * FROM employee_contracts WHERE employeeId = :employeeId ORDER BY startEpochDay DESC, id DESC")
    fun observeContracts(employeeId: Long): Flow<List<EmployeeContractEntity>>

    @Insert
    suspend fun insertContract(entity: EmployeeContractEntity): Long

    @Update
    suspend fun updateContract(entity: EmployeeContractEntity): Int

    @Query("SELECT * FROM employee_contracts WHERE id = :id LIMIT 1")
    suspend fun contractById(id: Long): EmployeeContractEntity?

    @Query("SELECT * FROM employee_advances WHERE employeeId = :employeeId ORDER BY advanceEpochDay DESC, id DESC")
    fun observeAdvances(employeeId: Long): Flow<List<EmployeeAdvanceEntity>>

    @Query("SELECT * FROM employee_advances WHERE status = 'OPEN' ORDER BY advanceEpochDay DESC, id DESC")
    fun observeOpenAdvances(): Flow<List<EmployeeAdvanceEntity>>

    @Insert
    suspend fun insertAdvance(entity: EmployeeAdvanceEntity): Long

    @Update
    suspend fun updateAdvance(entity: EmployeeAdvanceEntity): Int

    @Query("SELECT * FROM employee_advances WHERE id = :id LIMIT 1")
    suspend fun advanceById(id: Long): EmployeeAdvanceEntity?

    @Query("UPDATE employees SET status = 'INACTIVE', updatedAtEpochMillis = :now WHERE id = :id AND status = 'ACTIVE'")
    suspend fun deactivateEmployee(id: Long, now: Long): Int

    @Query("SELECT EXISTS(SELECT 1 FROM payroll_runs WHERE employeeId = :employeeId AND periodYear = :year AND periodMonth = :month)")
    suspend fun payrollExists(employeeId: Long, year: Int, month: Int): Boolean

    @Insert
    suspend fun insertPayroll(entity: PayrollRunEntity): Long

    @Query("""
        SELECT p.id, p.employeeId, e.name AS employeeName, p.periodYear, p.periodMonth,
               (p.baseSalaryRial + p.overtimeRial + p.bonusRial) AS grossPayRial,
               p.netPayRial, p.paymentEpochDay, p.paymentMethod, p.status
        FROM payroll_runs p
        INNER JOIN employees e ON e.id = p.employeeId
        ORDER BY p.periodYear DESC, p.periodMonth DESC, p.id DESC
    """)
    fun observePayrolls(): Flow<List<PayrollListRow>>

    @Query(
        """
        SELECT EXISTS(
            SELECT 1 FROM attendance
            WHERE employeeId = :employeeId
              AND workEpochDay BETWEEN :startEpochDay AND :endEpochDay
              AND status != 'LEAVE'
        )
        """,
    )
    suspend fun hasAttendanceConflict(employeeId: Long, startEpochDay: Long, endEpochDay: Long): Boolean

    @Query(
        """
        SELECT EXISTS(
            SELECT 1 FROM leaves
            WHERE employeeId = :employeeId
              AND status = 'APPROVED'
              AND startEpochDay <= :workEpochDay
              AND endEpochDay >= :workEpochDay
        )
        """,
    )
    suspend fun hasApprovedLeave(employeeId: Long, workEpochDay: Long): Boolean
}

data class PayrollListRow(
    val id: Long,
    val employeeId: Long,
    val employeeName: String,
    val periodYear: Int,
    val periodMonth: Int,
    val grossPayRial: Long,
    val netPayRial: Long,
    val paymentEpochDay: Long,
    val paymentMethod: String,
    val status: String,
)

/** Read-only source compatibility for pre-31 archive models; not part of AppDatabase. */
private interface LegacySalesArchiveQueries {
    @Query("SELECT COALESCE(SUM(totalRial-paidRial),0) FROM sales WHERE customerId=:customerId AND reversedAtEpochDay IS NULL AND totalRial>paidRial")
    suspend fun customerOutstandingRial(customerId: Long): Long

    @Query("SELECT COALESCE(SUM(totalRial-paidRial),0) FROM sales WHERE customerId=:customerId AND reversedAtEpochDay IS NULL AND totalRial>paidRial AND dueEpochDay IS NOT NULL AND dueEpochDay<:todayEpochDay")
    suspend fun customerOverdueRial(customerId: Long, todayEpochDay: Long): Long

    @Query(
        """
        SELECT mi.id AS menuItemId, mi.name AS name,
               COALESCE(SUM(CASE WHEN s.id IS NOT NULL THEN sl.quantityMicros ELSE 0 END),0) / 1000000 AS unitsSold,
               COALESCE(SUM(CASE WHEN s.id IS NOT NULL THEN sl.lineTotalRial ELSE 0 END),0) AS salesRial,
               COALESCE(SUM(CASE WHEN s.id IS NOT NULL THEN sl.costOfGoodsRial ELSE 0 END),0) AS costRial
        FROM menu_items mi
        LEFT JOIN sale_lines sl ON sl.menuItemId = mi.id
        LEFT JOIN sales s ON s.id = sl.saleId AND s.reversedAtEpochDay IS NULL
            AND s.saleEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        WHERE mi.isActive = 1
        GROUP BY mi.id, mi.name
        ORDER BY salesRial DESC, mi.name
        """,
    )
    fun observeMenuPerformance(fromEpochDay: Long, toEpochDay: Long): Flow<List<MenuPerformanceRow>>
    @Query("SELECT EXISTS(SELECT 1 FROM sales WHERE invoiceNo = :invoiceNo)")
    suspend fun invoiceExists(invoiceNo: String): Boolean

    @Query("SELECT * FROM customers WHERE id = :id AND isActive = 1 LIMIT 1")
    suspend fun activeCustomerById(id: Long): CustomerEntity?

    @Query("SELECT * FROM customers WHERE isActive = 1 ORDER BY name")
    fun observeActiveCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM sales WHERE id = :id LIMIT 1")
    suspend fun saleById(id: Long): SaleEntity?

    @Query("SELECT * FROM sale_payments WHERE id = :id LIMIT 1")
    suspend fun paymentById(id: Long): SalePaymentEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM sale_payments WHERE reversalOfPaymentId = :paymentId)")
    suspend fun paymentAlreadyReversed(paymentId: Long): Boolean

    @Query("SELECT COUNT(*) FROM sale_payments p WHERE p.saleId = :saleId AND p.reversalOfPaymentId IS NULL AND NOT EXISTS (SELECT 1 FROM sale_payments r WHERE r.reversalOfPaymentId = p.id)")
    suspend fun activeReceiptCount(saleId: Long): Long

    @Insert
    suspend fun insertPayment(entity: SalePaymentEntity): Long

    @Query("SELECT * FROM sale_payments WHERE saleId = :saleId ORDER BY paymentEpochDay DESC, id DESC")
    fun observePayments(saleId: Long): Flow<List<SalePaymentEntity>>

    @Query("UPDATE sales SET paidRial = :newPaidRial, paymentStatus = :status WHERE id = :saleId AND paidRial = :expectedPaidRial")
    suspend fun updatePaymentState(saleId: Long, expectedPaidRial: Long, newPaidRial: Long, status: String): Int

    @Insert
    suspend fun insertCustomer(entity: CustomerEntity): Long

    @Insert
    suspend fun insertSale(entity: SaleEntity): Long

    @Insert
    suspend fun insertLines(lines: List<SaleLineEntity>)

    @Query("SELECT * FROM sale_lines WHERE saleId = :saleId ORDER BY id")
    suspend fun linesBySale(saleId: Long): List<SaleLineEntity>

    @Query("UPDATE sales SET reversedAtEpochDay = :day, paymentStatus = 'REVERSED' WHERE id = :saleId AND reversedAtEpochDay IS NULL")
    suspend fun markSaleReversed(saleId: Long, day: Long): Int

    @Query(
        """
        SELECT id, invoiceNo, customerNameSnapshot AS customerName, saleEpochDay, dueEpochDay,
               totalRial, paidRial, paymentStatus, channel,
               COALESCE((SELECT SUM(costOfGoodsRial) FROM sale_lines sl WHERE sl.saleId = sales.id),0) AS costOfGoodsRial,
               CASE WHEN reversedAtEpochDay IS NULL THEN 0 ELSE 1 END AS reversed
        FROM sales
        WHERE :query = '' OR invoiceNo LIKE '%' || :query || '%'
           OR customerNameSnapshot LIKE '%' || :query || '%'
           OR channel LIKE '%' || :query || '%'
        ORDER BY saleEpochDay DESC, id DESC
        """,
    )
    fun observeSales(query: String): Flow<List<SaleListRow>>

    @Query("UPDATE sales SET replacementOfSaleId = :originalSaleId WHERE id = :replacementSaleId AND replacementOfSaleId IS NULL")
    suspend fun linkReplacement(replacementSaleId: Long, originalSaleId: Long): Int

    @Query(
        """
        SELECT id, invoiceNo, customerNameSnapshot AS customerName, saleEpochDay, dueEpochDay,
               totalRial, paidRial, paymentStatus, channel,
               COALESCE((SELECT SUM(costOfGoodsRial) FROM sale_lines sl WHERE sl.saleId = sales.id),0) AS costOfGoodsRial,
               CASE WHEN reversedAtEpochDay IS NULL THEN 0 ELSE 1 END AS reversed
        FROM sales
        WHERE saleEpochDay BETWEEN :fromEpochDay AND :toEpochDay
        ORDER BY saleEpochDay DESC, id DESC
        """
    )
    fun observeSalesInRange(fromEpochDay: Long, toEpochDay: Long): Flow<List<SaleListRow>>
}

data class SaleListRow(
    val id: Long,
    val invoiceNo: String,
    val customerName: String,
    val saleEpochDay: Long,
    val dueEpochDay: Long?,
    val totalRial: Long,
    val paidRial: Long,
    val paymentStatus: String,
    val channel: String,
    val costOfGoodsRial: Long,
    val reversed: Boolean,
)

data class MenuPerformanceRow(
    val menuItemId: Long,
    val name: String,
    val unitsSold: Long,
    val salesRial: Long,
    val costRial: Long,
)

@Dao
interface RecipeDao {
    @Insert
    suspend fun insertMenuItem(entity: MenuItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertIngredients(ingredients: List<RecipeIngredientEntity>)

    @Query("DELETE FROM recipe_ingredients WHERE menuItemId = :menuItemId")
    suspend fun clearIngredients(menuItemId: Long): Int

    @Query("SELECT * FROM menu_items WHERE isActive = 1 ORDER BY name")
    fun observeActiveMenuItems(): Flow<List<MenuItemEntity>>

    @Query(
        """SELECT mi.*, CAST(COUNT(ri.inventoryItemId) AS INTEGER) AS ingredientCount
        FROM menu_items mi
        LEFT JOIN recipe_ingredients ri ON ri.menuItemId = mi.id
        WHERE mi.isActive = 1
        GROUP BY mi.id
        ORDER BY mi.name""",
    )
    fun observeActiveMenuItemsWithCoverage(): Flow<List<MenuItemCoverageRow>>

    @Query("SELECT * FROM recipe_ingredients WHERE menuItemId = :menuItemId ORDER BY inventoryItemId")
    suspend fun ingredients(menuItemId: Long): List<RecipeIngredientEntity>

    @Query("SELECT ri.inventoryItemId, i.name AS inventoryName, i.unit, ri.quantityMicrosPerUnit FROM recipe_ingredients ri INNER JOIN inventory_items i ON i.id = ri.inventoryItemId WHERE ri.menuItemId = :menuItemId ORDER BY i.name")
    fun observeIngredientRows(menuItemId: Long): Flow<List<RecipeIngredientRow>>

    @Query("SELECT * FROM menu_items WHERE id = :id AND isActive = 1 LIMIT 1")
    suspend fun activeMenuItem(id: Long): MenuItemEntity?

    @Update
    suspend fun updateMenuItem(entity: MenuItemEntity): Int
}


data class RecipeIngredientRow(val inventoryItemId: Long, val inventoryName: String, val unit: String, val quantityMicrosPerUnit: Long)
data class MenuItemCoverageRow(val id: Long, val name: String, val category: String, val salePriceRial: Long, val isActive: Boolean, val createdAtEpochMillis: Long, val updatedAtEpochMillis: Long, val ingredientCount: Int)


@Dao
interface InventoryControlDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertCount(entity: InventoryCountEntity): Long

    @Query("SELECT * FROM inventory_counts ORDER BY createdAtEpochMillis DESC LIMIT :limit")
    fun observeRecentCounts(limit: Int = 100): Flow<List<InventoryCountEntity>>
}

@Dao
interface AuditLogDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: AuditLogEntity): Long

    @Query("SELECT * FROM audit_logs ORDER BY createdAtEpochMillis DESC LIMIT :limit")
    fun observeRecent(limit: Int = 200): Flow<List<AuditLogEntity>>
}

@Dao
interface SecurityDao {
    @Query("SELECT * FROM app_users ORDER BY isActive DESC, displayName")
    fun observeUsers(): Flow<List<AppUserEntity>>

    @Query("SELECT * FROM app_users WHERE id = :id LIMIT 1")
    suspend fun byId(id: Long): AppUserEntity?

    @Query("SELECT * FROM app_users WHERE username = :username COLLATE NOCASE LIMIT 1")
    suspend fun byUsername(username: String): AppUserEntity?

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: AppUserEntity): Long

    @Update
    suspend fun update(entity: AppUserEntity): Int

    @Query("UPDATE app_users SET isActive = 0, updatedAtEpochMillis = :now WHERE id = :id AND role != 'OWNER'")
    suspend fun deactivate(id: Long, now: Long): Int

    @Query("SELECT u.* FROM app_session s INNER JOIN app_users u ON u.id = s.currentUserId WHERE s.singletonId = 1 LIMIT 1")
    fun observeCurrentUser(): Flow<AppUserEntity?>

    @Query("SELECT u.* FROM app_session s INNER JOIN app_users u ON u.id = s.currentUserId WHERE s.singletonId = 1 LIMIT 1")
    suspend fun currentUser(): AppUserEntity?

    @Query("SELECT COUNT(*) FROM app_users")
    suspend fun userCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setSession(entity: AppSessionEntity)

    @Query("DELETE FROM app_session")
    suspend fun clearSession()
}

@Dao
interface AssetDao {
    @Insert suspend fun insertAsset(entity: FixedAssetEntity): Long
    @Update suspend fun updateAsset(entity: FixedAssetEntity): Int
    @Query("SELECT * FROM fixed_assets WHERE id=:id LIMIT 1") suspend fun assetById(id: Long): FixedAssetEntity?
    @Query("SELECT * FROM fixed_assets ORDER BY status, name") fun observeAssets(): Flow<List<FixedAssetEntity>>
    @Query("UPDATE fixed_assets SET status='DISPOSED', updatedAtEpochMillis=:now WHERE id=:id AND status='ACTIVE'") suspend fun disposeAsset(id: Long, now: Long): Int
    @Query("SELECT EXISTS(SELECT 1 FROM asset_depreciations WHERE assetId=:assetId AND periodYear=:year AND periodMonth=:month)") suspend fun depreciationExists(assetId: Long, year: Int, month: Int): Boolean
    @Insert suspend fun insertDepreciation(entity: AssetDepreciationEntity): Long
    @Query("UPDATE fixed_assets SET accumulatedDepreciationRial=accumulatedDepreciationRial+:amount, updatedAtEpochMillis=:now WHERE id=:id AND accumulatedDepreciationRial+:amount <= purchaseCostRial-salvageValueRial") suspend fun addDepreciation(id: Long, amount: Long, now: Long): Int
    @Query("""
      SELECT d.id, a.name AS assetName, d.periodYear, d.periodMonth, d.amountRial
      FROM asset_depreciations d INNER JOIN fixed_assets a ON a.id=d.assetId
      ORDER BY d.periodYear DESC, d.periodMonth DESC, d.id DESC
    """) fun observeDepreciations(): Flow<List<AssetDepreciationRow>>
}

data class AssetDepreciationRow(val id:Long,val assetName:String,val periodYear:Int,val periodMonth:Int,val amountRial:Long)

/** Pre-31 CRM query declarations retained only so old model sources remain readable. */
private interface LegacyCrmArchiveQueries {
    @Query("""
        SELECT c.id, c.name, c.phone,
               COALESCE((SELECT SUM(t.pointsDelta) FROM loyalty_transactions t WHERE t.customerId=c.id),0) AS points,
               COALESCE((SELECT SUM(s.totalRial) FROM sales s WHERE s.customerId=c.id AND s.reversedAtEpochDay IS NULL),0) AS lifetimeValueRial,
               COALESCE((SELECT MAX(s.saleEpochDay) FROM sales s WHERE s.customerId=c.id AND s.reversedAtEpochDay IS NULL),0) AS lastSaleEpochDay,
               COALESCE((SELECT COUNT(*) FROM sales s WHERE s.customerId=c.id AND s.reversedAtEpochDay IS NULL),0) AS invoiceCount,
               CAST(COALESCE((SELECT AVG(s.totalRial) FROM sales s WHERE s.customerId=c.id AND s.reversedAtEpochDay IS NULL),0) AS INTEGER) AS averageTicketRial
        FROM customers c WHERE c.isActive=1 ORDER BY points DESC, lifetimeValueRial DESC, c.name
    """)
    fun observeCustomerSummaries(): Flow<List<CrmCustomerRow>>

    @Insert suspend fun insertTransaction(entity: LoyaltyTransactionEntity): Long
    @Query("SELECT * FROM loyalty_transactions WHERE customerId=:customerId ORDER BY createdAtEpochMillis DESC, id DESC")
    fun observeTransactions(customerId: Long): Flow<List<LoyaltyTransactionEntity>>

    @Insert suspend fun insertFollowUp(entity: CustomerFollowUpEntity): Long
    @Query("SELECT f.*, c.name AS customerName FROM customer_followups f INNER JOIN customers c ON c.id=f.customerId ORDER BY f.isDone, f.dueEpochDay, f.id DESC")
    fun observeFollowUps(): Flow<List<CrmFollowUpRow>>
    @Query("UPDATE customer_followups SET isDone=1, completedAtEpochMillis=:now WHERE id=:id AND isDone=0")
    suspend fun completeFollowUp(id: Long, now: Long): Int
}

data class CrmCustomerRow(
    val id: Long,
    val name: String,
    val phone: String,
    val points: Long,
    val lifetimeValueRial: Long,
    val lastSaleEpochDay: Long,
    val invoiceCount: Long,
    val averageTicketRial: Long,
)
data class CrmFollowUpRow(val id: Long, val customerId: Long, val title: String, val dueEpochDay: Long, val notes: String, val isDone: Boolean, val createdAtEpochMillis: Long, val completedAtEpochMillis: Long?, val customerName: String)

@Dao
interface AlertDao {
    @Query("SELECT * FROM app_alerts WHERE isDismissed=0 ORDER BY CASE severity WHEN 'HIGH' THEN 0 WHEN 'MEDIUM' THEN 1 ELSE 2 END, COALESCE(dueEpochDay, 9223372036854775807), updatedAtEpochMillis DESC")
    fun observeVisible(): Flow<List<AppAlertEntity>>

    @Query("""
        INSERT INTO app_alerts(sourceType,sourceId,title,message,severity,dueEpochDay,isRead,isDismissed,createdAtEpochMillis,updatedAtEpochMillis)
        VALUES(:sourceType,:sourceId,:title,:message,:severity,:dueEpochDay,0,0,:now,:now)
        ON CONFLICT(sourceType,sourceId) DO UPDATE SET
            title=excluded.title,
            message=excluded.message,
            severity=excluded.severity,
            dueEpochDay=excluded.dueEpochDay,
            updatedAtEpochMillis=excluded.updatedAtEpochMillis
    """)
    suspend fun upsertGenerated(sourceType: String, sourceId: Long, title: String, message: String, severity: String, dueEpochDay: Long?, now: Long)

    @Query("SELECT sourceType, sourceId FROM app_alerts")
    suspend fun generatedKeys(): List<AlertKeyRow>

    @Query("DELETE FROM app_alerts WHERE sourceType=:sourceType AND sourceId=:sourceId")
    suspend fun deleteGenerated(sourceType: String, sourceId: Long)

    @Query("UPDATE app_alerts SET isRead=1, updatedAtEpochMillis=:now WHERE id=:id")
    suspend fun markRead(id: Long, now: Long): Int

    @Query("UPDATE app_alerts SET isDismissed=1, updatedAtEpochMillis=:now WHERE id=:id")
    suspend fun dismiss(id: Long, now: Long): Int

    @Query("DELETE FROM app_alerts WHERE isDismissed=1")
    suspend fun clearDismissed(): Int

    @Query("""
        SELECT p.id, p.invoiceNo, sp.name AS supplierName, p.dueEpochDay,
               (p.totalRial-p.paidRial) AS outstandingRial
        FROM purchases p
        INNER JOIN suppliers sp ON sp.id=p.supplierId
        WHERE p.paymentStatus IN ('UNPAID','PARTIAL') AND p.dueEpochDay<=:todayEpochDay
        ORDER BY p.dueEpochDay
    """)
    suspend fun overduePurchases(todayEpochDay: Long): List<OverduePurchaseAlertRow>

    @Query("SELECT * FROM inventory_items WHERE isActive=1 AND alertEnabled=1 AND stockMicros<=alertThresholdMicros ORDER BY stockMicros, name")
    suspend fun lowStock(): List<InventoryItemEntity>
}

data class AlertKeyRow(val sourceType: String, val sourceId: Long)
data class OverdueFollowUpAlertRow(val id: Long, val title: String, val dueEpochDay: Long, val customerName: String)
