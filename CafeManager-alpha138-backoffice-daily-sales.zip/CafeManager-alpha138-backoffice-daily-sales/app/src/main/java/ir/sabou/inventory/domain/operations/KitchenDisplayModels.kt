package ir.sabou.inventory.domain.operations

enum class KitchenTicketStatus { QUEUED, PREPARING, READY, SERVED, CANCELLED }

data class KitchenTicket(
    val id: Long, val orderNo: String, val station: String, val itemName: String,
    val quantity: Int, val createdAtEpochMillis: Long,
    val status: KitchenTicketStatus = KitchenTicketStatus.QUEUED, val priority: Int = 0,
) {
    fun transition(next: KitchenTicketStatus): KitchenTicket {
        val allowed = when (status) {
            KitchenTicketStatus.QUEUED -> next == KitchenTicketStatus.PREPARING || next == KitchenTicketStatus.CANCELLED
            KitchenTicketStatus.PREPARING -> next == KitchenTicketStatus.READY || next == KitchenTicketStatus.CANCELLED
            KitchenTicketStatus.READY -> next == KitchenTicketStatus.SERVED
            KitchenTicketStatus.SERVED, KitchenTicketStatus.CANCELLED -> false
        }
        require(allowed) { "تغییر وضعیت سفارش آشپزخانه مجاز نیست." }
        return copy(status = next)
    }
}

object KitchenQueue {
    fun prioritize(tickets: List<KitchenTicket>): List<KitchenTicket> = tickets
        .filter { it.status == KitchenTicketStatus.QUEUED || it.status == KitchenTicketStatus.PREPARING }
        .sortedWith(compareByDescending<KitchenTicket> { it.priority }.thenBy { it.createdAtEpochMillis })
}
