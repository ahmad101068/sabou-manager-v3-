package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_sales_summaries",
    indices = [Index(value = ["businessEpochDay"], unique = true)],
)
data class DailySalesSummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val businessEpochDay: Long,
    val grossSalesRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netSalesRial: Long,
    val theoreticalCostRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val notes: String,
    val journalEntryId: Long?,
    val costJournalEntryId: Long?,
    val isLegacyArchive: Boolean = false,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "daily_sales_menu_lines",
    foreignKeys = [
        ForeignKey(
            entity = DailySalesSummaryEntity::class,
            parentColumns = ["id"],
            childColumns = ["summaryId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("summaryId"), Index("menuItemId")],
)
data class DailySalesMenuLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val summaryId: Long,
    val menuItemId: Long?,
    val menuItemNameSnapshot: String,
    val quantityMicros: Long,
    val grossSalesRial: Long,
    val theoreticalCostRial: Long,
)
