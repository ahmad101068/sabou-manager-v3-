package ir.sabou.inventory.domain.operations

import ir.sabou.inventory.domain.sales.Reservation
import ir.sabou.inventory.domain.sales.RestaurantTable
import ir.sabou.inventory.domain.sales.OpenTableOrderDraft
import ir.sabou.inventory.domain.sales.TableCheckoutDraft
import ir.sabou.inventory.domain.sales.TableOrder
import ir.sabou.inventory.domain.sales.TableOrderItemDraft
import ir.sabou.inventory.domain.sales.TableStatus
import ir.sabou.inventory.domain.sales.BillSplitMode
import ir.sabou.inventory.domain.sales.CashShift
import ir.sabou.inventory.domain.sales.VoidOrderLineDraft
import ir.sabou.inventory.core.MoneyRial
import kotlinx.coroutines.flow.Flow

interface RestaurantOperationsRepository {
    val tables: Flow<List<RestaurantTable>>
    val reservations: Flow<List<Reservation>>
    val kitchenTickets: Flow<List<KitchenTicket>>
    val shifts: Flow<List<PlannedShift>>
    val approvals: Flow<List<ApprovalRequest>>
    val openOrders: Flow<List<TableOrder>>
    val cashShifts: Flow<List<CashShift>>
    suspend fun addTable(label: String, capacity: Int, zone: String): Long
    suspend fun transitionTable(id: Long, status: TableStatus, orderId: Long? = null)
    suspend fun addReservation(value: Reservation): Long
    suspend fun addKitchenTicket(orderNo: String, station: String, itemName: String, quantity: Int, priority: Int): Long
    suspend fun transitionKitchenTicket(id: Long, status: KitchenTicketStatus)
    suspend fun planShift(demand: ShiftDemand, staff: List<StaffAvailability>): Int
    suspend fun requestApproval(type: String, entityId: Long, amountRial: Long, requestedBy: String): Long
    suspend fun reviewApproval(id: Long, approve: Boolean, by: String, note: String = "")
    suspend fun openTableOrder(draft: OpenTableOrderDraft): Long
    suspend fun addTableOrderItem(orderId: Long, draft: TableOrderItemDraft): Long
    suspend fun transferTableOrder(orderId: Long, targetTableId: Long)
    suspend fun mergeTableOrders(sourceOrderId: Long, targetOrderId: Long)
    suspend fun checkoutTableOrder(orderId: Long, draft: TableCheckoutDraft): Long
    suspend fun transferTableOrderLine(lineId: Long, targetOrderId: Long)
    suspend fun voidTableOrderLine(lineId: Long, draft: VoidOrderLineDraft)
    suspend fun createBillSplits(orderId: Long, mode: BillSplitMode): Int
    suspend fun checkoutBillSplit(splitId: Long, draft: TableCheckoutDraft): Long
    suspend fun openCashShift(openingFloat: MoneyRial, note: String = ""): Long
    suspend fun closeCashShift(countedCash: MoneyRial, note: String = "")
}
