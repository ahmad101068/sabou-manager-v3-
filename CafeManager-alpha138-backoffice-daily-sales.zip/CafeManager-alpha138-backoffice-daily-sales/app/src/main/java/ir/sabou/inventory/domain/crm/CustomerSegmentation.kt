package ir.sabou.inventory.domain.crm

enum class CustomerSegment(val title: String) {
    NEW("جدید"),
    REGULAR("عادی"),
    LOYAL("وفادار"),
    VIP("ویژه"),
    AT_RISK("در معرض ریزش"),
    DORMANT("غیرفعال"),
}

object CustomerSegmentation {
    fun classify(
        invoiceCount: Long,
        lifetimeValueRial: Long,
        lastSaleEpochDay: Long,
        todayEpochDay: Long,
    ): CustomerSegment {
        if (invoiceCount <= 0L || lastSaleEpochDay <= 0L) return CustomerSegment.NEW
        val inactiveDays = (todayEpochDay - lastSaleEpochDay).coerceAtLeast(0L)
        return when {
            inactiveDays >= 90L -> CustomerSegment.DORMANT
            inactiveDays >= 45L && invoiceCount >= 2L -> CustomerSegment.AT_RISK
            invoiceCount >= 10L || lifetimeValueRial >= 100_000_000L -> CustomerSegment.VIP
            invoiceCount >= 4L -> CustomerSegment.LOYAL
            invoiceCount == 1L -> CustomerSegment.NEW
            else -> CustomerSegment.REGULAR
        }
    }
}
