package ir.sabou.inventory.data.repository

import ir.sabou.inventory.domain.operations.SyncTransport
import ir.sabou.inventory.domain.operations.SyncMetrics
import ir.sabou.inventory.domain.operations.SyncMetricsCalculator

data class SyncRunResult(val uploaded: Int, val conflicts: Int, val rejected: Int, val metrics: SyncMetrics = SyncMetrics(uploaded, conflicts, rejected, 0))

class SyncCoordinator(
    private val repository: LocalSyncRepository,
    private val transport: SyncTransport,
) {
    suspend fun runOnce(limit: Int = 50): SyncRunResult {
        val started = System.currentTimeMillis()
        val batch = repository.nextBatch(limit)
        if (batch.changes.isEmpty()) return SyncRunResult(0, 0, 0)
        val result = transport.upload(batch.changes)
        result.accepted.forEach { repository.markSynced(it) }
        result.conflicts.forEach { repository.markConflict(it, "تعارض در سرویس همگام‌سازی") }
        result.rejected.forEach { repository.markRejected(it, "تغییر توسط سرویس همگام‌سازی رد شد") }
        return SyncRunResult(result.accepted.size, result.conflicts.size, result.rejected.size, SyncMetricsCalculator.from(result,(System.currentTimeMillis()-started).coerceAtLeast(0)))
    }
}
