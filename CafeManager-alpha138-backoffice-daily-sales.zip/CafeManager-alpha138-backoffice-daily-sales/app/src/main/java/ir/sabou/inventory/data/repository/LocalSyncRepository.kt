package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.SyncChangeEntity
import ir.sabou.inventory.domain.operations.SyncChangeType
import ir.sabou.inventory.domain.operations.SyncConflictResolver
import ir.sabou.inventory.domain.operations.SyncEnvelope
import ir.sabou.inventory.domain.operations.SyncState
import ir.sabou.inventory.domain.operations.SyncBatch
import ir.sabou.inventory.domain.operations.SyncBatchPlanner
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalSyncRepository(private val database: AppDatabase) {
    private val dao get() = database.syncDao()

    val changes: Flow<List<SyncEnvelope>> = dao.observeAll().map { rows -> rows.map { it.toEnvelope() } }

    suspend fun enqueue(envelope: SyncEnvelope): Long {
        val valid = envelope.validated()
        return database.withTransaction {
            require(dao.byChangeId(valid.changeId) == null) { "این تغییر قبلاً در صف ثبت شده است." }
            dao.insert(SyncChangeEntity(changeId = valid.changeId, entityType = valid.entityType, entityId = valid.entityId, changeType = valid.type.name, deviceId = valid.deviceId, occurredAtEpochMillis = valid.occurredAtEpochMillis, revision = valid.revision, payloadVersion = valid.payloadVersion, payload = valid.payload, payloadHash = valid.payloadHash, state = valid.state.name))
        }
    }

    suspend fun markSynced(changeId: String) = updateState(changeId, SyncState.SYNCED, "")
    suspend fun markConflict(changeId: String, error: String) = updateState(changeId, SyncState.CONFLICT, error.trim())
    suspend fun markRejected(changeId: String, error: String) = updateState(changeId, SyncState.REJECTED, error.trim())

    suspend fun nextBatch(limit: Int = 50): SyncBatch = SyncBatchPlanner.plan(dao.pending(limit).map { it.toEnvelope() }, limit)

    suspend fun purgeSyncedBefore(beforeMillis: Long): Int {
        require(beforeMillis > 0) { "زمان پاک‌سازی نامعتبر است." }
        return dao.deleteSyncedBefore(beforeMillis)
    }

    suspend fun resolveConflict(local: SyncEnvelope, remote: SyncEnvelope): SyncEnvelope {
        val winner = SyncConflictResolver.choose(local, remote)
        markSynced(winner.changeId)
        return winner
    }

    private suspend fun updateState(changeId: String, state: SyncState, error: String) {
        val current = dao.byChangeId(changeId) ?: error("تغییر همگام‌سازی پیدا نشد.")
        check(dao.update(current.copy(state = state.name, lastError = error)) == 1)
    }

    private fun SyncChangeEntity.toEnvelope() = SyncEnvelope(changeId = changeId, entityType = entityType, entityId = entityId, type = runCatching { SyncChangeType.valueOf(changeType) }.getOrDefault(SyncChangeType.UPDATE), deviceId = deviceId, occurredAtEpochMillis = occurredAtEpochMillis, revision = revision, payloadVersion = payloadVersion, payload = payload, payloadHash = payloadHash, state = runCatching { SyncState.valueOf(state) }.getOrDefault(SyncState.PENDING))
}
