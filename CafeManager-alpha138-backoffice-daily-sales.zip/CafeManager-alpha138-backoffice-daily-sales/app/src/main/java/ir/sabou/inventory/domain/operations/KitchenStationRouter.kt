package ir.sabou.inventory.domain.operations

object KitchenStationRouter {
    fun stationFor(category: String): String {
        val normalized = category.trim().lowercase()
        return when {
            normalized.contains("نوش") || normalized.contains("دسر") -> "نوشیدنی و دسر"
            normalized.contains("سالاد") || normalized.contains("پیش") || normalized.contains("سوپ") -> "آماده‌سازی سرد"
            normalized.contains("کباب") || normalized.contains("گریل") || normalized.contains("جوجه") -> "گریل و کباب"
            normalized.contains("برنج") || normalized.contains("چلو") || normalized.contains("خورش") -> "آشپزخانه گرم"
            else -> "آشپزخانه اصلی"
        }
    }
}
