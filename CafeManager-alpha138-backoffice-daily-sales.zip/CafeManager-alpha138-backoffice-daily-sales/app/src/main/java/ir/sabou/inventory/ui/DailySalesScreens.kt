package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.sales.DailyMenuSaleDraft

@Composable
fun DailySalesScreen(
    state: DailySalesUiState,
    onSearch: (String) -> Unit,
    onPost: (Long, Long, Long, Long, Long, Long, Long, String, List<DailyMenuSaleDraft>, () -> Unit) -> Unit,
    onSetReportRange: (Long, Long) -> Unit,
    onBack: () -> Unit,
) {
    var showEntry by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    Scaffold(
        topBar = { ProfessionalTopBar("فروش روزانه صندوق", "ورود دستی خروجی POS؛ بدون مشتری، میز و آشپزخانه", onBack) },
        floatingActionButton = { Button(onClick = { showEntry = true }, enabled = !state.busy) { Text("ثبت فروش روز") } },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                PremiumHero("فروش ۳۰ روز", formatMoney(state.activeSalesRial), "سود ناخالص ${formatMoney(state.grossProfitRial)}")
            }
            item {
                OutlinedTextField(value = search, onValueChange = { search = it; onSearch(it) }, label = { Text("جست‌وجوی یادداشت یا تاریخ") }, modifier = Modifier.fillMaxWidth())
            }
            item { OutlinedButton(onClick = { showReport = true }, modifier = Modifier.fillMaxWidth()) { Text("گزارش بازه‌ای و مهندسی منو") } }
            if (state.sales.isEmpty()) item { EmptyStatePanel("هنوز فروش روزانه‌ای ثبت نشده", "خروجی روز صندوق را بر اساس آیتم‌های منو وارد کنید.") }
            items(state.sales, key = { it.id }) { sale ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(epochDayToPersian(sale.businessEpochDay).display(), fontWeight = FontWeight.ExtraBold)
                            Text(formatMoney(sale.netSalesRial), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Text("فروش ناخالص ${formatMoney(sale.grossSalesRial)} · بهای نظری ${formatMoney(sale.theoreticalCostRial)}")
                        Text("نقد ${formatMoney(sale.cashRial)} · کارت ${formatMoney(sale.cardRial)} · حواله ${formatMoney(sale.transferRial)}", style = MaterialTheme.typography.bodySmall)
                        if (sale.isLegacyArchive) Text("آرشیو تبدیل‌شده از نسخه قدیمی", color = MaterialTheme.colorScheme.tertiary)
                        if (sale.notes.isNotBlank()) Text(sale.notes, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    if (showEntry) DailySalesEntryDialog(state.menuItems, onDismiss = { showEntry = false }, onSave = onPost)
    if (showReport) DailySalesReportDialog(state, onDismiss = { showReport = false }, onApply = onSetReportRange)
}

@Composable
private fun DailySalesEntryDialog(
    menuItems: List<MenuItem>,
    onDismiss: () -> Unit,
    onSave: (Long, Long, Long, Long, Long, Long, Long, String, List<DailyMenuSaleDraft>, () -> Unit) -> Unit,
) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var discount by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    var tax by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("") }
    var card by remember { mutableStateOf("") }
    var transfer by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val quantities = remember { mutableStateMapOf<Long, String>() }
    val amounts = remember { mutableStateMapOf<Long, String>() }
    val lines = menuItems.mapNotNull { menu ->
        val quantity = runCatching { parseQuantity(quantities[menu.id].orEmpty()).value }.getOrDefault(0)
        if (quantity <= 0) null else DailyMenuSaleDraft(menu.id, quantity, parseMoneyInputOrZero(amounts[menu.id].orEmpty()))
    }
    val gross = lines.sumOf { it.grossSalesRial }
    val net = gross - parseMoneyInputOrZero(discount) + parseMoneyInputOrZero(service) + parseMoneyInputOrZero(tax)
    val paid = parseMoneyInputOrZero(cash) + parseMoneyInputOrZero(card) + parseMoneyInputOrZero(transfer)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت خروجی روزانه صندوق") },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 610.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item { PersianDateField("روز فروش", day, { day = it }) }
                item { Text("آیتم‌های فروخته‌شده", fontWeight = FontWeight.ExtraBold) }
                items(menuItems, key = { it.id }) { menu ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${menu.name} · ${menu.category}", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(quantities[menu.id].orEmpty(), { quantities[menu.id] = it }, label = { Text("تعداد") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                                OutlinedTextField(amounts[menu.id].orEmpty(), { amounts[menu.id] = formatMoneyInput(it) }, label = { Text("فروش کل") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            }
                        }
                    }
                }
                item { HorizontalDivider() }
                item { OutlinedTextField(discount, { discount = formatMoneyInput(it) }, label = { Text("تخفیف کل") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(service, { service = formatMoneyInput(it) }, label = { Text("حق سرویس") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(tax, { tax = formatMoneyInput(it) }, label = { Text("مالیات و عوارض") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { Text("تفکیک دریافتی صندوق", fontWeight = FontWeight.ExtraBold) }
                item { OutlinedTextField(cash, { cash = formatMoneyInput(it) }, label = { Text("نقد") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(card, { card = formatMoneyInput(it) }, label = { Text("کارتخوان") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(transfer, { transfer = formatMoneyInput(it) }, label = { Text("حواله") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { Text("فروش خالص ${formatMoney(net)} · دریافتی ${formatMoney(paid)}", fontWeight = FontWeight.Bold, color = if (net == paid) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
                item { OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") }, modifier = Modifier.fillMaxWidth()) }
                error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(onClick = {
                when {
                    menuItems.isEmpty() -> error = "ابتدا منو و رسپی‌ها را تعریف کنید."
                    lines.isEmpty() -> error = "تعداد فروش حداقل یک آیتم را وارد کنید."
                    lines.any { it.grossSalesRial <= 0 } -> error = "فروش کل هر آیتم باید بیشتر از صفر باشد."
                    net < 0 -> error = "فروش خالص نمی‌تواند منفی باشد."
                    paid != net -> error = "جمع نقد، کارت و حواله باید با فروش خالص برابر باشد."
                    else -> onSave(day, parseMoneyInputOrZero(discount), parseMoneyInputOrZero(service), parseMoneyInputOrZero(tax), parseMoneyInputOrZero(cash), parseMoneyInputOrZero(card), parseMoneyInputOrZero(transfer), notes, lines, onDismiss)
                }
            }) { Text("ثبت و صدور سند") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DailySalesReportDialog(state: DailySalesUiState, onDismiss: () -> Unit, onApply: (Long, Long) -> Unit) {
    var from by remember { mutableLongStateOf(state.reportFromEpochDay) }
    var to by remember { mutableLongStateOf(state.reportToEpochDay) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("گزارش فروش تجمیعی") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            PersianDateField("از تاریخ", from, { from = it })
            PersianDateField("تا تاریخ", to, { to = it })
            state.report?.let {
                Text("روزهای ثبت‌شده: ${it.dayCount}")
                Text("فروش خالص: ${formatMoney(it.salesRial)}")
                Text("بهای تمام‌شده: ${formatMoney(it.costOfGoodsRial)}")
                Text("سود ناخالص: ${formatMoney(it.grossProfitRial)}", fontWeight = FontWeight.ExtraBold)
            }
        } },
        confirmButton = { Button(onClick = { onApply(from, to) }) { Text("اعمال بازه") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}
