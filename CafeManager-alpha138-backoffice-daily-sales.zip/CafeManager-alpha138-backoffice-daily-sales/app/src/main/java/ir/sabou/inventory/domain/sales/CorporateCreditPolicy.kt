package ir.sabou.inventory.domain.sales

data class CorporateCreditPolicy(
    val customerId: Long,
    val creditLimitRial: Long,
    val settlementDays: Int = 12,
    val blockOnOverdue: Boolean = true,
) {
    fun validated(): CorporateCreditPolicy {
        require(customerId > 0) { "مشتری شرکتی معتبر نیست." }
        require(creditLimitRial >= 0) { "سقف اعتبار نمی‌تواند منفی باشد." }
        require(settlementDays in 1..365) { "دوره تسویه معتبر نیست." }
        return this
    }
}

data class CorporateCreditDecision(val allowed: Boolean, val remainingCreditRial: Long, val reason: String)

object CorporateCreditCalculator {
    fun decide(policy: CorporateCreditPolicy, currentOutstandingRial: Long, newSaleRial: Long, overdueRial: Long): CorporateCreditDecision {
        val valid = policy.validated()
        require(currentOutstandingRial >= 0 && newSaleRial >= 0 && overdueRial >= 0) { "مانده اعتبار معتبر نیست." }
        val remaining = (valid.creditLimitRial - currentOutstandingRial).coerceAtLeast(0L)
        if (valid.blockOnOverdue && overdueRial > 0) return CorporateCreditDecision(false, remaining, "مطالبات سررسیدشده تسویه نشده است.")
        if (newSaleRial > remaining) return CorporateCreditDecision(false, remaining, "فروش از سقف اعتبار مشتری بیشتر می‌شود.")
        return CorporateCreditDecision(true, remaining - newSaleRial, "فروش در سقف اعتبار مجاز است.")
    }
}
