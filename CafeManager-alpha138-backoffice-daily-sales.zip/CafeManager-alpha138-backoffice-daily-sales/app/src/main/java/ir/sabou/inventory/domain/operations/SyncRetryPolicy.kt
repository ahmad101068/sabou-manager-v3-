package ir.sabou.inventory.domain.operations

import kotlin.math.min

data class SyncRetryDecision(val canRetry: Boolean, val delayMillis: Long, val reason: String)

object SyncRetryPolicy {
    fun decide(attempt: Int, nowMillis: Long, lastAttemptMillis: Long, baseDelayMillis: Long = 5_000L, maxDelayMillis: Long = 15 * 60_000L): SyncRetryDecision {
        require(attempt >= 0) { "تعداد تلاش نامعتبر است." }
        require(baseDelayMillis > 0 && maxDelayMillis >= baseDelayMillis) { "بازه تأخیر نامعتبر است." }
        if (attempt >= 8) return SyncRetryDecision(false, 0, "حداکثر تلاش مجاز تکمیل شده است.")
        val exponent = 1L shl attempt
        val delay = min(maxDelayMillis, baseDelayMillis * exponent)
        val elapsed = (nowMillis - lastAttemptMillis).coerceAtLeast(0)
        return SyncRetryDecision(elapsed >= delay, (delay - elapsed).coerceAtLeast(0), "retry پس از backoff نمایی")
    }
}
