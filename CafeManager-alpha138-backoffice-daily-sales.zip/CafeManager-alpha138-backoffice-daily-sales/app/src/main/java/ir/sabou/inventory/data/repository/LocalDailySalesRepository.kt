package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.DailySalesMenuLineEntity
import ir.sabou.inventory.data.db.DailySalesSummaryEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryLotConsumptionEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.recipe.MenuEngineeringCalculator
import ir.sabou.inventory.domain.recipe.MenuPerformanceInput
import ir.sabou.inventory.domain.sales.DailySalesDraft
import ir.sabou.inventory.domain.sales.DailySalesItem
import ir.sabou.inventory.domain.sales.DailySalesReport
import ir.sabou.inventory.domain.sales.DailySalesRepository
import java.math.BigInteger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class LocalDailySalesRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val syncRecorder: SyncRecorder? = null,
    private val clock: () -> Long = System::currentTimeMillis,
) : DailySalesRepository {
    override suspend fun post(draft: DailySalesDraft): Long {
        authorizer.require("SALES")
        require(draft.businessEpochDay > 0) { "تاریخ فروش معتبر نیست." }
        require(draft.lines.isNotEmpty()) { "حداقل یک آیتم از منو وارد کنید." }
        require(draft.lines.all { it.menuItemId > 0 && it.quantityMicros > 0 && it.grossSalesRial >= 0 }) { "اطلاعات ردیف‌های فروش ناقص است." }
        require(draft.lines.map { it.menuItemId }.distinct().size == draft.lines.size) { "هر آیتم منو باید فقط یک‌بار در فروش روزانه ثبت شود." }
        require(listOf(draft.discountRial, draft.serviceRial, draft.taxRial, draft.cashRial, draft.cardRial, draft.transferRial).all { it >= 0 }) { "مبالغ نمی‌توانند منفی باشند." }
        val now = clock()
        return database.withTransaction {
            require(!database.dailySalesDao().dayExists(draft.businessEpochDay)) { "فروش این روز قبلاً ثبت شده است؛ برای جلوگیری از ثبت تکراری، همان روز را دوباره وارد نکنید." }
            val gross = draft.lines.fold(0L) { total, line -> SignedLongMath.add(total, line.grossSalesRial) }
            require(gross > 0) { "فروش ناخالص باید بیشتر از صفر باشد." }
            require(draft.discountRial <= gross) { "تخفیف نمی‌تواند از فروش ناخالص بیشتر باشد." }
            val productRevenue = SignedLongMath.subtract(gross, draft.discountRial)
            val net = SignedLongMath.add(SignedLongMath.add(productRevenue, draft.serviceRial), draft.taxRial)
            val payments = SignedLongMath.add(SignedLongMath.add(draft.cashRial, draft.cardRial), draft.transferRial)
            require(payments == net) { "جمع روش‌های پرداخت باید دقیقاً با فروش خالص برابر باشد." }

            data class Consumption(val item: InventoryItemEntity, val quantity: Long, val cost: Long)
            data class PreparedLine(val menuId: Long, val name: String, val quantity: Long, val gross: Long, val cost: Long)
            val consumptions = mutableListOf<Consumption>()
            val preparedLines = draft.lines.map { line ->
                val menu = database.recipeDao().activeMenuItem(line.menuItemId) ?: error("آیتم منوی انتخاب‌شده فعال نیست.")
                val ingredients = database.recipeDao().ingredients(menu.id)
                require(ingredients.isNotEmpty()) { "برای «${menu.name}» رسپی کامل ثبت نشده است." }
                var lineCost = 0L
                ingredients.forEach { ingredient ->
                    val item = database.inventoryDao().activeById(ingredient.inventoryItemId) ?: error("یکی از مواد اولیه «${menu.name}» فعال نیست.")
                    val needed = mulDiv(ingredient.quantityMicrosPerUnit, line.quantityMicros, 1_000_000L)
                    require(needed > 0) { "مصرف محاسبه‌شده برای ${item.name} نامعتبر است." }
                    val cost = if (item.stockMicros == 0L) 0L else mulDiv(item.inventoryValueRial, needed, item.stockMicros)
                    consumptions += Consumption(item, needed, cost)
                    lineCost = SignedLongMath.add(lineCost, cost)
                }
                PreparedLine(menu.id, menu.name, line.quantityMicros, line.grossSalesRial, lineCost)
            }
            val aggregated = consumptions.groupBy { it.item.id }.map { (_, rows) ->
                val item = rows.first().item
                val quantity = rows.fold(0L) { total, row -> SignedLongMath.add(total, row.quantity) }
                val cost = rows.fold(0L) { total, row -> SignedLongMath.add(total, row.cost) }
                require(item.stockMicros >= quantity) { "موجودی ${item.name} برای فروش ثبت‌شده کافی نیست." }
                Triple(item, quantity, cost)
            }
            val totalCost = preparedLines.fold(0L) { total, line -> SignedLongMath.add(total, line.cost) }
            val summaryId = database.dailySalesDao().insertSummary(
                DailySalesSummaryEntity(
                    businessEpochDay = draft.businessEpochDay,
                    grossSalesRial = gross,
                    discountRial = draft.discountRial,
                    serviceRial = draft.serviceRial,
                    taxRial = draft.taxRial,
                    netSalesRial = net,
                    theoreticalCostRial = totalCost,
                    cashRial = draft.cashRial,
                    cardRial = draft.cardRial,
                    transferRial = draft.transferRial,
                    notes = draft.notes.trim(),
                    journalEntryId = null,
                    costJournalEntryId = null,
                    createdAtEpochMillis = now,
                ),
            )
            database.dailySalesDao().insertLines(preparedLines.map {
                DailySalesMenuLineEntity(summaryId = summaryId, menuItemId = it.menuId, menuItemNameSnapshot = it.name, quantityMicros = it.quantity, grossSalesRial = it.gross, theoreticalCostRial = it.cost)
            })
            aggregated.forEach { (item, quantity, cost) ->
                check(database.inventoryDao().updateValuation(item.id, item.stockMicros - quantity, item.inventoryValueRial - cost, now) == 1)
                val movementId = database.stockMovementDao().insert(
                    StockMovementEntity(
                        itemId = item.id,
                        movementType = "DAILY_SALES_CONSUMPTION",
                        quantityDeltaMicros = -quantity,
                        valueDeltaRial = -cost,
                        referenceType = "DAILY_SALES",
                        referenceId = summaryId,
                        movementEpochDay = draft.businessEpochDay,
                        notes = "مصرف رسپی فروش روزانه",
                        createdAtEpochMillis = now,
                    ),
                )
                consumeLotsFefo(item.id, quantity, movementId, now)
            }
            val journalId = database.accountingDao().insertEntry(
                JournalEntryEntity(entryNo = "فر-$summaryId", entryEpochDay = draft.businessEpochDay, description = "فروش تجمیعی صندوق", sourceType = "DAILY_SALES", sourceId = summaryId, createdAtEpochMillis = now),
            )
            val revenueLines = buildList {
                if (draft.cashRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "1101", debitRial = draft.cashRial, creditRial = 0))
                if (draft.cardRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "1102", debitRial = draft.cardRial, creditRial = 0, memo = "کارتخوان"))
                if (draft.transferRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "1102", debitRial = draft.transferRial, creditRial = 0, memo = "حواله"))
                if (productRevenue > 0) add(JournalLineEntity(entryId = journalId, accountCode = "4101", debitRial = 0, creditRial = productRevenue))
                if (draft.serviceRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "4103", debitRial = 0, creditRial = draft.serviceRial))
                if (draft.taxRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "2103", debitRial = 0, creditRial = draft.taxRial))
            }
            database.accountingDao().insertLines(revenueLines)
            val costJournalId = if (totalCost > 0) {
                val costJournal = database.accountingDao().insertEntry(
                    JournalEntryEntity(entryNo = "بفر-$summaryId", entryEpochDay = draft.businessEpochDay, description = "بهای تمام‌شده فروش تجمیعی", sourceType = "DAILY_SALES_COGS", sourceId = summaryId, createdAtEpochMillis = now),
                )
                database.accountingDao().insertLines(listOf(
                    JournalLineEntity(entryId = costJournal, accountCode = "5101", debitRial = totalCost, creditRial = 0),
                    JournalLineEntity(entryId = costJournal, accountCode = "1301", debitRial = 0, creditRial = totalCost),
                ))
                costJournal
            } else null
            check(database.dailySalesDao().linkJournals(summaryId, journalId, costJournalId) == 1)
            syncRecorder?.record("DAILY_SALES", summaryId, "CREATE", now)
            summaryId
        }
    }

    override fun observe(query: String): Flow<List<DailySalesItem>> = database.dailySalesDao().observeSummaries(query.trim()).map { rows ->
        rows.map { it.toDomain() }
    }

    override fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<DailySalesReport> = combine(
        database.dailySalesDao().observeRange(fromEpochDay, toEpochDay),
        database.dailySalesDao().observeMenuPerformance(fromEpochDay, toEpochDay),
    ) { summaries, menuRows ->
        val performanceInputs = menuRows.mapNotNull { row ->
            row.menuItemId?.takeIf { it > 0 }?.let { MenuPerformanceInput(it, row.name, row.unitsSold, row.salesRial, row.costRial) }
        }
        val menuPerformance = if (performanceInputs.isEmpty()) emptyList() else MenuEngineeringCalculator.classify(performanceInputs)
        val sales = summaries.sumOf { it.netSalesRial }
        val cost = summaries.sumOf { it.theoreticalCostRial }
        DailySalesReport(fromEpochDay, toEpochDay, summaries.size, sales, cost, sales - cost, menuPerformance)
    }

    private suspend fun consumeLotsFefo(itemId: Long, quantityMicros: Long, stockMovementId: Long, now: Long) {
        var remaining = quantityMicros
        database.managementControlDao().availableLotsFefo(itemId).forEach { lot ->
            if (remaining <= 0L) return@forEach
            val consumed = minOf(remaining, lot.quantityMicros)
            check(database.managementControlDao().updateLot(lot.copy(quantityMicros = lot.quantityMicros - consumed, updatedAtEpochMillis = now)) == 1)
            database.managementControlDao().insertLotConsumption(InventoryLotConsumptionEntity(stockMovementId = stockMovementId, lotId = lot.id, quantityMicros = consumed))
            remaining -= consumed
        }
    }

    private fun DailySalesSummaryEntity.toDomain() = DailySalesItem(id, businessEpochDay, grossSalesRial, discountRial, serviceRial, taxRial, netSalesRial, theoreticalCostRial, cashRial, cardRial, transferRial, notes, isLegacyArchive)

    private fun mulDiv(a: Long, b: Long, divisor: Long): Long = BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(divisor)).longValueExact()
}
