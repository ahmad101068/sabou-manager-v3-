package ir.sabou.inventory.domain.operations

enum class ApprovalStatus { PENDING, APPROVED, REJECTED, CANCELLED }

data class ApprovalRequest(
    val id: Long,
    val requestType: String,
    val entityId: Long,
    val amountRial: Long,
    val requestedBy: String,
    val approver: String? = null,
    val status: ApprovalStatus = ApprovalStatus.PENDING,
    val note: String = "",
) {
    fun approve(by: String): ApprovalRequest {
        require(status == ApprovalStatus.PENDING) { "فقط درخواست در انتظار قابل تأیید است." }
        require(by.trim().isNotEmpty()) { "تأییدکننده مشخص نیست." }
        return copy(status = ApprovalStatus.APPROVED, approver = by.trim())
    }

    fun reject(by: String, reason: String): ApprovalRequest {
        require(status == ApprovalStatus.PENDING) { "فقط درخواست در انتظار قابل رد است." }
        require(by.trim().isNotEmpty() && reason.trim().length >= 3) { "تأییدکننده و دلیل رد الزامی است." }
        return copy(status = ApprovalStatus.REJECTED, approver = by.trim(), note = reason.trim())
    }
}

object ApprovalPolicy {
    fun requiresApproval(requestType: String, amountRial: Long, thresholdRial: Long): Boolean {
        require(requestType.trim().isNotEmpty()) { "نوع درخواست مشخص نیست." }
        require(amountRial >= 0 && thresholdRial >= 0) { "مبلغ تأیید معتبر نیست." }
        return amountRial >= thresholdRial
    }
}
