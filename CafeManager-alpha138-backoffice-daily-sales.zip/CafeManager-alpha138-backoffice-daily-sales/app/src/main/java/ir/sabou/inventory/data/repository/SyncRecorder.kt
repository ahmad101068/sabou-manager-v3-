package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.SyncChangeEntity
import ir.sabou.inventory.data.db.AuditLogEntity
import ir.sabou.inventory.domain.operations.SyncChangeType
import ir.sabou.inventory.domain.operations.SyncPayloadCodec
import java.util.UUID

/** Records a deterministic, versioned command payload in the enclosing Room transaction. */
open class SyncRecorder(private val database: AppDatabase, private val deviceId: String = "local") {
    open suspend fun record(
        entityType: String,
        entityId: Long,
        changeType: String,
        occurredAt: Long,
        payloadFields: Map<String, String> = emptyMap(),
    ) {
        val normalizedEntityType = entityType.trim().uppercase()
        val normalizedType = runCatching { SyncChangeType.valueOf(changeType) }
            .getOrElse { error("نوع تغییر همگام‌سازی پشتیبانی نمی‌شود: $changeType") }
        require(normalizedEntityType.isNotBlank() && entityId > 0 && occurredAt > 0)
        require(payloadFields.keys.none { it in RESERVED_FIELDS }) { "payload شامل کلید رزروشده است." }
        val revision = database.syncDao().maxRevision(normalizedEntityType, entityId) + 1
        check(revision > 0) { "revision همگام‌سازی سرریز کرد." }
        val payload = SyncPayloadCodec.canonicalize(
            mapOf(
                "changeType" to normalizedType.name,
                "entityId" to entityId.toString(),
                "entityType" to normalizedEntityType,
                "occurredAt" to occurredAt.toString(),
                "revision" to revision.toString(),
            ) + payloadFields,
        )
        val changeId = "$deviceId:$normalizedEntityType:$entityId:$revision:${UUID.randomUUID()}"
        database.syncDao().insert(
            SyncChangeEntity(
                changeId = changeId,
                entityType = normalizedEntityType,
                entityId = entityId,
                changeType = normalizedType.name,
                deviceId = deviceId,
                occurredAtEpochMillis = occurredAt,
                revision = revision,
                payloadVersion = PAYLOAD_VERSION,
                payload = payload,
                payloadHash = SyncPayloadCodec.sha256(payload),
            ),
        )
        val actor = database.securityDao().currentUser()?.let { it.displayName.ifBlank { it.username } } ?: "SYSTEM"
        database.auditLogDao().insert(
            AuditLogEntity(
                action = normalizedType.name,
                entityType = normalizedEntityType,
                entityId = entityId,
                description = "$normalizedEntityType #$entityId · ${normalizedType.name}",
                actor = actor,
                createdAtEpochMillis = occurredAt,
            ),
        )
    }

    private companion object {
        const val PAYLOAD_VERSION = 1
        val RESERVED_FIELDS = setOf("changeType", "entityId", "entityType", "occurredAt", "revision")
    }
}
