package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros

enum class TableOrderStatus { OPEN, CHECKED_OUT, CANCELLED, MERGED }
enum class BillSplitMode { BY_GUEST, BY_ITEM }
enum class BillSplitStatus { OPEN, SETTLED, CANCELLED }

data class TableOrderLine(
    val id: Long,
    val menuItemId: Long,
    val itemName: String,
    val quantity: QuantityMicros,
    val unitPrice: MoneyRial,
    val seatNo: Int = 0,
    val courseNo: Int = 1,
    val notes: String = "",
    val sentToKitchenAtEpochMillis: Long? = null,
) {
    val total: MoneyRial get() = unitPrice.times(quantity)
}

data class TableOrder(
    val id: Long,
    val orderNo: String,
    val tableId: Long,
    val tableLabel: String,
    val guestCount: Int,
    val waiterName: String,
    val customerId: Long?,
    val customerName: String,
    val status: TableOrderStatus,
    val openedAtEpochMillis: Long,
    val notes: String,
    val lines: List<TableOrderLine>,
    val billSplits: List<BillSplit> = emptyList(),
) {
    val subtotal: MoneyRial get() = MoneyRial.sum(lines.map { it.total })
}

data class BillSplit(
    val id: Long,
    val orderId: Long,
    val label: String,
    val mode: BillSplitMode,
    val status: BillSplitStatus,
    val saleId: Long?,
    val lines: List<TableOrderLine>,
) {
    val subtotal: MoneyRial get() = MoneyRial.sum(lines.map { it.total })
}

data class BillSplitPlan(val label: String, val lineIds: List<Long>)

object BillSplitPlanner {
    fun create(order: TableOrder, mode: BillSplitMode): List<BillSplitPlan> {
        require(order.status == TableOrderStatus.OPEN && order.lines.isNotEmpty()) { "سفارش قابل تقسیم نیست." }
        return when (mode) {
            BillSplitMode.BY_ITEM -> order.lines.mapIndexed { index, line ->
                BillSplitPlan("آیتم ${index + 1} · ${line.itemName}", listOf(line.id))
            }
            BillSplitMode.BY_GUEST -> order.lines.groupBy { it.seatNo }.toSortedMap().map { (seat, lines) ->
                BillSplitPlan(if (seat > 0) "مهمان $seat" else "اقلام مشترک", lines.map { it.id })
            }
        }
    }
}

data class VoidOrderLineDraft(val reason: String) {
    fun validated(): VoidOrderLineDraft {
        require(reason.trim().length >= 3) { "علت ابطال را کامل وارد کنید." }
        return copy(reason = reason.trim())
    }
}

enum class CashShiftStatus { OPEN, CLOSED }

data class CashShift(
    val id: Long,
    val openedAtEpochMillis: Long,
    val closedAtEpochMillis: Long?,
    val openingFloat: MoneyRial,
    val expectedCash: MoneyRial,
    val countedCash: MoneyRial?,
    val varianceRial: Long?,
    val openedBy: String,
    val closedBy: String?,
    val status: CashShiftStatus,
    val note: String,
)

object CashShiftReconciliation {
    fun variance(expectedCash: MoneyRial, countedCash: MoneyRial): Long = countedCash.value - expectedCash.value
}

data class OpenTableOrderDraft(
    val tableId: Long,
    val guestCount: Int,
    val waiterName: String,
    val customerId: Long? = null,
    val customerName: String = "مشتری متفرقه",
    val notes: String = "",
) {
    fun validated(): OpenTableOrderDraft {
        require(tableId > 0) { "میز معتبر انتخاب نشده است." }
        require(guestCount in 1..100) { "تعداد مهمان معتبر نیست." }
        require(waiterName.trim().isNotEmpty()) { "نام مسئول میز را وارد کنید." }
        require(customerName.trim().isNotEmpty()) { "نام مشتری معتبر نیست." }
        return copy(waiterName = waiterName.trim(), customerName = customerName.trim(), notes = notes.trim())
    }
}

data class TableOrderItemDraft(
    val menuItemId: Long,
    val quantity: QuantityMicros,
    val seatNo: Int = 0,
    val courseNo: Int = 1,
    val notes: String = "",
) {
    fun validated(): TableOrderItemDraft {
        require(menuItemId > 0 && quantity.value > 0) { "آیتم سفارش معتبر نیست." }
        require(seatNo in 0..100 && courseNo in 1..20) { "شماره مهمان یا مرحله سرو معتبر نیست." }
        return copy(notes = notes.trim())
    }
}

data class TableCheckoutDraft(
    val discount: MoneyRial = MoneyRial.ZERO,
    val serviceCharge: MoneyRial = MoneyRial.ZERO,
    val payments: List<SalePaymentAllocation>,
    val saleEpochDay: Long,
    val dueEpochDay: Long? = null,
)

object TableOrderRules {
    fun validateCheckout(order: TableOrder, draft: TableCheckoutDraft): MoneyRial {
        require(order.status == TableOrderStatus.OPEN && order.lines.isNotEmpty()) { "سفارش باز و قابل تسویه نیست." }
        require(draft.saleEpochDay > 0) { "تاریخ تسویه معتبر نیست." }
        require(draft.discount.value <= order.subtotal.value) { "تخفیف از جمع سفارش بیشتر است." }
        val total = order.subtotal - draft.discount + draft.serviceCharge
        val paid = MoneyRial.sum(draft.payments.map { it.amount })
        require(paid.value <= total.value) { "مجموع پرداخت‌ها از مبلغ صورتحساب بیشتر است." }
        if (paid.value < total.value) {
            require(order.customerId != null && draft.dueEpochDay != null) { "باقیمانده اعتباری به مشتری ثبت‌شده و تاریخ سررسید نیاز دارد." }
            require(draft.dueEpochDay >= draft.saleEpochDay) { "سررسید نمی‌تواند قبل از تاریخ تسویه باشد." }
        }
        return total
    }
}
