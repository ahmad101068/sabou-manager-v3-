package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.domain.recipe.MenuPerformanceResult
import kotlinx.coroutines.flow.Flow

data class DailyMenuSaleDraft(
    val menuItemId: Long,
    val quantityMicros: Long,
    val grossSalesRial: Long,
)

data class DailySalesDraft(
    val businessEpochDay: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val notes: String = "",
    val lines: List<DailyMenuSaleDraft>,
)

data class DailySalesItem(
    val id: Long,
    val businessEpochDay: Long,
    val grossSalesRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netSalesRial: Long,
    val theoreticalCostRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val notes: String,
    val isLegacyArchive: Boolean,
)

data class DailySalesReport(
    val fromEpochDay: Long,
    val toEpochDay: Long,
    val dayCount: Int,
    val salesRial: Long,
    val costOfGoodsRial: Long,
    val grossProfitRial: Long,
    val menuPerformance: List<MenuPerformanceResult>,
)

interface DailySalesRepository {
    suspend fun post(draft: DailySalesDraft): Long
    fun observe(query: String = ""): Flow<List<DailySalesItem>>
    fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<DailySalesReport>
}
