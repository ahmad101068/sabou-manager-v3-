package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AppSessionEntity
import ir.sabou.inventory.data.db.AppUserEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalSecurityRepository(private val db: AppDatabase, private val clock: () -> Long = System::currentTimeMillis, private val authorizer: SessionAuthorizer) : SecurityRepository {
    override val users: Flow<List<AppUserRecord>> = db.securityDao().observeUsers().map { list ->
        list.map { entity -> entity.asRecord() }
    }
    override val currentUser: Flow<AppUserRecord?> = db.securityDao().observeCurrentUser().map { entity -> entity?.asRecord() }

    override suspend fun save(id: Long?, draft: UserDraft): Long {
        val bootstrap = db.securityDao().userCount() == 0
        if (bootstrap) {
            require(id == null && draft.role == UserRole.OWNER) { "اولین کاربر باید مالک باشد." }
        } else {
            authorizer.require("MANAGE_USERS")
        }
        val username = draft.username.trim().lowercase()
        val displayName = draft.displayName.trim()
        require(username.length >= 3) { "نام کاربری باید حداقل ۳ حرف باشد." }
        require(displayName.isNotBlank()) { "نام نمایشی الزامی است." }
        require(draft.pin.length in 6..12 && draft.pin.all(Char::isDigit)) { "رمز باید بین ۶ تا ۱۲ رقم باشد." }
        if (bootstrap) requireValidRecoveryCode(draft.recoveryCode, draft.pin)
        if (draft.recoveryCode.isNotBlank()) requireValidRecoveryCode(draft.recoveryCode, draft.pin)
        val now = clock()
        return db.withTransaction {
            val duplicate = db.securityDao().byUsername(username)
            require(duplicate == null || duplicate.id == id) { "این نام کاربری قبلاً ثبت شده است." }
            val savedId = if (id == null) {
                db.securityDao().insert(AppUserEntity(username=username, displayName=displayName, pinHash=hashPin(draft.pin), recoveryCodeHash=hashRecoveryCode(draft.recoveryCode), role=draft.role.name, createdAtEpochMillis=now, updatedAtEpochMillis=now))
            } else {
                val current = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
                check(db.securityDao().update(current.copy(username=username, displayName=displayName, pinHash=hashPin(draft.pin), recoveryCodeHash=if (draft.recoveryCode.isBlank()) current.recoveryCodeHash else hashRecoveryCode(draft.recoveryCode), role=draft.role.name, isActive=true, updatedAtEpochMillis=now)) == 1)
                id
            }
            if (bootstrap) {
                db.securityDao().setSession(AppSessionEntity(currentUserId = savedId, updatedAtEpochMillis = now))
            }
            savedId
        }
    }

    override suspend fun deactivate(id: Long) {
        authorizer.require("MANAGE_USERS")
        check(db.securityDao().deactivate(id, clock()) == 1) { "کاربر مالک قابل غیرفعال‌سازی نیست یا کاربر پیدا نشد." }
    }

    override suspend fun switchUser(id: Long, pin: String) {
        val user = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
        require(user.isActive) { "این کاربر غیرفعال است." }
        val now = clock()
        require(now >= user.lockUntilEpochMillis) { "ورود موقتاً قفل است؛ کمی بعد دوباره تلاش کنید." }
        if (!verifyPin(pin, user.pinHash)) {
            val attempts = (user.failedPinAttempts + 1).coerceAtMost(20)
            val lockUntil = if (attempts >= MAX_ATTEMPTS) {
                now + lockDurationMillis(attempts)
            } else {
                0L
            }
            db.securityDao().update(user.copy(failedPinAttempts = attempts, lockUntilEpochMillis = lockUntil, updatedAtEpochMillis = now))
            throw IllegalArgumentException("رمز ورود نادرست است.")
        }
        if (needsRehash(user.pinHash)) {
            db.securityDao().update(user.copy(pinHash = hashPin(pin), failedPinAttempts = 0, lockUntilEpochMillis = 0, updatedAtEpochMillis = now))
        } else if (user.failedPinAttempts != 0 || user.lockUntilEpochMillis != 0L) {
            db.securityDao().update(user.copy(failedPinAttempts = 0, lockUntilEpochMillis = 0, updatedAtEpochMillis = now))
        }
        db.securityDao().setSession(AppSessionEntity(currentUserId=id, updatedAtEpochMillis=now))
    }

    override suspend fun setRecoveryCode(id: Long, recoveryCode: String) {
        authorizer.require("MANAGE_USERS")
        requireValidRecoveryCode(recoveryCode)
        val user = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
        require(user.isActive) { "این کاربر غیرفعال است." }
        check(
            db.securityDao().update(
                user.copy(
                    recoveryCodeHash = hashRecoveryCode(recoveryCode),
                    failedPinAttempts = 0,
                    lockUntilEpochMillis = 0,
                    updatedAtEpochMillis = clock(),
                ),
            ) == 1,
        ) { "ذخیره کد بازیابی انجام نشد." }
    }

    override suspend fun resetPinWithRecovery(id: Long, recoveryCode: String, newPin: String) {
        require(newPin.length in 6..12 && newPin.all(Char::isDigit)) { "رمز جدید باید بین ۶ تا ۱۲ رقم باشد." }
        requireValidRecoveryCode(recoveryCode, newPin)
        val user = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
        require(user.isActive) { "این کاربر غیرفعال است." }
        require(user.recoveryCodeHash.isNotBlank()) { "برای این کاربر کد بازیابی تعیین نشده است." }
        val now = clock()
        require(now >= user.lockUntilEpochMillis) { "بازیابی موقتاً قفل است؛ کمی بعد دوباره تلاش کنید." }
        if (!verifySecret(recoveryCode, user.recoveryCodeHash)) {
            registerFailedAttempt(user, now)
            throw IllegalArgumentException("کد بازیابی نادرست است.")
        }
        check(
            db.securityDao().update(
                user.copy(
                    pinHash = hashPin(newPin),
                    failedPinAttempts = 0,
                    lockUntilEpochMillis = 0,
                    updatedAtEpochMillis = now,
                ),
            ) == 1,
        ) { "تغییر رمز ورود انجام نشد." }
        db.securityDao().setSession(AppSessionEntity(currentUserId = id, updatedAtEpochMillis = now))
    }

    override suspend fun logout() {
        db.securityDao().clearSession()
    }

    private fun AppUserEntity.asRecord() = AppUserRecord(id, username, displayName, runCatching { UserRole.valueOf(role) }.getOrDefault(UserRole.CASHIER), isActive, recoveryCodeHash.isNotBlank())

    private fun requireValidRecoveryCode(recoveryCode: String, pin: String? = null) {
        require(recoveryCode.length in 8..16 && recoveryCode.all(Char::isDigit)) { "کد بازیابی باید بین ۸ تا ۱۶ رقم باشد." }
        require(pin == null || recoveryCode != pin) { "کد بازیابی نباید با رمز ورود یکسان باشد." }
    }

    private fun hashRecoveryCode(recoveryCode: String): String =
        if (recoveryCode.isBlank()) "" else hashPin(recoveryCode)

    private fun hashPin(pin: String): String {
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val spec = PBEKeySpec(pin.toCharArray(), salt, CURRENT_ITERATIONS, 256)
        val hash = SecretKeyFactory.getInstance(CURRENT_ALGORITHM).generateSecret(spec).encoded
        spec.clearPassword()
        return listOf(CURRENT_PREFIX, CURRENT_ITERATIONS.toString(), Base64.encodeToString(salt, Base64.NO_WRAP), Base64.encodeToString(hash, Base64.NO_WRAP)).joinToString("$")
    }

    private fun verifyPin(pin: String, encoded: String): Boolean = verifySecret(pin, encoded)

    private fun verifySecret(secret: String, encoded: String): Boolean {
        if (!encoded.startsWith("pbkdf2")) {
            val legacy = MessageDigest.getInstance("SHA-256")
                .digest(("sabou-v3:" + secret).toByteArray())
                .joinToString("") { "%02x".format(it) }
            return MessageDigest.isEqual(legacy.toByteArray(), encoded.toByteArray())
        }
        val parts = encoded.split('$')
        if (parts.size != 4) return false
        val algorithm = when (parts[0]) {
            "pbkdf2", "pbkdf2-sha256" -> "PBKDF2WithHmacSHA256"
            "pbkdf2-sha1" -> "PBKDF2WithHmacSHA1"
            else -> return false
        }
        val iterations = parts[1].toIntOrNull() ?: return false
        val salt = runCatching { Base64.decode(parts[2], Base64.NO_WRAP) }.getOrNull() ?: return false
        val expected = runCatching { Base64.decode(parts[3], Base64.NO_WRAP) }.getOrNull() ?: return false
        val spec = PBEKeySpec(secret.toCharArray(), salt, iterations, expected.size * 8)
        val actual = try {
            SecretKeyFactory.getInstance(algorithm).generateSecret(spec).encoded
        } catch (error: java.security.NoSuchAlgorithmException) {
            spec.clearPassword()
            throw IllegalStateException("الگوریتم PIN این نسخه پشتیبانی نمی‌شود؛ PIN را روی دستگاه قبلی تغییر دهید.", error)
        }
        spec.clearPassword()
        return MessageDigest.isEqual(expected, actual)
    }

    private suspend fun registerFailedAttempt(user: AppUserEntity, now: Long) {
        val attempts = (user.failedPinAttempts + 1).coerceAtMost(20)
        val lockUntil = if (attempts >= MAX_ATTEMPTS) now + lockDurationMillis(attempts) else 0L
        db.securityDao().update(user.copy(failedPinAttempts = attempts, lockUntilEpochMillis = lockUntil, updatedAtEpochMillis = now))
    }

    private fun needsRehash(encoded: String): Boolean {
        if (!encoded.startsWith("${CURRENT_PREFIX}$")) return true
        val iterations = encoded.split('$').getOrNull(1)?.toIntOrNull() ?: return true
        return iterations < CURRENT_ITERATIONS
    }

    private fun lockDurationMillis(attempts: Int): Long {
        val exponent = (attempts - MAX_ATTEMPTS).coerceIn(0, 5)
        return (BASE_LOCK_MILLIS shl exponent).coerceAtMost(MAX_LOCK_MILLIS)
    }

    private companion object {
        const val MAX_ATTEMPTS = 5
        const val BASE_LOCK_MILLIS = 30_000L
        const val MAX_LOCK_MILLIS = 15 * 60_000L
        const val CURRENT_PREFIX = "pbkdf2-sha1"
        const val CURRENT_ALGORITHM = "PBKDF2WithHmacSHA1"
        const val CURRENT_ITERATIONS = 310_000
    }
}
