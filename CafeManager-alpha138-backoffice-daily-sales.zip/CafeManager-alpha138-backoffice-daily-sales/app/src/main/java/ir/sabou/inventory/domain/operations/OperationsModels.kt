package ir.sabou.inventory.domain.operations

import kotlinx.coroutines.flow.Flow
import java.math.BigInteger

data class SupplierRecord(
    val id: Long,
    val name: String,
    val contactName: String,
    val phone: String,
    val address: String,
    val paymentTermsDays: Int,
    val notes: String,
)

data class SupplierDraft(
    val name: String,
    val contactName: String = "",
    val phone: String = "",
    val address: String = "",
    val paymentTermsDays: Int = 0,
    val notes: String = "",
) {
    fun validated(): SupplierDraft {
        val normalizedName = name.trim()
        require(normalizedName.length in 2..120) {
            "نام تأمین‌کننده باید بین ۲ تا ۱۲۰ نویسه باشد."
        }
        require(paymentTermsDays in 0..3650) {
            "مهلت پرداخت معتبر نیست."
        }
        require(phone.trim().length <= 30) {
            "شماره تماس بیش از حد طولانی است."
        }
        return copy(
            name = normalizedName,
            contactName = contactName.trim(),
            phone = phone.trim(),
            address = address.trim(),
            notes = notes.trim(),
        )
    }
}

data class InventoryItemRecord(
    val id: Long,
    val name: String,
    val category: String,
    val unit: String,
    val stockMicros: Long,
    val inventoryValueRial: Long,
    val alertEnabled: Boolean,
    val alertThresholdMicros: Long,
    val supplierId: Long?,
)

data class InventoryItemDraft(
    val name: String,
    val category: String,
    val unit: String,
    val alertEnabled: Boolean,
    val alertThresholdMicros: Long,
    val supplierId: Long?,
) {
    fun validated(): InventoryItemDraft {
        val normalizedName = name.trim()
        val normalizedCategory = category.trim()
        val normalizedUnit = unit.trim()
        require(normalizedName.length in 2..120) {
            "نام کالا باید بین ۲ تا ۱۲۰ نویسه باشد."
        }
        require(normalizedCategory.isNotEmpty()) {
            "دسته‌بندی کالا را وارد کنید."
        }
        require(normalizedUnit.isNotEmpty()) {
            "واحد شمارش کالا را وارد کنید."
        }
        require(alertThresholdMicros >= 0) {
            "حد هشدار موجودی نمی‌تواند منفی باشد."
        }
        return copy(
            name = normalizedName,
            category = normalizedCategory,
            unit = normalizedUnit,
        )
    }
}

data class PurchaseSummary(
    val id: Long,
    val invoiceNo: String,
    val supplierName: String,
    val purchaseEpochDay: Long,
    val dueEpochDay: Long,
    val totalRial: Long,
    val paidRial: Long,
    val isPaid: Boolean,
    val paymentStatus: String,
    val paymentMethod: String?,
    val reminderEnabled: Boolean,
    val reminderEpochDay: Long?,
) {
    val outstandingRial: Long get() = totalRial - paidRial

    fun reminderIsDue(todayEpochDay: Long): Boolean =
        paymentStatus in setOf("UNPAID", "PARTIAL") &&
            outstandingRial > 0 &&
            reminderEnabled &&
            reminderEpochDay != null &&
            reminderEpochDay <= todayEpochDay
}


data class InventoryCountDraft(
    val itemId: Long,
    val countedQuantityMicros: Long,
    val countedValueRial: Long,
    val countEpochDay: Long,
    val reason: String,
) {
    fun validated(): InventoryCountDraft {
        require(itemId > 0) { "کالای انبارگردانی نامعتبر است." }
        require(countedQuantityMicros >= 0) { "موجودی شمارش‌شده نمی‌تواند منفی باشد." }
        require(countedValueRial >= 0) { "ارزش شمارش‌شده نمی‌تواند منفی باشد." }
        require(countEpochDay > 0) { "تاریخ انبارگردانی معتبر نیست." }
        require(reason.trim().length in 3..300) { "دلیل اصلاح موجودی را وارد کنید." }
        return copy(reason = reason.trim())
    }
}

data class InventoryCountRecord(val id: Long, val itemId: Long, val previousQuantityMicros: Long, val countedQuantityMicros: Long, val previousValueRial: Long, val countedValueRial: Long, val countEpochDay: Long, val reason: String)
data class AuditLogRecord(val id: Long, val action: String, val entityType: String, val entityId: Long?, val description: String, val actor: String, val createdAtEpochMillis: Long)

data class InventoryUsageInsight(
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val usageMicros30Days: Long,
    val averageDailyUsageMicros: Long,
)

data class SupplierPriceInsight(
    val itemId: Long,
    val itemName: String,
    val supplierName: String,
    val latestUnitCostRial: Long,
    val previousUnitCostRial: Long,
) {
    val changePercent: Int
        get() = if (previousUnitCostRial <= 0) 0
        else BigInteger.valueOf(latestUnitCostRial)
            .subtract(BigInteger.valueOf(previousUnitCostRial))
            .multiply(BigInteger.valueOf(100L))
            .divide(BigInteger.valueOf(previousUnitCostRial))
            .coerceIn(BigInteger.valueOf(Int.MIN_VALUE.toLong()), BigInteger.valueOf(Int.MAX_VALUE.toLong()))
            .toInt()
}

data class WasteDraft(
    val itemId: Long,
    val quantityMicros: Long,
    val wasteEpochDay: Long,
    val reason: String,
    val notes: String = "",
) {
    fun validated(): WasteDraft {
        require(itemId > 0) { "کالای ضایعات نامعتبر است." }
        require(quantityMicros > 0) { "مقدار ضایعات باید بیشتر از صفر باشد." }
        require(wasteEpochDay > 0) { "تاریخ ضایعات معتبر نیست." }
        require(reason.trim().length in 2..120) { "علت ضایعات را وارد کنید." }
        return copy(reason = reason.trim(), notes = notes.trim())
    }
}

data class WasteRecord(
    val id: Long,
    val itemId: Long,
    val itemName: String,
    val unit: String,
    val quantityMicros: Long,
    val valueRial: Long,
    val wasteEpochDay: Long,
    val reason: String,
)

interface OperationsRepository {
    val suppliers: Flow<List<SupplierRecord>>
    val inventoryItems: Flow<List<InventoryItemRecord>>
    val lowStockItems: Flow<List<InventoryItemRecord>>
    val inventoryCounts: Flow<List<InventoryCountRecord>>
    val auditLogs: Flow<List<AuditLogRecord>>
    val usageInsights: Flow<List<InventoryUsageInsight>>
    val supplierPriceInsights: Flow<List<SupplierPriceInsight>>
    val wasteRecords: Flow<List<WasteRecord>>

    fun purchases(query: String): Flow<List<PurchaseSummary>>

    suspend fun createSupplier(draft: SupplierDraft): Long
    suspend fun updateSupplier(id: Long, draft: SupplierDraft)
    suspend fun deactivateSupplier(id: Long)

    suspend fun createInventoryItem(draft: InventoryItemDraft): Long
    suspend fun updateInventoryItem(id: Long, draft: InventoryItemDraft)
    suspend fun deactivateInventoryItem(id: Long)
    suspend fun postInventoryCount(draft: InventoryCountDraft): Long
    suspend fun postWaste(draft: WasteDraft): Long
}
