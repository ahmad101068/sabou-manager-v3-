package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "menu_items", indices = [Index(value = ["name"], unique = true)])
data class MenuItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String = "",
    val salePriceRial: Long = 0,
    val isActive: Boolean = true,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "recipe_ingredients",
    primaryKeys = ["menuItemId", "inventoryItemId"],
    foreignKeys = [
        ForeignKey(entity = MenuItemEntity::class, parentColumns = ["id"], childColumns = ["menuItemId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = InventoryItemEntity::class, parentColumns = ["id"], childColumns = ["inventoryItemId"], onDelete = ForeignKey.RESTRICT),
    ],
    indices = [Index("inventoryItemId")],
)
data class RecipeIngredientEntity(
    val menuItemId: Long,
    val inventoryItemId: Long,
    val quantityMicrosPerUnit: Long,
)
