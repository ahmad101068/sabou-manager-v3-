package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "loyalty_transactions",
    indices = [Index("customerId"), Index("createdAtEpochMillis")],
    foreignKeys = [ForeignKey(entity = CustomerEntity::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT)],
)
data class LoyaltyTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val pointsDelta: Long,
    val reason: String,
    val referenceType: String = "MANUAL",
    val referenceId: Long? = null,
    val createdAtEpochMillis: Long,
)

@Entity(
    tableName = "customer_followups",
    indices = [Index("customerId"), Index("dueEpochDay"), Index("isDone")],
    foreignKeys = [ForeignKey(entity = CustomerEntity::class, parentColumns = ["id"], childColumns = ["customerId"], onDelete = ForeignKey.RESTRICT)],
)
data class CustomerFollowUpEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerId: Long,
    val title: String,
    val dueEpochDay: Long,
    val notes: String = "",
    val isDone: Boolean = false,
    val createdAtEpochMillis: Long,
    val completedAtEpochMillis: Long? = null,
)
