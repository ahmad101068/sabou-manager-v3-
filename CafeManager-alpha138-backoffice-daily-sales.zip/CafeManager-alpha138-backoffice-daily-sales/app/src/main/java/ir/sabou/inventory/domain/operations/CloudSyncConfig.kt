package ir.sabou.inventory.domain.operations

data class CloudSyncConfig(val endpoint: String, val tenantId: String, val enabled: Boolean = false) {
    fun validated(): CloudSyncConfig { require(endpoint.startsWith("https://")); require(tenantId.isNotBlank()); return this }
}
