package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AssetDepreciationEntity
import ir.sabou.inventory.data.db.FixedAssetEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.assets.AssetRecord
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.assets.DepreciationDraft
import ir.sabou.inventory.domain.assets.DepreciationRecord
import ir.sabou.inventory.domain.operations.SyncChangeType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalAssetRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : AssetRepository {
    private val dao get() = database.assetDao()
    private val accounting get() = database.accountingDao()

    override val assets: Flow<List<AssetRecord>> = dao.observeAssets().map { rows ->
        rows.map { AssetRecord(it.id, it.assetCode, it.name, it.category, it.quantity, it.purchaseEpochDay, it.purchaseCostRial, it.salvageValueRial, it.accumulatedDepreciationRial, it.usefulLifeMonths, it.location, it.notes, it.status == "ACTIVE") }
    }
    override val depreciations: Flow<List<DepreciationRecord>> = dao.observeDepreciations().map { rows ->
        rows.map { DepreciationRecord(it.id, it.assetName, it.periodYear, it.periodMonth, it.amountRial) }
    }

    override suspend fun save(id: Long?, draft: AssetDraft): Long {
        authorizer.require("ASSETS")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            if (id == null) {
                dao.insertAsset(FixedAssetEntity(assetCode = valid.assetCode, name = valid.name, category = valid.category, quantity = valid.quantity, purchaseEpochDay = valid.purchaseEpochDay, purchaseCostRial = valid.purchaseCostRial, salvageValueRial = valid.salvageValueRial, usefulLifeMonths = valid.usefulLifeMonths, location = valid.location, notes = valid.notes, createdAtEpochMillis = now, updatedAtEpochMillis = now))
            } else {
                val current = dao.assetById(id) ?: error("دارایی پیدا نشد.")
                check(dao.updateAsset(current.copy(assetCode = valid.assetCode, name = valid.name, category = valid.category, quantity = valid.quantity, purchaseEpochDay = valid.purchaseEpochDay, purchaseCostRial = valid.purchaseCostRial, salvageValueRial = valid.salvageValueRial, usefulLifeMonths = valid.usefulLifeMonths, location = valid.location, notes = valid.notes, updatedAtEpochMillis = now)) == 1)
                id
            }
        }
    }

    override suspend fun dispose(id: Long) {
        authorizer.require("ASSETS")
        val now = clock()
        database.withTransaction {
            check(dao.disposeAsset(id, now) == 1) { "خروج دارایی انجام نشد." }
            syncRecorder?.record("ASSET", id, SyncChangeType.DISPOSE.name, now)
        }
    }

    override suspend fun postDepreciation(draft: DepreciationDraft): Long {
        authorizer.require("ASSETS")
        val valid = draft.validated()
        return database.withTransaction {
            val asset = dao.assetById(valid.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "دارایی فعال نیست." }
            require(!dao.depreciationExists(asset.id, valid.periodYear, valid.periodMonth)) { "استهلاک این دوره قبلاً ثبت شده است." }
            require(accounting.activeAccountExists("6110") && accounting.activeAccountExists("1502")) { "حساب‌های استهلاک در دفتر فعال نیستند." }
            val depreciable = asset.purchaseCostRial - asset.salvageValueRial
            val monthly = depreciable / asset.usefulLifeMonths
            val remaining = depreciable - asset.accumulatedDepreciationRial
            val amount = minOf(monthly, remaining)
            require(amount > 0) { "دارایی کاملاً مستهلک شده است." }
            val now = clock()
            val entryId = accounting.insertEntry(JournalEntryEntity(entryNo = "TMP-AST-$now", entryEpochDay = valid.postingEpochDay, description = "استهلاک ${asset.name} ${valid.periodYear}/${valid.periodMonth}", sourceType = "ASSET_DEPRECIATION", sourceId = 0, createdAtEpochMillis = now))
            accounting.insertLines(listOf(JournalLineEntity(entryId = entryId, accountCode = "6110", debitRial = amount, creditRial = 0, memo = "هزینه استهلاک"), JournalLineEntity(entryId = entryId, accountCode = "1502", debitRial = 0, creditRial = amount, memo = "استهلاک انباشته")))
            check(dao.addDepreciation(asset.id, amount, now) == 1) { "ثبت استهلاک از ارزش مجاز بیشتر است." }
            val depreciationId = dao.insertDepreciation(AssetDepreciationEntity(assetId = asset.id, periodYear = valid.periodYear, periodMonth = valid.periodMonth, amountRial = amount, journalEntryId = entryId, createdAtEpochMillis = now))
            check(depreciationId > 0) { "ثبت سابقه استهلاک انجام نشد." }
            check(accounting.finalizeEntryIdentity(entryId, "د-$entryId", depreciationId) == 1) { "اتصال سند استهلاک انجام نشد." }
            depreciationId
        }
    }
}
