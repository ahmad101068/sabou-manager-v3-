package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial

object SalesCalculator {
    fun prepare(draft: SaleDraft): PreparedSale {
        val normalized = draft.copy(
            invoiceNo = draft.invoiceNo.trim(),
            customerName = draft.customerName.trim(),
            channel = draft.channel.trim(),
            notes = draft.notes.trim(),
            lines = draft.lines.map { it.copy(productName = it.productName.trim()) },
        )
        require(normalized.invoiceNo.isNotBlank() && normalized.invoiceNo.length <= 80) { "شماره فاکتور فروش معتبر نیست." }
        require(normalized.customerName.isNotBlank() && normalized.customerName.length <= 120) { "نام مشتری معتبر نیست." }
        require(normalized.channel.isNotBlank() && normalized.channel.length <= 80) { "کانال فروش معتبر نیست." }
        require(normalized.notes.length <= 300) { "توضیحات بیش از حد طولانی است." }
        require(normalized.lines.isNotEmpty() && normalized.lines.size <= 500) { "فاکتور باید بین ۱ تا ۵۰۰ ردیف داشته باشد." }
        require(normalized.lines.all { it.productName.isNotBlank() && it.quantity.value > 0 && it.unitPrice.value >= 0 }) { "ردیف فروش معتبر نیست." }
        if (normalized.paymentMethod == SalePaymentMethod.RECEIVABLE) {
            require(normalized.customerId != null && normalized.customerId > 0) { "فروش اعتباری نیاز به مشتری ثبت‌شده دارد." }
            requireNotNull(normalized.dueEpochDay) { "تاریخ سررسید فروش اعتباری الزامی است." }
            require(normalized.dueEpochDay >= normalized.saleEpochDay) { "سررسید نمی‌تواند قبل از تاریخ فروش باشد." }
        }
        val lines = normalized.lines.map {
            PreparedSaleLine(it.menuItemId, it.productName, it.quantity.value, it.unitPrice.value, it.unitPrice.times(it.quantity))
        }
        val subtotal = MoneyRial.sum(lines.map { it.total })
        require(normalized.discount.value <= subtotal.value) { "تخفیف نمی‌تواند بیشتر از جمع فاکتور باشد." }
        val total = subtotal - normalized.discount + normalized.delivery
        return PreparedSale(normalized, lines, subtotal, total)
    }
}
