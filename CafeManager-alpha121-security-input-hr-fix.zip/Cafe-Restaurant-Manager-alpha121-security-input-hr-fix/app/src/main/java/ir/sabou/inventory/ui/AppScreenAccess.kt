package ir.sabou.inventory.ui

import ir.sabou.inventory.domain.operations.AppUserRecord

internal fun canOpenScreen(user: AppUserRecord?, screen: AppScreen): Boolean {
    if (screen == AppScreen.SECURITY) return true
    if (user == null) return false
    return when (screen) {
        AppScreen.DASHBOARD,
        AppScreen.GLOBAL_SEARCH,
        AppScreen.SETTINGS -> true
        AppScreen.PURCHASES, AppScreen.NEW_PURCHASE -> user.role.allows("PURCHASES")
        AppScreen.SUPPLIERS -> user.role.allows("SUPPLIERS")
        AppScreen.INVENTORY -> user.role.allows("INVENTORY")
        AppScreen.SALES, AppScreen.CRM -> user.role.allows("SALES")
        AppScreen.RECIPES -> user.role.allows("RECIPES")
        AppScreen.ACCOUNTING, AppScreen.NEW_JOURNAL -> user.role.allows("ACCOUNTING")
        AppScreen.PERSONNEL -> user.role.allows("PERSONNEL")
        AppScreen.ASSETS -> user.role.allows("ASSETS")
        AppScreen.ALERTS, AppScreen.REPORTS -> user.role.allows("ACCOUNTING")
        AppScreen.AUDIT_LOG -> user.role.allows("AUDIT")
        AppScreen.RESTAURANT_OPERATIONS -> listOf("SALES", "KITCHEN", "PERSONNEL", "AUDIT")
            .any(user.role::allows)
        AppScreen.SECURITY -> true
    }
}
