package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.CustomerFollowUpEntity
import ir.sabou.inventory.data.db.LoyaltyTransactionEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.crm.CrmRepository

class LocalCrmRepository(private val db: AppDatabase, private val authorizer: SessionAuthorizer, private val syncRecorder: SyncRecorder? = null) : CrmRepository {
    override fun customers() = db.crmDao().observeCustomerSummaries()
    override fun followUps() = db.crmDao().observeFollowUps()
    override fun transactions(customerId: Long) = db.crmDao().observeTransactions(customerId)
    override suspend fun adjustPoints(customerId: Long, delta: Long, reason: String) {
        authorizer.require("SALES")
        require(delta != 0L) { "تغییر امتیاز نمی‌تواند صفر باشد" }
        require(reason.isNotBlank()) { "دلیل تغییر امتیاز الزامی است" }
        val now=System.currentTimeMillis();val id=db.crmDao().insertTransaction(LoyaltyTransactionEntity(customerId=customerId, pointsDelta=delta, reason=reason.trim(), createdAtEpochMillis=now));syncRecorder?.record("LOYALTY",id,"CREATE",now)
    }
    override suspend fun addFollowUp(customerId: Long, title: String, dueEpochDay: Long, notes: String) {
        authorizer.require("SALES")
        require(title.isNotBlank()) { "عنوان پیگیری الزامی است" }
        val now=System.currentTimeMillis();val id=db.crmDao().insertFollowUp(CustomerFollowUpEntity(customerId=customerId, title=title.trim(), dueEpochDay=dueEpochDay, notes=notes.trim(), createdAtEpochMillis=now));syncRecorder?.record("FOLLOW_UP",id,"CREATE",now)
    }
    override suspend fun completeFollowUp(id: Long) { authorizer.require("SALES");val now=System.currentTimeMillis(); check(db.crmDao().completeFollowUp(id, now) == 1) { "پیگیری قبلاً انجام شده است" };syncRecorder?.record("FOLLOW_UP",id,"UPDATE",now) }
}
