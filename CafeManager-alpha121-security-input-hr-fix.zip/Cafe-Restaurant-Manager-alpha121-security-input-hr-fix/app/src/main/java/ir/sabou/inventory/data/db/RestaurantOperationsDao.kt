package ir.sabou.inventory.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RestaurantOperationsDao {
    @Query("SELECT * FROM restaurant_tables ORDER BY zone,label") fun observeTables(): Flow<List<RestaurantTableEntity>>
    @Insert suspend fun insertTable(value: RestaurantTableEntity): Long
    @Update suspend fun updateTable(value: RestaurantTableEntity): Int
    @Query("SELECT * FROM restaurant_tables WHERE id=:id") suspend fun table(id: Long): RestaurantTableEntity?

    @Query("SELECT * FROM reservations ORDER BY startEpochMillis") fun observeReservations(): Flow<List<ReservationEntity>>
    @Query("SELECT * FROM reservations") suspend fun allReservations(): List<ReservationEntity>
    @Insert suspend fun insertReservation(value: ReservationEntity): Long

    @Query("SELECT * FROM kitchen_tickets ORDER BY priority DESC,createdAtEpochMillis") fun observeKitchenTickets(): Flow<List<KitchenTicketEntity>>
    @Insert suspend fun insertKitchenTicket(value: KitchenTicketEntity): Long
    @Update suspend fun updateKitchenTicket(value: KitchenTicketEntity): Int
    @Query("SELECT * FROM kitchen_tickets WHERE id=:id") suspend fun kitchenTicket(id: Long): KitchenTicketEntity?

    @Query("SELECT * FROM planned_shifts ORDER BY epochDay,startMinute") fun observeShifts(): Flow<List<PlannedShiftEntity>>
    @Insert suspend fun insertShifts(values: List<PlannedShiftEntity>)

    @Query("SELECT * FROM approval_requests ORDER BY id DESC") fun observeApprovals(): Flow<List<ApprovalRequestEntity>>
    @Insert suspend fun insertApproval(value: ApprovalRequestEntity): Long
    @Update suspend fun updateApproval(value: ApprovalRequestEntity): Int
    @Query("SELECT * FROM approval_requests WHERE id=:id") suspend fun approval(id: Long): ApprovalRequestEntity?
}
