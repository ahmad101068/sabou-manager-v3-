package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "restaurant_tables", indices = [Index(value = ["label"], unique = true)])
data class RestaurantTableEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val label: String, val capacity: Int, val zone: String, val status: String = "FREE", val activeOrderId: Long? = null)

@Entity(tableName = "reservations", indices = [Index("tableId"), Index("startEpochMillis")])
data class ReservationEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val customerName: String, val phone: String, val tableId: Long, val startEpochMillis: Long, val endEpochMillis: Long, val partySize: Int, val notes: String = "")

@Entity(tableName = "kitchen_tickets", indices = [Index("status"), Index("createdAtEpochMillis")])
data class KitchenTicketEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val orderNo: String, val station: String, val itemName: String, val quantity: Int, val createdAtEpochMillis: Long, val status: String = "QUEUED", val priority: Int = 0)

@Entity(tableName = "planned_shifts", indices = [Index("employeeId"), Index("epochDay")])
data class PlannedShiftEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val employeeId: Long, val employeeName: String, val role: String, val epochDay: Long, val startMinute: Int, val endMinute: Int)

@Entity(tableName = "approval_requests", indices = [Index("status"), Index(value = ["requestType", "entityId"])])
data class ApprovalRequestEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val requestType: String, val entityId: Long, val amountRial: Long, val requestedBy: String, val approver: String? = null, val status: String = "PENDING", val note: String = "")
