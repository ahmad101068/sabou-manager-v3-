package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.assets.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AssetUiState(val assets:List<AssetRecord> = emptyList(), val depreciations:List<DepreciationRecord> = emptyList(), val message:String?=null)
class AssetViewModel(private val repository:AssetRepository):ViewModel(){
 private val message=MutableStateFlow<String?>(null)
 val state:StateFlow<AssetUiState> = combine(repository.assets,repository.depreciations,message){a,d,m->AssetUiState(a,d,m)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),AssetUiState())
 fun save(id:Long?,draft:AssetDraft)=launch("دارایی ذخیره شد."){repository.save(id,draft)}
 fun dispose(id:Long)=launch("دارایی از چرخه بهره‌برداری خارج شد."){repository.dispose(id)}
 fun depreciate(draft:DepreciationDraft)=launch("استهلاک ثبت و سند حسابداری صادر شد."){repository.postDepreciation(draft)}
 private fun launch(success:String, block:suspend()->Unit)=viewModelScope.launch{runCatching{block()}.onSuccess{message.value=success}.onFailure{message.value=it.message?:"خطا"}}
 companion object{fun factory(repo:AssetRepository)=object:ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST") override fun<T:ViewModel>create(modelClass:Class<T>):T=AssetViewModel(repo) as T}}
}
