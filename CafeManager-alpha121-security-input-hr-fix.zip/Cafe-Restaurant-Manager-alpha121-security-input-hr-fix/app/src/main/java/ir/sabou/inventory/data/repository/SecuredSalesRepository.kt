package ir.sabou.inventory.data.repository

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.sales.SalePaymentMethod
import ir.sabou.inventory.domain.sales.SalesRepository

/** Covers legacy compact command methods until LocalSalesRepository is fully decomposed. */
class SecuredSalesRepository(
    private val delegate: SalesRepository,
    private val authorizer: SessionAuthorizer,
) : SalesRepository by delegate {
    override suspend fun receive(
        saleId: Long,
        amount: MoneyRial,
        paymentEpochDay: Long,
        method: SalePaymentMethod,
    ): Long {
        authorizer.require("SALES")
        return delegate.receive(saleId, amount, paymentEpochDay, method)
    }

    override suspend fun reverseReceipt(paymentId: Long, reversalEpochDay: Long): Long {
        authorizer.require("SALES")
        return delegate.reverseReceipt(paymentId, reversalEpochDay)
    }
}
