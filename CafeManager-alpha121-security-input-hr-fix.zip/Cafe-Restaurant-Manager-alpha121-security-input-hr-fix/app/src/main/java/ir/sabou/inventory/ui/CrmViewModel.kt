package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.data.db.CrmCustomerRow
import ir.sabou.inventory.data.db.CrmFollowUpRow
import ir.sabou.inventory.domain.crm.CrmRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class CrmState(val customers: List<CrmCustomerRow> = emptyList(), val followUps: List<CrmFollowUpRow> = emptyList(), val message: String? = null)
class CrmViewModel(private val repository: CrmRepository) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    val state: StateFlow<CrmState> = combine(repository.customers(), repository.followUps(), message) { c, f, m -> CrmState(c, f, m) }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CrmState())
    fun adjustPoints(customerId: Long, delta: Long, reason: String) = run { repository.adjustPoints(customerId, delta, reason) }
    fun addFollowUp(customerId: Long, title: String, due: Long, notes: String) = run { repository.addFollowUp(customerId, title, due, notes) }
    fun complete(id: Long) = run { repository.completeFollowUp(id) }
    private fun run(block: suspend () -> Unit) { viewModelScope.launch { message.value = runCatching { block(); "عملیات با موفقیت ثبت شد" }.getOrElse { it.message ?: "خطا" } } }
    companion object { fun factory(repository: CrmRepository) = object : ViewModelProvider.Factory { override fun <T : ViewModel> create(modelClass: Class<T>): T = CrmViewModel(repository) as T } }
}
