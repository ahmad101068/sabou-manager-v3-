package ir.sabou.inventory.data

import android.content.Context
import android.net.Uri
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.repository.DashboardRepository
import ir.sabou.inventory.data.repository.LocalAccountingRepository
import ir.sabou.inventory.data.repository.LocalOperationsRepository
import ir.sabou.inventory.data.repository.LocalPurchaseRepository
import ir.sabou.inventory.data.repository.LocalPersonnelRepository
import ir.sabou.inventory.data.repository.LocalPerformanceRepository
import ir.sabou.inventory.data.repository.LocalSyncRepository
import ir.sabou.inventory.data.repository.SyncRecorder
import ir.sabou.inventory.data.repository.LocalSalesRepository
import ir.sabou.inventory.data.repository.SecuredSalesRepository
import ir.sabou.inventory.data.repository.LocalSecurityRepository
import ir.sabou.inventory.data.repository.LocalAssetRepository
import ir.sabou.inventory.data.repository.LocalRecipeRepository
import ir.sabou.inventory.data.repository.LocalCrmRepository
import ir.sabou.inventory.data.repository.LocalAlertRepository
import ir.sabou.inventory.data.repository.LocalRestaurantOperationsRepository
import ir.sabou.inventory.data.security.DatabaseKeyProvider
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.accounting.AccountingRepository
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.purchase.PurchaseRepository
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.sales.SalesRepository
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.crm.CrmRepository
import ir.sabou.inventory.domain.operations.AlertRepository
import ir.sabou.inventory.domain.operations.CloudSyncConfig
import ir.sabou.inventory.data.repository.HttpsSyncTransport
import ir.sabou.inventory.data.repository.SyncCoordinator
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val backupManager = BackupManager(appContext)
    private val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        backupManager.applyPendingRestore()
        val keyProvider = DatabaseKeyProvider(appContext)
        try {
            AppDatabase.create(appContext, keyProvider).also { db ->
                db.openHelper.writableDatabase.query("PRAGMA cipher_integrity_check").use { cursor ->
                    val integrityErrors = buildList {
                        while (cursor.moveToNext()) add(cursor.getString(0))
                    }
                    require(integrityErrors.isEmpty()) {
                        "اعتبارسنجی پایگاه داده ناموفق بود: ${integrityErrors.joinToString()}"
                    }
                }
                db.openHelper.writableDatabase.execSQL("DELETE FROM app_session")
                backupManager.markRestoreValidated()
            }
        } catch (error: Throwable) {
            if (!backupManager.rollbackLastRestore()) throw error
            AppDatabase.create(appContext, keyProvider).also { db ->
                db.openHelper.writableDatabase.execSQL("DELETE FROM app_session")
            }
        }
    }
    private val authorizer by lazy { SessionAuthorizer(database) }

    /** Opens and validates the encrypted Room database. Call this from a background dispatcher. */
    fun initialize() {
        database.openHelper.writableDatabase
    }

    val purchaseRepository: PurchaseRepository by lazy {
        LocalPurchaseRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }

    val salesRepository: SalesRepository by lazy {
        SecuredSalesRepository(
            LocalSalesRepository(database, syncRecorder = syncRecorder, authorizer = authorizer),
            authorizer,
        )
    }

    val recipeRepository: RecipeRepository by lazy { LocalRecipeRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }

    val dashboardRepository: DashboardRepository by lazy {
        DashboardRepository(database)
    }

    val operationsRepository: OperationsRepository by lazy {
        LocalOperationsRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }

    val securityRepository: SecurityRepository by lazy { LocalSecurityRepository(database, authorizer = authorizer) }

    val personnelRepository: PersonnelRepository by lazy { LocalPersonnelRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val performanceRepository by lazy { LocalPerformanceRepository(database, authorizer = authorizer, syncRecorder = syncRecorder) }
    val syncRepository by lazy { LocalSyncRepository(database) }
    private val syncPreferences by lazy { appContext.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE) }
    fun syncConfig(): CloudSyncConfig = CloudSyncConfig(syncPreferences.getString("endpoint","").orEmpty(),syncPreferences.getString("tenant","").orEmpty(),syncPreferences.getBoolean("enabled",false))
    suspend fun saveSyncConfig(config: CloudSyncConfig) { authorizer.require("BACKUP"); if(config.enabled) config.validated(); check(syncPreferences.edit().putString("endpoint",config.endpoint.trim()).putString("tenant",config.tenantId.trim()).putBoolean("enabled",config.enabled).commit()) }
    suspend fun runSync() = SyncCoordinator(syncRepository,HttpsSyncTransport(syncConfig())).runOnce()
    suspend fun runSyncAuthorized() = authorizer.require("BACKUP").let { runSync() }
    private val deviceId: String by lazy {
        val preferences = context.getSharedPreferences("sync_identity", Context.MODE_PRIVATE)
        preferences.getString("device_id", null) ?: UUID.randomUUID().toString().also { generated ->
            check(preferences.edit().putString("device_id", generated).commit()) { "ذخیره شناسه دستگاه انجام نشد." }
        }
    }
    val syncRecorder by lazy { SyncRecorder(database, deviceId) }
    val assetRepository: AssetRepository by lazy { LocalAssetRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val crmRepository: CrmRepository by lazy { LocalCrmRepository(database, authorizer = authorizer, syncRecorder = syncRecorder) }
    val alertRepository: AlertRepository by lazy { LocalAlertRepository(database) }
    val restaurantOperationsRepository by lazy { LocalRestaurantOperationsRepository(database, authorizer) }

    suspend fun createBackup(): String {
        authorizer.require("BACKUP")
        return withContext(Dispatchers.IO) { backupManager.create(database) }
    }
    suspend fun listBackups(): List<String> {
        authorizer.require("BACKUP")
        return withContext(Dispatchers.IO) { backupManager.list() }
    }
    suspend fun deleteBackup(name: String) {
        authorizer.require("BACKUP")
        withContext(Dispatchers.IO) { backupManager.delete(name) }
    }
    suspend fun scheduleRestore(name: String) {
        authorizer.require("BACKUP")
        withContext(Dispatchers.IO) { backupManager.scheduleRestore(name) }
    }
    suspend fun exportBackup(name: String, destination: Uri) {
        authorizer.require("BACKUP")
        withContext(Dispatchers.IO) {
            val output = requireNotNull(appContext.contentResolver.openOutputStream(destination, "w")) {
                "امکان نوشتن فایل مقصد وجود ندارد."
            }
            backupManager.export(name, output)
        }
    }
    suspend fun importBackup(source: Uri): String {
        authorizer.require("BACKUP")
        return withContext(Dispatchers.IO) {
            val input = requireNotNull(appContext.contentResolver.openInputStream(source)) {
                "امکان خواندن فایل انتخاب‌شده وجود ندارد."
            }
            backupManager.importFrom(input)
        }
    }

    val accountingRepository: AccountingRepository by lazy {
        LocalAccountingRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }
}
