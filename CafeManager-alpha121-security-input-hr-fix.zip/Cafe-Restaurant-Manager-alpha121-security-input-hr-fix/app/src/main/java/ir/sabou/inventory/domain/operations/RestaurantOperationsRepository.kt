package ir.sabou.inventory.domain.operations

import ir.sabou.inventory.domain.sales.Reservation
import ir.sabou.inventory.domain.sales.RestaurantTable
import ir.sabou.inventory.domain.sales.TableStatus
import kotlinx.coroutines.flow.Flow

interface RestaurantOperationsRepository {
    val tables: Flow<List<RestaurantTable>>
    val reservations: Flow<List<Reservation>>
    val kitchenTickets: Flow<List<KitchenTicket>>
    val shifts: Flow<List<PlannedShift>>
    val approvals: Flow<List<ApprovalRequest>>
    suspend fun addTable(label: String, capacity: Int, zone: String): Long
    suspend fun transitionTable(id: Long, status: TableStatus, orderId: Long? = null)
    suspend fun addReservation(value: Reservation): Long
    suspend fun addKitchenTicket(orderNo: String, station: String, itemName: String, quantity: Int, priority: Int): Long
    suspend fun transitionKitchenTicket(id: Long, status: KitchenTicketStatus)
    suspend fun planShift(demand: ShiftDemand, staff: List<StaffAvailability>): Int
    suspend fun requestApproval(type: String, entityId: Long, amountRial: Long, requestedBy: String): Long
    suspend fun reviewApproval(id: Long, approve: Boolean, by: String, note: String = "")
}
