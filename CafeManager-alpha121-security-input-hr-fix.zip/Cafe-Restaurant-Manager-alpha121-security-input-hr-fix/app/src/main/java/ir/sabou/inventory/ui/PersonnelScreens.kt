@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft

@Composable
fun PersonnelScreen(
    state: PersonnelUiState,
    performanceState: PerformanceUiState,
    onSaveEmployee: (Long?, EmployeeDraft) -> Unit,
    onDeactivate: (Long) -> Unit,
    onSaveAttendance: (Long?, AttendanceDraft) -> Unit,
    onPostPayroll: (PayrollDraft) -> Unit,
    onCalculatePayroll: (PayrollDraft) -> Unit,
    onSelectEmployee: (Long?) -> Unit,
    onSaveContract: (Long?, EmployeeContractDraft) -> Unit,
    onPostAdvance: (EmployeeAdvanceDraft) -> Unit,
    onSettleAdvance: (Long, Long) -> Unit,
    onRequestLeave: (LeaveDraft, String) -> Unit,
    onReviewLeave: (LeaveReviewDraft) -> Unit,
    onCancelLeave: (Long) -> Unit,
    onLoadAttendanceSummary: (Long, Long, Long) -> Unit,
    onSavePerformanceGoal: (ir.sabou.inventory.domain.personnel.PerformanceGoalDraft) -> Unit,
    onDeactivatePerformanceGoal: (Long) -> Unit,
    onSubmitPerformanceReview: (ir.sabou.inventory.domain.personnel.PerformanceReviewDraft) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    var showEmployee by remember { mutableStateOf(false) }
    var showPayroll by remember { mutableStateOf(false) }
    var showAttendance by remember { mutableStateOf(false) }
    var showLeave by remember { mutableStateOf(false) }
    var showSummary by remember { mutableStateOf(false) }
    var showContract by remember { mutableStateOf(false) }
    var showAdvance by remember { mutableStateOf(false) }
    val activeEmployees = state.employees.count { it.isActive }
    val totalPayroll = state.payrolls.sumOf { it.netPayRial }
    val monthlyCommitment = state.employees.filter { it.isActive }.sumOf { it.monthlySalaryRial }
    Scaffold(topBar = { ProfessionalTopBar("پرسنل و حقوق", "تیم، تعهد حقوق و پرداخت‌های ماهانه", onBack, "ثبت حقوق") { if (activeEmployees > 0) showPayroll = true } }, floatingActionButton = { ExtendedFloatingActionButton(onClick = { showEmployee = true }) { Text("پرسنل جدید") } }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = androidx.compose.foundation.layout.PaddingValues(start = 16.dp, top = 14.dp, end = 16.dp, bottom = 96.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item { PremiumHero("تعهد ماهانه حقوق", formatMoney(monthlyCommitment, CurrencyUnit.RIAL), "$activeEmployees نیروی فعال") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("کل پرسنل", state.employees.size.toString(), Modifier.weight(1f)); MetricTile("پرداخت‌شده", formatMoney(totalPayroll, CurrencyUnit.RIAL), Modifier.weight(1f)) } }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { if (activeEmployees > 0) showAttendance = true }, modifier = Modifier.weight(1f)) { Text("ثبت حضور") }
                    OutlinedButton(onClick = { if (activeEmployees > 0) showPayroll = true }, modifier = Modifier.weight(1f)) { Text("ثبت حقوق") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { showLeave = true }, enabled = activeEmployees > 0, modifier = Modifier.weight(1f)) { Text("درخواست مرخصی") }
                    OutlinedButton(onClick = { showSummary = true }, enabled = activeEmployees > 0, modifier = Modifier.weight(1f)) { Text("گزارش حضور") }
                }
            }
            if (state.pendingLeaves.isNotEmpty()) {
                item { SectionHeading("مرخصی‌های در انتظار", "تأیید یا رد درخواست‌ها") }
                items(state.pendingLeaves, key = { "leave-${it.id}" }) { leave ->
                    val employee = state.employees.firstOrNull { it.id == leave.employeeId }
                    Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text(employee?.name ?: "پرسنل", fontWeight = FontWeight.Bold)
                        Text("${epochDayToPersian(leave.startEpochDay).display()} تا ${epochDayToPersian(leave.endEpochDay).display()}")
                        Row { TextButton(onClick = { onReviewLeave(LeaveReviewDraft(leave.id, "APPROVE", "مدیر")) }) { Text("تأیید") }; TextButton(onClick = { onReviewLeave(LeaveReviewDraft(leave.id, "REJECT", "مدیر")) }) { Text("رد") }; TextButton(onClick = { onCancelLeave(leave.id) }) { Text("لغو") } }
                    } }
                }
            }
            item { SectionHeading("حضور و غیاب اخیر", "ورود، خروج، تأخیر و اضافه‌کاری") }
            if (state.attendance.isEmpty()) item { EmptyStatePanel("رکورد حضوری وجود ندارد", "ورود و خروج روزانه را ثبت کنید.") }
            items(state.attendance.take(10), key = { "attendance-${it.id}" }) { row ->
                val employeeName = state.employees.firstOrNull { it.id == row.employeeId }?.name ?: "پرسنل"
                Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(employeeName, fontWeight = FontWeight.Black); StatusPill(row.status) }
                        CompactInfoRow("تاریخ", epochDayToPersian(row.workEpochDay).display())
                        if (row.checkInMinute != null && row.checkOutMinute != null) {
                            CompactInfoRow("ورود / خروج", "${formatMinuteOfDay(row.checkInMinute)} / ${formatMinuteOfDay(row.checkOutMinute)}")
                        }
                        CompactInfoRow("کارکرد", "${row.workedMinutes} دقیقه")
                        CompactInfoRow("تأخیر / اضافه‌کاری", "${row.lateMinutes} / ${row.overtimeMinutes} دقیقه")
                    }
                }
            }
            item { SectionHeading("اعضای تیم", "اطلاعات شغلی و حقوق پایه") }
            item {
                PerformanceSection(
                    state = performanceState,
                    employees = state.employees,
                    onSaveGoal = onSavePerformanceGoal,
                    onDeactivateGoal = onDeactivatePerformanceGoal,
                    onSubmitReview = onSubmitPerformanceReview,
                )
            }
            if (state.employees.isEmpty()) item { EmptyStatePanel("هنوز پرسنلی ثبت نشده", "اولین عضو تیم را اضافه کنید.") }
            items(state.employees, key = { personnelEmployeeListKey(it.id) }) { employee ->
                Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) { Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(employee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black); Text(employee.jobTitle, color = MaterialTheme.colorScheme.onSurfaceVariant) }; StatusPill(if (employee.isActive) "فعال" else "غیرفعال") }
                        if (employee.fatherName.isNotBlank()) CompactInfoRow("نام پدر", employee.fatherName)
                        CompactInfoRow("حقوق پایه", formatMoney(employee.monthlySalaryRial, CurrencyUnit.RIAL), true)
                        if (employee.phone.isNotBlank()) CompactInfoRow("تماس", employee.phone)
                        employee.nationalId?.let { CompactInfoRow("کد ملی", it) }
                        employee.birthEpochDay?.let { CompactInfoRow("تاریخ تولد", epochDayToPersian(it).display()) }
                        employee.hireEpochDay?.let { CompactInfoRow("تاریخ استخدام", epochDayToPersian(it).display()) }
                        if (employee.isActive) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onSelectEmployee(employee.id); showContract = true }, modifier = Modifier.weight(1f)) { Text("قرارداد") }
                            OutlinedButton(onClick = { onSelectEmployee(employee.id); showAdvance = true }, modifier = Modifier.weight(1f)) { Text("مساعده") }
                        }
                        if (employee.isActive) OutlinedButton(onClick = { onDeactivate(employee.id) }, modifier = Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp)) { Text("غیرفعال‌کردن", color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
            item { SectionHeading("سوابق پرداخت", "آخرین حقوق‌های ثبت‌شده") }
            if (state.payrolls.isEmpty()) item { EmptyStatePanel("سابقه پرداختی وجود ندارد", "بعد از ثبت حقوق، سوابق اینجا دیده می‌شوند.") }
            items(state.payrolls, key = { personnelPayrollListKey(it.id) }) { payroll ->
                Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Column { Text(payroll.employeeName, fontWeight = FontWeight.Black); Text("دوره ${payroll.periodYear}/${payroll.periodMonth}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; StatusPill(payroll.status) }
                        CompactInfoRow("خالص پرداختی", formatMoney(payroll.netPayRial, CurrencyUnit.RIAL), true)
                        OutlinedButton(
                            onClick = { printPayrollSlip(context, payroll) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("چاپ فیش حقوقی / PDF") }
                    }
                }
            }
        }
    }
    if (showEmployee) EmployeeDialog({ showEmployee=false }) { onSaveEmployee(null,it); showEmployee=false }
    if (showAttendance) AttendanceDialog(state, { showAttendance=false }) { onSaveAttendance(null, it); showAttendance=false }
    if (showPayroll) PayrollDialog(state, { showPayroll=false }, onCalculatePayroll) { onPostPayroll(it); showPayroll=false }
    if (showLeave) LeaveDialog(state, { showLeave=false }) { onRequestLeave(it, "مدیر"); showLeave=false }
    if (showSummary) AttendanceSummaryDialog(state, { showSummary=false }, onLoadAttendanceSummary)
    if (showContract) ContractDialog(state, { showContract=false; onSelectEmployee(null) }) { onSaveContract(null, it); showContract=false; onSelectEmployee(null) }
    if (showAdvance) AdvanceDialog(state, { showAdvance=false; onSelectEmployee(null) }, onSettleAdvance) { onPostAdvance(it); showAdvance=false; onSelectEmployee(null) }
}

@Composable
private fun EmployeeDialog(onDismiss: () -> Unit, onSave: (EmployeeDraft) -> Unit) {
    var name by remember { mutableStateOf("") }
    var fatherName by remember { mutableStateOf("") }
    var job by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var salary by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }
    var birthDate by remember { mutableStateOf<Long?>(null) }
    var hireDate by remember { mutableLongStateOf(currentEpochDay()) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت پرسنل جدید") },
        text = {
            Column(
                Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedTextField(name, { name = it }, label = { Text("نام و نام خانوادگی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(fatherName, { fatherName = it }, label = { Text("نام پدر") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(job, { job = it }, label = { Text("عنوان شغلی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(nationalId, { nationalId = it.filter(Char::isDigit).take(10) }, label = { Text("کد ملی (۱۰ رقم)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OptionalPersianDateField("تاریخ تولد", birthDate, { birthDate = it })
                PersianDateField("تاریخ استخدام", hireDate, { hireDate = it })
                OutlinedTextField(
                    phone,
                    { phone = it.filter { ch -> ch.isDigit() || ch == '+' }.take(14) },
                    label = { Text("شماره تماس") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    salary,
                    { salary = formatMoneyInput(it) },
                    label = { Text("حقوق پایه (ریال)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching {
                    EmployeeDraft(
                        name = name,
                        fatherName = fatherName,
                        jobTitle = job,
                        phone = phone,
                        monthlySalaryRial = parseMoneyInputOrZero(salary),
                        nationalId = nationalId,
                        birthEpochDay = birthDate,
                        hireEpochDay = hireDate,
                    ).validated()
                }
                    .onSuccess(onSave)
                    .onFailure { error = it.message ?: "اطلاعات پرسنل معتبر نیست." }
            }) { Text("ذخیره پرسنل") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun AttendanceDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (AttendanceDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }
    var selected by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    val today = remember { currentEpochDay() }
    var workDay by remember { mutableLongStateOf(today) }
    var checkIn by remember { mutableStateOf("08:00") }
    var checkOut by remember { mutableStateOf("16:00") }
    var status by remember { mutableStateOf("PRESENT") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("ثبت حضور روزانه") },
        text = { Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            error?.let { MessageCard(it, isError = true) }
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(active.firstOrNull { it.id == selected }?.name ?: "انتخاب پرسنل") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) { active.forEach { employee -> DropdownMenuItem(text = { Text(employee.name) }, onClick = { selected = employee.id; expanded = false }) } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { status = "PRESENT" }, modifier = Modifier.weight(1f)) { Text(if (status == "PRESENT") "✓ حاضر" else "حاضر") }
                OutlinedButton(onClick = { status = "ABSENT" }, modifier = Modifier.weight(1f)) { Text(if (status == "ABSENT") "✓ غایب" else "غایب") }
            }
            if (status == "PRESENT") {
                ClockField(checkIn, { checkIn = it }, "ساعت ورود")
                ClockField(checkOut, { checkOut = it }, "ساعت خروج")
            }
            PersianDateField("تاریخ حضور", workDay, { workDay = it })
            OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                AttendanceDraft(
                    selected,
                    workDay,
                    status,
                    if (status == "PRESENT") parseClockMinute(checkIn) else null,
                    if (status == "PRESENT") parseClockMinute(checkOut) else null,
                    notes = notes,
                ).validated()
            }.onSuccess(onSave).onFailure { error = it.message ?: "اطلاعات حضور معتبر نیست." }
        }) { Text("ذخیره حضور") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayrollDialog(state: PersonnelUiState, onDismiss: () -> Unit, onCalculate: (PayrollDraft) -> Unit, onSave: (PayrollDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }
    var selected by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    val today = remember { currentEpochDay() }
    var periodDay by remember { mutableLongStateOf(today) }
    val payrollPeriod = epochDayToPersian(periodDay)
    var paymentDay by remember { mutableLongStateOf(today) }
    var overtime by remember { mutableStateOf("0") }
    var bonus by remember { mutableStateOf("0") }
    var deductions by remember { mutableStateOf("0") }
    var insurance by remember { mutableStateOf("0") }
    var tax by remember { mutableStateOf("0") }
    var paymentMethod by remember { mutableStateOf("BANK") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت حقوق ماهانه") },
        text = {
            Column(
                Modifier.heightIn(max = 580.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(active.firstOrNull { it.id == selected }?.name ?: "انتخاب پرسنل")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    active.forEach { employee ->
                        DropdownMenuItem(text = { Text(employee.name) }, onClick = { selected = employee.id; expanded = false })
                    }
                }
                PersianDateField("دوره حقوق", periodDay, { periodDay = it })
                MoneyField(overtime, { overtime = it }, "اضافه‌کار (ریال)")
                MoneyField(bonus, { bonus = it }, "پاداش (ریال)")
                MoneyField(deductions, { deductions = it }, "کسورات (ریال)")
                MoneyField(insurance, { insurance = it }, "بیمه (ریال)")
                MoneyField(tax, { tax = it }, "مالیات (ریال)")
                PersianDateField("تاریخ پرداخت", paymentDay, { paymentDay = it })
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { paymentMethod = "BANK" }, modifier = Modifier.weight(1f)) { Text(if (paymentMethod == "BANK") "✓ بانکی" else "بانکی") }
                    OutlinedButton(onClick = { paymentMethod = "CASH" }, modifier = Modifier.weight(1f)) { Text(if (paymentMethod == "CASH") "✓ نقدی" else "نقدی") }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                state.payrollPreview?.let { preview ->
                    MessageCard("ناخالص: ${formatMoney(preview.grossPayRial, CurrencyUnit.RIAL)} • کسورات: ${formatMoney(preview.totalDeductionsRial, CurrencyUnit.RIAL)} • خالص: ${formatMoney(preview.netPayRial, CurrencyUnit.RIAL)}")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val draft = PayrollDraft(
                    employeeId = selected,
                    periodYear = payrollPeriod.year,
                    periodMonth = payrollPeriod.month,
                    overtimeRial = parseMoneyInputOrZero(overtime),
                    bonusRial = parseMoneyInputOrZero(bonus),
                    deductionsRial = parseMoneyInputOrZero(deductions),
                    insuranceRial = parseMoneyInputOrZero(insurance),
                    taxRial = parseMoneyInputOrZero(tax),
                    paymentEpochDay = paymentDay,
                    paymentMethod = paymentMethod,
                    notes = notes,
                )
                runCatching { draft.validated() }
                    .onSuccess(onSave)
                    .onFailure { error = it.message ?: "اطلاعات حقوق معتبر نیست." }
            }) { Text("ثبت و صدور سند") }
        },
        dismissButton = { Row { TextButton(onClick = {
            val draft = PayrollDraft(selected, payrollPeriod.year, payrollPeriod.month, parseMoneyInputOrZero(overtime), parseMoneyInputOrZero(bonus), deductionsRial = parseMoneyInputOrZero(deductions), insuranceRial = parseMoneyInputOrZero(insurance), taxRial = parseMoneyInputOrZero(tax), paymentEpochDay = paymentDay, paymentMethod = paymentMethod, notes = notes)
            runCatching { draft.validated() }.onSuccess(onCalculate).onFailure { error = it.message }
        }) { Text("محاسبه") }; TextButton(onClick = onDismiss) { Text("انصراف") } } },
    )
}

@Composable
private fun LeaveDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (LeaveDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }; var employeeId by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }; var expanded by remember { mutableStateOf(false) }; var start by remember { mutableLongStateOf(currentEpochDay()) }; var end by remember { mutableLongStateOf(currentEpochDay()) }; var type by remember { mutableStateOf("PAID") }; var notes by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onDismiss,title={Text("درخواست مرخصی")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(active.firstOrNull{it.id==employeeId}?.name?:"انتخاب پرسنل")}; DropdownMenu(expanded,{expanded=false}){active.forEach{e->DropdownMenuItem(text={Text(e.name)},onClick={employeeId=e.id;expanded=false})}}; PersianDateField("از تاریخ",start,{start=it}); PersianDateField("تا تاریخ",end,{end=it}); Row{listOf("PAID" to "استحقاقی","SICK" to "استعلاجی","UNPAID" to "بدون حقوق").forEach{(v,t)->TextButton(onClick={type=v}){Text(if(type==v)"✓ $t" else t)}}};OutlinedTextField(notes,{notes=it},label={Text("توضیحات")})}},confirmButton={Button(onClick={onSave(LeaveDraft(employeeId,start,end,type,notes))}){Text("ثبت درخواست")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun AttendanceSummaryDialog(state: PersonnelUiState, onDismiss: () -> Unit, onLoad: (Long, Long, Long) -> Unit) {
    val active=state.employees.filter{it.isActive}; var employeeId by remember{mutableStateOf(active.firstOrNull()?.id?:0L)}; var expanded by remember{mutableStateOf(false)}; var from by remember{mutableLongStateOf(currentEpochDay()-30)}; var to by remember{mutableLongStateOf(currentEpochDay())}; val context=LocalContext.current
    AlertDialog(onDismissRequest=onDismiss,title={Text("گزارش حضور")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={expanded=true},modifier=Modifier.fillMaxWidth()){Text(active.firstOrNull{it.id==employeeId}?.name?:"انتخاب پرسنل")};DropdownMenu(expanded,{expanded=false}){active.forEach{e->DropdownMenuItem(text={Text(e.name)},onClick={employeeId=e.id;expanded=false})}};PersianDateField("از تاریخ",from,{from=it});PersianDateField("تا تاریخ",to,{to=it});state.attendanceSummary?.let{Text("حاضر: ${it.presentDays} • غیبت: ${it.absentDays} • مرخصی: ${it.leaveDays}\nکارکرد: ${it.workedMinutes} دقیقه • تأخیر: ${it.lateMinutes} • اضافه‌کاری: ${it.overtimeMinutes}",fontWeight=FontWeight.Bold);OutlinedButton(onClick={printAttendanceSummary(context,active.firstOrNull{employee->employee.id==employeeId}?.name?:"پرسنل",it)},modifier=Modifier.fillMaxWidth()){Text("چاپ گزارش حضور / PDF")}}}},confirmButton={Button(onClick={onLoad(employeeId,from,to)}){Text("محاسبه")}},dismissButton={TextButton(onClick=onDismiss){Text("بستن")}})
}

@Composable
private fun ContractDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (EmployeeContractDraft) -> Unit) {
    val id=state.selectedEmployeeId?:0L; var type by remember{mutableStateOf("تمام‌وقت")}; var start by remember{mutableLongStateOf(currentEpochDay())}; var end by remember{mutableStateOf<Long?>(null)}; var salary by remember{mutableStateOf(formatMoneyInput(state.employees.firstOrNull{it.id==id}?.monthlySalaryRial?.toString().orEmpty()))}
    AlertDialog(onDismissRequest=onDismiss,title={Text("ثبت قرارداد")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){state.contracts.firstOrNull()?.let{Text("قرارداد فعلی: ${it.contractType} • ${formatMoney(it.baseSalaryRial,CurrencyUnit.RIAL)}")};OutlinedTextField(type,{type=it},label={Text("نوع قرارداد")});PersianDateField("تاریخ شروع",start,{start=it});OptionalPersianDateField("تاریخ پایان",end,{end=it},defaultEpochDay=start);MoneyField(salary,{salary=it},"حقوق قرارداد")}},confirmButton={Button(onClick={onSave(EmployeeContractDraft(id,type,start,end,parseMoneyInputOrZero(salary)))}){Text("ذخیره قرارداد")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun AdvanceDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSettle: (Long, Long) -> Unit, onSave: (EmployeeAdvanceDraft) -> Unit) {
    val id=state.selectedEmployeeId?:0L; var amount by remember{mutableStateOf("")}; var day by remember{mutableLongStateOf(currentEpochDay())}; var method by remember{mutableStateOf("BANK")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("مساعده پرسنل")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){MoneyField(amount,{amount=it},"مبلغ مساعده (ریال)");PersianDateField("تاریخ مساعده",day,{day=it});Row{TextButton(onClick={method="BANK"}){Text(if(method=="BANK")"✓ بانکی" else "بانکی")};TextButton(onClick={method="CASH"}){Text(if(method=="CASH")"✓ نقدی" else "نقدی")}};state.advances.forEach{a->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("مانده: ${formatMoney(a.remainingAmountRial,CurrencyUnit.RIAL)}");if(a.status=="OPEN")TextButton(onClick={onSettle(a.id,a.remainingAmountRial)}){Text("تسویه کامل")}}}}},confirmButton={Button(onClick={onSave(EmployeeAdvanceDraft(id,parseMoneyInputOrZero(amount),day,method))}){Text("ثبت مساعده")}},dismissButton={TextButton(onClick=onDismiss){Text("بستن")}})
}

@Composable
private fun MoneyField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(formatMoneyInput(it)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = modifier,
    )
}

@Composable
private fun ClockField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(normalizeClockInput(it)) },
        label = { Text("$label (HH:mm)") },
        supportingText = { Text("نمونه: 08:30") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
    )
}
