package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.EmployeeEntity
import ir.sabou.inventory.data.db.EmployeeAdvanceEntity
import ir.sabou.inventory.data.db.EmployeeContractEntity
import ir.sabou.inventory.data.db.AttendanceEntity
import ir.sabou.inventory.data.db.LeaveEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.db.PayrollRunEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceDraft
import ir.sabou.inventory.domain.personnel.EmployeeAdvanceRecord
import ir.sabou.inventory.domain.personnel.EmployeeContractDraft
import ir.sabou.inventory.domain.personnel.EmployeeContractRecord
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.AttendanceCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollPolicy
import ir.sabou.inventory.domain.personnel.AttendancePayrollAdjustment
import ir.sabou.inventory.domain.personnel.LeaveDraft
import ir.sabou.inventory.domain.personnel.LeaveRecord
import ir.sabou.inventory.domain.personnel.LeaveReviewDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollCalculation
import ir.sabou.inventory.domain.personnel.PayrollCalculator
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalPersonnelRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : PersonnelRepository {
    private val personnel get() = database.personnelDao()
    private val accounting get() = database.accountingDao()

    override val employees: Flow<List<EmployeeRecord>> = personnel.observeEmployees().map { rows ->
        rows.map { EmployeeRecord(it.id, it.name, it.fatherName, it.jobTitle, it.phone, it.monthlySalaryRial, it.status == "ACTIVE", it.nationalId, it.birthEpochDay, it.hireEpochDay) }
    }

    override val payrolls: Flow<List<PayrollRecord>> = personnel.observePayrolls().map { rows ->
        rows.map { PayrollRecord(it.id, it.employeeName, it.periodYear, it.periodMonth, it.grossPayRial, it.netPayRial, it.paymentEpochDay, it.paymentMethod, it.status) }
    }

    override val attendance: Flow<List<AttendanceRecord>> = personnel.observeAttendance().map { rows ->
        rows.map { it.toRecord() }
    }

    override val leaves: Flow<List<LeaveRecord>> = personnel.observeLeaves().map { rows -> rows.map { it.toRecord() } }
    override val pendingLeaves: Flow<List<LeaveRecord>> = personnel.observePendingLeaves().map { rows -> rows.map { it.toRecord() } }

    override suspend fun saveEmployee(id: Long?, draft: EmployeeDraft): Long {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            if (id == null) {
                personnel.insertEmployee(EmployeeEntity(name = valid.name, fatherName = valid.fatherName, jobTitle = valid.jobTitle, phone = valid.phone,
                    nationalId = valid.nationalId.ifBlank { null }, birthEpochDay = valid.birthEpochDay, hireEpochDay = valid.hireEpochDay,
                    monthlySalaryRial = valid.monthlySalaryRial, leaveBalanceMicros = 0, createdAtEpochMillis = now, updatedAtEpochMillis = now)).also { syncRecorder?.record("EMPLOYEE", it, "CREATE", now) }
            } else {
                val current = personnel.employeeById(id) ?: error("پرسنل پیدا نشد.")
                check(personnel.updateEmployee(current.copy(name=valid.name, fatherName=valid.fatherName, jobTitle=valid.jobTitle, phone=valid.phone,
                    nationalId=valid.nationalId.ifBlank { null }, birthEpochDay=valid.birthEpochDay, hireEpochDay=valid.hireEpochDay,
                    monthlySalaryRial=valid.monthlySalaryRial, status="ACTIVE", updatedAtEpochMillis=now)) == 1)
                syncRecorder?.record("EMPLOYEE", id, "UPDATE", now)
                id
            }
        }
    }

    override suspend fun deactivateEmployee(id: Long) {
        authorizer.require("PERSONNEL")
        val now = clock()
        check(personnel.deactivateEmployee(id, now) == 1) { "غیرفعال‌کردن پرسنل انجام نشد." }
        syncRecorder?.record("EMPLOYEE", id, "DEACTIVATE", now)
    }

    override fun contracts(employeeId: Long): Flow<List<EmployeeContractRecord>> =
        personnel.observeContracts(employeeId).map { rows ->
            rows.map { it.toRecord() }
        }

    override fun advances(employeeId: Long): Flow<List<EmployeeAdvanceRecord>> =
        personnel.observeAdvances(employeeId).map { rows -> rows.map { it.toRecord() } }

    override val openAdvances: Flow<List<EmployeeAdvanceRecord>> =
        personnel.observeOpenAdvances().map { rows -> rows.map { it.toRecord() } }

    override suspend fun saveContract(id: Long?, draft: EmployeeContractDraft): Long {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان قرارداد ثبت کرد." }
            if (id == null) {
                personnel.insertContract(
                    EmployeeContractEntity(
                        employeeId = valid.employeeId,
                        contractType = valid.contractType,
                        startEpochDay = valid.startEpochDay,
                        endEpochDay = valid.endEpochDay,
                        baseSalaryRial = valid.baseSalaryRial,
                        dailyWorkMinutes = valid.dailyWorkMinutes,
                        weeklyWorkDays = valid.weeklyWorkDays,
                        notes = valid.notes,
                        createdAtEpochMillis = now,
                        updatedAtEpochMillis = now,
                    ),
                )
            } else {
                val current = personnel.contractById(id) ?: error("قرارداد پیدا نشد.")
                require(current.employeeId == valid.employeeId) { "پرسنل قرارداد قابل تغییر نیست." }
                check(
                    personnel.updateContract(
                        current.copy(
                            contractType = valid.contractType,
                            startEpochDay = valid.startEpochDay,
                            endEpochDay = valid.endEpochDay,
                            baseSalaryRial = valid.baseSalaryRial,
                            dailyWorkMinutes = valid.dailyWorkMinutes,
                            weeklyWorkDays = valid.weeklyWorkDays,
                            notes = valid.notes,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "ویرایش قرارداد انجام نشد." }
                id
            }
        }
    }

    override suspend fun saveAttendance(id: Long?, draft: AttendanceDraft): Long {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        val calculated = AttendanceCalculator.calculate(valid)
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان حضور ثبت کرد." }
            if (valid.status != "LEAVE") {
                require(!personnel.hasApprovedLeave(valid.employeeId, valid.workEpochDay)) { "برای این روز مرخصی تأییدشده وجود دارد." }
            }
            val entity = AttendanceEntity(
                id = id ?: 0, employeeId = valid.employeeId, workEpochDay = valid.workEpochDay,
                status = valid.status, checkInMinute = valid.checkInMinute, checkOutMinute = valid.checkOutMinute,
                lateMinutes = calculated.lateMinutes, overtimeMinutes = calculated.overtimeMinutes, notes = valid.notes,
            )
            if (id == null) personnel.insertAttendance(entity) else {
                val current = personnel.attendanceById(id) ?: error("رکورد حضور پیدا نشد.")
                require(current.employeeId == valid.employeeId) { "پرسنل رکورد حضور قابل تغییر نیست." }
                check(personnel.updateAttendance(entity) == 1) { "ویرایش حضور انجام نشد." }
                id
            }
        }
    }

    override suspend fun attendanceSummary(employeeId: Long, startEpochDay: Long, endEpochDay: Long): AttendanceSummary {
        authorizer.require("PERSONNEL")
        require(employeeId > 0 && startEpochDay > 0 && endEpochDay >= startEpochDay) { "بازه گزارش معتبر نیست." }
        val rows = personnel.attendanceInRange(employeeId, startEpochDay, endEpochDay)
        return AttendanceSummary(
            employeeId, startEpochDay, endEpochDay,
            presentDays = rows.count { it.status == "PRESENT" },
            absentDays = rows.count { it.status == "ABSENT" },
            leaveDays = rows.count { it.status == "LEAVE" },
            missionDays = rows.count { it.status == "MISSION" },
            workedMinutes = rows.sumOf { row -> if (row.checkInMinute != null && row.checkOutMinute != null) row.checkOutMinute - row.checkInMinute else 0 },
            lateMinutes = rows.sumOf { it.lateMinutes },
            overtimeMinutes = rows.sumOf { it.overtimeMinutes },
        )
    }

    override suspend fun attendancePayrollAdjustment(
        employeeId: Long,
        startEpochDay: Long,
        endEpochDay: Long,
        policy: AttendancePayrollPolicy,
    ): AttendancePayrollAdjustment {
        authorizer.require("PERSONNEL")
        return AttendancePayrollCalculator.calculate(
            attendanceSummary(employeeId, startEpochDay, endEpochDay),
            policy,
        )
    }

    override suspend fun requestLeave(draft: LeaveDraft, requestedBy: String): Long {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        require(requestedBy.trim().isNotEmpty()) { "ثبت‌کننده درخواست مشخص نیست." }
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
            require(!personnel.hasLeaveOverlap(valid.employeeId, valid.startEpochDay, valid.endEpochDay)) { "این درخواست با مرخصی دیگری هم‌پوشانی دارد." }
            val now = clock()
            personnel.insertLeave(LeaveEntity(
                employeeId = valid.employeeId, startEpochDay = valid.startEpochDay, endEpochDay = valid.endEpochDay,
                daysMicros = (valid.endEpochDay - valid.startEpochDay + 1) * 1_000_000L,
                leaveType = valid.leaveType, status = "PENDING", notes = valid.notes, requestedBy = requestedBy.trim(),
                createdAtEpochMillis = now, updatedAtEpochMillis = now,
            ))
        }
    }

    override suspend fun reviewLeave(draft: LeaveReviewDraft) {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        database.withTransaction {
            val current = personnel.leaveById(valid.leaveId) ?: error("درخواست مرخصی پیدا نشد.")
            require(current.status == "PENDING") { "فقط درخواست در انتظار قابل بررسی است." }
            val now = clock()
            if (valid.decision == "APPROVE") {
                require(!personnel.hasAttendanceConflict(current.employeeId, current.startEpochDay, current.endEpochDay)) { "در بازه مرخصی، رکورد حضور متعارض وجود دارد." }
                for (day in current.startEpochDay..current.endEpochDay) {
                    val existing = personnel.attendanceByEmployeeDay(current.employeeId, day)
                    if (existing == null) {
                        personnel.insertAttendance(AttendanceEntity(employeeId=current.employeeId, workEpochDay=day, status="LEAVE", checkInMinute=null, checkOutMinute=null, lateMinutes=0, overtimeMinutes=0, notes="ثبت خودکار از گردش کار مرخصی"))
                    }
                }
            }
            check(personnel.updateLeave(current.copy(
                status = if (valid.decision == "APPROVE") "APPROVED" else "REJECTED",
                reviewedBy = valid.reviewer, reviewNotes = valid.notes, reviewedAtEpochMillis = now, updatedAtEpochMillis = now,
            )) == 1) { "ثبت نتیجه بررسی مرخصی انجام نشد." }
        }
    }

    override suspend fun cancelLeave(id: Long) {
        authorizer.require("PERSONNEL")
        database.withTransaction {
            val current = personnel.leaveById(id) ?: error("درخواست مرخصی پیدا نشد.")
            require(current.status == "PENDING") { "فقط درخواست در انتظار قابل لغو است." }
            val now = clock()
            check(personnel.updateLeave(current.copy(status="CANCELLED", cancelledAtEpochMillis=now, updatedAtEpochMillis=now)) == 1) { "لغو درخواست انجام نشد." }
        }
    }

    override suspend fun approveLeave(draft: LeaveDraft): Long {
        authorizer.require("PERSONNEL")
        val id = requestLeave(draft, "SYSTEM")
        reviewLeave(LeaveReviewDraft(id, "APPROVE", "SYSTEM", "تأیید مستقیم سازگار با نسخه قبلی"))
        return id
    }

    override suspend fun postAdvance(draft: EmployeeAdvanceDraft): Long {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "برای پرسنل غیرفعال نمی‌توان مساعده ثبت کرد." }
            val entryId = accounting.insertEntry(
                JournalEntryEntity(
                    entryNo = "TMP-ADV-${clock()}",
                    entryEpochDay = valid.advanceEpochDay,
                    description = "مساعده پرسنل: ${employee.name}",
                    sourceType = "EMPLOYEE_ADVANCE",
                    sourceId = 0,
                    createdAtEpochMillis = clock(),
                ),
            )
            check(accounting.finalizeEntryIdentity(entryId, "م-$entryId", entryId) == 1)
            val paymentAccount = if (valid.paymentMethod == "CASH") "1101" else "1102"
            accounting.insertLines(
                listOf(
                    JournalLineEntity(entryId = entryId, accountCode = "1401", debitRial = valid.amountRial, creditRial = 0, memo = "مساعده ${employee.name}"),
                    JournalLineEntity(entryId = entryId, accountCode = paymentAccount, debitRial = 0, creditRial = valid.amountRial, memo = "پرداخت مساعده"),
                ),
            )
            val now = clock()
            personnel.insertAdvance(
                EmployeeAdvanceEntity(
                    employeeId = employee.id,
                    amountRial = valid.amountRial,
                    advanceEpochDay = valid.advanceEpochDay,
                    paymentMethod = valid.paymentMethod,
                    journalEntryId = entryId,
                    notes = valid.notes,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
        }
    }

    override suspend fun settleAdvance(id: Long, amountRial: Long) {
        authorizer.require("PERSONNEL")
        require(amountRial > 0) { "مبلغ تسویه باید بیشتر از صفر باشد." }
        database.withTransaction {
            val current = personnel.advanceById(id) ?: error("مساعده پیدا نشد.")
            require(current.status == "OPEN") { "این مساعده قبلاً تسویه شده است." }
            val newSettled = SignedLongMath.add(current.settledAmountRial, amountRial)
            require(newSettled <= current.amountRial) { "مبلغ تسویه بیشتر از مانده مساعده است." }
            check(
                personnel.updateAdvance(
                    current.copy(
                        settledAmountRial = newSettled,
                        status = if (newSettled == current.amountRial) "SETTLED" else "OPEN",
                        updatedAtEpochMillis = clock(),
                    ),
                ) == 1,
            ) { "تسویه مساعده انجام نشد." }
        }
    }

    override suspend fun calculatePayroll(draft: PayrollDraft): PayrollCalculation {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
        require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
        return PayrollCalculator.calculate(employee.monthlySalaryRial, valid)
    }

    override suspend fun postPayroll(draft: PayrollDraft): Long {
        authorizer.require("PERSONNEL")
        val valid = draft.validated()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
            require(!personnel.payrollExists(employee.id, valid.periodYear, valid.periodMonth)) { "حقوق این دوره قبلاً ثبت شده است." }
            val calculation = PayrollCalculator.calculate(employee.monthlySalaryRial, valid)
            require(calculation.grossPayRial >= calculation.netPayRial) { "محاسبه فیش حقوقی نامعتبر است." }
            val cashAccount = if (valid.paymentMethod == "CASH") "1101" else "1102"
            listOf("6101", cashAccount, "2104", "2103", "2102", "1401").distinct().forEach { code ->
                require(accounting.activeAccountExists(code)) { "حساب حسابداری $code در دفتر فعال نیست؛ ابتدا سرفصل‌ها را تکمیل کنید." }
            }
            val tempNo = "TMP-PAY-${clock()}"
            val entryId = accounting.insertEntry(JournalEntryEntity(entryNo=tempNo, entryEpochDay=valid.paymentEpochDay,
                description="حقوق ${employee.name} ${valid.periodYear}/${valid.periodMonth}", sourceType="PAYROLL", sourceId=0,
                createdAtEpochMillis=clock()))
            accounting.insertLines(listOf(
                JournalLineEntity(entryId=entryId, accountCode="6101", debitRial=calculation.grossPayRial, creditRial=0, memo="حقوق، مزایا و پاداش"),
                JournalLineEntity(entryId=entryId, accountCode=cashAccount, debitRial=0, creditRial=calculation.netPayRial, memo="خالص پرداخت"),
                JournalLineEntity(entryId=entryId, accountCode="2104", debitRial=0, creditRial=valid.insuranceRial, memo="بیمه پرداختنی"),
                JournalLineEntity(entryId=entryId, accountCode="2103", debitRial=0, creditRial=valid.taxRial, memo="مالیات پرداختنی"),
                JournalLineEntity(entryId=entryId, accountCode="2102", debitRial=0, creditRial=valid.deductionsRial, memo="سایر کسورات"),
                JournalLineEntity(entryId=entryId, accountCode="1401", debitRial=0, creditRial=valid.advanceDeductionRial, memo="کسر مساعده"),
            ).filter { it.debitRial != 0L || it.creditRial != 0L })
            val payrollId = personnel.insertPayroll(PayrollRunEntity(employeeId=employee.id, periodYear=valid.periodYear, periodMonth=valid.periodMonth,
                baseSalaryRial=calculation.baseSalaryRial, overtimeRial=valid.overtimeRial,
                bonusRial=SignedLongMath.add(valid.bonusRial, valid.allowancesRial),
                deductionsRial=SignedLongMath.add(valid.deductionsRial, valid.advanceDeductionRial),
                insuranceRial=valid.insuranceRial, taxRial=valid.taxRial, netPayRial=calculation.netPayRial,
                paymentEpochDay=valid.paymentEpochDay, paymentMethod=valid.paymentMethod, journalEntryId=entryId,
                notes=valid.notes, createdAtEpochMillis=clock()))
            check(payrollId > 0L) { "ثبت فیش حقوقی انجام نشد." }
            // Link the journal to the actual payroll row only after its id exists.
            check(accounting.finalizeEntryIdentity(entryId, "ح-$entryId", payrollId) == 1) {
                "تکمیل ارتباط سند حقوق با فیش انجام نشد."
            }
            syncRecorder?.record("PAYROLL", payrollId, "CREATE", clock())
            payrollId
        }
    }
}

private fun EmployeeContractEntity.toRecord() = EmployeeContractRecord(
    id = id,
    employeeId = employeeId,
    contractType = contractType,
    startEpochDay = startEpochDay,
    endEpochDay = endEpochDay,
    baseSalaryRial = baseSalaryRial,
    dailyWorkMinutes = dailyWorkMinutes,
    weeklyWorkDays = weeklyWorkDays,
    status = status,
    notes = notes,
)

private fun EmployeeAdvanceEntity.toRecord(): EmployeeAdvanceRecord {
    val remaining = SignedLongMath.subtract(amountRial, settledAmountRial)
    return EmployeeAdvanceRecord(
        id = id,
        employeeId = employeeId,
        amountRial = amountRial,
        settledAmountRial = settledAmountRial,
        remainingAmountRial = remaining,
        advanceEpochDay = advanceEpochDay,
        paymentMethod = paymentMethod,
        journalEntryId = journalEntryId,
        status = status,
        notes = notes,
    )
}


private fun AttendanceEntity.toRecord() = AttendanceRecord(
    id = id, employeeId = employeeId, workEpochDay = workEpochDay, status = status,
    checkInMinute = checkInMinute, checkOutMinute = checkOutMinute,
    workedMinutes = if (checkInMinute != null && checkOutMinute != null) checkOutMinute - checkInMinute else 0,
    lateMinutes = lateMinutes, overtimeMinutes = overtimeMinutes, notes = notes,
)


private fun LeaveEntity.toRecord() = LeaveRecord(
    id=id, employeeId=employeeId, startEpochDay=startEpochDay, endEpochDay=endEpochDay, daysMicros=daysMicros,
    leaveType=leaveType, status=status, notes=notes, requestedBy=requestedBy, reviewedBy=reviewedBy,
    reviewNotes=reviewNotes, reviewedAtEpochMillis=reviewedAtEpochMillis,
)
