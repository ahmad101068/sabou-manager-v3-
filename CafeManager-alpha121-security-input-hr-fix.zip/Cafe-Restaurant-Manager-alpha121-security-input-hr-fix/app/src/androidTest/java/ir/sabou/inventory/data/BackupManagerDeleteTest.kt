package ir.sabou.inventory.data

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import java.io.File
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BackupManagerDeleteTest {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private lateinit var backup: File

    @Before
    fun setUp() {
        val backupDirectory = File(context.filesDir, "backups").apply { mkdirs() }
        backup = File(backupDirectory, "delete-test-${System.nanoTime()}.db")
        backup.writeBytes(ByteArray(4_096) { 1 })
    }

    @After
    fun tearDown() {
        backup.delete()
    }

    @Test
    fun manualBackupCanBeDeleted() {
        val manager = BackupManager(context)
        manager.scheduleRestore(backup.name)
        manager.delete(backup.name)

        assertFalse(backup.exists())
        assertNull(
            context.getSharedPreferences("backup_state", Context.MODE_PRIVATE)
                .getString("pending_restore", null),
        )
    }
}
