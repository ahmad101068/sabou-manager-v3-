package ir.sabou.inventory.domain.personnel

import org.junit.Assert.assertEquals
import org.junit.Test

class EmployeeDraftTest {
    @Test
    fun fatherNameIsTrimmedWithOtherIdentityFields() {
        val result = EmployeeDraft(
            name = "  کارمند تست  ",
            fatherName = "  احمد  ",
            jobTitle = "  آشپز  ",
            phone = "09120000000",
            monthlySalaryRial = 10_000_000,
        ).validated()

        assertEquals("احمد", result.fatherName)
    }
}
