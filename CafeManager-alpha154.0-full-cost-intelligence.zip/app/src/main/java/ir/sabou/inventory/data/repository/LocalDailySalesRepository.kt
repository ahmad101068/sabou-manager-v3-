package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AuditLogEntity
import ir.sabou.inventory.data.db.DailySalesMenuLineEntity
import ir.sabou.inventory.data.db.DailySalesSummaryEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryLotConsumptionEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.db.SalesDayClosureEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.data.security.SensitiveActionGate
import ir.sabou.inventory.domain.operations.SensitiveAction
import ir.sabou.inventory.domain.recipe.MenuEngineeringCalculator
import ir.sabou.inventory.domain.recipe.FullCostCalculator
import ir.sabou.inventory.domain.recipe.MenuPerformanceInput
import ir.sabou.inventory.domain.sales.DailySalesDraft
import ir.sabou.inventory.domain.sales.DailySalesItem
import ir.sabou.inventory.domain.sales.DailySalesReport
import ir.sabou.inventory.domain.sales.DailySalesRepository
import ir.sabou.inventory.domain.sales.MenuProfitabilityResult
import ir.sabou.inventory.domain.sales.DailySalesProfitabilityLine
import ir.sabou.inventory.domain.sales.DailySalesReversalDraft
import ir.sabou.inventory.domain.sales.SalesDayClosureDraft
import ir.sabou.inventory.domain.sales.SalesDayReopenDraft
import ir.sabou.inventory.domain.sales.SalesDayClosureRecord
import java.math.BigInteger
import java.util.UUID
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

class LocalDailySalesRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val syncRecorder: SyncRecorder? = null,
    private val clock: () -> Long = System::currentTimeMillis,
    private val sensitiveActionGate: SensitiveActionGate = SensitiveActionGate(),
) : DailySalesRepository {
    override val dayClosures: Flow<List<SalesDayClosureRecord>> = database.dailySalesDao().observeDayClosures().map { rows ->
        rows.map { SalesDayClosureRecord(it.businessEpochDay, it.summaryId, it.grossSalesRial, it.netSalesRial, it.theoreticalCostRial, it.cashRial, it.cardRial, it.transferRial, it.status, it.revisionNo, it.closedBy, it.note, it.reopenedBy, it.reopenReason, it.createdAtEpochMillis) }
    }

    override suspend fun post(draft: DailySalesDraft): Long {
        authorizer.require("SALES")
        require(draft.businessEpochDay > 0) { "تاریخ فروش معتبر نیست." }
        require(draft.lines.isNotEmpty()) { "حداقل یک آیتم از منو وارد کنید." }
        require(draft.lines.all { it.menuItemId > 0 && it.quantityMicros > 0 && it.grossSalesRial >= 0 }) { "اطلاعات ردیف‌های فروش ناقص است." }
        require(draft.lines.map { it.menuItemId }.distinct().size == draft.lines.size) { "هر آیتم منو باید فقط یک‌بار در فروش روزانه ثبت شود." }
        require(listOf(draft.discountRial, draft.serviceRial, draft.taxRial, draft.cashRial, draft.cardRial, draft.transferRial).all { it >= 0 }) { "مبالغ نمی‌توانند منفی باشند." }
        val now = clock()
        return database.withTransaction {
            require(!database.dailySalesDao().dayClosed(draft.businessEpochDay)) { "این روز فروش بسته و امضاشده است و قابل ثبت مجدد نیست." }
            require(!database.dailySalesDao().dayExists(draft.businessEpochDay)) { "فروش این روز قبلاً ثبت شده است؛ برای جلوگیری از ثبت تکراری، همان روز را دوباره وارد نکنید." }
            val gross = draft.lines.fold(0L) { total, line -> SignedLongMath.add(total, line.grossSalesRial) }
            require(gross > 0) { "فروش ناخالص باید بیشتر از صفر باشد." }
            require(draft.discountRial <= gross) { "تخفیف نمی‌تواند از فروش ناخالص بیشتر باشد." }
            val productRevenue = SignedLongMath.subtract(gross, draft.discountRial)
            val net = SignedLongMath.add(SignedLongMath.add(productRevenue, draft.serviceRial), draft.taxRial)
            val payments = SignedLongMath.add(SignedLongMath.add(draft.cashRial, draft.cardRial), draft.transferRial)
            require(payments == net) { "جمع روش‌های پرداخت باید دقیقاً با فروش خالص برابر باشد." }

            data class Consumption(val item: InventoryItemEntity, val quantity: Long, val cost: Long)
            data class PreparedLine(
                val menuId: Long,
                val recipeVersionId: Long,
                val name: String,
                val quantity: Long,
                val gross: Long,
                val cost: Long,
                val foodCost: Long,
                val packagingCost: Long,
                val directLaborCost: Long,
                val allocatedOverhead: Long,
            )
            val consumptions = mutableListOf<Consumption>()
            val preparedLines = draft.lines.map { line ->
                val menu = database.recipeDao().activeMenuItem(line.menuItemId) ?: error("آیتم منوی انتخاب‌شده فعال نیست.")
                val recipeVersion = database.recipeDao().effectiveVersion(menu.id, draft.businessEpochDay)
                    ?: error("برای «${menu.name}» در تاریخ فروش، نسخه مؤثر رسپی وجود ندارد.")
                val ingredients = database.recipeDao().versionIngredients(recipeVersion.id)
                require(ingredients.isNotEmpty()) { "برای «${menu.name}» رسپی کامل ثبت نشده است." }
                var lineCost = 0L
                ingredients.forEach { ingredient ->
                    val item = database.inventoryDao().activeById(ingredient.inventoryItemId) ?: error("یکی از مواد اولیه «${menu.name}» فعال نیست.")
                    val needed = mulDiv(ingredient.quantityMicrosPerUnit, line.quantityMicros, 1_000_000L)
                    require(needed > 0) { "مصرف محاسبه‌شده برای ${item.name} نامعتبر است." }
                    val cost = if (item.stockMicros == 0L) 0L else mulDiv(item.inventoryValueRial, needed, item.stockMicros)
                    consumptions += Consumption(item, needed, cost)
                    lineCost = SignedLongMath.add(lineCost, cost)
                }
                val packaging = mulDiv(recipeVersion.packagingCostRial, line.quantityMicros, 1_000_000L)
                val labor = mulDiv(recipeVersion.directLaborCostRial, line.quantityMicros, 1_000_000L)
                val overhead = mulDiv(recipeVersion.allocatedOverheadRial, line.quantityMicros, 1_000_000L)
                val fullCost = FullCostCalculator.calculate(
                    FullCostCalculator.Input(
                        rawIngredientCostRial = lineCost,
                        yieldMicros = recipeVersion.yieldMicros,
                        preparationWasteBasisPoints = recipeVersion.preparationWasteBasisPoints,
                        cookingWasteBasisPoints = recipeVersion.cookingWasteBasisPoints,
                        packagingCostRial = packaging,
                        directLaborCostRial = labor,
                        allocatedOverheadRial = overhead,
                        salePriceRial = line.grossSalesRial,
                    ),
                )
                PreparedLine(menu.id, recipeVersion.id, menu.name, line.quantityMicros, line.grossSalesRial, lineCost, fullCost.foodCostRial, packaging, labor, overhead)
            }
            val aggregated = consumptions.groupBy { it.item.id }.map { (_, rows) ->
                val item = rows.first().item
                val quantity = rows.fold(0L) { total, row -> SignedLongMath.add(total, row.quantity) }
                val cost = rows.fold(0L) { total, row -> SignedLongMath.add(total, row.cost) }
                require(item.stockMicros >= quantity) { "موجودی ${item.name} برای فروش ثبت‌شده کافی نیست." }
                Triple(item, quantity, cost)
            }
            val totalCost = preparedLines.fold(0L) { total, line -> SignedLongMath.add(total, line.cost) }
            val summaryId = database.dailySalesDao().insertSummary(
                DailySalesSummaryEntity(
                    businessEpochDay = draft.businessEpochDay,
                    grossSalesRial = gross,
                    discountRial = draft.discountRial,
                    serviceRial = draft.serviceRial,
                    taxRial = draft.taxRial,
                    netSalesRial = net,
                    theoreticalCostRial = totalCost,
                    cashRial = draft.cashRial,
                    cardRial = draft.cardRial,
                    transferRial = draft.transferRial,
                    notes = draft.notes.trim(),
                    journalEntryId = null,
                    costJournalEntryId = null,
                    createdAtEpochMillis = now,
                ),
            )
            database.dailySalesDao().insertLines(preparedLines.map {
                DailySalesMenuLineEntity(
                    summaryId = summaryId,
                    menuItemId = it.menuId,
                    recipeVersionId = it.recipeVersionId,
                    menuItemNameSnapshot = it.name,
                    quantityMicros = it.quantity,
                    grossSalesRial = it.gross,
                    theoreticalCostRial = it.cost,
                    foodCostSnapshotRial = it.foodCost,
                    packagingCostSnapshotRial = it.packagingCost,
                    directLaborCostSnapshotRial = it.directLaborCost,
                    allocatedOverheadSnapshotRial = it.allocatedOverhead,
                )
            })
            aggregated.forEach { (item, quantity, cost) ->
                check(database.inventoryDao().updateValuation(item.id, item.stockMicros - quantity, item.inventoryValueRial - cost, now) == 1)
                val movementId = database.stockMovementDao().insert(
                    StockMovementEntity(
                        itemId = item.id,
                        movementType = "DAILY_SALES_CONSUMPTION",
                        quantityDeltaMicros = -quantity,
                        valueDeltaRial = -cost,
                        referenceType = "DAILY_SALES",
                        referenceId = summaryId,
                        movementEpochDay = draft.businessEpochDay,
                        notes = "مصرف رسپی فروش روزانه",
                        createdAtEpochMillis = now,
                    ),
                )
                consumeLotsFefo(item.id, quantity, movementId, now)
            }
            val journalId = database.accountingDao().insertEntry(
                JournalEntryEntity(entryNo = "فر-$summaryId", entryEpochDay = draft.businessEpochDay, description = "فروش تجمیعی صندوق", sourceType = "DAILY_SALES", sourceId = summaryId, createdAtEpochMillis = now),
            )
            val revenueLines = buildList {
                if (draft.cashRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "1101", debitRial = draft.cashRial, creditRial = 0))
                if (draft.cardRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "1102", debitRial = draft.cardRial, creditRial = 0, memo = "کارتخوان"))
                if (draft.transferRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "1102", debitRial = draft.transferRial, creditRial = 0, memo = "حواله"))
                if (productRevenue > 0) add(JournalLineEntity(entryId = journalId, accountCode = "4101", debitRial = 0, creditRial = productRevenue))
                if (draft.serviceRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "4103", debitRial = 0, creditRial = draft.serviceRial))
                if (draft.taxRial > 0) add(JournalLineEntity(entryId = journalId, accountCode = "2103", debitRial = 0, creditRial = draft.taxRial))
            }
            database.accountingDao().insertLines(revenueLines)
            val costJournalId = if (totalCost > 0) {
                val costJournal = database.accountingDao().insertEntry(
                    JournalEntryEntity(entryNo = "بفر-$summaryId", entryEpochDay = draft.businessEpochDay, description = "بهای تمام‌شده فروش تجمیعی", sourceType = "DAILY_SALES_COGS", sourceId = summaryId, createdAtEpochMillis = now),
                )
                database.accountingDao().insertLines(listOf(
                    JournalLineEntity(entryId = costJournal, accountCode = "5101", debitRial = totalCost, creditRial = 0),
                    JournalLineEntity(entryId = costJournal, accountCode = "1301", debitRial = 0, creditRial = totalCost),
                ))
                costJournal
            } else null
            check(database.dailySalesDao().linkJournals(summaryId, journalId, costJournalId) == 1)
            syncRecorder?.record("DAILY_SALES", summaryId, "CREATE", now)
            audit("CREATE", summaryId, "ثبت فروش روز ${draft.businessEpochDay}؛ خالص=$net؛ بهای تمام‌شده=$totalCost؛ سند=$journalId", now)
            summaryId
        }
    }

    override suspend fun reverse(draft: DailySalesReversalDraft) {
        authorizer.require("SALES")
        database.withTransaction {
            val summary = database.dailySalesDao().summary(draft.summaryId)
                ?: error("فروش روزانه پیدا نشد.")
            val valid = draft.validated(summary.businessEpochDay)
            require(!summary.isLegacyArchive) {
                "فروش آرشیوی نسخه‌های قبل از این مسیر قابل برگشت نیست."
            }
            require(summary.reversedAtEpochDay == null) { "این فروش روزانه قبلاً برگشت خورده است." }
            require(!database.dailySalesDao().dayClosed(summary.businessEpochDay)) { "این روز فروش بسته و امضاشده است و قابل برگشت نیست." }
            val movements = database.stockMovementDao().dailySalesConsumptions(summary.id)
            require(movements.isNotEmpty()) { "گردش موجودی فروش روزانه کامل نیست." }
            val now = clock()

            movements.forEach { movement ->
                require(movement.quantityDeltaMicros < 0 && movement.valueDeltaRial <= 0) {
                    "گردش مصرف فروش روزانه نامعتبر است."
                }
                val item = database.inventoryDao().byId(movement.itemId)
                    ?: error("ماده اولیه مصرف‌شده پیدا نشد.")
                val restoredQuantity = SignedLongMath.subtract(0, movement.quantityDeltaMicros)
                val restoredValue = SignedLongMath.subtract(0, movement.valueDeltaRial)
                check(
                    database.inventoryDao().restoreValuation(
                        itemId = item.id,
                        stockMicros = SignedLongMath.add(item.stockMicros, restoredQuantity),
                        inventoryValueRial = SignedLongMath.add(item.inventoryValueRial, restoredValue),
                        updatedAtEpochMillis = now,
                    ) == 1,
                ) { "بازگردانی موجودی ${item.name} انجام نشد." }

                database.managementControlDao().lotConsumptions(movement.id).forEach { consumption ->
                    val restoreToLot = SignedLongMath.subtract(consumption.quantityMicros, consumption.reversedQuantityMicros)
                    if (restoreToLot > 0) {
                        val lot = database.managementControlDao().lot(consumption.lotId)
                            ?: error("لات مصرف‌شده پیدا نشد.")
                        check(
                            database.managementControlDao().updateLot(
                                lot.copy(
                                    quantityMicros = SignedLongMath.add(lot.quantityMicros, restoreToLot),
                                    updatedAtEpochMillis = now,
                                ),
                            ) == 1,
                        ) { "بازگردانی موجودی لات انجام نشد." }
                        check(database.managementControlDao().markLotConsumptionReversed(consumption.id) == 1) {
                            "ثبت بازگشت مصرف لات انجام نشد."
                        }
                    }
                }

                database.stockMovementDao().insert(
                    StockMovementEntity(
                        itemId = item.id,
                        movementType = "DAILY_SALES_REVERSAL",
                        quantityDeltaMicros = restoredQuantity,
                        valueDeltaRial = restoredValue,
                        referenceType = "DAILY_SALES",
                        referenceId = summary.id,
                        movementEpochDay = valid.reversalEpochDay,
                        notes = "برگشت فروش روزانه: ${valid.reason}",
                        createdAtEpochMillis = now,
                    ),
                )
            }

            val revenueReversalId = reverseJournal(
                originalEntryId = summary.journalEntryId,
                summaryId = summary.id,
                epochDay = valid.reversalEpochDay,
                reason = valid.reason,
                originalSourceType = "DAILY_SALES",
                sourceType = "DAILY_SALES_REVERSAL",
                entryPrefix = "بفر",
                description = "برگشت فروش تجمیعی صندوق",
                now = now,
            ) ?: error("سند درآمد فروش روزانه پیدا نشد.")
            val costReversalId = reverseJournal(
                originalEntryId = summary.costJournalEntryId,
                summaryId = summary.id,
                epochDay = valid.reversalEpochDay,
                reason = valid.reason,
                originalSourceType = "DAILY_SALES_COGS",
                sourceType = "DAILY_SALES_COGS_REVERSAL",
                entryPrefix = "ببفر",
                description = "برگشت بهای تمام‌شده فروش تجمیعی",
                now = now,
            )
            check(
                database.dailySalesDao().markReversed(
                    summaryId = summary.id,
                    reversalEpochDay = valid.reversalEpochDay,
                    reason = valid.reason,
                    reversalJournalEntryId = revenueReversalId,
                    reversalCostJournalEntryId = costReversalId,
                ) == 1,
            ) { "وضعیت برگشت فروش روزانه ثبت نشد." }
            syncRecorder?.record("DAILY_SALES", summary.id, "REVERSAL", now)
            audit("REVERSE", summary.id, "برگشت فروش روز ${summary.businessEpochDay}؛ خالص=${summary.netSalesRial}؛ دلیل=${valid.reason}", now)
        }
    }

    override suspend fun closeDay(draft: SalesDayClosureDraft) {
        authorizer.require("SALES")
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.CLOSE_SALES_DAY)
        val valid = draft.validated()
        database.withTransaction {
            val dao = database.dailySalesDao()
            require(!dao.dayClosed(valid.businessEpochDay)) { "این روز قبلاً بسته شده است." }
            val summary = dao.activeSummaryByDay(valid.businessEpochDay) ?: error("برای این روز فروش فعال ثبت نشده است.")
            require(!summary.isLegacyArchive) { "روزهای آرشیوی باید از گردش کنترل مهاجرت بررسی شوند." }
            val actor = authorizer.actor()
            val now = clock()
            val previousClosure = dao.dayClosure(valid.businessEpochDay)
            val refreshed = SalesDayClosureEntity(
                businessEpochDay = summary.businessEpochDay, summaryId = summary.id,
                grossSalesRial = summary.grossSalesRial, netSalesRial = summary.netSalesRial,
                theoreticalCostRial = summary.theoreticalCostRial,
                cashRial = summary.cashRial, cardRial = summary.cardRial, transferRial = summary.transferRial,
                status = "CLOSED", revisionNo = (previousClosure?.revisionNo ?: 0) + 1,
                closedBy = actor, note = valid.note, createdAtEpochMillis = now,
            )
            if (previousClosure == null) dao.insertDayClosure(refreshed)
            else check(dao.updateDayClosure(refreshed) == 1) { "بستن مجدد روز فروش انجام نشد." }
            database.auditLogDao().insert(ir.sabou.inventory.data.db.AuditLogEntity(
                action = "CLOSE", entityType = "SALES_DAY", entityId = summary.id,
                description = "بستن روز فروش ${summary.businessEpochDay} به مبلغ ${summary.netSalesRial} ریال",
                actor = actor, createdAtEpochMillis = now,
            ))
            syncRecorder?.record("SALES_DAY", summary.id, "CLOSE", now)
        }
    }

    override suspend fun reopenDay(draft: SalesDayReopenDraft) {
        authorizer.requireOwner()
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.REOPEN_SALES_DAY)
        val valid = draft.validated()
        database.withTransaction {
            val dao = database.dailySalesDao()
            val closure = dao.dayClosure(valid.businessEpochDay) ?: error("سند بستن روز فروش پیدا نشد.")
            require(closure.status == "CLOSED") { "این روز در وضعیت بسته نیست." }
            val actor = authorizer.actor()
            val now = clock()
            check(dao.updateDayClosure(closure.copy(status = "REOPENED", reopenedBy = actor, reopenReason = valid.reason, reopenedAtEpochMillis = now)) == 1) {
                "بازگشایی روز فروش انجام نشد."
            }
            database.auditLogDao().insert(ir.sabou.inventory.data.db.AuditLogEntity(
                action = "REOPEN", entityType = "SALES_DAY", entityId = closure.summaryId,
                description = "بازگشایی کنترل‌شده روز فروش ${closure.businessEpochDay}: ${valid.reason}",
                actor = actor, createdAtEpochMillis = now,
            ))
            syncRecorder?.record("SALES_DAY", closure.summaryId, "REOPEN", now)
        }
    }

    override fun observe(query: String): Flow<List<DailySalesItem>> = combine(
        database.dailySalesDao().observeSummaries(query.trim()),
        database.dailySalesDao().observeDayClosures(),
        database.dailySalesDao().observeSummaryProfitability(),
        database.dailySalesDao().observeAllLines(),
    ) { rows, closures, profitabilityRows, lineRows ->
        val byDay = closures.associateBy { it.businessEpochDay }
        val bySummary = profitabilityRows.associateBy { it.summaryId }
        val linesBySummary = lineRows.groupBy { it.summaryId }
        rows.map { row -> row.toDomain(byDay[row.businessEpochDay], bySummary[row.id], linesBySummary[row.id].orEmpty()) }
    }

    override fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<DailySalesReport> = combine(
        database.dailySalesDao().observeRange(fromEpochDay, toEpochDay),
        database.dailySalesDao().observeMenuPerformance(fromEpochDay, toEpochDay),
    ) { summaries, menuRows ->
        val performanceInputs = menuRows.mapNotNull { row ->
            row.menuItemId?.takeIf { id ->
                id > 0 && row.unitsSold > 0 && row.salesRial > 0 && row.costRial >= 0
            }?.let { MenuPerformanceInput(it, row.name, row.unitsSold, row.salesRial, row.costRial) }
        }
        val menuPerformance = if (performanceInputs.isEmpty()) emptyList() else MenuEngineeringCalculator.classify(performanceInputs)
        val profitability = menuRows.mapNotNull { row ->
            val id = row.menuItemId ?: return@mapNotNull null
            val complete = row.totalLineCount > 0 && row.fullCostLineCount == row.totalLineCount
            val fullCost = row.fullCostRial.takeIf { complete }
            MenuProfitabilityResult(
                menuItemId = id,
                name = row.name,
                unitsSold = row.unitsSold,
                salesRial = row.salesRial,
                foodCostRial = row.costRial,
                fullCostRial = fullCost,
                foodMarginRial = SignedLongMath.subtract(row.salesRial, row.costRial),
                fullMarginRial = fullCost?.let { SignedLongMath.subtract(row.salesRial, it) },
                fullCostBasisPoints = fullCost?.takeIf { row.salesRial > 0 }?.let { mulDiv(it, 10_000, row.salesRial).coerceAtMost(Int.MAX_VALUE.toLong()).toInt() },
                hasCompleteFullCost = complete,
            )
        }
        val sales = summaries.fold(0L) { total, summary ->
            val posted = if (summary.businessEpochDay in fromEpochDay..toEpochDay) summary.netSalesRial else 0
            val reversed = if (summary.reversedAtEpochDay?.let { it in fromEpochDay..toEpochDay } == true) summary.netSalesRial else 0
            SignedLongMath.add(total, SignedLongMath.subtract(posted, reversed))
        }
        val cost = summaries.fold(0L) { total, summary ->
            val posted = if (summary.businessEpochDay in fromEpochDay..toEpochDay) summary.theoreticalCostRial else 0
            val reversed = if (summary.reversedAtEpochDay?.let { it in fromEpochDay..toEpochDay } == true) summary.theoreticalCostRial else 0
            SignedLongMath.add(total, SignedLongMath.subtract(posted, reversed))
        }
        val eventDays = buildSet {
            summaries.forEach { summary ->
                if (summary.businessEpochDay in fromEpochDay..toEpochDay) add(summary.businessEpochDay)
                summary.reversedAtEpochDay?.takeIf { it in fromEpochDay..toEpochDay }?.let { add(it) }
            }
        }
        val coveredLines = menuRows.sumOf { it.fullCostLineCount }
        val totalLines = menuRows.sumOf { it.totalLineCount }
        val fullCost = menuRows.fold(0L) { total, row -> SignedLongMath.add(total, row.fullCostRial) }.takeIf { totalLines > 0 && coveredLines == totalLines }
        DailySalesReport(
            fromEpochDay,
            toEpochDay,
            eventDays.size,
            sales,
            cost,
            SignedLongMath.subtract(sales, cost),
            menuPerformance,
            fullCost,
            fullCost?.let { SignedLongMath.subtract(sales, it) },
            coveredLines,
            totalLines,
            profitability,
        )
    }

    private suspend fun consumeLotsFefo(itemId: Long, quantityMicros: Long, stockMovementId: Long, now: Long) {
        var remaining = quantityMicros
        database.managementControlDao().availableLotsFefo(itemId).forEach { lot ->
            if (remaining <= 0L) return@forEach
            val consumed = minOf(remaining, lot.quantityMicros)
            check(database.managementControlDao().updateLot(lot.copy(quantityMicros = lot.quantityMicros - consumed, updatedAtEpochMillis = now)) == 1)
            database.managementControlDao().insertLotConsumption(InventoryLotConsumptionEntity(stockMovementId = stockMovementId, lotId = lot.id, quantityMicros = consumed))
            remaining -= consumed
        }
    }

    private suspend fun reverseJournal(
        originalEntryId: Long?,
        summaryId: Long,
        epochDay: Long,
        reason: String,
        originalSourceType: String,
        sourceType: String,
        entryPrefix: String,
        description: String,
        now: Long,
    ): Long? {
        if (originalEntryId == null) return null
        val original = database.accountingDao().entryById(originalEntryId)
            ?: error("سند حسابداری مبدأ پیدا نشد.")
        require(original.status == "POSTED") { "سند حسابداری مبدأ ثبت‌شده نیست." }
        require(original.sourceType == originalSourceType && original.sourceId == summaryId) {
            "سند حسابداری مبدأ با فروش روزانه تطابق ندارد."
        }
        val lines = database.accountingDao().linesByEntry(original.id)
        require(lines.size >= 2) { "آرتیکل‌های سند حسابداری مبدأ کامل نیستند." }
        val reversalId = database.accountingDao().insertEntry(
            JournalEntryEntity(
                entryNo = "TMP-${UUID.randomUUID()}",
                entryEpochDay = epochDay,
                description = "$description: $reason",
                sourceType = sourceType,
                sourceId = summaryId,
                createdAtEpochMillis = now,
            ),
        )
        check(database.accountingDao().finalizeEntryIdentity(reversalId, "$entryPrefix-$reversalId", summaryId) == 1) {
            "شماره‌گذاری سند برگشت انجام نشد."
        }
        database.accountingDao().insertLines(
            lines.map { line ->
                JournalLineEntity(
                    entryId = reversalId,
                    accountCode = line.accountCode,
                    debitRial = line.creditRial,
                    creditRial = line.debitRial,
                    memo = reason,
                )
            },
        )
        return reversalId
    }

    private fun DailySalesSummaryEntity.toDomain(
        closure: SalesDayClosureEntity? = null,
        profitability: ir.sabou.inventory.data.db.DailySalesProfitabilityRow? = null,
        lines: List<DailySalesMenuLineEntity> = emptyList(),
    ): DailySalesItem {
        val completeFullCost = profitability
            ?.takeIf { it.totalLineCount > 0 && it.coveredLineCount == it.totalLineCount }
            ?.fullCostRial
        return DailySalesItem(
            id = id,
            businessEpochDay = businessEpochDay,
            grossSalesRial = grossSalesRial,
            discountRial = discountRial,
            serviceRial = serviceRial,
            taxRial = taxRial,
            netSalesRial = netSalesRial,
            theoreticalCostRial = theoreticalCostRial,
            fullCostRial = completeFullCost,
            fullMarginRial = completeFullCost?.let { SignedLongMath.subtract(netSalesRial, it) },
            fullCostCoverageLineCount = profitability?.coveredLineCount ?: 0,
            totalLineCount = profitability?.totalLineCount ?: 0,
            profitabilityLines = lines.map { line ->
                DailySalesProfitabilityLine(
                    line.menuItemId,
                    line.recipeVersionId,
                    line.menuItemNameSnapshot,
                    line.quantityMicros,
                    line.grossSalesRial,
                    line.theoreticalCostRial,
                    line.foodCostSnapshotRial,
                    line.packagingCostSnapshotRial,
                    line.directLaborCostSnapshotRial,
                    line.allocatedOverheadSnapshotRial,
                )
            },
            cashRial = cashRial,
            cardRial = cardRial,
            transferRial = transferRial,
            notes = notes,
            isLegacyArchive = isLegacyArchive,
            reversedAtEpochDay = reversedAtEpochDay,
            reversalReason = reversalReason,
            isClosed = closure?.status == "CLOSED",
            closedBy = closure?.closedBy,
            closeNote = closure?.note.orEmpty(),
            closureStatus = closure?.status,
            closureRevisionNo = closure?.revisionNo ?: 0,
            reopenedBy = closure?.reopenedBy,
            reopenReason = closure?.reopenReason.orEmpty(),
        )
    }

    private suspend fun audit(action: String, entityId: Long, description: String, now: Long) {
        database.auditLogDao().insert(
            AuditLogEntity(
                action = action,
                entityType = "DAILY_SALES",
                entityId = entityId,
                description = description.replace('\n', ' ').replace('\r', ' ').replace('|', '/').take(500),
                actor = authorizer.actor().replace('\n', ' ').replace('\r', ' ').take(120),
                createdAtEpochMillis = now,
            ),
        )
    }

    private fun mulDiv(a: Long, b: Long, divisor: Long): Long = BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(divisor)).longValueExact()
}
