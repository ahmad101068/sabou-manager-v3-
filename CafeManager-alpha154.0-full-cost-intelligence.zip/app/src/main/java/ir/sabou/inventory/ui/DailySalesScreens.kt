package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.domain.sales.DailyMenuSaleDraft
import ir.sabou.inventory.domain.sales.DailySalesItem

@Composable
fun DailySalesScreen(
    state: DailySalesUiState,
    onSearch: (String) -> Unit,
    onPost: (Long, Long, Long, Long, Long, Long, Long, String, List<DailyMenuSaleDraft>, () -> Unit) -> Unit,
    onReverse: (Long, Long, String, () -> Unit) -> Unit,
    onCloseDay: (Long, String, String, () -> Unit) -> Unit,
    onReopenDay: (Long, String, String, () -> Unit) -> Unit,
    onSetReportRange: (Long, Long) -> Unit,
    onBack: () -> Unit,
) {
    var showEntry by remember { mutableStateOf(false) }
    var showReport by remember { mutableStateOf(false) }
    var search by rememberSaveable { mutableStateOf("") }
    var reversalTarget by remember { mutableStateOf<DailySalesItem?>(null) }
    var closeTarget by remember { mutableStateOf<DailySalesItem?>(null) }
    var reopenTarget by remember { mutableStateOf<DailySalesItem?>(null) }
    Scaffold(
        topBar = { ProfessionalTopBar("فروش روزانه صندوق", "ورود دستی خروجی POS؛ بدون مشتری، میز و آشپزخانه", onBack) },
        floatingActionButton = { Button(onClick = { showEntry = true }, enabled = !state.busy) { Text("ثبت فروش روز") } },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.message?.let { item { MessageCard(it) } }
            item {
                PremiumHero("فروش ۳۰ روز", formatMoney(state.activeSalesRial), "سود ناخالص ${formatMoney(state.grossProfitRial)}")
            }
            item {
                OutlinedTextField(value = search, onValueChange = { search = it; onSearch(it) }, label = { Text("جست‌وجوی یادداشت یا تاریخ") }, modifier = Modifier.fillMaxWidth())
            }
            item { OutlinedButton(onClick = { showReport = true }, modifier = Modifier.fillMaxWidth()) { Text("گزارش بازه‌ای و مهندسی منو") } }
            if (state.sales.isEmpty()) item { EmptyStatePanel("هنوز فروش روزانه‌ای ثبت نشده", "خروجی روز صندوق را بر اساس آیتم‌های منو وارد کنید.") }
            items(state.sales, key = { it.id }) { sale ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(epochDayToPersian(sale.businessEpochDay).display(), fontWeight = FontWeight.ExtraBold)
                            if (sale.isReversed) StatusPill("برگشت‌خورده")
                            else if (sale.isClosed) StatusPill("بسته و امضاشده")
                            else Text(formatMoney(sale.netSalesRial), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Text("فروش ناخالص ${formatMoney(sale.grossSalesRial)} · بهای مواد ${formatMoney(sale.theoreticalCostRial)}")
                        if (sale.fullCostRial != null && sale.fullMarginRial != null) {
                            Text("بهای کامل ${formatMoney(sale.fullCostRial)} · حاشیه کامل ${formatMoney(sale.fullMarginRial)}", fontWeight = FontWeight.Bold)
                        } else if (sale.totalLineCount > 0) {
                            Text("اطلاعات بهای کامل این فروش تاریخی کامل نیست (${sale.fullCostCoverageLineCount}/${sale.totalLineCount})", color = MaterialTheme.colorScheme.error)
                        }
                        sale.profitabilityLines.take(4).forEach { line ->
                            val lineFullCost = line.fullCostRial
                            val lineFullMargin = line.fullMarginRial
                            Surface(Modifier.fillMaxWidth(), shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f)) {
                                Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("${line.name} · ${formatQuantity(line.quantityMicros)} واحد · نسخه رسپی ${line.recipeVersionId ?: "نامشخص"}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                    if (lineFullCost != null && lineFullMargin != null) Text("مواد ${formatMoney(line.ingredientCostRial)} · بهای کامل ${formatMoney(lineFullCost)} · حاشیه ${formatMoney(lineFullMargin)}", style = MaterialTheme.typography.bodySmall)
                                    else Text("Snapshot بهای کامل برای این ردیف موجود نیست.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        Text("نقد ${formatMoney(sale.cashRial)} · کارت ${formatMoney(sale.cardRial)} · حواله ${formatMoney(sale.transferRial)}", style = MaterialTheme.typography.bodySmall)
                        if (sale.isLegacyArchive) Text("آرشیو تبدیل‌شده از نسخه قدیمی", color = MaterialTheme.colorScheme.tertiary)
                        if (sale.isReversed) {
                            Text("برگشت در ${epochDayToPersian(requireNotNull(sale.reversedAtEpochDay)).display()} · ${sale.reversalReason}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                        if (sale.isClosed) {
                            Text("بسته‌شده توسط ${sale.closedBy ?: "مدیر"} · ویرایش ${sale.closureRevisionNo}${sale.closeNote.takeIf { it.isNotBlank() }?.let { " · $it" }.orEmpty()}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = { reopenTarget = sale }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text("بازگشایی کنترل‌شده (مالک)") }
                        }
                        if (sale.closureStatus == "REOPENED") Text("بازگشایی‌شده توسط ${sale.reopenedBy ?: "مالک"} · ${sale.reopenReason}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        if (sale.notes.isNotBlank()) Text(sale.notes, style = MaterialTheme.typography.bodySmall)
                        if (!sale.isLegacyArchive && !sale.isReversed && !sale.isClosed) {
                            OutlinedButton(onClick = { reversalTarget = sale }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
                                Text("برگشت برای اصلاح")
                            }
                            Button(onClick = { closeTarget = sale }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
                                Text("بستن و امضای روز فروش")
                            }
                        }
                    }
                }
            }
        }
    }
    if (showEntry) DailySalesEntryDialog(state.menuItems, onDismiss = { showEntry = false }, onSave = onPost)
    if (showReport) DailySalesReportDialog(state, onDismiss = { showReport = false }, onApply = onSetReportRange)
    reversalTarget?.let { sale ->
        DailySalesReversalDialog(
            sale = sale,
            busy = state.busy,
            onDismiss = { reversalTarget = null },
            onConfirm = { epochDay, reason ->
                onReverse(sale.id, epochDay, reason) { reversalTarget = null }
            },
        )
    }
    closeTarget?.let { sale ->
        SalesDayCloseDialog(sale, state.busy, state.message, { closeTarget = null }) { note, pin ->
            onCloseDay(sale.businessEpochDay, note, pin) { closeTarget = null }
        }
    }
    reopenTarget?.let { sale ->
        SalesDayReopenDialog(sale, state.busy, state.message, { reopenTarget = null }) { reason, pin ->
            onReopenDay(sale.businessEpochDay, reason, pin) { reopenTarget = null }
        }
    }
}

@Composable
private fun SalesDayReopenDialog(sale: DailySalesItem, busy: Boolean, message: String?, onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var reason by remember(sale.id) { mutableStateOf("") }
    var pin by remember(sale.id) { mutableStateOf("") }
    var submitted by remember(sale.id) { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بازگشایی روز فروش") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("قفل دیتابیس این روز با مجوز مالک باز می‌شود و رویداد مستقل حسابرسی و همگام‌سازی ثبت خواهد شد.")
            Text(epochDayToPersian(sale.businessEpochDay).display(), fontWeight = FontWeight.Bold)
            OutlinedTextField(reason, { reason = it.take(300) }, label = { Text("دلیل اجباری بازگشایی") }, minLines = 3, modifier = Modifier.fillMaxWidth())
            if (submitted) message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            SensitivePinField(pin, { pin = it })
        } },
        confirmButton = { Button(enabled = !busy && reason.trim().length >= 5 && pin.length in 6..12, onClick = { val submittedPin = pin; pin = ""; submitted = true; onConfirm(reason.trim(), submittedPin) }) { Text("بازگشایی با ثبت رویداد") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun SalesDayCloseDialog(sale: DailySalesItem, busy: Boolean, message: String?, onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var note by remember(sale.id) { mutableStateOf("") }
    var pin by remember(sale.id) { mutableStateOf("") }
    var submitted by remember(sale.id) { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("بستن روز فروش") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("پس از تأیید، فروش، بهای تمام‌شده و روش‌های دریافت این روز snapshot می‌شوند و روز دیگر قابل برگشت یا ثبت مجدد نیست.")
            Text("${epochDayToPersian(sale.businessEpochDay).display()} · فروش خالص ${formatMoney(sale.netSalesRial)} · سود ناخالص ${formatMoney(SignedLongMath.subtract(sale.netSalesRial, sale.theoreticalCostRial))}", fontWeight = FontWeight.Bold)
            OutlinedTextField(note, { note = it }, label = { Text("یادداشت مدیر (اختیاری)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            if (submitted) message?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            SensitivePinField(pin, { pin = it })
        } },
        confirmButton = { Button(enabled = !busy && pin.length in 6..12, onClick = { val submittedPin = pin; pin = ""; submitted = true; onConfirm(note.trim(), submittedPin) }) { Text("بستن قطعی") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DailySalesReversalDialog(
    sale: DailySalesItem,
    busy: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (Long, String) -> Unit,
) {
    var reversalDay by remember(sale.id) { mutableLongStateOf(maxOf(currentEpochDay(), sale.businessEpochDay)) }
    var reason by remember(sale.id) { mutableStateOf("") }
    var error by remember(sale.id) { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("برگشت فروش روزانه") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("تمام آثار موجودی، لات و اسناد درآمد و بهای تمام‌شده خنثی می‌شوند. سپس همین روز را می‌توانید با ارقام صحیح دوباره ثبت کنید.")
                Text("روز فروش: ${epochDayToPersian(sale.businessEpochDay).display()} · مبلغ: ${formatMoney(sale.netSalesRial)}", fontWeight = FontWeight.Bold)
                PersianDateField("تاریخ برگشت", reversalDay, { reversalDay = it })
                OutlinedTextField(reason, { reason = it }, label = { Text("دلیل برگشت") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    when {
                        reversalDay < sale.businessEpochDay -> error = "تاریخ برگشت نمی‌تواند قبل از روز فروش باشد."
                        reason.trim().length !in 3..200 -> error = "دلیل برگشت باید بین ۳ تا ۲۰۰ نویسه باشد."
                        else -> onConfirm(reversalDay, reason.trim())
                    }
                },
            ) { Text("برگشت قطعی") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DailySalesEntryDialog(
    menuItems: List<MenuItem>,
    onDismiss: () -> Unit,
    onSave: (Long, Long, Long, Long, Long, Long, Long, String, List<DailyMenuSaleDraft>, () -> Unit) -> Unit,
) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var discount by remember { mutableStateOf("") }
    var service by remember { mutableStateOf("") }
    var tax by remember { mutableStateOf("") }
    var cash by remember { mutableStateOf("") }
    var card by remember { mutableStateOf("") }
    var transfer by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val quantities = remember { mutableStateMapOf<Long, String>() }
    val amounts = remember { mutableStateMapOf<Long, String>() }
    val discountRial = parseMoneyInputOrNull(discount) ?: 0L
    val serviceRial = parseMoneyInputOrNull(service) ?: 0L
    val taxRial = parseMoneyInputOrNull(tax) ?: 0L
    val cashRial = parseMoneyInputOrNull(cash) ?: 0L
    val cardRial = parseMoneyInputOrNull(card) ?: 0L
    val transferRial = parseMoneyInputOrNull(transfer) ?: 0L
    val invalidMoneyInput = (amounts.values + listOf(discount, service, tax, cash, card, transfer))
        .any { it.isNotBlank() && parseMoneyInputOrNull(it) == null }
    val lines = menuItems.mapNotNull { menu ->
        val quantity = runCatching { parseQuantity(quantities[menu.id].orEmpty()).value }.getOrDefault(0)
        if (quantity <= 0) null else DailyMenuSaleDraft(menu.id, quantity, parseMoneyInputOrNull(amounts[menu.id].orEmpty()) ?: 0L)
    }
    val totals = runCatching {
        val gross = lines.fold(0L) { total, line -> SignedLongMath.add(total, line.grossSalesRial) }
        val net = SignedLongMath.add(
            SignedLongMath.add(SignedLongMath.subtract(gross, discountRial), serviceRial),
            taxRial,
        )
        val paid = SignedLongMath.add(SignedLongMath.add(cashRial, cardRial), transferRial)
        Triple(gross, net, paid)
    }.getOrNull()
    val gross = totals?.first ?: 0L
    val net = totals?.second ?: 0L
    val paid = totals?.third ?: 0L
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت خروجی روزانه صندوق") },
        text = {
            LazyColumn(Modifier.fillMaxWidth().heightIn(max = 610.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                item { PersianDateField("روز فروش", day, { day = it }) }
                item { Text("آیتم‌های فروخته‌شده", fontWeight = FontWeight.ExtraBold) }
                items(menuItems, key = { it.id }) { menu ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("${menu.name} · ${menu.category}", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(quantities[menu.id].orEmpty(), { quantities[menu.id] = it }, label = { Text("تعداد") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                                OutlinedTextField(amounts[menu.id].orEmpty(), { amounts[menu.id] = formatMoneyInput(it) }, label = { Text("فروش کل") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            }
                        }
                    }
                }
                item { HorizontalDivider() }
                item { OutlinedTextField(discount, { discount = formatMoneyInput(it) }, label = { Text("تخفیف کل") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(service, { service = formatMoneyInput(it) }, label = { Text("حق سرویس") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(tax, { tax = formatMoneyInput(it) }, label = { Text("مالیات و عوارض") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { Text("تفکیک دریافتی صندوق", fontWeight = FontWeight.ExtraBold) }
                item { OutlinedTextField(cash, { cash = formatMoneyInput(it) }, label = { Text("نقد") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(card, { card = formatMoneyInput(it) }, label = { Text("کارتخوان") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { OutlinedTextField(transfer, { transfer = formatMoneyInput(it) }, label = { Text("حواله") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { Text("فروش خالص ${formatMoney(net)} · دریافتی ${formatMoney(paid)}", fontWeight = FontWeight.Bold, color = if (net == paid) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
                item { OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") }, modifier = Modifier.fillMaxWidth()) }
                error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(onClick = {
                when {
                    invalidMoneyInput || totals == null -> error = "مبلغ واردشده از محدوده مجاز خارج است."
                    menuItems.isEmpty() -> error = "ابتدا منو و رسپی‌ها را تعریف کنید."
                    lines.isEmpty() -> error = "تعداد فروش حداقل یک آیتم را وارد کنید."
                    lines.any { it.grossSalesRial <= 0 } -> error = "فروش کل هر آیتم باید بیشتر از صفر باشد."
                    net < 0 -> error = "فروش خالص نمی‌تواند منفی باشد."
                    paid != net -> error = "جمع نقد، کارت و حواله باید با فروش خالص برابر باشد."
                    else -> onSave(day, discountRial, serviceRial, taxRial, cashRial, cardRial, transferRial, notes, lines, onDismiss)
                }
            }) { Text("ثبت و صدور سند") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DailySalesReportDialog(state: DailySalesUiState, onDismiss: () -> Unit, onApply: (Long, Long) -> Unit) {
    var from by remember { mutableLongStateOf(state.reportFromEpochDay) }
    var to by remember { mutableLongStateOf(state.reportToEpochDay) }
    var profitabilitySort by remember { mutableStateOf("MARGIN") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("گزارش فروش تجمیعی") },
        text = { LazyColumn(Modifier.fillMaxWidth().heightIn(max = 600.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { PersianDateField("از تاریخ", from, { from = it }) }
            item { PersianDateField("تا تاریخ", to, { to = it }) }
            state.report?.let { report -> item {
                val it = report
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("روزهای دارای رویداد فروش/برگشت: ${it.dayCount}")
                    Text("فروش خالص: ${formatMoney(it.salesRial)}")
                    Text("بهای مواد مصرف‌شده: ${formatMoney(it.costOfGoodsRial)}")
                    Text("حاشیه پس از هزینه مواد: ${formatMoney(it.grossProfitRial)}", fontWeight = FontWeight.Bold)
                    if (it.fullCostRial != null && it.fullMarginRial != null) {
                        Text("بهای کامل: ${formatMoney(it.fullCostRial)}")
                        Text("حاشیه پس از بهای کامل: ${formatMoney(it.fullMarginRial)}", fontWeight = FontWeight.ExtraBold)
                    } else if (it.totalLineCount > 0) {
                        Text(
                            "پوشش بهای کامل ${it.fullCostCoverageLineCount} از ${it.totalLineCount} ردیف است؛ جمع دوره برای جلوگیری از گزارش گمراه‌کننده نمایش داده نمی‌شود.",
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                }
            } }
            state.report?.takeIf { it.menuProfitability.isNotEmpty() }?.let { report ->
                item {
                    Text("سودآوری منو", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { profitabilitySort = "MARGIN" }) { Text("حاشیه کامل") }
                        TextButton(onClick = { profitabilitySort = "SALES" }) { Text("فروش") }
                        TextButton(onClick = { profitabilitySort = "COST" }) { Text("درصد هزینه") }
                    }
                }
                val sorted = when (profitabilitySort) {
                    "SALES" -> report.menuProfitability.sortedByDescending { it.salesRial }
                    "COST" -> report.menuProfitability.sortedByDescending { it.fullCostBasisPoints ?: Int.MIN_VALUE }
                    else -> report.menuProfitability.sortedByDescending { it.fullMarginRial ?: Long.MIN_VALUE }
                }
                items(sorted.take(20), key = { "profitability-${it.menuItemId}" }) { row ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(row.name, fontWeight = FontWeight.Bold)
                            Text("${row.unitsSold} واحد · فروش ${formatMoney(row.salesRial)} · هزینه مواد ${formatMoney(row.foodCostRial)}", style = MaterialTheme.typography.bodySmall)
                            val full = row.fullMarginRial?.let(::formatMoney) ?: "فاقد Snapshot بهای کامل"
                            Text("حاشیه کامل: $full", style = MaterialTheme.typography.bodySmall, color = if (row.fullMarginRial?.let { it < 0 } == true) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        } },
        confirmButton = { Button(onClick = { onApply(from, to) }) { Text("اعمال بازه") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("بستن") } },
    )
}
