# Startup authentication boundary fix (Alpha161.3)

## Device evidence
The supplied device bugreport records 25 main-thread fatal crashes for `ir.sabou.inventory`; all 25 are `AuthenticationRequiredException` from `SessionAuthorizer.actorIdentity(SessionAuthorizer.kt:24)`. The installed package in that report is versionCode 205 / versionName `3.0.1-alpha161.1-ci-compile-fix`.

## Root cause
`AppContainer.openAndValidateDatabase()` deliberately clears `app_session` at process start. The previous `SabouApp` still instantiated and collected the whole ERP ViewModel graph before authentication. `PersonnelViewModel.hrState` subscribes `LocalHrPayrollService.periods` and `batches`; these are authorization-guarded flows and immediately call `authorizer.require(PAYROLL_VIEW_ALL)`. With the startup session cleared, that guard correctly throws and the uncaught flow exception cancels the main UI coroutine.

## Corrective design
`SabouApp` is now a bootstrap boundary. Before an active authenticated user exists, it creates only `SecurityViewModel` and renders `SecurityScreen`. The protected ERP ViewModel graph is moved to `AuthenticatedSabouApp` and is not instantiated or subscribed before authentication. Payroll observation is separately permission-gated so authenticated roles without `PAYROLL_VIEW_ALL` do not subscribe it.

Security authorization itself was not weakened; `SessionAuthorizer` remains unchanged.

## Regression proof added
- JVM: `StartupAuthorizationBoundaryTest`
- Instrumentation: `StartupAuthenticationCrashRegressionTest`
- Static invariant: `scripts/verify-startup-auth-boundary.py`

## Build identity
- versionCode: 206
- versionName: `3.0.2-alpha161.3-startup-auth-boundary-fix`
