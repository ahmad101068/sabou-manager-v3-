#!/usr/bin/env python3
from pathlib import Path
import re
root = Path(__file__).resolve().parents[1]
app = (root / 'app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt').read_text(encoding='utf-8')
gradle = (root / 'app/build.gradle.kts').read_text(encoding='utf-8')
assert 'fun SabouApp(' in app
assert 'private fun AuthenticatedSabouApp(' in app
public_body = app.split('fun SabouApp(',1)[1].split('@Composable\nprivate fun AuthenticatedSabouApp',1)[0]
assert public_body.count('SecurityViewModel.factory') == 1, 'security bootstrap must be the only ViewModel before authentication'
for forbidden in ['DashboardViewModel.factory','InventoryWorkspaceViewModel.factory','AccountingViewModel.factory','DailySalesViewModel.factory','SalesPosViewModel.factory','PersonnelViewModel.factory','AlertViewModel.factory','SyncViewModel.factory']:
    assert forbidden not in public_body, f'protected ViewModel created before auth: {forbidden}'
assert 'if (!canStartProtectedAppGraph(securityState.currentUser))' in public_body
assert 'val hrPayrollState = collectHrPayrollStateIfAuthorized' in app
assert 'val hrPayrollState by personnel.hrState.collectAsStateWithLifecycle()' not in app
assert re.search(r'versionCode\s*=\s*206\b', gradle)
assert '3.0.2-alpha161.3-startup-auth-boundary-fix' in gradle
print('STARTUP_AUTH_BOUNDARY_VERIFICATION=PASS')
