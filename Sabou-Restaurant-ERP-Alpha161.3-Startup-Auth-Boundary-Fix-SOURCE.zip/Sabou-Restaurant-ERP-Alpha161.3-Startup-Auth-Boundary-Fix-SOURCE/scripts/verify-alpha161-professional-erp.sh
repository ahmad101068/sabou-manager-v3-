#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MAIN="$ROOT/app/src/main/java/ir/sabou/inventory"
fail(){ echo "Alpha161 verification failed: $*" >&2; exit 1; }
req(){ test -s "$ROOT/$1" || fail "missing $1"; }
lit(){ rg -Fq "$1" "$ROOT/$2" || fail "missing '$1' in $2"; }
for f in \
 app/src/main/java/ir/sabou/inventory/domain/common/DocumentNumbering.kt \
 app/src/main/java/ir/sabou/inventory/data/db/DocumentSequenceEntities.kt \
 app/src/main/java/ir/sabou/inventory/data/db/DocumentSequenceDao.kt \
 app/src/main/java/ir/sabou/inventory/data/repository/LocalDocumentNumberAllocator.kt \
 app/src/main/java/ir/sabou/inventory/domain/sales/ProfessionalSalesModels.kt \
 app/src/main/java/ir/sabou/inventory/domain/sales/SalesCalculator.kt \
 app/src/main/java/ir/sabou/inventory/data/db/SalesEntities.kt \
 app/src/main/java/ir/sabou/inventory/data/db/SalesDao.kt \
 app/src/main/java/ir/sabou/inventory/data/repository/LocalProfessionalSalesRepository.kt \
 app/src/main/java/ir/sabou/inventory/application/sales/SalesUseCases.kt \
 app/src/main/java/ir/sabou/inventory/ui/SalesPosViewModel.kt \
 app/src/main/java/ir/sabou/inventory/ui/ProfessionalSalesScreens.kt \
 app/src/main/java/ir/sabou/inventory/data/db/ProfessionalSalesGuards.kt \
 app/src/main/java/ir/sabou/inventory/data/db/migration/ProfessionalErpMigrations.kt \
 app/src/test/java/ir/sabou/inventory/domain/sales/SalesCalculatorTest.kt \
 app/src/androidTest/java/ir/sabou/inventory/data/db/ProfessionalSalesMigration44To45Test.kt \
 scripts/verify-alpha161-sql.py; do req "$f"; done
lit 'APP_DATABASE_SCHEMA_VERSION = 45' app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt
lit 'MIGRATION_44_45' app/src/main/java/ir/sabou/inventory/data/db/migration/AppMigrations.kt
lit 'LocalProfessionalSalesRepository' app/src/main/java/ir/sabou/inventory/data/AppContainer.kt
lit 'SalesUseCases' app/src/main/java/ir/sabou/inventory/data/AppContainer.kt
lit 'ProfessionalSalesScreen' app/src/main/java/ir/sabou/inventory/ui/OperationsRoutes.kt
lit 'SALES_DAILY_CONTROL' app/src/main/java/ir/sabou/inventory/ui/AppRoutes.kt
lit 'LocalDocumentNumberAllocator' app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt
lit 'LocalDocumentNumberAllocator' app/src/main/java/ir/sabou/inventory/data/repository/LocalAssetRepository.kt
lit 'DocumentNumberType.EMPLOYEE' app/src/main/java/ir/sabou/inventory/data/repository/LocalPersonnelRepository.kt
lit 'restoreTrackedLotQuantity' app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryCommandEngine.kt
lit 'CUSTOMER_RECEIVABLE' app/src/main/java/ir/sabou/inventory/domain/accounting/AccountingPosting.kt
lit 'SALES_RETURN' app/src/main/java/ir/sabou/inventory/domain/security/Permission.kt
lit 'SALES_VOID' app/src/main/java/ir/sabou/inventory/domain/security/Permission.kt
lit 'trg_sales_invoice_financial_identity_immutable' app/src/main/java/ir/sabou/inventory/data/db/ProfessionalSalesGuards.kt
lit 'printSalesInvoice' app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt
lit 'auditInvoicePrint' app/src/main/java/ir/sabou/inventory/data/repository/LocalProfessionalSalesRepository.kt
lit 'sales_pos_day_closures' app/src/main/java/ir/sabou/inventory/data/db/migration/ProfessionalErpMigrations.kt
lit 'override suspend fun closeDay' app/src/main/java/ir/sabou/inventory/data/repository/LocalProfessionalSalesRepository.kt
lit 'override suspend fun reopenDay' app/src/main/java/ir/sabou/inventory/data/repository/LocalProfessionalSalesRepository.kt
lit 'posDayClosure' app/src/main/java/ir/sabou/inventory/data/repository/LocalManagementControlRepository.kt
lit 'PURCHASE_REQUISITION' app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt
lit 'PURCHASE_ORDER' app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt
lit 'GOODS_RECEIPT' app/src/main/java/ir/sabou/inventory/data/repository/ProcurementReceivingService.kt
lit 'PURCHASE_RETURN' app/src/main/java/ir/sabou/inventory/data/repository/ProcurementReceivingService.kt
lit 'INVENTORY_TRANSFER' app/src/main/java/ir/sabou/inventory/data/repository/LocalInventoryTransferService.kt
lit 'activeInvoiceCountForDay' app/src/main/java/ir/sabou/inventory/data/repository/LocalDailySalesRepository.kt
if rg -n 'System\.currentTimeMillis\(\).*takeLast|KH-\$\{System\.currentTimeMillis|AST-\$\{System\.currentTimeMillis' "$MAIN/ui" -g '*.kt'; then
  fail 'timestamp-based document numbering remains in UI'
fi
if rg -n 'requestNo = "PR-\$\{now|orderNo = "PO-\$\{now|receiptNo = "GR-\$\{now|returnNo = "RT-\$\{now' "$MAIN/data/repository" -g '*.kt'; then
  fail 'timestamp/UUID procurement numbering remains'
fi
if rg -n '@Ignore|Assume\.assume|assumeTrue\(false\)' "$ROOT/app/src/test" "$ROOT/app/src/androidTest" -g '*.kt'; then
  fail 'disabled/weakened tests detected'
fi
if rg -n 'fallbackToDestructiveMigration' "$ROOT/app/src/main"; then fail 'destructive migration forbidden'; fi
echo 'ALPHA161_STATIC_VERIFICATION=PASS'
