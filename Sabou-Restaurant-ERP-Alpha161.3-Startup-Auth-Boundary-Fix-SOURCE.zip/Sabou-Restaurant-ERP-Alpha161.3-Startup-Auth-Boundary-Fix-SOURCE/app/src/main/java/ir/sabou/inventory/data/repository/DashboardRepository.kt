package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SystemSemanticAccountResolver
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import java.time.LocalDate

data class DashboardSnapshot(
    val inventoryValueRial: Long = 0,
    val supplierPayablesRial: Long = 0,
    val cashBalanceRial: Long = 0,
    val bankBalanceRial: Long = 0,
    val todayProfessionalInvoiceCount: Long = 0,
    val todayProfessionalReturnCount: Long = 0,
    val todayProfessionalSalesRial: Long = 0,
    val todayProfessionalGrossProfitRial: Long = 0,
    val customerReceivablesRial: Long = 0,
    val heldSaleCount: Long = 0,
)

class DashboardRepository(database: AppDatabase) {
    val snapshot: Flow<DashboardSnapshot> = combine(
        database.inventoryDao().observeInventoryValueRial(),
        database.purchaseDao().observePayablesRial(),
        database.accountingDao().observeBalanceRial(SystemSemanticAccountResolver.codeFor(SemanticAccountRole.CASH)),
        database.accountingDao().observeBalanceRial(SystemSemanticAccountResolver.codeFor(SemanticAccountRole.BANK)),
        database.salesDao().observeDashboardKpis(LocalDate.now().toEpochDay()),
    ) { inventory, payables, cash, bank, sales ->
        DashboardSnapshot(
            inventoryValueRial = inventory,
            supplierPayablesRial = payables,
            cashBalanceRial = cash,
            bankBalanceRial = bank,
            todayProfessionalInvoiceCount = sales.todayInvoiceCount,
            todayProfessionalReturnCount = sales.todayReturnCount,
            todayProfessionalSalesRial = sales.todayNetSalesRial,
            todayProfessionalGrossProfitRial = ir.sabou.inventory.core.SignedLongMath.subtract(sales.todayNetSalesRial, sales.todayCogsRial),
            customerReceivablesRial = sales.customerReceivablesRial,
            heldSaleCount = sales.heldSaleCount,
        )
    }
}

