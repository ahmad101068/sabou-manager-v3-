package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput

private data class IngredientDraft(val inventoryItemId: Long? = null, val quantity: String = "")

@Composable
fun RecipeScreen(
    state: RecipeUiState,
    onSelect: (Long?) -> Unit,
    onSave: (Long?, String, String, Long, List<RecipeIngredientInput>, () -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var editor by remember { mutableStateOf(false) }
    Scaffold(topBar = { ScreenHeader("رسپی و بهای تمام‌شده", "محصول جدید", { onSelect(null); editor = true }, onBack) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            state.message?.let { MessageCard(it) }
            Text("محصولات منو", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(state.menuItems, key = { it.id }) { item ->
                    Card(onClick = { onSelect(item.id); editor = true }) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(item.name, fontWeight = FontWeight.Bold)
                            Text("${item.category.ifBlank { "بدون دسته‌بندی" }} · ${formatMoney(item.salePriceRial)}")
                            val selectedIngredients = if (state.selectedMenuItemId == item.id) state.ingredients else emptyList()
                            if (selectedIngredients.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Text(selectedIngredients.joinToString("، ") { "${it.inventoryName}: ${formatQuantity(it.quantityMicrosPerUnit)} ${it.unit}" }, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
    if (editor) {
        val selected = state.menuItems.firstOrNull { it.id == state.selectedMenuItemId }
        RecipeEditorDialog(selected, state.inventoryItems, state.ingredients, { editor = false }, onSave)
    }
}

@Composable
private fun RecipeEditorDialog(
    selected: MenuItem?,
    inventory: List<InventoryItemRecord>,
    currentIngredients: List<ir.sabou.inventory.domain.recipe.RecipeIngredientItem>,
    onDismiss: () -> Unit,
    onSave: (Long?, String, String, Long, List<RecipeIngredientInput>, () -> Unit) -> Unit,
) {
    var name by remember(selected?.id) { mutableStateOf(selected?.name.orEmpty()) }
    var category by remember(selected?.id) { mutableStateOf(selected?.category.orEmpty()) }
    var price by remember(selected?.id) { mutableStateOf(selected?.salePriceRial?.toString().orEmpty()) }
    var rows by remember(selected?.id, currentIngredients) {
        mutableStateOf(if (currentIngredients.isEmpty()) listOf(IngredientDraft()) else currentIngredients.map { IngredientDraft(it.inventoryItemId, formatQuantity(it.quantityMicrosPerUnit)) })
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (selected == null) "محصول و رسپی جدید" else "ویرایش رسپی") },
        text = {
            LazyColumn(Modifier.heightIn(max = 560.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { OutlinedTextField(name, { name = it }, label = { Text("نام محصول") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(category, { category = it }, label = { Text("دسته‌بندی") }, modifier = Modifier.fillMaxWidth()) }
                item { OutlinedTextField(price, { price = it.filter(Char::isDigit) }, label = { Text("قیمت فروش ریال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()) }
                items(rows.indices.toList()) { index ->
                    val row = rows[index]
                    Card { Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("ماده اولیه ${index + 1}", fontWeight = FontWeight.SemiBold)
                        LazyRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            items(inventory, key = { it.id }) { item ->
                                FilterChip(selected = row.inventoryItemId == item.id, onClick = { rows = rows.toMutableList().also { it[index] = row.copy(inventoryItemId = item.id) } }, label = { Text(item.name, maxLines = 1) })
                            }
                        }
                        OutlinedTextField(row.quantity, { value -> rows = rows.toMutableList().also { it[index] = row.copy(quantity = value.filter { ch -> ch.isDigit() || ch == '.' }) } }, label = { Text("مصرف برای یک واحد") }, modifier = Modifier.fillMaxWidth())
                        if (rows.size > 1) TextButton(onClick = { rows = rows.toMutableList().also { it.removeAt(index) } }) { Text("حذف ماده") }
                    } }
                }
                item { TextButton(onClick = { rows = rows + IngredientDraft() }) { Text("+ افزودن ماده اولیه") } }
            }
        },
        confirmButton = { Button(onClick = {
            val ingredients = rows.map { row -> RecipeIngredientInput(row.inventoryItemId ?: 0, parseQuantityMicros(row.quantity)) }
            onSave(selected?.id, name, category, price.toLongOrNull() ?: 0, ingredients, onDismiss)
        }) { Text("ذخیره") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

private fun parseQuantityMicros(value: String): Long = try { ir.sabou.inventory.core.QuantityMicros.parse(value).value } catch (_: Exception) { 0L }
