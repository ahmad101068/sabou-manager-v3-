@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.PayrollDraft
import java.time.LocalDate

@Composable
fun PersonnelScreen(
    state: PersonnelUiState,
    onSaveEmployee: (Long?, EmployeeDraft) -> Unit,
    onDeactivate: (Long) -> Unit,
    onPostPayroll: (PayrollDraft) -> Unit,
    onBack: () -> Unit,
) {
    var showEmployee by remember { mutableStateOf(false) }
    var showPayroll by remember { mutableStateOf(false) }
    val activeEmployees = state.employees.count { it.isActive }
    val totalPayroll = state.payrolls.sumOf { it.netPayRial }

    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = "پرسنل و حقوق",
                subtitle = "مدیریت کارکنان، حقوق پایه و سوابق پرداخت",
                onBack = onBack,
                actionLabel = "ثبت حقوق",
                onAction = { if (activeEmployees > 0) showPayroll = true },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showEmployee = true }) { Text("پرسنل جدید") }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 14.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile("پرسنل فعال", activeEmployees.toString(), Modifier.weight(1f))
                    MetricTile("جمع پرداخت‌ها", formatMoney(totalPayroll, CurrencyUnit.RIAL), Modifier.weight(1f))
                }
            }
            state.message?.let { item { MessageCard(it, isError = false) } }
            item { SectionHeading("فهرست پرسنل", "اطلاعات شغلی و حقوق پایه کارکنان") }
            if (state.employees.isEmpty()) {
                item { EmptyStatePanel("هنوز پرسنلی ثبت نشده", "با دکمه پایین صفحه اولین پرسنل را اضافه کنید.") }
            } else {
                items(state.employees, key = { it.id }) { employee ->
                    Card(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(employee.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                    Text(employee.jobTitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusPill(if (employee.isActive) "فعال" else "غیرفعال")
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("حقوق پایه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatMoney(employee.monthlySalaryRial, CurrencyUnit.RIAL), fontWeight = FontWeight.Bold)
                            }
                            if (employee.phone.isNotBlank()) {
                                Text("تلفن: ${employee.phone}", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            if (employee.isActive) {
                                TextButton(onClick = { onDeactivate(employee.id) }) {
                                    Text("غیرفعال‌کردن پرسنل", color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
            item { SectionHeading("سوابق پرداخت", "آخرین حقوق‌های ثبت‌شده و اسناد صادرشده") }
            if (state.payrolls.isEmpty()) {
                item { EmptyStatePanel("سابقه پرداختی وجود ندارد", "بعد از ثبت حقوق ماهانه، سوابق در این بخش دیده می‌شوند.") }
            } else {
                items(state.payrolls, key = { it.id }) { payroll ->
                    Card(shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(payroll.employeeName, fontWeight = FontWeight.Bold)
                                    Text("دوره ${payroll.periodYear}/${payroll.periodMonth}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                StatusPill(payroll.status)
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("خالص پرداختی")
                                Text(formatMoney(payroll.netPayRial, CurrencyUnit.RIAL), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEmployee) {
        EmployeeDialog(onDismiss = { showEmployee = false }) {
            onSaveEmployee(null, it)
            showEmployee = false
        }
    }
    if (showPayroll) {
        PayrollDialog(state, onDismiss = { showPayroll = false }) {
            onPostPayroll(it)
            showPayroll = false
        }
    }
}

@Composable
private fun EmployeeDialog(onDismiss: () -> Unit, onSave: (EmployeeDraft) -> Unit) {
    var name by remember { mutableStateOf("") }
    var job by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var salary by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت پرسنل جدید") },
        text = {
            Column(
                Modifier.heightIn(max = 500.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedTextField(name, { name = it }, label = { Text("نام و نام خانوادگی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(job, { job = it }, label = { Text("عنوان شغلی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    phone,
                    { phone = it.filter { ch -> ch.isDigit() || ch == '+' }.take(14) },
                    label = { Text("شماره تماس") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    salary,
                    { salary = it.filter(Char::isDigit) },
                    label = { Text("حقوق پایه (ریال)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching { EmployeeDraft(name, job, phone, salary.toLongOrNull() ?: 0L).validated() }
                    .onSuccess(onSave)
                    .onFailure { error = it.message ?: "اطلاعات پرسنل معتبر نیست." }
            }) { Text("ذخیره پرسنل") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PayrollDialog(state: PersonnelUiState, onDismiss: () -> Unit, onSave: (PayrollDraft) -> Unit) {
    val active = state.employees.filter { it.isActive }
    var selected by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    val now = remember { LocalDate.now() }
    val todayPersian = remember { epochDayToPersian(now.toEpochDay()) }
    var year by remember { mutableStateOf(todayPersian.year.toString()) }
    var month by remember { mutableStateOf(todayPersian.month.toString()) }
    var overtime by remember { mutableStateOf("0") }
    var bonus by remember { mutableStateOf("0") }
    var deductions by remember { mutableStateOf("0") }
    var insurance by remember { mutableStateOf("0") }
    var tax by remember { mutableStateOf("0") }
    var paymentMethod by remember { mutableStateOf("BANK") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت حقوق ماهانه") },
        text = {
            Column(
                Modifier.heightIn(max = 580.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(active.firstOrNull { it.id == selected }?.name ?: "انتخاب پرسنل")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    active.forEach { employee ->
                        DropdownMenuItem(text = { Text(employee.name) }, onClick = { selected = employee.id; expanded = false })
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NumericField(year, { year = it }, "سال", Modifier.weight(1f))
                    NumericField(month, { month = it }, "ماه", Modifier.weight(1f))
                }
                NumericField(overtime, { overtime = it }, "اضافه‌کار (ریال)")
                NumericField(bonus, { bonus = it }, "پاداش (ریال)")
                NumericField(deductions, { deductions = it }, "کسورات (ریال)")
                NumericField(insurance, { insurance = it }, "بیمه (ریال)")
                NumericField(tax, { tax = it }, "مالیات (ریال)")
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { paymentMethod = "BANK" }, modifier = Modifier.weight(1f)) { Text(if (paymentMethod == "BANK") "✓ بانکی" else "بانکی") }
                    OutlinedButton(onClick = { paymentMethod = "CASH" }, modifier = Modifier.weight(1f)) { Text(if (paymentMethod == "CASH") "✓ نقدی" else "نقدی") }
                }
                OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                val draft = PayrollDraft(
                    employeeId = selected,
                    periodYear = year.toIntOrNull() ?: 0,
                    periodMonth = month.toIntOrNull() ?: 0,
                    overtimeRial = overtime.toLongOrNull() ?: 0,
                    bonusRial = bonus.toLongOrNull() ?: 0,
                    deductionsRial = deductions.toLongOrNull() ?: 0,
                    insuranceRial = insurance.toLongOrNull() ?: 0,
                    taxRial = tax.toLongOrNull() ?: 0,
                    paymentEpochDay = now.toEpochDay(),
                    paymentMethod = paymentMethod,
                    notes = notes,
                )
                runCatching { draft.validated() }
                    .onSuccess(onSave)
                    .onFailure { error = it.message ?: "اطلاعات حقوق معتبر نیست." }
            }) { Text("ثبت و صدور سند") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun NumericField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier.fillMaxWidth(),
) {
    OutlinedTextField(
        value = value,
        onValueChange = { onValueChange(it.filter(Char::isDigit)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        modifier = modifier,
    )
}
