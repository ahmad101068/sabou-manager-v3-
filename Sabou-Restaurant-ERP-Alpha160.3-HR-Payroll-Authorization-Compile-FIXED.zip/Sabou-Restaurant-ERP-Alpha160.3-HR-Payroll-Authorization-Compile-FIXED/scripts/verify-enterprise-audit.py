#!/usr/bin/env python3
"""Host-side structural audit gate for the current Sabou source tree.

This check is intentionally limited to facts that can be proved without the Android SDK. It does
not claim Kotlin type safety, Room schema validation, UI execution, or device-runtime coverage.
"""

from __future__ import annotations

import pathlib
import re
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/ir/sabou/inventory"


def fail(message: str) -> None:
    print(f"ENTERPRISE_AUDIT_FAIL: {message}", file=sys.stderr)
    raise SystemExit(1)


def read(relative: str) -> str:
    return (ROOT / relative).read_text(encoding="utf-8")


database_source = read("app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt")
version_match = re.search(r"APP_DATABASE_SCHEMA_VERSION\s*=\s*(\d+)", database_source)
if version_match is None:
    fail("database schema version is not declared")
schema_version = int(version_match.group(1))

migration_registry = read("app/src/main/java/ir/sabou/inventory/data/db/migration/AppMigrations.kt")
migrations = [tuple(map(int, pair)) for pair in re.findall(r"MIGRATION_(\d+)_(\d+)", migration_registry)]
expected_migrations = [(version, version + 1) for version in range(1, schema_version)]
if migrations != expected_migrations:
    fail(f"migration registry is not the exact 1..{schema_version} chain: {migrations}")

build = read("app/build.gradle.kts")
if 'versionCode = 205' not in build or 'versionName = "3.0.0-alpha160.3-hr-payroll-authorization-compile-fix"' not in build:
    fail("release identity was not advanced to the audited source version")

all_main_kotlin = "\n".join(path.read_text(encoding="utf-8") for path in MAIN.rglob("*.kt"))
for forbidden in ("TODO", "FIXME", "NotImplementedError", "fallbackToDestructiveMigration"):
    if forbidden in all_main_kotlin:
        fail(f"forbidden production marker found: {forbidden}")

test_text = "\n".join(
    path.read_text(encoding="utf-8")
    for source_set in (ROOT / "app/src/test", ROOT / "app/src/androidTest")
    for path in source_set.rglob("*.kt")
)
if "@Ignore" in test_text:
    fail("disabled test found")

entity_count = len(re.findall(r"@Entity(?:\s*\(|\b)", all_main_kotlin))
dao_count = len(re.findall(r"\binterface\s+\w*Dao\b", all_main_kotlin))
repository_files = list((MAIN / "data/repository").glob("*.kt"))
view_model_count = len(re.findall(r"\bclass\s+\w+ViewModel\b", all_main_kotlin))

route_source = read("app/src/main/java/ir/sabou/inventory/ui/AppRoutes.kt")
screen_block = re.search(r"enum class AppScreen.*?\{(.*?)\n\}", route_source, re.DOTALL)
if screen_block is None:
    fail("AppScreen registry not found")
screens = re.findall(r"^\s*([A-Z][A-Z0-9_]*)\(", screen_block.group(1), re.MULTILINE)
unreferenced = [screen for screen in screens if all_main_kotlin.count(f"AppScreen.{screen}") < 2]
if unreferenced:
    fail(f"screen constants without a second source reference: {unreferenced}")

operations_migration = read("app/src/main/java/ir/sabou/inventory/data/db/migration/OperationsMigrations.kt")
migration_30_31 = operations_migration.split("internal val MIGRATION_30_31", 1)[1].split(
    "internal val MIGRATION_31_32", 1
)[0]
executable_sql = "\n".join(
    re.findall(r'db\.execSQL\(\s*"""(.*?)"""\s*,?\s*\)', migration_30_31, re.DOTALL)
    + re.findall(r'db\.execSQL\("([^"\n]+)"\)', migration_30_31)
)
if re.search(r"DROP\s+TABLE", executable_sql, re.IGNORECASE):
    fail("schema 30 to 31 still drops retired operational tables")
if re.search(r"DELETE\s+FROM\s+(app_alerts|sync_changes)", executable_sql, re.IGNORECASE):
    fail("schema 30 to 31 still deletes alert or sync evidence")
legacy_tables = set(re.findall(r'"(customers|sales|sale_lines|sale_payments|loyalty_transactions|customer_followups|approval_requests|restaurant_tables|reservations|kitchen_tickets|cash_shifts|table_orders|table_order_lines|bill_splits|bill_split_lines)"', migration_30_31))
if len(legacy_tables) != 15:
    fail(f"retired table preservation list has {len(legacy_tables)} entries instead of 15")

schema_dir = ROOT / "app/schemas/ir.sabou.inventory.data.db.AppDatabase"
schema_exports = sorted(path.name for path in schema_dir.glob("*.json"))
if f"{schema_version}.json" not in schema_exports:
    fail(f"current Room schema export {schema_version}.json is missing")

print(
    "ENTERPRISE_AUDIT_PASS "
    f"schema={schema_version} migrations={len(migrations)} entities={entity_count} daos={dao_count} "
    f"repository_files={len(repository_files)} viewmodels={view_model_count} screens={len(screens)} "
    f"legacy_tables_preserved={len(legacy_tables)} schema_exports={','.join(schema_exports)}"
)
