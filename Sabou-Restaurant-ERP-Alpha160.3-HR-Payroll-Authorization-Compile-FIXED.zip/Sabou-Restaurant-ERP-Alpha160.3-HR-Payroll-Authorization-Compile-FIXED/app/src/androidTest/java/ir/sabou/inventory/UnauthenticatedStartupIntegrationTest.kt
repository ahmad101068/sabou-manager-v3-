package ir.sabou.inventory

import android.os.SystemClock
import androidx.lifecycle.Lifecycle
import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class UnauthenticatedStartupIntegrationTest {
    @Test
    fun cleanEntryKeepsLoginScreenAliveWithoutAuthenticatedActor() {
        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            // The original failure was dispatched by a protected ViewModel shortly
            // after the login screen first appeared, so keep the Activity alive long
            // enough for startup Flow collectors and Compose effects to execute.
            SystemClock.sleep(3_000L)

            assertTrue(
                "MainActivity left the foreground during unauthenticated startup: ${scenario.state}",
                scenario.state.isAtLeast(Lifecycle.State.STARTED),
            )
        }
    }
}
