package ir.sabou.inventory.domain.operations

data class ShiftDemand(val epochDay: Long, val startMinute: Int, val endMinute: Int, val requiredStaff: Int)
data class StaffAvailability(val employeeId: Long, val name: String, val availableFromMinute: Int, val availableToMinute: Int, val role: String)
data class PlannedShift(val employeeId: Long, val employeeName: String, val role: String, val epochDay: Long, val startMinute: Int, val endMinute: Int)

object ShiftPlanner {
    fun plan(demand: ShiftDemand, staff: List<StaffAvailability>): List<PlannedShift> {
        require(demand.epochDay > 0 && demand.startMinute in 0..1439 && demand.endMinute in 1..1440 && demand.endMinute > demand.startMinute) { "نیاز شیفت معتبر نیست." }
        require(demand.requiredStaff >= 0) { "تعداد نیروی موردنیاز معتبر نیست." }
        val eligible = staff.filter { it.employeeId > 0 && it.availableFromMinute <= demand.startMinute && it.availableToMinute >= demand.endMinute }
        return eligible.take(demand.requiredStaff).map { PlannedShift(it.employeeId, it.name, it.role, demand.epochDay, demand.startMinute, demand.endMinute) }
    }
}
