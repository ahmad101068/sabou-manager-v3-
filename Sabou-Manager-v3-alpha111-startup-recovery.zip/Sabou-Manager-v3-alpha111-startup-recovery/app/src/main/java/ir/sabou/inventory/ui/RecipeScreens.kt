package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeIngredientInput
import ir.sabou.inventory.domain.recipe.RecipeIngredientItem

private data class IngredientDraft(
    val inventoryItemId: Long? = null,
    val quantity: String = "",
)

@Composable
fun RecipeScreen(
    state: RecipeUiState,
    onSelect: (Long?) -> Unit,
    onSave: (Long?, String, String, Long, List<RecipeIngredientInput>, () -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    var editorOpen by remember { mutableStateOf(false) }
    val categories = state.menuItems.map { it.category.ifBlank { "بدون دسته‌بندی" } }.distinct().size

    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = "تولید و رسپی",
                subtitle = "فرمول ساخت، مواد اولیه و قیمت فروش محصولات",
                onBack = onBack,
                actionLabel = "محصول جدید",
                onAction = {
                    onSelect(null)
                    editorOpen = true
                },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            state.message?.let { message -> item { MessageCard(message) } }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionHeading("نمای کلی تولید", "اطلاعات محصولات قابل فروش و ساخت")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        MetricTile("محصولات", state.menuItems.size.toString(), Modifier.weight(1f))
                        MetricTile("دسته‌ها", categories.toString(), Modifier.weight(1f))
                    }
                }
            }
            item { SectionHeading("محصولات و فرمول ساخت", "برای مشاهده یا ویرایش رسپی، محصول را انتخاب کنید") }
            if (state.menuItems.isEmpty()) {
                item {
                    EmptyStatePanel(
                        title = "هنوز محصولی تعریف نشده",
                        description = "اولین محصول را ایجاد و مواد اولیه مصرفی آن را مشخص کنید.",
                    )
                }
            } else {
                items(state.menuItems, key = { it.id }) { item ->
                    RecipeProductCard(
                        item = item,
                        ingredients = if (state.selectedMenuItemId == item.id) state.ingredients else emptyList(),
                        onClick = {
                            onSelect(item.id)
                            editorOpen = true
                        },
                    )
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }

    if (editorOpen) {
        RecipeEditorDialog(
            selected = state.menuItems.firstOrNull { it.id == state.selectedMenuItemId },
            inventory = state.inventoryItems,
            currentIngredients = state.ingredients,
            busy = state.busy,
            onDismiss = { editorOpen = false },
            onSave = onSave,
        )
    }
}

@Composable
private fun RecipeProductCard(
    item: MenuItem,
    ingredients: List<RecipeIngredientItem>,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top,
            ) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = item.category.ifBlank { "بدون دسته‌بندی" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                StatusPill(if (ingredients.isEmpty()) "رسپی ثبت نشده" else "${ingredients.size} ماده")
            }
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = .55f),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("قیمت فروش", style = MaterialTheme.typography.labelMedium)
                    Text(formatMoney(item.salePriceRial), fontWeight = FontWeight.ExtraBold)
                }
            }
            if (ingredients.isNotEmpty()) {
                Text(
                    text = ingredients.joinToString("  •  ") {
                        "${it.inventoryName}: ${formatQuantity(it.quantityMicrosPerUnit)} ${it.unit}"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                )
            } else {
                Text(
                    "برای این محصول هنوز مواد اولیه تعیین نشده است.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
        }
    }
}

@Composable
private fun RecipeEditorDialog(
    selected: MenuItem?,
    inventory: List<InventoryItemRecord>,
    currentIngredients: List<RecipeIngredientItem>,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (Long?, String, String, Long, List<RecipeIngredientInput>, () -> Unit) -> Unit,
) {
    var name by remember(selected?.id) { mutableStateOf(selected?.name.orEmpty()) }
    var category by remember(selected?.id) { mutableStateOf(selected?.category.orEmpty()) }
    var categoryExpanded by remember { mutableStateOf(false) }
    val productCategories = listOf("غذای اصلی", "پیش‌غذا", "سالاد", "نوشیدنی", "دسر", "صبحانه", "فست‌فود", "سرویس و افزودنی")
    var price by remember(selected?.id) { mutableStateOf(selected?.salePriceRial?.toString().orEmpty()) }
    var error by remember(selected?.id) { mutableStateOf<String?>(null) }
    var rows by remember(selected?.id, currentIngredients) {
        mutableStateOf(
            if (currentIngredients.isEmpty()) listOf(IngredientDraft())
            else currentIngredients.map { IngredientDraft(it.inventoryItemId, formatQuantity(it.quantityMicrosPerUnit)) },
        )
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(if (selected == null) "محصول و رسپی جدید" else "ویرایش محصول و رسپی") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 570.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    FormSection("مشخصات محصول", "اطلاعات پایه محصول قابل فروش") {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it; error = null },
                            label = { Text("نام محصول") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Box(Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category.ifBlank { "انتخاب دسته‌بندی منو" }) }
                            androidx.compose.material3.DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                                productCategories.forEach { value -> androidx.compose.material3.DropdownMenuItem(text = { Text(value) }, onClick = { category = value; categoryExpanded = false }) }
                            }
                        }
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it.filter(Char::isDigit); error = null },
                            label = { Text("قیمت فروش به ریال") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                item { SectionHeading("مواد اولیه", "مقدار مصرف هر ماده برای تولید یک واحد") }
                itemsIndexed(rows) { index, row ->
                    IngredientEditorCard(
                        index = index,
                        row = row,
                        inventory = inventory,
                        removable = rows.size > 1,
                        onSelectItem = { itemId ->
                            rows = rows.toMutableList().also { it[index] = row.copy(inventoryItemId = itemId) }
                            error = null
                        },
                        onQuantityChange = { value ->
                            rows = rows.toMutableList().also { it[index] = row.copy(quantity = value) }
                            error = null
                        },
                        onRemove = { rows = rows.toMutableList().also { it.removeAt(index) } },
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { rows = rows + IngredientDraft() },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("افزودن ماده اولیه") }
                }
                item {
                    val estimatedCost = rows.sumOf { row ->
                        val stock = inventory.firstOrNull { it.id == row.inventoryItemId }
                        if (stock == null || stock.stockMicros <= 0) 0L else
                            (stock.inventoryValueRial.toDouble() * parseQuantityMicros(row.quantity) / stock.stockMicros).toLong()
                    }
                    val salePrice = price.toLongOrNull() ?: 0L
                    FormSection("بهای تمام‌شده", "برآورد لحظه‌ای بر اساس ارزش موجودی") {
                        Text("هزینه مواد: ${formatMoney(estimatedCost, CurrencyUnit.RIAL)}")
                        Text("سود ناخالص هر واحد: ${formatMoney((salePrice - estimatedCost).coerceAtLeast(0L), CurrencyUnit.RIAL)}", fontWeight = FontWeight.Bold)
                    }
                }
                error?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.error) } }
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    val normalizedName = name.trim()
                    val salePrice = price.toLongOrNull() ?: 0L
                    val validRows = rows.filter { it.inventoryItemId != null && parseQuantityMicros(it.quantity) > 0L }
                    error = when {
                        normalizedName.length < 2 -> "نام محصول را کامل وارد کنید."
                        salePrice <= 0L -> "قیمت فروش باید بیشتر از صفر باشد."
                        validRows.isEmpty() -> "حداقل یک ماده اولیه و مقدار مصرف معتبر وارد کنید."
                        validRows.mapNotNull { it.inventoryItemId }.distinct().size != validRows.size -> "هر ماده اولیه فقط یک‌بار قابل انتخاب است."
                        else -> null
                    }
                    if (error == null) {
                        onSave(
                            selected?.id,
                            normalizedName,
                            category.trim(),
                            salePrice,
                            validRows.map { row ->
                                RecipeIngredientInput(
                                    inventoryItemId = requireNotNull(row.inventoryItemId) {
                                        "ماده اولیه انتخاب نشده است."
                                    },
                                    quantityMicrosPerUnit = parseQuantityMicros(row.quantity),
                                )
                            },
                            onDismiss,
                        )
                    }
                },
            ) { Text(if (busy) "در حال ذخیره…" else "ذخیره") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun IngredientEditorCard(
    index: Int,
    row: IngredientDraft,
    inventory: List<InventoryItemRecord>,
    removable: Boolean,
    onSelectItem: (Long) -> Unit,
    onQuantityChange: (String) -> Unit,
    onRemove: () -> Unit,
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ماده اولیه ${index + 1}", fontWeight = FontWeight.Bold)
                if (removable) TextButton(onClick = onRemove) { Text("حذف") }
            }
            if (inventory.isEmpty()) {
                Text("ابتدا در بخش انبار یک ماده اولیه ثبت کنید.", color = MaterialTheme.colorScheme.error)
            } else {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(inventory, key = { it.id }) { item ->
                        FilterChip(
                            selected = row.inventoryItemId == item.id,
                            onClick = { onSelectItem(item.id) },
                            label = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        )
                    }
                }
            }
            val selectedItem = inventory.firstOrNull { it.id == row.inventoryItemId }
            OutlinedTextField(
                value = row.quantity,
                onValueChange = { value -> onQuantityChange(value.filter { it.isDigit() || it == '.' }) },
                label = { Text("مصرف برای یک واحد${selectedItem?.unit?.let { " ($it)" }.orEmpty()}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

private fun parseQuantityMicros(value: String): Long = try {
    ir.sabou.inventory.core.QuantityMicros.parse(value).value
} catch (_: Exception) {
    0L
}
