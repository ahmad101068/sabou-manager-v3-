package ir.sabou.inventory.data

import android.content.Context
import ir.sabou.inventory.data.db.AppDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupManager(private val context: Context) {
    private val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("backup_state", Context.MODE_PRIVATE)

    fun applyPendingRestore() {
        val pending = prefs.getString("pending_restore", null) ?: return
        val source = resolveBackup(pending)
        if (source.isFile) {
            require(source.length() >= MIN_DATABASE_BYTES) { "فایل پشتیبان ناقص یا نامعتبر است." }
            context.getDatabasePath("sabou_manager_v3.db").also { target ->
                target.parentFile?.mkdirs()
                val staged = File(target.parentFile, "${target.name}.restore")
                source.copyTo(staged, overwrite = true)
                require(staged.length() == source.length()) { "کپی فایل پشتیبان کامل نشد." }
                if (target.exists()) {
                    val recovery = File(backupDir, "pre-restore-${System.currentTimeMillis()}.db")
                    target.copyTo(recovery, overwrite = false)
                    prefs.edit().putString("last_restore_recovery", recovery.name).commit()
                }
                require(staged.renameTo(target) || runCatching { staged.copyTo(target, overwrite = true); staged.delete(); true }.getOrDefault(false)) {
                    "جایگزینی پایگاه داده انجام نشد."
                }
            }
            context.getDatabasePath("sabou_manager_v3.db-wal").delete()
            context.getDatabasePath("sabou_manager_v3.db-shm").delete()
        }
        prefs.edit().remove("pending_restore").commit()
    }

    fun create(database: AppDatabase): String {
        val name = "sabou-backup-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}.db"
        val source = context.getDatabasePath("sabou_manager_v3.db")
        val destination = File(backupDir, name)
        database.openHelper.writableDatabase.execSQL("VACUUM INTO ?", arrayOf(destination.absolutePath))
        require(destination.length() >= MIN_DATABASE_BYTES && source.length() >= MIN_DATABASE_BYTES) {
            destination.delete()
            "ساخت نسخه پشتیبان کامل نشد."
        }
        return name
    }

    fun markRestoreValidated() {
        prefs.edit().remove("last_restore_recovery").commit()
    }

    fun rollbackLastRestore(): Boolean {
        val recoveryName = prefs.getString("last_restore_recovery", null) ?: return false
        val recovery = resolveBackup(recoveryName)
        val target = context.getDatabasePath("sabou_manager_v3.db")
        if (!recovery.isFile) return false
        recovery.copyTo(target, overwrite = true)
        context.getDatabasePath("sabou_manager_v3.db-wal").delete()
        context.getDatabasePath("sabou_manager_v3.db-shm").delete()
        prefs.edit().remove("last_restore_recovery").commit()
        return true
    }

    fun list(): List<String> = backupDir.listFiles()?.filter { it.isFile && it.extension == "db" }?.sortedByDescending { it.lastModified() }?.map { it.name }.orEmpty()

    fun scheduleRestore(name: String) {
        require(resolveBackup(name).isFile) { "فایل پشتیبان پیدا نشد." }
        prefs.edit().putString("pending_restore", name).apply()
    }

    private fun resolveBackup(name: String): File {
        require(name == File(name).name && name.endsWith(".db")) { "نام فایل پشتیبان معتبر نیست." }
        val candidate = File(backupDir, name).canonicalFile
        require(candidate.parentFile == backupDir.canonicalFile) { "مسیر فایل پشتیبان معتبر نیست." }
        return candidate
    }

    private companion object {
        const val MIN_DATABASE_BYTES = 4_096L
    }
}
