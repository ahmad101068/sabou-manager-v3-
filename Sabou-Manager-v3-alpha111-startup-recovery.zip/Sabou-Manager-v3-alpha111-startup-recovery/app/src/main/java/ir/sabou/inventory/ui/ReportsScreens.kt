package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.accounting.CashFlowCalculator
import ir.sabou.inventory.domain.accounting.CashFlowEvent
import ir.sabou.inventory.domain.operations.ReorderInput
import ir.sabou.inventory.domain.operations.SmartReorderCalculator
import ir.sabou.inventory.domain.sales.ReceivableInput
import ir.sabou.inventory.domain.sales.ReceivablesAgingCalculator
import ir.sabou.inventory.domain.operations.RestaurantKpiCalculator

@Composable
fun ReportsCenterScreen(
    dashboard: DashboardSnapshot,
    sales: SalesUiState,
    accounting: AccountingUiState,
    operations: OperationsUiState,
    onOpenSales: () -> Unit,
    onOpenAccounting: () -> Unit,
    onOpenInventory: () -> Unit,
    onBack: () -> Unit,
) {
    val netProfit = accounting.profitLoss.netProfitRial
    val liquidity = dashboard.cashBalanceRial + dashboard.bankBalanceRial
    val lowStock = operations.lowStockItems.size
    val openSettlements = operations.settlementAlerts.size
    val activeSales = sales.sales.filterNot { it.reversed }
    val kpi = RestaurantKpiCalculator.calculate(
        salesRial = activeSales.sumOf { it.totalRial },
        costRial = activeSales.sumOf { it.costOfGoodsRial },
        invoiceCount = activeSales.size,
    )
    val aging = ReceivablesAgingCalculator.buckets(currentEpochDay(), activeSales.map {
        ReceivableInput(it.id, it.customerName, it.dueEpochDay, (it.totalRial - it.paidRial).coerceAtLeast(0))
    })
    val cashFlow = CashFlowCalculator.forecast(
        startBalanceRial = liquidity.coerceAtLeast(0),
        events = activeSales.mapNotNull { sale ->
            val dueEpochDay = sale.dueEpochDay
            if (sale.totalRial <= sale.paidRial || dueEpochDay == null) null
            else CashFlowEvent(dueEpochDay, sale.totalRial - sale.paidRial, "مطالبه ${sale.invoiceNo}", incoming = true)
        } + operations.purchases.filter { it.outstandingRial > 0 }.map {
            CashFlowEvent(it.dueEpochDay, it.outstandingRial, "بدهی ${it.invoiceNo}", incoming = false)
        },
    )
    val reorders = operations.inventoryItems.map { item ->
        SmartReorderCalculator.recommend(ReorderInput(
            itemId = item.id, itemName = item.name, unit = item.unit,
            currentStockMicros = item.stockMicros, averageDailyUsageMicros = 0,
            minimumStockMicros = item.alertThresholdMicros,
        ))
    }.filter { it.recommendedOrderMicros > 0 }.sortedByDescending { it.urgency.ordinal }
    Scaffold(topBar = { ProfessionalTopBar("مرکز گزارش‌ها", "تصمیم‌گیری سریع با شاخص‌های کلیدی", onBack) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PremiumHero("سود خالص", formatMoney(netProfit), "نقدینگی در دسترس ${formatMoney(liquidity)}") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("فروش فعال", formatMoney(sales.activeSalesRial), Modifier.weight(1f)); MetricTile("سود ناخالص", formatMoney(sales.grossProfitRial), Modifier.weight(1f)) } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("مطالبات", formatMoney(sales.receivablesRial), Modifier.weight(1f)); MetricTile("ارزش انبار", formatMoney(dashboard.inventoryValueRial), Modifier.weight(1f)) } }
            item { SectionHeading("شاخص‌های رستوران", "محاسبه زنده از فروش‌های ثبت‌شده") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("حاشیه سود", "${kpi.marginPercent}%", Modifier.weight(1f)); MetricTile("تعداد فاکتور", kpi.invoiceCount.toString(), Modifier.weight(1f)) } }
            item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("پیش‌بینی جریان نقدی", fontWeight = FontWeight.ExtraBold)
                ReportAlertRow("مانده پایان دوره", formatMoney(cashFlow.endBalanceRial), cashFlow.endBalanceRial < 0)
                ReportAlertRow("کمترین مانده", formatMoney(cashFlow.minimumBalanceRial), cashFlow.minimumBalanceRial < 0)
                ReportAlertRow("روزهای کسری", "${cashFlow.deficitDays.size} روز", cashFlow.deficitDays.isNotEmpty())
            } } }
            if (aging.isNotEmpty()) item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("سنی مطالبات", fontWeight = FontWeight.ExtraBold)
                aging.forEach { bucket -> ReportAlertRow(bucket.title, formatMoney(bucket.totalRial), bucket.totalRial > 0 && bucket.title != "جاری") }
            } } }
            sales.report?.menuPerformance?.takeIf { it.isNotEmpty() }?.let { menu -> item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("مهندسی منو", fontWeight = FontWeight.ExtraBold)
                menu.take(8).forEach { result -> ReportAlertRow(result.name, "${result.quadrant.name} · ${formatMoney(result.grossProfitRial)}", result.grossProfitRial < 0) }
            } } } }
            if (reorders.isNotEmpty()) item { Card(shape = MaterialTheme.shapes.extraLarge) { Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("پیشنهاد سفارش مجدد", fontWeight = FontWeight.ExtraBold)
                reorders.take(8).forEach { result -> ReportAlertRow(result.itemName, "${formatQuantity(result.recommendedOrderMicros)} ${result.unit}", true) }
            } } }
            item { SectionHeading("نیازمند توجه", "مواردی که بهتر است امروز بررسی شوند") }
            item { Card(shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) { Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) { ReportAlertRow("کالاهای کم‌موجود", "$lowStock مورد", lowStock > 0); ReportAlertRow("تسویه‌های سررسید", "$openSettlements مورد", openSettlements > 0); ReportAlertRow("بدهی تأمین‌کنندگان", formatMoney(dashboard.supplierPayablesRial), dashboard.supplierPayablesRial > 0) } } }
            item { SectionHeading("گزارش‌های تفصیلی", "ورود سریع به تحلیل هر حوزه") }
            item { ReportDestinationCard("فروش و درآمد", "فروش، بهای تمام‌شده، سود ناخالص و مطالبات", "مشاهده فروش", onOpenSales) }
            item { ReportDestinationCard("حسابداری و تراز", "سود و زیان، تراز آزمایشی و اسناد", "ورود به حسابداری", onOpenAccounting) }
            item { ReportDestinationCard("موجودی و تأمین", "ارزش انبار، کمبودها و اصلاح موجودی", "مشاهده انبار", onOpenInventory) }
        }
    }
}

@Composable
private fun ReportAlertRow(title: String, value: String, needsAttention: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.SemiBold)
        StatusPill(
            text = value,
            containerColor = if (needsAttention) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
            contentColor = if (needsAttention) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
        )
    }
}

@Composable
private fun ReportDestinationCard(title: String, description: String, action: String, onClick: () -> Unit) {
    Card(
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
            Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(action) }
        }
    }
}
