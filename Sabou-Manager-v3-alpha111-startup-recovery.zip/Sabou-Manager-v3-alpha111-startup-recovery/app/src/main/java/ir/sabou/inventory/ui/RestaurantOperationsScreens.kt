package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.*
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.sales.*

private enum class OpsDialog { TABLE, RESERVATION, KITCHEN, SHIFT, APPROVAL }

@Composable fun RestaurantOperationsScreen(state:RestaurantOperationsUiState,employees:List<EmployeeRecord>,onAddTable:(String,Int,String)->Unit,onTable:(Long,TableStatus,Long?)->Unit,onReservation:(Reservation)->Unit,onTicket:(String,String,String,Int,Int)->Unit,onTicketStatus:(Long,KitchenTicketStatus)->Unit,onShift:(ShiftDemand,List<StaffAvailability>)->Unit,onApproval:(String,Long,Long,String)->Unit,onReview:(Long,Boolean,String,String)->Unit,onBack:()->Unit){
    var dialog by remember{mutableStateOf<OpsDialog?>(null)}
    Scaffold(topBar={ProfessionalTopBar("عملیات رستوران","میز، رزرو، آشپزخانه، شیفت و تأیید",onBack)}){padding->LazyColumn(Modifier.fillMaxSize().padding(padding),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        state.message?.let{item{StatusPill(it,MaterialTheme.colorScheme.secondaryContainer,MaterialTheme.colorScheme.onSecondaryContainer)}}
        item{ActionStrip(listOf("میز" to OpsDialog.TABLE,"رزرو" to OpsDialog.RESERVATION,"آشپزخانه" to OpsDialog.KITCHEN,"شیفت" to OpsDialog.SHIFT,"تأیید" to OpsDialog.APPROVAL)){dialog=it}}
        item{SectionHeading("میزها و رزرو","${state.tables.size} میز · ${state.reservations.size} رزرو")}
        items(state.tables,key={it.id}){table->Card{Column(Modifier.fillMaxWidth().padding(14.dp)){Text("میز ${table.label} · ${table.zone}",fontWeight=FontWeight.Bold);Text("ظرفیت ${table.capacity} · ${table.status.name}");Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){nextTableStatuses(table.status).forEach{next->TextButton(onClick={onTable(table.id,next,if(next==TableStatus.OCCUPIED) System.currentTimeMillis() else table.activeOrderId)}){Text(next.name)}}}}}}
        item{SectionHeading("صف آشپزخانه","اولویت‌بندی زنده سفارش‌ها")}
        items(state.tickets,key={it.id}){ticket->Card{Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Column{Text("${ticket.orderNo} · ${ticket.itemName}",fontWeight=FontWeight.Bold);Text("${ticket.quantity} عدد · ${ticket.station} · ${ticket.status.name}")};nextTicketStatus(ticket.status)?.let{next->TextButton(onClick={onTicketStatus(ticket.id,next)}){Text(next.name)}}}}}
        item{SectionHeading("شیفت‌ها و تأییدها","${state.shifts.size} شیفت · ${state.approvals.count{it.status==ApprovalStatus.PENDING}} در انتظار")}
        items(state.shifts.take(8)){shift->Text("${shift.employeeName} · ${shift.epochDay} · ${shift.startMinute/60}:${(shift.startMinute%60).toString().padStart(2,'0')}–${shift.endMinute/60}:${(shift.endMinute%60).toString().padStart(2,'0')}")}
        items(state.approvals,key={it.id}){request->Card{Column(Modifier.fillMaxWidth().padding(12.dp)){Text("${request.requestType} · ${formatMoney(request.amountRial)}",fontWeight=FontWeight.Bold);Text(request.status.name);if(request.status==ApprovalStatus.PENDING)Row{TextButton(onClick={onReview(request.id,true,"مدیر","")}){Text("تأیید")};TextButton(onClick={onReview(request.id,false,"مدیر","رد توسط مدیر")}){Text("رد")}}}}}
    }}
    dialog?.let{mode->OperationsInputDialog(mode,state.tables,employees,{dialog=null}){a,b,c,d,e->when(mode){OpsDialog.TABLE->onAddTable(a,b.toIntOrNull()?:0,c);OpsDialog.RESERVATION->{val table=state.tables.firstOrNull();if(table!=null)onReservation(Reservation(0,a,b,table.id,System.currentTimeMillis()+3_600_000,System.currentTimeMillis()+7_200_000,c.toIntOrNull()?:1,d))};OpsDialog.KITCHEN->onTicket(a,b,c,d.toIntOrNull()?:1,e.toIntOrNull()?:0);OpsDialog.SHIFT->onShift(ShiftDemand(currentEpochDay(),a.toIntOrNull()?:540,b.toIntOrNull()?:1020,c.toIntOrNull()?:1),employees.filter{it.isActive}.map{StaffAvailability(it.id,it.name,0,1440,it.jobTitle)});OpsDialog.APPROVAL->onApproval(a,b.toLongOrNull()?:1,c.toLongOrNull()?:0,d)}}}
}

@Composable private fun ActionStrip(actions:List<Pair<String,OpsDialog>>,onClick:(OpsDialog)->Unit){LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp)){items(actions){(label,mode)->FilledTonalButton(onClick={onClick(mode)}){Text("افزودن $label")}}}}
private fun nextTableStatuses(status:TableStatus)=when(status){TableStatus.FREE->listOf(TableStatus.RESERVED,TableStatus.OCCUPIED);TableStatus.RESERVED->listOf(TableStatus.OCCUPIED,TableStatus.FREE);TableStatus.OCCUPIED->listOf(TableStatus.WAITING_PAYMENT,TableStatus.CLEANING);TableStatus.WAITING_PAYMENT->listOf(TableStatus.CLEANING);TableStatus.CLEANING->listOf(TableStatus.FREE)}
private fun nextTicketStatus(status:KitchenTicketStatus)=when(status){KitchenTicketStatus.QUEUED->KitchenTicketStatus.PREPARING;KitchenTicketStatus.PREPARING->KitchenTicketStatus.READY;KitchenTicketStatus.READY->KitchenTicketStatus.SERVED;else->null}

@Composable private fun OperationsInputDialog(mode:OpsDialog,tables:List<RestaurantTable>,employees:List<EmployeeRecord>,dismiss:()->Unit,save:(String,String,String,String,String)->Unit){var a by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var c by remember{mutableStateOf("")};var d by remember{mutableStateOf("")};var e by remember{mutableStateOf("")};val labels=when(mode){OpsDialog.TABLE->listOf("برچسب میز","ظرفیت","بخش");OpsDialog.RESERVATION->listOf("نام مشتری","تلفن","تعداد مهمان","یادداشت");OpsDialog.KITCHEN->listOf("شماره سفارش","ایستگاه","نام آیتم","تعداد","اولویت ۰ تا ۱۰");OpsDialog.SHIFT->listOf("شروع به دقیقه","پایان به دقیقه","نیروی موردنیاز");OpsDialog.APPROVAL->listOf("نوع درخواست","شناسه مرجع","مبلغ","درخواست‌کننده")};val values=listOf(a,b,c,d,e);AlertDialog(onDismissRequest=dismiss,title={Text("ثبت ${mode.name}")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){if(mode==OpsDialog.RESERVATION)Text("رزرو برای ${tables.firstOrNull()?.label?:"ابتدا میز ثبت کنید"}");if(mode==OpsDialog.SHIFT)Text("${employees.count{it.isActive}} پرسنل فعال");labels.forEachIndexed{i,label->OutlinedTextField(values[i],{v->when(i){0->a=v;1->b=v;2->c=v;3->d=v;else->e=v}},label={Text(label)},singleLine=true)}}},confirmButton={Button(onClick={save(a,b,c,d,e);dismiss()}){Text("ثبت")}},dismissButton={TextButton(onClick=dismiss){Text("انصراف")}})}
