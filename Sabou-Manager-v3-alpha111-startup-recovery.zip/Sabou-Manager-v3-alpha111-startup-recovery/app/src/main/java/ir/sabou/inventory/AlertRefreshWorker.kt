package ir.sabou.inventory

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.flow.first
import java.time.LocalDate

class AlertRefreshWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = runCatching {
        val app = applicationContext as SabouApplication
        val repository = app.container.alertRepository
        repository.refresh(LocalDate.now().toEpochDay())
        val urgent = repository.alerts().first().count { it.severity == "HIGH" && !it.isRead && !it.isDismissed }
        if (urgent > 0) notifyUrgent(urgent)
        Result.success()
    }.getOrElse { Result.retry() }

    private fun notifyUrgent(count: Int) {
        val manager = applicationContext.getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "هشدارهای مدیریتی", NotificationManager.IMPORTANCE_DEFAULT))
        if (Build.VERSION.SDK_INT < 33 || applicationContext.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(applicationContext).notify(7001, NotificationCompat.Builder(applicationContext, CHANNEL_ID).setSmallIcon(ir.sabou.inventory.R.mipmap.ic_launcher).setContentTitle("سابو منیجر").setContentText("$count هشدار مهم نیازمند بررسی است").setAutoCancel(true).build())
        }
    }
    private companion object { const val CHANNEL_ID = "sabou_manager_alerts" }
}
