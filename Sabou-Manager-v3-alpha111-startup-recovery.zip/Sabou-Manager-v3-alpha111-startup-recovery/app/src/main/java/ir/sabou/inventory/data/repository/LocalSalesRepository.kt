package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.*
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.sales.*
import ir.sabou.inventory.domain.recipe.MenuEngineeringCalculator
import ir.sabou.inventory.domain.recipe.MenuPerformanceInput
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.math.BigInteger

class LocalSalesRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : SalesRepository {
    override suspend fun post(draft: SaleDraft): PostedSale {
        authorizer.require("SALES")
        val prepared = SalesCalculator.prepare(draft)
        val valid = prepared.draft
        val now = clock()
        return database.withTransaction {
            require(!database.salesDao().invoiceExists(valid.invoiceNo)) { "شماره فاکتور فروش تکراری است." }
            if (valid.customerId != null) {
                val customer = database.salesDao().activeCustomerById(valid.customerId) ?: error("مشتری فعال پیدا نشد.")
                require(customer.name.equals(valid.customerName, ignoreCase = true)) { "نام مشتری با پرونده انتخاب‌شده مطابقت ندارد." }
                if (valid.paymentMethod == SalePaymentMethod.RECEIVABLE && customer.creditLimitRial > 0) {
                    val currentOutstanding = database.salesDao().customerOutstandingRial(customer.id)
                    val overdue = database.salesDao().customerOverdueRial(customer.id, valid.saleEpochDay)
                    val decision = CorporateCreditCalculator.decide(
                        CorporateCreditPolicy(
                            customerId = customer.id,
                            creditLimitRial = customer.creditLimitRial,
                            blockOnOverdue = true,
                        ),
                        currentOutstandingRial = currentOutstanding,
                        newSaleRial = prepared.total.value,
                        overdueRial = overdue,
                    )
                    require(decision.allowed) { decision.reason }
                }
            }

            data class Consumption(val item: InventoryItemEntity, val quantity: Long, val cost: Long)
            val consumptions = mutableListOf<Consumption>()
            val lineCosts = mutableListOf<Long>()
            prepared.lines.forEach { line ->
                if (line.menuItemId == null) {
                    lineCosts += 0L
                } else {
                    val menu = database.recipeDao().activeMenuItem(line.menuItemId) ?: error("محصول منوی انتخاب‌شده فعال نیست.")
                    require(menu.name.equals(line.productName, ignoreCase = true)) { "نام محصول با منوی انتخاب‌شده مطابقت ندارد." }
                    val ingredients = database.recipeDao().ingredients(menu.id)
                    require(ingredients.isNotEmpty()) { "برای ${menu.name} رسپی ثبت نشده است." }
                    var lineCost = 0L
                    ingredients.forEach { ingredient ->
                        val item = database.inventoryDao().activeById(ingredient.inventoryItemId) ?: error("ماده اولیه رسپی فعال نیست.")
                        val needed = mulDiv(ingredient.quantityMicrosPerUnit, line.quantityMicros, 1_000_000L)
                        require(needed > 0) { "مقدار مصرف محاسبه‌شده نامعتبر است." }
                        require(item.stockMicros >= needed) { "موجودی ${item.name} برای ثبت فروش کافی نیست." }
                        val cost = if (item.stockMicros == 0L) 0L else mulDiv(item.inventoryValueRial, needed, item.stockMicros)
                        consumptions += Consumption(item, needed, cost)
                        lineCost = SignedLongMath.add(lineCost, cost)
                    }
                    lineCosts += lineCost
                }
            }
            // aggregate duplicated ingredients before changing stock
            val aggregated = consumptions.groupBy { it.item.id }.map { (_, rows) ->
                val item = rows.first().item
                Triple(item, rows.sumOf { it.quantity }, rows.sumOf { it.cost })
            }
            aggregated.forEach { (item, qty, cost) ->
                require(item.stockMicros >= qty && item.inventoryValueRial >= cost) { "موجودی ${item.name} هم‌زمان تغییر کرده است." }
            }

            val paid = valid.paymentMethod != SalePaymentMethod.RECEIVABLE
            val saleId = database.salesDao().insertSale(SaleEntity(
                invoiceNo = valid.invoiceNo, customerId = valid.customerId, customerNameSnapshot = valid.customerName,
                saleEpochDay = valid.saleEpochDay, dueEpochDay = valid.dueEpochDay, channel = valid.channel,
                subtotalRial = prepared.subtotal.value, discountRial = valid.discount.value, deliveryRial = valid.delivery.value,
                totalRial = prepared.total.value, paidRial = if (paid) prepared.total.value else 0,
                paymentStatus = if (paid) "PAID" else "UNPAID", paymentMethod = valid.paymentMethod.storedValue,
                notes = valid.notes, createdAtEpochMillis = now,
            ))
            database.salesDao().insertLines(prepared.lines.mapIndexed { index, line -> SaleLineEntity(
                saleId = saleId, menuItemId = line.menuItemId, productNameSnapshot = line.productName,
                quantityMicros = line.quantityMicros, unitPriceRial = line.unitPriceRial,
                lineTotalRial = line.total.value, costOfGoodsRial = lineCosts[index],
            ) })

            aggregated.forEach { (item, qty, cost) ->
                check(database.inventoryDao().updateValuation(item.id, item.stockMicros - qty, item.inventoryValueRial - cost, now) == 1)
                database.stockMovementDao().insert(StockMovementEntity(
                    itemId=item.id, movementType="SALE_CONSUMPTION", quantityDeltaMicros=-qty, valueDeltaRial=-cost,
                    referenceType="SALE", referenceId=saleId, movementEpochDay=valid.saleEpochDay,
                    notes="مصرف رسپی فروش ${valid.invoiceNo}", createdAtEpochMillis=now,
                ))
            }

            val debitAccount = requireNotNull(valid.paymentMethod.accountCode) { "روش پرداخت انتخاب‌شده حساب معین ندارد." }
            check(database.accountingDao().activeAccountExists(debitAccount)); check(database.accountingDao().activeAccountExists("4101"))
            val journalId = database.accountingDao().insertEntry(JournalEntryEntity(
                entryNo="ف-$saleId", entryEpochDay=valid.saleEpochDay, description="فروش به ${valid.customerName}",
                sourceType="SALE", sourceId=saleId, createdAtEpochMillis=now,
            ))
            database.accountingDao().insertLines(listOf(
                JournalLineEntity(entryId=journalId, accountCode=debitAccount, debitRial=prepared.total.value, creditRial=0),
                JournalLineEntity(entryId=journalId, accountCode="4101", debitRial=0, creditRial=prepared.total.value),
            ))
            val totalCost = MoneyRial.sum(lineCosts.map(MoneyRial::of)).value
            if (totalCost > 0) {
                val costJournal = database.accountingDao().insertEntry(JournalEntryEntity(
                    entryNo="بف-$saleId", entryEpochDay=valid.saleEpochDay, description="بهای تمام‌شده فروش ${valid.invoiceNo}",
                    sourceType="SALE_COGS", sourceId=saleId, createdAtEpochMillis=now,
                ))
                database.accountingDao().insertLines(listOf(
                    JournalLineEntity(entryId=costJournal, accountCode="5101", debitRial=totalCost, creditRial=0),
                    JournalLineEntity(entryId=costJournal, accountCode="1301", debitRial=0, creditRial=totalCost),
                ))
            }
            syncRecorder?.record("SALE", saleId, "CREATE", now)
            PostedSale(saleId, journalId, prepared.total, totalCost)
        }
    }

    override suspend fun reverseSale(saleId: Long, reversalEpochDay: Long): Long = database.withTransaction {
        authorizer.require("SALES")
        val sale = database.salesDao().saleById(saleId) ?: error("فاکتور فروش پیدا نشد.")
        require(sale.reversedAtEpochDay == null) { "فاکتور قبلاً برگشت خورده است." }
        require(reversalEpochDay >= sale.saleEpochDay) { "تاریخ برگشت نمی‌تواند قبل از فروش باشد." }
        require(database.salesDao().activeReceiptCount(saleId) == 0L) { "ابتدا وصول‌های فعال این فاکتور را برگشت بزنید." }
        val lines = database.salesDao().linesBySale(saleId)
        val now = clock()
        lines.filter { it.menuItemId != null }.forEach { line ->
            database.recipeDao().ingredients(requireNotNull(line.menuItemId) { "شناسه آیتم منو برای برگشت فروش موجود نیست." }).forEach { ingredient ->
                val item = database.inventoryDao().byId(ingredient.inventoryItemId) ?: error("ماده اولیه پیدا نشد.")
                val qty = mulDiv(ingredient.quantityMicrosPerUnit, line.quantityMicros, 1_000_000L)
                val lineTotalCost = line.costOfGoodsRial
                val recipe = database.recipeDao().ingredients(line.menuItemId)
                val totalQtyWeight = recipe.sumOf { mulDiv(it.quantityMicrosPerUnit, line.quantityMicros, 1_000_000L) }.coerceAtLeast(1)
                val value = mulDiv(lineTotalCost, qty, totalQtyWeight)
                check(database.inventoryDao().updateValuation(item.id, SignedLongMath.add(item.stockMicros, qty), SignedLongMath.add(item.inventoryValueRial, value), now) == 1)
                database.stockMovementDao().insert(StockMovementEntity(itemId=item.id,movementType="SALE_REVERSAL",quantityDeltaMicros=qty,valueDeltaRial=value,referenceType="SALE_REVERSAL",referenceId=saleId,movementEpochDay=reversalEpochDay,notes="برگشت فروش ${sale.invoiceNo}",createdAtEpochMillis=now))
            }
        }
        check(database.salesDao().markSaleReversed(saleId, reversalEpochDay) == 1)
        val debitAccount = when (sale.paymentMethod) { "نقدی" -> "1101"; "کارتخوان", "حواله" -> "1102"; else -> "1201" }
        val journalId=database.accountingDao().insertEntry(JournalEntryEntity(entryNo="برف-$saleId-$now",entryEpochDay=reversalEpochDay,description="برگشت فروش ${sale.invoiceNo}",sourceType="SALE_REVERSAL",sourceId=saleId,createdAtEpochMillis=now))
        val cost=lines.sumOf { it.costOfGoodsRial }
        val journalLines=mutableListOf(
            JournalLineEntity(entryId=journalId,accountCode="4101",debitRial=sale.totalRial,creditRial=0),
            JournalLineEntity(entryId=journalId,accountCode=debitAccount,debitRial=0,creditRial=sale.totalRial),
        )
        if(cost>0){ journalLines += JournalLineEntity(entryId=journalId,accountCode="1301",debitRial=cost,creditRial=0); journalLines += JournalLineEntity(entryId=journalId,accountCode="5101",debitRial=0,creditRial=cost) }
        database.accountingDao().insertLines(journalLines); syncRecorder?.record("SALE", saleId, "REVERSAL", now); journalId
    }

    override suspend fun addCustomer(name: String, phone: String, address: String, creditLimitRial: Long, notes: String): Long {
        authorizer.require("SALES")
        val normalizedName = name.trim()
        require(normalizedName.isNotEmpty())
        require(creditLimitRial >= 0)
        val now = clock()
        return database.salesDao().insertCustomer(CustomerEntity(name = normalizedName, phone = phone.trim(), address = address.trim(), creditLimitRial = creditLimitRial, notes = notes.trim(), createdAtEpochMillis = now, updatedAtEpochMillis = now))
    }

    override suspend fun receive(saleId: Long, amount: MoneyRial, paymentEpochDay: Long, method: SalePaymentMethod): Long = database.withTransaction {
        authorizer.require("SALES")
        require(method != SalePaymentMethod.RECEIVABLE)
        require(amount.value > 0)
        val sale = database.salesDao().saleById(saleId) ?: error("فاکتور فروش پیدا نشد.")
        require(sale.reversedAtEpochDay == null) { "فاکتور برگشت‌خورده است." }
        val remaining = MoneyRial.of(sale.totalRial) - MoneyRial.of(sale.paidRial)
        require(amount <= remaining)
        val account = requireNotNull(method.accountCode) { "روش پرداخت انتخاب‌شده حساب معین ندارد." }
        val now = clock()
        val journalId = database.accountingDao().insertEntry(JournalEntryEntity(entryNo = "و-$saleId-$now", entryEpochDay = paymentEpochDay, description = "وصول فاکتور ${sale.invoiceNo}", sourceType = "SALE_RECEIPT", sourceId = saleId, createdAtEpochMillis = now))
        database.accountingDao().insertLines(listOf(JournalLineEntity(entryId = journalId, accountCode = account, debitRial = amount.value, creditRial = 0), JournalLineEntity(entryId = journalId, accountCode = "1201", debitRial = 0, creditRial = amount.value)))
        val newPaid = MoneyRial.of(sale.paidRial) + amount
        check(database.salesDao().updatePaymentState(saleId, sale.paidRial, newPaid.value, if (newPaid.value == sale.totalRial) "PAID" else "PARTIAL") == 1)
        val paymentId = database.salesDao().insertPayment(SalePaymentEntity(saleId = saleId, amountRial = amount.value, paymentEpochDay = paymentEpochDay, method = method.storedValue ?: method.name, journalEntryId = journalId, createdAtEpochMillis = now))
        syncRecorder?.record("SALE", saleId, "RECEIPT", now, mapOf("amountRial" to amount.value.toString(), "paymentId" to paymentId.toString()))
        paymentId
    }

    override suspend fun reverseReceipt(paymentId: Long, reversalEpochDay: Long): Long = database.withTransaction {
        authorizer.require("SALES")
        val payment = database.salesDao().paymentById(paymentId) ?: error("سند وصول پیدا نشد.")
        require(payment.reversalOfPaymentId == null)
        require(!database.salesDao().paymentAlreadyReversed(paymentId))
        require(reversalEpochDay >= payment.paymentEpochDay)
        val sale = database.salesDao().saleById(payment.saleId) ?: error("فاکتور فروش پیدا نشد.")
        val newPaid = MoneyRial.of(sale.paidRial) - MoneyRial.of(payment.amountRial)
        val account = when (payment.method) { "نقدی" -> "1101"; "کارتخوان", "حواله" -> "1102"; else -> error("روش پرداخت ناشناخته است: ${payment.method}") }
        val now = clock()
        val journalId = database.accountingDao().insertEntry(JournalEntryEntity(entryNo = "بو-$paymentId-$now", entryEpochDay = reversalEpochDay, description = "برگشت وصول فاکتور ${sale.invoiceNo}", sourceType = "SALE_RECEIPT_REVERSAL", sourceId = paymentId, createdAtEpochMillis = now))
        database.accountingDao().insertLines(listOf(JournalLineEntity(entryId = journalId, accountCode = "1201", debitRial = payment.amountRial, creditRial = 0), JournalLineEntity(entryId = journalId, accountCode = account, debitRial = 0, creditRial = payment.amountRial)))
        check(database.salesDao().updatePaymentState(sale.id, sale.paidRial, newPaid.value, if (newPaid.value == 0L) "UNPAID" else "PARTIAL") == 1)
        val reversalId = database.salesDao().insertPayment(SalePaymentEntity(saleId = sale.id, amountRial = SignedLongMath.subtract(0, payment.amountRial), paymentEpochDay = reversalEpochDay, method = payment.method, journalEntryId = journalId, reversalOfPaymentId = paymentId, createdAtEpochMillis = now))
        syncRecorder?.record("SALE", sale.id, "REVERSAL", now, mapOf("paymentId" to paymentId.toString(), "reversalId" to reversalId.toString()))
        reversalId
    }
    override fun observeCustomers():Flow<List<CustomerItem>> = database.salesDao().observeActiveCustomers().map{it.map{x->CustomerItem(x.id,x.name,x.phone,x.creditLimitRial)}}
    override fun observePayments(saleId:Long):Flow<List<SalePaymentItem>> = database.salesDao().observePayments(saleId).map{list->val reversed=list.mapNotNull{it.reversalOfPaymentId}.toSet();list.filter{it.reversalOfPaymentId==null}.map{SalePaymentItem(it.id,it.amountRial,it.paymentEpochDay,it.method,it.id in reversed)}}
    override fun observeSales(query:String):Flow<List<SaleListItem>> = database.salesDao().observeSales(query.trim()).map{rows->rows.map{SaleListItem(it.id,it.invoiceNo,it.customerName,it.saleEpochDay,it.dueEpochDay,it.totalRial,it.paidRial,it.paymentStatus,it.channel,it.costOfGoodsRial,it.reversed)}}

    override suspend fun replaceSale(saleId: Long, reversalEpochDay: Long, replacement: SaleDraft): PostedSale = database.withTransaction {
        authorizer.require("SALES")
        val original = database.salesDao().saleById(saleId) ?: error("فاکتور فروش پیدا نشد.")
        require(original.reversedAtEpochDay == null) { "فاکتور قبلاً برگشت خورده است." }
        require(replacement.invoiceNo != original.invoiceNo) { "برای فاکتور جایگزین شماره جدید وارد کنید." }
        reverseSale(saleId, reversalEpochDay)
        val posted = post(replacement)
        check(database.salesDao().linkReplacement(posted.saleId, saleId) == 1)
        posted
    }

    override fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<SalesReport> {
        require(fromEpochDay <= toEpochDay) { "بازه گزارش نامعتبر است." }
        return combine(
            database.salesDao().observeSalesInRange(fromEpochDay, toEpochDay),
            database.salesDao().observeMenuPerformance(fromEpochDay, toEpochDay),
        ) { rows, menuRows ->
            val active = rows.filterNot { it.reversed }
            val sales = MoneyRial.sum(active.map { MoneyRial.of(it.totalRial) }).value
            val cost = MoneyRial.sum(active.map { MoneyRial.of(it.costOfGoodsRial) }).value
            SalesReport(
                fromEpochDay = fromEpochDay,
                toEpochDay = toEpochDay,
                invoiceCount = active.size,
                salesRial = sales,
                costOfGoodsRial = cost,
                grossProfitRial = SignedLongMath.subtract(sales, cost),
                receivablesRial = MoneyRial.sum(active.map { MoneyRial.of(it.totalRial) - MoneyRial.of(it.paidRial) }).value,
                topChannels = active.groupBy { it.channel }.mapValues { (_, list) -> MoneyRial.sum(list.map { MoneyRial.of(it.totalRial) }).value }.entries.sortedByDescending { it.value }.take(5).map { it.key to it.value },
                menuPerformance = menuRows.takeIf { it.isNotEmpty() }?.let { performance ->
                    MenuEngineeringCalculator.classify(performance.map { MenuPerformanceInput(it.menuItemId, it.name, it.unitsSold, it.salesRial, it.costRial) })
                }.orEmpty(),
            )
        }
    }

    private fun mulDiv(a:Long,b:Long,d:Long):Long { require(a>=0&&b>=0&&d>0); val v=BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(d)); require(v<=BigInteger.valueOf(Long.MAX_VALUE)){"محاسبه از محدوده امن خارج شد."}; return v.toLong() }
}
