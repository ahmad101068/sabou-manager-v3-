package ir.sabou.inventory.ui

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import ir.sabou.inventory.domain.sales.SalesReport
import ir.sabou.inventory.domain.purchase.PurchaseDetails

private fun printHtml(context: Context, title: String, html: String) {
    val webView = WebView(context)
    webView.webViewClient = object : android.webkit.WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            manager.print(title, view.createPrintDocumentAdapter(title), PrintAttributes.Builder().build())
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}

fun printPurchaseInvoice(context: Context, details: PurchaseDetails) {
    val rows = details.lines.joinToString("") { "<tr><td>${it.itemName}</td><td>${it.quantityMicros / 1_000_000.0} ${it.unit}</td><td>${it.unitCostRial}</td><td>${it.lineTotalRial}</td></tr>" }
    printHtml(context, "فاکتور خرید ${details.invoiceNo}", """<html dir='rtl'><head><meta charset='utf-8'><style>body{font-family:sans-serif;padding:24px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #888;padding:8px}</style></head><body><h1>فاکتور خرید ${details.invoiceNo}</h1><p>تأمین‌کننده: ${details.supplierName}</p><table><tr><th>شرح</th><th>تعداد</th><th>فی</th><th>جمع</th></tr>$rows</table><h3>جمع کل: ${details.totalRial} ریال</h3></body></html>""")
}

fun printSalesReport(context: Context, report: SalesReport) {
    val html = """<html dir='rtl'><head><meta charset='utf-8'><style>body{font-family:sans-serif;padding:24px}h1{font-size:22px}table{width:100%;border-collapse:collapse}td{border:1px solid #888;padding:8px}</style></head><body><h1>گزارش فروش سبو</h1><p>بازه: ${report.fromEpochDay} تا ${report.toEpochDay}</p><table><tr><td>تعداد فاکتور</td><td>${report.invoiceCount}</td></tr><tr><td>فروش</td><td>${report.salesRial}</td></tr><tr><td>بهای تمام‌شده</td><td>${report.costOfGoodsRial}</td></tr><tr><td>سود ناخالص</td><td>${report.grossProfitRial}</td></tr><tr><td>مطالبات</td><td>${report.receivablesRial}</td></tr></table></body></html>"""
    val webView = WebView(context)
    webView.webViewClient = object : android.webkit.WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            manager.print("Sabou-Sales-Report", view.createPrintDocumentAdapter("گزارش فروش"), PrintAttributes.Builder().build())
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}
