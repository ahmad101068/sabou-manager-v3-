package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AssetOutboxIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var authorizer: SessionAuthorizer
    private val now = 2_000_000L

    @Before
    fun setUp() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = AppDatabase.createInMemory(context)
        authorizer = SessionAuthorizer(database)
        val security = LocalSecurityRepository(database, clock = { now }, authorizer = authorizer)
        val ownerId = security.save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER))
        security.switchUser(ownerId, "123456")
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun recorderFailureRollsBackAssetDisposal() = runBlocking {
        val failingRecorder = object : SyncRecorder(database, "test-device") {
            override suspend fun record(entityType: String, entityId: Long, changeType: String, occurredAt: Long, payloadFields: Map<String, String>) {
                error("forced outbox failure")
            }
        }
        val repository = LocalAssetRepository(database, clock = { now }, syncRecorder = failingRecorder, authorizer = authorizer)
        val id = repository.save(null, draft("A-1"))
        try {
            repository.dispose(id)
            fail("Expected disposal failure")
        } catch (_: IllegalStateException) {
            // expected
        }
        assertEquals("ACTIVE", database.assetDao().assetById(id)?.status)
        assertTrue(database.syncDao().pending(10).isEmpty())
    }

    @Test
    fun successfulDisposalCommitsAssetAndVersionedOutboxTogether() = runBlocking {
        val repository = LocalAssetRepository(database, clock = { now }, syncRecorder = SyncRecorder(database, "test-device"), authorizer = authorizer)
        val id = repository.save(null, draft("A-2"))
        repository.dispose(id)
        assertEquals("DISPOSED", database.assetDao().assetById(id)?.status)
        val change = database.syncDao().pending(10).single()
        assertEquals("DISPOSE", change.changeType)
        assertEquals(1L, change.revision)
        assertEquals(1, change.payloadVersion)
        assertEquals(64, change.payloadHash.length)
        assertTrue(change.payload.isNotBlank())
    }

    private fun draft(code: String) = AssetDraft(code, "دارایی تست", "تجهیزات", 20_000, 1_000_000, 100_000, 24, "آشپزخانه", "")
}
