package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.control.BudgetCategory
import ir.sabou.inventory.domain.control.AvailabilityDraft
import ir.sabou.inventory.domain.control.BudgetDraft
import ir.sabou.inventory.domain.control.BudgetRecord
import ir.sabou.inventory.domain.control.InventoryLotRecord
import ir.sabou.inventory.domain.control.LaborPolicy
import ir.sabou.inventory.domain.control.LotRegistrationDraft
import ir.sabou.inventory.domain.control.LotTransferDraft
import ir.sabou.inventory.domain.control.ProcurementException
import ir.sabou.inventory.domain.control.StorageLocationRecord
import ir.sabou.inventory.domain.control.ShiftSwapDraft
import ir.sabou.inventory.domain.control.AccountingPeriodDraft
import ir.sabou.inventory.domain.control.CashReconciliationDraft
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.personnel.EmployeeRecord

@Composable
fun ManagementControlScreen(
    state: ControlCenterUiState,
    inventoryItems: List<InventoryItemRecord>,
    employees: List<EmployeeRecord>,
    onSetRange: (Long, Long) -> Unit,
    onFollowUp: (Long, String, () -> Unit) -> Unit,
    onCreateLocation: (String, String, () -> Unit) -> Unit,
    onRegisterLot: (LotRegistrationDraft, () -> Unit) -> Unit,
    onTransferLot: (LotTransferDraft, () -> Unit) -> Unit,
    onSaveBudget: (Long?, BudgetDraft, () -> Unit) -> Unit,
    onRecordSpend: (Long, Long, Long, String, () -> Unit) -> Unit,
    onSaveLaborPolicy: (LaborPolicy, () -> Unit) -> Unit,
    onSaveAvailability: (AvailabilityDraft, () -> Unit) -> Unit,
    onRequestShiftSwap: (ShiftSwapDraft, () -> Unit) -> Unit,
    onReviewShiftSwap: (Long, Boolean) -> Unit,
    onRecordWorkBreak: (Long, Int, Int, () -> Unit) -> Unit,
    onCloseAccountingPeriod: (AccountingPeriodDraft, () -> Unit) -> Unit,
    onReopenAccountingPeriod: (Long) -> Unit,
    onReconcileSalesCash: (CashReconciliationDraft, () -> Unit) -> Unit,
    onBack: () -> Unit,
) {
    val snapshot = state.snapshot
    var showLocation by remember { mutableStateOf(false) }
    var showLot by remember { mutableStateOf(false) }
    var showBudget by remember { mutableStateOf(false) }
    var showPolicy by remember { mutableStateOf(false) }
    var showAvailability by remember { mutableStateOf(false) }
    var showSwap by remember { mutableStateOf(false) }
    var followUpTarget by remember { mutableStateOf<ProcurementException?>(null) }
    var transferTarget by remember { mutableStateOf<InventoryLotRecord?>(null) }
    var spendTarget by remember { mutableStateOf<BudgetRecord?>(null) }
    var breakTarget by remember { mutableStateOf<ir.sabou.inventory.domain.control.LaborShiftInput?>(null) }
    var showPeriodClose by remember { mutableStateOf(false) }
    var showCashReconcile by remember { mutableStateOf(false) }

    Scaffold(topBar = { ProfessionalTopBar("مرکز کنترل مدیریت", "خرید، فودکاست، انبار، بودجه و نیروی انسانی", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            state.message?.let { item { MessageCard(it) } }
            item {
                FormSection("دوره تحلیل بهای تمام‌شده") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(Modifier.weight(1f)) { PersianDateField("از تاریخ", state.fromEpochDay) { onSetRange(it, state.toEpochDay) } }
                        Column(Modifier.weight(1f)) { PersianDateField("تا تاریخ", state.toEpochDay) { onSetRange(state.fromEpochDay, it) } }
                    }
                    snapshot?.foodCost?.let { food ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            MetricTile("تئوری", formatMoney(food.theoreticalCostRial), Modifier.weight(1f))
                            MetricTile("مصرف ثبت‌شده", formatMoney(food.actualCostRial), Modifier.weight(1f), emphasized = food.varianceRial > 0)
                        }
                        CompactInfoRow("مغایرت مصرف", formatMoney(food.varianceRial), food.varianceRial > 0)
                        CompactInfoRow("ضایعات دوره", formatMoney(food.wasteCostRial))
                        CompactInfoRow("درصد واقعی از فروش", "${food.actualBasisPoints / 100}.${(food.actualBasisPoints % 100).toString().padStart(2, '0')}٪")
                    }
                }
            }
            item { SectionHeading("استثناهای سفارش خرید", "مواردی که به پیگیری عملی نیاز دارند") }
            if (snapshot?.procurementExceptions.isNullOrEmpty()) item { EmptyStatePanel("مورد بحرانی وجود ندارد", "سفارش‌های باز در محدوده زمانی قابل‌قبول هستند.") }
            else items(snapshot!!.procurementExceptions, key = { "${it.purchaseOrderId}-${it.kind}" }) { exception ->
                ControlCard(exception.title, "${exception.orderNo} · ${exception.supplierName}") {
                    CompactInfoRow("روزهای تأخیر", exception.ageDays.toString(), exception.ageDays > 0)
                    OutlinedButton(onClick = { followUpTarget = exception }, modifier = Modifier.fillMaxWidth()) { Text("ثبت پیگیری") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionHeading("موجودی مکان‌محور و بچ", "FEFO، انقضا و انتقال داخلی")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TextButton(onClick = { showLocation = true }) { Text("محل جدید") }
                        TextButton(onClick = { showLot = true }, enabled = !snapshot?.locations.isNullOrEmpty() && inventoryItems.isNotEmpty()) { Text("ثبت بچ") }
                    }
                }
            }
            if (snapshot?.lots.isNullOrEmpty()) item { EmptyStatePanel("هنوز بچی ثبت نشده", "ابتدا محل نگهداری و سپس بچ کالا را ثبت کنید.") }
            else items(snapshot!!.lots, key = { it.id }) { lot ->
                ControlCard("${lot.itemName} · ${lot.lotCode}", lot.locationName) {
                    CompactInfoRow("مقدار", formatQuantity(lot.quantityMicros))
                    lot.barcode?.let { CompactInfoRow("بارکد", it) }
                    CompactInfoRow("انقضا", lot.expiryEpochDay?.let { epochDayToPersian(it).display() } ?: "بدون انقضا", lot.expiryRisk(currentEpochDay()) != null)
                    OutlinedButton(onClick = { transferTarget = lot }, modifier = Modifier.fillMaxWidth(), enabled = snapshot.locations.size > 1) { Text("انتقال به محل دیگر") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionHeading("بودجه و کنترل هزینه", "خرید، حقوق و ضایعات به‌صورت خودکار محاسبه می‌شوند")
                    TextButton(onClick = { showBudget = true }) { Text("بودجه جدید") }
                }
            }
            if (snapshot?.budgets.isNullOrEmpty()) item { EmptyStatePanel("بودجه‌ای تعریف نشده", "برای دوره جاری سقف هزینه تعریف کنید.") }
            else items(snapshot!!.budgets, key = { it.id }) { budget ->
                ControlCard(budget.name, "${budget.costCenter} · ${budget.category.name}") {
                    CompactInfoRow("مصرف / سقف", "${formatMoney(budget.actualRial)} / ${formatMoney(budget.limitRial)}", budget.actualRial > budget.limitRial)
                    CompactInfoRow("تعهد باز", formatMoney(budget.committedRial), budget.committedRial > 0)
                    CompactInfoRow("مانده", formatMoney(budget.remainingRial), budget.remainingRial < 0)
                    OutlinedButton(onClick = { spendTarget = budget }, modifier = Modifier.fillMaxWidth()) { Text("ثبت هزینه دستی") }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    SectionHeading("کنترل نیروی انسانی", "سقف ساعات، استراحت و فاصله بین شیفت‌ها")
                    Row { TextButton(onClick = { showAvailability = true }, enabled = employees.isNotEmpty()) { Text("دسترسی") }; TextButton(onClick = { showSwap = true }, enabled = !snapshot?.plannedShifts.isNullOrEmpty()) { Text("تعویض شیفت") }; TextButton(onClick = { showPolicy = true }) { Text("سیاست کار") } }
                }
            }
            if (snapshot?.laborAlerts.isNullOrEmpty()) item { EmptyStatePanel("مغایرت برنامه کاری وجود ندارد", "شیفت‌های ثبت‌شده با سیاست فعلی سازگار هستند.") }
            else items(snapshot!!.laborAlerts, key = { "${it.shiftId}-${it.message}" }) { alert ->
                ControlCard(alert.employeeName, alert.message) {
                    snapshot!!.plannedShifts.firstOrNull { it.shiftId == alert.shiftId }?.let { shift ->
                        OutlinedButton(onClick = { breakTarget = shift }, modifier = Modifier.fillMaxWidth()) { Text("ثبت زمان استراحت") }
                    }
                }
            }
            if (!snapshot?.shiftSwaps.isNullOrEmpty()) {
                item { SectionHeading("درخواست‌های جابه‌جایی شیفت", "درخواست‌های باز نیازمند تصمیم مدیر") }
                items(snapshot!!.shiftSwaps, key = { it.id }) { swap ->
                    ControlCard(swap.requesterName, "${swap.note} · ${swap.status}") {
                        if (swap.status == "PENDING") Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onReviewShiftSwap(swap.id, false) }, modifier = Modifier.weight(1f)) { Text("رد") }
                            Button(onClick = { onReviewShiftSwap(swap.id, true) }, modifier = Modifier.weight(1f), enabled = swap.targetEmployeeId != null) { Text("تأیید") }
                        }
                    }
                }
            }
            item { Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){SectionHeading("کنترل مالی قطعی","قفل دوره، تطبیق صندوق و مسیر سند");Row{TextButton(onClick={showCashReconcile=true}){Text("تطبیق صندوق")};TextButton(onClick={showPeriodClose=true}){Text("بستن دوره")}}} }
            if (!snapshot?.accountingPeriods.isNullOrEmpty()) items(snapshot!!.accountingPeriods,key={"period-${it.id}"}) { period ->
                ControlCard("${epochDayToPersian(period.fromEpochDay).display()} تا ${epochDayToPersian(period.toEpochDay).display()}","${period.status} · ${period.closedBy}") { Text(period.reason,style=MaterialTheme.typography.bodySmall); if(period.status=="CLOSED") OutlinedButton(onClick={onReopenAccountingPeriod(period.id)},modifier=Modifier.fillMaxWidth()){Text("بازگشایی فقط توسط مالک")} }
            }
            if (!snapshot?.cashReconciliations.isNullOrEmpty()) items(snapshot!!.cashReconciliations.take(10),key={"cash-${it.id}"}) { cash ->
                ControlCard("تطبیق ${epochDayToPersian(cash.businessEpochDay).display()} · نسخه ${cash.revisionNo}",cash.status) { CompactInfoRow("انتظار / واقعی","${formatMoney(cash.expectedTotalRial)} / ${formatMoney(cash.actualTotalRial)}",cash.varianceRial!=0L); CompactInfoRow("مغایرت",formatMoney(cash.varianceRial),cash.varianceRial!=0L) }
            }
            item { SectionHeading("ردیابی KPI تا سند","آخرین اسناد قطعی بازه انتخاب‌شده") }
            if (!snapshot?.kpiTrace.isNullOrEmpty()) items(snapshot!!.kpiTrace.take(15),key={"trace-${it.id}"}) { trace -> ControlCard(trace.entryNo,trace.description){Text("${trace.sourceType} #${trace.sourceId} · ${epochDayToPersian(trace.entryEpochDay).display()}",style=MaterialTheme.typography.bodySmall);CompactInfoRow("گردش بدهکار / بستانکار","${formatMoney(trace.debitRial)} / ${formatMoney(trace.creditRial)}") } }
        }
    }

    followUpTarget?.let { target -> FollowUpDialog(target, { followUpTarget = null }) { note -> onFollowUp(target.purchaseOrderId, note) { followUpTarget = null } } }
    if (showLocation) LocationDialog({ showLocation = false }) { name, kind -> onCreateLocation(name, kind) { showLocation = false } }
    if (showLot && snapshot != null) LotDialog(inventoryItems, snapshot.locations, { showLot = false }) { onRegisterLot(it) { showLot = false } }
    transferTarget?.let { lot -> TransferDialog(lot, snapshot?.locations.orEmpty(), { transferTarget = null }) { onTransferLot(it) { transferTarget = null } } }
    if (showBudget) BudgetDialog({ showBudget = false }) { onSaveBudget(null, it) { showBudget = false } }
    spendTarget?.let { budget -> SpendDialog(budget, { spendTarget = null }) { amount, day, reference -> onRecordSpend(budget.id, amount, day, reference) { spendTarget = null } } }
    if (showPolicy) LaborPolicyDialog({ showPolicy = false }) { onSaveLaborPolicy(it) { showPolicy = false } }
    if (showAvailability) AvailabilityDialog(employees, { showAvailability = false }) { onSaveAvailability(it) { showAvailability = false } }
    if (showSwap && snapshot != null) ShiftSwapDialog(snapshot.plannedShifts, employees, { showSwap = false }) { onRequestShiftSwap(it) { showSwap = false } }
    breakTarget?.let { shift -> WorkBreakDialog(shift, { breakTarget = null }) { start, end -> onRecordWorkBreak(shift.shiftId, start, end) { breakTarget = null } } }
    if(showPeriodClose) AccountingPeriodDialog({showPeriodClose=false}){onCloseAccountingPeriod(it){showPeriodClose=false}}
    if(showCashReconcile) CashReconciliationDialog({showCashReconcile=false}){onReconcileSalesCash(it){showCashReconcile=false}}
}

@Composable private fun AccountingPeriodDialog(onDismiss:()->Unit,onSave:(AccountingPeriodDraft)->Unit){var from by remember{mutableLongStateOf(currentEpochDay()-29)};var to by remember{mutableLongStateOf(currentEpochDay())};var reason by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("بستن قطعی دوره مالی")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){PersianDateField("از",from){from=it};PersianDateField("تا",to){to=it};OutlinedTextField(reason,{reason=it.take(300)},label={Text("دلیل بستن")})}},confirmButton={Button(enabled=reason.trim().length>=5,onClick={onSave(AccountingPeriodDraft(from,to,reason))}){Text("بستن و قفل اسناد")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})}

@Composable
private fun CashReconciliationDialog(onDismiss: () -> Unit, onSave: (CashReconciliationDraft) -> Unit) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var cash by remember { mutableStateOf("") }
    var card by remember { mutableStateOf("") }
    var transfer by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    @Composable fun AmountField(value: String, change: (String) -> Unit, label: String) = OutlinedTextField(
        value = value,
        onValueChange = { change(formatMoneyInput(it)) },
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تطبیق صندوق و کارت‌خوان") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PersianDateField("روز فروش بسته‌شده", day) { day = it }
                AmountField(cash, { cash = it }, "نقد واقعی")
                AmountField(card, { card = it }, "کارت واقعی")
                AmountField(transfer, { transfer = it }, "حواله واقعی")
                OutlinedTextField(note, { note = it.take(300) }, label = { Text("توضیح مغایرت") })
            }
        },
        confirmButton = { Button(onClick = { onSave(CashReconciliationDraft(day, parseMoneyInputOrZero(cash), parseMoneyInputOrZero(card), parseMoneyInputOrZero(transfer), note)) }) { Text("ثبت تطبیق") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable private fun ControlCard(title: String, subtitle: String, content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable private fun FollowUpDialog(target: ProcurementException, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("پیگیری ${target.orderNo}") }, text = { OutlinedTextField(note, { note = it.take(300) }, label = { Text("نتیجه تماس یا پیگیری") }, modifier = Modifier.fillMaxWidth()) }, confirmButton = { Button(onClick = { onSave(note) }) { Text("ثبت") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun LocationDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var kind by remember { mutableStateOf("WAREHOUSE") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("محل نگهداری جدید") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it.take(80) }, label = { Text("نام محل") }); SelectionField("نوع", kind, listOf(0L to "WAREHOUSE", 1L to "KITCHEN", 2L to "BAR", 3L to "FREEZER", 4L to "OTHER")) { kind = listOf("WAREHOUSE", "KITCHEN", "BAR", "FREEZER", "OTHER")[it.toInt()] } } }, confirmButton = { Button(onClick = { onSave(name, kind) }) { Text("ثبت") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun LotDialog(items: List<InventoryItemRecord>, locations: List<StorageLocationRecord>, onDismiss: () -> Unit, onSave: (LotRegistrationDraft) -> Unit) {
    var itemId by remember { mutableLongStateOf(items.firstOrNull()?.id ?: 0) }; var locationId by remember { mutableLongStateOf(locations.firstOrNull()?.id ?: 0) }
    var code by remember { mutableStateOf("") }; var barcode by remember { mutableStateOf("") }; var quantity by remember { mutableStateOf("") }; var cost by remember { mutableStateOf("") }
    var received by remember { mutableLongStateOf(currentEpochDay()) }; var expiry by remember { mutableStateOf<Long?>(null) }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت بچ / سری ساخت") },
        text = {
            Column(
                Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                error?.let { MessageCard(it, true) }
                SelectionField("کالا", items.firstOrNull { it.id == itemId }?.name, items.map { it.id to it.name }) { itemId = it }
                SelectionField("محل", locations.firstOrNull { it.id == locationId }?.name, locations.map { it.id to it.name }) { locationId = it }
                OutlinedTextField(code, { code = it.take(80) }, label = { Text("شماره بچ") })
                OutlinedTextField(barcode, { barcode = it.take(80) }, label = { Text("بارکد (اختیاری)") })
                OutlinedTextField(quantity, { quantity = it }, label = { Text("مقدار") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                OutlinedTextField(cost, { cost = formatMoneyInput(it) }, label = { Text("بهای واحد") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                PersianDateField("تاریخ ورود", received) { received = it }
                OptionalPersianDateField("تاریخ انقضا", expiry, { selected -> expiry = selected })
            }
        },
        confirmButton = {
            Button(onClick = {
                runCatching {
                    LotRegistrationDraft(
                        itemId = itemId,
                        locationId = locationId,
                        lotCode = code,
                        receivedEpochDay = received,
                        expiryEpochDay = expiry,
                        quantityMicros = parseQuantity(quantity).value,
                        unitCostRial = parseMoneyInputOrZero(cost),
                        barcode = barcode.trim().takeIf { value -> value.isNotEmpty() },
                    ).validated()
                }.onSuccess(onSave).onFailure { error = it.message }
            }) { Text("ثبت") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable private fun TransferDialog(lot: InventoryLotRecord, locations: List<StorageLocationRecord>, onDismiss: () -> Unit, onSave: (LotTransferDraft) -> Unit) {
    val targets = locations.filter { it.id != lot.locationId && it.isActive }; var destination by remember { mutableLongStateOf(targets.firstOrNull()?.id ?: 0) }; var quantity by remember { mutableStateOf("") }; var day by remember { mutableLongStateOf(currentEpochDay()) }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("انتقال ${lot.itemName}") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { error?.let { MessageCard(it, true) }; SelectionField("مقصد", targets.firstOrNull { it.id == destination }?.name, targets.map { it.id to it.name }) { destination = it }; OutlinedTextField(quantity, { quantity = it }, label = { Text("مقدار از ${formatQuantity(lot.quantityMicros)}") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)); PersianDateField("تاریخ انتقال", day) { day = it }; OutlinedTextField(note, { note = it.take(300) }, label = { Text("توضیحات") }) } }, confirmButton = { Button(onClick = { runCatching { LotTransferDraft(lot.id, destination, parseQuantity(quantity).value, day, note).validated() }.onSuccess(onSave).onFailure { error = it.message } }) { Text("انتقال") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun BudgetDialog(onDismiss: () -> Unit, onSave: (BudgetDraft) -> Unit) {
    var name by remember { mutableStateOf("") }; var category by remember { mutableStateOf(BudgetCategory.PURCHASE) }; var center by remember { mutableStateOf("کل مجموعه") }; var from by remember { mutableLongStateOf(currentEpochDay()) }; var to by remember { mutableLongStateOf(currentEpochDay() + 30) }; var limit by remember { mutableStateOf("") }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("تعریف بودجه") }, text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) { error?.let { MessageCard(it, true) }; OutlinedTextField(name, { name = it.take(80) }, label = { Text("نام بودجه") }); SelectionField("نوع", category.name, BudgetCategory.entries.mapIndexed { index, value -> index.toLong() to value.name }) { category = BudgetCategory.entries[it.toInt()] }; OutlinedTextField(center, { center = it.take(80) }, label = { Text("مرکز هزینه") }); PersianDateField("شروع", from) { from = it }; PersianDateField("پایان", to) { to = it }; OutlinedTextField(limit, { limit = formatMoneyInput(it) }, label = { Text("سقف بودجه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) } }, confirmButton = { Button(onClick = { runCatching { BudgetDraft(name, category, center, from, to, parseMoneyInputOrZero(limit)).validated() }.onSuccess(onSave).onFailure { error = it.message } }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun SpendDialog(budget: BudgetRecord, onDismiss: () -> Unit, onSave: (Long, Long, String) -> Unit) {
    var amount by remember { mutableStateOf("") }; var day by remember { mutableLongStateOf(currentEpochDay().coerceIn(budget.fromEpochDay, budget.toEpochDay)) }; var reference by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("هزینه دستی ${budget.name}") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(amount, { amount = formatMoneyInput(it) }, label = { Text("مبلغ") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)); PersianDateField("تاریخ", day) { day = it }; OutlinedTextField(reference, { reference = it.take(120) }, label = { Text("مرجع / توضیح") }) } }, confirmButton = { Button(onClick = { runCatching { onSave(parseMoneyInputOrZero(amount), day, reference) } }) { Text("ثبت") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun LaborPolicyDialog(onDismiss: () -> Unit, onSave: (LaborPolicy) -> Unit) {
    var weekly by remember { mutableStateOf("44") }; var shift by remember { mutableStateOf("12") }; var rest by remember { mutableStateOf("11") }; var breakAfter by remember { mutableStateOf("6") }; var breakMinutes by remember { mutableStateOf("30") }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("سیاست کنترل ساعات کار") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { error?.let { MessageCard(it, true) }; OutlinedTextField(weekly, { weekly = it.filter(Char::isDigit) }, label = { Text("سقف هفتگی (ساعت)") }); OutlinedTextField(shift, { shift = it.filter(Char::isDigit) }, label = { Text("سقف هر شیفت (ساعت)") }); OutlinedTextField(rest, { rest = it.filter(Char::isDigit) }, label = { Text("حداقل استراحت بین شیفت‌ها (ساعت)") }); OutlinedTextField(breakAfter, { breakAfter = it.filter(Char::isDigit) }, label = { Text("الزام استراحت پس از (ساعت)") }); OutlinedTextField(breakMinutes, { breakMinutes = it.filter(Char::isDigit) }, label = { Text("حداقل استراحت (دقیقه)") }) } }, confirmButton = { Button(onClick = { runCatching { LaborPolicy(weekly.toInt() * 60, shift.toInt() * 60, rest.toInt() * 60, breakAfter.toInt() * 60, breakMinutes.toInt()).validated() }.onSuccess(onSave).onFailure { error = it.message } }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun AvailabilityDialog(employees: List<EmployeeRecord>, onDismiss: () -> Unit, onSave: (AvailabilityDraft) -> Unit) {
    var employeeId by remember { mutableLongStateOf(employees.firstOrNull()?.id ?: 0) }; var day by remember { mutableStateOf("1") }; var from by remember { mutableStateOf("480") }; var to by remember { mutableStateOf("1020") }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("دسترس‌پذیری هفتگی") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { error?.let { MessageCard(it, true) }; SelectionField("پرسنل", employees.firstOrNull { it.id == employeeId }?.name, employees.map { it.id to it.name }) { employeeId = it }; SelectionField("روز هفته", day, (1L..7L).map { it to "روز $it" }) { day = it.toString() }; OutlinedTextField(from, { from = it.filter(Char::isDigit) }, label = { Text("شروع به دقیقه از نیمه‌شب") }); OutlinedTextField(to, { to = it.filter(Char::isDigit) }, label = { Text("پایان به دقیقه از نیمه‌شب") }) } }, confirmButton = { Button(onClick = { runCatching { AvailabilityDraft(employeeId, day.toInt(), from.toInt(), to.toInt()).validated() }.onSuccess(onSave).onFailure { error = it.message } }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun ShiftSwapDialog(shifts: List<ir.sabou.inventory.domain.control.LaborShiftInput>, employees: List<EmployeeRecord>, onDismiss: () -> Unit, onSave: (ShiftSwapDraft) -> Unit) {
    var shiftId by remember { mutableLongStateOf(shifts.firstOrNull()?.shiftId ?: 0) }; val shift = shifts.firstOrNull { it.shiftId == shiftId }; var target by remember { mutableLongStateOf(employees.firstOrNull { it.id != shift?.employeeId }?.id ?: 0) }; var note by remember { mutableStateOf("") }; var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("درخواست تعویض شیفت") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { error?.let { MessageCard(it, true) }; SelectionField("شیفت", shift?.let { "${it.employeeName} · ${epochDayToPersian(it.epochDay).display()}" }, shifts.map { it.shiftId to "${it.employeeName} · ${epochDayToPersian(it.epochDay).display()}" }) { shiftId = it }; SelectionField("جایگزین", employees.firstOrNull { it.id == target }?.name, employees.filter { it.id != shift?.employeeId }.map { it.id to it.name }) { target = it }; OutlinedTextField(note, { note = it.take(300) }, label = { Text("دلیل درخواست") }) } }, confirmButton = { Button(onClick = { runCatching { ShiftSwapDraft(shiftId, requireNotNull(shift).employeeId, target.takeIf { it > 0 }, note).validated() }.onSuccess(onSave).onFailure { error = it.message } }) { Text("ثبت درخواست") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable private fun WorkBreakDialog(shift: ir.sabou.inventory.domain.control.LaborShiftInput, onDismiss: () -> Unit, onSave: (Int, Int) -> Unit) {
    var start by remember { mutableStateOf((shift.startMinute + 180).toString()) }; var end by remember { mutableStateOf((shift.startMinute + 210).coerceAtMost(shift.endMinute).toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ثبت استراحت ${shift.employeeName}") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("شیفت: ${shift.startMinute} تا ${shift.endMinute}"); OutlinedTextField(start, { start = it.filter(Char::isDigit) }, label = { Text("شروع به دقیقه از نیمه‌شب") }); OutlinedTextField(end, { end = it.filter(Char::isDigit) }, label = { Text("پایان به دقیقه از نیمه‌شب") }) } }, confirmButton = { Button(onClick = { runCatching { onSave(start.toInt(), end.toInt()) } }) { Text("ثبت") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}
