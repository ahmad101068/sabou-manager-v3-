package ir.sabou.inventory.data

import android.content.Context
import android.net.Uri
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AccountSeedCallback
import ir.sabou.inventory.data.repository.DashboardRepository
import ir.sabou.inventory.data.repository.LocalAccountingRepository
import ir.sabou.inventory.data.repository.LocalOperationsRepository
import ir.sabou.inventory.data.repository.LocalPurchaseRepository
import ir.sabou.inventory.data.repository.LocalProcurementRepository
import ir.sabou.inventory.data.repository.LocalPersonnelRepository
import ir.sabou.inventory.data.repository.LocalPerformanceRepository
import ir.sabou.inventory.data.repository.LocalSyncRepository
import ir.sabou.inventory.data.repository.SyncRecorder
import ir.sabou.inventory.data.repository.LocalDailySalesRepository
import ir.sabou.inventory.data.repository.LocalSecurityRepository
import ir.sabou.inventory.data.repository.LocalAssetRepository
import ir.sabou.inventory.data.repository.LocalRecipeRepository
import ir.sabou.inventory.data.repository.LocalAlertRepository
import ir.sabou.inventory.data.repository.LocalManagementControlRepository
import ir.sabou.inventory.data.security.DatabaseKeyProvider
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.accounting.AccountingRepository
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.purchase.PurchaseRepository
import ir.sabou.inventory.domain.purchase.ProcurementRepository
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.sales.DailySalesRepository
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.operations.AlertRepository
import ir.sabou.inventory.domain.operations.CloudSyncConfig
import ir.sabou.inventory.domain.control.ManagementControlRepository
import ir.sabou.inventory.data.repository.HttpsSyncTransport
import ir.sabou.inventory.data.repository.SyncCoordinator
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    private val keyProvider = DatabaseKeyProvider(appContext)
    val backupManager = BackupManager(appContext, keyProvider)
    private val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        backupManager.applyPendingRestore()
        try {
            AppDatabase.create(appContext, keyProvider).also { db ->
                db.openHelper.writableDatabase.query("PRAGMA cipher_integrity_check").use { cursor ->
                    val integrityErrors = buildList {
                        while (cursor.moveToNext()) add(cursor.getString(0))
                    }
                    require(integrityErrors.isEmpty()) {
                        "اعتبارسنجی پایگاه داده ناموفق بود: ${integrityErrors.joinToString()}"
                    }
                }
                db.openHelper.writableDatabase.execSQL("DELETE FROM app_session")
                backupManager.markRestoreValidated()
            }
        } catch (error: Throwable) {
            if (!backupManager.rollbackLastRestore()) throw error
            AppDatabase.create(appContext, keyProvider).also { db ->
                db.openHelper.writableDatabase.execSQL("DELETE FROM app_session")
            }
        }
    }
    private val authorizer by lazy { SessionAuthorizer(database) }

    /** Opens and validates the encrypted Room database. Call this from a background dispatcher. */
    fun initialize() {
        database.openHelper.writableDatabase
    }

    val purchaseRepository: PurchaseRepository by lazy {
        LocalPurchaseRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }

    val procurementRepository: ProcurementRepository by lazy {
        LocalProcurementRepository(database, authorizer, syncRecorder = syncRecorder)
    }

    val dailySalesRepository: DailySalesRepository by lazy {
        LocalDailySalesRepository(database, authorizer, syncRecorder = syncRecorder)
    }

    val recipeRepository: RecipeRepository by lazy { LocalRecipeRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }

    val dashboardRepository: DashboardRepository by lazy {
        DashboardRepository(database)
    }

    val operationsRepository: OperationsRepository by lazy {
        LocalOperationsRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }

    val securityRepository: SecurityRepository by lazy { LocalSecurityRepository(database, authorizer = authorizer) }

    val personnelRepository: PersonnelRepository by lazy { LocalPersonnelRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val performanceRepository by lazy { LocalPerformanceRepository(database, authorizer = authorizer, syncRecorder = syncRecorder) }
    val syncRepository by lazy { LocalSyncRepository(database) }
    private val syncPreferences by lazy { appContext.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE) }
    fun syncConfig(): CloudSyncConfig = CloudSyncConfig(
        endpoint = syncPreferences.getString("endpoint", "").orEmpty(),
        tenantId = syncPreferences.getString("tenant", "").orEmpty(),
        enabled = syncPreferences.getBoolean("enabled", false),
        accessToken = syncPreferences.getString("access_token_protected", null)?.let(keyProvider::unprotectSecret)
            ?: syncPreferences.getString("access_token", "").orEmpty(),
        refreshToken = syncPreferences.getString("refresh_token_protected", null)?.let(keyProvider::unprotectSecret)
            ?: syncPreferences.getString("refresh_token", "").orEmpty(),
        accessTokenExpiresAtEpochMillis = syncPreferences.getLong("access_expires_at", 0),
        deviceId = deviceId,
    )
    private fun persistSyncConfig(config: CloudSyncConfig) {
        check(
            syncPreferences.edit()
                .putString("endpoint", config.endpoint.trim())
                .putString("tenant", config.tenantId.trim())
                .putBoolean("enabled", config.enabled)
                .putString("access_token_protected", keyProvider.protectSecret(config.accessToken))
                .putString("refresh_token_protected", keyProvider.protectSecret(config.refreshToken))
                .remove("access_token")
                .remove("refresh_token")
                .putLong("access_expires_at", config.accessTokenExpiresAtEpochMillis)
                .commit(),
        )
    }
    suspend fun saveSyncConfig(config: CloudSyncConfig) { authorizer.require("BACKUP"); val normalized=config.copy(deviceId=deviceId); if(normalized.enabled) normalized.validated(); persistSyncConfig(normalized) }
    suspend fun runSync(): ir.sabou.inventory.data.repository.SyncRunResult { var config=syncConfig(); if(config.enabled && config.accessTokenExpired){config=ir.sabou.inventory.data.repository.SyncTokenRefresher().refresh(config);persistSyncConfig(config)}; return SyncCoordinator(syncRepository,HttpsSyncTransport(config)).runOnce() }
    suspend fun runSyncAuthorized() = authorizer.require("BACKUP").let { runSync() }
    suspend fun resolveSyncIssueAuthorized(changeId:String,keepLocal:Boolean){authorizer.require("BACKUP");syncRepository.resolveIssue(changeId,keepLocal)}
    private val deviceId: String by lazy {
        val preferences = context.getSharedPreferences("sync_identity", Context.MODE_PRIVATE)
        preferences.getString("device_id", null) ?: UUID.randomUUID().toString().also { generated ->
            check(preferences.edit().putString("device_id", generated).commit()) { "ذخیره شناسه دستگاه انجام نشد." }
        }
    }
    val syncRecorder by lazy { SyncRecorder(database, deviceId) }
    val assetRepository: AssetRepository by lazy { LocalAssetRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val alertRepository: AlertRepository by lazy { LocalAlertRepository(database) }
    val managementControlRepository: ManagementControlRepository by lazy {
        LocalManagementControlRepository(database, procurementRepository, authorizer, syncRecorder = syncRecorder)
    }

    suspend fun createBackup(): String {
        authorizer.require("BACKUP")
        return withContext(Dispatchers.IO) {
            backupManager.create(database).also { backupManager.prune(BackupPolicyStore(appContext).load().maxFiles) }
        }
    }
    internal suspend fun createAutomaticBackup(maxFiles: Int): String = withContext(Dispatchers.IO) {
        backupManager.create(database).also { backupManager.prune(maxFiles) }
    }
    suspend fun factoryReset() {
        authorizer.require("MANAGE_USERS")
        withContext(Dispatchers.IO) {
            database.clearAllTables()
            AccountSeedCallback.seedMissingAccounts(database.openHelper.writableDatabase)
            backupManager.clearAll()
            listOf("cloud_sync", "sync_identity", "automatic_backup_policy").forEach { name ->
                check(appContext.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit()) {
                    "پاک‌سازی تنظیمات $name انجام نشد."
                }
            }
        }
    }
    suspend fun listBackups(): List<String> {
        authorizer.require("BACKUP")
        return withContext(Dispatchers.IO) { backupManager.list() }
    }
    suspend fun deleteBackup(name: String) {
        authorizer.require("BACKUP")
        withContext(Dispatchers.IO) { backupManager.delete(name) }
    }
    suspend fun scheduleRestore(name: String) {
        authorizer.require("BACKUP")
        withContext(Dispatchers.IO) { backupManager.scheduleRestore(name) }
    }
    suspend fun exportBackup(name: String, password: CharArray, destination: Uri) {
        authorizer.require("BACKUP")
        withContext(Dispatchers.IO) {
            val output = requireNotNull(appContext.contentResolver.openOutputStream(destination, "w")) {
                "امکان نوشتن فایل مقصد وجود ندارد."
            }
            output.use { backupManager.exportPortable(name, password, it) }
        }
    }
    suspend fun importBackup(source: Uri, password: CharArray): String {
        authorizer.require("BACKUP")
        return withContext(Dispatchers.IO) {
            val input = requireNotNull(appContext.contentResolver.openInputStream(source)) {
                "امکان خواندن فایل انتخاب‌شده وجود ندارد."
            }
            backupManager.importPortable(input, password).also { backupManager.prune(BackupPolicyStore(appContext).load().maxFiles) }
        }
    }

    val accountingRepository: AccountingRepository by lazy {
        LocalAccountingRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }
}
