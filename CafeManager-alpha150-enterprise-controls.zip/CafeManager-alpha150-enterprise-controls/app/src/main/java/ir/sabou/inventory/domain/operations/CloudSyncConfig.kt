package ir.sabou.inventory.domain.operations

data class CloudSyncConfig(val endpoint: String, val tenantId: String, val enabled: Boolean = false, val accessToken: String = "", val refreshToken: String = "", val accessTokenExpiresAtEpochMillis: Long = 0, val deviceId: String = "") {
    val accessTokenExpired: Boolean get() = accessTokenExpiresAtEpochMillis <= System.currentTimeMillis() + 30_000L
    fun validated(): CloudSyncConfig { require(endpoint.startsWith("https://")); require(tenantId.isNotBlank()); require(deviceId.isNotBlank()); require(accessToken.isNotBlank() && !accessTokenExpired) { "توکن دسترسی Sync معتبر یا فعال نیست." }; return this }
}
