package ir.sabou.inventory.domain.operations

data class SyncMetrics(val uploaded: Int, val conflicts: Int, val rejected: Int, val durationMillis: Long) {
    val successRatePercent: Long get() = if (uploaded + conflicts + rejected == 0) 100 else uploaded.toLong() * 100 / (uploaded + conflicts + rejected)
}

object SyncMetricsCalculator {
    fun from(result: SyncUploadResult, durationMillis: Long): SyncMetrics {
        require(durationMillis >= 0) { "مدت همگام‌سازی نامعتبر است." }
        return SyncMetrics(result.accepted.size, result.conflicts.size, result.rejected.size, durationMillis)
    }
}
