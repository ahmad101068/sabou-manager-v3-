package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.data.repository.LocalSyncRepository
import ir.sabou.inventory.domain.operations.SyncHealth
import ir.sabou.inventory.domain.operations.SyncStatusCalculator
import ir.sabou.inventory.domain.operations.SyncStatusSummary
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class SyncUiState(val summary: SyncStatusSummary = SyncStatusSummary(0, 0, 0, 0, null, SyncHealth.HEALTHY))

class SyncViewModel(repository: LocalSyncRepository) : ViewModel() {
    val state: StateFlow<SyncUiState> = repository.changes.map { SyncUiState(SyncStatusCalculator.summarize(it)) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SyncUiState())

    companion object {
        fun factory(repository: LocalSyncRepository) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = SyncViewModel(repository) as T
        }
    }
}
