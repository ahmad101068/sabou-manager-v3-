package ir.sabou.inventory.domain.operations

class OperationGuard(private val role: UserRole) {
    fun require(permission: Permission) {
        check(AccessPolicy.allows(role, permission)) { "دسترسی نقش ${role.name} برای این عملیات مجاز نیست." }
    }
}
