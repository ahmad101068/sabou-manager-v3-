package ir.sabou.inventory.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "sync_changes", indices = [Index(value = ["changeId"], unique = true), Index("state"), Index("occurredAtEpochMillis")])
data class SyncChangeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val changeId: String,
    val entityType: String,
    val entityId: Long,
    val changeType: String,
    val deviceId: String,
    val occurredAtEpochMillis: Long,
    val payloadHash: String,
    val state: String = "PENDING",
    val lastError: String = "",
)
