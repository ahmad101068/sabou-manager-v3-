package ir.sabou.inventory.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowOutward
import androidx.compose.material.icons.outlined.ColorLens
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

enum class ThemePreference(val title: String, val description: String) {
    SYSTEM("مطابق گوشی", "حالت روشن یا تیره را از تنظیمات دستگاه بگیر"),
    LIGHT("روشن", "پس‌زمینه روشن برای محیط‌های پرنور"),
    DARK("تیره", "نمای تیره برای استفاده شبانه"),
}

internal data class NavigationDestination(
    val title: String,
    val subtitle: String,
    val keywords: String,
    val screen: AppScreen,
)

internal val navigationDestinations = listOf(
    NavigationDestination("خرید و فاکتورها", "ثبت، جست‌وجو و تسویه خرید", "خرید فاکتور تامین کننده پرداخت", AppScreen.PURCHASES),
    NavigationDestination("ثبت خرید جدید", "ایجاد فاکتور خرید", "خرید جدید فاکتور", AppScreen.NEW_PURCHASE),
    NavigationDestination("تأمین‌کنندگان", "مدیریت فروشندگان و مانده‌ها", "تامین کننده فروشنده", AppScreen.SUPPLIERS),
    NavigationDestination("انبار", "کالا، موجودی و انبارگردانی", "انبار کالا موجودی شمارش", AppScreen.INVENTORY),
    NavigationDestination("فروش", "فاکتور فروش و دریافت‌ها", "فروش مشتری فاکتور دریافت", AppScreen.SALES),
    NavigationDestination("تولید و رسپی", "محصول و مواد اولیه", "رسپی تولید محصول مواد اولیه", AppScreen.RECIPES),
    NavigationDestination("حسابداری", "اسناد، حساب‌ها و گزارش‌های مالی", "حسابداری سند حساب دفتر تراز سود", AppScreen.ACCOUNTING),
    NavigationDestination("ثبت سند جدید", "سند دستی حسابداری", "سند جدید حسابداری", AppScreen.NEW_JOURNAL),
    NavigationDestination("CRM", "باشگاه مشتریان و پیگیری", "مشتری امتیاز پیگیری باشگاه", AppScreen.CRM),
    NavigationDestination("پرسنل و حقوق", "کارکنان و پرداخت حقوق", "پرسنل کارمند حقوق", AppScreen.PERSONNEL),
    NavigationDestination("دارایی‌های ثابت", "اموال و استهلاک", "دارایی اموال استهلاک", AppScreen.ASSETS),
    NavigationDestination("مرکز هشدارها", "هشدارهای عملیاتی و مالی", "هشدار سررسید موجودی", AppScreen.ALERTS),
    NavigationDestination("گزارش‌های مدیریتی", "شاخص‌های کلیدی کسب‌وکار", "گزارش فروش سود موجودی", AppScreen.REPORTS),
    NavigationDestination("لاگ عملیات", "ردیابی تغییرات و حسابرسی", "لاگ حسابرسی عملیات", AppScreen.AUDIT_LOG),
    NavigationDestination("کاربران و پشتیبان", "امنیت، کاربران و نسخه پشتیبان", "کاربر امنیت بکاپ پشتیبان", AppScreen.SECURITY),
    NavigationDestination("تنظیمات برنامه", "ظاهر و تجربه کاربری", "تنظیمات ظاهر تم", AppScreen.SETTINGS),
)

@Composable
internal fun GlobalSearchScreen(
    currentUser: ir.sabou.inventory.domain.operations.AppUserRecord?,
    onOpen: (AppScreen) -> Unit,
    onBack: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val allowed = navigationDestinations.filter { destination ->
        if (currentUser == null) return@filter true
        when (destination.screen) {
            AppScreen.PURCHASES, AppScreen.NEW_PURCHASE -> currentUser?.role?.allows("PURCHASES") == true
            AppScreen.SUPPLIERS -> currentUser?.role?.allows("SUPPLIERS") == true
            AppScreen.INVENTORY -> currentUser?.role?.allows("INVENTORY") == true
            AppScreen.SALES, AppScreen.CRM -> currentUser?.role?.allows("SALES") == true
            AppScreen.RECIPES -> currentUser?.role?.allows("RECIPES") == true
            AppScreen.ACCOUNTING, AppScreen.NEW_JOURNAL, AppScreen.REPORTS -> currentUser?.role?.allows("ACCOUNTING") == true
            AppScreen.PERSONNEL -> currentUser?.role?.allows("PERSONNEL") == true
            AppScreen.ASSETS -> currentUser?.role?.allows("ASSETS") == true
            AppScreen.AUDIT_LOG -> currentUser?.role?.allows("AUDIT") == true
            AppScreen.SECURITY -> currentUser?.role?.allows("BACKUP") == true
            else -> true
        }
    }
    val normalized = query.trim()
    val results = if (normalized.isBlank()) allowed else allowed.filter {
        it.title.contains(normalized, ignoreCase = true) ||
            it.subtitle.contains(normalized, ignoreCase = true) ||
            it.keywords.contains(normalized, ignoreCase = true)
    }

    Scaffold(topBar = { ProfessionalTopBar("جست‌وجوی سراسری", "دسترسی سریع به همه بخش‌های مجاز", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نام بخش یا عملیات") },
                    placeholder = { Text("مثلاً انبار، حقوق یا سند") },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                )
            }
            item {
                Text(
                    if (query.isBlank()) "همه میان‌برها" else "${results.size} نتیجه",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (results.isEmpty()) {
                item { EmptyStatePanel("نتیجه‌ای پیدا نشد", "عبارت کوتاه‌تری وارد کنید یا نام بخش را تغییر دهید.") }
            } else {
                items(results) { destination ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(destination.screen) },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                androidx.compose.material3.Icon(
                                    Icons.Outlined.ArrowOutward,
                                    contentDescription = null,
                                    modifier = Modifier.padding(10.dp).size(20.dp),
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(destination.title, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(destination.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
internal fun SettingsScreen(
    themePreference: ThemePreference,
    syncState: SyncUiState,
    onThemePreferenceChange: (ThemePreference) -> Unit,
    onOpenSecurity: () -> Unit,
    onBack: () -> Unit,
) {
    Scaffold(topBar = { ProfessionalTopBar("تنظیمات برنامه", "ظاهر، امنیت و اطلاعات نسخه", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                BrandStatementCard(
                    title = "هویت سابو",
                    description = "گرمای مهمان‌نوازی در کنار دقت مدیریت؛ مرجانی برای اقدام، سبز برای اطمینان و زعفرانی برای توجه.",
                )
            }
            item {
                FormSection("ظاهر برنامه", "انتخاب شما بلافاصله اعمال و روی دستگاه ذخیره می‌شود") {
                    ThemePreference.entries.forEach { preference ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onThemePreferenceChange(preference) },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (themePreference == preference) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            ),
                            border = BorderStroke(1.dp, if (themePreference == preference) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(preference.title, fontWeight = FontWeight.Bold)
                                    Text(preference.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (themePreference == preference) "●" else "○", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }
            item {
                SyncHealthPanel(syncState)
            }
            item {
                FormSection("امنیت و داده‌ها", "مدیریت کاربران، پشتیبان‌گیری و بازیابی") {
                    TextButton(onClick = onOpenSecurity, modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.Icon(Icons.Outlined.Security, null, modifier = Modifier.size(20.dp))
                        Text("باز کردن کاربران و پشتیبان", modifier = Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                FormSection("درباره برنامه") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("نسخه")
                        Text("3.0.0-alpha45-brand-identity", fontWeight = FontWeight.Bold)
                    }
                    Text("Sabou Manager v3", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    Text("مدیریت یکپارچه خرید، فروش، انبار، حسابداری و عملیات مجموعه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun SyncHealthPanel(state: SyncUiState) {
    val summary = state.summary
    val (title, color) = when (summary.health) {
        ir.sabou.inventory.domain.operations.SyncHealth.HEALTHY -> "همگام‌سازی سالم" to MaterialTheme.colorScheme.primary
        ir.sabou.inventory.domain.operations.SyncHealth.PENDING_WORK -> "تغییر در انتظار همگام‌سازی" to MaterialTheme.colorScheme.secondary
        ir.sabou.inventory.domain.operations.SyncHealth.NEEDS_ATTENTION -> "نیازمند بررسی تعارض" to MaterialTheme.colorScheme.error
    }
    FormSection("وضعیت همگام‌سازی", "پایش صف تغییرات آفلاین دستگاه") {
        StatusPill(title, containerColor = color.copy(alpha = .14f), contentColor = color)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CompactInfoRow("کل تغییرات", summary.total.toString())
            CompactInfoRow("در انتظار", summary.pending.toString())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CompactInfoRow("همگام‌شده", summary.synced.toString())
            CompactInfoRow("تعارض", summary.conflicts.toString())
        }
    }
}
