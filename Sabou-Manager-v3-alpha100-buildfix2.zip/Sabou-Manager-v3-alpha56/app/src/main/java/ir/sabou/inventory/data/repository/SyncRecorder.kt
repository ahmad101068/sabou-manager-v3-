package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.SyncChangeEntity
import ir.sabou.inventory.domain.operations.SyncChangeType
import java.util.UUID

/** Records local mutations in the durable outbox in the same Room transaction. */
class SyncRecorder(private val database: AppDatabase, private val deviceId: String = "local") {
    suspend fun record(entityType: String, entityId: Long, changeType: String, occurredAt: Long) {
        val normalizedType = runCatching { SyncChangeType.valueOf(changeType) }
            .getOrElse { error("نوع تغییر همگام‌سازی پشتیبانی نمی‌شود: $changeType") }
        // Timestamp alone is not unique when two mutations happen in one millisecond.
        val changeId = "$deviceId:$entityType:$entityId:$occurredAt:${UUID.randomUUID()}"
        database.syncDao().insert(
            SyncChangeEntity(
                changeId = changeId,
                entityType = entityType,
                entityId = entityId,
                changeType = normalizedType.name,
                deviceId = deviceId,
                occurredAtEpochMillis = occurredAt,
                payloadHash = "local-${entityType.lowercase()}-$entityId",
            ),
        )
    }
}
