package ir.sabou.inventory.domain.operations

data class RestaurantKpi(val salesRial: Long, val costRial: Long, val grossProfitRial: Long, val marginPercent: Long, val invoiceCount: Int)

object RestaurantKpiCalculator {
    fun calculate(salesRial: Long, costRial: Long, invoiceCount: Int): RestaurantKpi {
        require(salesRial >= 0 && costRial >= 0 && invoiceCount >= 0)
        val profit = salesRial - costRial
        return RestaurantKpi(salesRial, costRial, profit, if (salesRial == 0L) 0 else profit * 100 / salesRial, invoiceCount)
    }
}
