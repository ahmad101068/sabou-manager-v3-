package ir.sabou.inventory.data

import android.content.Context
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.repository.DashboardRepository
import ir.sabou.inventory.data.repository.LocalAccountingRepository
import ir.sabou.inventory.data.repository.LocalOperationsRepository
import ir.sabou.inventory.data.repository.LocalPurchaseRepository
import ir.sabou.inventory.data.repository.LocalPersonnelRepository
import ir.sabou.inventory.data.repository.LocalPerformanceRepository
import ir.sabou.inventory.data.repository.LocalSyncRepository
import ir.sabou.inventory.data.repository.SyncRecorder
import ir.sabou.inventory.data.repository.LocalSalesRepository
import ir.sabou.inventory.data.repository.LocalSecurityRepository
import ir.sabou.inventory.data.repository.LocalAssetRepository
import ir.sabou.inventory.data.repository.LocalRecipeRepository
import ir.sabou.inventory.data.repository.LocalCrmRepository
import ir.sabou.inventory.data.repository.LocalAlertRepository
import ir.sabou.inventory.data.security.DatabaseKeyProvider
import ir.sabou.inventory.domain.accounting.AccountingRepository
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.purchase.PurchaseRepository
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import ir.sabou.inventory.domain.sales.SalesRepository
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.recipe.RecipeRepository
import ir.sabou.inventory.domain.assets.AssetRepository
import ir.sabou.inventory.domain.crm.CrmRepository
import ir.sabou.inventory.domain.operations.AlertRepository

class AppContainer(context: Context) {
    val backupManager = BackupManager(context).also { it.applyPendingRestore() }
    private val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        AppDatabase.create(context, DatabaseKeyProvider(context))
    }

    val purchaseRepository: PurchaseRepository by lazy {
        LocalPurchaseRepository(database, syncRecorder = syncRecorder)
    }

    val salesRepository: SalesRepository by lazy {
        LocalSalesRepository(database, syncRecorder = syncRecorder)
    }

    val recipeRepository: RecipeRepository by lazy { LocalRecipeRepository(database) }

    val dashboardRepository: DashboardRepository by lazy {
        DashboardRepository(database)
    }

    val operationsRepository: OperationsRepository by lazy {
        LocalOperationsRepository(database, syncRecorder = syncRecorder)
    }

    val securityRepository: SecurityRepository by lazy { LocalSecurityRepository(database) }

    val personnelRepository: PersonnelRepository by lazy { LocalPersonnelRepository(database) }
    val performanceRepository by lazy { LocalPerformanceRepository(database) }
    val syncRepository by lazy { LocalSyncRepository(database) }
    val syncRecorder by lazy { SyncRecorder(database) }
    val assetRepository: AssetRepository by lazy { LocalAssetRepository(database) }
    val crmRepository: CrmRepository by lazy { LocalCrmRepository(database) }
    val alertRepository: AlertRepository by lazy { LocalAlertRepository(database) }

    fun createBackup(): String = backupManager.create(database)
    fun listBackups(): List<String> = backupManager.list()
    fun scheduleRestore(name: String) = backupManager.scheduleRestore(name)

    val accountingRepository: AccountingRepository by lazy {
        LocalAccountingRepository(database)
    }
}
