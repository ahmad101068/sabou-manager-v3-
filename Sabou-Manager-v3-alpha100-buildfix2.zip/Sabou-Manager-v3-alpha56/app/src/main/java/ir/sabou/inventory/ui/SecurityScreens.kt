@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole

@Composable
fun SecurityScreen(
    state: SecurityUiState,
    onSave: (Long?, UserDraft, () -> Unit) -> Unit,
    onDeactivate: (Long) -> Unit,
    onSwitch: (Long, String, () -> Unit) -> Unit,
    onBackup: () -> Unit,
    onRestore: (String) -> Unit,
    onBack: () -> Unit,
) {
    var showNew by remember { mutableStateOf(false) }
    var switchId by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = "امنیت و پشتیبان‌گیری",
                subtitle = "کاربران، سطح دسترسی و نسخه‌های امن اطلاعات",
                onBack = onBack,
                actionLabel = "کاربر جدید",
                onAction = { showNew = true },
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                CurrentUserPanel(state)
            }
            state.message?.let { message ->
                item { MessageCard(message, isError = false) }
            }
            item { SectionHeading("کاربران", "ورود و دسترسی هر نقش را از این بخش مدیریت کنید.") }
            if (state.users.isEmpty()) {
                item { EmptyStatePanel("کاربری ثبت نشده", "برای شروع، یک کاربر جدید بسازید.") }
            } else {
                items(state.users, key = { it.id }) { user ->
                    Card(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(user.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                    Text("@${user.username}", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                StatusPill(if (user.isActive) user.role.title else "غیرفعال")
                            }
                            Text(
                                roleDescription(user.role),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                            ) {
                                if (user.isActive) {
                                    OutlinedButton(
                                        modifier = Modifier.weight(1f),
                                        onClick = { switchId = user.id },
                                        enabled = !state.busy && state.currentUser?.id != user.id,
                                    ) { Text(if (state.currentUser?.id == user.id) "کاربر فعال" else "ورود با این کاربر") }
                                }
                                if (user.role != UserRole.OWNER && user.isActive) {
                                    TextButton(
                                        onClick = { onDeactivate(user.id) },
                                        enabled = !state.busy,
                                    ) { Text("غیرفعال‌کردن", color = MaterialTheme.colorScheme.error) }
                                }
                            }
                        }
                    }
                }
            }
            item { HorizontalDivider() }
            item { SectionHeading("پشتیبان‌گیری محلی", "نسخه رمزگذاری‌شده بسازید و در صورت نیاز بازیابی کنید.") }
            item {
                Button(
                    onClick = onBackup,
                    enabled = !state.busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text(if (state.busy) "در حال انجام…" else "ساخت نسخه پشتیبان رمزگذاری‌شده") }
            }
            if (state.backups.isEmpty()) {
                item { EmptyStatePanel("نسخه پشتیبان ندارید", "پس از ساخت، فایل‌های پشتیبان در این قسمت نمایش داده می‌شوند.") }
            } else {
                items(state.backups, key = { it }) { name ->
                    Surface(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            OutlinedButton(
                                onClick = { onRestore(name) },
                                enabled = !state.busy,
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("بازیابی این نسخه") }
                        }
                    }
                }
            }
        }
    }

    if (showNew) {
        UserEditorDialog(
            busy = state.busy,
            onDismiss = { showNew = false },
            onSave = { draft -> onSave(null, draft) { showNew = false } },
        )
    }
    switchId?.let { id ->
        PinDialog(
            busy = state.busy,
            onDismiss = { switchId = null },
            onConfirm = { pin -> onSwitch(id, pin) { switchId = null } },
        )
    }
}

@Composable
private fun CurrentUserPanel(state: SecurityUiState) {
    Card(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("نشست فعال", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(
                state.currentUser?.displayName ?: "کاربر مشخص نیست",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
                state.currentUser?.let { "${it.role.title} · @${it.username}" } ?: "برای ادامه یک کاربر را انتخاب کنید.",
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .78f),
            )
        }
    }
}

@Composable
private fun UserEditorDialog(
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (UserDraft) -> Unit,
) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var role by remember { mutableStateOf(UserRole.CASHIER) }
    var expanded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ساخت کاربر جدید") },
        text = {
            Column(
                Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                error?.let { MessageCard(it, isError = true) }
                OutlinedTextField(username, { username = it.trimStart() }, label = { Text("نام کاربری") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(name, { name = it }, label = { Text("نام نمایشی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(8) },
                    label = { Text("رمز عددی ۴ تا ۸ رقم") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text("نقش: ${role.title}") }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    UserRole.entries.forEach { item ->
                        DropdownMenuItem(text = { Text(item.title) }, onClick = { role = item; expanded = false })
                    }
                }
                Text(roleDescription(role), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    val normalizedUsername = username.trim()
                    val normalizedName = name.trim()
                    when {
                        normalizedUsername.length < 3 -> error = "نام کاربری باید حداقل ۳ نویسه باشد."
                        normalizedName.length < 2 -> error = "نام نمایشی معتبر نیست."
                        pin.length !in 4..8 -> error = "رمز عددی باید بین ۴ تا ۸ رقم باشد."
                        else -> onSave(UserDraft(normalizedUsername, normalizedName, pin, role))
                    }
                },
            ) { Text("ذخیره کاربر") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun PinDialog(busy: Boolean, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ورود با کاربر انتخاب‌شده") },
        text = {
            OutlinedTextField(
                value = pin,
                onValueChange = { pin = it.filter(Char::isDigit).take(8) },
                label = { Text("رمز عددی") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            Button(onClick = { onConfirm(pin) }, enabled = !busy && pin.isNotBlank()) { Text("ورود") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

private fun roleDescription(role: UserRole): String = when (role) {
    UserRole.OWNER -> "دسترسی کامل به تمام بخش‌ها و تنظیمات برنامه"
    UserRole.MANAGER -> "مدیریت عملیات، گزارش‌ها، حسابداری و منابع انسانی"
    UserRole.CASHIER -> "ثبت فروش و مشاهده گزارش‌های مرتبط"
    UserRole.KITCHEN -> "دسترسی به عملیات آشپزخانه"
    UserRole.INVENTORY -> "مشاهده و مدیریت موجودی انبار"
    UserRole.STOREKEEPER -> "مدیریت خرید، تأمین‌کننده، انبار و رسپی‌ها"
    UserRole.ACCOUNTANT -> "حسابداری، گزارش‌ها، اسناد، پرسنل و دارایی‌ها"
}
