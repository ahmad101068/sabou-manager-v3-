package ir.sabou.inventory.data.repository

import ir.sabou.inventory.domain.operations.SyncTransport

data class SyncRunResult(val uploaded: Int, val conflicts: Int, val rejected: Int)

class SyncCoordinator(
    private val repository: LocalSyncRepository,
    private val transport: SyncTransport,
) {
    suspend fun runOnce(limit: Int = 50): SyncRunResult {
        val batch = repository.nextBatch(limit)
        if (batch.changes.isEmpty()) return SyncRunResult(0, 0, 0)
        val result = transport.upload(batch.changes)
        result.accepted.forEach { repository.markSynced(it) }
        result.conflicts.forEach { repository.markConflict(it, "تعارض در سرویس همگام‌سازی") }
        return SyncRunResult(result.accepted.size, result.conflicts.size, result.rejected.size)
    }
}
