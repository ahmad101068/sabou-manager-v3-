package ir.sabou.inventory.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncDao {
    @Query("SELECT * FROM sync_changes ORDER BY occurredAtEpochMillis, id")
    fun observeAll(): Flow<List<SyncChangeEntity>>

    @Query("SELECT * FROM sync_changes WHERE state = 'PENDING' ORDER BY occurredAtEpochMillis, id LIMIT :limit")
    suspend fun pending(limit: Int): List<SyncChangeEntity>

    @Insert
    suspend fun insert(change: SyncChangeEntity): Long

    @Update
    suspend fun update(change: SyncChangeEntity): Int

    @Query("SELECT * FROM sync_changes WHERE changeId = :changeId LIMIT 1")
    suspend fun byChangeId(changeId: String): SyncChangeEntity?

    @Query("DELETE FROM sync_changes WHERE state = 'SYNCED' AND occurredAtEpochMillis < :beforeMillis")
    suspend fun deleteSyncedBefore(beforeMillis: Long): Int
}
