package ir.sabou.inventory.domain.operations

import org.junit.Assert.assertEquals
import org.junit.Test

class SyncStatusCalculatorTest {
    @Test fun conflictsTakePriorityOverPending() {
        val base = SyncEnvelope("a", "sale", 1, SyncChangeType.UPDATE, "phone", 10, "12345678")
        val result = SyncStatusCalculator.summarize(listOf(base, base.copy(changeId = "b", state = SyncState.CONFLICT, occurredAtEpochMillis = 20)))
        assertEquals(SyncHealth.NEEDS_ATTENTION, result.health)
        assertEquals(20, result.lastChangeEpochMillis)
    }
}
