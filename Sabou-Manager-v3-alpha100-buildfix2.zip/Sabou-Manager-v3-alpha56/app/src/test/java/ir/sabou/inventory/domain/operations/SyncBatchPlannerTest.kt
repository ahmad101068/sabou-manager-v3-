package ir.sabou.inventory.domain.operations

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class SyncBatchPlannerTest {
    @Test fun ordersByTimeAndLimitsBatch() {
        val a = SyncEnvelope("b", "SALE", 2, "CREATE", "d", 20, "payload-b")
        val b = SyncEnvelope("a", "SALE", 1, "CREATE", "d", 10, "payload-a")
        val batch = SyncBatchPlanner.plan(listOf(a, b), 1)
        assertEquals("a", batch.changes.single().changeId)
        assertTrue(batch.hasMore)
    }
}
