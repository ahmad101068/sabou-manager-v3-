package ir.sabou.inventory.domain.operations

import kotlin.test.Test
import kotlin.test.assertFailsWith

class OperationGuardTest {
    @Test fun cashierCannotManageInventory() = assertFailsWith<IllegalStateException> {
        OperationGuard(UserRole.CASHIER).require(Permission.MANAGE_INVENTORY)
    }
}
