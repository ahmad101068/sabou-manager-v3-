package ir.sabou.inventory.domain.operations

import kotlin.test.Test
import kotlin.test.assertEquals

class SyncMetricsTest {
    @Test fun calculatesSuccessRate() {
        val m = SyncMetricsCalculator.from(SyncUploadResult(listOf("a", "b"), listOf("c"), emptyList()), 120)
        assertEquals(66, m.successRatePercent)
    }
}
