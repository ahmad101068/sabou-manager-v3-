package ir.sabou.inventory.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val SabouLightColors = lightColorScheme(
    primary = Color(0xFFE64B5D),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE1E5),
    onPrimaryContainer = Color(0xFF5B1020),
    secondary = Color(0xFF735A63),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF6DDE5),
    onSecondaryContainer = Color(0xFF2B151C),
    tertiary = Color(0xFF4F6357),
    tertiaryContainer = Color(0xFFD2E8DA),
    background = Color(0xFFFAF8F8),
    onBackground = Color(0xFF211A1C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF211A1C),
    surfaceVariant = Color(0xFFF1EDEF),
    onSurfaceVariant = Color(0xFF6F6367),
    outline = Color(0xFF9B8B90),
    outlineVariant = Color(0xFFE4DDE0),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
)

private val SabouDarkColors = darkColorScheme(
    primary = Color(0xFFFFB2BC),
    onPrimary = Color(0xFF68002A),
    primaryContainer = Color(0xFF8E173E),
    onPrimaryContainer = Color(0xFFFFD9DE),
    secondary = Color(0xFFE4BDC7),
    onSecondary = Color(0xFF422932),
    secondaryContainer = Color(0xFF5B3F48),
    onSecondaryContainer = Color(0xFFFFD9E2),
    tertiary = Color(0xFFB6CCBD),
    tertiaryContainer = Color(0xFF374B3F),
    background = Color(0xFF171214),
    onBackground = Color(0xFFEDE0E3),
    surface = Color(0xFF211A1C),
    onSurface = Color(0xFFEDE0E3),
    surfaceVariant = Color(0xFF514347),
    onSurfaceVariant = Color(0xFFD7C2C7),
    outlineVariant = Color(0xFF514347),
)

private val SabouTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 38.sp, fontWeight = FontWeight.Black, letterSpacing = (-0.25).sp),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 30.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 27.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun SabouTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) SabouDarkColors else SabouLightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.background.toArgb()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.navigationBarColor = colors.surface.toArgb()
            }
        }
    }
    MaterialTheme(colorScheme = colors, typography = SabouTypography, content = content)
}
