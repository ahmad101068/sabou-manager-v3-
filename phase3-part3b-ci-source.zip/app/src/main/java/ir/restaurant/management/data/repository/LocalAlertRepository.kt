package ir.restaurant.management.data.repository

import androidx.room.withTransaction
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.GeneratedAlertRow
import ir.restaurant.management.domain.crm.ReceivableAgingCalculator
import ir.restaurant.management.domain.crm.ReceivableLedgerRecord
import ir.restaurant.management.domain.operations.AlertRepository

class LocalAlertRepository(private val db: AppDatabase) : AlertRepository {
    override fun alerts() = db.alertDao().observeVisible()

    override suspend fun refresh(todayEpochDay: Long) = db.withTransaction {
        require(todayEpochDay > 0)
        val now = System.currentTimeMillis()
        val horizon = todayEpochDay + 30
        val activeKeys = mutableSetOf<Pair<String, Long>>()

        suspend fun upsert(sourceType: String, rows: List<GeneratedAlertRow>) {
            rows.forEach { row ->
                activeKeys += sourceType to row.sourceId
                val updated = db.alertDao().updateGenerated(
                    sourceType = sourceType,
                    sourceId = row.sourceId,
                    title = row.title,
                    message = row.message,
                    severity = row.severity,
                    dueEpochDay = row.dueEpochDay,
                    now = now,
                )
                if (updated == 0) {
                    db.alertDao().insertGeneratedIfAbsent(
                        sourceType = sourceType,
                        sourceId = row.sourceId,
                        title = row.title,
                        message = row.message,
                        severity = row.severity,
                        dueEpochDay = row.dueEpochDay,
                        now = now,
                    )
                }
            }
        }

        upsert("PURCHASE_PAYABLE", db.alertDao().overduePurchases(todayEpochDay))
        upsert("LOW_STOCK", db.alertDao().lowStock())
        upsert("LOT_EXPIRING", db.alertDao().expiringLots(todayEpochDay, horizon))
        upsert("LOT_EXPIRED", db.alertDao().expiredLots(todayEpochDay))
        upsert("CUSTOMER_RECEIVABLE", overdueReceivables(todayEpochDay))
        upsert("CONTRACT_EXPIRY", db.alertDao().expiringContracts(todayEpochDay, horizon))
        upsert("UNPAID_PAYROLL", db.alertDao().unpaidPayroll())
        upsert("ASSET_MAINTENANCE", db.alertDao().dueAssetMaintenance(todayEpochDay, horizon))
        upsert("ATTENDANCE_ANOMALY", db.alertDao().attendanceAnomalies())
        upsert("PURCHASE_DELIVERY_OVERDUE", db.alertDao().overdueDeliveries(todayEpochDay))
        upsert("INVENTORY_DISCREPANCY", db.alertDao().inventoryDiscrepancies())

        db.alertDao().generatedKeys().forEach { key ->
            if ((key.sourceType to key.sourceId) !in activeKeys) {
                db.alertDao().resolveGenerated(key.sourceType, key.sourceId, now)
            }
        }
    }


    private suspend fun overdueReceivables(todayEpochDay: Long): List<GeneratedAlertRow> =
        db.alertDao().overdueReceivableCandidates(todayEpochDay).mapNotNull { candidate ->
            val ledger = db.customerReceivableDao().ledger(candidate.customerId).map { row ->
                ReceivableLedgerRecord(
                    row.id, row.customerId, row.businessEpochDay, row.entryType, row.debitRial, row.creditRial,
                    row.sourceType, row.sourceId, row.reference, row.dueEpochDay,
                )
            }
            val aging = ReceivableAgingCalculator.calculate(ledger, todayEpochDay)
            val overdue = Math.addExact(
                Math.addExact(aging.days1To30Rial, aging.days31To60Rial),
                Math.addExact(aging.days61To90Rial, aging.over90Rial),
            )
            overdue.takeIf { it > 0L }?.let { amount ->
                GeneratedAlertRow(
                    sourceId = candidate.customerId,
                    title = "مطالبه سررسیدشده مشتری",
                    message = "${candidate.customerName} · مانده سررسیدشده $amount ریال",
                    severity = "HIGH",
                    dueEpochDay = candidate.oldestDueEpochDay,
                )
            }
        }

    override suspend fun markRead(id: Long) {
        require(db.alertDao().markRead(id, System.currentTimeMillis()) == 1) { "هشدار پیدا نشد." }
    }

    override suspend fun markActioned(id: Long) {
        require(db.alertDao().markActioned(id, System.currentTimeMillis()) == 1) { "هشدار قابل اقدام پیدا نشد." }
    }

    override suspend fun resolve(id: Long) {
        require(db.alertDao().resolve(id, System.currentTimeMillis()) == 1) { "هشدار قابل حل پیدا نشد." }
    }

    override suspend fun dismiss(id: Long) {
        require(db.alertDao().dismiss(id, System.currentTimeMillis()) == 1) { "هشدار پیدا نشد." }
    }

    override suspend fun clearDismissed() {
        db.alertDao().clearDismissed()
    }
}
