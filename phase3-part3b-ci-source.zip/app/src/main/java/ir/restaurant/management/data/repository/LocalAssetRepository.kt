package ir.restaurant.management.data.repository

import ir.restaurant.management.domain.security.Permission
import ir.restaurant.management.domain.common.DocumentNumberType

import androidx.room.withTransaction
import ir.restaurant.management.core.currentLocalEpochDay
import ir.restaurant.management.core.SignedLongMath
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.AssetDepreciationEntity
import ir.restaurant.management.data.db.AssetLifecycleEventEntity
import ir.restaurant.management.data.db.AssetMaintenanceEntity
import ir.restaurant.management.data.db.FixedAssetEntity
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.domain.assets.AssetDraft
import ir.restaurant.management.domain.assets.AssetImpairmentDraft
import ir.restaurant.management.domain.assets.AssetLifecycleRecord
import ir.restaurant.management.domain.assets.AssetLifecycleType
import ir.restaurant.management.domain.assets.AssetMaintenanceDraft
import ir.restaurant.management.domain.assets.AssetMaintenanceRecord
import ir.restaurant.management.domain.assets.AssetSaleDraft
import ir.restaurant.management.domain.assets.AssetTransferDraft
import ir.restaurant.management.domain.assets.AssetAcquisitionSource
import ir.restaurant.management.domain.assets.AssetRecord
import ir.restaurant.management.domain.assets.AssetRepository
import ir.restaurant.management.domain.assets.DepreciationDraft
import ir.restaurant.management.domain.assets.DepreciationRecord
import ir.restaurant.management.domain.accounting.SemanticAccountRole
import ir.restaurant.management.domain.accounting.AccountingPostingContext
import ir.restaurant.management.domain.accounting.AccountingScope
import ir.restaurant.management.domain.accounting.SemanticJournalDraft
import ir.restaurant.management.domain.accounting.SemanticJournalLine
import ir.restaurant.management.domain.operations.SyncChangeType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalAssetRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : AssetRepository {
    private val dao get() = database.assetDao()
    private val accounting get() = database.accountingDao()
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)
    private val numbering = LocalDocumentNumberAllocator(database, clock)
    private val audit = LocalAuditEventWriter(database)
    private val branchResolver = CanonicalBranchResolver(database)

    override val assets: Flow<List<AssetRecord>> = dao.observeAssets().map { rows ->
        rows.map { row -> AssetRecord(
            id = row.id, assetCode = row.assetCode, name = row.name, category = row.category, quantity = row.quantity,
            purchaseEpochDay = row.purchaseEpochDay, purchaseCostRial = row.purchaseCostRial, salvageValueRial = row.salvageValueRial,
            accumulatedDepreciationRial = row.accumulatedDepreciationRial, usefulLifeMonths = row.usefulLifeMonths, location = row.location,
            notes = row.notes, isActive = row.status == "ACTIVE", isAccountingRecognized = row.isAccountingRecognized,
            branch = row.branch, responsiblePerson = row.responsiblePerson, impairmentRial = row.impairmentRial, status = row.status, branchId = row.branchId,
        ) }
    }
    override val depreciations: Flow<List<DepreciationRecord>> = dao.observeDepreciations().map { rows ->
        rows.map { DepreciationRecord(it.id, it.assetName, it.periodYear, it.periodMonth, it.amountRial) }
    }

    override suspend fun save(id: Long?, draft: AssetDraft): Long {
        val actor = authorizer.require(Permission.ASSETS)
        val now = clock()
        return database.withTransaction {
            val numberedDraft = if (id == null && draft.assetCode.isBlank()) {
                var generated: String
                do { generated = numbering.next(DocumentNumberType.FIXED_ASSET) } while (dao.assetCodeExists(generated))
                draft.copy(assetCode = generated)
            } else draft
            val valid = numberedDraft.validated()
            val branch = branchResolver.resolveOptional(valid.branchId, valid.branch)
            if (id == null) {
                val assetId = dao.insertAsset(FixedAssetEntity(assetCode = valid.assetCode, name = valid.name, category = valid.category, quantity = valid.quantity, purchaseEpochDay = valid.purchaseEpochDay, purchaseCostRial = valid.purchaseCostRial, salvageValueRial = valid.salvageValueRial, usefulLifeMonths = valid.usefulLifeMonths, location = valid.location, notes = valid.notes, createdAtEpochMillis = now, updatedAtEpochMillis = now, branch = branch?.name.orEmpty(), branchId = branch?.id, responsiblePerson = valid.responsiblePerson))
                check(assetId > 0) { "ثبت دارایی انجام نشد." }
                val acquisitionJournalId = postAcquisitionJournal(
                    asset = dao.assetById(assetId) ?: error("دارایی ثبت‌شده پیدا نشد."),
                    source = valid.acquisitionSource,
                    postingEpochDay = valid.purchaseEpochDay,
                    actorId = actor.id,
                )
                val lifecycleId = database.assetLifecycleDao().insertEvent(
                    AssetLifecycleEventEntity(
                        assetId = assetId,
                        eventType = AssetLifecycleType.PURCHASE.name,
                        businessEpochDay = valid.purchaseEpochDay,
                        amountRial = valid.purchaseCostRial,
                        toLocation = valid.location,
                        toBranch = branch?.name.orEmpty(),
                        toResponsiblePerson = valid.responsiblePerson,
                        note = "ثبت اولیه دارایی",
                        journalEntryId = acquisitionJournalId,
                        actorId = actor.id,
                        createdAtEpochMillis = now,
                    ),
                )
                audit.appendAuthorized(
                    authorizer = authorizer,
                    action = "CREATE",
                    entityType = "ASSET",
                    entityId = assetId,
                    description = "ثبت دارایی ${valid.assetCode}: ${valid.name}",
                    occurredAtEpochMillis = now,
                    businessEpochDay = valid.purchaseEpochDay,
                    afterSnapshot = "historicalCost=${valid.purchaseCostRial};salvage=${valid.salvageValueRial};location=${valid.location};branch=${valid.branch};event=$lifecycleId",
                    correlationId = "asset:$assetId:purchase:$lifecycleId",
                )
                syncRecorder?.record("ASSET", assetId, SyncChangeType.CREATE.name, now, valid.syncPayload())
                assetId
            } else {
                val current = dao.assetById(id) ?: error("دارایی پیدا نشد.")
                require(current.status == "ACTIVE") { "دارایی خارج‌شده قابل ویرایش نیست." }
                require(
                    current.assetCode == valid.assetCode &&
                        current.quantity == valid.quantity &&
                        current.purchaseEpochDay == valid.purchaseEpochDay &&
                        current.purchaseCostRial == valid.purchaseCostRial &&
                        current.salvageValueRial == valid.salvageValueRial &&
                        current.usefulLifeMonths == valid.usefulLifeMonths,
                ) {
                    "کد، تعداد، تاریخ و مبالغ مبنای دارایی پس از ثبت سند تحصیل قابل تغییر نیست؛ اصلاح مالی باید با سند اصلاحی انجام شود."
                }
                check(dao.updateAsset(current.copy(assetCode = valid.assetCode, name = valid.name, category = valid.category, quantity = valid.quantity, purchaseEpochDay = valid.purchaseEpochDay, purchaseCostRial = valid.purchaseCostRial, salvageValueRial = valid.salvageValueRial, usefulLifeMonths = valid.usefulLifeMonths, location = valid.location, notes = valid.notes, branch = branch?.name.orEmpty(), branchId = branch?.id, responsiblePerson = valid.responsiblePerson, updatedAtEpochMillis = now)) == 1)
                audit.appendAuthorized(
                    authorizer = authorizer,
                    action = "UPDATE",
                    entityType = "ASSET",
                    entityId = id,
                    description = "ویرایش مشخصات غیرمالی دارایی ${current.assetCode}",
                    occurredAtEpochMillis = now,
                    businessEpochDay = current.purchaseEpochDay,
                    beforeSnapshot = "name=${current.name};category=${current.category};location=${current.location};branch=${current.branch};responsible=${current.responsiblePerson}",
                    afterSnapshot = "name=${valid.name};category=${valid.category};location=${valid.location};branch=${valid.branch};responsible=${valid.responsiblePerson}",
                    correlationId = "asset:$id:update:$now",
                )
                syncRecorder?.record("ASSET", id, SyncChangeType.UPDATE.name, now, valid.syncPayload())
                id
            }
        }
    }

    override suspend fun recognizeImportedAsset(id: Long): Long {
        val actor = authorizer.require(Permission.ASSETS)
        val now = clock()
        return database.withTransaction {
            val asset = dao.assetById(id) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "فقط دارایی فعال قابل تطبیق مالی است." }
            require(accounting.entryBySource("ASSET_ACQUISITION", asset.id) == null) {
                "سند تحصیل این دارایی قبلاً ثبت شده است."
            }
            postAcquisitionJournal(
                asset = asset,
                source = AssetAcquisitionSource.OWNER_CAPITAL,
                postingEpochDay = currentLocalEpochDay(),
                description = "ثبت مانده افتتاحیه دارایی قدیمی: ${asset.name}",
                actorId = actor.id,
            ).also { entryId ->
                syncRecorder?.record(
                    "ASSET",
                    asset.id,
                    "RECOGNIZE_ACCOUNTING",
                    now,
                    mapOf("acquisitionSource" to AssetAcquisitionSource.OWNER_CAPITAL.name, "journalEntryId" to entryId.toString()),
                )
            }
        }
    }

    override suspend fun dispose(id: Long) {
        val actor = authorizer.require(Permission.ASSETS)
        val now = clock()
        database.withTransaction {
            val asset = dao.assetById(id) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "دارایی قبلاً از چرخه بهره‌برداری خارج شده است." }
            require(accounting.entryBySource("ASSET_ACQUISITION", asset.id) != null) {
                "دارایی قدیمی فاقد سند تحصیل است؛ ابتدا مانده افتتاحیه آن را در حسابداری تطبیق دهید."
            }
            val bookValue = SignedLongMath.subtract(SignedLongMath.subtract(asset.purchaseCostRial, asset.accumulatedDepreciationRial), asset.impairmentRial)
            require(bookValue >= 0) { "ارزش دفتری دارایی نامعتبر است." }
            val disposalLines = buildList {
                if (asset.accumulatedDepreciationRial > 0) add(SemanticJournalLine(SemanticAccountRole.ACCUMULATED_DEPRECIATION, debit = MoneyRial.of(asset.accumulatedDepreciationRial), memo = "بستن استهلاک انباشته"))
                if (asset.impairmentRial > 0) add(SemanticJournalLine(SemanticAccountRole.ACCUMULATED_IMPAIRMENT, debit = MoneyRial.of(asset.impairmentRial), memo = "بستن کاهش ارزش انباشته"))
                if (bookValue > 0) add(SemanticJournalLine(SemanticAccountRole.ASSET_DISPOSAL_LOSS, debit = MoneyRial.of(bookValue), memo = "زیان خروج دارایی بدون عایدی"))
                add(SemanticJournalLine(SemanticAccountRole.FIXED_ASSET, credit = MoneyRial.of(asset.purchaseCostRial), memo = asset.assetCode))
            }
            val postingEpochDay = currentLocalEpochDay()
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "خد-$id-$now",
                    entryEpochDay = postingEpochDay,
                    description = "خروج بدون عایدی دارایی ثابت: ${asset.name}",
                    sourceType = "ASSET_DISPOSAL",
                    sourceId = asset.id,
                    accountingScope = asset.accountingScope(),
                    branchId = asset.branchId,
                    lines = disposalLines,
                ),
                context = AccountingPostingContext.local(
                    sourceType = "ASSET_DISPOSAL",
                    sourceId = asset.id,
                    suffix = "post",
                    actorId = actor.id,
                    correlationId = "asset_disposal:${asset.id}",
                ),
            )
            check(dao.disposeAsset(id, now) == 1) { "خروج دارایی انجام نشد." }
            val lifecycleId = database.assetLifecycleDao().insertEvent(
                AssetLifecycleEventEntity(
                    assetId = asset.id,
                    eventType = AssetLifecycleType.DISPOSAL.name,
                    businessEpochDay = postingEpochDay,
                    amountRial = bookValue,
                    fromLocation = asset.location,
                    fromBranch = asset.branch,
                    fromResponsiblePerson = asset.responsiblePerson,
                    note = "خروج بدون عایدی",
                    journalEntryId = entryId,
                    actorId = actor.id,
                    createdAtEpochMillis = now,
                ),
            )
            audit.appendAuthorized(
                authorizer = authorizer,
                action = "DISPOSE",
                entityType = "ASSET",
                entityId = asset.id,
                description = "خروج بدون عایدی ${asset.assetCode}",
                occurredAtEpochMillis = now,
                businessEpochDay = postingEpochDay,
                reason = "خروج بدون عایدی",
                beforeSnapshot = "historicalCost=${asset.purchaseCostRial};accDep=${asset.accumulatedDepreciationRial};impairment=${asset.impairmentRial};book=$bookValue",
                afterSnapshot = "status=DISPOSED;event=$lifecycleId;journal=$entryId",
                correlationId = "asset:${asset.id}:disposal:$lifecycleId",
            )
            syncRecorder?.record(
                "ASSET",
                id,
                SyncChangeType.DISPOSE.name,
                now,
                mapOf("bookValueRial" to bookValue.toString(), "disposalJournalEntryId" to entryId.toString(), "lifecycleEventId" to lifecycleId.toString()),
            )
        }
    }

    override suspend fun postDepreciation(draft: DepreciationDraft): Long {
        val actor = authorizer.require(Permission.ASSETS)
        val valid = draft.validated()
        return database.withTransaction {
            val asset = dao.assetById(valid.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "دارایی فعال نیست." }
            require(accounting.entryBySource("ASSET_ACQUISITION", asset.id) != null) {
                "برای این دارایی سند تحصیل ثبت نشده است؛ قبل از استهلاک، مانده افتتاحیه را تطبیق دهید."
            }
            require(!dao.depreciationExists(asset.id, valid.periodYear, valid.periodMonth)) { "استهلاک این دوره قبلاً ثبت شده است." }
            val depreciable = asset.purchaseCostRial - asset.salvageValueRial
            val monthly = depreciable / asset.usefulLifeMonths
            val remaining = depreciable - asset.accumulatedDepreciationRial - asset.impairmentRial
            val amount = minOf(monthly, remaining)
            require(amount > 0) { "دارایی کاملاً مستهلک شده است." }
            val now = clock()
            val entryId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "د-${asset.id}-${valid.periodYear}-${valid.periodMonth}", entryEpochDay = valid.postingEpochDay,
                    description = "استهلاک ${asset.name} ${valid.periodYear}/${valid.periodMonth}",
                    sourceType = "ASSET_DEPRECIATION", sourceId = asset.id,
                    accountingScope = asset.accountingScope(), branchId = asset.branchId,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.DEPRECIATION_EXPENSE, debit = MoneyRial.of(amount), memo = "هزینه استهلاک"),
                        SemanticJournalLine(SemanticAccountRole.ACCUMULATED_DEPRECIATION, credit = MoneyRial.of(amount), memo = "استهلاک انباشته"),
                    ),
                ),
                context = AccountingPostingContext.local(
                    sourceType = "ASSET_DEPRECIATION",
                    sourceId = asset.id,
                    suffix = "${valid.periodYear}:${valid.periodMonth}",
                    actorId = actor.id,
                    correlationId = "asset_depreciation:${asset.id}:${valid.periodYear}:${valid.periodMonth}",
                ),
            )
            check(dao.addDepreciation(asset.id, amount, now) == 1) { "ثبت استهلاک از ارزش مجاز بیشتر است." }
            val depreciationId = dao.insertDepreciation(AssetDepreciationEntity(assetId = asset.id, periodYear = valid.periodYear, periodMonth = valid.periodMonth, amountRial = amount, journalEntryId = entryId, createdAtEpochMillis = now))
            check(depreciationId > 0) { "ثبت سابقه استهلاک انجام نشد." }
            syncRecorder?.record(
                "ASSET_DEPRECIATION",
                depreciationId,
                SyncChangeType.CREATE.name,
                now,
                mapOf(
                    "amountRial" to amount.toString(),
                    "assetId" to asset.id.toString(),
                    "journalEntryId" to entryId.toString(),
                    "periodMonth" to valid.periodMonth.toString(),
                    "periodYear" to valid.periodYear.toString(),
                ),
            )
            depreciationId
        }
    }

    override suspend fun transfer(draft: AssetTransferDraft): Long {
        val actor = authorizer.require(Permission.ASSET_LIFECYCLE)
        val reason = draft.reason.trim()
        require(draft.assetId > 0 && draft.businessEpochDay > 0 && reason.length in 3..300) { "اطلاعات انتقال دارایی ناقص است." }
        return database.withTransaction {
            val asset = dao.assetById(draft.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "فقط دارایی فعال قابل انتقال است." }
            val location = draft.toLocation.trim()
            val canonicalBranch = branchResolver.resolveOptional(draft.toBranchId, draft.toBranch)
            val branch = canonicalBranch?.name.orEmpty()
            val responsible = draft.toResponsiblePerson.trim()
            require(location.isNotBlank() || branch.isNotBlank() || responsible.isNotBlank()) { "مقصد انتقال مشخص نشده است." }
            val now = clock()
            check(dao.transferAsset(asset.id, location, branch, canonicalBranch?.id, responsible, now) == 1) { "انتقال دارایی انجام نشد." }
            val eventId = database.assetLifecycleDao().insertEvent(AssetLifecycleEventEntity(
                assetId = asset.id, eventType = AssetLifecycleType.TRANSFER.name, businessEpochDay = draft.businessEpochDay,
                fromLocation = asset.location, toLocation = location, fromBranch = asset.branch, toBranch = branch,
                fromResponsiblePerson = asset.responsiblePerson, toResponsiblePerson = responsible, note = reason,
                actorId = actor.id, createdAtEpochMillis = now,
            ))
            audit.appendAuthorized(authorizer, "TRANSFER", "ASSET", asset.id, "انتقال دارایی ${asset.assetCode}", now, draft.businessEpochDay, reason,
                beforeSnapshot = "location=${asset.location};branch=${asset.branch};responsible=${asset.responsiblePerson}",
                afterSnapshot = "location=$location;branch=$branch;responsible=$responsible", correlationId = "asset:${asset.id}:transfer:$eventId")
            syncRecorder?.record("ASSET", asset.id, "TRANSFER", now, mapOf("eventId" to eventId.toString()))
            eventId
        }
    }

    override suspend fun recordMaintenance(draft: AssetMaintenanceDraft): Long {
        val actor = authorizer.require(Permission.ASSET_LIFECYCLE)
        val type = draft.serviceType.trim()
        require(draft.assetId > 0 && draft.serviceEpochDay > 0 && type.isNotBlank()) { "اطلاعات سرویس دارایی ناقص است." }
        require(draft.costRial >= 0) { "هزینه سرویس نامعتبر است." }
        draft.nextServiceEpochDay?.let { require(it > draft.serviceEpochDay) { "تاریخ سرویس بعدی باید بعد از سرویس فعلی باشد." } }
        require(draft.paymentSource != AssetAcquisitionSource.OWNER_CAPITAL) { "منبع پرداخت نگهداری معتبر نیست." }
        return database.withTransaction {
            val asset = dao.assetById(draft.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "فقط دارایی فعال قابل سرویس است." }
            val now = clock()
            val journalId = if (draft.costRial > 0) accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "نگ-${asset.id}-$now", entryEpochDay = draft.serviceEpochDay,
                    description = "تعمیر و نگهداری ${asset.name}", sourceType = "ASSET_MAINTENANCE", sourceId = asset.id,
                    accountingScope = asset.accountingScope(), branchId = asset.branchId,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.MAINTENANCE_EXPENSE, debit = MoneyRial.of(draft.costRial), memo = type),
                        SemanticJournalLine(sourceRole(draft.paymentSource), credit = MoneyRial.of(draft.costRial), memo = draft.contractor.trim()),
                    ),
                ),
                context = AccountingPostingContext.local("ASSET_MAINTENANCE", asset.id, now.toString(), actor.id, "asset_maintenance:${asset.id}:$now"),
            ) else null
            val maintenanceId = database.assetLifecycleDao().insertMaintenance(AssetMaintenanceEntity(
                assetId = asset.id, serviceType = type, serviceEpochDay = draft.serviceEpochDay, costRial = draft.costRial,
                contractor = draft.contractor.trim(), note = draft.note.trim(), nextServiceEpochDay = draft.nextServiceEpochDay,
                actorId = actor.id, createdAtEpochMillis = now,
            ))
            database.assetLifecycleDao().insertEvent(AssetLifecycleEventEntity(
                assetId = asset.id, eventType = AssetLifecycleType.MAINTENANCE.name, businessEpochDay = draft.serviceEpochDay,
                amountRial = draft.costRial, counterparty = draft.contractor.trim(), note = draft.note.trim(), journalEntryId = journalId,
                actorId = actor.id, createdAtEpochMillis = now,
            ))
            audit.appendAuthorized(authorizer, "MAINTENANCE", "ASSET", asset.id, "سرویس ${asset.assetCode}: $type", now, draft.serviceEpochDay,
                draft.note.trim().ifBlank { "ثبت سرویس دارایی" }, afterSnapshot = "maintenanceId=$maintenanceId;cost=${draft.costRial};next=${draft.nextServiceEpochDay}", correlationId = "asset:${asset.id}:maintenance:$maintenanceId")
            maintenanceId
        }
    }

    override suspend fun impair(draft: AssetImpairmentDraft): Long {
        val actor = authorizer.require(Permission.ASSET_LIFECYCLE)
        val reason = draft.reason.trim()
        require(draft.assetId > 0 && draft.businessEpochDay > 0 && draft.amountRial > 0 && reason.length in 3..300) { "اطلاعات کاهش ارزش ناقص است." }
        return database.withTransaction {
            val asset = dao.assetById(draft.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "دارایی فعال نیست." }
            val bookBefore = asset.purchaseCostRial - asset.accumulatedDepreciationRial - asset.impairmentRial
            require(draft.amountRial <= bookBefore - asset.salvageValueRial) { "کاهش ارزش نمی‌تواند ارزش دفتری را کمتر از ارزش اسقاط کند." }
            val now = clock()
            val journalId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "کز-${asset.id}-$now", entryEpochDay = draft.businessEpochDay, description = "کاهش ارزش ${asset.name}", sourceType = "ASSET_IMPAIRMENT", sourceId = asset.id,
                    accountingScope = asset.accountingScope(), branchId = asset.branchId,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.ASSET_IMPAIRMENT_LOSS, debit = MoneyRial.of(draft.amountRial), memo = reason),
                        SemanticJournalLine(SemanticAccountRole.ACCUMULATED_IMPAIRMENT, credit = MoneyRial.of(draft.amountRial), memo = asset.assetCode),
                    ),
                ),
                context = AccountingPostingContext.local("ASSET_IMPAIRMENT", asset.id, now.toString(), actor.id, "asset_impairment:${asset.id}:$now"),
            )
            check(dao.addImpairment(asset.id, draft.amountRial, now) == 1) { "ثبت کاهش ارزش انجام نشد." }
            val eventId = database.assetLifecycleDao().insertEvent(AssetLifecycleEventEntity(assetId = asset.id, eventType = AssetLifecycleType.IMPAIRMENT.name, businessEpochDay = draft.businessEpochDay, amountRial = draft.amountRial, note = reason, journalEntryId = journalId, actorId = actor.id, createdAtEpochMillis = now))
            audit.appendAuthorized(authorizer, "IMPAIR", "ASSET", asset.id, "کاهش ارزش ${asset.assetCode}", now, draft.businessEpochDay, reason, beforeSnapshot = "book=$bookBefore", afterSnapshot = "book=${bookBefore-draft.amountRial};event=$eventId", correlationId = "asset:${asset.id}:impair:$eventId")
            eventId
        }
    }

    override suspend fun sell(draft: AssetSaleDraft): Long {
        val actor = authorizer.require(Permission.ASSET_LIFECYCLE)
        val reason = draft.reason.trim()
        require(draft.assetId > 0 && draft.businessEpochDay > 0 && draft.salePriceRial >= 0 && reason.length in 3..300) { "اطلاعات فروش دارایی ناقص است." }
        require(draft.receiptSource == AssetAcquisitionSource.CASH || draft.receiptSource == AssetAcquisitionSource.BANK) { "دریافت فروش دارایی باید نقد یا بانک باشد." }
        return database.withTransaction {
            val asset = dao.assetById(draft.assetId) ?: error("دارایی پیدا نشد.")
            require(asset.status == "ACTIVE") { "فقط دارایی فعال قابل فروش است." }
            val bookValue = asset.purchaseCostRial - asset.accumulatedDepreciationRial - asset.impairmentRial
            require(bookValue >= 0) { "ارزش دفتری دارایی نامعتبر است." }
            val gain = (draft.salePriceRial - bookValue).coerceAtLeast(0)
            val loss = (bookValue - draft.salePriceRial).coerceAtLeast(0)
            val lines = buildList {
                if (draft.salePriceRial > 0) add(SemanticJournalLine(sourceRole(draft.receiptSource), debit = MoneyRial.of(draft.salePriceRial), memo = draft.buyer.trim()))
                if (asset.accumulatedDepreciationRial > 0) add(SemanticJournalLine(SemanticAccountRole.ACCUMULATED_DEPRECIATION, debit = MoneyRial.of(asset.accumulatedDepreciationRial)))
                if (asset.impairmentRial > 0) add(SemanticJournalLine(SemanticAccountRole.ACCUMULATED_IMPAIRMENT, debit = MoneyRial.of(asset.impairmentRial)))
                if (loss > 0) add(SemanticJournalLine(SemanticAccountRole.ASSET_DISPOSAL_LOSS, debit = MoneyRial.of(loss)))
                add(SemanticJournalLine(SemanticAccountRole.FIXED_ASSET, credit = MoneyRial.of(asset.purchaseCostRial), memo = asset.assetCode))
                if (gain > 0) add(SemanticJournalLine(SemanticAccountRole.ASSET_DISPOSAL_GAIN, credit = MoneyRial.of(gain)))
            }
            val now = clock()
            val journalId = accountingPosting.post(
                draft = SemanticJournalDraft(
                    entryNo = "فد-${asset.id}-$now", description = "فروش دارایی ${asset.name}", entryEpochDay = draft.businessEpochDay,
                    sourceType = "ASSET_SALE", sourceId = asset.id, accountingScope = asset.accountingScope(), branchId = asset.branchId, lines = lines,
                ),
                context = AccountingPostingContext.local("ASSET_SALE", asset.id, now.toString(), actor.id, "asset_sale:${asset.id}:$now"),
            )
            check(dao.markSold(asset.id, draft.salePriceRial, draft.businessEpochDay, now) == 1) { "ثبت فروش دارایی انجام نشد." }
            val eventId = database.assetLifecycleDao().insertEvent(AssetLifecycleEventEntity(assetId = asset.id, eventType = AssetLifecycleType.SALE.name, businessEpochDay = draft.businessEpochDay, amountRial = draft.salePriceRial, counterparty = draft.buyer.trim(), note = reason, journalEntryId = journalId, actorId = actor.id, createdAtEpochMillis = now))
            audit.appendAuthorized(authorizer, "SALE", "ASSET", asset.id, "فروش ${asset.assetCode}", now, draft.businessEpochDay, reason, beforeSnapshot = "historicalCost=${asset.purchaseCostRial};accDep=${asset.accumulatedDepreciationRial};impairment=${asset.impairmentRial};book=$bookValue", afterSnapshot = "sale=${draft.salePriceRial};gain=$gain;loss=$loss;status=SOLD", correlationId = "asset:${asset.id}:sale:$eventId")
            eventId
        }
    }

    override fun observeLifecycle(assetId: Long): Flow<List<AssetLifecycleRecord>> = database.assetLifecycleDao().observeEvents(assetId).map { rows ->
        rows.map { AssetLifecycleRecord(it.id, it.assetId, AssetLifecycleType.valueOf(it.eventType), it.businessEpochDay, it.amountRial, it.note) }
    }

    override fun observeMaintenance(assetId: Long): Flow<List<AssetMaintenanceRecord>> = database.assetLifecycleDao().observeMaintenance(assetId).map { rows ->
        rows.map { AssetMaintenanceRecord(it.id, it.assetId, it.serviceType, it.serviceEpochDay, it.costRial, it.contractor, it.nextServiceEpochDay) }
    }

    private fun sourceRole(source: AssetAcquisitionSource): SemanticAccountRole = when (source) {
        AssetAcquisitionSource.CASH -> SemanticAccountRole.CASH
        AssetAcquisitionSource.BANK -> SemanticAccountRole.BANK
        AssetAcquisitionSource.PAYABLE -> SemanticAccountRole.SUPPLIER_PAYABLE
        AssetAcquisitionSource.OWNER_CAPITAL -> SemanticAccountRole.OWNER_CAPITAL
    }

    private fun AssetDraft.syncPayload(): Map<String, String> = mapOf(
        "acquisitionSource" to acquisitionSource.name,
        "assetCode" to assetCode,
        "category" to category,
        "location" to location,
        "branch" to branch,
        "branchId" to branchId?.toString().orEmpty(),
        "responsiblePerson" to responsiblePerson,
        "name" to name,
        "purchaseCostRial" to purchaseCostRial.toString(),
        "purchaseEpochDay" to purchaseEpochDay.toString(),
        "quantity" to quantity.toString(),
        "salvageValueRial" to salvageValueRial.toString(),
        "usefulLifeMonths" to usefulLifeMonths.toString(),
    )

    private suspend fun postAcquisitionJournal(
        asset: FixedAssetEntity,
        source: AssetAcquisitionSource,
        postingEpochDay: Long,
        actorId: Long,
        description: String = "تحصیل دارایی ثابت: ${asset.name}",
    ): Long {
        val sourceRole = when (source) {
            AssetAcquisitionSource.CASH -> SemanticAccountRole.CASH
            AssetAcquisitionSource.BANK -> SemanticAccountRole.BANK
            AssetAcquisitionSource.PAYABLE -> SemanticAccountRole.SUPPLIER_PAYABLE
            AssetAcquisitionSource.OWNER_CAPITAL -> SemanticAccountRole.OWNER_CAPITAL
        }
        return accountingPosting.post(
            draft = SemanticJournalDraft(
                entryNo = "تد-${asset.id}",
                entryEpochDay = postingEpochDay,
                description = description,
                sourceType = "ASSET_ACQUISITION",
                sourceId = asset.id,
                accountingScope = asset.accountingScope(),
                branchId = asset.branchId,
                lines = listOf(
                    SemanticJournalLine(SemanticAccountRole.FIXED_ASSET, debit = MoneyRial.of(asset.purchaseCostRial), memo = asset.assetCode),
                    SemanticJournalLine(sourceRole, credit = MoneyRial.of(asset.purchaseCostRial), memo = source.title),
                ),
            ),
            context = AccountingPostingContext.local(
                sourceType = "ASSET_ACQUISITION",
                sourceId = asset.id,
                suffix = "post",
                actorId = actorId,
                correlationId = "asset_acquisition:${asset.id}",
            ),
        )
    }

    private fun FixedAssetEntity.accountingScope(): AccountingScope =
        if (branchId != null) AccountingScope.BRANCH else AccountingScope.ORGANIZATION
}
