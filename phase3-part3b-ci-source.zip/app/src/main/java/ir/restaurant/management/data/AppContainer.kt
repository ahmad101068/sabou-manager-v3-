package ir.restaurant.management.data

import ir.restaurant.management.application.sales.SalesHistoryUseCases
import ir.restaurant.management.application.crm.CrmUseCases
import ir.restaurant.management.application.treasury.TreasuryUseCases
import ir.restaurant.management.application.treasury.ReverseTreasuryTransactionUseCase
import ir.restaurant.management.application.assets.AssetUseCases
import ir.restaurant.management.application.recipe.RecipeUseCases
import ir.restaurant.management.application.accounting.AccountingUseCases
import ir.restaurant.management.application.procurement.ProcurementUseCases
import ir.restaurant.management.application.inventory.InventoryUseCases
import ir.restaurant.management.application.inventory.OperationsInventoryUseCases
import ir.restaurant.management.application.personnel.PersonnelUseCases
import ir.restaurant.management.application.personnel.AttendanceUseCases
import ir.restaurant.management.application.payroll.PayrollUseCases
import ir.restaurant.management.domain.security.Permission
import ir.restaurant.management.OrganizationSettingsStore

import android.content.Context
import android.net.Uri
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.APP_DATABASE_SCHEMA_VERSION
import ir.restaurant.management.data.db.AccountSeedCallback
import ir.restaurant.management.data.db.clearAllTablesForFactoryReset
import ir.restaurant.management.data.repository.DashboardRepository
import ir.restaurant.management.data.repository.LocalAccountingRepository
import ir.restaurant.management.data.repository.LocalBranchRepository
import ir.restaurant.management.data.repository.LocalOperationsRepository
import ir.restaurant.management.data.repository.LocalInventoryRepository
import ir.restaurant.management.data.repository.LocalInventoryIntegrityService
import ir.restaurant.management.data.repository.LocalInventoryCommandEngine
import ir.restaurant.management.data.repository.LocalInventoryCountService
import ir.restaurant.management.data.repository.LocalInventoryLotService
import ir.restaurant.management.data.repository.LocalInventoryTransferService
import ir.restaurant.management.data.repository.LocalInventoryReplenishmentService
import ir.restaurant.management.data.repository.LocalInventoryReadService
import ir.restaurant.management.data.repository.LocalInventoryWasteService
import ir.restaurant.management.data.repository.LocalPurchaseRepository
import ir.restaurant.management.data.repository.LocalProcurementRepository
import ir.restaurant.management.data.repository.LocalPersonnelRepository
import ir.restaurant.management.data.repository.LocalHrPayrollService
import ir.restaurant.management.data.repository.LocalPerformanceRepository
import ir.restaurant.management.data.repository.LocalSyncRepository
import ir.restaurant.management.data.repository.SyncRecorder
import ir.restaurant.management.data.repository.LocalDailySalesRepository
import ir.restaurant.management.data.repository.LocalSalesHistoryRepository
import ir.restaurant.management.data.repository.LocalSecurityRepository
import ir.restaurant.management.data.repository.LocalAssetRepository
import ir.restaurant.management.data.repository.LocalRecipeRepository
import ir.restaurant.management.data.repository.LocalCustomerAccountService
import ir.restaurant.management.data.repository.LocalAlertRepository
import ir.restaurant.management.data.repository.LocalManagementControlRepository
import ir.restaurant.management.data.repository.LocalAccountingPostingEngine
import ir.restaurant.management.data.repository.LocalAuditEventWriter
import ir.restaurant.management.data.repository.LocalReceivableService
import ir.restaurant.management.data.repository.LocalManagementWorkflowService
import ir.restaurant.management.data.repository.LocalManagementWorkflowReadService
import ir.restaurant.management.data.repository.LocalDailyManagementBriefService
import ir.restaurant.management.data.repository.OverdueReceivableRule
import ir.restaurant.management.data.repository.FoodCostVarianceRule
import ir.restaurant.management.data.repository.CashVarianceRule
import ir.restaurant.management.data.repository.LowStockRule
import ir.restaurant.management.data.repository.WasteSpikeRule
import ir.restaurant.management.data.repository.PurchasePriceSpikeRule
import ir.restaurant.management.data.repository.CardSettlementVarianceRule
import ir.restaurant.management.data.repository.InventoryUsageVarianceRule
import ir.restaurant.management.data.repository.ManagementRuleEngine
import ir.restaurant.management.data.repository.ControlSettingsService
import ir.restaurant.management.data.repository.LocalCostControlReadService
import ir.restaurant.management.domain.control.CostControlReadService
import ir.restaurant.management.data.treasury.DefaultTreasuryAccountCatalog
import ir.restaurant.management.data.treasury.LocalTreasuryServiceV2
import ir.restaurant.management.data.security.DatabaseKeyProvider
import ir.restaurant.management.data.security.SensitiveActionGate
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.data.security.StartupSessionBoundary
import ir.restaurant.management.domain.accounting.AccountingRepository
import ir.restaurant.management.domain.accounting.AccountingPostingService
import ir.restaurant.management.domain.branch.BranchRepository
import ir.restaurant.management.domain.audit.AuditService
import ir.restaurant.management.domain.operations.OperationsRepository
import ir.restaurant.management.domain.inventory.InventoryRepository
import ir.restaurant.management.domain.inventory.InventoryIntegrityService
import ir.restaurant.management.domain.inventory.InventoryCommandService
import ir.restaurant.management.domain.inventory.InventoryCountService
import ir.restaurant.management.domain.inventory.InventoryLotService
import ir.restaurant.management.domain.inventory.InventoryTransferService
import ir.restaurant.management.domain.inventory.InventoryReplenishmentService
import ir.restaurant.management.domain.inventory.InventoryReadService
import ir.restaurant.management.domain.inventory.InventoryWasteService
import ir.restaurant.management.domain.purchase.PurchaseRepository
import ir.restaurant.management.domain.purchase.ProcurementRepository
import ir.restaurant.management.domain.personnel.PersonnelRepository
import ir.restaurant.management.domain.personnel.HrPayrollCommandService
import ir.restaurant.management.domain.sales.DailySalesRepository
import ir.restaurant.management.domain.sales.SalesHistoryRepository
import ir.restaurant.management.domain.operations.SecurityRepository
import ir.restaurant.management.domain.operations.SensitiveAction
import ir.restaurant.management.domain.recipe.RecipeRepository
import ir.restaurant.management.domain.assets.AssetRepository
import ir.restaurant.management.domain.operations.AlertRepository
import ir.restaurant.management.domain.operations.CloudSyncConfig
import ir.restaurant.management.domain.operations.SyncSafetyGate
import ir.restaurant.management.domain.control.ManagementControlRepository
import ir.restaurant.management.domain.receivables.ReceivableService
import ir.restaurant.management.domain.control.ManagementWorkflowService
import ir.restaurant.management.domain.control.ManagementWorkflowReadService
import ir.restaurant.management.domain.brief.DailyManagementBriefService
import ir.restaurant.management.domain.control.ManagementRuleContext
import ir.restaurant.management.domain.security.AuthorizationService
import ir.restaurant.management.domain.treasury.TreasuryAccountCatalog
import ir.restaurant.management.domain.treasury.TreasuryService
import ir.restaurant.management.domain.treasury.TreasuryLedgerReader
import ir.restaurant.management.domain.crm.CustomerAccountService
import ir.restaurant.management.data.repository.HttpsSyncTransport
import ir.restaurant.management.data.repository.SyncCoordinator
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AppContainer(context: Context) {
    private val appContext = context.applicationContext
    val organizationSettings = OrganizationSettingsStore(appContext)
    private val keyProvider = DatabaseKeyProvider(appContext)
    private val sensitiveActionGate = SensitiveActionGate()
    private val deviceId: String by lazy {
        val preferences = context.getSharedPreferences("sync_identity", Context.MODE_PRIVATE)
        preferences.getString("device_id", null) ?: UUID.randomUUID().toString().also { generated ->
            check(preferences.edit().putString("device_id", generated).commit()) { "ذخیره شناسه دستگاه انجام نشد." }
        }
    }
    val backupManager = BackupManager(appContext, keyProvider) { deviceId }
    private val database: AppDatabase by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        backupManager.applyPendingRestore()
        backupManager.preparePreMigrationRecovery(APP_DATABASE_SCHEMA_VERSION)
        var openedDatabase: AppDatabase? = null
        try {
            openedDatabase = openAndValidateDatabase()
            backupManager.markRestoreValidated()
            backupManager.markDatabaseSchemaValidated(APP_DATABASE_SCHEMA_VERSION)
            checkNotNull(openedDatabase)
        } catch (error: Throwable) {
            openedDatabase?.close()
            if (backupManager.rollbackLastRestore()) {
                val recoveredDatabase = openAndValidateDatabase()
                try {
                    backupManager.markRestoreValidated()
                    backupManager.markDatabaseSchemaValidated(APP_DATABASE_SCHEMA_VERSION)
                    recoveredDatabase
                } catch (recoveryError: Throwable) {
                    recoveredDatabase.close()
                    recoveryError.addSuppressed(error)
                    throw recoveryError
                }
            } else {
                runCatching { backupManager.rollbackPreMigrationRecovery() }
                    .exceptionOrNull()
                    ?.let(error::addSuppressed)
                throw error
            }
        }
    }

    private fun openAndValidateDatabase(): AppDatabase {
        val database = AppDatabase.create(appContext, keyProvider)
        try {
            val sqlite = database.openHelper.writableDatabase
            val cipherResults = sqlite.query("PRAGMA cipher_integrity_check").use { cursor ->
                buildList {
                    while (cursor.moveToNext()) add(cursor.getString(0))
                }
            }
            require(cipherResults.isEmpty() || cipherResults.all { it.equals("ok", ignoreCase = true) }) {
                "اعتبارسنجی پایگاه داده ناموفق بود."
            }
            StartupSessionBoundary.invalidatePersistedSession(sqlite)
            return database
        } catch (error: Throwable) {
            database.close()
            throw error
        }
    }
    internal val databaseForTesting: AppDatabase
        get() = database

    private val authorizer by lazy { SessionAuthorizer(database) }
    val authorizationService: AuthorizationService by lazy { authorizer }
    val auditService: AuditService by lazy { LocalAuditEventWriter(database) }
    val branchRepository: BranchRepository by lazy { LocalBranchRepository(database, authorizer) }
    val accountingPostingService: AccountingPostingService by lazy {
        LocalAccountingPostingEngine(database)
    }
    val treasuryAccountCatalog: TreasuryAccountCatalog by lazy {
        DefaultTreasuryAccountCatalog()
    }
    val treasuryService: TreasuryService by lazy {
        LocalTreasuryServiceV2(
            database = database,
            accounting = accountingPostingService,
            authorizer = authorizer,
            accountCatalog = treasuryAccountCatalog,
        )
    }
    val treasuryLedgerReader: TreasuryLedgerReader by lazy { treasuryService as TreasuryLedgerReader }
    val treasuryUseCases: TreasuryUseCases by lazy { TreasuryUseCases(treasuryService, treasuryLedgerReader, treasuryAccountCatalog) }
    val reverseTreasuryTransactionUseCase: ReverseTreasuryTransactionUseCase by lazy { ReverseTreasuryTransactionUseCase(treasuryService, treasuryLedgerReader) }

    val hrPayrollService: HrPayrollCommandService by lazy {
        LocalHrPayrollService(
            database = database,
            authorizer = authorizer,
            accountingPosting = accountingPostingService,
            treasury = treasuryService,
            audit = auditService,
        )
    }
    val payrollUseCases: PayrollUseCases by lazy { PayrollUseCases(hrPayrollService) }

    /** Opens and validates the encrypted Room database. Call this from a background dispatcher. */
    fun initialize() {
        database.openHelper.writableDatabase
    }

    val purchaseRepository: PurchaseRepository by lazy {
        LocalPurchaseRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }

    val procurementRepository: ProcurementRepository by lazy {
        LocalProcurementRepository(
            database,
            authorizer,
            syncRecorder = syncRecorder,
            inventoryReplenishment = inventoryReplenishmentService,
        )
    }
    val procurementUseCases: ProcurementUseCases by lazy { ProcurementUseCases(procurementRepository, purchaseRepository) }

    val dailySalesRepository: DailySalesRepository by lazy {
        LocalDailySalesRepository(
            database,
            authorizer,
            syncRecorder = syncRecorder,
            sensitiveActionGate = sensitiveActionGate,
        )
    }

    val receivableService: ReceivableService by lazy { LocalReceivableService(database, authorizer) }
    val managementWorkflowService: ManagementWorkflowService by lazy { LocalManagementWorkflowService(database, authorizer) }
    val managementWorkflowReadService: ManagementWorkflowReadService by lazy { LocalManagementWorkflowReadService(database, authorizer) }
    val dailyManagementBriefService: DailyManagementBriefService by lazy { LocalDailyManagementBriefService(database, authorizer) }
    val controlSettingsService: ControlSettingsService by lazy { ControlSettingsService(database, authorizer) }
    val costControlReadService: CostControlReadService by lazy { LocalCostControlReadService(database, authorizer) }
    val managementRuleEngine: ManagementRuleEngine by lazy {
        ManagementRuleEngine(
            managementWorkflowService,
            listOf(OverdueReceivableRule(database), FoodCostVarianceRule(database), WasteSpikeRule(database), PurchasePriceSpikeRule(database), CashVarianceRule(database), CardSettlementVarianceRule(database), InventoryUsageVarianceRule(database), LowStockRule(database)),
        )
    }
    suspend fun refreshManagementRules(branchId: Long, fromEpochDay: Long, toEpochDay: Long): Int =
        managementRuleEngine.refresh(ManagementRuleContext(branchId, fromEpochDay, toEpochDay))

    val salesHistoryRepository: SalesHistoryRepository by lazy {
        LocalSalesHistoryRepository(
            database = database,
            authorizer = authorizer,
            syncRecorder = syncRecorder,
        )
    }

    val salesHistoryUseCases: SalesHistoryUseCases by lazy {
        SalesHistoryUseCases(salesHistoryRepository)
    }

    val customerAccountService: CustomerAccountService by lazy { LocalCustomerAccountService(database, authorizer) }
    val crmUseCases: CrmUseCases by lazy { CrmUseCases(customerAccountService) }

    val recipeRepository: RecipeRepository by lazy { LocalRecipeRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val recipeUseCases: RecipeUseCases by lazy { RecipeUseCases(recipeRepository) }

    val dashboardRepository: DashboardRepository by lazy {
        DashboardRepository(database)
    }

    val inventoryRepository: InventoryRepository by lazy {
        LocalInventoryRepository(
            database = database,
            authorizer = authorizer,
            syncRecorder = syncRecorder,
        )
    }

    val inventoryIntegrityService: InventoryIntegrityService by lazy {
        LocalInventoryIntegrityService(database, authorizer)
    }

    val inventoryCommandService: InventoryCommandService by lazy {
        LocalInventoryCommandEngine(database)
    }

    val inventoryCountService: InventoryCountService by lazy {
        LocalInventoryCountService(database, authorizer, syncRecorder = syncRecorder)
    }

    val inventoryLotService: InventoryLotService by lazy {
        LocalInventoryLotService(database, authorizer, syncRecorder = syncRecorder)
    }

    val inventoryWasteService: InventoryWasteService by lazy {
        LocalInventoryWasteService(
            database = database,
            authorizer = authorizer,
            accounting = accountingPostingService,
            syncRecorder = syncRecorder,
        )
    }

    val inventoryTransferService: InventoryTransferService by lazy {
        LocalInventoryTransferService(
            database = database,
            authorizer = authorizer,
            syncRecorder = syncRecorder,
        )
    }

    val inventoryReplenishmentService: InventoryReplenishmentService by lazy {
        LocalInventoryReplenishmentService(database, authorizer)
    }

    val inventoryReadService: InventoryReadService by lazy {
        LocalInventoryReadService(database, authorizer)
    }
    val inventoryUseCases: InventoryUseCases by lazy {
        InventoryUseCases(
            master = inventoryRepository,
            commands = inventoryCommandService,
            counts = inventoryCountService,
            lots = inventoryLotService,
            waste = inventoryWasteService,
            transfers = inventoryTransferService,
            reads = inventoryReadService,
            replenishment = inventoryReplenishmentService,
            integrity = inventoryIntegrityService,
        )
    }

    val operationsRepository: OperationsRepository by lazy {
        LocalOperationsRepository(
            database,
            syncRecorder = syncRecorder,
            authorizer = authorizer,
            sensitiveActionGate = sensitiveActionGate,
            inventoryRepository = inventoryRepository,
            inventoryWasteService = inventoryWasteService,
        )
    }

    val operationsInventoryUseCases: OperationsInventoryUseCases by lazy {
        OperationsInventoryUseCases(operationsRepository, securityRepository)
    }

    val securityRepository: SecurityRepository by lazy {
        LocalSecurityRepository(
            database,
            authorizer = authorizer,
            sensitiveActionGate = sensitiveActionGate,
            deviceIdProvider = { deviceId },
        )
    }

    val personnelRepository: PersonnelRepository by lazy { LocalPersonnelRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val personnelUseCases: PersonnelUseCases by lazy { PersonnelUseCases(personnelRepository) }
    val attendanceUseCases: AttendanceUseCases by lazy { AttendanceUseCases(personnelRepository) }
    val performanceRepository by lazy { LocalPerformanceRepository(database, authorizer = authorizer, syncRecorder = syncRecorder) }
    val syncRepository by lazy { LocalSyncRepository(database) }
    private val syncPreferences by lazy { appContext.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE) }
    fun syncConfig(): CloudSyncConfig = CloudSyncConfig(
        endpoint = syncPreferences.getString("endpoint", "").orEmpty(),
        organizationId = syncPreferences.getString("organization_id", null)
            ?: syncPreferences.getString("tenant", "").orEmpty(),
        enabled = syncPreferences.getBoolean("enabled", false) && SyncSafetyGate.isProductionReady,
        accessToken = syncPreferences.getString("access_token_protected", null)?.let(keyProvider::unprotectSecret)
            ?: syncPreferences.getString("access_token", "").orEmpty(),
        refreshToken = syncPreferences.getString("refresh_token_protected", null)?.let(keyProvider::unprotectSecret)
            ?: syncPreferences.getString("refresh_token", "").orEmpty(),
        accessTokenExpiresAtEpochMillis = syncPreferences.getLong("access_expires_at", 0),
        deviceId = deviceId,
    )
    private fun persistSyncConfig(config: CloudSyncConfig) {
        check(
            syncPreferences.edit()
                .putString("endpoint", config.endpoint.trim())
                .putString("organization_id", config.organizationId.trim())
                .remove("tenant")
                .putBoolean("enabled", config.enabled)
                .putString("access_token_protected", keyProvider.protectSecret(config.accessToken))
                .putString("refresh_token_protected", keyProvider.protectSecret(config.refreshToken))
                .remove("access_token")
                .remove("refresh_token")
                .putLong("access_expires_at", config.accessTokenExpiresAtEpochMillis)
                .commit(),
        )
    }
    suspend fun saveSyncConfig(config: CloudSyncConfig) { authorizer.require(Permission.BACKUP); if(config.enabled) SyncSafetyGate.requireProductionReady(); val normalized=config.copy(deviceId=deviceId,enabled=false); persistSyncConfig(normalized) }
    suspend fun runSync(): ir.restaurant.management.data.repository.SyncRunResult { SyncSafetyGate.requireProductionReady(); var config=syncConfig(); if(config.enabled && config.accessTokenExpired){config=ir.restaurant.management.data.repository.SyncTokenRefresher().refresh(config);persistSyncConfig(config)}; return SyncCoordinator(syncRepository,HttpsSyncTransport(config)).runOnce() }
    suspend fun runSyncAuthorized() = authorizer.require(Permission.BACKUP).let { runSync() }
    suspend fun resolveSyncIssueAuthorized(changeId:String,keepLocal:Boolean){authorizer.require(Permission.BACKUP);syncRepository.resolveIssue(changeId,keepLocal)}
    val syncRecorder by lazy { SyncRecorder(database, deviceId) }
    val assetRepository: AssetRepository by lazy { LocalAssetRepository(database, syncRecorder = syncRecorder, authorizer = authorizer) }
    val assetUseCases: AssetUseCases by lazy { AssetUseCases(assetRepository) }
    val alertRepository: AlertRepository by lazy { LocalAlertRepository(database) }
    val managementControlRepository: ManagementControlRepository by lazy {
        LocalManagementControlRepository(
            database,
            procurementRepository,
            authorizer,
            syncRecorder = syncRecorder,
            sensitiveActionGate = sensitiveActionGate,
            inventoryRepository = inventoryRepository,
            inventoryTransferService = inventoryTransferService,
        )
    }

    suspend fun createBackup(): String {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) {
            backupManager.create(database).also { backupManager.prune(BackupPolicyStore(appContext).load().maxFiles) }
        }
    }
    internal suspend fun createAutomaticBackup(maxFiles: Int): String = withContext(Dispatchers.IO) {
        backupManager.create(database).also { backupManager.prune(maxFiles) }
    }
    suspend fun factoryReset() {
        authorizer.require(Permission.MANAGE_USERS)
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.FACTORY_RESET)
        withContext(Dispatchers.IO) {
            database.clearAllTablesForFactoryReset()
            AccountSeedCallback.seedMissingAccounts(database.openHelper.writableDatabase)
            AccountSeedCallback.seedSystemLocations(database.openHelper.writableDatabase)
            backupManager.clearAll()
            listOf("cloud_sync", "sync_identity", "automatic_backup_policy").forEach { name ->
                check(appContext.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear().commit()) {
                    "پاک‌سازی تنظیمات $name انجام نشد."
                }
            }
        }
    }
    suspend fun listBackups(): List<String> {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) { backupManager.list() }
    }
    suspend fun describeBackups(): List<BackupDescriptor> {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) {
            val visibleNames = backupManager.list().toSet()
            backupManager.describe().filter { it.name in visibleNames }
        }
    }
    suspend fun deleteBackup(name: String) {
        authorizer.require(Permission.BACKUP)
        withContext(Dispatchers.IO) { backupManager.delete(name) }
    }
    suspend fun scheduleRestore(name: String) {
        authorizer.require(Permission.BACKUP)
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.RESTORE_BACKUP)
        withContext(Dispatchers.IO) {
            require(backupManager.verify(name)) { "فایل پشتیبان معتبر نیست یا تغییر کرده است." }
            val recoveryName = backupManager.create(database)
            try {
                backupManager.scheduleRestore(name, recoveryName)
            } catch (error: Throwable) {
                runCatching { backupManager.delete(recoveryName) }
                throw error
            }
        }
    }
    suspend fun exportBackup(name: String, password: CharArray, destination: Uri) {
        authorizer.require(Permission.BACKUP)
        withContext(Dispatchers.IO) {
            val output = requireNotNull(appContext.contentResolver.openOutputStream(destination, "w")) {
                "امکان نوشتن فایل مقصد وجود ندارد."
            }
            output.use { backupManager.exportPortable(name, password, it) }
        }
    }
    suspend fun importBackup(source: Uri, password: CharArray): String {
        authorizer.require(Permission.BACKUP)
        return withContext(Dispatchers.IO) {
            val input = requireNotNull(appContext.contentResolver.openInputStream(source)) {
                "امکان خواندن فایل انتخاب‌شده وجود ندارد."
            }
            backupManager.importPortable(input, password).also { backupManager.prune(BackupPolicyStore(appContext).load().maxFiles) }
        }
    }

    val accountingRepository: AccountingRepository by lazy {
        LocalAccountingRepository(database, syncRecorder = syncRecorder, authorizer = authorizer)
    }
    val accountingUseCases: AccountingUseCases by lazy { AccountingUseCases(accountingRepository) }
}
