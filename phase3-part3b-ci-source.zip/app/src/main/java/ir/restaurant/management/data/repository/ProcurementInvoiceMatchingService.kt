package ir.restaurant.management.data.repository

import ir.restaurant.management.core.toLongExactCompat
import androidx.room.withTransaction
import ir.restaurant.management.core.CorrelationId
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.core.QuantityMicros
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.ProcurementInvoiceLinkEntity
import ir.restaurant.management.data.db.PurchaseEntity
import ir.restaurant.management.data.db.PurchaseLineEntity
import ir.restaurant.management.domain.accounting.AccountingPostingCommand
import ir.restaurant.management.domain.accounting.AccountingPostingService
import ir.restaurant.management.domain.accounting.AccountingScope
import ir.restaurant.management.domain.accounting.SemanticAccountRole
import ir.restaurant.management.domain.accounting.SemanticJournalLine
import ir.restaurant.management.domain.purchase.PostedPurchase
import ir.restaurant.management.domain.purchase.PurchaseCalculator
import ir.restaurant.management.domain.purchase.PurchaseDraft
import ir.restaurant.management.domain.purchase.PurchaseOrderStatus
import ir.restaurant.management.domain.purchase.PurchasePaymentMethod
import ir.restaurant.management.domain.purchase.PurchasePaymentStatus
import ir.restaurant.management.domain.purchase.ThreeWayMatchResult
import ir.restaurant.management.domain.purchase.ThreeWayMatchStatus
import ir.restaurant.management.domain.security.AuthorizationService
import ir.restaurant.management.domain.security.Permission
import java.math.BigInteger
import kotlin.math.abs

/** Procurement-owned approval and persistence boundary for PO/receipt/invoice matching. */
internal class ProcurementInvoiceMatchingService(
    private val database: AppDatabase,
    private val authorizer: AuthorizationService,
    private val accountingPosting: AccountingPostingService,
    private val clock: () -> Long,
    private val syncRecorder: SyncRecorder?,
) {
    private val branchResolver = CanonicalBranchResolver(database)

    suspend fun preview(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
    ): ThreeWayMatchResult = database.withTransaction { calculateMatch(purchaseOrderId, invoice) }

    suspend fun post(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
        approvePriceVariance: Boolean,
    ): PostedPurchase {
        val actor = authorizer.require(Permission.PURCHASES)
        val prepared = PurchaseCalculator.prepare(invoice)
        val now = clock()
        return database.withTransaction {
            val branch = branchResolver.resolveOptional(prepared.draft.branchId, prepared.draft.branchName)
            val order = database.procurementDao().orderById(purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(order.status == PurchaseOrderStatus.RECEIVED.name) {
                "برای تطبیق فاکتور، دریافت سفارش باید کامل باشد."
            }
            require(order.supplierId == prepared.draft.supplierId) {
                "تأمین‌کننده فاکتور با سفارش یکسان نیست."
            }
            require(prepared.draft.purchaseEpochDay >= order.orderEpochDay) {
                "تاریخ فاکتور نمی‌تواند قبل از سفارش خرید باشد."
            }
            require(!database.procurementDao().orderHasInvoice(order.id)) {
                "برای این سفارش قبلاً فاکتور ثبت شده است."
            }
            require(!database.purchaseDao().invoiceExists(prepared.draft.invoiceNo)) {
                "شماره فاکتور خرید تکراری است."
            }
            val match = calculateMatch(order.id, prepared.draft)
            require(match.status != ThreeWayMatchStatus.QUANTITY_VARIANCE) {
                "مقدار فاکتور با کالای پذیرفته‌شده یکسان نیست."
            }
            val requiresApproval = match.status == ThreeWayMatchStatus.PRICE_VARIANCE &&
                match.priceVarianceBasisPoints > PRICE_VARIANCE_APPROVAL_BASIS_POINTS
            val varianceApprover = if (requiresApproval) {
                require(approvePriceVariance) { "مغایرت قیمت بیش از ۵٪ است و تأیید مدیر لازم دارد." }
                authorizer.require(Permission.AUDIT)
            } else {
                null
            }
            val paid = prepared.draft.paymentMethod != PurchasePaymentMethod.PAYABLE
            val purchaseId = database.purchaseDao().insert(
                PurchaseEntity(
                    invoiceNo = prepared.draft.invoiceNo,
                    supplierId = order.supplierId,
                    purchaseEpochDay = prepared.draft.purchaseEpochDay,
                    branchName = branch?.name.orEmpty(),
                    branchId = branch?.id,
                    dueEpochDay = prepared.draft.dueEpochDay,
                    totalRial = prepared.total.value,
                    paidRial = if (paid) prepared.total.value else 0,
                    paymentStatus = if (paid) {
                        PurchasePaymentStatus.PAID.storedValue
                    } else {
                        PurchasePaymentStatus.UNPAID.storedValue
                    },
                    paymentMethod = prepared.draft.paymentMethod.storedValue,
                    reminderEnabled = !paid && prepared.draft.reminderEnabled,
                    reminderEpochDay = if (!paid && prepared.draft.reminderEnabled) {
                        prepared.draft.reminderEpochDay
                    } else {
                        null
                    },
                    createdAtEpochMillis = now,
                ),
            )
            val items = database.procurementDao().orderLines(order.id).associateBy { it.itemId }
            database.purchaseDao().insertLines(
                prepared.lines.map { line ->
                    val ordered = items[line.itemId] ?: error("کالای فاکتور در سفارش وجود ندارد.")
                    PurchaseLineEntity(
                        purchaseId = purchaseId,
                        itemId = line.itemId,
                        itemNameSnapshot = ordered.itemNameSnapshot,
                        quantityMicros = line.quantityMicros,
                        unitCostRial = line.unitCostRial,
                        lineTotalRial = line.total.value,
                    )
                },
            )
            val journalLines = buildList {
                add(
                    SemanticJournalLine(
                        SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED,
                        debit = MoneyRial.of(match.acceptedValueRial),
                    ),
                )
                if (match.priceVarianceRial > 0) {
                    add(
                        SemanticJournalLine(
                            SemanticAccountRole.PURCHASE_PRICE_VARIANCE,
                            debit = MoneyRial.of(match.priceVarianceRial),
                        ),
                    )
                } else if (match.priceVarianceRial < 0) {
                    add(
                        SemanticJournalLine(
                            SemanticAccountRole.PURCHASE_PRICE_VARIANCE,
                            credit = MoneyRial.of(-match.priceVarianceRial),
                        ),
                    )
                }
                add(SemanticJournalLine(prepared.draft.paymentMethod.settlementRole, credit = prepared.total))
            }
            val journalId = accountingPosting.post(
                AccountingPostingCommand(
                    entryNo = "تخ-$purchaseId",
                    businessEpochDay = prepared.draft.purchaseEpochDay,
                    description = "تطبیق فاکتور ${prepared.draft.invoiceNo} با ${order.orderNo}",
                    sourceType = "PROCUREMENT_INVOICE",
                    sourceId = purchaseId,
                    accountingScope = if (branch != null) AccountingScope.BRANCH else AccountingScope.ORGANIZATION,
                    branchId = branch?.id,
                    lines = journalLines,
                    idempotencyKey = "PROCUREMENT_INVOICE:$purchaseId:post",
                    correlationId = CorrelationId.parse("procurement_invoice:$purchaseId"),
                    actorId = actor.id,
                ),
            ).entryId
            database.procurementDao().insertInvoiceLink(
                ProcurementInvoiceLinkEntity(
                    purchaseOrderId = order.id,
                    purchaseId = purchaseId,
                    matchStatus = match.status.name,
                    acceptedValueRial = match.acceptedValueRial,
                    invoiceValueRial = match.invoiceValueRial,
                    priceVarianceRial = match.priceVarianceRial,
                    varianceApprovedBy = varianceApprover?.displayName,
                    matchedAtEpochMillis = now,
                ),
            )
            check(database.procurementDao().updateOrderStatus(order.id, PurchaseOrderStatus.CLOSED.name, now) == 1) {
                "بستن سفارش انجام نشد."
            }
            database.managementControlDao().transitionCommitment(
                referenceType = "PURCHASE_REQUISITION",
                referenceId = order.requisitionId,
                status = "CONSUMED",
                now = now,
            )
            syncRecorder?.record("PURCHASE", purchaseId, "THREE_WAY_MATCH", now)
            PostedPurchase(purchaseId, journalId, prepared.total)
        }
    }

    private suspend fun calculateMatch(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
    ): ThreeWayMatchResult {
        val prepared = PurchaseCalculator.prepare(invoice)
        val accepted = database.procurementDao().orderLines(purchaseOrderId)
        require(accepted.isNotEmpty()) { "ردیف‌های سفارش پیدا نشدند." }
        val invoiceQty = prepared.lines.associate { it.itemId to it.quantityMicros }
        val acceptedQty = accepted
            .map { it.itemId to (it.receivedQtyMicros - it.returnedQtyMicros) }
            .filter { it.second > 0 }
            .toMap()
        val quantityMatches = invoiceQty == acceptedQty
        val acceptedValue = MoneyRial.sum(
            accepted.map {
                MoneyRial.of(it.unitCostRial).times(
                    QuantityMicros.of(it.receivedQtyMicros - it.returnedQtyMicros),
                )
            },
        ).value
        val variance = prepared.total.value - acceptedValue
        val basisPoints = if (acceptedValue == 0L) {
            0L
        } else {
            BigInteger.valueOf(abs(variance))
                .multiply(BigInteger.valueOf(10_000))
                .divide(BigInteger.valueOf(acceptedValue))
                .toLongExactCompat()
        }
        val status = when {
            !quantityMatches -> ThreeWayMatchStatus.QUANTITY_VARIANCE
            variance != 0L -> ThreeWayMatchStatus.PRICE_VARIANCE
            else -> ThreeWayMatchStatus.MATCHED
        }
        return ThreeWayMatchResult(status, acceptedValue, prepared.total.value, variance, basisPoints)
    }

    private companion object {
        const val PRICE_VARIANCE_APPROVAL_BASIS_POINTS = 500L
    }
}
