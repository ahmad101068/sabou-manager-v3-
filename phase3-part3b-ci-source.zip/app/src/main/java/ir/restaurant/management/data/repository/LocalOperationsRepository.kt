package ir.restaurant.management.data.repository

import ir.restaurant.management.domain.security.Permission

import androidx.room.withTransaction
import ir.restaurant.management.core.SignedLongMath
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.InventoryItemEntity
import ir.restaurant.management.data.db.InventoryCountEntity
import ir.restaurant.management.data.db.InventoryPeriodClosureEntity
import ir.restaurant.management.data.db.InventoryPeriodClosureLineEntity
import ir.restaurant.management.data.db.StockMovementEntity
import ir.restaurant.management.data.db.SupplierEntity
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.data.security.SensitiveActionGate
import ir.restaurant.management.domain.operations.InventoryItemDraft
import ir.restaurant.management.domain.operations.InventoryCountDraft
import ir.restaurant.management.domain.operations.InventoryCountRecord
import ir.restaurant.management.domain.operations.InventoryPeriodCloseDraft
import ir.restaurant.management.domain.operations.InventoryPeriodReopenDraft
import ir.restaurant.management.domain.operations.InventoryPeriodClosureRecord
import ir.restaurant.management.domain.operations.InventoryPeriodStatus
import ir.restaurant.management.domain.operations.InventoryPeriodClosureDetails
import ir.restaurant.management.domain.operations.InventoryPeriodClosureLineRecord
import ir.restaurant.management.domain.operations.InventoryPeriodCalculator
import ir.restaurant.management.domain.operations.AuditLogRecord
import ir.restaurant.management.domain.operations.AuditLogQuery
import ir.restaurant.management.domain.operations.InventoryItemRecord
import ir.restaurant.management.domain.operations.StockMovementRecord
import ir.restaurant.management.domain.operations.InventoryUsageInsight
import ir.restaurant.management.domain.operations.OperationsRepository
import ir.restaurant.management.domain.operations.SensitiveAction
import ir.restaurant.management.domain.operations.PurchaseSummary
import ir.restaurant.management.domain.operations.PurchaseDashboardSummary
import ir.restaurant.management.domain.operations.SupplierPriceInsight
import ir.restaurant.management.domain.operations.SupplierDraft
import ir.restaurant.management.domain.operations.SupplierRecord
import ir.restaurant.management.domain.operations.WasteDraft
import ir.restaurant.management.domain.operations.WasteRecord
import ir.restaurant.management.domain.purchase.PurchasePaymentStatus
import ir.restaurant.management.domain.purchase.PurchasePaymentMethod
import ir.restaurant.management.domain.inventory.InventoryCommandContext
import ir.restaurant.management.domain.inventory.InventoryMovementType
import ir.restaurant.management.domain.inventory.InventoryReasonCode
import ir.restaurant.management.domain.inventory.InventoryReferenceType
import ir.restaurant.management.domain.inventory.InventorySku
import ir.restaurant.management.domain.inventory.InventoryItemType
import ir.restaurant.management.domain.inventory.InventoryStorageCondition
import ir.restaurant.management.domain.inventory.InventoryItemMasterDraft
import ir.restaurant.management.domain.inventory.InventoryRepository
import ir.restaurant.management.domain.inventory.CreateWasteCommand
import ir.restaurant.management.domain.inventory.InventoryWasteService
import ir.restaurant.management.domain.inventory.WasteReason
import ir.restaurant.management.domain.common.BusinessError
import ir.restaurant.management.domain.common.asViolation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.combine

class LocalOperationsRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
    private val sensitiveActionGate: SensitiveActionGate = SensitiveActionGate(),
    private val inventoryRepository: InventoryRepository = LocalInventoryRepository(
        database = database,
        authorizer = authorizer,
        clock = clock,
        syncRecorder = syncRecorder,
    ),
    private val inventoryWasteService: InventoryWasteService = LocalInventoryWasteService(
        database = database,
        authorizer = authorizer,
        clock = clock,
        syncRecorder = syncRecorder,
    ),
) : OperationsRepository {
    private val auditWriter = LocalAuditEventWriter(database)
    override val recentStockMovements: Flow<List<StockMovementRecord>> =
        database.stockMovementDao().observeRecent().map { rows -> rows.map { it.toRecord() } }

    override fun stockMovements(itemId: Long): Flow<List<StockMovementRecord>> {
        require(itemId > 0) { "کالای انتخاب‌شده معتبر نیست." }
        return database.stockMovementDao().observeForItem(itemId).map { rows ->
            rows.map { it.toRecord() }
        }
    }
    override val suppliers: Flow<List<SupplierRecord>> =
        database.supplierDao().observeActive().map { rows -> rows.map(SupplierEntity::toRecord) }

    override val inventoryItems: Flow<List<InventoryItemRecord>> =
        database.inventoryDao().observeActive().map { rows -> rows.map(InventoryItemEntity::toRecord) }

    override val lowStockItems: Flow<List<InventoryItemRecord>> =
        database.inventoryDao().observeLowStock().map { rows -> rows.map(InventoryItemEntity::toRecord) }

    override val inventoryCounts: Flow<List<InventoryCountRecord>> =
        database.inventoryControlDao().observeRecentCounts().map { rows -> rows.map { InventoryCountRecord(it.id, it.itemId, it.previousQuantityMicros, it.countedQuantityMicros, it.previousValueRial, it.countedValueRial, it.countEpochDay, it.reason) } }

    override val inventoryPeriodClosures: Flow<List<InventoryPeriodClosureRecord>> =
        database.inventoryControlDao().observeClosures().map { rows ->
            rows.map { it.toRecord() }
        }

    override fun inventoryPeriodClosureDetails(closureId: Long): Flow<InventoryPeriodClosureDetails?> = combine(
        database.inventoryControlDao().observeClosure(closureId),
        database.inventoryControlDao().observeClosureLines(closureId),
    ) { closure, lines ->
        closure?.let {
            InventoryPeriodClosureDetails(
                closure = it.toRecord(),
                lines = lines.map { line ->
                    InventoryPeriodClosureLineRecord(
                        line.itemId, line.itemNameSnapshot, line.unitSnapshot,
                        line.openingQuantityMicros, line.openingValueRial,
                        line.netPurchaseQuantityMicros, line.netPurchaseValueRial,
                        line.recordedOutflowQuantityMicros, line.recordedOutflowValueRial,
                        line.adjustmentQuantityMicros, line.adjustmentValueRial,
                        line.expectedClosingQuantityMicros, line.expectedClosingValueRial,
                        line.countedClosingQuantityMicros, line.countedClosingValueRial,
                    )
                },
            )
        }
    }

    override fun auditLogs(query: AuditLogQuery): Flow<List<AuditLogRecord>> {
        val zone = java.time.ZoneId.systemDefault()
        val fromMillis = query.fromEpochDay?.let { java.time.LocalDate.ofEpochDay(it).atStartOfDay(zone).toInstant().toEpochMilli() }
        val toExclusiveMillis = query.toEpochDay?.let { java.time.LocalDate.ofEpochDay(it + 1L).atStartOfDay(zone).toInstant().toEpochMilli() }
        return database.auditLogDao().observeFiltered(
            search = query.search.trim(),
            actor = query.actor.trim(),
            action = query.action.trim().uppercase(),
            entityType = query.entityType.trim().uppercase(),
            entityId = query.entityId,
            sourceReference = query.sourceReference.trim(),
            severity = query.severity.trim().uppercase(),
            fromMillis = fromMillis,
            toExclusiveMillis = toExclusiveMillis,
        ).map { rows ->
            rows.map { row ->
                AuditLogRecord(
                    id = row.id, action = row.action, entityType = row.entityType, entityId = row.entityId,
                    description = row.description, actor = row.actor, createdAtEpochMillis = row.createdAtEpochMillis,
                    actorId = row.actorId, referenceType = row.referenceType, referenceId = row.referenceId,
                    reason = row.reason, beforeSnapshot = row.beforeSnapshot, afterSnapshot = row.afterSnapshot,
                    correlationId = row.correlationId,
                )
            }
        }
    }

    override val usageInsights: Flow<List<InventoryUsageInsight>> =
        database.stockMovementDao().observeUsageSince((clock() / 86_400_000L) - 29L).map { rows ->
            rows.map { row ->
                InventoryUsageInsight(
                    itemId = row.itemId,
                    itemName = row.itemName,
                    unit = row.unit,
                    usageMicros30Days = row.usageMicros,
                    averageDailyUsageMicros = row.usageMicros / 30L,
                )
            }
        }

    override val supplierPriceInsights: Flow<List<SupplierPriceInsight>> =
        database.purchaseDao().observeSupplierPriceInsights().map { rows ->
            rows.map { row ->
                SupplierPriceInsight(
                    itemId = row.itemId,
                    itemName = row.itemName,
                    supplierName = row.supplierName,
                    latestUnitCostRial = row.latestUnitCostRial,
                    previousUnitCostRial = row.previousUnitCostRial,
                )
            }
        }

    override val wasteRecords: Flow<List<WasteRecord>> =
        database.stockMovementDao().observeWasteRecords().map { rows ->
            rows.map { row ->
                WasteRecord(
                    id = row.id,
                    itemId = row.itemId,
                    itemName = row.itemName,
                    unit = row.unit,
                    quantityMicros = row.quantityMicros,
                    valueRial = row.valueRial,
                    wasteEpochDay = row.wasteEpochDay,
                    reason = row.reason,
                )
            }
        }

    override fun purchases(query: String): Flow<List<PurchaseSummary>> =
        database.purchaseDao().observeSearch(query.trim()).map { rows ->
            rows.map { row ->
                PurchaseSummary(
                    id = row.purchaseId,
                    invoiceNo = row.invoiceNo,
                    supplierName = row.supplierName,
                    purchaseEpochDay = row.purchaseEpochDay,
                    dueEpochDay = row.dueEpochDay,
                    totalRial = row.totalRial,
                    paidRial = row.paidRial,
                    paymentStatus = PurchasePaymentStatus.fromStoredValue(row.paymentStatus),
                    paymentMethod = PurchasePaymentMethod.fromStored(row.paymentMethod),
                    reminderEnabled = row.reminderEnabled,
                    reminderEpochDay = row.reminderEpochDay,
                )
            }
        }

    override fun purchaseDashboardSummary(fromEpochDay: Long, toEpochDay: Long, todayEpochDay: Long): Flow<PurchaseDashboardSummary> {
        require(fromEpochDay > 0 && toEpochDay >= fromEpochDay) { "بازه داشبورد خرید معتبر نیست." }
        return database.purchaseDao().observeDashboardSummary(fromEpochDay, toEpochDay, todayEpochDay).map { row ->
            PurchaseDashboardSummary(
                periodPurchaseRial = row.periodPurchaseRial,
                openOrderCount = row.openOrderCount,
                activeSupplierCount = row.activeSupplierCount,
                supplierPayablesRial = row.supplierPayablesRial,
                pendingReceiptCount = row.pendingReceiptCount,
                openRequisitionCount = row.openRequisitionCount,
                pendingApprovalCount = row.pendingApprovalCount,
                overdueOrderCount = row.overdueOrderCount,
            )
        }
    }

    override suspend fun createSupplier(draft: SupplierDraft): Long {
        authorizer.require(Permission.SUPPLIERS)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val previous = database.supplierDao().byName(valid.name)
            if (previous != null) {
                require(!previous.isActive) { "تأمین‌کننده‌ای با این نام وجود دارد." }
                check(
                    database.supplierDao().update(
                        previous.copy(
                            contactName = valid.contactName,
                            phone = valid.phone,
                            address = valid.address,
                            paymentTermsDays = valid.paymentTermsDays,
                            notes = valid.notes,
                            isActive = true,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "فعال‌سازی دوباره تأمین‌کننده انجام نشد." }
                syncRecorder?.record("SUPPLIER", previous.id, "UPSERT", now)
                return@withTransaction previous.id
            }
            val id = database.supplierDao().insert(
                SupplierEntity(
                    name = valid.name,
                    contactName = valid.contactName,
                    phone = valid.phone,
                    address = valid.address,
                    paymentTermsDays = valid.paymentTermsDays,
                    notes = valid.notes,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            syncRecorder?.record("SUPPLIER", id, "CREATE", now)
            id
        }
    }

    override suspend fun updateSupplier(id: Long, draft: SupplierDraft) {
        authorizer.require(Permission.SUPPLIERS)
        val current = database.supplierDao().activeById(id)
            ?: error("تأمین‌کننده پیدا نشد.")
        val valid = draft.validated()
        val now = clock()
        check(
            database.supplierDao().update(
                current.copy(
                    name = valid.name,
                    contactName = valid.contactName,
                    phone = valid.phone,
                    address = valid.address,
                    paymentTermsDays = valid.paymentTermsDays,
                    notes = valid.notes,
                    updatedAtEpochMillis = now,
                ),
            ) == 1,
        ) { "ویرایش تأمین‌کننده انجام نشد." }
        syncRecorder?.record("SUPPLIER", id, "UPDATE", now)
    }

    override suspend fun deactivateSupplier(id: Long) {
        authorizer.require(Permission.SUPPLIERS)
        database.withTransaction {
            val now = clock()
            check(database.supplierDao().deactivate(id, now) == 1) {
                "حذف تأمین‌کننده انجام نشد."
            }
            database.inventoryDao().clearSupplierReference(id, now)
            syncRecorder?.record("SUPPLIER", id, "DEACTIVATE", now)
        }
    }

    override suspend fun createInventoryItem(draft: InventoryItemDraft): Long {
        val valid = draft.validated()
        val stableSku = database.inventoryDao().byName(valid.name)?.sku ?: InventorySku.generated().value
        return inventoryRepository.saveItem(null, valid.toMasterDraft(stableSku))
    }

    override suspend fun updateInventoryItem(id: Long, draft: InventoryItemDraft) {
        val current = database.inventoryDao().activeById(id)
            ?: throw BusinessError.EntityNotFound("INVENTORY_ITEM", id).asViolation()
        val valid = draft.validated()
        inventoryRepository.saveItem(id, valid.toMasterDraft(current.sku))
    }

    override suspend fun deactivateInventoryItem(id: Long) = inventoryRepository.deactivateItem(id)

    override suspend fun postInventoryCount(draft: InventoryCountDraft): Long {
        val actor = authorizer.require(Permission.INVENTORY_ADJUST)
        sensitiveActionGate.requireAndConsume(actor.id, SensitiveAction.ADJUST_INVENTORY)
        val valid = draft.validated()
        return database.withTransaction {
            val idempotencyKey = "inventory_count:${valid.commandId}"
            val correlationId = idempotencyKey
            database.inventoryControlDao().countByIdempotencyKey(idempotencyKey)?.let { existing ->
                val samePayload = existing.itemId == valid.itemId &&
                    existing.countedQuantityMicros == valid.countedQuantityMicros &&
                    existing.countedValueRial == valid.countedValueRial &&
                    existing.countEpochDay == valid.countEpochDay &&
                    existing.reason == valid.reason &&
                    existing.actorId == actor.id
                if (!samePayload) throw BusinessError.IdempotencyConflict(idempotencyKey).asViolation()
                return@withTransaction existing.id
            }
            val current = database.inventoryDao().activeById(valid.itemId) ?: error("کالا پیدا نشد.")
            val now = clock()
            val locationId = database.managementControlDao().defaultLocationId()
                ?: error("محل پیش‌فرض انبار تنظیم نشده است.")
            val countId = database.inventoryControlDao().insertCount(
                InventoryCountEntity(
                    itemId = current.id, previousQuantityMicros = current.stockMicros,
                    countedQuantityMicros = valid.countedQuantityMicros, previousValueRial = current.inventoryValueRial,
                    countedValueRial = valid.countedValueRial, countEpochDay = valid.countEpochDay,
                    reason = valid.reason, createdAtEpochMillis = now,
                    globalId = valid.commandId,
                    idempotencyKey = idempotencyKey,
                    correlationId = correlationId,
                    actorId = actor.id,
                    deviceId = "local-android",
                    locationId = locationId,
                ),
            )
            if (
                current.stockMicros != valid.countedQuantityMicros ||
                current.inventoryValueRial != valid.countedValueRial
            ) {
                LocalInventoryCommandEngine(database, clock = { now }).adjustToCount(
                    itemId = current.id,
                    countedQuantityMicros = valid.countedQuantityMicros,
                    countedValueRial = valid.countedValueRial,
                    referenceId = countId,
                    movementEpochDay = valid.countEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.INVENTORY_COUNT,
                        referenceId = countId,
                        suffix = "adjust:${current.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.PHYSICAL_COUNT,
                        reason = valid.reason,
                        correlationId = correlationId,
                        locationId = locationId,
                    ),
                    notes = valid.reason,
                )
            }
            audit(
                action = "INVENTORY_COUNT",
                entityType = "INVENTORY_ITEM",
                entityId = current.id,
                description = "انبارگردانی ${current.name}: ${current.stockMicros} → ${valid.countedQuantityMicros}",
                now = now,
                businessEpochDay = valid.countEpochDay,
                reason = valid.reason,
                beforeSnapshot = "quantityMicros=${current.stockMicros};valueRial=${current.inventoryValueRial}",
                afterSnapshot = "quantityMicros=${valid.countedQuantityMicros};valueRial=${valid.countedValueRial}",
                correlationId = correlationId,
            )
            countId
        }
    }

    override suspend fun closeInventoryPeriod(draft: InventoryPeriodCloseDraft): Long {
        authorizer.require(Permission.INVENTORY)
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.CLOSE_INVENTORY_PERIOD)
        val valid = draft.validated()
        return database.withTransaction {
            val control = database.inventoryControlDao()
            val previousClosure = control.closureByRange(valid.fromEpochDay, valid.toEpochDay)
            require(previousClosure?.status != "CLOSED") { "این دوره قبلاً بسته شده است." }
            require(!control.closureOverlaps(valid.fromEpochDay, valid.toEpochDay)) { "این بازه با دوره بسته‌شده دیگری هم‌پوشانی دارد." }
            control.lastClosedEpochDay()?.let { lastDay ->
                require(valid.fromEpochDay == lastDay + 1L) { "دوره جدید باید از روز بعد آخرین دوره بسته‌شده شروع شود." }
            }
            val items = database.inventoryDao().activeItems()
            require(items.isNotEmpty()) { "برای بستن دوره، کالای فعال وجود ندارد." }
            val latestCounts = control.countsOnDay(valid.toEpochDay)
                .groupBy { it.itemId }
                .mapValues { (_, rows) -> rows.maxBy { it.createdAtEpochMillis } }
            val missing = items.filter { latestCounts[it.id] == null }.map { it.name }
            require(missing.isEmpty()) { "ابتدا در تاریخ پایان دوره برای همه کالاها انبارگردانی ثبت کنید: ${missing.take(6).joinToString("، ")}" }
            val stale = items.filter { item ->
                val count = latestCounts.getValue(item.id)
                count.countedQuantityMicros != item.stockMicros || count.countedValueRial != item.inventoryValueRial
            }.map { it.name }
            require(stale.isEmpty()) { "پس از آخرین شمارش این کالاها گردش جدید ثبت شده؛ دوباره شمارش کنید: ${stale.take(6).joinToString("، ")}" }
            val totalsByItem = control.movementTotals(valid.fromEpochDay, valid.toEpochDay).associateBy { it.itemId }
            val calculations = items.associateWith { item ->
                val totals = totalsByItem[item.id]
                InventoryPeriodCalculator.calculate(
                    countedClosingQuantityMicros = item.stockMicros,
                    countedClosingValueRial = item.inventoryValueRial,
                    netMovementQuantityMicros = totals?.netQuantityMicros ?: 0,
                    netMovementValueRial = totals?.netValueRial ?: 0,
                    netPurchaseQuantityMicros = totals?.netPurchaseQuantityMicros ?: 0,
                    netPurchaseValueRial = totals?.netPurchaseValueRial ?: 0,
                    countAdjustmentQuantityMicros = totals?.countAdjustmentQuantityMicros ?: 0,
                    countAdjustmentValueRial = totals?.countAdjustmentValueRial ?: 0,
                )
            }
            fun total(selector: (ir.restaurant.management.domain.operations.InventoryPeriodLineCalculation) -> Long): Long =
                calculations.values.fold(0L) { sum, line -> SignedLongMath.add(sum, selector(line)) }
            val openingValue = total { it.openingValueRial }
            val purchases = total { it.netPurchaseValueRial }
            val outflow = total { it.recordedOutflowValueRial }
            val expected = total { it.expectedClosingValueRial }
            val counted = total { it.countedClosingValueRial }
            val variance = SignedLongMath.subtract(counted, expected)
            val now = clock()
            val refreshed = InventoryPeriodClosureEntity(
                id = previousClosure?.id ?: 0,
                fromEpochDay = valid.fromEpochDay, toEpochDay = valid.toEpochDay,
                openingValueRial = openingValue, netPurchaseValueRial = purchases,
                recordedOutflowValueRial = outflow, expectedClosingValueRial = expected,
                countedClosingValueRial = counted, varianceValueRial = variance,
                itemCount = items.size, status = "CLOSED", revisionNo = (previousClosure?.revisionNo ?: 0) + 1,
                closedBy = authorizer.actor(), note = valid.note,
                createdAtEpochMillis = now,
            )
            val closureId = if (previousClosure == null) {
                control.insertClosure(refreshed)
            } else {
                check(control.updateClosure(refreshed) == 1) { "بستن مجدد دوره انجام نشد." }
                control.deleteClosureLines(previousClosure.id)
                previousClosure.id
            }
            control.insertClosureLines(calculations.map { (item, line) ->
                InventoryPeriodClosureLineEntity(
                    closureId = closureId, itemId = item.id, itemNameSnapshot = item.name, unitSnapshot = item.unit,
                    openingQuantityMicros = line.openingQuantityMicros, openingValueRial = line.openingValueRial,
                    netPurchaseQuantityMicros = line.netPurchaseQuantityMicros, netPurchaseValueRial = line.netPurchaseValueRial,
                    recordedOutflowQuantityMicros = line.recordedOutflowQuantityMicros, recordedOutflowValueRial = line.recordedOutflowValueRial,
                    adjustmentQuantityMicros = line.adjustmentQuantityMicros, adjustmentValueRial = line.adjustmentValueRial,
                    expectedClosingQuantityMicros = line.expectedClosingQuantityMicros, expectedClosingValueRial = line.expectedClosingValueRial,
                    countedClosingQuantityMicros = line.countedClosingQuantityMicros, countedClosingValueRial = line.countedClosingValueRial,
                )
            })
            audit(
                action = "CLOSE",
                entityType = "INVENTORY_PERIOD",
                entityId = closureId,
                description = "بستن انبار ${valid.fromEpochDay} تا ${valid.toEpochDay}؛ مغایرت ارزش $variance ریال",
                now = now,
                businessEpochDay = valid.toEpochDay,
                reason = valid.note.ifBlank { "پایان دوره و تأیید شمارش‌ها" },
                afterSnapshot = "from=${valid.fromEpochDay};to=${valid.toEpochDay};varianceValueRial=$variance;status=CLOSED",
            )
            syncRecorder?.record("INVENTORY_PERIOD", closureId, "CLOSE", now)
            closureId
        }
    }

    override suspend fun reopenInventoryPeriod(draft: InventoryPeriodReopenDraft) {
        authorizer.requireOwner()
        sensitiveActionGate.requireAndConsume(authorizer.currentUserId(), SensitiveAction.REOPEN_INVENTORY_PERIOD)
        val valid = draft.validated()
        database.withTransaction {
            val control = database.inventoryControlDao()
            val closure = control.closureById(valid.closureId) ?: error("دوره انبار پیدا نشد.")
            require(InventoryPeriodStatus.fromStoredValue(closure.status) == InventoryPeriodStatus.CLOSED) { "این دوره در وضعیت بسته نیست." }
            require(control.latestClosedClosure()?.id == closure.id) { "فقط آخرین دوره بسته‌شده قابل بازگشایی است." }
            val actor = authorizer.actor()
            val now = clock()
            check(control.updateClosure(closure.copy(status = "REOPENED", reopenedBy = actor, reopenReason = valid.reason, reopenedAtEpochMillis = now)) == 1) {
                "بازگشایی دوره انبار انجام نشد."
            }
            audit(
                action = "REOPEN",
                entityType = "INVENTORY_PERIOD",
                entityId = closure.id,
                description = "بازگشایی کنترل‌شده انبار ${closure.fromEpochDay} تا ${closure.toEpochDay}: ${valid.reason}",
                now = now,
                businessEpochDay = closure.toEpochDay,
                reason = valid.reason,
                beforeSnapshot = "status=CLOSED",
                afterSnapshot = "status=REOPENED;reason=${valid.reason}",
            )
            syncRecorder?.record("INVENTORY_PERIOD", closure.id, "REOPEN", now)
        }
    }

    override suspend fun postWaste(draft: WasteDraft): Long {
        val actor = authorizer.require(Permission.INVENTORY_WASTE_CREATE)
        val valid = draft.validated()
        val locationId = database.inventoryLocationDao().defaultLocationId()
            ?: throw BusinessError.EntityNotFound("DEFAULT_STORAGE_LOCATION", null).asViolation()
        return inventoryWasteService.submitAndPost(
            CreateWasteCommand(
                itemId = valid.itemId,
                locationId = locationId,
                quantityMicros = valid.quantityMicros,
                reason = WasteReason.fromStoredInput(valid.reason),
                businessEpochDay = valid.wasteEpochDay,
                reasonDetail = valid.reason,
                notes = valid.notes,
                actorId = actor.id,
                commandId = valid.commandId,
                correlationId = "inventory_waste:${valid.commandId}",
            ),
        ).id
    }

    private fun InventoryPeriodClosureEntity.toRecord() = InventoryPeriodClosureRecord(
        id, fromEpochDay, toEpochDay, openingValueRial, netPurchaseValueRial,
        recordedOutflowValueRial, expectedClosingValueRial, countedClosingValueRial,
        varianceValueRial, itemCount, InventoryPeriodStatus.fromStoredValue(status), revisionNo, closedBy, note, reopenedBy, reopenReason,
    )

    private suspend fun log(action: String, entityType: String, entityId: Long?, description: String) =
        audit(action, entityType, entityId, description, clock())

    private suspend fun audit(
        action: String,
        entityType: String,
        entityId: Long?,
        description: String,
        now: Long,
        businessEpochDay: Long? = null,
        reason: String = description,
        beforeSnapshot: String? = null,
        afterSnapshot: String? = null,
        correlationId: String = "audit:$entityType:${entityId ?: 0}:$action:$now",
    ) {
        auditWriter.appendAuthorized(
            authorizer = authorizer,
            action = action,
            entityType = entityType,
            entityId = entityId,
            description = description,
            occurredAtEpochMillis = now,
            businessEpochDay = businessEpochDay,
            reason = reason,
            beforeSnapshot = beforeSnapshot,
            afterSnapshot = afterSnapshot,
            correlationId = correlationId,
        )
    }

}

private fun StockMovementEntity.toRecord() = StockMovementRecord(
    id = id,
    itemId = itemId,
    movementType = InventoryMovementType.fromStoredValue(movementType),
    quantityDeltaMicros = quantityDeltaMicros,
    valueDeltaRial = valueDeltaRial,
    referenceType = InventoryReferenceType.fromStoredValue(referenceType),
    referenceId = referenceId,
    movementEpochDay = movementEpochDay,
    notes = notes,
)

private fun SupplierEntity.toRecord() = SupplierRecord(
    id = id,
    name = name,
    contactName = contactName,
    phone = phone,
    address = address,
    paymentTermsDays = paymentTermsDays,
    notes = notes,
)

private fun InventoryItemDraft.toMasterDraft(fallbackSku: String) = InventoryItemMasterDraft(
    sku = sku.ifBlank { fallbackSku },
    name = name,
    category = category,
    itemType = itemType,
    baseUnit = unit,
    purchaseUnit = purchaseUnit,
    purchaseToBaseNumerator = purchaseToStockNumerator,
    purchaseToBaseDenominator = purchaseToStockDenominator,
    recipeUnit = recipeUnit,
    recipeToBaseNumerator = recipeToStockNumerator,
    recipeToBaseDenominator = recipeToStockDenominator,
    primaryBarcode = primaryBarcode,
    brand = brand,
    storageCondition = storageCondition,
    shelfLifeDays = shelfLifeDays,
    trackLot = trackLot,
    trackExpiry = trackExpiry,
    minimumStockMicros = minimumStockMicros.takeIf { it > 0 } ?: alertThresholdMicros,
    maximumStockMicros = maximumStockMicros,
    safetyStockMicros = safetyStockMicros,
    reorderPointMicros = reorderPointMicros.takeIf { it > 0 } ?: alertThresholdMicros,
    preferredSupplierId = supplierId,
    leadTimeDays = leadTimeDays,
)

private fun InventoryItemEntity.toRecord() = InventoryItemRecord(
    id = id,
    name = name,
    category = category,
    unit = unit,
    purchaseUnit = purchaseUnit,
    purchaseToStockNumerator = purchaseToStockNumerator,
    purchaseToStockDenominator = purchaseToStockDenominator,
    recipeUnit = recipeUnit,
    recipeToStockNumerator = recipeToStockNumerator,
    recipeToStockDenominator = recipeToStockDenominator,
    stockMicros = stockMicros,
    inventoryValueRial = inventoryValueRial,
    alertEnabled = alertEnabled,
    alertThresholdMicros = alertThresholdMicros,
    supplierId = supplierId,
    sku = sku,
    itemType = InventoryItemType.fromStoredValue(itemType),
    primaryBarcode = primaryBarcode,
    brand = brand,
    storageCondition = InventoryStorageCondition.fromStoredValue(storageCondition),
    shelfLifeDays = shelfLifeDays,
    trackLot = trackLot,
    trackExpiry = trackExpiry,
    minimumStockMicros = minimumStockMicros,
    maximumStockMicros = maximumStockMicros,
    safetyStockMicros = safetyStockMicros,
    reorderPointMicros = reorderPointMicros,
    leadTimeDays = leadTimeDays,
)
