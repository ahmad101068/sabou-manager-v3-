package ir.restaurant.management.data.repository

import androidx.room.withTransaction
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.BranchEntity
import ir.restaurant.management.data.db.BranchLegacyAliasEntity
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.domain.branch.BranchDraft
import ir.restaurant.management.domain.branch.BranchRecord
import ir.restaurant.management.domain.branch.BranchRepository
import ir.restaurant.management.domain.security.Permission
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalBranchRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val clock: () -> Long = System::currentTimeMillis,
) : BranchRepository {
    private val dao = database.branchDao()
    private val audit = LocalAuditEventWriter(database)

    override val branches: Flow<List<BranchRecord>> = dao.observeAll().map { rows -> rows.map(BranchEntity::toRecord) }
    override val activeBranches: Flow<List<BranchRecord>> = dao.observeActive().map { rows -> rows.map(BranchEntity::toRecord) }

    override suspend fun getById(id: Long): BranchRecord? = dao.byId(id)?.toRecord()

    override suspend fun getByGlobalId(globalId: String): BranchRecord? = dao.byGlobalId(globalId.trim())?.toRecord()

    override suspend fun findDeterministicLegacyMapping(legacyKey: String): BranchRecord? {
        val normalized = legacyKey.trim()
        if (normalized.isEmpty()) return null
        return dao.legacyCandidates(normalized).singleOrNull()?.toRecord()
    }

    override suspend fun listActive(): List<BranchRecord> = dao.listActive().map(BranchEntity::toRecord)

    override suspend fun create(draft: BranchDraft): Long {
        val actor = authorizer.require(Permission.BRANCH_MANAGE)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            require(dao.byGlobalId(valid.globalId) == null) { "branch_global_id_duplicate" }
            valid.code?.let { code ->
                require(dao.byOrganizationAndCode(valid.organizationId, code) == null) { "branch_organization_code_duplicate" }
            }
            val id = dao.insert(
                BranchEntity(
                    globalId = valid.globalId,
                    organizationId = valid.organizationId,
                    code = valid.code,
                    name = valid.name,
                    isActive = true,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            dao.insertLegacyAlias(valid.name.toLegacyAlias(id, now))
            audit.appendAuthorized(authorizer, "CREATE", "BRANCH", id, "ایجاد شعبه ${valid.name}", now, reason = "ایجاد شعبه", afterSnapshot = "name=${valid.name};code=${valid.code.orEmpty()};active=true", correlationId = "branch:$id:create")
            id
        }
    }

    override suspend fun rename(id: Long, name: String) {
        val actor = authorizer.require(Permission.BRANCH_MANAGE)
        require(actor.id > 0)
        val normalized = name.trim()
        require(normalized.length in 2..120) { "branch_name_invalid" }
        database.withTransaction {
            val current = dao.byId(id) ?: error("شعبه پیدا نشد.")
            val now = clock()
            dao.insertLegacyAlias(current.name.toLegacyAlias(id, now))
            dao.insertLegacyAlias(normalized.toLegacyAlias(id, now))
            check(dao.update(current.copy(name = normalized, updatedAtEpochMillis = now)) == 1)
            audit.appendAuthorized(authorizer, "RENAME", "BRANCH", id, "تغییر نام شعبه", now, reason = "تغییر نام شعبه", beforeSnapshot = "name=${current.name}", afterSnapshot = "name=$normalized", correlationId = "branch:$id:rename:$now")
        }
    }

    override suspend fun setActive(id: Long, active: Boolean) {
        authorizer.require(Permission.BRANCH_MANAGE)
        database.withTransaction {
            val current = dao.byId(id) ?: error("شعبه پیدا نشد.")
            if (current.isActive == active) return@withTransaction
            val now = clock()
            check(dao.update(current.copy(isActive = active, updatedAtEpochMillis = now)) == 1)
            audit.appendAuthorized(authorizer, if (active) "ACTIVATE" else "DEACTIVATE", "BRANCH", id, if (active) "فعال‌سازی شعبه" else "غیرفعال‌سازی شعبه", now, reason = if (active) "فعال‌سازی شعبه" else "غیرفعال‌سازی شعبه", beforeSnapshot = "active=${current.isActive}", afterSnapshot = "active=$active", correlationId = "branch:$id:active:$now")
        }
    }
}

internal fun BranchEntity.toRecord() = BranchRecord(
    id = id,
    globalId = globalId,
    organizationId = organizationId,
    code = code,
    name = name,
    isActive = isActive,
)


private fun String.toLegacyAlias(branchId: Long, now: Long): BranchLegacyAliasEntity {
    val display = trim()
    require(display.isNotEmpty()) { "branch_alias_blank" }
    return BranchLegacyAliasEntity(
        branchId = branchId,
        aliasName = display,
        normalizedAlias = display.lowercase(),
        createdAtEpochMillis = now,
    )
}
