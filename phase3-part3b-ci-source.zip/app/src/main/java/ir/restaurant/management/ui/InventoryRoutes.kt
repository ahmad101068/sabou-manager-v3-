package ir.restaurant.management.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import ir.restaurant.management.domain.branch.BranchRecord

/** Inventory-owned route group. RestaurantManagementApp remains a composition root, not an inventory router. */
@Composable
internal fun InventoryRoutes(
    screen: AppScreen,
    state: InventoryWorkspaceUiState,
    inventory: InventoryWorkspaceViewModel,
    operationsState: OperationsUiState,
    operations: OperationsViewModel,
    branches: List<BranchRecord>,
    navigate: (AppScreen) -> Unit,
    navigateBack: () -> Unit,
) {
    LaunchedEffect(screen) {
        if (screen == AppScreen.STOCK_MOVEMENTS) {
            inventory.selectSection(InventoryWorkspaceSection.MOVEMENTS)
        } else if (state.section == InventoryWorkspaceSection.MOVEMENTS && state.focusedItemId == null) {
            inventory.selectSection(InventoryWorkspaceSection.OVERVIEW)
        }
    }
    InventoryWorkspaceScreen(
        state = state,
        viewModel = inventory,
        operationsState = operationsState,
        operations = operations,
        branches = branches,
        onBack = navigateBack,
        onNavigate = navigate,
    )
}
