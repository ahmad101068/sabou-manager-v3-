package ir.restaurant.management.data.repository

import androidx.room.withTransaction
import ir.restaurant.management.core.CorrelationId
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.core.QuantityMicros
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.GoodsReceiptEntity
import ir.restaurant.management.data.db.GoodsReceiptLineEntity
import ir.restaurant.management.data.db.PurchaseOrderLineEntity
import ir.restaurant.management.data.db.PurchaseReturnEntity
import ir.restaurant.management.data.db.PurchaseReturnLineEntity
import ir.restaurant.management.data.db.SupplierCreditEntity
import ir.restaurant.management.domain.accounting.AccountingPostingCommand
import ir.restaurant.management.domain.accounting.AccountingPostingService
import ir.restaurant.management.domain.accounting.AccountingScope
import ir.restaurant.management.domain.accounting.SemanticAccountRole
import ir.restaurant.management.domain.accounting.SemanticJournalLine
import ir.restaurant.management.domain.common.DocumentNumberType
import ir.restaurant.management.domain.inventory.InventoryCommandContext
import ir.restaurant.management.domain.inventory.InventoryMovementType
import ir.restaurant.management.domain.inventory.InventoryReasonCode
import ir.restaurant.management.domain.inventory.InventoryReferenceType
import ir.restaurant.management.domain.inventory.InventoryReceiptLot
import ir.restaurant.management.domain.inventory.ReceiveInventoryCommand
import ir.restaurant.management.domain.purchase.GoodsReceiptDraft
import ir.restaurant.management.domain.purchase.PurchaseOrderStatus
import ir.restaurant.management.domain.purchase.PurchasePaymentStatus
import ir.restaurant.management.domain.purchase.PurchaseReturnDraft
import ir.restaurant.management.domain.security.AuthorizationService
import ir.restaurant.management.domain.security.Permission

/** Owns procurement receiving and supplier-return workflows while the legacy repository stays a facade. */
internal class ProcurementReceivingService(
    private val database: AppDatabase,
    private val authorizer: AuthorizationService,
    private val accountingPosting: AccountingPostingService,
    private val clock: () -> Long,
    private val syncRecorder: SyncRecorder?,
) {
    private val inventoryCommands = LocalInventoryCommandEngine(database, clock = clock)
    private val numbering = LocalDocumentNumberAllocator(database, clock)
    private val auditWriter = LocalAuditEventWriter(database)

    suspend fun receive(draft: GoodsReceiptDraft): Long {
        val actor = authorizer.require(Permission.PURCHASES)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(valid.purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            val existingReceipt = database.procurementDao().receiptByDeliveryNote(order.id, valid.deliveryNoteNo)
            val currentOrderLines = database.procurementDao().orderLines(order.id)
            GoodsReceiptIdempotency.existingReplayIdOrThrow(
                existing = existingReceipt,
                existingLines = existingReceipt?.let { database.procurementDao().receiptLines(it.id) }.orEmpty(),
                currentOrderLines = currentOrderLines,
                draft = valid,
            )?.let { return@withTransaction it }
            require(order.status in setOf(PurchaseOrderStatus.OPEN.name, PurchaseOrderStatus.PARTIALLY_RECEIVED.name)) {
                "این سفارش قابل دریافت نیست."
            }
            require(valid.receiptEpochDay >= order.orderEpochDay) {
                "تاریخ دریافت نمی‌تواند قبل از سفارش باشد."
            }
            val receiptNo = numbering.next(DocumentNumberType.GOODS_RECEIPT)
            require(!database.procurementDao().receiptNoExists(receiptNo)) { "شماره رسید تکراری است." }
            require(!database.procurementDao().deliveryNoteExists(order.id, valid.deliveryNoteNo)) {
                "این شماره حواله قبلاً برای سفارش ثبت شده است."
            }
            val receiptId = database.procurementDao().insertReceipt(
                GoodsReceiptEntity(
                    receiptNo = receiptNo,
                    purchaseOrderId = order.id,
                    receiptEpochDay = valid.receiptEpochDay,
                    deliveryNoteNo = valid.deliveryNoteNo,
                    receivedBy = actor.displayName,
                    note = valid.note,
                    createdAtEpochMillis = now,
                ),
            )
            val orderLines = currentOrderLines.associateBy { it.id }
            var acceptedTotal = MoneyRial.ZERO
            val receiptLines = valid.lines.map { received ->
                val orderLine = orderLines[received.purchaseOrderLineId]
                    ?: error("ردیف تحویل متعلق به این سفارش نیست.")
                val remaining = orderLine.orderedQtyMicros - orderLine.receivedQtyMicros
                require(received.deliveredQtyMicros <= remaining) {
                    "تحویل «${orderLine.itemNameSnapshot}» از مانده سفارش بیشتر است."
                }
                val rejected = if (valid.finalizeOrder) {
                    remaining - received.acceptedQtyMicros
                } else {
                    received.deliveredQtyMicros - received.acceptedQtyMicros
                }
                require(rejected == 0L || received.rejectionReason.length >= 3) {
                    "برای کسری یا رد «${orderLine.itemNameSnapshot}» دلیل ثبت کنید."
                }
                check(
                    database.procurementDao().addReceiptQuantities(
                        lineId = orderLine.id,
                        purchaseOrderId = order.id,
                        acceptedQtyMicros = received.acceptedQtyMicros,
                        rejectedQtyMicros = rejected,
                    ) == 1,
                ) { "مقدار دریافت هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
                val acceptedValue = MoneyRial.of(orderLine.unitCostRial)
                    .times(QuantityMicros.of(received.acceptedQtyMicros))
                acceptedTotal += acceptedValue
                if (received.acceptedQtyMicros > 0) {
                    inventoryCommands.receive(
                        ReceiveInventoryCommand(
                        itemId = orderLine.itemId,
                        quantityMicros = received.acceptedQtyMicros,
                        valueRial = acceptedValue.value,
                        movementType = InventoryMovementType.GOODS_RECEIPT,
                        referenceType = InventoryReferenceType.GOODS_RECEIPT,
                        referenceId = receiptId,
                        businessEpochDay = valid.receiptEpochDay,
                        context = InventoryCommandContext.local(
                            referenceType = InventoryReferenceType.GOODS_RECEIPT,
                            referenceId = receiptId,
                            suffix = "receive:${orderLine.id}",
                            actorId = actor.id,
                            reasonCode = InventoryReasonCode.GOODS_RECEIPT,
                            reason = "دریافت ${order.orderNo} / ${valid.deliveryNoteNo}",
                            correlationId = "goods_receipt:$receiptId",
                        ),
                        notes = "${order.orderNo} / ${valid.deliveryNoteNo}",
                        lot = received.lotNumber?.let { lotNumber ->
                            InventoryReceiptLot(
                                lotNumber = lotNumber,
                                supplierLotNumber = received.supplierLotNumber,
                                productionEpochDay = received.productionEpochDay,
                                expiryEpochDay = received.expiryEpochDay,
                                barcode = received.lotBarcode,
                            )
                        },
                        ),
                    )
                }
                GoodsReceiptLineEntity(
                    goodsReceiptId = receiptId,
                    purchaseOrderLineId = orderLine.id,
                    itemId = orderLine.itemId,
                    deliveredQtyMicros = received.deliveredQtyMicros,
                    acceptedQtyMicros = received.acceptedQtyMicros,
                    rejectedQtyMicros = rejected,
                    rejectionReason = received.rejectionReason,
                    acceptedValueRial = acceptedValue.value,
                    lotNumber = received.lotNumber,
                    supplierLotNumber = received.supplierLotNumber,
                    productionEpochDay = received.productionEpochDay,
                    expiryEpochDay = received.expiryEpochDay,
                    lotBarcode = received.lotBarcode,
                )
            }
            database.procurementDao().insertReceiptLines(receiptLines)
            if (acceptedTotal > MoneyRial.ZERO) {
                postJournal(
                    entryNo = "رس-$receiptId",
                    epochDay = valid.receiptEpochDay,
                    description = "دریافت کالا برای ${order.orderNo}",
                    sourceType = "GOODS_RECEIPT",
                    sourceId = receiptId,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, debit = acceptedTotal),
                        SemanticJournalLine(
                            SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED,
                            credit = acceptedTotal,
                        ),
                    ),
                    actorId = actor.id,
                )
            }
            val refreshed = database.procurementDao().orderLines(order.id)
            val status = if (
                valid.finalizeOrder || refreshed.all { it.receivedQtyMicros == it.orderedQtyMicros }
            ) {
                PurchaseOrderStatus.RECEIVED
            } else {
                PurchaseOrderStatus.PARTIALLY_RECEIVED
            }
            check(database.procurementDao().updateOrderStatus(order.id, status.name, now) == 1) {
                "وضعیت سفارش تغییر نکرد."
            }
            auditWriter.appendAuthorized(
                authorizer = authorizer,
                action = "RECEIVE",
                entityType = "GOODS_RECEIPT",
                entityId = receiptId,
                description = "دریافت کالا برای ${order.orderNo}",
                occurredAtEpochMillis = now,
                businessEpochDay = valid.receiptEpochDay,
                reason = "DELIVERY_NOTE:${valid.deliveryNoteNo}",
                afterSnapshot = "status=${status.name};acceptedValueRial=${acceptedTotal.value};lineCount=${receiptLines.size}",
                correlationId = "goods_receipt:$receiptId",
                referenceType = "PURCHASE_ORDER",
                referenceId = order.id,
            )
            syncRecorder?.record("GOODS_RECEIPT", receiptId, "POST", now, recordAudit = false)
            receiptId
        }
    }

    suspend fun returnToSupplier(draft: PurchaseReturnDraft): Long {
        val actor = authorizer.require(Permission.PURCHASES)
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(valid.purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(
                order.status in setOf(
                    PurchaseOrderStatus.PARTIALLY_RECEIVED.name,
                    PurchaseOrderStatus.RECEIVED.name,
                    PurchaseOrderStatus.CLOSED.name,
                ),
            ) { "این سفارش کالای قابل مرجوعی ندارد." }
            val latestReceiptDay = database.procurementDao().latestReceiptEpochDay(order.id)
                ?: error("برای این سفارش رسید کالایی ثبت نشده است.")
            require(valid.returnEpochDay >= latestReceiptDay) {
                "تاریخ مرجوعی نمی‌تواند قبل از آخرین رسید کالا باشد."
            }

            val invoiceLink = database.procurementDao().invoiceLinkForOrder(order.id)
            val orderLines = database.procurementDao().orderLines(order.id).associateBy { it.id }
            val preparedLines = valid.lines.map { returned ->
                val orderLine = orderLines[returned.purchaseOrderLineId]
                    ?: error("ردیف مرجوعی متعلق به این سفارش نیست.")
                val returnable = orderLine.receivedQtyMicros - orderLine.returnedQtyMicros
                require(returned.quantityMicros <= returnable) {
                    "مقدار مرجوعی «${orderLine.itemNameSnapshot}» از مقدار قابل مرجوع بیشتر است."
                }
                val supplierUnitCredit = invoiceLink?.let { link ->
                    database.procurementDao().purchaseLineForItem(link.purchaseId, orderLine.itemId)?.unitCostRial
                        ?: error("ردیف فاکتور متناظر با «${orderLine.itemNameSnapshot}» پیدا نشد.")
                } ?: orderLine.unitCostRial
                val quantity = QuantityMicros.of(returned.quantityMicros)
                PreparedPurchaseReturnLine(
                    orderLine = orderLine,
                    quantityMicros = returned.quantityMicros,
                    inventoryUnitCostRial = orderLine.unitCostRial,
                    supplierUnitCreditRial = supplierUnitCredit,
                    inventoryValue = MoneyRial.of(orderLine.unitCostRial).times(quantity),
                    supplierCreditValue = if (invoiceLink == null) {
                        MoneyRial.ZERO
                    } else {
                        MoneyRial.of(supplierUnitCredit).times(quantity)
                    },
                    reason = returned.reason,
                )
            }
            val inventoryTotal = MoneyRial.sum(preparedLines.map { it.inventoryValue })
            val supplierCreditTotal = MoneyRial.sum(preparedLines.map { it.supplierCreditValue })
            val returnId = database.procurementDao().insertPurchaseReturn(
                PurchaseReturnEntity(
                    returnNo = numbering.next(DocumentNumberType.PURCHASE_RETURN),
                    purchaseOrderId = order.id,
                    purchaseId = invoiceLink?.purchaseId,
                    supplierId = order.supplierId,
                    returnEpochDay = valid.returnEpochDay,
                    reason = valid.reason,
                    returnedBy = actor.displayName,
                    inventoryValueRial = inventoryTotal.value,
                    supplierCreditValueRial = supplierCreditTotal.value,
                    createdAtEpochMillis = now,
                ),
            )

            preparedLines.forEach { line ->
                check(
                    database.procurementDao().addReturnedQuantity(
                        lineId = line.orderLine.id,
                        purchaseOrderId = order.id,
                        quantityMicros = line.quantityMicros,
                    ) == 1,
                ) { "مقدار قابل مرجوع هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
                val item = database.inventoryDao().activeById(line.orderLine.itemId)
                    ?: error("کالای «${line.orderLine.itemNameSnapshot}» فعال نیست.")
                require(item.stockMicros >= line.quantityMicros) {
                    "موجودی «${line.orderLine.itemNameSnapshot}» برای مرجوعی کافی نیست."
                }
                require(item.inventoryValueRial >= line.inventoryValue.value) {
                    "ارزش موجودی «${line.orderLine.itemNameSnapshot}» برای مرجوعی کافی نیست."
                }
                inventoryCommands.issue(
                    itemId = item.id,
                    quantityMicros = line.quantityMicros,
                    valueRial = line.inventoryValue.value,
                    movementType = InventoryMovementType.PURCHASE_RETURN,
                    referenceType = InventoryReferenceType.PURCHASE_RETURN,
                    referenceId = returnId,
                    movementEpochDay = valid.returnEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.PURCHASE_RETURN,
                        referenceId = returnId,
                        suffix = "return:${line.orderLine.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.PURCHASE_RETURN,
                        reason = line.reason,
                        correlationId = "purchase_return:$returnId",
                    ),
                    notes = "${order.orderNo} · ${line.reason}",
                    lotPolicy = LocalInventoryCommandEngine.LotIssuePolicy.FEFO_ALLOCATED_ONLY,
                )
            }
            database.procurementDao().insertPurchaseReturnLines(
                preparedLines.map { line ->
                    PurchaseReturnLineEntity(
                        purchaseReturnId = returnId,
                        purchaseOrderLineId = line.orderLine.id,
                        itemId = line.orderLine.itemId,
                        quantityMicros = line.quantityMicros,
                        inventoryUnitCostRial = line.inventoryUnitCostRial,
                        supplierUnitCreditRial = line.supplierUnitCreditRial,
                        inventoryValueRial = line.inventoryValue.value,
                        supplierCreditValueRial = line.supplierCreditValue.value,
                        reason = line.reason,
                    )
                },
            )

            if (invoiceLink == null) {
                postJournal(
                    entryNo = "مر-$returnId",
                    epochDay = valid.returnEpochDay,
                    description = "مرجوعی پیش از فاکتور ${order.orderNo}",
                    sourceType = "PURCHASE_RETURN",
                    sourceId = returnId,
                    lines = listOf(
                        SemanticJournalLine(
                            SemanticAccountRole.GOODS_RECEIVED_NOT_INVOICED,
                            debit = inventoryTotal,
                        ),
                        SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, credit = inventoryTotal),
                    ),
                    actorId = actor.id,
                )
            } else {
                postInvoicedReturn(
                    orderNo = order.orderNo,
                    supplierId = order.supplierId,
                    purchaseId = invoiceLink.purchaseId,
                    returnId = returnId,
                    returnEpochDay = valid.returnEpochDay,
                    inventoryTotal = inventoryTotal,
                    supplierCreditTotal = supplierCreditTotal,
                    actorId = actor.id,
                    now = now,
                )
            }
            syncRecorder?.record("PURCHASE_RETURN", returnId, "POST", now)
            returnId
        }
    }

    private suspend fun postInvoicedReturn(
        orderNo: String,
        supplierId: Long,
        purchaseId: Long,
        returnId: Long,
        returnEpochDay: Long,
        inventoryTotal: MoneyRial,
        supplierCreditTotal: MoneyRial,
        actorId: Long,
        now: Long,
    ) {
        val purchase = database.purchaseDao().byId(purchaseId)
            ?: error("فاکتور تطبیق‌شده پیدا نشد.")
        val outstanding = (purchase.totalRial - purchase.paidRial).coerceAtLeast(0)
        val applied = supplierCreditTotal.value.coerceAtMost(outstanding)
        val openCredit = supplierCreditTotal.value - applied
        if (applied > 0) {
            val newPaid = purchase.paidRial + applied
            val paidInFull = newPaid == purchase.totalRial
            check(
                database.purchaseDao().updateSettlementState(
                    purchaseId = purchase.id,
                    expectedPaidRial = purchase.paidRial,
                    newPaidRial = newPaid,
                    paymentStatus = if (paidInFull) {
                        PurchasePaymentStatus.PAID.storedValue
                    } else {
                        PurchasePaymentStatus.PARTIAL.storedValue
                    },
                    reminderEnabled = !paidInFull && purchase.reminderEnabled,
                    reminderEpochDay = if (paidInFull) null else purchase.reminderEpochDay,
                ) == 1,
            ) { "مانده فاکتور هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
        }
        database.procurementDao().insertSupplierCredit(
            SupplierCreditEntity(
                creditNo = "SC-$returnId",
                supplierId = supplierId,
                sourceReturnId = returnId,
                appliedPurchaseId = purchase.id.takeIf { applied > 0 },
                amountRial = supplierCreditTotal.value,
                appliedRial = applied,
                status = when {
                    applied == supplierCreditTotal.value -> "APPLIED"
                    applied > 0 -> "PARTIAL"
                    else -> "OPEN"
                },
                createdAtEpochMillis = now,
            ),
        )
        val journalLines = buildList {
            if (applied > 0) {
                add(SemanticJournalLine(SemanticAccountRole.SUPPLIER_PAYABLE, debit = MoneyRial.of(applied)))
            }
            if (openCredit > 0) {
                add(
                    SemanticJournalLine(
                        SemanticAccountRole.SUPPLIER_CREDIT_RECEIVABLE,
                        debit = MoneyRial.of(openCredit),
                    ),
                )
            }
            if (inventoryTotal.value > supplierCreditTotal.value) {
                add(
                    SemanticJournalLine(
                        SemanticAccountRole.PURCHASE_PRICE_VARIANCE,
                        debit = MoneyRial.of(inventoryTotal.value - supplierCreditTotal.value),
                    ),
                )
            }
            add(SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, credit = inventoryTotal))
            if (supplierCreditTotal.value > inventoryTotal.value) {
                add(
                    SemanticJournalLine(
                        SemanticAccountRole.PURCHASE_PRICE_VARIANCE,
                        credit = MoneyRial.of(supplierCreditTotal.value - inventoryTotal.value),
                    ),
                )
            }
        }
        postJournal(
            entryNo = "مر-$returnId",
            epochDay = returnEpochDay,
            description = "مرجوعی خرید و اعتبار تأمین‌کننده $orderNo",
            sourceType = "PURCHASE_RETURN",
            sourceId = returnId,
            lines = journalLines,
            actorId = actorId,
        )
    }

    private suspend fun postJournal(
        entryNo: String,
        epochDay: Long,
        description: String,
        sourceType: String,
        sourceId: Long,
        lines: List<SemanticJournalLine>,
        actorId: Long,
    ): Long = accountingPosting.post(
        AccountingPostingCommand(
            entryNo = entryNo,
            businessEpochDay = epochDay,
            description = description,
            sourceType = sourceType,
            sourceId = sourceId,
            accountingScope = AccountingScope.ORGANIZATION,
            branchId = null,
            lines = lines,
            idempotencyKey = "$sourceType:$sourceId:post",
            correlationId = CorrelationId.parse("${sourceType.lowercase()}:$sourceId"),
            actorId = actorId,
        ),
    ).entryId
}

private data class PreparedPurchaseReturnLine(
    val orderLine: PurchaseOrderLineEntity,
    val quantityMicros: Long,
    val inventoryUnitCostRial: Long,
    val supplierUnitCreditRial: Long,
    val inventoryValue: MoneyRial,
    val supplierCreditValue: MoneyRial,
    val reason: String,
)
