package ir.restaurant.management.domain.receivables

enum class ReceivableType { PERSONAL, CORPORATE }
enum class ReceivableStatus { OPEN, PARTIALLY_PAID, PAID, VOIDED }
enum class ReceivableCollectionMethod { CASH, CARD, BANK_TRANSFER }

data class ReceivableRecord(
    val id: Long,
    val globalId: String,
    val branchId: Long,
    val partyId: Long,
    val type: ReceivableType,
    val sourceType: String,
    val sourceId: Long,
    val originalAmountRial: Long,
    val paidAmountRial: Long,
    val outstandingAmountRial: Long,
    val issueEpochDay: Long,
    val dueEpochDay: Long?,
    val status: ReceivableStatus,
) {
    fun isOverdue(todayEpochDay: Long): Boolean = dueEpochDay != null && outstandingAmountRial > 0 && todayEpochDay > dueEpochDay
}

data class ReceivableCollectionDraft(
    val receivableId: Long,
    val amountRial: Long,
    val method: ReceivableCollectionMethod,
    val cashboxId: Long? = null,
    val bankAccountId: Long? = null,
    val reference: String? = null,
    val businessEpochDay: Long,
) {
    fun validated(outstandingRial: Long): ReceivableCollectionDraft {
        require(receivableId > 0 && businessEpochDay > 0) { "دریافتنی معتبر نیست." }
        require(amountRial > 0) { "مبلغ وصول باید بیشتر از صفر باشد." }
        require(amountRial <= outstandingRial) { "مبلغ وصول از مانده دریافتنی بیشتر است." }
        return copy(reference = reference?.trim()?.takeIf(String::isNotEmpty))
    }
}

data class ReceivableAging(
    val currentRial: Long,
    val overdue1To7Rial: Long,
    val overdue8To30Rial: Long,
    val overdue31To60Rial: Long,
    val overdue61To90Rial: Long,
    val overdueOver90Rial: Long,
)

data class ReceivableCollectionReversalDraft(
    val collectionId: Long,
    val reason: String,
    val reversalEpochDay: Long,
) {
    fun validated(): ReceivableCollectionReversalDraft {
        require(collectionId > 0 && reversalEpochDay > 0) { "وصول معتبر نیست." }
        val normalized = reason.trim()
        require(normalized.length in 3..300) { "دلیل برگشت وصول الزامی است." }
        return copy(reason = normalized)
    }
}

interface ReceivableService {
    fun observeOpen(branchId: Long): kotlinx.coroutines.flow.Flow<List<ReceivableRecord>>
    suspend fun collect(draft: ReceivableCollectionDraft): Long
    suspend fun reverseCollection(draft: ReceivableCollectionReversalDraft)
    suspend fun aging(branchId: Long, todayEpochDay: Long): ReceivableAging
}
