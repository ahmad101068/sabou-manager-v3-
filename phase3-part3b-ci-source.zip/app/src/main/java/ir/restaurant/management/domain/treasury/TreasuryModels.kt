package ir.restaurant.management.domain.treasury

import ir.restaurant.management.core.CorrelationId
import ir.restaurant.management.core.GlobalId
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.domain.common.BusinessError
import ir.restaurant.management.domain.common.asViolation

enum class TreasuryChannel(val storedValue: String) {
    CASH("CASH"),
    BANK("BANK"),
    CARD("CARD"),
    TRANSFER("TRANSFER");

    companion object {
        fun fromStoredValue(value: String): TreasuryChannel =
            entries.firstOrNull { it.storedValue == value.trim().uppercase() }
                ?: throw BusinessError.UnknownStoredValue(
                    ownerDomain = "treasury",
                    field = "treasury.channel",
                    storedValue = value,
                ).asViolation()
    }
}

enum class TreasuryDirection { RECEIPT, PAYMENT }
enum class TreasuryAccountKind { CASH, BANK, CARD_TERMINAL, PETTY_CASH }
enum class TreasuryTransactionKind { RECEIPT, PAYMENT, INTERNAL_TRANSFER, SETTLEMENT, RECONCILIATION }

enum class SettlementStatus(val storedValue: String) {
    PENDING("PENDING"),
    SETTLED("SETTLED"),
    REVERSED("REVERSED"),
    LEGACY_UNKNOWN("LEGACY_UNKNOWN");

    companion object {
        fun fromStoredValue(value: String): SettlementStatus =
            entries.firstOrNull { it.storedValue == value.trim().uppercase() } ?: LEGACY_UNKNOWN
    }
}

@JvmInline
value class TreasuryAccountId private constructor(val value: String) {
    companion object {
        fun parse(raw: String): TreasuryAccountId {
            val normalized = raw.trim().lowercase()
            require(normalized.matches(Regex("[a-z][a-z0-9_-]{2,63}"))) { "treasury_account_id_invalid" }
            return TreasuryAccountId(normalized)
        }
    }
}

data class TreasuryAccount(
    val id: TreasuryAccountId,
    val name: String,
    val kind: TreasuryAccountKind,
    val channel: TreasuryChannel,
    val isActive: Boolean,
) {
    init {
        require(name.isNotBlank()) { "treasury_account_name_missing" }
    }
}

interface TreasuryAccountCatalog {
    fun activeAccounts(): List<TreasuryAccount>
    fun account(id: TreasuryAccountId): TreasuryAccount?
}

/**
 * Persistence-neutral command model. Current flows can adapt to this boundary without introducing
 * a second cash/bank source of truth before a dedicated treasury ledger migration exists.
 */
sealed interface TreasuryCommand {
    val commandId: GlobalId
    val businessEpochDay: Long
    val correlationId: CorrelationId
    val sourceType: String
    val sourceId: Long
    val reason: String

    data class Receipt(
        override val commandId: GlobalId,
        override val businessEpochDay: Long,
        override val correlationId: CorrelationId,
        override val sourceType: String,
        override val sourceId: Long,
        override val reason: String,
        val accountId: TreasuryAccountId,
        val channel: TreasuryChannel,
        val amount: MoneyRial,
    ) : TreasuryCommand

    data class Payment(
        override val commandId: GlobalId,
        override val businessEpochDay: Long,
        override val correlationId: CorrelationId,
        override val sourceType: String,
        override val sourceId: Long,
        override val reason: String,
        val accountId: TreasuryAccountId,
        val channel: TreasuryChannel,
        val amount: MoneyRial,
    ) : TreasuryCommand

    data class InternalTransfer(
        override val commandId: GlobalId,
        override val businessEpochDay: Long,
        override val correlationId: CorrelationId,
        override val sourceType: String,
        override val sourceId: Long,
        override val reason: String,
        val fromAccountId: TreasuryAccountId,
        val toAccountId: TreasuryAccountId,
        val amount: MoneyRial,
    ) : TreasuryCommand

    data class Settlement(
        override val commandId: GlobalId,
        override val businessEpochDay: Long,
        override val correlationId: CorrelationId,
        override val sourceType: String,
        override val sourceId: Long,
        override val reason: String,
        val accountId: TreasuryAccountId,
        val direction: TreasuryDirection,
        val channel: TreasuryChannel,
        val amount: MoneyRial,
    ) : TreasuryCommand

    data class Reconciliation(
        override val commandId: GlobalId,
        override val businessEpochDay: Long,
        override val correlationId: CorrelationId,
        override val sourceType: String,
        override val sourceId: Long,
        override val reason: String,
        val accountId: TreasuryAccountId,
        val expected: MoneyRial,
        val actual: MoneyRial,
    ) : TreasuryCommand
}

data class TreasuryTransaction(
    val id: String,
    val kind: TreasuryTransactionKind,
    val businessEpochDay: Long,
    val correlationId: CorrelationId,
    val sourceType: String,
    val sourceId: Long,
    val amount: MoneyRial,
    val journalEntryId: Long?,
    val idempotentReplay: Boolean,
)

data class TreasuryReversalCommand(
    val commandId: GlobalId,
    val originalTransactionId: String,
    val originalJournalEntryId: Long,
    val businessEpochDay: Long,
    val correlationId: CorrelationId,
    val sourceType: String,
    val sourceId: Long,
    val reason: String,
    val accountId: TreasuryAccountId,
    val channel: TreasuryChannel,
    val amount: MoneyRial,
) {
    fun validated(): TreasuryReversalCommand {
        require(originalTransactionId.isNotBlank()) { "treasury_original_transaction_missing" }
        require(originalJournalEntryId > 0 && businessEpochDay > 0 && sourceId > 0)
        require(sourceType.trim().uppercase().matches(Regex("[A-Z][A-Z0-9_]{1,63}")))
        require(reason.trim().length in 3..500)
        require(amount > MoneyRial.ZERO)
        return copy(sourceType = sourceType.trim().uppercase(), reason = reason.trim())
    }
}

interface TreasuryService {
    suspend fun execute(command: TreasuryCommand): TreasuryTransaction
    suspend fun reverse(command: TreasuryReversalCommand): TreasuryTransaction
}

data class TreasuryLedgerRecord(
    val id: String,
    val kind: TreasuryTransactionKind,
    val businessEpochDay: Long,
    val sourceType: String,
    val sourceId: Long,
    val amountRial: Long,
    val status: String,
    val reason: String,
    val journalEntryId: Long?,
    val createdAtEpochMillis: Long,
)

data class TreasuryReversalContext(
    val transactionId: String,
    val status: String,
    val journalEntryId: Long?,
    val businessEpochDay: Long,
    val sourceType: String,
    val sourceId: Long,
    val amountRial: Long,
    val accountId: TreasuryAccountId,
    val channel: TreasuryChannel,
    val reversalOfTransactionId: String?,
)

interface TreasuryLedgerReader {
    val recentTransactions: kotlinx.coroutines.flow.Flow<List<TreasuryLedgerRecord>>
    fun observeBalance(accountId: TreasuryAccountId): kotlinx.coroutines.flow.Flow<Long>
    suspend fun reversalContext(transactionId: String): TreasuryReversalContext?
}

fun TreasuryCommand.validated(): TreasuryCommand {
    require(businessEpochDay > 0) { "treasury_business_date_invalid" }
    require(sourceType.trim().uppercase().matches(Regex("[A-Z][A-Z0-9_]{1,63}"))) {
        "treasury_source_type_invalid"
    }
    require(sourceId > 0) { "treasury_source_id_invalid" }
    require(reason.trim().length in 3..500) { "treasury_reason_invalid" }
    when (this) {
        is TreasuryCommand.Receipt -> require(amount > MoneyRial.ZERO) { "treasury_receipt_amount_not_positive" }
        is TreasuryCommand.Payment -> require(amount > MoneyRial.ZERO) { "treasury_payment_amount_not_positive" }
        is TreasuryCommand.InternalTransfer -> {
            require(amount > MoneyRial.ZERO) { "treasury_transfer_amount_not_positive" }
            require(fromAccountId != toAccountId) { "treasury_transfer_same_account" }
        }
        is TreasuryCommand.Settlement -> require(amount > MoneyRial.ZERO) { "treasury_settlement_amount_not_positive" }
        is TreasuryCommand.Reconciliation -> Unit
    }
    return this
}

data class TreasuryMovementDraft(
    val direction: TreasuryDirection,
    val channel: TreasuryChannel,
    val amount: MoneyRial,
    val epochDay: Long,
    val sourceType: String,
    val sourceId: Long,
    val reference: String = "",
) {
    fun validated(): TreasuryMovementDraft {
        require(amount > MoneyRial.ZERO) { "treasury_amount_not_positive" }
        require(epochDay > 0) { "treasury_business_date_invalid" }
        require(sourceType.isNotBlank() && sourceId > 0) { "treasury_source_missing" }
        return copy(sourceType = sourceType.trim(), reference = reference.trim())
    }
}
