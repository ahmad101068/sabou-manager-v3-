package ir.restaurant.management.data.treasury

import ir.restaurant.management.domain.treasury.TreasuryAccount
import ir.restaurant.management.domain.treasury.TreasuryAccountCatalog
import ir.restaurant.management.domain.treasury.TreasuryAccountId
import ir.restaurant.management.domain.treasury.TreasuryAccountKind
import ir.restaurant.management.domain.treasury.TreasuryChannel

/**
 * Default account catalog backed by existing cash/bank concepts. It exposes existing cash/bank concepts without claiming a
 * dedicated treasury table or creating a second balance source of truth.
 */
class DefaultTreasuryAccountCatalog : TreasuryAccountCatalog {
    private val accounts = listOf(
        TreasuryAccount(
            TreasuryAccountId.parse("cash_main"),
            "صندوق اصلی",
            TreasuryAccountKind.CASH,
            TreasuryChannel.CASH,
            isActive = true,
        ),
        TreasuryAccount(
            TreasuryAccountId.parse("bank_main"),
            "حساب بانکی اصلی",
            TreasuryAccountKind.BANK,
            TreasuryChannel.BANK,
            isActive = true,
        ),
        TreasuryAccount(
            TreasuryAccountId.parse("card_terminal"),
            "کارتخوان",
            TreasuryAccountKind.CARD_TERMINAL,
            TreasuryChannel.CARD,
            isActive = true,
        ),
        TreasuryAccount(
            TreasuryAccountId.parse("petty_cash"),
            "تنخواه",
            TreasuryAccountKind.PETTY_CASH,
            TreasuryChannel.CASH,
            isActive = true,
        ),
    )

    override fun activeAccounts(): List<TreasuryAccount> = accounts

    override fun account(id: TreasuryAccountId): TreasuryAccount? =
        accounts.firstOrNull { it.id == id }
}
