package ir.restaurant.management.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddBusiness
import androidx.compose.material.icons.outlined.AddShoppingCart
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Search
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import ir.restaurant.management.core.GlobalId
import ir.restaurant.management.domain.operations.InventoryItemDraft
import ir.restaurant.management.domain.operations.InventoryCountDraft
import ir.restaurant.management.domain.operations.InventoryItemRecord
import ir.restaurant.management.domain.operations.InventoryPeriodCloseDraft
import ir.restaurant.management.domain.operations.InventoryPeriodClosureRecord
import ir.restaurant.management.domain.operations.InventoryPeriodStatus
import ir.restaurant.management.domain.purchase.PurchasePaymentStatus
import ir.restaurant.management.domain.operations.StockMovementRecord
import ir.restaurant.management.domain.operations.SupplierDraft
import ir.restaurant.management.domain.operations.SupplierRecord
import ir.restaurant.management.domain.operations.WasteDraft
import ir.restaurant.management.domain.purchase.PostedPurchase
import ir.restaurant.management.domain.purchase.PurchaseDraft
import ir.restaurant.management.domain.purchase.PurchaseLineDraft
import ir.restaurant.management.domain.purchase.PurchasePaymentMethod

@Composable
fun SuppliersScreen(
    state: OperationsUiState,
    onSave: (Long?, SupplierDraft, () -> Unit) -> Unit,
    onDeactivate: (Long) -> Unit,
    onOpenPurchases: () -> Unit,
    onNewPurchase: () -> Unit,
    onBack: () -> Unit,
) {
    var editorOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<SupplierRecord?>(null) }
    var deactivateTarget by remember { mutableStateOf<SupplierRecord?>(null) }
    var search by rememberSaveable { mutableStateOf("") }
    val summary = supplierDashboardSummary(state)
    val visibleSuppliers = state.suppliers.filter { supplier ->
        val q = search.trim()
        q.isBlank() || listOf(supplier.name, supplier.contactName, supplier.phone, supplier.address).any { it.contains(q, ignoreCase = true) }
    }
    Scaffold(topBar = { ProfessionalTopBar("تأمین‌کنندگان", "شبکه تأمین، تماس‌ها و شرایط پرداخت", onBack, "تأمین‌کننده جدید") { selected = null; editorOpen = true } }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            state.message?.let { item { MessageCard(it) } }
            item {
                ErpDashboardHero(
                    eyebrow = "شبکه تأمین",
                    value = "${ErpDisplayFormatters.integer(summary.activeSuppliers)} تأمین‌کننده",
                    caption = "میانگین مهلت پرداخت ${ErpDisplayFormatters.integer(summary.averagePaymentTermsDays)} روز",
                    metrics = listOf(
                        ErpKpiItem("خرید باز", ErpDisplayFormatters.integer(summary.openPurchaseCount)),
                        ErpKpiItem("پرداختنی", ErpDisplayFormatters.money(summary.payableRial)),
                        ErpKpiItem("سررسید", ErpDisplayFormatters.integer(summary.dueSettlementCount)),
                    ),
                )
            }
            item {
                SectionHeading("عملیات سریع", "عملیات به مسیرهای واقعی خرید و تسویه متصل‌اند")
                ErpQuickActionsGrid(
                    listOf(
                        ErpActionItem("تأمین‌کننده جدید", Icons.Outlined.AddBusiness, ErpPalette.IndigoSoft, ErpPalette.Indigo, onClick = { selected = null; editorOpen = true }),
                        ErpActionItem("سفارش خرید", Icons.Outlined.AddShoppingCart, ErpPalette.TealSoft, ErpPalette.Teal, onClick = onOpenPurchases),
                        ErpActionItem("ثبت خرید", Icons.Outlined.ReceiptLong, ErpPalette.GreenSoft, ErpPalette.Green, onClick = onNewPurchase),
                        ErpActionItem("پرداخت و گردش", Icons.Outlined.Payments, ErpPalette.AmberSoft, ErpPalette.Amber, onClick = onOpenPurchases),
                    ),
                )
            }
            item {
                SectionHeading("شرکای تأمین", "اطلاعات تماس و شرایط همکاری")
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("جست‌وجوی نام، رابط، تلفن یا آدرس") },
                    leadingIcon = { androidx.compose.material3.Icon(Icons.Outlined.Search, contentDescription = "جست‌وجو") },
                    singleLine = true,
                )
            }
            if (visibleSuppliers.isEmpty()) item { ErpStatePanel("تأمین‌کننده‌ای پیدا نشد", if (state.suppliers.isEmpty()) "اولین شریک تأمین را اضافه کنید تا ثبت خرید سریع‌تر شود." else "عبارت جست‌وجو را تغییر دهید.") }
            items(visibleSuppliers, key = { it.id }) { supplier ->
                ElevatedCard(shape = RoundedCornerShape(24.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface), elevation = CardDefaults.elevatedCardElevation(1.dp)) {
                    Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(supplier.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                                Text(if (supplier.contactName.isBlank()) "بدون رابط ثبت‌شده" else supplier.contactName, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill("${supplier.paymentTermsDays} روز")
                        }
                        if (supplier.phone.isNotBlank()) CompactInfoRow("شماره تماس", supplier.phone)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { selected = supplier; editorOpen = true }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("ویرایش") }
                            TextButton(onClick = { deactivateTarget = supplier }, modifier = Modifier.weight(1f)) { Text("غیرفعال‌کردن", color = MaterialTheme.colorScheme.error) }
                        }
                    }
                }
            }
        }
    }
    if (editorOpen) SupplierEditorDialog(existing = selected, busy = state.busy, onDismiss = { editorOpen = false }, onSave = { draft -> onSave(selected?.id, draft) { editorOpen = false } })
    deactivateTarget?.let { target -> ConfirmDeactivateDialog("غیرفعال‌کردن تأمین‌کننده", "«${target.name}» از فهرست انتخاب‌ها حذف می‌شود؛ سوابق قبلی باقی می‌مانند.", { deactivateTarget = null }) { deactivateTarget = null; onDeactivate(target.id) } }
}

@Composable
private fun SupplierEditorDialog(
    existing: SupplierRecord?,
    busy: Boolean,
    onDismiss: () -> Unit,
    onSave: (SupplierDraft) -> Unit,
) {
    var name by remember(existing?.id) { mutableStateOf(existing?.name.orEmpty()) }
    var contact by remember(existing?.id) { mutableStateOf(existing?.contactName.orEmpty()) }
    var phone by remember(existing?.id) { mutableStateOf(existing?.phone.orEmpty()) }
    var address by remember(existing?.id) { mutableStateOf(existing?.address.orEmpty()) }
    var terms by remember(existing?.id) { mutableStateOf(existing?.paymentTermsDays?.toString() ?: "0") }
    var notes by remember(existing?.id) { mutableStateOf(existing?.notes.orEmpty()) }
    var error by remember(existing?.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "تأمین‌کننده جدید" else "ویرایش تأمین‌کننده") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedTextField(name, { name = it }, label = { Text("نام") })
                OutlinedTextField(contact, { contact = it }, label = { Text("نام رابط") })
                OutlinedTextField(
                    phone,
                    { phone = it },
                    label = { Text("شماره تماس") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
                OutlinedTextField(address, { address = it }, label = { Text("نشانی") })
                OutlinedTextField(
                    terms,
                    { terms = it },
                    label = { Text("مهلت تسویه پیش‌فرض (روز)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") })
            }
        },
        confirmButton = {
            Button(
                enabled = !busy,
                onClick = {
                    try {
                        val parsedTerms = normalizeNumberInput(terms).toInt()
                        onSave(
                            SupplierDraft(
                                name = name,
                                contactName = contact,
                                phone = phone,
                                address = address,
                                paymentTermsDays = parsedTerms,
                                notes = notes,
                            ),
                        )
                    } catch (failure: Exception) {
                        error = failure.message ?: "مهلت تسویه معتبر نیست."
                    }
                },
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}


