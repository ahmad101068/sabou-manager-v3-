package ir.restaurant.management.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import ir.restaurant.management.domain.branch.BranchRecord

/** Canonical operational selector: branchId is identity; branch name is display-only. */
@Composable
internal fun CanonicalBranchSelector(
    branches: List<BranchRecord>,
    selectedBranchId: Long?,
    onBranchSelected: (Long?) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "شعبه",
    allowAllBranches: Boolean = false,
    enabled: Boolean = true,
    tag: String = "canonical_branch_selector",
) {
    var expanded by remember { mutableStateOf(false) }
    val activeBranches = remember(branches) { branches.filter { it.isActive } }
    val selected = selectedBranchId?.let { id -> branches.firstOrNull { it.id == id } }
    val display = when {
        selected != null -> selected.name
        allowAllBranches && selectedBranchId == null -> "همه شعب"
        branches.isEmpty() -> "شعبه‌ای تعریف نشده"
        else -> "انتخاب شعبه"
    }

    Box(modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            enabled = enabled && (branches.isNotEmpty() || allowAllBranches),
            modifier = Modifier.fillMaxWidth().testTag(tag),
        ) {
            Text("$label: $display", modifier = Modifier.weight(1f))
            Icon(Icons.Outlined.ArrowDropDown, contentDescription = "انتخاب شعبه")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            LazyColumn(Modifier.heightIn(max = 320.dp)) {
                if (allowAllBranches) {
                    item(key = "all-branches") {
                        DropdownMenuItem(
                            text = { Text("همه شعب") },
                            onClick = {
                                expanded = false
                                onBranchSelected(null)
                            },
                        )
                    }
                }
                items(activeBranches, key = { it.id }) { branch ->
                    DropdownMenuItem(
                        text = { Text(branch.name) },
                        onClick = {
                            expanded = false
                            onBranchSelected(branch.id)
                        },
                    )
                }
            }
        }
    }
}
