package ir.restaurant.management.domain.operations

import ir.restaurant.management.data.db.AppAlertEntity
import kotlinx.coroutines.flow.Flow

interface AlertRepository {
    fun alerts(): Flow<List<AppAlertEntity>>
    suspend fun refresh(todayEpochDay: Long)
    suspend fun markRead(id: Long)
    suspend fun markActioned(id: Long)
    suspend fun resolve(id: Long)
    suspend fun dismiss(id: Long)
    suspend fun clearDismissed()
}
