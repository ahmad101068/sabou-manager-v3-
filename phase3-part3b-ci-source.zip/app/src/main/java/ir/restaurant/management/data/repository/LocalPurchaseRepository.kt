package ir.restaurant.management.data.repository

import ir.restaurant.management.domain.security.Permission
import ir.restaurant.management.domain.common.DocumentNumberType

import androidx.room.withTransaction
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.core.QuantityMicros
import ir.restaurant.management.core.FixedPointRatio
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.PurchaseEntity
import ir.restaurant.management.data.db.PurchaseLineEntity
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.domain.accounting.BalancedJournalDraft
import ir.restaurant.management.domain.accounting.AccountingPostingContext
import ir.restaurant.management.domain.accounting.AccountingScope
import ir.restaurant.management.domain.accounting.JournalLineDraft
import ir.restaurant.management.domain.accounting.SemanticAccountRole
import ir.restaurant.management.domain.accounting.SemanticJournalDraft
import ir.restaurant.management.domain.accounting.SemanticJournalLine
import ir.restaurant.management.domain.purchase.PostedPurchase
import ir.restaurant.management.domain.purchase.PostedPurchaseSettlement
import ir.restaurant.management.domain.purchase.PurchaseCalculator
import ir.restaurant.management.domain.purchase.PurchaseDetails
import ir.restaurant.management.domain.purchase.PurchaseDraft
import ir.restaurant.management.domain.purchase.PurchaseLineRecord
import ir.restaurant.management.domain.purchase.PurchasePaymentMethod
import ir.restaurant.management.domain.purchase.PurchasePaymentStatus
import ir.restaurant.management.domain.purchase.PurchaseRepository
import ir.restaurant.management.domain.purchase.PurchaseReversalDraft
import ir.restaurant.management.domain.purchase.PurchaseSettlementDraft
import ir.restaurant.management.domain.purchase.PurchaseSettlementReversalDraft
import ir.restaurant.management.domain.purchase.PurchaseSettlementRecord
import ir.restaurant.management.domain.purchase.SettlementPaymentMethod
import ir.restaurant.management.domain.operations.UnitConversionFactor
import ir.restaurant.management.domain.inventory.InventoryCommandContext
import ir.restaurant.management.domain.inventory.InventoryMovementType
import ir.restaurant.management.domain.inventory.InventoryReasonCode
import ir.restaurant.management.domain.inventory.InventoryReferenceType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class LocalPurchaseRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
    private val authorizer: SessionAuthorizer,
) : PurchaseRepository {
    private val inventoryCommands = LocalInventoryCommandEngine(database, clock = clock)
    private val accountingPosting = LocalAccountingPostingEngine(database, clock = clock)
    private val auditWriter = LocalAuditEventWriter(database)
    private val numbering = LocalDocumentNumberAllocator(database, clock)
    private val branchResolver = CanonicalBranchResolver(database)
    override suspend fun post(draft: PurchaseDraft): PostedPurchase {
        val actor = authorizer.require(Permission.PURCHASES)
        val now = clock()

        return database.withTransaction {
            val numberedDraft = if (draft.invoiceNo.isBlank()) {
                var generated: String
                do { generated = numbering.next(DocumentNumberType.PURCHASE) } while (database.purchaseDao().invoiceExists(generated))
                draft.copy(invoiceNo = generated)
            } else draft
            val prepared = PurchaseCalculator.prepare(numberedDraft)
            val normalizedDraft = prepared.draft
            val branch = branchResolver.resolveOptional(normalizedDraft.branchId, normalizedDraft.branchName)
            val preparedLines = prepared.lines
            val total = prepared.total
            val supplier = database.supplierDao().activeById(normalizedDraft.supplierId)
                ?: error("تأمین‌کننده فعال پیدا نشد.")
            require(!database.purchaseDao().invoiceExists(normalizedDraft.invoiceNo)) {
                "شماره فاکتور خرید تکراری است."
            }

            val paid = normalizedDraft.paymentMethod != PurchasePaymentMethod.PAYABLE
            val purchaseId = database.purchaseDao().insert(
                PurchaseEntity(
                    invoiceNo = normalizedDraft.invoiceNo,
                    supplierId = supplier.id,
                    purchaseEpochDay = normalizedDraft.purchaseEpochDay,
                    branchName = branch?.name.orEmpty(),
                    branchId = branch?.id,
                    dueEpochDay = normalizedDraft.dueEpochDay,
                    totalRial = total.value,
                    paidRial = if (paid) total.value else 0,
                    paymentStatus = if (paid) PurchasePaymentStatus.PAID.storedValue else PurchasePaymentStatus.UNPAID.storedValue,
                    paymentMethod = normalizedDraft.paymentMethod.storedValue,
                    reminderEnabled = !paid && normalizedDraft.reminderEnabled,
                    reminderEpochDay = if (!paid && normalizedDraft.reminderEnabled) normalizedDraft.reminderEpochDay else null,
                    createdAtEpochMillis = now,
                ),
            )

            val purchaseLines = preparedLines.map { line ->
                val item = database.inventoryDao().activeById(line.itemId)
                    ?: error("یکی از کالاهای خرید پیدا نشد.")
                val stockQuantityMicros = UnitConversionFactor(
                    item.purchaseToStockNumerator, item.purchaseToStockDenominator,
                ).toStockMicros(line.quantityMicros)
                inventoryCommands.receive(
                    itemId = item.id,
                    quantityMicros = stockQuantityMicros,
                    valueRial = line.total.value,
                    movementType = InventoryMovementType.PURCHASE,
                    referenceType = InventoryReferenceType.PURCHASE,
                    referenceId = purchaseId,
                    movementEpochDay = normalizedDraft.purchaseEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.PURCHASE,
                        referenceId = purchaseId,
                        suffix = "receive:${item.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.PURCHASE_RECEIPT,
                        reason = "ثبت فاکتور ${normalizedDraft.invoiceNo}",
                        correlationId = "purchase:$purchaseId",
                    ),
                    notes = normalizedDraft.invoiceNo,
                )
                PurchaseLineEntity(
                    purchaseId = purchaseId,
                    itemId = item.id,
                    itemNameSnapshot = item.name,
                    quantityMicros = stockQuantityMicros,
                    unitCostRial = FixedPointRatio.unitCostRial(line.total.value, stockQuantityMicros),
                    lineTotalRial = line.total.value,
                )
            }
            database.purchaseDao().insertLines(purchaseLines)

            val journalId = if (total > MoneyRial.ZERO) {
                LocalAccountingPostingEngine(database, clock = clock).post(
                    draft = SemanticJournalDraft(
                        entryNo = "خ-$purchaseId",
                        description = "خرید مواد اولیه از ${supplier.name}",
                        entryEpochDay = normalizedDraft.purchaseEpochDay,
                        sourceType = "PURCHASE",
                        sourceId = purchaseId,
                        accountingScope = if (branch != null) AccountingScope.BRANCH else AccountingScope.ORGANIZATION,
                        branchId = branch?.id,
                        lines = listOf(
                            SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, debit = total),
                            SemanticJournalLine(normalizedDraft.paymentMethod.settlementRole, credit = total),
                        ),
                    ),
                    context = AccountingPostingContext.local(
                        sourceType = "PURCHASE",
                        sourceId = purchaseId,
                        suffix = "post",
                        actorId = actor.id,
                        correlationId = "purchase:$purchaseId",
                    ),
                )
            } else {
                null
            }
            syncRecorder?.record("PURCHASE", purchaseId, "CREATE", now)
            audit("CREATE", purchaseId, "ثبت فاکتور ${normalizedDraft.invoiceNo} به مبلغ ${total.value} ریال؛ سند=${journalId ?: 0}", now)
            PostedPurchase(purchaseId, journalId, total)
        }
    }

    override fun details(purchaseId: Long): Flow<PurchaseDetails?> =
        combine(
            database.purchaseDao().observeHeader(purchaseId),
            database.purchaseDao().observeDetailLines(purchaseId),
            database.accountingDao().observePurchaseSettlements(purchaseId),
        ) { header, lines, settlements ->
            header?.let {
                PurchaseDetails(
                    id = it.purchaseId,
                    invoiceNo = it.invoiceNo,
                    supplierName = it.supplierName,
                    purchaseEpochDay = it.purchaseEpochDay,
                    dueEpochDay = it.dueEpochDay,
                    totalRial = it.totalRial,
                    paidRial = it.paidRial,
                    paymentStatus = PurchasePaymentStatus.fromStoredValue(it.paymentStatus),
                    paymentMethod = PurchasePaymentMethod.fromStored(it.paymentMethod),
                    reminderEnabled = it.reminderEnabled,
                    reminderEpochDay = it.reminderEpochDay,
                    lines = lines.map { line ->
                        PurchaseLineRecord(
                            itemId = line.itemId,
                            itemName = line.itemName,
                            unit = line.unit,
                            quantityMicros = line.quantityMicros,
                            unitCostRial = line.unitCostRial,
                            lineTotalRial = line.lineTotalRial,
                        )
                    },
                    settlements = settlements.map { settlement ->
                        PurchaseSettlementRecord(
                            journalEntryId = settlement.journalEntryId,
                            entryNo = settlement.entryNo,
                            settlementEpochDay = settlement.settlementEpochDay,
                            amountRial = settlement.amountRial,
                            paymentMethod = SettlementPaymentMethod.fromStoredValue(settlement.paymentMethod),
                            referenceNo = settlement.referenceNo,
                            notes = settlement.notes,
                            isReversed = settlement.isReversed,
                        )
                    },
                )
            }
        }

    override suspend fun settle(draft: PurchaseSettlementDraft): PostedPurchaseSettlement {
        val actor = authorizer.require(Permission.PAYMENT_APPROVE)
        val valid = draft.validated()
        return database.withTransaction {
            val purchase = database.purchaseDao().byId(valid.purchaseId)
                ?: error("فاکتور خرید پیدا نشد.")
            val journalDraft = BalancedJournalDraft(
                entryEpochDay = valid.settlementEpochDay,
                description = "تسویه فاکتور ${purchase.invoiceNo} با ${valid.paymentMethod.title}",
                sourceType = "PURCHASE_SETTLEMENT",
                sourceId = purchase.id,
                accountingScope = if (purchase.branchId != null) AccountingScope.BRANCH else AccountingScope.ORGANIZATION,
                branchId = purchase.branchId,
                lines = listOf(
                    JournalLineDraft(
                        accountCode = ir.restaurant.management.domain.accounting.SystemSemanticAccountResolver.codeFor(SemanticAccountRole.SUPPLIER_PAYABLE),
                        debit = valid.amount,
                        memo = valid.notes,
                    ),
                    JournalLineDraft(
                        accountCode = ir.restaurant.management.domain.accounting.SystemSemanticAccountResolver.codeFor(valid.paymentMethod.settlementRole),
                        credit = valid.amount,
                        memo = valid.referenceNo,
                    ),
                ),
            )
            val postingContext = AccountingPostingContext.local(
                sourceType = "PURCHASE_SETTLEMENT",
                sourceId = purchase.id,
                suffix = "command:${valid.commandId}",
                actorId = actor.id,
                correlationId = "purchase_settlement:${valid.commandId}",
            )
            if (database.accountingDao().entryByIdempotencyKey(postingContext.idempotencyKey) != null) {
                val replay = accountingPosting.postBalanced(
                    draft = journalDraft,
                    context = postingContext,
                    entryNoFactory = { id -> "ت-$id" },
                )
                val currentRemaining = MoneyRial.of(purchase.totalRial) - MoneyRial.of(purchase.paidRial)
                return@withTransaction PostedPurchaseSettlement(
                    purchaseId = purchase.id,
                    journalEntryId = replay.entryId,
                    journalEntryNo = replay.entryNo,
                    remaining = currentRemaining,
                )
            }
            require(purchase.paymentMethod == null) {
                "این فاکتور هنگام خرید پرداخت شده است."
            }
            require(PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus) in setOf(PurchasePaymentStatus.UNPAID, PurchasePaymentStatus.PARTIAL)) {
                "این فاکتور قابل تسویه نیست."
            }
            require(valid.settlementEpochDay >= purchase.purchaseEpochDay) {
                "تاریخ تسویه نمی‌تواند قبل از تاریخ خرید باشد."
            }
            val remaining = MoneyRial.of(purchase.totalRial) - MoneyRial.of(purchase.paidRial)
            require(valid.amount <= remaining) {
                "مبلغ تسویه از مانده فاکتور بیشتر است."
            }

            val postedJournal = accountingPosting.postBalanced(
                draft = journalDraft,
                context = postingContext,
                entryNoFactory = { id -> "ت-$id" },
            )

            val newPaid = MoneyRial.of(purchase.paidRial) + valid.amount
            val newRemaining = MoneyRial.of(purchase.totalRial) - newPaid
            val paidInFull = newRemaining == MoneyRial.ZERO
            check(
                database.purchaseDao().updateSettlementState(
                    purchaseId = purchase.id,
                    expectedPaidRial = purchase.paidRial,
                    newPaidRial = newPaid.value,
                    paymentStatus = if (paidInFull) PurchasePaymentStatus.PAID.storedValue else PurchasePaymentStatus.PARTIAL.storedValue,
                    reminderEnabled = !paidInFull && purchase.reminderEnabled,
                    reminderEpochDay = if (paidInFull) null else purchase.reminderEpochDay,
                ) == 1,
            ) { "مانده فاکتور هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }

            syncRecorder?.record("PURCHASE", purchase.id, "SETTLEMENT", clock())
            audit("SETTLEMENT", purchase.id, "تسویه ${valid.amount.value} ریال؛ سند=${postedJournal.entryNo}؛ مانده=${newRemaining.value}", clock())

            PostedPurchaseSettlement(
                purchaseId = purchase.id,
                journalEntryId = postedJournal.entryId,
                journalEntryNo = postedJournal.entryNo,
                remaining = newRemaining,
            )
        }
    }


    override suspend fun reverseSettlement(draft: PurchaseSettlementReversalDraft) {
        val actor = authorizer.require(Permission.PAYMENT_APPROVE)
        authorizer.require(Permission.JOURNAL_REVERSE)
        val valid = draft.validated()
        database.withTransaction {
            val purchase = database.purchaseDao().byId(valid.purchaseId)
                ?: error("فاکتور خرید پیدا نشد.")
            require(purchase.paymentMethod == null) {
                "برگشت تسویه فقط برای خرید نسیه مجاز است."
            }
            require(PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus) != PurchasePaymentStatus.REVERSED) {
                "فاکتور برگشت‌خورده قابل اصلاح تسویه نیست."
            }
            val settlementEntry = database.accountingDao().entryById(valid.settlementJournalEntryId)
                ?: error("سند تسویه پیدا نشد.")
            require(settlementEntry.sourceType == "PURCHASE_SETTLEMENT" && settlementEntry.sourceId == purchase.id) {
                "سند انتخاب‌شده متعلق به این فاکتور نیست."
            }
            require(valid.reversalEpochDay >= settlementEntry.entryEpochDay) {
                "تاریخ برگشت تسویه نمی‌تواند قبل از تاریخ خود تسویه باشد."
            }
            val originalLines = database.accountingDao().linesByEntry(settlementEntry.id)
            require(originalLines.size >= 2) { "آرتیکل‌های سند تسویه کامل نیستند." }
            val amount = originalLines.fold(MoneyRial.ZERO) { total, line ->
                total + MoneyRial.of(line.debitRial)
            }
            require(amount > MoneyRial.ZERO) { "مبلغ سند تسویه معتبر نیست." }
            require(amount.value <= purchase.paidRial) {
                "مانده پرداخت‌شده فاکتور از مبلغ این تسویه کمتر است."
            }

            val now = clock()
            val reversalDraft = BalancedJournalDraft(
                entryEpochDay = valid.reversalEpochDay,
                description = "برگشت تسویه ${settlementEntry.entryNo}: ${valid.reason}",
                sourceType = "PURCHASE_SETTLEMENT_REVERSAL",
                sourceId = settlementEntry.id,
                accountingScope = AccountingScope.fromStoredValue(settlementEntry.accountingScope),
                branchId = settlementEntry.branchId,
                lines = originalLines.map { line ->
                    JournalLineDraft(
                        accountCode = line.accountCode,
                        debit = MoneyRial.of(line.creditRial),
                        credit = MoneyRial.of(line.debitRial),
                        memo = valid.reason,
                    )
                },
            )
            val postingContext = AccountingPostingContext.local(
                sourceType = "PURCHASE_SETTLEMENT_REVERSAL",
                sourceId = settlementEntry.id,
                suffix = "command:${valid.commandId}",
                actorId = actor.id,
                correlationId = "purchase_settlement_reversal:${valid.commandId}",
                reversalOfEntryId = settlementEntry.id,
            )
            if (database.accountingDao().entryByIdempotencyKey(postingContext.idempotencyKey) != null) {
                accountingPosting.postBalanced(
                    draft = reversalDraft,
                    context = postingContext,
                    entryNoFactory = { id -> "بت-$id" },
                )
                return@withTransaction
            }
            require(!database.accountingDao().hasSettlementReversal(settlementEntry.id)) {
                "این تسویه قبلاً برگشت خورده است."
            }
            accountingPosting.postBalanced(
                draft = reversalDraft,
                context = postingContext,
                entryNoFactory = { id -> "بت-$id" },
            )

            val newPaid = MoneyRial.of(purchase.paidRial) - amount
            val newStatus = if (newPaid == MoneyRial.ZERO) PurchasePaymentStatus.UNPAID.storedValue else PurchasePaymentStatus.PARTIAL.storedValue
            check(
                database.purchaseDao().updateSettlementState(
                    purchaseId = purchase.id,
                    expectedPaidRial = purchase.paidRial,
                    newPaidRial = newPaid.value,
                    paymentStatus = newStatus,
                    reminderEnabled = purchase.reminderEnabled,
                    reminderEpochDay = purchase.reminderEpochDay,
                ) == 1,
            ) { "مانده فاکتور هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
            syncRecorder?.record("PURCHASE", purchase.id, "SETTLEMENT_REVERSAL", now)
            audit("REVERSE_SETTLEMENT", purchase.id, "برگشت تسویه ${settlementEntry.entryNo} به مبلغ ${amount.value} ریال؛ دلیل=${valid.reason}", now)
        }
    }

    override suspend fun reverse(draft: PurchaseReversalDraft) {
        authorizer.require(Permission.PURCHASES)
        val actor = authorizer.require(Permission.JOURNAL_REVERSE)
        val valid = draft.validated()
        database.withTransaction {
            val purchase = database.purchaseDao().byId(valid.purchaseId)
                ?: error("فاکتور خرید پیدا نشد.")
            require(PurchasePaymentStatus.fromStoredValue(purchase.paymentStatus) != PurchasePaymentStatus.REVERSED) {
                "این فاکتور قبلاً برگشت خورده است."
            }
            require(!database.purchaseDao().isProcurementInvoice(purchase.id)) {
                "فاکتور تطبیق‌شده با سفارش خرید باید از مسیر برگشت کالا و اصلاح تدارکات برگشت بخورد."
            }
            require(valid.reversalEpochDay >= purchase.purchaseEpochDay) {
                "تاریخ برگشت نمی‌تواند قبل از تاریخ خرید باشد."
            }
            require(purchase.paidRial == 0L || purchase.paymentMethod != null) {
                "فاکتور نسیه‌ای که تسویه دارد ابتدا باید از مسیر اصلاح تسویه بررسی شود."
            }
            require(!database.accountingDao().hasPurchaseReversal(purchase.id)) {
                "برای این فاکتور قبلاً سند برگشت ثبت شده است."
            }
            val originalJournal = if (purchase.totalRial > 0) {
                database.accountingDao().entryBySource("PURCHASE", purchase.id)
                    ?: error("سند حسابداری خرید پیدا نشد.")
            } else null
            val originalJournalLines = originalJournal?.let { originalEntry ->
                database.accountingDao().linesByEntry(originalEntry.id).also { lines ->
                    require(lines.size >= 2) { "آرتیکل‌های سند خرید کامل نیستند." }
                }
            }.orEmpty()
            val purchaseLines = database.purchaseDao().linesByPurchase(purchase.id)
            require(purchaseLines.isNotEmpty()) { "ردیف‌های فاکتور خرید پیدا نشدند." }
            val now = clock()

            purchaseLines.forEach { line ->
                val item = database.inventoryDao().byId(line.itemId)
                    ?: error("کالای «${line.itemNameSnapshot}» پیدا نشد.")
                inventoryCommands.issue(
                    itemId = item.id,
                    quantityMicros = line.quantityMicros,
                    valueRial = line.lineTotalRial,
                    movementType = InventoryMovementType.PURCHASE_REVERSAL,
                    referenceType = InventoryReferenceType.PURCHASE,
                    referenceId = purchase.id,
                    movementEpochDay = valid.reversalEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.PURCHASE,
                        referenceId = purchase.id,
                        suffix = "reverse:${line.itemId}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.PURCHASE_REVERSAL,
                        reason = valid.reason,
                        correlationId = "purchase_reversal:${purchase.id}",
                    ),
                    notes = valid.reason,
                    lotPolicy = LocalInventoryCommandEngine.LotIssuePolicy.FEFO_ALLOCATED_ONLY,
                )
            }

            if (originalJournalLines.isNotEmpty()) {
                accountingPosting.postBalanced(
                    draft = BalancedJournalDraft(
                        entryEpochDay = valid.reversalEpochDay,
                        description = "برگشت فاکتور ${purchase.invoiceNo}: ${valid.reason}",
                        sourceType = "PURCHASE_REVERSAL",
                        sourceId = purchase.id,
                        accountingScope = AccountingScope.fromStoredValue(requireNotNull(originalJournal).accountingScope),
                        branchId = requireNotNull(originalJournal).branchId,
                        lines = originalJournalLines.map { line ->
                            JournalLineDraft(
                                accountCode = line.accountCode,
                                debit = MoneyRial.of(line.creditRial),
                                credit = MoneyRial.of(line.debitRial),
                                memo = valid.reason,
                            )
                        },
                    ),
                    context = AccountingPostingContext.local(
                        sourceType = "PURCHASE_REVERSAL",
                        sourceId = purchase.id,
                        suffix = "reverse:${purchase.id}",
                        actorId = actor.id,
                        correlationId = "purchase_reversal:${purchase.id}",
                        reversalOfEntryId = requireNotNull(originalJournal).id,
                    ),
                    entryNoFactory = { id -> "بخ-$id" },
                )
            }
            check(database.purchaseDao().markReversed(purchase.id) == 1) {
                "وضعیت فاکتور تغییر نکرد."
            }
            syncRecorder?.record("PURCHASE", purchase.id, "REVERSAL", now)
            audit("REVERSE", purchase.id, "برگشت فاکتور ${purchase.invoiceNo}؛ مبلغ=${purchase.totalRial}؛ دلیل=${valid.reason}", now)
        }
    }

    private suspend fun audit(action: String, entityId: Long, description: String, now: Long) {
        auditWriter.appendAuthorized(
            authorizer = authorizer,
            action = action,
            entityType = "PURCHASE",
            entityId = entityId,
            description = description,
            occurredAtEpochMillis = now,
            correlationId = "purchase:$entityId:$action:$now",
        )
    }
}
