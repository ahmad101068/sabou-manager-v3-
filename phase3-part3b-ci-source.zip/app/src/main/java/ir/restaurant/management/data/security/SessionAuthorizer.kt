package ir.restaurant.management.data.security

import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.domain.common.BusinessError
import ir.restaurant.management.domain.common.BusinessRuleViolation
import ir.restaurant.management.domain.security.AuthorizationService
import ir.restaurant.management.domain.security.AuthorizedActor
import ir.restaurant.management.domain.security.Permission
import ir.restaurant.management.domain.security.UserRole

class AuthenticationRequiredException :
    BusinessRuleViolation(BusinessError.AuthenticationRequired)

class AccessDeniedException(val permission: Permission) :
    BusinessRuleViolation(BusinessError.PermissionDenied(permission))

/** Enforces authorization at the data-command boundary. UI filtering is not a security boundary. */
class SessionAuthorizer(private val database: AppDatabase) : AuthorizationService {
    suspend fun actor(): String = database.securityDao().currentUser()
        ?.let { it.displayName.ifBlank { it.username } }
        ?: "SYSTEM"

    override suspend fun actorIdentity(): AuthorizedActor {
        val user = database.securityDao().currentUser() ?: throw AuthenticationRequiredException()
        if (!user.isActive) throw AuthenticationRequiredException()
        return AuthorizedActor(
            id = user.id,
            displayName = user.displayName.ifBlank { user.username },
            role = UserRole.fromStoredValue(user.role),
        )
    }

    override suspend fun can(permission: Permission): Boolean {
        val user = database.securityDao().currentUser() ?: return false
        if (!user.isActive) return false
        return UserRole.fromStoredValue(user.role).allows(permission)
    }

    override suspend fun require(permission: Permission): AuthorizedActor {
        val actor = actorIdentity()
        val role = actor.role
        if (!role.allows(permission)) throw AccessDeniedException(permission)
        return actor
    }

    suspend fun requireOwner(): AuthorizedActor {
        val actor = actorIdentity()
        if (actor.role != UserRole.OWNER) {
            throw AccessDeniedException(Permission.MANAGE_USERS)
        }
        return actor
    }

    internal suspend fun currentUserId(): Long {
        return actorIdentity().id
    }
}
