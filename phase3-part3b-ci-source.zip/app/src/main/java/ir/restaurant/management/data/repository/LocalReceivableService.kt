package ir.restaurant.management.data.repository

import androidx.room.withTransaction
import ir.restaurant.management.core.GlobalId
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.core.SignedLongMath
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.CustomerReceivableLedgerEntity
import ir.restaurant.management.data.db.ReceivableCollectionEntity
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.domain.accounting.AccountingPostingContext
import ir.restaurant.management.domain.accounting.AccountingScope
import ir.restaurant.management.domain.accounting.BalancedJournalDraft
import ir.restaurant.management.domain.accounting.JournalLineDraft
import ir.restaurant.management.domain.accounting.SemanticAccountRole
import ir.restaurant.management.domain.accounting.SemanticJournalDraft
import ir.restaurant.management.domain.accounting.SemanticJournalLine
import ir.restaurant.management.domain.receivables.ReceivableAging
import ir.restaurant.management.domain.receivables.ReceivableCollectionDraft
import ir.restaurant.management.domain.receivables.ReceivableCollectionMethod
import ir.restaurant.management.domain.receivables.ReceivableCollectionReversalDraft
import ir.restaurant.management.domain.receivables.ReceivableRecord
import ir.restaurant.management.domain.receivables.ReceivableService
import ir.restaurant.management.domain.receivables.ReceivableStatus
import ir.restaurant.management.domain.receivables.ReceivableType
import ir.restaurant.management.domain.security.Permission
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalReceivableService(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val clock: () -> Long = System::currentTimeMillis,
) : ReceivableService {
    private val accounting = LocalAccountingPostingEngine(database, clock = clock)
    private val audit = LocalAuditEventWriter(database)
    private val branchResolver = CanonicalBranchResolver(database)

    override fun observeOpen(branchId: Long): Flow<List<ReceivableRecord>> =
        database.businessOperationsDao().observeOpenReceivables(branchId).map { rows ->
            rows.map { row ->
                ReceivableRecord(row.id,row.globalId,row.branchId,row.partyId,ReceivableType.valueOf(row.type),row.sourceType,row.sourceId,row.originalAmountRial,row.paidAmountRial,row.outstandingAmountRial,row.issueEpochDay,row.dueEpochDay,ReceivableStatus.valueOf(row.status))
            }
        }

    override suspend fun collect(draft: ReceivableCollectionDraft): Long {
        val actor = authorizer.require(Permission.RECEIVABLE_COLLECT)
        val now = clock()
        return database.withTransaction {
            val dao = database.businessOperationsDao()
            val current = dao.receivable(draft.receivableId) ?: error("مطالبه پیدا نشد.")
            branchResolver.requireExisting(current.branchId)
            require(current.status in setOf("OPEN", "PARTIALLY_PAID")) { "این مطالبه قابل وصول نیست." }
            val valid = draft.validated(current.outstandingAmountRial)
            val collectionId = dao.insertCollection(
                ReceivableCollectionEntity(
                    globalId = GlobalId.new().value,
                    receivableId = current.id,
                    amountRial = valid.amountRial,
                    method = valid.method.name,
                    cashboxId = valid.cashboxId,
                    bankAccountId = valid.bankAccountId,
                    reference = valid.reference,
                    businessEpochDay = valid.businessEpochDay,
                    createdByUserId = actor.id,
                    createdAtEpochMillis = now,
                ),
            )
            val ledgerReference = receivableLedgerReference(current.id)
            database.customerReceivableDao().insertLedger(
                CustomerReceivableLedgerEntity(
                    customerId = current.partyId,
                    businessEpochDay = valid.businessEpochDay,
                    entryType = "COLLECTION",
                    debitRial = 0,
                    creditRial = valid.amountRial,
                    sourceType = "RECEIVABLE_COLLECTION",
                    sourceId = collectionId,
                    reference = ledgerReference,
                    dueEpochDay = current.dueEpochDay,
                    actorId = actor.id,
                    createdAtEpochMillis = now,
                ),
            )
            val newPaid = SignedLongMath.add(current.paidAmountRial, valid.amountRial)
            val outstanding = SignedLongMath.subtract(current.originalAmountRial, newPaid)
            val status = if (outstanding == 0L) "PAID" else "PARTIALLY_PAID"
            check(dao.updateReceivableBalance(current.id, newPaid, outstanding, status, now) == 1)
            check(database.customerReceivableDao().balanceByReference(current.partyId, ledgerReference) == outstanding) {
                "مانده سند دریافتنی با دفتر دریافتنی یکسان نیست."
            }
            val debitRole = when (valid.method) {
                ReceivableCollectionMethod.CASH -> SemanticAccountRole.CASH
                ReceivableCollectionMethod.CARD, ReceivableCollectionMethod.BANK_TRANSFER -> SemanticAccountRole.BANK
            }
            val creditRole = if (current.type == "CORPORATE") SemanticAccountRole.CORPORATE_RECEIVABLE else SemanticAccountRole.PERSONAL_RECEIVABLE
            accounting.post(
                SemanticJournalDraft(
                    entryNo = "RCV-$collectionId",
                    entryEpochDay = valid.businessEpochDay,
                    description = "وصول مطالبات؛ بدون ایجاد درآمد جدید",
                    sourceType = "RECEIVABLE_COLLECTION",
                    sourceId = collectionId,
                    accountingScope = AccountingScope.BRANCH,
                    branchId = current.branchId,
                    lines = listOf(
                        SemanticJournalLine(debitRole, debit = MoneyRial.of(valid.amountRial)),
                        SemanticJournalLine(creditRole, credit = MoneyRial.of(valid.amountRial)),
                    ),
                ),
                AccountingPostingContext.local(
                    sourceType = "RECEIVABLE_COLLECTION",
                    sourceId = collectionId,
                    suffix = "collect",
                    actorId = actor.id,
                    correlationId = "receivable_collection:$collectionId",
                ),
            )
            audit.appendAuthorized(authorizer,"COLLECT","RECEIVABLE",current.id,"وصول ${valid.amountRial} ریال؛ مانده=$outstanding",now,valid.businessEpochDay,correlationId="receivable_collection:$collectionId")
            collectionId
        }
    }

    override suspend fun reverseCollection(draft: ReceivableCollectionReversalDraft) {
        val actor = authorizer.require(Permission.RECEIVABLE_ADJUST)
        val valid = draft.validated()
        val now = clock()
        database.withTransaction {
            val dao = database.businessOperationsDao()
            val collection = dao.collection(valid.collectionId) ?: error("وصول مطالبات پیدا نشد.")
            if (collection.reversedAtEpochMillis != null) return@withTransaction
            val receivable = dao.receivable(collection.receivableId) ?: error("مطالبه مرتبط پیدا نشد.")
            val originalJournal = database.accountingDao().entryBySource("RECEIVABLE_COLLECTION", collection.id)
                ?: error("سند حسابداری وصول پیدا نشد.")
            val originalLines = database.accountingDao().linesByEntry(originalJournal.id)
            require(originalLines.size >= 2) { "آرتیکل‌های سند وصول کامل نیستند." }
            val reversal = accounting.postBalanced(
                BalancedJournalDraft(
                    entryEpochDay = valid.reversalEpochDay,
                    description = "برگشت وصول مطالبات: ${valid.reason}",
                    sourceType = "RECEIVABLE_COLLECTION_REVERSAL",
                    sourceId = collection.id,
                    accountingScope = AccountingScope.fromStoredValue(originalJournal.accountingScope),
                    branchId = originalJournal.branchId,
                    lines = originalLines.map { line ->
                        JournalLineDraft(
                            accountCode = line.accountCode,
                            debit = MoneyRial.of(line.creditRial),
                            credit = MoneyRial.of(line.debitRial),
                            memo = valid.reason,
                        )
                    },
                ),
                AccountingPostingContext.local(
                    sourceType = "RECEIVABLE_COLLECTION_REVERSAL",
                    sourceId = collection.id,
                    suffix = "reverse:${originalJournal.id}",
                    actorId = actor.id,
                    correlationId = "receivable_collection_reversal:${collection.id}",
                    reversalOfEntryId = originalJournal.id,
                ),
                entryNoFactory = { id -> "RCVR-$id" },
            )
            val ledgerReference = receivableLedgerReference(receivable.id)
            database.customerReceivableDao().insertLedger(
                CustomerReceivableLedgerEntity(
                    customerId = receivable.partyId,
                    businessEpochDay = valid.reversalEpochDay,
                    entryType = "COLLECTION_REVERSAL",
                    debitRial = collection.amountRial,
                    creditRial = 0,
                    sourceType = "RECEIVABLE_COLLECTION_REVERSAL",
                    sourceId = collection.id,
                    reference = ledgerReference,
                    dueEpochDay = receivable.dueEpochDay,
                    actorId = actor.id,
                    createdAtEpochMillis = now,
                ),
            )
            val newPaid = SignedLongMath.subtract(receivable.paidAmountRial, collection.amountRial)
            require(newPaid >= 0) { "مانده وصول سند دریافتنی نامعتبر شد." }
            val outstanding = SignedLongMath.subtract(receivable.originalAmountRial, newPaid)
            val status = if (newPaid == 0L) "OPEN" else "PARTIALLY_PAID"
            check(dao.updateReceivableBalance(receivable.id, newPaid, outstanding, status, now) == 1)
            check(database.customerReceivableDao().balanceByReference(receivable.partyId, ledgerReference) == outstanding) {
                "مانده سند دریافتنی با دفتر دریافتنی یکسان نیست."
            }
            check(dao.markCollectionReversed(collection.id, now, valid.reason, reversal.entryId) == 1)
            audit.appendAuthorized(
                authorizer,"REVERSE_COLLECTION","RECEIVABLE",receivable.id,
                "برگشت وصول ${collection.amountRial} ریال؛ مانده=$outstanding",now,valid.reversalEpochDay,
                reason=valid.reason,correlationId="receivable_collection_reversal:${collection.id}",
            )
        }
    }

    override suspend fun aging(branchId: Long, todayEpochDay: Long): ReceivableAging {
        authorizer.require(Permission.RECEIVABLE_VIEW)
        require(branchId > 0 && todayEpochDay > 0)
        branchResolver.requireExisting(branchId)
        // Branch aging contains only facts with trustworthy branch attribution. Legacy rows are
        // preserved by the canonical allocator as unassigned rather than being fabricated as branch 1.
        val lots = CanonicalReceivableReadModel(database).openLotsForBranch(branchId)
        var current=0L; var d1=0L; var d8=0L; var d31=0L; var d61=0L; var d90=0L
        lots.forEach { lot ->
            val days = todayEpochDay - lot.dueEpochDay
            when {
                days <= 0 -> current = SignedLongMath.add(current, lot.outstandingRial)
                days <= 7 -> d1 = SignedLongMath.add(d1, lot.outstandingRial)
                days <= 30 -> d8 = SignedLongMath.add(d8, lot.outstandingRial)
                days <= 60 -> d31 = SignedLongMath.add(d31, lot.outstandingRial)
                days <= 90 -> d61 = SignedLongMath.add(d61, lot.outstandingRial)
                else -> d90 = SignedLongMath.add(d90, lot.outstandingRial)
            }
        }
        return ReceivableAging(current,d1,d8,d31,d61,d90)
    }

    private fun receivableLedgerReference(receivableId: Long): String = "RECEIVABLE:$receivableId"
}
