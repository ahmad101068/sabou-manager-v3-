package ir.restaurant.management.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.restaurant.management.core.MoneyRial
import ir.restaurant.management.core.QuantityMicros
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.BranchEntity
import ir.restaurant.management.data.db.InventoryItemEntity
import ir.restaurant.management.data.db.SupplierEntity
import ir.restaurant.management.data.security.SessionAuthorizer
import ir.restaurant.management.domain.operations.UserDraft
import ir.restaurant.management.domain.operations.UserRole
import ir.restaurant.management.domain.purchase.PurchaseDraft
import ir.restaurant.management.domain.purchase.PurchaseLineDraft
import ir.restaurant.management.domain.purchase.PurchasePaymentMethod
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class BranchPurchasePostingIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var repository: LocalPurchaseRepository
    private var now = 1_920_000_000_000L

    @Before
    fun setUp() = runBlocking {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        val authorizer = SessionAuthorizer(database)
        val security = LocalSecurityRepository(database, clock = { ++now }, authorizer = authorizer)
        val ownerId = security.save(null, UserDraft("branch-purchase-owner", "مالک خرید شعبه", "123456", UserRole.OWNER, "87654321"))
        security.switchUser(ownerId, "123456")
        database.branchDao().insert(
            BranchEntity(id = 2L, globalId = "test:purchase:branch:2", code = "P2", name = "ونک", createdAtEpochMillis = now, updatedAtEpochMillis = now),
        )
        repository = LocalPurchaseRepository(database, clock = { ++now }, authorizer = authorizer)
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun branchPurchaseUsesCanonicalBranchButDoesNotBecomeOperatingExpense() = runBlocking {
        val supplierId = database.supplierDao().insert(
            SupplierEntity(name = "تأمین‌کننده خرید شعبه", createdAtEpochMillis = now, updatedAtEpochMillis = now),
        )
        val itemId = database.inventoryDao().insert(
            InventoryItemEntity(
                name = "ماده اولیه خرید شعبه",
                category = "مواد اولیه",
                unit = "کیلوگرم",
                supplierId = supplierId,
                createdAtEpochMillis = now,
                updatedAtEpochMillis = now,
            ),
        )

        val posted = repository.post(
            PurchaseDraft(
                invoiceNo = "BR-P-2",
                supplierId = supplierId,
                purchaseEpochDay = 30_000L,
                dueEpochDay = 30_010L,
                paymentMethod = PurchasePaymentMethod.PAYABLE,
                reminderEnabled = false,
                reminderEpochDay = null,
                lines = listOf(PurchaseLineDraft(itemId, QuantityMicros.positive(1), MoneyRial.of(12_000_000L))),
                branchId = 2L,
            ),
        )

        val journalId = requireNotNull(posted.journalEntryId)
        val journal = requireNotNull(database.accountingDao().entryById(journalId))
        assertEquals("BRANCH", journal.accountingScope)
        assertEquals(2L, journal.branchId)
        val lines = database.accountingDao().linesByEntry(journalId)
        assertEquals(12_000_000L, lines.single { it.accountCode == "1301" }.debitRial)
        assertEquals(0L, database.accountingDao().branchProfitLoss(2L, 30_000L, 30_000L).operatingExpensesExcludingPayrollRial)
    }
}
