package ir.restaurant.management.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.CustomerEntity
import ir.restaurant.management.data.db.CustomerReceivableLedgerEntity
import ir.restaurant.management.data.db.SalesInvoiceEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AlertReceivableIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var alerts: LocalAlertRepository
    private var now = 100_000L

    @Before
    fun setUp() {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        alerts = LocalAlertRepository(database)
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun fullySettledOverdueInvoice_doesNotGenerateFalseReceivableAlert_butPartialDoes() = runBlocking {
        val today = 40_000L
        val settled = insertCustomer("CUS-ALERT-1", "مشتری تسویه‌شده")
        val partial = insertCustomer("CUS-ALERT-2", "مشتری بدهکار")
        insertCreditInvoice(settled, "SAL-A-1", today - 20, today - 10, 100_000L)
        insertCreditInvoice(partial, "SAL-A-2", today - 20, today - 10, 100_000L)
        insertLedger(settled, today - 20, today - 10, 100_000L, 0L, "SALES_INVOICE", 1)
        insertLedger(settled, today - 5, null, 0L, 100_000L, "TREASURY_RECEIPT", settled)
        insertLedger(partial, today - 20, today - 10, 100_000L, 0L, "SALES_INVOICE", 2)
        insertLedger(partial, today - 5, null, 0L, 40_000L, "TREASURY_RECEIPT", partial)

        alerts.refresh(today)
        val receivableAlerts = alerts.alerts().first().filter { it.sourceType == "CUSTOMER_RECEIVABLE" }

        assertEquals(1, receivableAlerts.size)
        assertEquals(partial, receivableAlerts.single().sourceId)
        assertEquals(60_000L, messageAmount(receivableAlerts.single().message))
    }

    private suspend fun insertCustomer(code: String, name: String): Long = database.salesDao().insertCustomer(
        CustomerEntity(
            customerCode = code,
            name = name,
            phone = "",
            nationalId = "",
            creditLimitRial = 500_000L,
            notes = "",
            createdAtEpochMillis = now++,
            updatedAtEpochMillis = now++,
        ),
    )

    private suspend fun insertCreditInvoice(customerId: Long, no: String, day: Long, due: Long, credit: Long): Long =
        database.salesDao().insertInvoice(
            SalesInvoiceEntity(
                invoiceNo = no,
                commandId = "00000000-0000-4000-8000-${customerId.toString().padStart(12, '0')}",
                businessEpochDay = day,
                customerId = customerId,
                dueEpochDay = due,
                grossRial = credit,
                discountRial = 0,
                serviceRial = 0,
                taxRial = 0,
                netRial = credit,
                creditRial = credit,
                theoreticalCostRial = 0,
                journalEntryId = null,
                cogsJournalEntryId = null,
                status = "POSTED",
                notes = "",
                createdByActorId = 1,
                createdAtEpochMillis = now++,
            ),
        )

    private suspend fun insertLedger(
        customerId: Long,
        day: Long,
        due: Long?,
        debit: Long,
        credit: Long,
        sourceType: String,
        sourceId: Long,
    ) = database.customerReceivableDao().insertLedger(
        CustomerReceivableLedgerEntity(
            customerId = customerId,
            businessEpochDay = day,
            entryType = sourceType,
            debitRial = debit,
            creditRial = credit,
            sourceType = sourceType,
            sourceId = sourceId,
            dueEpochDay = due,
            actorId = 1,
            createdAtEpochMillis = now++,
        ),
    )

    private fun messageAmount(message: String): Long =
        Regex("مانده سررسیدشده ([0-9]+) ریال").find(message)?.groupValues?.get(1)?.toLong()
            ?: error("مبلغ هشدار از پیام قابل استخراج نیست: $message")
}
