package ir.restaurant.management.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.restaurant.management.core.QuantityMicros
import ir.restaurant.management.data.db.AppDatabase
import ir.restaurant.management.data.db.InventoryItemEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AlertStateIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var repository: LocalAlertRepository
    private var now = 6_000_000L
    private val today = 24_000L

    @Before
    fun setUp() {
        database = AppDatabase.createInMemory(ApplicationProvider.getApplicationContext<Context>())
        repository = LocalAlertRepository(database)
    }

    @After
    fun tearDown() = database.close()

    @Test
    fun repeatedRefresh_isIdempotent_andStateTransitionsFollowRealConditionLifecycle() = runBlocking {
        val itemId = database.inventoryDao().insert(
            InventoryItemEntity(
                name = "کالای هشدار تست",
                category = "TEST",
                unit = "عدد",
                stockMicros = 5 * QuantityMicros.SCALE,
                alertThresholdMicros = 10 * QuantityMicros.SCALE,
                alertEnabled = true,
                createdAtEpochMillis = ++now,
                updatedAtEpochMillis = ++now,
            ),
        )

        repository.refresh(today)
        val first = repository.alerts().first().single { it.sourceType == "LOW_STOCK" && it.sourceId == itemId }
        assertEquals("NEW", first.status)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM app_alerts WHERE sourceType='LOW_STOCK' AND sourceId=$itemId"))

        repository.refresh(today)
        val replay = repository.alerts().first().single { it.sourceType == "LOW_STOCK" && it.sourceId == itemId }
        assertEquals(first.id, replay.id)
        assertEquals(1L, scalar("SELECT COUNT(*) FROM app_alerts WHERE sourceType='LOW_STOCK' AND sourceId=$itemId"))

        repository.markRead(first.id)
        assertEquals("READ", stringScalar("SELECT status FROM app_alerts WHERE id=${first.id}"))
        assertEquals(1L, scalar("SELECT isRead FROM app_alerts WHERE id=${first.id}"))

        repository.markActioned(first.id)
        assertEquals("ACTIONED", stringScalar("SELECT status FROM app_alerts WHERE id=${first.id}"))

        database.openHelper.writableDatabase.execSQL(
            "UPDATE inventory_items SET stockMicros=${20 * QuantityMicros.SCALE}, updatedAtEpochMillis=${++now} WHERE id=$itemId",
        )
        repository.refresh(today)
        assertEquals("RESOLVED", stringScalar("SELECT status FROM app_alerts WHERE id=${first.id}"))
        assertTrue(repository.alerts().first().none { it.id == first.id })

        database.openHelper.writableDatabase.execSQL(
            "UPDATE inventory_items SET stockMicros=${5 * QuantityMicros.SCALE}, updatedAtEpochMillis=${++now} WHERE id=$itemId",
        )
        repository.refresh(today)
        val reopened = repository.alerts().first().single { it.sourceType == "LOW_STOCK" && it.sourceId == itemId }
        assertEquals(first.id, reopened.id)
        assertEquals("NEW", reopened.status)

        repository.dismiss(reopened.id)
        assertEquals("DISMISSED", stringScalar("SELECT status FROM app_alerts WHERE id=${reopened.id}"))
        assertTrue(repository.alerts().first().none { it.id == reopened.id })
        repository.clearDismissed()
        assertEquals(0L, scalar("SELECT COUNT(*) FROM app_alerts WHERE id=${reopened.id}"))
    }

    private fun scalar(sql: String): Long = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getLong(0)
    }

    private fun stringScalar(sql: String): String = database.openHelper.writableDatabase.query(sql).use { cursor ->
        check(cursor.moveToFirst())
        cursor.getString(0)
    }
}
