package ir.restaurant.management.data.security

import ir.restaurant.management.domain.operations.SensitiveAction
import kotlin.test.assertFailsWith
import org.junit.Test

class SensitiveActionGateTest {
    private var now = 10_000L
    private val gate = SensitiveActionGate(clockMillis = { now }, permitLifetimeMillis = 5_000L)

    @Test
    fun permitIsBoundToUserActionAndSingleConsumption() {
        gate.grant(7L, SensitiveAction.CLOSE_ACCOUNTING_PERIOD)

        assertFailsWith<SensitiveAuthenticationRequiredException> {
            gate.requireAndConsume(8L, SensitiveAction.CLOSE_ACCOUNTING_PERIOD)
        }
        assertFailsWith<SensitiveAuthenticationRequiredException> {
            gate.requireAndConsume(7L, SensitiveAction.REOPEN_ACCOUNTING_PERIOD)
        }

        gate.requireAndConsume(7L, SensitiveAction.CLOSE_ACCOUNTING_PERIOD)
        assertFailsWith<SensitiveAuthenticationRequiredException> {
            gate.requireAndConsume(7L, SensitiveAction.CLOSE_ACCOUNTING_PERIOD)
        }
    }

    @Test
    fun expiredAndInvalidatedPermitsAreRejected() {
        gate.grant(3L, SensitiveAction.RESTORE_BACKUP)
        now += 5_001L
        assertFailsWith<SensitiveAuthenticationRequiredException> {
            gate.requireAndConsume(3L, SensitiveAction.RESTORE_BACKUP)
        }

        gate.grant(3L, SensitiveAction.FACTORY_RESET)
        gate.invalidateAll()
        assertFailsWith<SensitiveAuthenticationRequiredException> {
            gate.requireAndConsume(3L, SensitiveAction.FACTORY_RESET)
        }
    }
}
