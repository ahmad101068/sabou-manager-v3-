# نقشه قابلیت ماژول‌ها — alpha153.5

| ماژول | وضعیت | اتصال اصلی | مسئله/ریسک باقی‌مانده | Target |
|---|---|---|---|---|
| Dashboard و Quick Actions | FUNCTIONAL / NEEDS VISUAL TEST | DashboardRepository → DashboardViewModel → DashboardScreen | تست تبلت، Landscape و Font Scale واقعی اجرا نشده | Adaptive dashboard با Visual Regression |
| خرید و تأمین‌کننده | FUNCTIONAL / NEEDS REFACTOR | Room + Purchase/Procurement Repository → OperationsViewModel → Purchase UI | Repository و Screen بزرگ؛ Build کامل لازم است | تفکیک تدریجی Presentation بدون تغییر Workflow |
| انبار، شمارش و ضایعات | FUNCTIONAL | OperationsRepository → Inventory UI | تست دستگاه و داده حجیم اجرا نشده | تست Flow بحرانی و Benchmark Query |
| رسپی نسخه‌دار | FUNCTIONAL | RecipeRepository → RecipeViewModel → Recipe UI | Full Cost طبق Sprint بعدی ناقص است | Migration 39→40 فقط در Sprint مستقل |
| فروش روزانه POS | FUNCTIONAL | DailySalesRepository → DailySalesViewModel → DailySalesScreen | Visual/IME test اجرا نشده | Compose UI test و داده حجیم |
| حسابداری | FUNCTIONAL / NEEDS REFACTOR | AccountingRepository → AccountingViewModel → Accounting UI | Screen و DAO بزرگ؛ حساس به Regression | Refactor مرحله‌ای پس از CI سبز |
| پرسنل، حقوق و عملکرد | FUNCTIONAL | Personnel/Performance Repository → ViewModel → Personnel UI | Performance زیر Workflow پرسنل است، Route مستقل ندارد | تست Navigation داخلی و State restoration |
| دارایی ثابت | FUNCTIONAL | AssetRepository → AssetViewModel → Asset UI | Busy state صریح در مدل ندارد | افزودن Action state در Batch مستقل |
| هشدارها | FUNCTIONAL / UPGRADED | AlertRepository → AlertViewModel → AlertCenter | Permission denial دائمی نیازمند لینک تنظیمات سیستم است | Permission state کامل و UI test |
| گزارش و چاپ | FUNCTIONAL / HARDENED | Repository snapshots → Reports UI → local WebView print | چاپ روی دستگاه واقعی تأیید نشده | Print regression روی API 23/35 |
| کاربران و دسترسی | FUNCTIONAL / SECURITY SENSITIVE | SecurityRepository → SecurityViewModel → Security UI | Biometric وجود ندارد | PIN fallback + Biometric در Sprint مستقل |
| پشتیبان و Restore | FUNCTIONAL / SECURITY SENSITIVE | BackupManager + Security Gate → Security UI | Restore دستگاه دوم اجرا نشده | Device-to-device restore gate |
| مرکز کنترل مدیریت | FUNCTIONAL / NEEDS REFACTOR | ManagementControlRepository → ViewModel → Screen | Screen متراکم و بزرگ | IA و Progressive Disclosure پس از تست بصری |
| Sync چنددستگاهی | PARTIAL / DISABLED | Outbox + LocalSyncRepository + Transport | Push/Pull و Apply تراکنشی کامل نیست | همچنان Fail-Closed تا تکمیل Protocol |
| CRM | LEGACY / DISCONNECTED | پوشه Domain خالی و بدون Route/Entity فعال | خارج از دامنه محصول فعلی | حذف فقط پس از تصمیم محصول؛ فعلاً بدون اثر Runtime |

## اتصال Featureها

- تمام Screenهای موجود در `AppScreen` در Router اصلی شاخه دارند و دسترسی آن‌ها با `canOpenScreen` کنترل می‌شود.
- Repositoryهای اصلی توسط `AppContainer` ساخته و به ViewModelهای متصل تزریق می‌شوند.
- Performance به‌صورت بخش داخلی ماژول پرسنل مصرف می‌شود و Feature بدون مصرف نیست.
- Procurement داخل خرید و مرکز کنترل مدیریت مصرف می‌شود.
- Sync UI موجود است اما قابلیت عملیاتی به‌صورت آگاهانه مسدود باقی مانده است.
