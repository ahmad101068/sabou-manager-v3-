# تغییرات نسخه 3.0.0-alpha110-compile-fix

## اصلاح خطاهای کامپایل GitHub Actions

- افزودن `return` صریح به تابع ساخت فایل پشتیبان.
- ارسال صحیح `customerId` و `creditLimitRial` به سیاست اعتبار مشتری.
- افزودن import لازم برای `LaunchedEffect` در رابط Compose.
- افزودن کنترل ایستا برای هر سه اصلاح بالا.

## نسخه

- `versionCode`: 143
- `versionName`: `3.0.0-alpha110-compile-fix`
