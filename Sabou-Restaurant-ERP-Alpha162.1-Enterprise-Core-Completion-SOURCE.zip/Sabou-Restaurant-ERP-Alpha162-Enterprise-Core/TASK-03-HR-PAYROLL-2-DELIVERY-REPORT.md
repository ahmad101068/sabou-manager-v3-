# TASK 03 — HR / Payroll 2.0 Delivery Report

Baseline: Sabou Restaurant ERP — Alpha159 Inventory 2.0 CI-Repair  
Delivered version: `3.0.0-alpha160.0-hr-payroll-2` (`versionCode=203`)  
Database: schema `43 -> 44`  
Date: 2026-08-09

## Executive Summary

ماژول legacy پرسنل/حقوق به یک HR & Payroll document system تبدیل شد. رکورد جاری کارمند دیگر منبع حقیقت تاریخ مالی نیست: قراردادها versioned، سمت/دپارتمان/شعبه effective-dated، حضور event-based، و هر حقوق یک Payslip مستقل با Snapshot و Component Ledger است. محاسبه، بررسی، تأیید، accrual، پرداخت خزانه، برگشت و revision از هم جدا و با مجوز، audit، correlation ID، idempotency و optimistic transition کنترل می‌شوند.

Historical payroll با تغییر بعدی نام، حقوق، قرارداد، policy، حضور یا مرخصی دوباره محاسبه نمی‌شود. داده schema 43 بدون جعل جزئیات به legacy period/batch/payslipهای deterministic مهاجرت می‌کند.

## HR/Payroll Before

- `EmployeeEntity` یک row mutable شامل current salary، job، اطلاعات حساس و raw status بود.
- قرارداد update-in-place می‌شد و resolver با `LIMIT 1` conflict را پنهان می‌کرد.
- حضور یک aggregate روزانه قابل overwrite و بدون correction evidence بود.
- مرخصی entitlement ledger یا تفکیک paid/unpaid قابل اتکا نداشت.
- `payroll_runs` totals را نگه می‌داشت، اما Period/Batch/Payslip/Snapshot/Component نبود.
- approval مستقیماً حقوق را PAID و journal را شامل cash/bank می‌کرد؛ accrual و payment یکی بودند.
- payment ledger، partial payment، idempotency و treasury service implementation وجود نداشت.
- UX یک صفحه بزرگ و permissions درشت‌دانه بود.

گزارش ممیزی کامل پیش از implementation در `docs/HR-PAYROLL-CURRENT-STATE-AUDIT.md` ثبت شده است.

## HR/Payroll After

- Employee 360 با profile جاری، private metadata ماسک‌شده، assignment history و timeline projection.
- Contract history immutable/versioned با resolver deterministic و overlap guard.
- Attendance event ledger، derived summary، anomaly detection و correction workflow.
- Leave typed workflow و balance ledger با paid/unpaid payroll inputs.
- Payroll Period، Batch، Payslip، immutable Snapshot و positive-amount Component Ledger.
- Calculation deterministic با `Long`، checked arithmetic و HALF_UP.
- review/approval/SoD، accrual accounting، partial Treasury payment و compensating reversal.
- Legacy history preservation با incomplete marker و بدون component/event/payment ساختگی.
- People/Attendance/Leave/Payroll/Advances/Performance navigation و Employee 360 tabs.

## Architecture Changes

| Boundary | مسئولیت نهایی |
|---|---|
| Personnel/Workforce | Employee master، assignment/contract history، attendance، leave، advances |
| Payroll | period/batch/payslip/snapshot/component و lifecycle commands |
| Accounting Foundation | accrual، settlement و reversal از `AccountingPostingService` |
| Treasury Foundation | payment و compensating reversal از `TreasuryService` adapter |
| Security Foundation | typed permissions در application boundary |
| Audit Foundation | actor/action/entity/reason/before-after/correlation |

parallel architecture ایجاد نشده است. مسیرهای قدیمی payroll write در repository با typed unsupported failure بسته شده‌اند تا سند مالی جدید دور زده نشود.

## Database Changes

Schema 44 هجده جدول جدید، indexهای employee/contract/attendance/leave/payroll/payment/advance و 34 trigger حفاظتی اضافه می‌کند. مهم‌ترین constraints شامل unique employee code، contract number، period key، batch document/idempotency، employee+period+revision و payment idempotency key است. Snapshot/components/approved payslip/payment/allocation/approval/receipt به‌صورت append-only یا controlled-transition محافظت می‌شوند.

Room schema export: `app/schemas/ir.sabou.inventory.data.db.AppDatabase/44.json`.

## Employee 360

`employees` current projection باقی مانده، ولی identity/contact/employment fields تکمیل شده است. `employee_private_profiles` داده ملی/بیمه و فقط metadata ماسک‌شده بانک/IBAN را جدا می‌کند. Employee timeline از sourceهای authoritative ساخته می‌شود و جدول truth موازی ندارد. queryهای timeline/history با `limit/offset` bounded هستند.

## Contract History

`employment_contract_versions` شامل contract number، version، effective range، base salary، standard minutes، policy references، assignment snapshot، creator/approver و replacement link است. قرارداد referenced/frozen edit یا delete نمی‌شود. successor پس از approval predecessor را `SUPERSEDED` می‌کند. overlap در domain و DB رد و conflict legacy در anomaly ledger ثبت می‌شود.

`EffectiveContractResolver` فقط exactly-one contract برمی‌گرداند؛ zero و multiple به‌ترتیب `NoEffectiveContract` و `ConflictingContracts` هستند.

## Attendance

`attendance_events` رویدادهای clock-in/out، break start/end، manual adjustment و absence mark را با source/actor/device/location/reason/correlation ثبت می‌کند. `AttendanceEventAggregator` first-in/last-out، worked/break/late/early/overtime/absence و anomalyها را مشتق می‌کند. correction دارای before/after، reason، actor، approval، audit و payroll-lock است. daily attendance legacy حفظ شده و event ساختگی تولید نشده است.

## Leave

Leave type/statusها typed شده‌اند و `leave_ledger_entries` grant/use/restore را ثبت می‌کند. balance برابر granted/used/pending/remaining واقعی است. فقط leave تأییدشده/taken وارد payroll می‌شود؛ paid leave absence deduction ایجاد نمی‌کند و unpaid leave component مستقل و traceable دارد.

## Payroll Period

Period دارای start/end/due date، lifecycle typed، opener/closer و close/reopen command است. period دارای batch تسویه‌نشده بسته نمی‌شود و closed period calculation/approval را رد می‌کند.

## Payroll Batch

Batch دارای document number، period، scope، branch/department، creator/calculator/reviewer/approver، correlation، exception count و KPI totals است. lifecycle فقط با state machine و compare-and-set تغییر می‌کند:

`DRAFT -> CALCULATED -> UNDER_REVIEW -> APPROVED -> PAYMENT_PENDING -> PARTIALLY_PAID/PAID -> REVERSED`.

## Payslip

برای هر employee در batch یک Payslip مستقل با revision پایدار، contract link، totals، paid/remaining و lifecycle وجود دارد. unique employee+period+revision برقرار است؛ financial edit/delete پس از approval ممنوع است.

## Components

هر component مقدار مثبت، direction مستقل (`EARNING`/`DEDUCTION`)، type، source/sourceId، quantity/rate و manual override metadata دارد. manual adjustment بدون reason/actor/approval وارد calculation نمی‌شود. Componentهای business شامل base salary، overtime، bonus، allowance، insurance، tax، absence/late، unpaid leave، advance و سایر adjustmentهای واقعی هستند.

## Calculation Engine

`PayrollCalculationService` از immutable input snapshot نتیجه deterministic شامل components، gross، deductions، net و warnings می‌سازد. پول فقط `Long`/`MoneyRial` است؛ basis pointها fixed-point و rounding صریحاً HALF_UP است. checked arithmetic overflow و negative net را typed failure می‌کند. Calculation هیچ accounting یا treasury side effect ندارد.

## Historical Snapshot

`payroll_snapshots` employee name/code، contract ID/number/version، base salary، standard/eligible/actual/overtime/absence/late/paid/unpaid minutes، policy ID/version/parameters، totals، calculation version و hash را freeze می‌کند. Approval hash را دوباره اعتبارسنجی می‌کند. تغییر live employee/contract/policy/attendance هیچ read-time recalculation روی approved history ندارد.

## Payroll History

Employee 360 همه ماه‌ها و revisionها را با period، gross، deductions، net، paid، remaining، status، batch و revision نشان می‌دهد. detail شامل contract snapshot، attendance/leave inputs، components، advance allocations، approval events، payment ledger، journal references، reversal/revision و audit است. query bounded و indexed است.

## Approval

Calculate، review و final approval فرمان‌های مستقل‌اند. Creator یا Calculator نمی‌تواند final approver همان batch باشد. Approval در transaction snapshot completeness/hash، exceptions، payslip totals، advance allocations و state را validate می‌کند؛ سپس accrual را از accounting boundary ثبت، اسناد را freeze و approval/audit/receipt را append می‌کند.

## Advances

Advance principal/issued/outstanding/status و accounting/treasury references حفظ شده است. هر payroll deduction allocation مستقل، مثبت، capped به outstanding و idempotent دارد. partial allocation پشتیبانی و reversal outstanding را با compensating allocation restore می‌کند؛ over-allocation و duplicate رد می‌شوند.

## Accounting

Approval از `AccountingPostingService` برای recognition هزینه/بدهی استفاده می‌کند. Payroll از semantic account roleها برای salary، overtime، bonus، insurance/tax payable، advance offset و employee payable استفاده می‌کند؛ direct Journal DAO mutation و account-code پراکنده وجود ندارد. Payment جداگانه liability را settle می‌کند و reversal balanced/compensating است.

## Treasury/Payment

`LocalTreasuryServiceAdapter` foundation موجود را بدون cash/bank mutation مستقیم پیاده می‌کند. `payroll_payments` ledger شامل payslip، amount، treasury account/transaction، date/reference/status، creator، idempotency key و correlation است. پرداخت کامل، چند پرداخت جزئی، remaining derived، overpayment rejection، duplicate replay و compensating payment reversal پشتیبانی می‌شوند. full Treasury 2.0 طبق scope بازطراحی نشده است.

## Security

مجوزهای view-own، view-all، sensitive edit، contract approve، attendance correct، leave approve، payroll create/calculate/review/approve/reverse/pay جدا هستند. enforcement در `HrPayrollCommandService`/repository boundary انجام می‌شود، نه فقط UI. Cashier به حقوق کارکنان دسترسی ندارد. account/card/IBAN در UI ماسک و از audit/log payload حذف می‌شوند.

## Audit

Employee create/edit، contract change/approval، attendance correction، leave decision، payroll calculate/review/approve/reverse، manual adjustment، payment و advance allocation audit می‌شوند. evidence شامل actor، action، entity، business date، system timestamp، reason، correlation و before/after لازم است.

## Idempotency

`hr_payroll_command_receipts` برای calculate/approve/post/pay/reverse/allocate command ID، payload hash و result را ثبت می‌کند. replay برابر همان result را برمی‌گرداند؛ replay با payload متفاوت `IdempotencyConflict` است. rowVersion/CAS و unique constraints race ناشی از double tap، retry و two approvers را مهار می‌کنند.

## Migration

Schema 43 data حذف یا overwrite نمی‌شود. Employees/contracts/attendance/leaves/advances/payroll runs حفظ می‌شوند. payroll تاریخی برای هر دوره به legacy period/batch/payslip deterministic تبدیل می‌شود و `source=LEGACY_MIGRATION`, `componentDetailComplete=false`, incomplete snapshot دارد. contract/policy/attendance ناشناخته به گذشته نسبت داده نمی‌شود. component، payment، allocation یا clock event ساختگی ساخته نمی‌شود. overlapها repair نمی‌شوند و anomaly ثبت می‌گردد.

Host verifier تمام 186 statement واقعی migration/guard را روی دو schema 43 مستقل اجرا و 49 integrity check را PASS کرده است.

## UI/UX

Navigation جدید: People، Attendance، Leave، Payroll، Advances، Performance. People search نام/code/phone/job/department/status و contract status filters دارد. Employee detail به Overview/Employment/Contracts/Attendance/Leave/Payroll/Advances/Performance/Documents/Audit تقسیم شده است. Payroll Center queueها، KPI، exception center، payslip detail، partial payment و reversal را نمایش می‌دهد. UI RTL، مبلغ Rial format و تاریخ شمسی presentation دارد و business date را از system timestamp جدا نگه می‌دارد. Workforce ownership از Management Control خارج شده است.

## Files Added

37 فایل افزوده شد:

- `app/schemas/ir.sabou.inventory.data.db.AppDatabase/44.json`
- `app/src/androidTest/java/ir/sabou/inventory/data/db/HrPayrollMigration43To44Test.kt`
- `app/src/main/java/ir/sabou/inventory/data/db/HrPayrollDao.kt`
- `app/src/main/java/ir/sabou/inventory/data/db/HrPayrollEntities.kt`
- `app/src/main/java/ir/sabou/inventory/data/db/HrPayrollGuards.kt`
- `app/src/main/java/ir/sabou/inventory/data/db/migration/HrPayrollMigrations.kt`
- `app/src/main/java/ir/sabou/inventory/data/repository/LocalHrPayrollService.kt`
- `app/src/main/java/ir/sabou/inventory/data/treasury/LocalTreasuryServiceAdapter.kt`
- `app/src/main/java/ir/sabou/inventory/domain/operations/LegacyWorkflowCompatibility.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/AttendanceCorrectionCodec.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/AttendanceEventAggregator.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/EffectiveContractResolver.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/HrPayrollCommandService.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/HrPayrollModels.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/HrPayrollTypes.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/LeaveBalanceCalculator.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/PayrollAccountingPlanner.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/PayrollCalculationService.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/PayrollPaymentLedger.kt`
- `app/src/main/java/ir/sabou/inventory/domain/personnel/PayrollStateMachines.kt`
- `app/src/main/java/ir/sabou/inventory/ui/HrPayrollScreens.kt`
- شش unit test جدید HR/Payroll زیر `app/src/test/.../domain/personnel/`
- هشت سند design/audit/test/migration/transaction/UX زیر `docs/`
- `scripts/verify-hr-payroll-migration.py`
- این گزارش تحویل.

## Files Modified

33 فایل baseline اصلاح شد:

- build/database wiring: `app/build.gradle.kts`, `AppDatabase.kt`, `AppMigrations.kt`, `DatabaseIntegrityLifecycle.kt`, `DatabaseSeedCallback.kt`, `AppContainer.kt`.
- personnel/application: `PersonnelDao.kt`, `PersonnelEntities.kt`, `PersonnelModels.kt`, `LocalPersonnelRepository.kt`.
- boundaries/security: `AccountingPosting.kt`, `BusinessError.kt`, `Permission.kt`, `TreasuryModels.kt`.
- UX/navigation: `ManagementControlScreen.kt`, `ManagementRoutes.kt`, `PersonnelScreens.kt`, `PersonnelViewModel.kt`, `SabouApp.kt`, `WorkforceRoutes.kt`.
- compatibility fixes: `CashFlowCalculator.kt`, `InventoryWasteModels.kt`, `SyncRetryPolicy.kt` و `SyncStatusCalculatorTest.kt`.
- Android test compile fixes: `FullMigration1ToCurrentTest.kt`, `AccountingPostingIntegrationTest.kt`, `AssetOutboxIntegrationTest.kt`, `RecipeVersionIntegrationTest.kt`.
- permission test: `PermissionMappingTest.kt`.
- foundation docs/scripts: `ARCHITECTURE-FOUNDATION-STATUS.md`, `DOMAIN-BOUNDARIES.md`, `FOUNDATION-VERIFICATION-REPORT.md`, `verify-foundation.sh`.

## Files Removed

هیچ فایل baseline حذف نشد و هیچ test برای سبز شدن build حذف یا skip نشد.

## Tests Added

- `EmployeeContractHistoryV2Test`: 4 test.
- `AttendanceEventAggregatorV2Test`: 3 test.
- `LeaveBalanceV2Test`: 2 test.
- `PayrollCalculationServiceV2Test`: 6 test.
- `PayrollLifecycleV2Test`: 3 test.
- `PayrollPaymentLedgerV2Test`: 5 test.
- `PermissionMappingTest`: یک test role/permission جدید.
- `HrPayrollMigration43To44Test`: migration instrumentation test.
- `verify-hr-payroll-migration.py`: executable host migration/integrity verifier.

## Tests Executed

| Command / Suite | Result |
|---|---|
| `./gradlew :app:testDebugUnitTest` | PASS — 234 tests، 0 failure، 0 error، 0 skipped |
| `scripts/verify-hr-payroll-migration.py` | PASS — 186 statements، 49 checks، deterministic=1 |
| `scripts/verify-foundation.sh` | PASS |
| `./gradlew :app:assembleDebugAndroidTest` | PASS — instrumentation APK ساخته شد |
| `./gradlew :app:connectedDebugAndroidTest` | NOT EXECUTED — emulator/device در محیط موجود نبود |

instrumentation migration test compile شده است؛ همان production SQL با verifier مستقل روی SQLite واقعاً اجرا شده است. ریسک runtime Android framework در بخش Remaining Risks ثبت شده است.

## Build Result

| Gate | Result |
|---|---|
| `./gradlew :app:compileDebugKotlin` | PASS |
| `./gradlew :app:assembleDebug` | PASS |
| Debug APK | `app/build/outputs/apk/debug/app-debug.apk` |
| Android test APK | `app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk` |

## Remaining Risks

- `connectedDebugAndroidTest` به علت نبود emulator/device اجرا نشد؛ این gate باید در CI دارای Android runner اجرا شود.
- load benchmark واقعی روی device برای 1,000 employee / 100,000 attendance / 50,000 component اجرا نشده؛ queryها bounded/indexed/bulk هستند، اما latency دستگاه production باید اندازه‌گیری شود.
- semantic account mapping و treasury account setup قبل از production باید با chart/config واقعی هر رستوران validate شود.

این موارد implementation یا build را block نمی‌کنند؛ برای deploy production operational gates هستند.

## Remaining Technical Debt

- Full Workforce Scheduling 2.0، device ingestion و shift swap workflow متعلق به Task بعدی است.
- Full Treasury 2.0 خارج scope است؛ adapter فعلی boundary صحیح را رعایت می‌کند.
- PDF renderer/document vault خارج scope است؛ Payslip snapshot export-ready است.
- legacy rows عمداً component detail ندارند؛ تنها راه تکمیل آنها ورود evidence واقعی و correction workflow است، نه reconstruction از current salary.

## Completion Matrix

| Capability | Status | Evidence |
|---|---|---|
| Employee 360 | DONE | profile/private/assignment/timeline/tabs |
| Employee Code | DONE | deterministic backfill، allocator، unique/stable guard |
| Employment Status | DONE | typed state + transition validator + DB guard |
| Contract History | DONE | version/replacement/freeze/overlap |
| Effective Contract Resolver | DONE | exactly-one + typed zero/conflict |
| Attendance Events | DONE | append-only typed event ledger |
| Attendance Summary | DONE | derived summary + anomalies |
| Leave Integration | DONE | ledger + paid/unpaid payroll trace |
| Payroll Period | DONE | lifecycle/close/reopen |
| Payroll Batch | DONE | scope/state/KPI/exceptions |
| Payslip | DONE | independent employee document + revision |
| Payslip Snapshot | DONE | immutable complete native snapshot/hash |
| Payroll Components | DONE | typed source ledger/direction |
| Calculation Engine | DONE | deterministic Long/HALF_UP/checked math |
| Payroll History | DONE | bounded month/revision/detail |
| Approval Workflow | DONE | calculate/review/approve separated |
| Segregation of Duties | DONE | creator/calculator != approver |
| Advances | DONE | capped partial allocation + reversal |
| Accounting Integration | DONE | `AccountingPostingService`, accrual/payment split |
| Treasury Integration | DONE | `TreasuryService` adapter، no direct cash mutation |
| Partial Payment | DONE | append-only ledger + derived remaining |
| Reversal/Revision | DONE | compensating reversal + new revision |
| Authorization | DONE | granular application-boundary permissions |
| Audit | DONE | lifecycle evidence + before/after/correlation |
| Idempotency | DONE | command receipts + payload hash + CAS |
| Migration | DONE | preservation/no fabrication/deterministic verifier PASS |
| Performance | DONE | indexed/bounded/bulk query architecture |
| UX | DONE | six homes + Employee 360 + Payroll Center |
| Tests | DONE | 234 unit + host migration + test APK; device runtime NOT EXECUTED |
| Build | DONE | compileDebugKotlin/assembleDebug/AndroidTest APK PASS |

## Final Status

`HR_PAYROLL_2_COMPLETE`
