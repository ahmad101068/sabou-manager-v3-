# تغییرات alpha153.9 — Inventory Command Center

- دفتر گردش سراسری با Search، فیلتر ورود/خروج/ضایعات، جمع ارزش و Item Drill-down اضافه شد.
- گردش موجودی به Global Search افزوده شد و نتیجه مستقیماً Item 360 را باز می‌کند.
- هشدار کمبود موجودی و بدهی خرید به کالا یا فاکتور مقصد متصل شد.
- Quick Action و مقصد Navigation مستقل برای دفتر گردش اضافه شد.
- `versionCode`: 196؛ Schema: 39 بدون Migration.
