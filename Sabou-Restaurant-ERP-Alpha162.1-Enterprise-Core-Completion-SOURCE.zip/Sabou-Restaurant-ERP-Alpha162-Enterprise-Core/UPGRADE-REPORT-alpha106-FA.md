# گزارش ارتقا Alpha 106

نسخه: `3.0.0-alpha106-integration-tests`  
Version code: `139`  
Schema: `18`

## هدف و نتیجه

این موج ادعاهای امنیت و اتمی‌بودن Alpha104/105 را به تست‌های اجرایی Room تبدیل می‌کند. تست‌ها session خالی، bootstrap مالک، مرز نقش مدیر، rate limit PIN، rollback شکست outbox و commit موفق دارایی+outbox را پوشش می‌دهند.

CI علاوه بر unit/lint/build، emulatorهای API 23 و API 35 را بالا می‌آورد و `connectedDebugAndroidTest` را روی هر دو اجرا می‌کند. نسخه action emulator روی `v2.30.1` ثابت شده تا تغییر ناگهانی dependency روی workflow اثر نگذارد.

طبق مستندات Android، `PBKDF2withHmacSHA256` از API 26 در دسترس است. قالب جدید PIN از PBKDF2-HMAC-SHA1 با 310 هزار iteration و prefix نسخه‌دار استفاده می‌کند تا minSdk 23 واقعاً پشتیبانی شود. hashهای قدیمی در دستگاه‌های سازگار پس از ورود موفق خودکار به قالب جدید ارتقا می‌یابند.

## وضعیت اعتبارسنجی محلی

کنترل ایستا و اعتبار YAML در محیط ممیزی اجرا می‌شود. اجرای Gradle/Emulator محلی همچنان به‌علت مسدودبودن دانلود Gradle ممکن نیست؛ معیار پذیرش این نسخه سبزشدن کامل workflow روی GitHub Actions است.

مجموعه فعلی شامل ۶۷ تست واحد و ۷ تست Android است.
