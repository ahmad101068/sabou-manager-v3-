# تغییرات alpha153.7 — Product Evolution

- `versionCode`: 194
- `versionName`: `3.0.0-alpha153.7-product-evolution`
- Database schema: 39 (بدون Migration)

Dashboard اجرایی، Global Search داده‌محور، فیلتر و Sort انبار، فیلتر اسناد، جست‌وجوی پرسنل، پروفایل مالی کارکنان، Drill-down گزارش پرسنل و Quick Actionهای جدید اضافه شدند.
