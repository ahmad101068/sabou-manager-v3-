# گزارش ارتقا Alpha 105

نسخه: `3.0.0-alpha105-sync-contract`  
Version code: `138`  
Schema: `18`

## نتیجه موج دوم

قرارداد outbox اکنون payload نسخه‌دار، revision و hash واقعی دارد. مهاجرت 17→18 رکوردهای قدیمی ناقص را قرنطینه می‌کند و یک تست Android مستقل ساختار و داده را بررسی می‌کند. مسیرهای وصول فروش بازنویسی شده‌اند و محاسبات گزارش فروش، KPI و metrics از primitive arithmetic پرخطر فاصله گرفته‌اند.

## مرز این نسخه

payload فعلی یک فرمان canonical و tamper-evident است؛ برای replication کامل چنددستگاهی هنوز باید snapshot دامنه‌ای هر entity، سیاست merge اختصاصی و transport احراز‌شده سمت سرور در موج بعد اضافه شود.

## اعتبارسنجی لازم

در محیط CI باید `testDebugUnitTest`, `lintDebug`, `assembleDebug`, `assembleDebugAndroidTest` و `assembleRelease` سبز شوند. تست migration باید روی emulator اجرا شود و schema تولیدشده نسخه 18 پس از build به مخزن افزوده شود.

کنترل ایستای محلی و YAML موفق بود. مجموعه فعلی شامل ۶۷ تست واحد و یک تست Android است؛ اجرای Gradle محلی به‌علت مسدودبودن دانلود توزیع Gradle در محیط ممیزی ممکن نشد.
