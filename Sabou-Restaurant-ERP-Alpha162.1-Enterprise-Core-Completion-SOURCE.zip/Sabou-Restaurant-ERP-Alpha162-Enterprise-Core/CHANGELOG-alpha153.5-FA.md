# تغییرات alpha153.5 — Android Modernization

## Compose و Lifecycle

- جمع‌آوری ۱۲ StateFlow اصلی از `collectAsState` به `collectAsStateWithLifecycle` منتقل شد تا Collection هنگام پس‌زمینه بودن UI متوقف شود.
- وابستگی رسمی `lifecycle-runtime-compose` با همان خانواده نسخه Lifecycle موجود اضافه شد.
- Navigation stack، دیالوگ خروج، Query جست‌وجوی سراسری، Query فروش و تب حسابداری در Recreation حفظ می‌شوند.
- Theme دیگر Context را مستقیماً به Activity cast نمی‌کند و ContextWrapper را امن resolve می‌کند.

## UI/UX

- Permission اعلان در Startup درخواست نمی‌شود؛ توضیح و اقدام روشن داخل مرکز هشدارها نمایش داده می‌شود.
- وضعیت Refresh هشدارها Progress قابل‌مشاهده دارد.
- جست‌وجوی مشترک دارای IME مناسب و دکمه پاک‌کردن قابل‌دسترسی است.
- توضیح Empty Stateها برای خوانایی بهتر وسط‌چین شد.
- فهرست Moduleها و نتایج جست‌وجو کلید پایدار دارند.

## Performance

- جست‌وجوی فروش، خرید و اسناد حسابداری با Debounce ۲۵۰ میلی‌ثانیه اجرا می‌شود تا Queryهای متوالی Room کاهش یابند.
- Collectionهای Flow با Lifecycle صفحه هماهنگ شده‌اند و کار پس‌زمینه غیرضروری کاهش می‌یابد.

## Compatibility

- Schema دیتابیس نسخه ۳۹ است.
- Migration، تغییر قرارداد Repository یا بازنویسی منطق مالی وجود ندارد.
- Sync همچنان fail-closed است.
