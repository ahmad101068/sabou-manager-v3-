# آزمون نسخه alpha109 در GitHub

1. محتوای پوشه پروژه را در ریشه مخزن GitHub قرار دهید.
2. از بخش **Actions**، گردش‌کار **Build Sabou APK** را اجرا کنید.
3. ابتدا مرحله `Verify foundation` و سپس `Build APK` باید موفق شوند.
4. پس از پایان، Artifact با نام زیر را دانلود کنید:

`sabou-manager-alpha109-debug-apk-<run number>`

اگر اجرا شکست خورد، ZIP کامل Logs همان اجرا را ارسال کنید؛ پیام اصلی معمولاً در فایل
مرحله‌ای است که قرمز شده است.
