# Changelog — alpha156 ERP 2.0 Ledger Foundation

## Added

- `GlobalId`، `FixedPointRatio` و Business Errorهای type-safe
- Permission/Role type-safe و Separation of Duties policy
- Inventory command context و ledger result idempotent
- Audit event envelope و writer اتمیک
- سند immutable ضایعات و metadata سازمانی شمارش موجودی/انتقال لات
- Migration `41→42`، edge test و Full Migration `1→current`
- تست‌های Integration ثبت حسابداری و دفتر موجودی
- مستندات Audit، Architecture، Migration و Roadmap

## Changed

- ثبت سند به `DRAFT → lines → POSTED` در Transaction مالک Accounting منتقل شد.
- Journal قطعی، Stock Movement، Count، Waste Document، Transfer و Audit در DB append-only شدند.
- دریافت/خروج/شمارش/ضایعات/انتقال/برگشت موجودی مالک Transaction و idempotency شدند.
- شمارش موجودی به Permission مستقل و PIN مجدد متصل شد.
- purchase/payroll approval actor ID و SoD دریافت کردند.
- Performance persistence از `Double` به `Long micros` canonical مهاجرت کرد.
- خطاهای Business در UI به پیام فارسی actionable map می‌شوند.
- CI روی API 23 و 35، unit test، lint، Debug/Release و Android Test gate دارد.

## Fixed

- حذف destructive داده‌های Audit در Migration تاریخی `30→31`
- خطر partial write در موتور موجودی و posting حسابداری
- امکان ویرایش/حذف Journal قطعی در دوره باز
- fallback ناامن role ناشناخته به Cashier
- ضرب خام مستعد overflow در نسبت‌های unit cost
- تکرار فرمان‌های Manual Journal، Payroll، Settlement، Waste و Inventory Count

## Known limitations

- Build Gradle در محیط تولید بسته اجرا نشد؛ CI قبل از Merge الزامی است.
- Schema export نسخه 42 باید توسط Room/KSP در CI تولید و بازبینی شود.
- این نسخه foundation است و تکمیل POS/KDS/Production/Treasury/Sync/Multi-branch را ادعا نمی‌کند.
