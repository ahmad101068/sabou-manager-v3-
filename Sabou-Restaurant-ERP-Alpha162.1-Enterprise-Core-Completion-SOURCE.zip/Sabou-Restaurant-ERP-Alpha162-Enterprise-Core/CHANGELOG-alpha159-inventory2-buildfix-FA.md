# Alpha159 Inventory 2.0 — CI Compile Buildfix

این اصلاحیه خطاهای گزارش‌شده در `:app:compileDebugKotlin` از لاگ CI شماره
`84906939378` را با کمترین تغییر ممکن برطرف می‌کند.

## اصلاحات سورس

- فراخوانی نصب guardهای دوره بسته در Migration با مالک واقعی آن،
  `AccountSeedCallback.installClosedPeriodGuards(db)`، qualified شد؛ SQL و ترتیب
  Migration تغییر نکرد.
- call-site دریافت خرید با قرارداد فعلی `ReceiveInventoryCommand` هماهنگ شد و
  `businessEpochDay` جای نام قدیمی `movementEpochDay` را گرفت؛ مقدار و semantics
  تاریخ کسب‌وکار بدون تغییر باقی ماند.
- callback فیلد تاریخ انقضا با آرگومان نام‌دار `onSelected` و متغیر صریح
  `selectedExpiryEpochDay` ارسال شد تا trailing lambda به پارامتر نهایی `Modifier`
  متصل نشود؛ رفتار حفظ state تغییر نکرد.
- نگاشت نمایشی `InventoryMovementType` برای شش مقدار Inventory 2.0 به‌صورت
  explicit و exhaustive تکمیل شد؛ از `else` یا fallback پنهان استفاده نشده است.

## دامنه اثر

- Database schema: بدون تغییر
- Migration SQL/data transformation: بدون تغییر
- Accounting / inventory transaction semantics: بدون تغییر
- DAO و Repository contract: بدون تغییر
- UI behavior: فقط رفع اتصال اشتباه callback و تکمیل عنوان typeهای موجود

## Verification

- Kotlin syntax parsing برای هر چهار فایل تغییرکرده: `PASS`
- `scripts/verify-foundation.sh`: `PASS`
- `git diff --check`: `PASS`
- `:app:compileDebugKotlin`: `NOT EXECUTED` در محیط تحویل؛ Gradle Wrapper برای
  دریافت Gradle 8.13 به `services.gradle.org` نیاز داشت و شبکه محیط آن را مسدود
  کرد. تأیید نهایی باید با rerun همان GitHub Actions انجام شود.
- `:app:assembleDebug` و تست‌های Gradle: `NOT EXECUTED` به همان دلیل.

هیچ task یا check در GitHub Actions حذف، suppress یا permissive نشده است.
