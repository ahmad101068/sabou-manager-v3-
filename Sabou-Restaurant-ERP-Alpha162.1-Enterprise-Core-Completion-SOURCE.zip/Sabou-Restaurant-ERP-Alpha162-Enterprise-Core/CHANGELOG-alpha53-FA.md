# تغییرات Sabou Manager v3 — alpha53

نسخه: `3.0.0-alpha53-module-upgrade` — `versionCode 78`

## ارتقاهای انجام‌شده

- مرور استاتیک همه ۷۹ فایل بخش اصلی برنامه و تمام ماژول‌های داده، دامنه و رابط کاربری.
- حذف همه force unwrapهای `!!` از سورس اصلی Kotlin.
- ایمن‌سازی خواندن تنظیم پوسته در `MainActivity` در برابر مقدار null یا مقدار قدیمی نامعتبر.
- حذف force unwrap حساب پرداخت خرید و افزودن خطای دامنه‌ای روشن برای روش پرداخت بدون حساب.
- حذف force unwrap شناسه ماده اولیه در فرم رسپی.
- افزودن `UiErrorHandler` برای:
  - ثبت stack trace خطاهای غیرمنتظره در Logcat؛
  - حفظ لغو coroutine؛
  - تفکیک خطاهای اعتبارسنجی، فایل و خطای داخلی؛
  - جلوگیری از نمایش مستقیم جزئیات خطای داخلی به کاربر.
- اتصال مدیریت خطای جدید به `SalesViewModel` و `SecurityViewModel`.
- اجرای موفق آزمون ساختاری `scripts/verify-foundation.sh`.

## وضعیت Build

فرمان زیر اجرا شد:

```bash
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug
```

Gradle Wrapper به علت نبود دسترسی DNS به `services.gradle.org` نتوانست Gradle 8.13 را دریافت کند؛ بنابراین Build نهایی در این محیط تأیید نشده و باید در GitHub Actions اجرا شود.
