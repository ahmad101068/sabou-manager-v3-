#!/usr/bin/env python3
"""Offline Alpha161 migration/guard verification against the real exported v44 schema."""
from __future__ import annotations

import json
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "app/schemas/ir.sabou.inventory.data.db.AppDatabase/44.json"
MIGRATION = ROOT / "app/src/main/java/ir/sabou/inventory/data/db/migration/ProfessionalErpMigrations.kt"
GUARDS = ROOT / "app/src/main/java/ir/sabou/inventory/data/db/ProfessionalSalesGuards.kt"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"ALPHA161_SQL_VERIFICATION=FAIL {message}")


def main() -> None:
    database = json.loads(SCHEMA.read_text(encoding="utf-8"))["database"]
    migration_text = MIGRATION.read_text(encoding="utf-8")
    guards_text = GUARDS.read_text(encoding="utf-8")
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")

    for entity in database["entities"]:
        table = entity["tableName"]
        db.execute(entity["createSql"].replace("${TABLE_NAME}", table))
        for index in entity.get("indices", []):
            db.execute(index["createSql"].replace("${TABLE_NAME}", table))
    for query in database.get("setupQueries", []):
        db.execute(query)

    table_sql = re.findall(r'"""(CREATE TABLE IF NOT EXISTS .*?)"""', migration_text, flags=re.S)
    index_sql = re.findall(r'"(CREATE (?:UNIQUE )?INDEX IF NOT EXISTS [^"]+)"', migration_text)
    require(len(table_sql) >= 11, "migration tables were not parsed")
    require(len(index_sql) >= 30, "migration indexes were not parsed")
    for sql in table_sql + index_sql:
        db.execute(sql)

    trigger_sql = re.findall(
        r'db\.execSQL\("""(CREATE TRIGGER IF NOT EXISTS .*?)"""\)',
        guards_text,
        flags=re.S,
    )
    for sql in trigger_sql:
        db.execute(sql)
    for table, prefix in re.findall(r'immutable\(db, "([^"]+)", "([^"]+)"\)', guards_text):
        db.execute(
            f"CREATE TRIGGER IF NOT EXISTS {prefix}_no_update BEFORE UPDATE ON {table} "
            "BEGIN SELECT RAISE(ABORT, 'SALES_LEDGER_IMMUTABLE'); END"
        )
        db.execute(
            f"CREATE TRIGGER IF NOT EXISTS {prefix}_no_delete BEFORE DELETE ON {table} "
            "BEGIN SELECT RAISE(ABORT, 'SALES_LEDGER_IMMUTABLE'); END"
        )

    require(db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "integrity_check failed")
    require(not list(db.execute("PRAGMA foreign_key_check")), "foreign_key_check failed")
    required_tables = {
        "document_sequences", "customers", "sales_invoices", "sales_invoice_lines",
        "sales_payments", "sales_consumption_snapshots", "sales_returns", "sales_return_lines",
        "sales_holds", "sales_hold_lines", "sales_pos_day_closures",
    }
    existing_tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    require(required_tables <= existing_tables, "one or more Alpha161 tables are missing")

    # Exercise sequence CAS and immutable/closed-day guards.
    db.execute("INSERT INTO document_sequences(sequenceKey,nextValue,updatedAtEpochMillis) VALUES('sales_invoice',1,1)")
    changed = db.execute(
        "UPDATE document_sequences SET nextValue=2,updatedAtEpochMillis=2 WHERE sequenceKey='sales_invoice' AND nextValue=1"
    ).rowcount
    require(changed == 1, "sequence compare-and-advance failed")
    db.execute(
        "INSERT INTO customers(customerCode,name,phone,nationalId,creditLimitRial,notes,isActive,createdAtEpochMillis,updatedAtEpochMillis) "
        "VALUES('CUS-TEST','Test','','',0,'',1,1,1)"
    )
    invoice_insert = (
        "INSERT INTO sales_invoices(invoiceNo,commandId,businessEpochDay,customerId,dueEpochDay,grossRial,discountRial,serviceRial,taxRial,"
        "netRial,creditRial,theoreticalCostRial,journalEntryId,cogsJournalEntryId,status,notes,createdByActorId,createdAtEpochMillis,"
        "voidedAtEpochDay,voidCommandId,voidReason,voidJournalEntryId,voidCogsJournalEntryId) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    )
    base = ("SAL-TEST-1", "CMD-TEST-1", 21000, 1, None, 100, 0, 0, 0, 100, 0, 50, None, None, "POSTED", "", 1, 1, None, None, "", None, None)
    db.execute(invoice_insert, base)
    db.execute("UPDATE sales_invoices SET journalEntryId=10,cogsJournalEntryId=11 WHERE invoiceNo='SAL-TEST-1'")
    try:
        db.execute("UPDATE sales_invoices SET netRial=99 WHERE invoiceNo='SAL-TEST-1'")
        require(False, "invoice financial fact remained mutable")
    except sqlite3.DatabaseError as error:
        require("SALES_INVOICE_IMMUTABLE" in str(error), "unexpected invoice immutability error")

    db.execute(
        "INSERT INTO sales_pos_day_closures(businessEpochDay,grossSalesRial,netSalesRial,returnRial,cogsRial,cashRial,cardRial,transferRial,creditRial,"
        "invoiceCount,returnCount,status,revisionNo,closedByActorId,closedByName,note,reopenedByActorId,reopenedByName,reopenReason,reopenedAtEpochMillis,createdAtEpochMillis) "
        "VALUES(21001,0,0,0,0,0,0,0,0,0,0,'CLOSED',1,1,'owner','',NULL,NULL,'',NULL,2)"
    )
    closed = list(base)
    closed[0], closed[1], closed[2], closed[3] = "SAL-TEST-2", "CMD-TEST-2", 21001, None
    try:
        db.execute(invoice_insert, tuple(closed))
        require(False, "closed POS day accepted a new invoice")
    except sqlite3.DatabaseError as error:
        require("SALES_DAY_CLOSED" in str(error), "unexpected closed-day error")

    trigger_count = db.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0]
    require(trigger_count >= 15, "professional sales triggers are incomplete")
    print(
        "ALPHA161_SQL_VERIFICATION=PASS "
        f"v44_entities={len(database['entities'])} tables={len(existing_tables)} triggers={trigger_count}"
    )


if __name__ == "__main__":
    main()
