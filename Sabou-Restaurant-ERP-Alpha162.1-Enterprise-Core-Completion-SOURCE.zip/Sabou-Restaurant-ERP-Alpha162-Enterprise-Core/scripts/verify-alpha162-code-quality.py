#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main"
TEST_ROOTS = [ROOT / "app/src/test", ROOT / "app/src/androidTest"]
failures: list[str] = []

def source_files(root: Path):
    if not root.exists():
        return []
    return [p for p in root.rglob('*') if p.is_file() and p.suffix in {'.kt', '.java', '.xml', '.sql'}]

main_files = source_files(MAIN)
test_files = [p for root in TEST_ROOTS for p in source_files(root)]

def rel(p: Path) -> str:
    return str(p.relative_to(ROOT))

def fail(message: str) -> None:
    failures.append(message)

for marker in ("TODO", "FIXME", "NotImplemented", "Coming Soon", "ComingSoon", "UnsupportedOperationException"):
    hits = [rel(p) for p in main_files if marker in p.read_text(encoding='utf-8', errors='ignore')]
    if hits:
        fail(f"production marker {marker!r}: {hits[:8]}")

for p in main_files:
    body = p.read_text(encoding='utf-8', errors='ignore')
    if re.search(r"catch\s*\([^)]*\)\s*\{\s*\}", body, flags=re.S):
        fail(f"empty catch: {rel(p)}")
    if re.search(r"catch\s*\([^)]*Exception[^)]*\)\s*\{(?:(?!\}).)*Result\.success", body, flags=re.S):
        fail(f"exception converted to success: {rel(p)}")
    if "fallbackToDestructiveMigration" in body:
        fail(f"destructive migration fallback: {rel(p)}")
    if re.search(r"(?i)(amount|price|cost|rial|money|balance|salary|wage|tax|discount|total)[A-Za-z0-9_]*\s*:\s*(Float|Double)\b", body):
        fail(f"floating-point money contract: {rel(p)}")
    if re.search(r"(?m)^\s*(class|object)\s+(Fake|Mock|Demo)[A-Za-z0-9_]*(Repository|Service|Dao)\b", body):
        fail(f"fake/mock/demo production data boundary: {rel(p)}")
    if re.search(r"Log\.[a-zA-Z]+\([^\n]*(password|passwd|token|secret|pin)", body, flags=re.I):
        fail(f"possible sensitive log: {rel(p)}")

for p in test_files:
    body = p.read_text(encoding='utf-8', errors='ignore')
    if re.search(r"@(Ignore|Disabled)\b", body) or re.search(r"assume(?:True|False)\s*\(\s*false", body):
        fail(f"disabled/skipped test: {rel(p)}")

legacy_adapter = ROOT / "app/src/main/java/ir/sabou/inventory/data/treasury/LocalTreasuryServiceAdapter.kt"
if legacy_adapter.exists():
    fail("dead LocalTreasuryServiceAdapter returned to production")


# UnsupportedDomainOperation may remain as a typed error and renderer, but no active production caller may construct/throw it.
for p in main_files:
    body = p.read_text(encoding='utf-8', errors='ignore')
    if 'UnsupportedDomainOperation(' in body and not rel(p).endswith('domain/common/BusinessError.kt'):
        fail(f"active UnsupportedDomainOperation construction: {rel(p)}")

# A runCatching used for a business command must surface the failure instead of converting it to null/default.
for p in main_files:
    if '/data/Backup' in rel(p):
        continue  # backup/restore is explicitly out of scope for this completion mission.
    body = p.read_text(encoding='utf-8', errors='ignore')
    for match in re.finditer(r"runCatching\s*\{([^{}]|\{[^{}]*\}){0,800}\}\s*\.(getOrNull|getOrDefault)\s*\(", body, flags=re.S):
        snippet = match.group(0)
        if re.search(
            r"(?:repository|Repository|useCases|UseCases|service|Service)\s*\.|"
            r"container\.(?:run|save|post|reverse|execute|resolve|sync)\s*\(",
            snippet,
        ):
            fail(f"silent runCatching around business operation: {rel(p)}")

# The pre-authenticated process must not schedule protected Alerts/Sync work.
sabou_application = (ROOT / 'app/src/main/java/ir/sabou/inventory/SabouApplication.kt').read_text(encoding='utf-8')
if 'ProtectedWorkScheduler.disable(this)' not in sabou_application:
    fail('protected background work is not disabled at process bootstrap')
sabou_app = (ROOT / 'app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt').read_text(encoding='utf-8')
if 'owner.viewModelStore.clear()' not in sabou_app or 'if (authenticatedUser == null)' not in sabou_app:
    fail('protected Compose graph is not session-scoped')

# A current Room database may not silently claim schema proof without exported JSON.
schema_dir = ROOT / "app/schemas/ir.sabou.inventory.data.db.AppDatabase"
exported = {p.stem for p in schema_dir.glob('*.json')} if schema_dir.exists() else set()
missing_schema = sorted({"45", "46", "47"} - exported)

if failures:
    print("ALPHA162_CODE_QUALITY=FAIL")
    for item in failures:
        print(f" - {item}")
    sys.exit(1)

print(f"ALPHA162_CODE_QUALITY=PASS production_files={len(main_files)} test_files={len(test_files)}")
if missing_schema:
    print("ALPHA162_ROOM_SCHEMA_EVIDENCE=NOT_COMPLETE missing=" + ",".join(missing_schema))
else:
    print("ALPHA162_ROOM_SCHEMA_EVIDENCE=PASS versions=45,46,47")
