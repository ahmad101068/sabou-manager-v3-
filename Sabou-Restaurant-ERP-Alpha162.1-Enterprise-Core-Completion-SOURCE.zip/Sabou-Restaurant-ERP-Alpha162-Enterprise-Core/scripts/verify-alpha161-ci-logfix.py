from pathlib import Path

root = Path(__file__).resolve().parents[1]
movement = (root / 'app/src/main/java/ir/sabou/inventory/ui/InventoryMovementCenterScreen.kt').read_text(encoding='utf-8')
nav = (root / 'app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt').read_text(encoding='utf-8')
sales = (root / 'app/src/main/java/ir/sabou/inventory/ui/ProfessionalSalesScreens.kt').read_text(encoding='utf-8')

required_movement = [
    'InventoryMovementType.SALES_INVOICE_CONSUMPTION',
    'InventoryMovementType.SALES_RETURN',
    'InventoryMovementType.SALES_VOID',
]
required_reference = [
    'InventoryReferenceType.SALES_INVOICE',
    'InventoryReferenceType.SALES_RETURN',
    'InventoryReferenceType.SALES_VOID',
]

for token in required_movement:
    if token not in movement:
        raise SystemExit(f'MISSING_MOVEMENT_TITLE_BRANCH={token}')
    if token not in nav:
        raise SystemExit(f'MISSING_SEARCH_TITLE_BRANCH={token}')
for token in required_reference:
    if token not in movement:
        raise SystemExit(f'MISSING_REFERENCE_TITLE_BRANCH={token}')

bad_import = 'import androidx.compose.foundation.layout.weight'
if bad_import in sales:
    raise SystemExit('FORBIDDEN_COMPOSE_WEIGHT_IMPORT_PRESENT')

print('ALPHA161_CI_LOGFIX_REGRESSION=PASS')
