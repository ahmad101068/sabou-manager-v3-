# تغییرات نسخه 3.0.0-alpha109-room-ksp-fix

## اصلاح خطای GitHub Actions

- تحلیل لاگ اجرای GitHub و شناسایی شکست در وظیفه `:app:kspDebugKotlin`.
- تکمیل تعریف قطع‌شده‌ی `SalePaymentEntity` با فیلد `createdAtEpochMillis`.
- بستن صحیح سازنده‌ی Entity تا Room بتواند وابستگی‌های `AppDatabase` را پردازش کند.
- افزودن کنترل ایستا برای جلوگیری از انتشار دوباره‌ی Entity ناقص.
- به‌روزرسانی نسخه برنامه و نام Artifact دیباگ.

## نسخه

- `versionCode`: 142
- `versionName`: `3.0.0-alpha109-room-ksp-fix`
