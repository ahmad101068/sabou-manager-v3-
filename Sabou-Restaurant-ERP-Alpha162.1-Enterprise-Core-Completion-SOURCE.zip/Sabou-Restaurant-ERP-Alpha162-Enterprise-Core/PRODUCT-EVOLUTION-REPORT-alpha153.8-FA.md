# گزارش Product Evolution — alpha153.8

## Before / After / User Impact

| ماژول | قبل | بعد | اثر کاربری |
|---|---|---|---|
| Finance / Accounting | دفتر حساب فقط فهرست گردش و مانده جاری بود | صورت‌حساب با افتتاحیه/اختتامیه، بازه تاریخ، جست‌وجو، بدهکار/بستانکار و جمع دوره | کنترل حساب و تهیه Statement بدون مرور دستی همه اسناد |
| Inventory | Stock Movement ثبت می‌شد اما از UI قابل مشاهده نبود | Detail هر کالا با موجودی، ارزش، حداقل و History ورودی/خروجی/اصلاح/ضایعات و مرجع | ریشه تغییر موجودی و عملیات مرتبط قابل ردیابی است |
| Personnel | پروفایل مالی حقوق و مساعده داشت | Timeline حضور، کارکرد، تأخیر و اضافه‌کاری نیز یکپارچه شد | مدیر نمای کامل فرد را بدون جابه‌جایی بین بخش‌ها می‌بیند |
| Global Search | Entity پیدا می‌شد اما فقط ماژول باز می‌شد | کالا، فاکتور، حساب، سند و کارمند مستقیماً در Detail مقصد باز می‌شوند | مسیر Search → Entity → Source واقعی شد |
| Data correctness | فرمت مقدار منفی برای خروج و ضایعات نادرست بود | formatter مرکزی signed و مقاوم به `Long.MIN_VALUE` شد | گردش خروجی و ضایعات به‌درستی نمایش داده می‌شود |

## Vertical Slice

- Inventory History: Room DAO → Repository → Domain Model → ViewModel State → Item Detail UI → Search Drill-down → Integration Test.
- Account Statement: Ledger Repository موجود → فیلتر/خلاصه Presentation → UI حرفه‌ای با Opening/Closing.
- Employee Drill-down: Search target → Navigation state → Employee profile → Financial/Attendance timeline.
- Schema همچنان 39 است و Migration یا Data Copy اضافه نشده است.

## Verification

- Foundation/static verification: اجرا و موفق.
- Unit/Instrumentation tests: ایجاد شدند؛ اجرای Gradle محلی به‌دلیل عدم دسترسی به Gradle 8.13 مسدود است.
