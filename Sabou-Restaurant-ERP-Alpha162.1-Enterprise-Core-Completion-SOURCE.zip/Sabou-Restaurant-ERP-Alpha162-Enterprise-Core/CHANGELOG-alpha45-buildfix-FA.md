# تغییرات alpha45-buildfix

- رفع خطای کامپایل در `PersonnelScreens.kt`.
- حذف استفاده ناسازگار از `PaddingValues.copy`.
- تعریف مستقیم فاصله‌های `start`, `top`, `end`, `bottom`.
- افزایش نسخه به `3.0.0-alpha45-buildfix` با `versionCode = 74`.
