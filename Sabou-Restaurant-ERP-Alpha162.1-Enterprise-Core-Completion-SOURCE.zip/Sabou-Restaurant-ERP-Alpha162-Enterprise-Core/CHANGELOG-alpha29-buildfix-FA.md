# تغییرات alpha29-buildfix

- اصلاح import اشتباه `AssetUiState` در صفحه دارایی‌ها؛ این کلاس در پکیج UI تعریف شده است، نه در دامنه دارایی‌ها.
- جایگزینی فراخوانی ناسازگار `ExtendedFloatingActionButton` با `Button` سازگار با نسخه Material 3 پروژه.
- رفع خطاهای زنجیره‌ای Composable در `AssetScreens.kt`.
- افزایش نسخه به `3.0.0-alpha29-buildfix` با `versionCode = 57`.
