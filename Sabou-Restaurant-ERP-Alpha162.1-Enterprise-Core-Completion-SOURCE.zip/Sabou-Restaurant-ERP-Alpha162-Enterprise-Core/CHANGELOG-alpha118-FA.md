# تغییرات نسخه 3.0.0-alpha118-calendar-compile-fix

- رفع خطای `compileDebugKotlin` در `CrmScreens.kt` و `PurchaseManagementDialogs.kt`.
- بازگرداندن سازگاری `PersianDateField` با فراخوانی‌های trailing lambda.
- حفظ تمام امکانات alpha117 شامل تقویم سراسری، چاپ/PDF و Google Drive.
- `versionName`: `3.0.0-alpha118-calendar-compile-fix`
- `versionCode`: `151`
