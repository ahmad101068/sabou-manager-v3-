# راهنمای تحویل alpha153 به GitHub

این پوشه یک پروژه کامل Android Studio است. محتویات پوشه را در Branch جداگانه‌ای مانند زیر قرار دهید:

`feature/alpha153-versioned-recipes`

## کنترل‌های مورد انتظار در GitHub Actions

```bash
./gradlew --no-daemon clean testDebugUnitTest lintDebug
./gradlew --no-daemon connectedDebugAndroidTest
./gradlew --no-daemon assembleRelease
```

برای `assembleRelease` متغیرهای Keystore تعریف‌شده در `app/build.gradle.kts` باید در Secrets محیط CI قرار گیرند.

## معیار Merge

- تولید موفق Schema نسخه ۳۹ در `app/schemas`
- پاس‌شدن `FullMigration1To39Test`
- پاس‌شدن `RecipeVersionMigration38To39Test`
- پاس‌شدن تست فروش و برگشت فروش
- نصب نسخه Release روی alpha152 بدون حذف داده
- تهیه Backup پیش از Update و Restore آزمایشی پس از Update

نسخه Debug برای استفاده عملیاتی منتشر نشود.
