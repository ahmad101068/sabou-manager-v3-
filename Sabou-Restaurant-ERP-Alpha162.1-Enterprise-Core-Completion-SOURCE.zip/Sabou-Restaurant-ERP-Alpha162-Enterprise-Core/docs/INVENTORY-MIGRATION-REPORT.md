# Inventory 2.0 — Migration Report

Migration edge: Room `42 → 43`  
Registry: `ALL_MIGRATIONS` contains one ordered edge for every version `1 → 43`  
Mode: data-preserving, non-destructive

## Old schema

Schema 42 had an item-global quantity/value projection, nullable movement locations, legacy location
kinds, partial lot caches, immediate inventory counts, free-text posted waste records and immediate
single-step transfers. It did not have item/location balance projections, controlled count sessions or
document transfer lifecycle fields.

## New schema

Schema 43 adds or hardens:

- Item Master fields: SKU, typed item type, primary barcode, brand, storage condition, shelf life,
  lot/expiry policy, min/max/safety/reorder thresholds and lead time;
- stable location code/type/update timestamp;
- richer lot identity/status/source/correlation/actor fields and lot-allocation cost snapshots;
- optional lot/production/expiry/barcode facts on goods-receipt lines;
- `inventory_balances` keyed by item/location;
- `inventory_count_sessions` and `inventory_count_lines` with unique document/idempotency/post keys;
- typed, cost-aware, actor-aware waste documents;
- document-based transfers and lines with requested/issued/received/variance quantities;
- compound indexes for item/location/date, lot/expiry, status, actor, source and correlation queries;
- SQLite validation, transition and immutability guards.

## Data transformation

| Legacy data | Transformation | Preservation rule |
|---|---|---|
| Item without SKU | `SKU-` plus zero-padded stable database id | Unique index; SKU is not equal to the raw id |
| Category/item type | Conservative typed backfill for known packaging/consumable names; otherwise ingredient | No item removed or deactivated |
| Alert threshold | Copied to minimum stock and reorder point | Existing alert behavior remains meaningful |
| Primary location | Stable code `MAIN`, type `WAREHOUSE` | Existing id/name retained |
| Other location | Stable `LOC-xxxxxx` code; known `COLD` normalized | Unknown type text remains visible to strict mapper |
| Legacy lot | Global id, initial quantity, status, correlation and creation timestamp backfilled | Remaining quantity and lot number preserved |
| Legacy waste | Converted to immutable `POSTED` document with readable legacy document number | Original reason/notes/value/actor/time retained; reason code is explicitly `LEGACY_UNKNOWN` |
| Legacy transfer | Converted to balanced `COMPLETED` document | Source/destination, number, lines, actor snapshot and time retained |
| Existing count history | Retained in legacy immutable count table | New workflow uses separate session/line tables |

## Opening-balance reconciliation

Migration does not invent a fake full transaction history. For each item it compares the legacy item
projection with the sum of existing movement facts. Only the quantity/value difference is appended as
one `OPENING_BALANCE` movement at `MAIN`, with source `MIGRATION` and stable key
`migration:42:43:opening:<itemId>`. When ledger and projection already agree, no movement is created.
The unique idempotency key and `INSERT OR IGNORE` make the reconciliation replay-safe.

After reconciliation, `inventory_balances` is built by grouping the ledger by item/location. A zero
`MAIN` row is created for active legacy items that otherwise have no location row. Non-lot-tracked
inventory keeps a null lot; the migration does not generate fake lots.

## Defaults and constraints

- Item type: `INGREDIENT` unless a conservative recognized category mapping applies.
- Storage condition: `AMBIENT`.
- `trackLot`/`trackExpiry`: enabled only when existing lot evidence fully reconciles with item stock;
  partial legacy lot data is preserved without falsely claiming complete tracking.
- Quantity/value thresholds and lead time: zero unless derived from the legacy alert threshold.
- Foreign keys use `RESTRICT` for operational history.
- Destructive migration and `fallbackToDestructiveMigration` are absent.

## Rollback risk

Room migrations are forward-only; application downgrade after opening schema 43 is unsafe unless a
verified database backup is restored. The highest-risk operations are the waste/transfer table rebuilds
and opening-balance reconciliation. They are isolated in the 42→43 edge, copy explicit columns, recreate
indexes/guards, and are covered by data-preservation assertions. Production rollout must still be
preceded by an encrypted backup and migration of a real database copy.

## Verification assets

- `InventoryMasterMigration42To43Test`: items, stock/value, SKU uniqueness, locations, lots, opening
  reconciliation, balance projection, count tables/guards, waste preservation/immutability, transfer
  preservation/immutability and foreign keys.
- `FullMigration1ToCurrentTest`: dynamic full chain to `APP_DATABASE_SCHEMA_VERSION`.
- `MigrationRegistryTest` and `MigrationChainContractTest`: unique contiguous registry edges.
- SQL/SQLite simulations executed during development verified representative migration statements,
  transfer guards and foreign-key integrity.

## Execution status

Migration code and tests are authored. Static registry and SQL simulations passed in this workspace.
Android migration tests and Room/KSP schema validation are **NOT EXECUTED** because Gradle 8.13 is not
available locally and the wrapper cannot reach its distribution. The generated Room schema export for
version 43 must be produced and reviewed by CI before merge. This is a release blocker, not a reason to
weaken or bypass migration validation.

