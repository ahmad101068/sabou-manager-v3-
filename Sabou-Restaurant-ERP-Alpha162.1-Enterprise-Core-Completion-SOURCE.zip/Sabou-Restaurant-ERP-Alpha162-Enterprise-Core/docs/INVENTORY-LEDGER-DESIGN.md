# Inventory 2.0 — Immutable Ledger Design

Version: Alpha159 Inventory 2.0  
Schema: 43

## Authority model

`stock_movements` is the immutable historical source of truth. A posted movement cannot be edited or
deleted; correction is represented by a linked reversal and, when required, a new correcting movement.
The source document, actor, business date, creation timestamp, location, unit-cost snapshot,
idempotency key and correlation identifier remain attached to the historical fact.

`inventory_balances` is the rebuildable item/location projection used by operational availability
guards. `inventory_items.stockMicros` and `inventoryValueRial` remain aggregate compatibility
projections while legacy callers are migrated. Lot quantity is a guarded cache tied to movement
allocation facts. These projections are not independent business authorities.

## Balance dimensions

| Dimension | Meaning | Persistence in schema 43 |
|---|---|---|
| `onHand` | Physically recorded quantity at an item/location | Stored projection |
| `reserved` | Quantity committed but still physically present | Stored projection |
| `inTransit` | Quantity issued from a transfer and not yet received | Stored projection |
| `damaged` | Quantity present but unavailable because of damage | Stored projection |
| `quarantined` | Quantity blocked by lot control | Stored projection |
| `available` | `onHand - reserved - damaged - quarantined` | Derived, never a second authority |
| `onOrder` | Open procurement quantity | Read from Procurement data |

All arithmetic uses fixed-point `Long` primitives (`QuantityMicros`, `MoneyRial`) and checked math.
Financial quantity/value logic does not use `Float` or `Double`.

## Command boundary

`InventoryCommandService` owns receipt, issue, adjustment, transfer legs and reversal. The local
implementation is `LocalInventoryCommandEngine`; no parallel stock engine was introduced.

For a stock-affecting command the boundary performs, in one Room transaction:

1. permission, actor, business-date and document-state validation;
2. exact-payload idempotency validation;
3. item/location/lot and expiry policy validation;
4. negative-stock and overflow checks;
5. immutable movement append;
6. compare-and-set update of location, lot and aggregate compatibility projections;
7. accounting posting where the source workflow requires it;
8. audit/outbox append and source-document transition.

A thrown business, accounting, audit, DAO or constraint failure aborts the surrounding transaction.

## Movement vocabulary

`InventoryMovementType`, `InventoryReferenceType` and `InventoryReasonCode` are typed in the domain.
The database remains text-backed for compatibility. Unknown persistence values are exposed as a
legacy/unknown read state or rejected before a state-changing command; they never silently become a
financially meaningful movement type.

The vocabulary covers purchase receipt/return, sales and recipe consumption, production output,
waste, transfer out/in, count variance, adjustment, opening balance and reversal. Historical aliases
from earlier schemas remain readable through explicit mapping.

## Negative-stock invariant

Normal issue commands require sufficient `available` quantity at the requested location. For
lot-tracked items the selected/allocated lots must also cover the requested quantity. The command
returns a typed insufficient-stock/lot shortage failure before a movement is committed. There is no
silent global-stock fallback that allows one location to mask a deficit in another.

Database guards reject negative projection components and invalid balance combinations. Compare-and-
set writes detect stale snapshots and surface a concurrency conflict instead of overwriting another
command.

## Lot and FEFO behavior

`InventoryLotService` owns lot creation, status changes and searchable lot reads. Lot statuses are
`ACTIVE`, `QUARANTINED`, `EXPIRED`, `DEPLETED` and `BLOCKED`; an unknown legacy state is fail-safe and
non-allocatable.

`LotAllocationService` is deterministic. For normal consumption it filters by item and location,
requires positive available quantity, excludes expired/quarantined/blocked lots, and orders eligible
lots by earliest expiry with stable tie breakers. The result contains allocations and an explicit
shortage. FEFO is a picking policy, not a costing method.

Expiry detection never deletes stock. An expired lot is blocked from normal allocation; disposal is a
separate waste/adjustment command and remains auditable.

## Valuation

The existing weighted-average valuation policy is preserved. Every material movement stores its
historical `unitCostRial` and `valueDeltaRial`; changing supplier pricing does not revalue history.
`InventoryValuationService` centralizes checked cost calculations. Internal location transfer carries
the source value and creates no P&L journal because locations are not accounting entities.

## Transfer accounting and in-transit

Transfer issue appends `TRANSFER_OUT`, reduces source on-hand and increases the explicit in-transit
projection. Receipt appends `TRANSFER_IN`, increases destination on-hand and releases in-transit.
Issue and receive command identifiers are independently unique. A quantity difference is retained as
an explicit variance and cannot be hidden by mutating either leg.

## Reversal and idempotency

Movement history has a unique `reversalOfMovementId`. Replaying a command with the same key and exact
payload returns the original outcome; reuse with different payload is a typed duplicate/conflict.
Count posting, waste posting, transfer issue/receive, receipt application and sales posting have
stable command/source identities. Historical movement mutation is also blocked by SQLite triggers.

## Projection integrity

`InventoryIntegrityService` returns structured issues for:

- negative or invalid balance;
- ledger/location-projection mismatch;
- aggregate/item-projection mismatch;
- lot balance mismatch or invalid/orphan lot;
- active expired lot;
- orphan movement/location reference;
- transfer quantity/value imbalance.

The checker reports evidence; it does not silently repair data. Rebuild/repair remains an explicit,
authorized maintenance operation.

## Read and performance boundary

`InventoryReadService` exposes decision-oriented read models. Item, balance, lot, movement, count,
waste, transfer and replenishment queries validate page sizes and execute search/filter/order/limit in
SQL. Workspace screens do not load all movements and filter in Compose. Stable database identifiers
are used as list keys.

## Cross-domain ownership

- Procurement calls Inventory for receipt/return effects and supplies lot/expiry/location facts.
- Sales/Recipe calls Inventory consumption/reversal commands; it does not write stock projections.
- Waste posts accounting through the existing `AccountingPostingService`.
- Replenishment may create a Procurement requisition input; it never creates a purchase order.
- Authorization and Audit use the existing Foundation services; no Inventory-specific security or
  audit engine exists.

