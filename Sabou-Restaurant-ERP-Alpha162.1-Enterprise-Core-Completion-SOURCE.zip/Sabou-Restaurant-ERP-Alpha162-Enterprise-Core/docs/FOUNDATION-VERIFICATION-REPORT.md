# Sabou ERP 2.0 — Foundation Verification Report

Foundation baseline: `3.0.0-alpha158.0-foundation-hardening`

Current candidate: `3.0.0-alpha160.0-hr-payroll-2`

Room schema: 44

Date: 2026-08-09

## Verification levels

| Check | Status | Evidence / command |
|---|---|---|
| Baseline Git and DAO split | PASS | Alpha157 commit history inspected; `Daos.kt` absent; dynamic DAO/accessor parity |
| Migration source parity | PASS | 41 old/new migration bodies compared before extraction: `MISMATCH=0` |
| Migration registry chain | PASS | complete unique edges 1→44 derived from the schema constant |
| Destructive migration guard | PASS | no `fallbackToDestructiveMigration` or ledger delete SQL |
| Architecture policy script | PASS | `bash scripts/verify-foundation.sh` |
| Kotlin/Gradle compile | PASS | `./gradlew :app:compileDebugKotlin` |
| Unit tests | PASS | 234 tests, zero failures/skips |
| KSP / Room schema processing | PASS | schema 44 exported and Android test assets copied |
| HR/Payroll migration execution | PASS | host SQLite: 186 production SQL statements, 49 checks, deterministic |
| Android test APK compile | PASS | `:app:assembleDebugAndroidTest` |
| Android migration/integration runtime | NOT EXECUTED | emulator/device unavailable; APK compiled |
| Lint | NOT EXECUTED | requires Android Gradle toolchain |
| `assembleDebug` | PASS | debug APK produced |
| Release build | NOT EXECUTED | not part of TASK 03 build gate |

Static verification, unit execution, Room compilation and debug assembly are reported separately.

## Architecture checks enforced

- no `Double`/`Float` in core/domain fixed-point models;
- no direct DAO call, journal DAO mutation, or posting call from UI;
- no destructive Room migration fallback;
- no `GlobalScope`;
- inventory projection CAS only in `LocalInventoryCommandEngine` and its DAO declaration;
- posted journals, stock movements and audit history have no direct deletion path;
- direct draft-to-post transition is owned only by the accounting engine;
- direct `AuditLogEntity` construction is restricted to entity declaration and audit writer;
- no domain-to-presentation dependency;
- migration edge count, uniqueness and adjacency match `APP_DATABASE_SCHEMA_VERSION`;
- Room schema, version name/code, SQLCipher factory, manifest backup and cleartext policy are present;
- DAO declaration/accessor parity is discovered dynamically rather than hard-coded to Alpha157 counts.
- Inventory Workspace does not reintroduce direct DAO access or a presentation God file;
- Inventory balance/movement read queries remain explicitly bounded;
- Inventory location/lot/transfer UI ownership does not leak back to Management Control.

## Tests added or strengthened

| Test | Layer | Business assertion |
|---|---|---|
| `AccountingPostingBoundaryTest` | Unit | source normalization, balanced fixed-point command and reversal reason |
| `AuthorizationBoundaryTest` | Unit | permission enforcement and actor identity |
| `DomainFailureMappingTest` | Unit | structured failures map to actionable Persian presentation text |
| `TypedStateMappingTest` | Unit | known mapping and explicit unknown handling for channels, movement and document states |
| `MigrationRegistryTest` | Unit | exactly one ordered migration edge for every version 1→current |
| `GoodsReceiptIdempotencyTest` | Unit | exact replay, payload conflict and finalization equivalence |
| `AccountingPostingIntegrationTest` updates | Room integration | posting/reversal audit, replay and audit-failure rollback |
| `GoodsReceiptTransactionIntegrationTest` | Room integration | facade compatibility, no duplicate effects, period-failure full rollback |

Existing full-chain migration tests and critical inventory/management transaction tests were retained;
none were deleted or weakened.

## Commands required in CI before merge

```bash
bash scripts/verify-foundation.sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
./gradlew --no-daemon assembleRelease
```

The repository workflow runs instrumentation on API 23 and API 35, then uploads the debug APK and
Room schemas. A merge or Inventory 2.0 branch must not treat this document as a substitute for those
results.

## Release gate

Current local foundation gate: **PASS for TASK 03 debug scope**. Device instrumentation, lint and release assembly remain CI gates.

Required evidence to clear the gate:

1. unit and lint tasks pass;
2. KSP/Room schema validation passes;
3. full migration chain and latest 43→44 data-preservation tests pass on emulator;
4. Inventory ledger/count/waste/transfer/receipt replay and rollback integration tests pass;
5. debug and release assembly complete without source or resource errors.
