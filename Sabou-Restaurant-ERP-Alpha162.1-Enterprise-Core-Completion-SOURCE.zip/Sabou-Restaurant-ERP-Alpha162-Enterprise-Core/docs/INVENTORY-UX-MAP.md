# Inventory 2.0 — Persian-first UX Map

## Workspace objective

Inventory is a decision and execution workspace, not a decorative dashboard. Its first question is
«الان چه چیزی نیاز به اقدام دارد؟» and every attention metric leads to an owned workflow.

## Navigation map

| Workspace | Decision / task | Primary drill-down |
|---|---|---|
| Overview | Value, low/out stock, expiry, waste, variance, pending transfers/counts | KPI → filtered owner workspace |
| Item & Location | Find item by name/SKU/barcode; inspect location availability | Item → overview, locations, lots, movements, replenishment, controls |
| Expiry & Lot | Expiring, expired and quarantined lots | Lot → source receipt and explicit quarantine/waste action |
| Movement Ledger | Explain every quantity/value change | Movement → source document, actor, lot, correlation and reversal |
| Count Center | Draft, active, recount, approval and posted sessions | Session → protected lines and lifecycle actions |
| Waste Center | Cost by date/reason/item/location and approval state | Document → lot/cost/source/accounting trace |
| Transfer Center | Requested, approved, in-transit, completed and variance | Document → issue/receipt actors and line quantities |
| Replenishment | Items needing procurement action | Recommendation → Procurement requisition boundary |
| Period | Inventory period close/reopen controls | Period evidence and authorized action |

## Item detail information architecture

Item detail is sectioned rather than a giant form:

- Overview: SKU, barcode, type, units, storage and stock policy;
- Stock by Location: on-hand, available, reserved, damaged, quarantined and in-transit;
- Lots: lot number, expiry, status, remaining quantity and source receipt;
- Movements: bounded chronological ledger with source/actor/correlation;
- Suppliers/Replenishment: preferred supplier, lead time, cover and recommendation;
- Waste/Counts: operational history and shortcuts to owned centers.

Master editing uses progressive disclosure for conversion, expiry and replenishment fields. Advanced
fields do not block the common create/edit path.

## Operational safeguards

- Blind count hides system quantity from the counter and reveals variance only to authorized reviewers.
- Expired/quarantined/blocked lots are visibly unavailable; the UI never silently substitutes another
  state or removes stock.
- Count, waste and transfer actions show explicit status and actionable domain failures.
- Repeated taps are safe at the command boundary; UI loading state is convenience, not idempotency.
- Permission-based hiding is convenience only; services enforce every sensitive action again.

## Persian and device behavior

- RTL layout and Persian accounting/inventory terminology are retained.
- Money and quantities are formatted from fixed-point values; no floating-point domain conversion.
- Business date is shown separately from creation/audit time.
- Lists use stable ids, large touch targets and bounded database search.
- Layout is decomposed into focused screens suitable for tablet/landscape workflows.
- Barcode lookup has a dedicated read boundary so scanner integration can be added without rewriting
  Item Master or inventory commands.

## Ownership cleanup

Location, Lot, FEFO and Transfer entry points are owned by Inventory routes. The historical Management
Control entry is a temporary redirect to Inventory and does not host duplicate inventory screens.
Management Control remains an exception/decision center for its own cross-domain controls.

## Deliberately deferred UX

- Physical scanner SDK integration and multi-barcode packaging editor;
- production-grade tablet/device usability study;
- Compose instrumentation coverage and accessibility automation;
- multi-branch location switcher and conflict-resolution UX;
- advanced forecasting/turnover KPI until complete COGS data exists.

Deferred items are not presented as completed functionality or fake KPIs.

