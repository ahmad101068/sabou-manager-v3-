# Sabou ERP 2.0 — Transaction Integrity Matrix

> This document preserves the TASK 01-B Foundation assessment. Inventory rows describe the Alpha158
> baseline and are superseded by the implemented Alpha159 matrix in
> `docs/INVENTORY-TRANSACTION-MATRIX.md`; non-Inventory findings remain current.

Assessment basis: Alpha157 source plus TASK 01-B changes. “Atomic” means every listed local Room
mutation joins one outer `database.withTransaction`; a nested inventory/accounting transaction joins
the same database transaction. It does not claim remote sync atomicity—the outbox row is local and is
committed with the business operation.

| Workflow | Entry point | Tables touched | Inventory | Accounting | Treasury | Audit | Current boundary | Atomic | Idempotent | Failure behavior | Required fix / status |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Purchase posting | `LocalPurchaseRepository.post` | `purchases`, `purchase_lines`, `inventory_items`, `stock_movements`, `journal_entries`, `journal_lines`, `audit_logs`, `sync_changes` | Receipt per line through inventory engine | Inventory Dr; payable/cash/bank Cr | Channel expressed through semantic account; no treasury ledger | Journal + document | outer purchase Room transaction | Yes | Duplicate-safe by invoice number; not replay-returning | Any line, period, journal, audit or outbox failure rolls back document and stock | P1: add stable document command ID before sync enablement |
| Goods receipt | facade → `ProcurementReceivingService.receive` | `goods_receipts`, lines, PO lines/status, inventory projection/movements, journal/lines, audit/outbox | Accepted quantity/value receipt | Inventory Dr; GRNI Cr | None | explicit `RECEIVE` + journal | outer receiving Room transaction | Yes | Yes: PO + delivery note natural key with exact payload comparison | exact replay returns original ID; conflicting payload raises typed conflict; later failure rolls back all effects | DONE; integration test added |
| Purchase return | facade → `ProcurementReceivingService.returnToSupplier` | return header/lines, PO lines, inventory/movements, purchase settlement state, supplier credits, journal/lines, audit/outbox | guarded issue; FEFO allocated lots | GRNI or supplier payable/credit/price variance | supplier credit concept only | journal + sync audit | outer receiving Room transaction | Yes | No stable return command ID | stock/value/account/audit failure rolls back return and supplier credit | P1: add return command/global ID and replay equivalence |
| Three-way invoice matching | facade → `ProcurementInvoiceMatchingService.post` | purchase/lines, invoice link, PO status, budget commitment, journal/lines, audit/outbox | no new movement; validates accepted quantity | GRNI and price variance to payable/channel | payment channel adapter only | journal + sync audit | outer matching Room transaction | Yes | DB uniqueness prevents second invoice; no replay result | variance approval, journal or final status failure rolls back invoice | P1: stable match command ID; current corruption risk is controlled |
| Supplier settlement | `LocalPurchaseRepository.settle` | purchase settlement projection, journal/lines, audit/outbox | None | Payable Dr; cash/bank Cr | Future treasury payment; currently semantic account | explicit document + journal | outer purchase Room transaction | Yes | Yes by command ID / journal key and exact journal payload | replay returns original journal; CAS conflict or audit failure rolls back | DONE foundation; migrate effect through treasury adapter later |
| Daily sales posting | `LocalDailySalesRepository.post` | sales summary/lines, recipe snapshots/read models, inventory projection/movements/lot consumption, journal/lines, audit/outbox | recipe consumption with stock/value guards | cash/bank/receivable and revenue/COGS postings | existing channel totals only | explicit sales + journal | outer sales Room transaction | Yes | Yes by business day plus payload equivalence | insufficient stock, closed day/period, journal or audit failure rolls back complete sale | DONE |
| Sales reversal | `LocalDailySalesRepository.reverse` | sales status, reversal stock movements/projection, journal reversal, audit/outbox | reverses original consumption | append-only correcting entries | channel totals reversed in accounting | explicit reversal + journal | outer sales Room transaction | Yes | status/original-effect replay guard | duplicate reversal is no-op/validated; any new failure rolls back | DONE |
| Inventory adjustment | no arbitrary public mutation; count command calls `adjustToCount` | same as inventory count | projection CAS + movement | variance journal from count workflow | None | count audit | inventory command nested in count transaction | Yes | only through count command | direct arbitrary adjustment path is intentionally absent | Keep absent until a separately authorized adjustment document is designed |
| Inventory count | `LocalOperationsRepository.postInventoryCount` | count document, inventory projection, stock movement, journal/lines, audit/outbox | absolute counted quantity/value; no negative result | variance posting | None | explicit count + journal | outer operations Room transaction | Yes | Yes by command ID and payload | replay returns original; period/concurrency/journal/audit failure rolls back | DONE |
| Waste posting | `LocalOperationsRepository.postWaste` | waste document, inventory projection, lots/consumption, movement, journal/lines, audit/outbox | guarded issue and FEFO consumption | waste expense Dr; inventory Cr | None | explicit waste + journal | outer operations Room transaction | Yes | Yes by command ID and payload | insufficient stock/value, period or accounting failure rolls back every projection | DONE; rollback integration coverage exists |
| Payroll posting / approval | `LocalPersonnelRepository.postPayroll`, `approvePayroll` | payroll run, advance allocations, journal draft/lines/status, audit/outbox | None | balanced payroll liability/withholding; post on approval | payment channel typed; treasury adapter pending | explicit approval + journal | each command owns Room transaction | Yes | post by global command ID/fingerprint; approval status replay guard | SoD/permission/period/post failure rolls back status, allocations and journal | DONE foundation |
| Asset depreciation | `LocalAssetRepository.postDepreciation` | depreciation row, asset accumulated projection, journal/lines, audit/outbox | None | depreciation expense Dr; accumulated depreciation Cr | None | journal + outbox audit | outer asset Room transaction | Yes | unique asset-period plus journal key | period/account/outbox failure rolls back row and accumulated projection | DONE; normalize command ID in later asset task |
| Accounting period close | `LocalManagementControlRepository.closeAccountingPeriod` | period lock, audit, outbox; DB triggers govern journals | blocks financial posting, indirectly protects cross-domain commands | closes date range | None | explicit `CLOSE` | outer management-control Room transaction | Yes | unique range; duplicate is rejected, not replayed | re-auth/permission/overlap/audit/outbox failure leaves no lock | DONE integrity; move owner UI to accounting later |
| Accounting period reopen | `LocalManagementControlRepository.reopenAccountingPeriod` | period status, audit, outbox | future commands become possible after authorized reopen | controlled status transition | None | explicit `REOPEN` | outer Room transaction | Yes | status guard; no command ID | permission/re-auth/concurrency/audit/outbox failure preserves CLOSED | DONE integrity; add command ID before remote retry |

## Critical findings and actions

### Fixed P0/P1-integrity defect

Goods receipt replay previously evaluated the now-mutated purchase-order status before duplicate
identity. Retrying a successfully committed full receipt therefore failed instead of returning the
original result. The new natural-key lookup executes before status validation and compares header,
line quantities, rejection semantics and finalization effects. A same-key/different-payload command
raises `IdempotencyConflict`; an exact replay emits no extra stock movement, journal, audit or outbox.

The receiving integration test also closes the accounting period after fixture creation and verifies
that a journal failure rolls back receipt header/lines, PO received projection, inventory projection,
movement and audit.

### No P0 partial-posting path found

Every audited workflow that touches both an operational document and journal/stock effects owns an
outer Room transaction. Inventory and accounting engines use nested Room transactions on the same
database and therefore join it. Audit and local sync outbox failures propagate rather than being
swallowed.

### Remaining idempotency debt

- Purchase return has neither a stable command ID nor a natural document number supplied by the
  caller. A retry can create a second legitimate-looking return while quantities remain available.
- Initial purchase posting and matched invoice use unique business numbers/links to reject a
  duplicate, but do not return the original result after an exact retry.
- Period close/reopen and asset depreciation are duplicate-safe through unique/state constraints,
  but do not share the uniform command-result replay model.

These are P1 hardening items, not evidence of a currently non-atomic commit. They must be completed
before enabling unattended remote retry for those commands.
