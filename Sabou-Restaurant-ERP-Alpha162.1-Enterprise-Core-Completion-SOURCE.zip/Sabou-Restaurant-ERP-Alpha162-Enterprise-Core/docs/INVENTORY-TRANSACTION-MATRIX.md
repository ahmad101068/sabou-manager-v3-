# Inventory 2.0 — Transaction Integrity Matrix

Candidate: Alpha159 / schema 43

Status: implemented source; Gradle/Android execution gate remains blocked in this workspace

| Workflow | Entry point | Tables touched | Inventory impact | Accounting impact | Authorization | Audit | Transaction / idempotency | Failure behavior |
|---|---|---|---|---|---|---|---|---|
| Purchase receipt application | `ProcurementReceivingService.receive` → `InventoryCommandService.receive` | receipt/lines, lot, balance/item projection, movement, journal, audit/outbox | receipt by location/optional lot | inventory/GRNI through existing posting boundary | purchase receiving + Inventory command validation | shared correlation | one Room transaction; natural receipt identity + movement key | any lot/period/journal/audit conflict rolls back receipt and stock |
| Purchase return | `ProcurementReceivingService.returnToSupplier` → Inventory issue/reversal | return/lines, lot allocation, balance/item projection, movement, supplier credit, journal, audit/outbox | lot/location issue | liability/inventory correction | purchase permission | shared correlation | one Room transaction; source return identity | shortage, blocked lot or posting failure rolls back all participants |
| Recipe consumption | daily-sales application → `InventoryCommandService.issue` | recipe snapshot reads, lot allocation, balance/item projection, movement | FEFO location issue | part of daily-sales COGS | sales boundary plus Inventory validation | parent sales event | parent Room transaction; parent/source command identity | Inventory failure aborts daily sales posting |
| Sales consumption | `LocalDailySalesRepository.post` → Inventory issue | sales summary/lines, lots, balances, movements, journals, audit/outbox | ingredient consumption | COGS/inventory | sales permission | parent sales event | one Room transaction; daily-sale key | partial stock/journal cannot commit |
| Sales reversal | sales reopen/reversal → Inventory reversal | reversal movements, lots, balances, correcting journals, audit/outbox | restores exact source effects | reversal/correcting journal | sensitive sales permission | parent correlation | one Room transaction; source-constrained reversal | duplicate reversal rejected; participant failure rolls back |
| Waste | `InventoryWasteService.post` | waste document, lot, balances, movement, journal, audit/outbox | location/lot decrease | waste expense/inventory through `AccountingPostingService` | create/approve permissions | document/correlation | one Room transaction; create and post command ids | invalid/expired-policy/shortage/period/accounting/audit failure rolls back |
| Count posting | `InventoryCountService.post` | count session/lines, balances/item projection, movements, audit/outbox | variance movement per finalized line | none in current policy | count post; prior approval + SoD | session/correlation | one Room transaction; unique `postCommandId` | unapproved/stale snapshot/failed movement leaves session unposted |
| Transfer issue | `InventoryTransferService.issue` | transfer/lines, source lot/balance/item projection, OUT movement, audit/outbox | source decrease + in-transit increase | none for same entity | transfer issue | document/correlation | one Room transaction; unique issue command | duplicate/stale/shortage failure leaves document unissued |
| Transfer receipt | `InventoryTransferService.receive` | transfer/lines, destination lot/balance/item projection, IN movement, in-transit release, audit/outbox | destination increase + explicit variance | none for same entity | transfer receive | document/correlation | one Room transaction; unique receive command | over/invalid receipt or stale state leaves transfer in transit |
| Adjustment | `InventoryCommandService.adjust` / approved count path | balance/item projection, movement, audit owner | signed controlled movement | policy-dependent; no direct account mutation | inventory adjust/count post | source document | one Room transaction; command/source key | negative stock, closed period or conflict aborts |
| Reversal | `InventoryCommandService.reverse` through source owner | reversal movement, balance/item/lot projection, audit and caller journal | exact opposite linked to original | caller posts correcting/reversal journal | source-specific sensitive permission | shared correlation | unique `reversalOfMovementId` | historical row remains immutable; duplicate reversal rejected |

## Invariants enforced

1. Every migrated stock effect appends a movement; no Compose/ViewModel writes a stock field.
2. Movement, item/location projection, lot cache, accounting effect and audit event share the parent Room
   transaction when they participate in the same business command.
3. Location availability is validated before issue; another location cannot mask a deficit.
4. Idempotency replay is accepted only for the same payload. A key reused with different facts is a
   conflict, not a second effect.
5. Business date is checked against Inventory closure; Accounting separately enforces its own period.
6. Posted movements and documents are corrected by reversal/correcting facts, never edit/delete.

## Residual compatibility paths

`LocalOperationsRepository` and `LocalManagementControlRepository` retain selected public facade methods
for existing ViewModels. Their migrated Inventory operations delegate to the Inventory services; direct
legacy projection writers are not exposed to presentation. The compatibility item aggregate remains in
the same transaction until all non-Inventory readers migrate to item/location balances.

## Verification status

Integration tests assert representative rollback and replay behavior for ledger, count, waste,
transfer, goods receipt and sales reversal. They are authored but **NOT EXECUTED** in this workspace
because Gradle 8.13 is unavailable. Static architecture and SQLite simulations passed; they do not
replace the Android transaction tests.
