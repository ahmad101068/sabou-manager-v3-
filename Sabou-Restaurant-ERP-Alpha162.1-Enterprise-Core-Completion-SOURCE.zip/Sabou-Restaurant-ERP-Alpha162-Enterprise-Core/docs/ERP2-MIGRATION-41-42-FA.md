# مشخصات Migration پایگاه داده 41 → 42

## هدف

Schema 42 یک Migration سخت‌سازی است: هویت سراسری، idempotency، correlation، actor/location
و immutability را به مسیرهای بحرانی مالی، موجودی و Audit اضافه می‌کند. Migration ترتیبی است
و هیچ `fallbackToDestructiveMigration` یا پاک‌کردن داده برای سبزکردن Build ندارد.

## Old Schema 41

- `journal_entries` فاقد global/idempotency/correlation و actor قطعی بود.
- `stock_movements` actor، location، unit cost، correlation و reversal reference نداشت.
- `inventory_counts` و `stock_transfers` command identity سازمانی نداشتند.
- Audit metadata ساخت‌یافته نبود.
- Performance مقدارهای canonical را در `REAL` نگه می‌داشت.
- requester/approver خرید و creator/approver حقوق فقط با متن یا به‌شکل ناقص قابل ردیابی بود.
- سند مستقل و immutable برای ضایعات وجود نداشت.

## New Schema 42

| Table | تغییر اصلی | Index/Constraint |
|---|---|---|
| `journal_entries` | `globalId`, `idempotencyKey`, `correlationId`, `reversalOfEntryId`, posting actor/time | unique برای global/idempotency/reversal؛ Posted immutable |
| `stock_movements` | command metadata، actor/device/location، unit cost، reason code، reversal | unique idempotency/global/reversal؛ append-only |
| `inventory_counts` | global/idempotency/correlation، actor/device/location | unique command identity؛ append-only |
| `stock_transfers` | global/idempotency/correlation، actor/device | unique command identity؛ header/line immutable |
| `inventory_waste_documents` | جدول جدید سند ضایعات | FK `RESTRICT`، unique identity، append-only |
| `audit_logs` | actorId، business day، device، reference، reason، snapshots، correlation | index actor/reference/date/correlation؛ append-only |
| `performance_goals/scores` | `targetValueMicros` و `achievedValueMicros` | `Long?` canonical؛ `REAL` فقط legacy |
| `purchase_requisitions` | global/correlation و actor IDهای درخواست/تأیید | index requester/approver/correlation |
| `payroll_runs` | global/correlation و creator/approver actor IDs | index status/actor/correlation |

## Data Transformation

- شناسه‌های legacy به‌صورت deterministic مانند `legacy:journal_entry:<id>` backfill می‌شوند.
- idempotency/correlation ردیف‌های قدیمی با prefix مشخص `legacy:*` تولید می‌شود.
- Location قدیمی به محل فعال پیش‌فرض متصل می‌شود؛ اگر «انبار اصلی» وجود نداشته باشد seed می‌شود.
- actor ID قدیمی حدس زده نمی‌شود و `NULL` باقی می‌ماند؛ metadata legacy با sentinel صریح از
  command جدید قابل تشخیص است.
- Performance با `ROUND(legacyReal * 1_000_000)` به fixed-point منتقل می‌شود و ستون Legacy
  برای سازگاری/ممیزی نگه داشته می‌شود.
- Journalهای قطعی قبلی `postedAt` را از `createdAt` backfill می‌کنند؛ actor جعلی ساخته نمی‌شود.
- Auditهای قدیمی حفظ می‌شوند. Migration تاریخی `30→31` دیگر Audit مشتری/میز/سفارش را حذف
  نمی‌کند.

## Default Strategy

Defaultهای blank یا `legacy-unknown` فقط اجازه می‌دهند Room جدول قدیمی را migrate کند.
Triggerهای Schema 42 درج command جدید با blank/sentinel، actor نامعتبر، location غیرفعال یا
reason خالی را رد می‌کنند. Legacy rows موجود قابل خواندن می‌مانند اما به‌عنوان command جدید
بازنویسی نمی‌شوند.

## Delete Behavior

- اسناد مالی/عملیاتی جدید از FK `RESTRICT` استفاده می‌کنند.
- `journal_lines` برای Draft از رابطه موجود استفاده می‌کند، ولی پس از `POSTED` trigger حذف
  header/line را متوقف می‌کند.
- Ledger، Count، Waste، Transfer و Audit update/delete نمی‌شوند.
- Factory Reset فقط در مسیر owner-authorized، guardها را موقتاً برمی‌دارد؛ سپس حساب‌های
  سیستمی، محل پیش‌فرض و تمام guardها را دوباره نصب می‌کند.

## Rollback Risk و Mitigation

| ریسک | راهکار |
|---|---|
| ناسازگاری مسیر قدیمی درج مستقیم `POSTED` | همه postingها ابتدا Draft و سپس finalize/post می‌شوند |
| نبود location برای داده قدیمی | seed محل سیستم پیش از backfill |
| collision شناسه legacy | prefix جداگانه entity + local ID و unique index |
| overflow تبدیل ratio | محاسبات جدید با `BigInteger`؛ تبدیل Legacy در SQLite و تست boundary |
| شکست Audit و partial write | Audit داخل Transaction و failure-propagating |
| تغییر trigger و Factory Reset | فهرست مرکزی drop/reinstall و تست reseed |
| تفاوت Entity و Migration | Full Migration با Room schema validation در CI |

SQLite rollback migration معکوس خودکار ندارد. Downgrade از 42 به 41 پشتیبانی نمی‌شود؛ راه
بازگشت عملیاتی، restore یک Backup سازگار و تأییدشده است. قبل از Upgrade نسخه Production باید
Backup رمزگذاری‌شده و checksum کنترل شود.

## Migration Tests

- `EnterpriseLedgerMigration41To42Test`: backfill، fixed-point، جدول جدید و guardهای
  append-only را بررسی می‌کند.
- `FullMigration1ToCurrentTest`: Schema واقعی نسخه 1 را ایجاد، همه edgeها را اجرا و نتیجه را
  با Entity model جاری Room validate می‌کند.
- `MigrationChainContractTest`: تمام edgeهای ترتیبی `1→current` را اجباری می‌کند.
- `DailySalesMigration30To31Test`: حفظ Auditهای تاریخی را بررسی می‌کند.

تولید و review فایل export شده Schema 42 در `app/schemas` بخشی از CI/Definition of Done است؛
در محیط این بازآرایی KSP/Room اجرا نشد و فایل Schema دست‌ساز تولید نشده است.
