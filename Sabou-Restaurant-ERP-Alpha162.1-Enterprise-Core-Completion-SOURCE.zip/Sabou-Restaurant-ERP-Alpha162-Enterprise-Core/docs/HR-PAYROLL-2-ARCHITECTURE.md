# HR / Payroll 2.0 Architecture

نسخه مبنا: Alpha159 Inventory 2.0 CI-Repair  
نسخه دیتابیس پس از اجرا: 44  
تاریخ طراحی: 2026-08-09

## هدف معماری

HR/Payroll 2.0 یک Document System است، نه یک فرم محاسبه مبلغ. هر عدد نهایی باید از یک سند تاریخی مستقل از state زنده کارمند خوانده شود و مسیر آن تا قرارداد، حضور، مرخصی، policy، adjustment، مساعده، تأیید، حسابداری و پرداخت قابل پیگیری باشد.

اصل مرکزی:

> تغییر بعدی کارمند، قرارداد، حقوق، policy یا حضور نباید مبلغ یا توضیح فیش تأییدشده قبلی را تغییر دهد.

## Boundaryها

| Boundary | مالک | قرارداد مورد استفاده |
|---|---|---|
| HR master و history | Personnel/Workforce | `PersonnelRepository` |
| Payroll documents | Payroll | `HrPayrollCommandService` |
| حسابداری تعهد و برگشت | Accounting Foundation | `AccountingPostingService` |
| پرداخت و برگشت پرداخت | Treasury Foundation | `TreasuryService` |
| مجوز | Security Foundation | `AuthorizationService` + typed `Permission` |
| ممیزی | Audit Foundation | `AuditService` / `LocalAuditEventWriter` |
| trace | Foundation | `CorrelationId` و command receipt |

هیچ DAO حسابداری یا cash/bank از UI یا Payroll مستقیماً mutate نمی‌شود. `LocalTreasuryServiceAdapter` یک adapter محدود بر foundation فعلی است و Treasury 2.0 را در این Task بازطراحی نمی‌کند.

## نمای اجزای سیستم

```mermaid
flowchart TD
    A["Employee master"] --> B["Effective-dated HR history"]
    B --> C["PayrollCalculationService"]
    D["Attendance + Leave ledgers"] --> C
    E["Policy + approved adjustments"] --> C
    C --> F["Payslip snapshot + components"]
    F --> G["Approval + accrual posting"]
    G --> H["Treasury payment ledger"]
    H --> I["Revision / compensating reversal"]
```

## HR Master و تاریخچه

### Employee master

`employees` current projection نگه داشته شده است تا compatibility سورس فعلی حفظ شود. فیلدهای current مانند نام نمایشی، وضعیت، سمت جاری، دپارتمان، شعبه، location، manager، تاریخ استخدام و خاتمه در آن قرار دارند.

حقایق تاریخی یا حساس جدا هستند:

- `employee_private_profiles`: شناسه ملی، بیمه و فقط metadata ماسک‌شده حساب/IBAN؛
- `employment_assignments`: سمت، دپارتمان، شعبه/location و manager با `effectiveFrom/effectiveTo`؛
- `employment_contract_versions`: نسخه‌های قرارداد و حقوق پایه؛
- timeline: projection bounded از رکوردهای فوق و ledgerهای مالی؛ جدول source-of-truth جدید ندارد.

`employeeCode` برای legacy به شکل deterministic `EMP-%06d` backfill می‌شود. ایجاد جدید نیز همین قالب human-readable را در transaction تخصیص می‌دهد. unique index و trigger الزام/ثبات را enforce می‌کنند.

### وضعیت استخدام

`EmploymentStatus` شامل `APPLICANT`, `ACTIVE`, `ON_LEAVE`, `SUSPENDED`, `TERMINATED`, `ARCHIVED` است. `EmploymentStatusTransitionValidator` transition و الزام termination date را کنترل می‌کند؛ DB نیز value ناشناخته را رد می‌کند.

### قرارداد

قرارداد update-in-place نمی‌شود. اصلاح، row جدید با `versionNo`, `replacesContractId`, دلیل و actor می‌سازد. predecessor فقط هنگام approval موفق successor، `SUPERSEDED` می‌شود؛ بنابراین draft یا approval شکست‌خورده قرارداد جاری را از بین نمی‌برد.

`EffectiveContractResolver` فقط یکی از این سه نتیجه را می‌دهد:

- یک قرارداد مؤثر؛
- `NoEffectiveContract`؛
- `ConflictingContracts`.

انتخاب arbitrary با `LIMIT 1` در مسیر Payroll وجود ندارد. overlap هم در domain و هم با trigger دیتابیس کنترل می‌شود.

## Attendance 2.0

`attendance_events` append-only است و event/source/actor/device/location/reason/correlation را ثبت می‌کند. eventهای typed عبارت‌اند از clock-in/out، break start/end، manual adjustment و absence mark.

`AttendanceEventAggregator` summary روزانه را مشتق می‌کند:

- first in / last out؛
- worked / break؛
- late / early leave / overtime / absence؛
- status و anomalyها.

anomalyهای missing clock-out، duplicate in/out، break باز، duration منفی، session متداخل، duration بیش از policy و event خارج دوره استخدام blocking payroll exception می‌شوند.

`attendance` قدیمی به‌عنوان projection/legacy summary باقی مانده است. Migration هیچ clock event ساختگی از aggregate روزانه تولید نمی‌کند.

اصلاح دستی در `attendance_corrections` شامل before/after، دلیل، درخواست‌کننده، approver و timestamp است. اگر policy approval بخواهد، projection فقط بعد از approval و با segregation of duties تغییر می‌کند.

## Leave 2.0

`LeaveStatus` و `LeaveType` typed هستند. درخواست، بررسی، لغو و taken semantics از raw arbitrary state جدا شده‌اند. `leave_ledger_entries` entitlement و usage را append-only نگه می‌دارد و `LeaveBalanceCalculator` چهار مقدار granted/used/pending/remaining را محاسبه می‌کند.

Payroll ورودی مرخصی را فقط از `APPROVED`/`TAKEN` می‌خواند:

- paid/annual/sick/hourly به paid leave minutes تبدیل می‌شوند؛
- unpaid/other به unpaid leave minutes و deduction قابل trace تبدیل می‌شوند؛
- paid leave absence deduction تولید نمی‌کند.

## Payroll document model

### Payroll Period

بازه کسب‌وکار، due date و lifecycle را نگه می‌دارد. close/reopen فرمان مجزا، مجوز مجزا، receipt و optimistic state transition دارد. دوره دارای batch تسویه‌نشده بسته نمی‌شود.

### Payroll Batch

scope، document number، branch/department optional، creator/calculator/reviewer/approver، correlation، exception count و KPIهای aggregate را نگه می‌دارد.

چرخه native:

`DRAFT -> CALCULATED -> UNDER_REVIEW -> APPROVED -> PAYMENT_PENDING -> PARTIALLY_PAID/PAID -> REVERSED`

legacy/cancelled stateها explicit هستند. status فقط از state machine و compare-and-set DAO تغییر می‌کند.

### Payroll Payslip

هر employee در batch یک document مستقل با revision پایدار دارد. unique constraint روی employee + period + revision برقرار است. correction با reversal و revision بعدی ساخته می‌شود؛ فیش approved/paid delete یا financial edit نمی‌شود.

### Snapshot

`payroll_snapshots` تمام input مؤثر را freeze می‌کند:

- employee code/name؛
- contract id/number/version و base salary؛
- standard/eligible/actual/overtime/absence/late/paid-leave/unpaid-leave minutes؛
- policy id/version و basis points/rate؛
- gross/deduction/net؛
- calculation parameters/version/hash.

Snapshot update/delete با trigger ممنوع است. Approval hash را دوباره از snapshot و components محاسبه و مقایسه می‌کند.

### Component ledger

همه amountها مثبت‌اند و `direction` معنای earning/deduction را تعیین می‌کند. هر component type/source/sourceId/quantity/rate/manual override/reason/actor دارد. پس از approval، insert/update/delete component ممنوع است.

## Calculation

`PayrollCalculationService` یک تابع domain deterministic است. ورودی آن snapshot ثابت و adjustmentهای approved است؛ خروجی component ledger، gross، deductions، net و warningهاست. پول فقط `Long`/`MoneyRial` و نسبت فقط fixed-point basis points است. محاسبات از checked arithmetic و HALF_UP استفاده می‌کنند.

Calculation هیچ اثر حسابداری/خزانه ندارد. failure یک employee به `payroll_exceptions` تبدیل می‌شود؛ batch نیمه‌approved یا نیمه‌paid نمی‌ماند.

## Approval و segregation of duties

Creator و Calculator نمی‌توانند final approver همان batch باشند. adjustment و attendance correction نیز self-approval را رد می‌کنند. مجوزهای create/calculate/review/approve/reverse/pay و view-all مستقل هستند.

Final approval در یک transaction:

1. period/batch/payslip state و exceptionها را اعتبارسنجی می‌کند؛
2. snapshot completeness/hash را بررسی می‌کند؛
3. allocations مساعده را با سقف outstanding ثبت می‌کند؛
4. accrual journal را از `AccountingPostingService` ثبت می‌کند؛
5. فیش‌ها و batch را freeze/transition می‌دهد؛
6. approval event، audit و command receipt را append می‌کند.

## Accounting و Treasury

Approval، expense/liability recognition است. componentها با semantic role به salary/overtime/bonus/insurance/tax/advance offset/payroll payable نگاشت می‌شوند؛ account code در Payroll پراکنده نیست.

Payment رویداد جداست. `TreasuryService.execute` liability را از حساب خزانه منتخب settle می‌کند. هر payment دارای idempotency key، reference، treasury transaction، journal و correlation است. paid/remaining از payment ledger محاسبه و projection فیش با optimistic version به‌روزرسانی می‌شود.

Payment reversal اول compensating treasury/accounting transaction می‌سازد، سپس original و reversal ledger row را ثبت می‌کند. Payslip reversal تا وقتی payment باز وجود دارد ممنوع است.

## Advance allocation

Allocation برای هر payslip/advance row مستقل دارد، amount مثبت و capped به outstanding است. unique command key duplicate را رد می‌کند. reversal فیش allocation را reverse و outstanding advance را restore می‌کند.

## Idempotency و concurrency

هر command مالی `commandId` پایدار دارد. `hr_payroll_command_receipts`، command type + payload hash + result را append-only نگه می‌دارد:

- replay با payload برابر همان result را برمی‌گرداند؛
- replay با payload متفاوت `IdempotencyConflict` است؛
- rowVersion و compare-and-set double-click/two-approver race را رد می‌کنند؛
- unique indexها آخرین safeguard دیتابیس‌اند.

Batch، payslip، journal، treasury transaction، approval/audit و receipt correlation مشترک دارند.

## Data integrity guards

Schema 44 triggerهایی برای موارد زیر نصب می‌کند:

- employee code/status و no-delete دارای history؛
- contract overlap/freeze/no-delete؛
- attendance event/correction و leave ledger immutability؛
- snapshot/component/payslip freeze و amount equations؛
- payment/allocation validity/freeze/no-delete؛
- approval event و command receipt append-only.

Guardها در migration، fresh create و factory reset دوباره نصب می‌شوند.

## Performance

- calculation inputها به‌صورت bulk و chunked برای SQLite `IN` limit خوانده می‌شوند؛
- queryهای attendance/payroll history index دارند؛
- Employee Timeline و Payslip History `limit/offset` دارند و UI حداکثر 100 row بار می‌کند؛
- dashboardهای attendance/leave/legacy payroll با limit ثابت bounded هستند؛
- batch KPI در SQL aggregate می‌شود؛
- component و snapshot load به‌صورت batch انجام می‌شود و N+1 محاسبه حذف شده است.

## Legacy semantics

Legacy payroll totals حفظ می‌شوند، اما component و payment ساختگی ساخته نمی‌شود. legacy payslip دارای `source=LEGACY_MIGRATION`, `componentDetailComplete=false` و snapshot ناقص explicit است. قراردادهای legacy متعارض repair نمی‌شوند و anomaly ثبت می‌شود.

## محدودیت آگاهانه Scope

- Treasury adapter از foundation موجود استفاده می‌کند؛ Treasury 2.0 کامل خارج Scope است.
- Document vault و PDF renderer خارج Scope هستند؛ IDs و snapshot export-ready هستند.
- دستگاه حضور و scheduling کامل در Task بعدی توسعه می‌یابد؛ event/device/location و Workforce ownership از اکنون آماده‌اند.
