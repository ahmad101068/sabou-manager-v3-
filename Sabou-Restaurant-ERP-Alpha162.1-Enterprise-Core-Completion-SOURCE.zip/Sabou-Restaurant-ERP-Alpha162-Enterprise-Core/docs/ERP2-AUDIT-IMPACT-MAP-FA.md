# ممیزی و Impact Map بازآرایی Sabou Restaurant ERP 2.0

تاریخ ممیزی: ۱۴۰۵/۰۵/۱۸ (2026-08-09)

## دامنه ممیزی

این گزارش پیش از هر تغییر رفتاری و با بررسی ساختار Gradle، تمام Entityها و DAOها،
Repositoryها، مدل‌های Domain و Calculatorها، ViewModelها، Screenها و Navigation، تست‌های
واحد و Instrumentation، زنجیره Migration و مستندات موجود تهیه شده است.

خط مبنا:

- Kotlin/Android/Compose در یک ماژول `:app`
- Room + SQLCipher و Schema جاری `41`
- 27,183 خط Kotlin در `main`، 2,043 خط Unit Test و 2,724 خط Instrumentation Test
- 151 تست واحد و 52 تست Instrumentation شناسایی‌شده
- Sync عمداً fail-closed است و نباید به‌عنوان replication عملیاتی معرفی شود

## نتیجه اجرایی

پروژه یک Prototype خالی نیست: primitiveهای fixed-point، Accounting Posting Boundary،
Journal balance validation، تراکنش‌های Room، recipe versioning، backup امن و تعدادی guard
دیتابیس وجود دارند. با این حال، بسته فعلی با معیار Restaurant ERP 2.0 فاصله معنادار دارد و
نباید در وضعیت فعلی تنها مرجع مالی یا موجودی Production باشد.

### یافته‌های P0

1. `AppDatabase` روی Schema 41 است، اما `MigrationChainContractTest` فقط تا 40 را انتظار
   دارد و Full Migration Test نیز نام/انتظار 39/40 دارد. `STATUS-FA.md` و artifact name در
   CI همچنان alpha153.9 را اعلام می‌کنند.
2. `scripts/verify-foundation.sh` به versionName و Schema قدیمی assert می‌کند و در خط مبنا
   بدون خروجی با exit code 1 متوقف می‌شود؛ بنابراین CI قبل از Gradle شکست خواهد خورد.
3. فقط Schema export نسخه 1 در repository وجود دارد. Schema جاری باید توسط Room در CI
   تولید و با diff کنترل شود.
4. Journalهای `POSTED` فقط در دوره بسته محافظت می‌شوند؛ در دوره باز guard سراسری
   append-only برای header/lines وجود ندارد. اصل «Reversal + Correcting Entry» در سطح DB
   کامل enforce نشده است.
5. `LocalInventoryCommandEngine` از caller انتظار Transaction دارد. فراخوانی مستقل آن
   می‌تواند projection موجودی و Stock Movement را نیمه‌کاره باقی بگذارد.
6. Stock Movement فاقد `globalId`، `idempotencyKey`، `correlationId`، actor، location و
   unit-cost صریح است و در سطح DB append-only نیست.
7. Audit Log append-only است، ولی ستون‌های اجباری actorId، business timestamp، deviceId،
   reference، reason و before/after snapshot را به‌صورت ساخت‌یافته ندارد؛ بخشی از این داده‌ها
   داخل `description` فشرده شده‌اند.

### یافته‌های P1

1. Permissionها String-based هستند. Role ناشناخته به `CASHIER` fallback می‌کند و ممکن است
   دسترسی ناخواسته فروش/گزارش بدهد؛ fallback باید fail-closed باشد.
2. تأیید درخواست خرید، creator/approver و approverهای سطح اول/دوم را با actor ID جدا نمی‌کند.
   Payroll نیز creator actor ID ندارد و self-approval در داده قابل جلوگیری قطعی نیست.
3. Business failureها عمدتاً با `require`, `check`, `error(message)` و message string کنترل
   می‌شوند. UI فقط `IllegalArgumentException/IllegalStateException` را می‌شناسد.
4. موجودی جاری در `inventory_items` و ledger در `stock_movements` هر دو نگه‌داری می‌شوند،
   ولی projection reconciliation و invariant test سراسری وجود ندارد.
5. Performance quantity در persistence از `REAL/Double` استفاده می‌کند و هنگام mapping با
   ضرب `1_000_000.0` به fixed point تبدیل می‌شود.
6. یک محاسبه unit-cost خرید از ضرب خام `Long * 1_000_000` استفاده می‌کند و در مرزهای بزرگ
   امکان overflow دارد.

### یافته‌های معماری و نگهداشت‌پذیری

| فایل | خطوط | ریسک |
|---|---:|---|
| `data/db/Daos.kt` | 1690 | God DAO file و ownership مبهم |
| `data/db/AppDatabase.kt` | 1555 | Database definition، migrations، triggers و seed در یک فایل |
| `ui/OperationsScreens.kt` | 1333 | چند workflow و component در یک Screen file |
| `data/repository/LocalProcurementRepository.kt` | 1202 | requisition تا receiving/return/sourcing در یک class |
| `ui/SabouApp.kt` | 1118 | route model، DI/ViewModel wiring، router و dashboard در یک فایل |
| `ui/AccountingScreens.kt` | 903 | چند workspace مالی در یک فایل |
| `data/BackupManager.kt` | 717 | orchestration، crypto envelope و filesystem policy در یک class |

تفکیک باید Incremental باشد؛ Multi-module Big Bang در این مرحله انجام نمی‌شود. ابتدا مرزهای
کد و قراردادها تثبیت می‌شوند و سپس انتقال Gradle module در یک build-verified increment مستقل
انجام خواهد شد.

## Capability Map ماژول‌ها

| Boundary هدف | وضعیت موجود | مالک فعلی | شکاف اصلی |
|---|---|---|---|
| core | فعال | `core` | typed business result و شناسه سراسری کم است |
| inventory | فعال/ترکیبی | `domain.operations`, `LocalOperationsRepository` | metadata/idempotency/ledger projection |
| procurement | فعال | `domain.purchase`, `LocalProcurementRepository` | God repository، SoD و typed status mapping |
| sales/POS | فروش تجمیعی روزانه | `domain.sales` | POS order lifecycle واقعی وجود ندارد |
| recipe | فعال و versioned | `domain.recipe` | production/semi-finished recipe وجود ندارد |
| production | غایب | — | batch/yield/WIP/production consumption |
| accounting | فعال | `domain.accounting` | posted immutability و idempotent posting کامل نیست |
| treasury | فقط foundation model | `domain.treasury` | repository، settlement workflow و reconciliation کامل |
| workforce | فعال/ترکیبی | `domain.personnel`, `domain.control` | مرز workforce/payroll جدا و SoD ناقص |
| payroll | فعال | `LocalPersonnelRepository` | creator/approver IDs و approval policy |
| assets | فعال | `domain.assets` | batch runs و action state |
| analytics | پراکنده | dashboard/control/management | KPI definition و drill-down یکدست نیست |
| security | فعال | `domain.operations`, `data.security` | typed permission و fail-closed legacy mapping |
| audit | فعال ولی کم‌ساختار | `audit_logs` در operations | event envelope کامل و structured snapshots |
| sync | partial و disabled | `domain.operations`, repository | pull/apply/conflict protocol غایب؛ باید disabled بماند |
| multi-location | foundation | location/lot/transfer در management control | اتصال همه movementها و documentها به location/branch |

## Target Design این Increment

1. `core`: typed `BusinessError`, safe fixed-point ratio و `GlobalId`.
2. `security`: `Permission` type-safe، role mapping fail-closed و authorization در command
   boundary.
3. `accounting`: تمام postingها در transaction داخلی؛ header/lineهای posted در DB immutable؛
   اصلاح فقط با reversal/correction.
4. `inventory`: command context دارای idempotency/correlation/actor/location؛ هر command داخل
   transaction داخلی؛ ledger append-only و balance projection قابل reconciliation.
5. `audit`: envelope ساخت‌یافته با actorId، business time، device، reference، reason و
   before/after snapshot.
6. `procurement/payroll`: actor IDs و Separation of Duties برای approvalهای جدید.
7. `database`: Migration ترتیبی `41 -> 42` با backfill fail-safe، index و migration tests.
8. `presentation`: mapping متمرکز BusinessError به پیام فارسی actionable و explicit action
   state برای workflowهای تغییرکرده.
9. `structure`: split تدریجی DAO/Database/Navigation بدون تغییر API رفتاری هم‌زمان.

## Impact Map فایل‌ها

### فایل‌های جدید

- `core/GlobalId.kt`
- `core/FixedPointRatio.kt`
- `domain/common/BusinessError.kt`
- `domain/security/Permission.kt`
- `domain/inventory/InventoryLedgerModels.kt`
- `domain/audit/AuditEvent.kt`
- `data/repository/AuditEventWriter.kt`
- `data/db/DatabaseIntegrityGuards.kt`
- `data/db/DatabaseMigrations.kt` یا migration range files
- Unit/Instrumentation tests متناظر برای error mapping، SoD، idempotency، rollback،
  immutability، reconciliation و Migration 41→42

### فایل‌های Split شونده

- `Daos.kt` → DAOهای supplier, inventory, purchase, procurement, stock movement,
  accounting, personnel, recipe, audit, security, asset, alert
- `AppDatabase.kt` → database definition، migration registry، migrations، integrity guards،
  seed callback
- `SabouApp.kt` → route contract، module catalog، router/root host و dashboard
- `OperationsScreens.kt` → inventory/supplier/purchase/shared date components (مرحله‌ای)
- `LocalProcurementRepository.kt` → requisition/approval/order/receiving/invoice-match/return/
  sourcing delegates پشت facade فعلی (مرحله‌ای)

### Entityهای تغییرکننده در Schema 42

- `journal_entries`: idempotency/global identity و immutability guards
- `stock_movements`: global/idempotency/correlation، actor/location، unit cost و guardها
- `audit_logs`: envelope ساخت‌یافته کامل و indexهای reference/actor/business time
- `performance_goals`, `performance_scores`: fixed-point micros به‌عنوان مقدار canonical
- `purchase_requisitions`: requester/approver actor IDs برای SoD
- `payroll_runs`: creator/approver actor IDs برای SoD

### Contractهای تغییرکننده

- `SessionAuthorizer.require(String)` → `require(Permission)`
- `UserRole.permissions: Set<String>` → `Set<Permission>` و legacy mapping fail-closed
- Inventory command methods → command context type-safe و نتیجه idempotent
- Audit insertion مستقیم → `AuditEventWriter`
- persistence status/reference mapping → enum/value-object در Domain boundary
- UI error handling → `BusinessError` mapping، جدا از technical failure

### Migration 41 → 42

- old schema: Schema 41 با unit conversion و ستون‌های audit/ledger legacy
- new schema: ستون‌ها و indexهای بالا، triggerهای immutability و fixed-point canonical
- transformation: backfill شناسه legacy قطعی، تبدیل `REAL * 1_000_000` با کنترل null،
  actor IDهای legacy به null و metadata legacy با sentinel صریح
- default strategy: فقط برای رکوردهای legacy؛ commandهای جدید مجاز به sentinel یا blank نیستند
- rollback risk: trigger ناسازگار با مسیرهای قدیمی finalize journal و constructorهای Room
- mitigation: ابتدا posting paths به DRAFT→lines→finalize→POSTED منتقل می‌شوند، سپس guard؛
  migration test و full-chain Room validation الزامی است

## Regression Surface

- create/settle/reverse خرید و procurement receiving/return
- daily sales posting/reversal و COGS
- payroll draft/approval/reversal و advance allocation
- asset acquisition/depreciation/disposal
- manual journal/reversal و period close/reopen
- inventory count/waste/lot FEFO/transfer/period close
- backup restore و full migration chain
- sync outbox revision/audit coupling
- UI role visibility، sensitive action re-auth و پیام خطا

## Verification Gate

هر Increment باید حداقل این کنترل‌ها را پاس کند:

1. static architecture/foundation checks بدون assertion شکننده نسخه‌ای
2. Unit tests برای overflow، fixed precision، typed state/error و SoD
3. Room migration test 41→42 و full chain 1→42
4. Transaction rollback tests برای inventory+accounting+audit
5. idempotency tests برای command retry
6. DB guard tests برای update/delete Journal، Stock Movement و Audit
7. `testDebugUnitTest`, `lintDebug`, `assembleDebug`, `assembleRelease`
8. Instrumentation روی API 23 و API جاری

در محیط فعلی Android SDK و Gradle distribution در دسترس نیست؛ بنابراین Build success تنها
پس از اجرای واقعی Gradle/CI قابل ادعا است. Static verification جای Build را نمی‌گیرد.

## مواردی که نباید جعلی Done اعلام شوند

- POS/KDS/production کامل، treasury عملیاتی، backend sync و multi-branch conflict resolution
  در سورس فعلی وجود ندارند و با افزودن Screen یا مدل placeholder «تکمیل‌شده» محسوب نمی‌شوند.
- Sync تا تکمیل pull/apply/idempotent conflict protocol باید fail-closed باقی بماند.
- این Increment foundation و critical-path hardening است؛ تکمیل Restaurant OS به Vertical
  Sliceهای بعدی نیاز دارد.
