# Employee 360 Design

## هدف

Employee 360 یک master profile با history قابل اثبات است. رکورد current برای تجربه کاربری سریع استفاده می‌شود، اما تغییر current state هیچ fact تاریخی قرارداد یا Payroll را بازنویسی نمی‌کند.

## تفکیک اطلاعات

| گروه | محل نگهداری | رفتار تاریخی |
|---|---|---|
| شناسه و تماس current | `employees` | current projection |
| وضعیت استخدام | `employees.status` + audit | typed transition |
| ملی/بیمه/پرداخت | `employee_private_profiles` | دسترسی حساس و metadata ماسک‌شده |
| سمت/دپارتمان/شعبه/location/manager | `employment_assignments` | effective-dated |
| حقوق پایه و شرایط کار | `employment_contract_versions` | versioned/approved |
| حضور | event ledger + legacy summary | append-only/derived |
| مرخصی | request + entitlement/usage ledger | workflow + append-only |
| حقوق | period/batch/payslip/snapshot/component/payment | immutable document history |
| Timeline | SQL projection | source-of-truth جدید نیست |

## Employee Code

- nullable legacy code در migration با `EMP-%06d` و local ID موجود backfill می‌شود؛
- code جدید در transaction با sequence human-readable تخصیص می‌یابد؛
- کاربر می‌تواند code معتبر ارائه کند؛ unique index collision را رد می‌کند؛
- پس از وجود payroll history، trigger تغییر code را ممنوع می‌کند؛
- DB ID هرگز به‌عنوان code نمایشی خام استفاده نمی‌شود.

## Employment Status

| From | transitionهای مجاز |
|---|---|
| APPLICANT | ACTIVE, ARCHIVED |
| ACTIVE | ON_LEAVE, SUSPENDED, TERMINATED, ARCHIVED |
| ON_LEAVE | ACTIVE, SUSPENDED, TERMINATED, ARCHIVED |
| SUSPENDED | ACTIVE, TERMINATED, ARCHIVED |
| TERMINATED | ARCHIVED |
| ARCHIVED | هیچ transition |

`TERMINATED` به termination date نیاز دارد. state ناشناخته در command boundary typed failure و در DB trigger violation است.

## Assignment history

هر تغییر job/department/branch/location/manager به یک assignment جدید نیاز دارد. assignment باز قبلی با روز قبل از `effectiveFrom` جدید بسته می‌شود. تاریخ اثر الزامی است و تغییر current employee row و history در یک transaction انجام می‌شود.

## Contract history

هر row قرارداد شامل موارد زیر است:

- contract number و version؛
- employee و predecessor؛
- contract type؛
- effective range؛
- base salary Rial؛
- standard daily/weekly minutes؛
- overtime/payroll policy reference؛
- snapshot سمت/دپارتمان/شعبه؛
- status، actor و approval timestamps؛
- reason/correlation/source.

اصلاح قرارداد row جدید می‌سازد. predecessor هنگام approve successor superseded می‌شود. قرارداد استفاده‌شده در فیش frozen قابل edit/delete نیست. overlap بدون policy مجاز نیست.

## Effective Contract Resolution

Resolver همه candidateهای معتبر روز کسب‌وکار را می‌گیرد و replacement chain را در نظر می‌گیرد. خروجی فقط یک قرارداد است. zero و conflict به‌ترتیب `NoEffectiveContract` و `ConflictingContracts` هستند؛ caller حق انتخاب arbitrary ندارد.

## Sensitive Profile

`employee_private_profiles` شامل national ID، insurance number، bank name، last four account/IBAN و account holder است. command مشاهده/ویرایش private profile به `EMPLOYEE_SENSITIVE_EDIT` نیاز دارد.

قواعد privacy:

- مقدار کامل card/account/IBAN در جدول جدید ذخیره نمی‌شود؛
- UI فقط `••••1234` نمایش می‌دهد؛
- list model national ID و account data خام برنمی‌گرداند؛
- audit/log description شامل مقدار حساس نیست؛
- اطلاعات legacy پس از انتقال به private profile از ستون‌های عمومی پاک می‌شوند.

## Timeline projection

Timeline bounded مستقیماً از این منابع ساخته می‌شود:

- employee hire/termination؛
- assignment changes؛
- approved contract versions و salary changes؛
- approved/taken leave و return status audit؛
- approved/reversed payslips؛
- payroll payments و payment reversals؛
- advances.

eventهای اصلی: `HIRED`, `JOB_CHANGED`, `CONTRACT_STARTED`, `CONTRACT_CHANGED`, `SALARY_CHANGED`, `LEAVE`, `RETURNED`, `PAYROLL_APPROVED`, `PAYROLL_PAID`, `PAYROLL_PAYMENT_REVERSED`, `PAYROLL_REVERSED`, `ADVANCE_CREATED`, `TERMINATED`.

Timeline با `LIMIT/OFFSET` خوانده می‌شود و stable key آن از reference واقعی ساخته می‌شود.

## Employee 360 UX

People Home جست‌وجوی name/code/phone/job/department و فیلتر status/department را ارائه می‌کند. detail به tabهای زیر تقسیم شده است:

1. Overview
2. Employment + Timeline
3. Contracts
4. Attendance
5. Leave
6. Payroll
7. Advances
8. Performance
9. Documents readiness
10. Audit readiness

Payroll tab history دوره‌به‌دوره و revision‌به‌revision را نشان می‌دهد. جزئیات فیش از snapshot و ledger خوانده می‌شود، نه employee/contract current.

## Retention و deletion

- employee دارای contract/attendance/payroll history hard-delete نمی‌شود؛
- archive/terminate مسیر رسمی است؛
- contract versions delete نمی‌شوند؛
- posted payroll/payment/accounting records فقط با reversal جبران می‌شوند؛
- legacy facts همان source marker خود را حفظ می‌کنند.

## Query strategy

- People list current projection است؛
- attendance/leave dashboard حداکثر 500 row اخیر می‌خواند؛
- timeline و payslip history حداکثر 100 row در هر page؛
- Payroll detail فقط هنگام بازشدن فیش snapshot/components/payments/approvals را load می‌کند؛
- batch calculation از bulk queries و chunking استفاده می‌کند.
