# گزارش فنی بازآرایی Sabou Restaurant ERP 2.0

تاریخ: 2026-08-09

نسخه: `3.0.0-alpha156.0-erp2-ledger-foundation`

Schema: `42`

## خلاصه نتیجه

این بسته یک Vertical Slice کامل برای کل Restaurant OS نیست؛ یک Increment قابل Review برای
سخت‌سازی foundation و مسیرهای بحرانی Accounting/Inventory/Audit/Security است. تغییرها Big
Bang یا Multi-module نیستند و facadeهای موجود برای کاهش Regression حفظ شده‌اند.

## PHASE A — Audit

تمام Entityها، DAOها، Repositoryها، Domain calculatorها، ViewModelها، Screen/Navigation،
تست‌ها، Migration chain، CI و مستندات بررسی شد. یافته‌های P0 شامل stale migration tests،
Journal قابل‌ویرایش، Inventory engine وابسته به caller transaction، metadata ناقص Ledger،
Audit ناکافی و role fallback ناامن بود.

خروجی: `ERP2-AUDIT-IMPACT-MAP-FA.md`.

## PHASE B — Target Domain Design

Boundaryهای هدف، dependency rule، transaction envelope، state machine حسابداری، ledger/
projection policy، typed error/permission و مسیر split تدریجی تعریف شد.

خروجی: `ERP2-TARGET-ARCHITECTURE-FA.md`.

## PHASE C — Data Model

- Global ID و command metadata به Journal، Movement، Count، Transfer، Audit، Requisition و
  Payroll اضافه شد.
- `inventory_waste_documents` به‌عنوان سند immutable ضایعات اضافه شد.
- Performance مقدار `Long micros` canonical دریافت کرد.
- Actor fields لازم برای SoD خرید و حقوق افزوده شد.
- Indexهای پرتکرار identity/status/actor/location/reference/date افزوده شدند.

## PHASE D — Migration

Schema از 41 به 42 ارتقا یافت. Backfill deterministic و قابل تشخیص است، Audit قدیمی حفظ
می‌شود، location سیستم قبل از backfill seed می‌شود و guardهای تازه هم در Migration و هم در
callback نصب می‌شوند. مشخصات کامل در `ERP2-MIGRATION-41-42-FA.md` است.

## PHASE E — Domain Logic

- `FixedPointRatio` ضرب/تقسیم را با `BigInteger` و rounding صریح انجام می‌دهد.
- `BusinessError` مسیرهای insufficient stock، closed period، permission، SoD، expired lot،
  idempotency و concurrent modification را type-safe می‌کند.
- Permission/UserRole typed و legacy role fail-closed شد.
- statusهای Journal، Payroll، Inventory Period و Purchase Payment در Domain typed شدند.
- SoD مستقل برای requester/approver و payroll creator/approver اجرا شد.

## PHASE F — Repository / Transaction Boundary

- Accounting: درج Draft، همه lines، کنترل balance و transition به Posted در یک Transaction؛
  retry همان نتیجه را بازمی‌گرداند.
- Inventory: commandها مالک Transaction هستند؛ Projection با CAS و Movement append-only در
  یک مرز ثبت می‌شوند.
- Waste: Document + FEFO lot consumption + Projection + Movement + Journal + Audit + Outbox
  اتمیک است.
- Count/Transfer/Settlement/Payroll/Manual Journal دارای command ID پایدار شدند.
- Audit writer شکست را swallow نمی‌کند و Transaction را rollback می‌کند.
- authorization در Repository/Command boundary enforce می‌شود، نه فقط UI.

## PHASE G — ViewModel

UiErrorHandler خطاهای Business را مستقل از خطاهای فنی به پیام فارسی actionable تبدیل می‌کند.
ViewModelهای تغییرکرده stateهای saving/error را نگه می‌دارند و منطق مالی/SQL وارد Compose
نشده است. بازطراحی همه ViewModelهای قدیمی خارج از این Increment باقی مانده است.

## PHASE H — UX/UI

- شمارش موجودی workflow احراز مجدد PIN دارد.
- command ID در طول بازبودن dialog ثابت می‌ماند تا double-tap/retry سند تکراری نسازد.
- متن خطا فارسی و قابل اقدام است.
- RTL و اجزای فعلی حفظ شد؛ بازطراحی کامل Tablet/Landscape و split فایل عظیم Screen در
  Increment build-verified بعدی انجام می‌شود.

## PHASE I — Tests

Unit tests جدید:

- Global ID و fixed-point ratio/overflow/rounding
- Permission legacy fail-closed
- Separation of Duties و threshold تأیید خرید
- command identity شمارش و ضایعات

Instrumentation tests جدید/به‌روزشده:

- Accounting balance، idempotent retry، Posted immutability، closed-period rollback و reversal retry
- Inventory receive retry، payload conflict، ledger immutability و closed-period rollback
- Waste/Count exactly-once و rollback اتمیک cross-domain
- Migration `41→42`، Full Chain `1→current` و حفظ Audit تاریخی
- Factory Reset و reseed حساب/Location/guard

در سورس نهایی ۱۶۴ `@Test` واحد و ۶۱ `@Test` Instrumentation شناسایی شد. این عدد شمارش
تعریف تست است، نه ادعای اجرای موفق Gradle در این محیط.

## PHASE J — Build & Verification

| Gate | نتیجه این محیط |
|---|---|
| `scripts/verify-foundation.sh` | موفق |
| `git diff --check` | موفق |
| Parse ۸۴ فایل Kotlin تغییرکرده | بدون خطای نحوی |
| Gradle wrapper / Android SDK | در دسترس نبود |
| Unit/Instrumentation/Lint/KSP/Build | اجرا نشده؛ در انتظار CI |

Gradle Wrapper به `services.gradle.org` نیاز داشت و distribution 8.13 در cache موجود نبود.
به همین دلیل عبارت «Build موفق» در این گزارش وجود ندارد. Workflow گیت‌هاب Unit Test، Lint،
Debug، Android Test APK، Instrumentation روی API 23/35 و Release را gate می‌کند.

## PHASE K — Technical Report

مستندات README، Status، Changelog، Impact Map، Architecture، Migration و Remaining Roadmap
به‌روزرسانی شد. نام artifact CI با alpha156 هماهنگ است.

## Regression Surface بررسی‌شده

- خرید/تسویه/برگشت و procurement receiving/return
- فروش روزانه/COGS و reversal
- payroll draft/approval/reversal
- asset accounting
- manual journal/reversal و period guards
- count/waste/lot/transfer/inventory close
- security audit، factory reset، backup/full migration و sync outbox coupling

Static review جای اجرای device test را نمی‌گیرد؛ موارد بالا باید در CI و سپس smoke test گوشی
واقعی تأیید شوند.

## تصمیم‌های آگاهانه

- Multi-module Big Bang انجام نشد.
- schema export 42 دست‌ساز نشد؛ Room/KSP باید آن را تولید کند.
- Sync ناقص فعال نشد.
- POS/KDS/Production/Treasury/Multi-branch با placeholder «تکمیل» اعلام نشدند.
- ستون‌های Legacy برای migration compatibility حذف نشدند.
