# Inventory 2.0 — Audit, Impact Map, and Implemented Architecture

Baseline audited: Sabou Restaurant ERP 2.0 Alpha158, Room schema 42

Candidate implemented: Alpha159 Inventory 2.0, Room schema 43

Audit phase status: completed before implementation; retained below as design evidence

## Executive audit conclusion

Alpha158 already has a valuable inventory-ledger foundation: stock movements are append-only, command execution is wrapped in Room transactions, quantity/value projections use compare-and-set writes, closed inventory periods are guarded at the database boundary, and receipt/sale/waste paths already carry idempotency and correlation identifiers.

The current model is nevertheless item-centric rather than location-centric. `inventory_items.stockMicros` and `inventoryValueRial` are the operational projection used for stock guards; lot quantities and locations are secondary structures under Management Control. Counts and transfers are immediate one-step records rather than controlled documents. Goods receipts do not create traceable lots, stock movements do not identify a lot directly, FEFO is item-wide, and the inventory UI loads aggregate lists into one Operations state.

Inventory 2.0 therefore extends the verified engine instead of creating a parallel stock system. The immutable stock ledger remains the historical authority; rebuildable item/location projections provide fast availability checks. Legacy aggregate fields remain compatibility projections until all callers are migrated.

## Implemented outcome

The target architecture below is implemented in schema 43. Inventory now owns item/location/lot master
data, immutable movement commands, location balances, FEFO, integrity checks, controlled count/waste/
transfer workflows, replenishment intelligence and decision workspaces. Purchase receipt/return and
sales/recipe consumption adapt to the same command engine. Accounting, authorization, audit,
correlation and migration registries reuse the Alpha158 Foundation rather than creating parallel
infrastructure.

The release-verification status is intentionally separate: static checks pass, but Gradle/KSP/Room and
Android migration/integration tests could not execute in this environment. See
`INVENTORY-TEST-REPORT.md` and `INVENTORY-MIGRATION-REPORT.md`.

## Existing entities

| Entity | Current responsibility | Main limitation |
|---|---|---|
| `InventoryItemEntity` | Item identity, units, supplier, aggregate quantity/value | No SKU, typed item type, barcode, storage/expiry policy, or replenishment master data |
| `StockMovementEntity` | Append-only quantity/value history with source, actor, location, idempotency, correlation, reversal | `locationId` is nullable for legacy; no direct `lotId`; raw persistence strings |
| `InventoryCountEntity` | One-item immediate physical correction | No count session, lines, blind count, approval, recount, or state machine |
| `InventoryWasteDocumentEntity` | One-item posted waste document | No document number, typed reason/status, lot, approval, or explicit unit-cost snapshot |
| `StorageLocationEntity` | Named active location | Owned by Management Control; no stable code; raw kind |
| `InventoryLotEntity` | Lot/location allocation and mutable remaining quantity cache | No status, supplier lot, production date, source receipt, or immutable ledger-derived balance |
| `InventoryLotConsumptionEntity` | Links an issue movement to consumed lots | Consumption-only; receipt and transfer movements are not directly lot-addressable |
| `StockTransferEntity` | Immediate source-to-destination lot transfer | No lifecycle, in-transit state, issue/receipt actors, or variance control |
| `StockTransferLineEntity` | Item/lot-code transfer quantity | Lot is a string, not a foreign key; no requested/issued/received quantities |
| `InventoryReplenishmentPolicyEntity` | Target cover, lead time, safety stock, order multiple | Item-global; no location context or min/max/reorder point |
| `InventoryPeriodClosureEntity` and line | Inventory period close and value snapshot | Must remain compatible with the new ledger/projection model |

## Existing tables

Inventory-owned or inventory-affecting tables are:

- `inventory_items`
- `stock_movements`
- `inventory_counts`
- `inventory_waste_documents`
- `inventory_period_closures`
- `inventory_period_closure_lines`
- `storage_locations`
- `inventory_lots`
- `inventory_lot_consumptions`
- `stock_transfers`
- `stock_transfer_lines`
- `inventory_replenishment_policies`
- purchase/goods-receipt/return tables, recipe version tables, daily-sales tables, journal tables, audit log, and sync outbox as integration participants

## Existing DAO queries

| DAO | Relevant behavior | Risk/constraint |
|---|---|---|
| `InventoryDao` | Item CRUD, aggregate projection CAS, active items, low-stock list | `observeActive()` and `activeItems()` load all rows; legacy non-CAS projection methods remain declared |
| `StockMovementDao` | Insert, idempotency/reversal lookup, bounded item/recent history, sales usage | No item/location/lot paged explorer; missing compound item/location/date and lot indexes |
| `InventoryControlDao` | Waste/count insert and replay lookup, recent counts, period close summaries | Existing count/waste shapes are posted-record models, not workflows |
| `ManagementControlDao` | Location, lot, FEFO, lot consumption, transfer persistence | Inventory ownership is misplaced; FEFO is item-wide and unbounded by status/location |
| `ProcurementDao` | Replenishment policies, 30-day demand, open PO, supplier offers | Demand mixes waste with consumption and uses aggregate item stock |

No Compose screen calls a DAO directly. Repository/application boundaries are already present and must be preserved.

## Current source-of-truth map

### Current stock source of truth

`stock_movements` is the immutable historical ledger by architectural intent. Operational stock guards and UI balances use the mutable but compare-and-set protected `inventory_items.stockMicros` and `inventoryValueRial` projection. Only `LocalInventoryCommandEngine` currently calls the CAS methods. There is no stored location balance projection.

### Current lot source of truth

`inventory_lots.quantityMicros` is a mutable lot balance cache. Issue movements are connected to lots through `inventory_lot_consumptions`; receipt and transfer movement rows do not directly identify their lot. Consequently a complete lot ledger cannot currently be reconstructed from `stock_movements` alone.

### Current location model

Locations are `StorageLocationEntity` records owned by Management Control. A `PRIMARY` location named «انبار اصلی» is seeded. Commands resolve a default location when none is supplied, but the item-level negative-stock guard is global and not per location.

### Current cost/valuation model

The item projection stores aggregate quantity and inventory value. Receipts add their historical value snapshot. Waste derives a current weighted-average unit cost from item aggregate value/quantity. Sales consumption receives a calculated cost from the sales/recipe path. FEFO selects lots and is not the costing method. Historical movement value is not recomputed from supplier prices.

### Current workflows

| Workflow | Current implementation | Main gap |
|---|---|---|
| Count | Immediate item correction in one transaction with sensitive re-authentication | No session/lines, blind count, recount, approval, SoD, or location scope |
| Waste | Document + FEFO issue + journal + audit in one transaction | Raw reason, no lot choice/status/approval/document number |
| Transfer | Immediate lot mutation and paired OUT/IN movements in one transaction | No requested/issued/in-transit/received lifecycle or variance |
| Replenishment | 30-day arithmetic demand, open POs, lead time, safety stock, target cover, supplier offers | Item-global; waste is included in demand; no location availability/in-transit inputs |
| Purchase receipt | Receipt, stock movement, accounting, audit, outbox in one transaction | No lot/expiry capture and default location only |
| Purchase return | Inventory issue with allocated-lot policy and supplier/accounting effects | No explicit source receipt/lot trace in the return line |
| Sales/recipe consumption | Daily sales issues inventory through the command engine and reverses by movement reference | Default location and item-wide FEFO; recipe repository itself is read/master-data only |

## Current security and audit integration

- Repository/application commands use `AuthorizationService`; UI checks are convenience only.
- Generic `INVENTORY`, `INVENTORY_ADJUST`, and `INVENTORY_PERIOD_CLOSE` permissions exist. Fine-grained count/waste/transfer/location/lot permissions do not.
- Count correction and period closure use `SensitiveActionGate`; waste and transfer do not have action-specific approval boundaries.
- `AuditService` is append-only and propagates failures. Count, waste, receipt, and period workflows record audit events. Existing immediate transfer has sync recording but lacks an explicit inventory audit event.
- Correlation and idempotency value objects already exist. New commands must reuse them.

## Current weaknesses and data-integrity risks

| Priority | Finding | Consequence | Required treatment |
|---|---|---|---|
| P0 | Negative-stock guard is item-global, not item/location/lot aware | A location can be over-issued while another location masks the deficit | Location balance CAS in the existing transaction boundary |
| P0 | Lot receipt/transfer history is not fully reconstructable from the movement ledger | Lot cache corruption cannot be reliably rebuilt | Add lot-addressable movement facts and deterministic integrity checks |
| P0 | Count and transfer are posted immediately, without controlled lifecycle | Unauthorized or accidental state changes cannot be separated/reviewed | Document state machines and command-only transitions |
| P1 | Goods receipt cannot capture lot/expiry/location | Traceability breaks at procurement receipt | Inventory receipt command with optional lot specification |
| P1 | FEFO is item-wide and rejects on the first expired candidate | Wrong-location allocation and avoidable failures | Location/status-aware deterministic allocator that excludes invalid lots |
| P1 | Inventory ownership remains in Management Control | Coupled presentation/repository ownership | Move contracts/routes to Inventory; retain a temporary redirect only |
| P1 | Item list and reporting use load-all/filter-in-memory | Poor behavior at 10,000 items/50,000 movements | Database search/filter/bounded paging queries |
| P1 | Raw item/location/lot/waste/transfer states | Invalid stored values can silently leak into behavior | Typed domain mapping with explicit unknown-value failure |
| P2 | Two independent reorder calculators exist | Inconsistent recommendations | Consolidate policy math under Inventory; Procurement consumes recommendations |
| P2 | Non-CAS projection DAO methods remain | Future bypass risk | Remove or restrict after proving no call sites; verification enforces the sole writer |

## Target design

### Authority and projections

1. `stock_movements` remains immutable and is the historical source of truth.
2. `inventory_balances` is a rebuildable item/location projection used for `onHand`, `reserved`, `inTransit`, `damaged`, `quarantined`, and value snapshots.
3. Legacy item aggregate quantity/value remains a compatibility projection during this release and is updated only in the same transaction as the ledger and location projection.
4. Lot remaining quantity remains a cache during migration, but every new lot-affecting command creates enough movement/allocation facts for verification and rebuild.
5. Projection mutation is restricted to the existing inventory command boundary; no DAO is exposed to UI.

### Domain boundaries

| Boundary | Responsibility |
|---|---|
| `InventoryCommandService` | Receipt, issue, adjustment, reversal, projection CAS, period check, idempotency |
| `InventoryRepository` | Bounded read models and item/location/lot master data through authorization-aware application methods |
| `LotAllocationService` | Pure deterministic FEFO allocation with explicit shortage |
| `InventoryValuationService` | Existing weighted-average valuation policy and overflow-safe snapshots |
| `InventoryCountService` | Session lifecycle, blind/recount policy, approval/SoD, atomic posting |
| `InventoryWasteService` | Typed waste document, approval, lot-aware issue, accounting boundary, audit |
| `InventoryTransferService` | Request/issue/receive lifecycle and in-transit reconciliation |
| `InventoryIntegrityService` | Structured ledger/projection/lot/location/transfer checks |
| `ReplenishmentService` | Location-aware recommendation; emits procurement requisition input, never a PO |

`LocalInventoryCommandEngine` will implement/adapt to `InventoryCommandService`; no second accounting, stock, audit, or authorization engine will be introduced.

### Typed models — first Inventory 2.0 wave

- `InventoryItemType`: `INGREDIENT`, `PACKAGING`, `CONSUMABLE`, `PREPARED_ITEM`, `FINISHED_GOOD`
- `InventoryLocationType`: `WAREHOUSE`, `COLD_STORAGE`, `FREEZER`, `KITCHEN`, `PREP`, `BAR`, `OTHER`
- `InventoryLotStatus`: `ACTIVE`, `QUARANTINED`, `EXPIRED`, `DEPLETED`, `BLOCKED`
- `InventoryMovementType`: expanded with explicit receipt/return/consumption/production/waste/transfer/count/opening/reversal values while preserving legacy parsing
- `InventoryCountStatus`: `DRAFT`, `OPEN`, `COUNTING`, `RECOUNT_REQUIRED`, `PENDING_APPROVAL`, `APPROVED`, `POSTED`, `CANCELLED`
- `WasteReason` and `WasteStatus`
- `InventoryTransferStatus`: `DRAFT`, `REQUESTED`, `APPROVED`, `ISSUED`, `IN_TRANSIT`, `RECEIVED`, `COMPLETED`, `CANCELLED`

Persistence remains string-backed. Every mapper must reject or explicitly represent unknown stored values; silent fallback is forbidden.

## Database impact map

The implemented database increment is schema 42 → 43. It is additive/data-preserving except where a table is rebuilt to establish constraints. No destructive fallback is used.

| Existing table | Implemented change |
|---|---|
| `inventory_items` | Add stable unique SKU, item type, primary barcode, brand/storage/shelf-life/lot-expiry policy, stock thresholds, lead time, and updated indexes |
| `storage_locations` | Add stable unique code, normalized location type, update timestamp; preserve ids/names |
| `stock_movements` | Add nullable lot reference and compound location/date/item indexes; preserve append-only rows |
| `inventory_lots` | Add supplier lot, production date, initial quantity, typed status, source receipt, and indexes |
| `inventory_waste_documents` | Add document number, lot, unit cost, typed reason/status, approval/posting actors and timestamps |
| `stock_transfers` / lines | Add lifecycle, command actors/timestamps, lot FK, requested/issued/received/variance quantities |
| New `inventory_balances` | Rebuildable item/location projection with unique item/location key |
| New count session/line tables | Controlled count workflow; legacy `inventory_counts` remains immutable history |

Migration reconciliation creates a single stable `OPENING_BALANCE` only for the difference between each legacy item projection and its existing movement-ledger totals, allocated to the default location. It does not rewrite history. Stable migration idempotency keys and unique constraints prevent duplicate effects. The authored 42→43 migration test verifies items, lots, locations, stock/value, opening movements, foreign keys and document preservation; its Android execution remains a CI gate.

## Repository and API impact map

| File/contract | Action | Compatibility strategy |
|---|---|---|
| `LocalInventoryCommandEngine.kt` | Extend behind an Inventory command contract; location/lot projection atomics | Existing purchase/sales call sites adapt incrementally |
| `LocalOperationsRepository.kt` | Remove inventory workflow logic by delegation | Keep current `OperationsRepository` methods as a temporary facade |
| `LocalManagementControlRepository.kt` | Remove Inventory ownership by delegation/redirect | Non-inventory Management Control APIs remain unchanged |
| `ProcurementReceivingService.kt` | Supply location/lot/expiry receipt command | Procurement lifecycle and accounting contract remain intact |
| `LocalDailySalesRepository.kt` | Supply explicit location and FEFO consumption command | No POS redesign |
| `InventoryDao` / `StockMovementDao` | Add bounded search and projection-safe queries | Existing signatures retained unless demonstrably unsafe |
| New Inventory DAOs | Own balance, lot, count, waste, and transfer persistence | One DAO per coherent owner, no God DAO |
| `AppContainer` | Wire one Inventory repository and services | Composition root remains the only constructor owner |

## Presentation impact map

- Split `InventoryOperationsScreens.kt` into Inventory Home, item list/detail, movement ledger, expiry, count, waste, and transfer screens.
- Create a dedicated `InventoryViewModel` with explicit loading/saving/error/success state and intents.
- Add an `InventoryRoutes` group; `SabouApp` remains the composition root.
- Remove Location/Lot/FEFO/Transfer ownership from Management Control UI. A legacy navigation entry may redirect to Inventory during compatibility, but duplicate long-lived UI is not allowed.
- Item/movement search and filters use bounded database queries. Compose list keys remain stable ids.
- Persian-first RTL, tablet layout, progressive item editing, and actionable failures are retained.

## Regression surface

- Purchase posting/reversal and goods receipt accounting atomicity
- Daily sales cost posting and reversal
- Recipe quantity conversion and consumption
- Inventory period close/reopen guards
- Waste accounting journal balance and closed-period rollback
- SQLCipher startup, pre-migration recovery, backup validation, full migration chain
- Existing role compatibility and fail-safe legacy role behavior
- Sync outbox identities and replay semantics
- Management Control non-inventory workflows

## Incremental execution gates

Each implementation phase preserved reviewable commits, ran Kotlin syntax/static checks, reviewed `git diff --check`, and attempted the Gradle gate. Gradle could not execute because its distribution is unavailable in the environment, so build/test results are recorded as `NOT EXECUTED`; static verification is not reported as a build pass.

## Final impact result

| Area | Result |
|---|---|
| Entities/tables | Schema 43 item master, location/lot enrichment, balances, count sessions/lines, waste and transfer documents |
| DAO/query ownership | Dedicated bounded Inventory DAOs; no Compose DAO access |
| Domain contracts | Inventory command/read/master/lot/count/waste/transfer/replenishment/integrity services |
| Integration | Procurement and Sales/Recipe use the Inventory command boundary; Waste reuses Accounting posting |
| Presentation | Inventory workspace/routes and focused centers; old God screen removed |
| Management Control | Inventory-owned UI removed; compatibility redirect retained |
| Regression controls | Foundation script, typed failures/states, append-only guards, CAS projections, idempotency and tests |
| Remaining release blocker | Gradle/KSP/Room/Android tests and schema-43 export verification in CI |
