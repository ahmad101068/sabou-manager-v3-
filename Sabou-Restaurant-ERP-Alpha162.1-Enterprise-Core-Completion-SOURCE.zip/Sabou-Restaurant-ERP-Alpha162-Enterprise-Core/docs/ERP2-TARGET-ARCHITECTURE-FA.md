# معماری هدف Sabou Restaurant ERP 2.0

## تصمیم معماری

بازآرایی به‌صورت Strangler/Incremental انجام می‌شود. ماژول Android موجود تا زمانی که
baseline Build و Migrationها در CI سبز نشده‌اند به Multi-module Big Bang تبدیل نمی‌شود؛
اما ownership و dependency rule از همین نسخه در package و contractها enforce می‌شود.

## Boundaries و مالکیت

| Boundary | مالک داده و Rule | خروجی مجاز |
|---|---|---|
| `core` | پول، مقدار، ratio، شناسه، clock/error primitives | بدون وابستگی به Android/Room |
| `inventory` | item، ledger، lot، location، count، transfer، close | command/query contract؛ بدون posting مستقیم حساب |
| `procurement` | requisition، approval، PO، receiving، invoice match، return | event/command برای inventory/accounting/treasury |
| `sales` | sale/POS lifecycle، payment allocation، close/reversal | event/command برای inventory/accounting |
| `recipe` | recipe revision، yield و ingredient requirement | immutable effective revision |
| `production` | production batch، WIP، yield، waste | inventory commands؛ نه mutation مستقیم balance |
| `accounting` | chart، journal، posting، period، reversal | تنها مرز مجاز ساخت Journal |
| `treasury` | cash/bank movement، settlement، reconciliation | accounting posting request |
| `workforce` | employee، contract، attendance، leave، shift | payroll inputs |
| `payroll` | run، approval، allocation، payment، reversal | treasury/accounting requests |
| `assets` | acquisition، depreciation، disposal | accounting posting request |
| `analytics` | read models/KPI definitions/drill-down | بدون write عملیاتی |
| `security` | identity، role، permission، session، sensitive grant | authorization decision |
| `audit` | append-only audit event | query/export؛ بدون update/delete |
| `sync` | outbox، idempotency، conflict state | تا تکمیل protocol، fail-closed |

`ManagementControl` فقط یک read-oriented workspace برای exception/KPI/drill-down است و
مالک Entityهای عملیاتی جدید نخواهد بود.

## Dependency Rule

```text
UI -> ViewModel -> Application Command/Query -> Domain -> Port
                                               ^        |
                                               |        v
                                        Data Adapter <- Room/Transport
```

- Domain به Compose، Android، Room Entity یا DAO وابسته نیست.
- UI فقط state را render و intent را emit می‌کند.
- ViewModel transaction، محاسبه مالی یا SQL ندارد.
- Adapterهای Room، enum/value object را در persistence boundary map می‌کنند.
- Domainهای عملیاتی برای اثر مالی فقط `AccountingPostingPort` را صدا می‌زنند.
- balance حساب یا stock projection خارج از owner boundary قابل mutation نیست.

## Transaction Envelope

هر command حساس یک envelope دارد:

```text
commandId / idempotencyKey
correlationId
actorId
deviceId
businessTimestamp
locationId / branchId (در صورت ارتباط)
reason
payload
```

الگوی اجرای command:

1. validate envelope و payload
2. enforce permission و Separation of Duties
3. check idempotency؛ retry سازگار همان نتیجه قبلی را بازمی‌گرداند
4. شروع/پیوستن به Room transaction
5. enforce period/state/version guards
6. write owner-domain ledger/document
7. invoke inventory/accounting/treasury ports داخل همان transaction
8. write audit event و outbox؛ شکست هرکدام کل transaction را rollback می‌کند
9. commit و ارائه result type-safe

## Accounting State Machine

```text
DRAFT -> POSTED -> REVERSED_BY(new journal)
```

- header و lines در `DRAFT` قابل تکمیل هستند.
- transition به `POSTED` فقط پس از `Debit == Credit > 0` انجام می‌شود.
- `POSTED` در سطح DB immutable است.
- اصلاح با Journal جدید و reference به سند مبدأ انجام می‌شود.
- هیچ مسیر `POSTED -> DRAFT` یا delete وجود ندارد.

## Inventory Ledger و Projection

`stock_movements` ledger عملیاتی append-only است. `inventory_items.stockMicros` و
`inventoryValueRial` صرفاً projection سریع هستند، نه تاریخچه مستقل.

- هر تغییر projection و ledger در یک transaction داخلی owner boundary انجام می‌شود.
- command جدید بدون idempotency/correlation/actor/location پذیرفته نمی‌شود.
- update/delete ledger در DB ممنوع است؛ reversal یک movement جدید است.
- reconciliation query باید جمع ledger را با projection مقایسه کند.
- lot consumption، location و document reference زنجیره trace را کامل می‌کنند.

## Typed State و Persistence Mapping

- Permission، lifecycle status، movement/reference type، payment channel و audit action در
  Domain به‌صورت enum/sealed/value object هستند.
- مقدار ذخیره‌شده فقط در adapter با `storedValue` map می‌شود.
- مقدار legacy ناشناخته به state محدود/unknown map می‌شود و هرگز permission یا transition
  جدید دریافت نمی‌کند.
- ستون‌های legacy `REAL` در Performance فقط برای migration compatibility باقی می‌مانند؛
  مقدار canonical جدید `Long micros` است.

## Error Contract

Business failure یک `BusinessError` type-safe است؛ نمونه‌ها:

- `InsufficientStock`
- `ClosedAccountingPeriod`
- `DuplicateDocument`
- `InvalidRecipe`
- `PermissionDenied`
- `ApprovalRequired`
- `SeparationOfDutiesViolation`
- `SupplierInactive`
- `LotExpired`
- `IdempotencyConflict`
- `ConcurrentModification`

Data adapter خطاهای شناخته‌شده constraint/trigger را به این contract map می‌کند. UI mapping
فارسی مستقل است و technical failure یا stack trace به کاربر نمایش داده نمی‌شود.

## Authorization و Separation of Duties

- Permission در UI فقط برای visibility است.
- command boundary همیشه session فعال و Permission type-safe را enforce می‌کند.
- role ناشناخته fail-closed است.
- درخواست خرید جدید توسط requester قابل approve نیست.
- approver سطح دوم با requester و approver سطح اول متفاوت است.
- Payroll creator با final approver متفاوت است.
- sensitive grant به `(actorId, action)` متصل و یک‌بارمصرف باقی می‌ماند.

## Migration Policy

- فقط migration ترتیبی و ثبت‌شده؛ destructive fallback ممنوع.
- triggerها در migration و callback نصب تازه یکسان نصب می‌شوند.
- backfill legacy قابل تشخیص است و blank/sentinel برای command جدید پذیرفته نمی‌شود.
- Full Migration از Schema 1 تا current و edge test هر نسخه Gate است.

## Performance و Query Policy

- فهرست‌های عملیاتی query/search/sort را در DB انجام می‌دهند.
- queryهای بدون limit برای historyهای بزرگ در incrementهای بعدی به keyset pagination تبدیل
  می‌شوند.
- Stable Compose keys اجباری هستند.
- dashboard فقط read model تصمیم‌محور با status/trend/context/drill-down/action ارائه می‌کند.

## مسیر تفکیک ساختاری

1. Split DAO file بدون تغییر signature.
2. Split Database definition/migration/guards/seed.
3. استخراج permission/error/audit/inventory contracts.
4. حفظ facadeهای فعلی برای UI و انتقال implementation به delegateهای owner-domain.
5. پس از CI سبز، استخراج ماژول‌های pure Kotlin `:core` و `:domain:*`.
6. در مرحله بعد، feature presentation modules و navigation graph type-safe.

## اصول عدم ادعا

وجود boundary یا مدل به‌معنی تکمیل Feature نیست. POS/KDS، production، treasury workflow،
sync backend و multi-branch فقط وقتی Done هستند که Domain/DB/Migration/Authorization/Audit/
UI/Failure tests و Build gate کامل باشند.
