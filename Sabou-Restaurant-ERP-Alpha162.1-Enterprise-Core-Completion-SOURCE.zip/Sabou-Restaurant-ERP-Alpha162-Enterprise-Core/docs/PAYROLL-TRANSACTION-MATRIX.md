# Payroll Transaction Matrix

همه workflowهای زیر در application boundary مجوز را enforce می‌کنند. `Atomic` به transaction فعلی Room/SQLite اشاره دارد. Treasury adapter فعلی local و transaction-compatible است؛ جایگزینی آن با provider remote باید از outbox/coordinator استفاده کند.

| Workflow | Tables touched | Accounting impact | Treasury impact | Audit impact | Atomic? | Idempotent? | Authorization? | Failure handling |
|---|---|---|---|---|---|---|---|---|
| Payroll calculate | read: employees, contract versions, policies, attendance events/corrections/legacy summaries, leaves, adjustments, advances, old payslips; write: payslips, snapshots, components, exceptions, adjustment consumption, batch/period, receipts, audit | None | None | `CALCULATE` batch + receipt correlation | Yes; result either calculated documents or explicit blocking draft exceptions | Yes; command receipt + payload hash + unique revision | `PAYROLL_CALCULATE` | typed exception/CAS/unique violation rolls back; blocking input errors persist only as controlled exception outcome, never accounting side effect |
| Payroll review | batch, period, approval events, receipts, audit | None | None | reviewer, reason, from/to | Yes | Yes | `PAYROLL_REVIEW` | invalid state/closed period/CAS rolls back |
| Payroll approve | batch, period, payslips, snapshots read, components read, advance allocations, advances projection, journal tables through AccountingPostingService, approval events, receipts, audit | expense/liability accrual per payslip; semantic account mapping | None | final approver, snapshot hash, reason, correlation | Yes with current local accounting boundary | Yes; receipt + accounting idempotency + CAS | `PAYROLL_APPROVE`; creator/calculator != approver | incomplete/hash mismatch/exceptions/SoD/accounting/CAS causes rollback of allocation, journal, status and audit |
| Payroll payment | payslip, payroll payments, batch projection, journal tables through TreasuryService, approval events, receipts, audit | Payroll Payable settlement | execute treasury transaction against typed account/channel | payment reference, actor, business date, correlation | Yes with local Treasury adapter; coordinator-safe contract required for remote provider | Yes; receipt + unique payment key + treasury command ID | `PAYROLL_PAY` | overpayment/duplicate/closed period/treasury failure/CAS rolls back ledger/projection/audit |
| Payment reversal | original payment status, compensating payment row, payslip/batch projection, treasury/accounting reversal, approval events, receipts, audit | compensating settlement reversal | compensating Treasury reversal; original transaction linked | reason, actor, before/after, correlation | Yes with local adapter | Yes | `PAYROLL_REVERSE` | original must be posted and unreversed; closed period/missing journal/provider failure rolls back |
| Payslip reversal | payslip/batch, accounting reversal, advance allocations, advance projection, approval events, receipts, audit | reverse original accrual with linked journal | None; any posted payment must be reversed first | reason, business date, actor, revision reference | Yes | Yes | `PAYROLL_REVERSE` | open payment, closed period, missing accrual, CAS or accounting failure aborts all effects |
| New payslip revision | calculate path creates revision N+1 with `replacesPayslipId` | None until approval | None | calculate/review/approve history on new document | Yes per command | Yes; employee+period+revision unique + receipt | calculate/review/approve permissions | predecessor is never edited; replacement validation failure leaves original unchanged |
| Advance allocation | allocation row, employee advance settled projection, approval receipt/audit (inside approval) | credit Employee Advance Receivable offset in accrual | None | allocation actor/reason/correlation | Yes inside approve | Yes; deterministic key + unique index | `PAYROLL_APPROVE` via approval workflow | amount cannot exceed outstanding; any allocation/journal failure rolls back all batch approval effects |
| Advance allocation reversal | allocation status, advance settled projection, payslip reversal audit | part of accrual reversal | None | before/after and reason | Yes inside payslip reversal | Yes via reversal receipt/CAS | `PAYROLL_REVERSE` | only ALLOCATED can reverse; underflow/CAS rolls back |
| Attendance create | daily projection, real attendance events, audit | None | None | actor, source, date, reason, correlation | Yes | Yes; event key/global ID | `PERSONNEL` | employment/leave/payroll lock/duplicate failure rolls back event and projection |
| Attendance correction | correction row, manual event, optionally daily projection, audit | None | None | required reason + before/after + requester/approver/timestamps | Yes | Yes; correction/event command keys | `ATTENDANCE_CORRECT`; optional approver separation | locked payroll day/invalid status/CAS leaves prior projection unchanged |
| Leave submit/review | leave row, leave ledger, daily compatibility projection, audit | None until Payroll consumes input | None | request/review actor, reason, before/after, correlation | Yes | Yes; leave/global/ledger keys | `PERSONNEL`; approval `LEAVE_APPROVE` + SoD | overlap, attendance conflict, locked payroll, insufficient balance rolls back workflow |
| Contract create/revision | contract version, audit | None | None | creator, predecessor, reason, effective date | Yes | contract number unique; version relation stable | `PERSONNEL` | overlap/input failure does not mutate predecessor |
| Contract approval | successor status, predecessor supersede, audit | None | None | independent approver and before/after | Yes | replay of already-approved is no-op; CAS status | `CONTRACT_APPROVE` + SoD | conflict/CAS causes both predecessor and successor changes to roll back |
| Period close/reopen | period, receipt, audit | None directly | None | actor/reason/status/correlation | Yes | Yes | `PAYROLL_APPROVE` | unsettled batch or invalid transition rejects without state change |
| Manual adjustment submit/approve | adjustment, receipts, audit; later consume link | None until payslip approval | None | reason, optional attachment metadata, creator/approver | Yes | Yes | create `PAYROLL_CREATE`; approve `PAYROLL_REVIEW` + SoD | missing reason, self-approval, duplicate payload or invalid type rolls back |

## Atomicity notes

### Calculate

Calculation و posting جدا هستند. یک batch تنها زمانی `CALCULATED` می‌شود که payslip/snapshot/components مورد انتظار کامل باشند. Input failureهای business به Exception Center تبدیل می‌شوند؛ financial state ایجاد نمی‌شود.

### Approval

Approval ترتیب validate -> freeze evidence -> allocate advances -> post accrual -> transition -> audit/receipt را در یک transaction اجرا می‌کند. snapshot trigger و component/payslip guards تغییر بعد از approval را رد می‌کنند.

### Payment

Payment amount باید در remaining جا شود. Treasury result قبل از append payment به همان transaction local برمی‌گردد. paid/remaining از کل ledger محاسبه می‌شود و projection equation در trigger کنترل می‌شود.

### Remote Treasury evolution

اگر Treasury در آینده remote شود، database transaction نمی‌تواند provider خارجی را rollback کند. قرارداد مناسب:

1. persist payment intent/outbox با idempotency key؛
2. execute provider؛
3. persist provider receipt؛
4. resume-safe finalize؛
5. compensating reversal برای failure پس از provider success.

این Task provider remote یا Treasury 2.0 کامل ایجاد نمی‌کند.
