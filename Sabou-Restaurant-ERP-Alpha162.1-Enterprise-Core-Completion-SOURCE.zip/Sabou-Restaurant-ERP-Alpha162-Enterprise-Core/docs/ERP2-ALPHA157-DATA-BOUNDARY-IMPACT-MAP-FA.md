# Impact Map — Alpha157 Data Boundary Split

تاریخ: 2026-08-09

## هدف

کاهش ریسک `Daos.kt` به‌عنوان God File، بدون تغییر رفتار، Query، Entity، Schema یا قرارداد
`AppDatabase`. این Increment فقط ownership فایل‌ها را شفاف می‌کند تا تغییرهای بعدی هر Domain
قابل Review و تست مستقل باشند.

## وضعیت پیش از تغییر

- `Daos.kt`: ۱٬۷۱۲ خط و شامل ۱۲ DAO متعلق به چند Domain نامرتبط
- `AppDatabase.kt`: ۱٬۷۸۶ خط؛ خارج از محدوده تغییر رفتاری این Increment
- تمام DAOها در package یکسان `ir.sabou.inventory.data.db` قرار دارند.
- accessorهای `AppDatabase` به نام type وابسته‌اند، نه نام فایل؛ بنابراین Split نباید API را
  تغییر دهد.

## فایل‌های هدف

| Owner Domain | فایل جدید | قراردادهای منتقل‌شونده |
|---|---|---|
| suppliers | `SupplierDao.kt` | `SupplierDao` |
| inventory | `InventoryDao.kt` | `InventoryDao` |
| purchasing | `PurchaseDao.kt` | `PurchaseDao` و read rowهای خرید |
| procurement | `ProcurementDao.kt` | `ProcurementDao` و read rowهای تدارکات |
| accounting | `AccountingDao.kt` | `AccountingDao` و read rowهای دفتر کل |
| workforce/payroll | `PersonnelDao.kt` | `PersonnelDao` و `PayrollListRow` |
| recipe | `RecipeDao.kt` | `RecipeDao` و read rowهای رسپی |
| inventory control | `InventoryControlDao.kt` | Count/Closure/Waste DAO |
| audit | `AuditLogDao.kt` | `AuditLogDao` |
| security | `SecurityDao.kt` | `SecurityDao` |
| assets | `AssetDao.kt` | `AssetDao` و read rowهای دارایی |
| alerts | `AlertDao.kt` | `AlertDao` و alert read rows |

پس از parity check، فایل `Daos.kt` حذف می‌شود.

## تغییرهای صریحاً خارج از Scope

- هیچ Entity، column، index، trigger یا Migration تغییر نمی‌کند.
- Schema روی نسخه `42` باقی می‌ماند.
- نام، visibility، annotation، SQL و signature هیچ DAO تغییر نمی‌کند.
- Repository، ViewModel، UI و Navigation تغییر رفتاری ندارند.
- `AppDatabase` accessorها تغییر نمی‌کنند.

## Regression Surface

1. کشف DAOها توسط Kotlin/KSP پس از انتقال فایل
2. importهای Room و `Flow`
3. duplicate یا missing declaration هنگام حذف فایل قدیمی
4. query parity و annotation parity
5. reference resolution تمام Repositoryها و testها

## کنترل پذیرش

- hash محتوای declarationها پیش/پس از Split پس از حذف package/import/whitespace برابر باشد.
- هر type دقیقاً یک‌بار در package تعریف شود.
- `Daos.kt` دیگر وجود نداشته باشد.
- Schema version و migration registry بدون diff بمانند.
- static foundation check، `git diff --check` و parse نحوی فایل‌های تغییرکرده موفق باشد.
- Gradle/KSP در CI اجرا شود؛ این Split بدون compile واقعی Production-ready اعلام نمی‌شود.
