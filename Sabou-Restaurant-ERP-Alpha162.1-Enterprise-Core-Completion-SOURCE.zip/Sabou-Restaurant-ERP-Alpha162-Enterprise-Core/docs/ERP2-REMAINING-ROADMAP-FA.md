# Roadmap باقی‌مانده Restaurant ERP 2.0

این Roadmap فاصله بعد از alpha157 را نشان می‌دهد. ترتیب بر اساس ریسک داده و dependency است،
نه تعداد Screen.

## P0 — Merge Gate همین Increment

1. اجرای کامل CI و رفع هر خطای Compile/KSP/Room/Lint.
2. تولید و review فایل Schema 42.
3. Migration یک کپی واقعی Schema 41 با SQLCipher و `foreign_key_check`.
4. تست هم‌زمانی/Retry روی دستگاه و آزمون Restore رمزگذاری‌شده.
5. reconciliation گزارش جمع Ledger با Projection و مانده حساب‌ها.

## P1 — شکستن God Objectها بدون تغییر رفتار

- `AppDatabase.kt`: migration registry، migration ranges، seed و guards به فایل‌های مستقل.
- **انجام‌شده در alpha157:** فایل `Daos.kt` به DAOهای domain-owned تفکیک شد؛ SQL و API ثابت ماند.
- `LocalProcurementRepository`: facade روی Requisition، Approval، Order، Receiving، Matching، Return.
- `OperationsScreens.kt` و `SabouApp.kt`: route contract، workspace و dialogهای feature-owned.

هر PR فقط یک split مکانیکی + tests و Build سبز؛ تغییر business behavior هم‌زمان ممنوع.

## P1 — تکمیل Integrity

- Inventory reconciliation job و گزارش actionable مغایرت.
- lot valuation policy صریح و snapshot بهای تمام‌شده.
- idempotency command table یا result envelope مشترک برای همه workflowهای حساس.
- actor/location/global ID برای بقیه اسناد فروش، خرید، دارایی و خزانه.
- typed lifecycle برای status/channelهای باقی‌مانده در persistence boundary.
- audit diff ساخت‌یافته و policy نگهداشت/Export امضاشده.

## P2 — Procurement و Treasury واقعی

- تفکیک Repositoryهای procurement پشت facade.
- invoice matching variance policy، partial receipt و credit note end-to-end.
- Treasury owner domain برای cash/bank account، receipt/payment، approval و reconciliation.
- creator/purchaser/payment approver SoD با threshold قابل تنظیم.
- payment idempotency و accounting posting داخل Transaction واحد.

## P2 — POS / Sales Operating Flow

- order lifecycle، table/service channel، modifier، discount authorization و payment allocation.
- shift/open-close، cash drawer و reconciliation.
- offline command IDs و duplicate-safe posting.
- sale + inventory consumption + COGS + payment + journal + audit اتمیک.
- Persian-first Tablet/Landscape و Compose UI tests.

## P2 — Production و Food Cost

- production batch، semi-finished item، yield، WIP، variance و waste.
- recipe revision مؤثر و snapshot مصرف واقعی.
- FEFO lot issue و backflush policy قابل ممیزی.
- standard/actual cost و drill-down تا movement/receipt/batch.

## P3 — Workforce / Payroll / Assets

- boundary مستقل workforce و payroll، payroll approval workflow چندسطحی.
- attendance/leave/overtime policy versioning.
- payroll liability سپس Treasury settlement؛ پرداخت مستقیم از Payroll حذف شود.
- depreciation batch preview/approve/post/reverse و asset subledger reconciliation.

## P3 — Analytics و Management Control

- read modelهای paged و queryهای DB-side برای ۱۰هزار+ رکورد.
- KPI با definition، status، trend، context، drill-down و action.
- ManagementControl فقط consumer باشد و Entity عملیاتی جدید مالک نشود.

## P4 — Sync و Multi-branch

- branch/location global identity، server acknowledgement و deterministic command replay.
- conflict policy owner-domain؛ Last Write Wins برای inventory/accounting/payment ممنوع.
- encrypted pull/apply transaction، outbox state machine و reconciliation.
- observability با correlationId بدون log داده حساس.

تا تکمیل این مرحله Sync باید fail-closed بماند.

## Definition of Done هر Vertical Slice

Domain rule، Entity/constraint/index، Migration، authorization/SoD، audit، transaction،
idempotency، Persian workflow، failure tests، migration/integration tests، Build/Lint و سند
کوتاه باید هم‌زمان کامل باشند. نمایش یک Screen به‌تنهایی Done نیست.
