# Sabou ERP 2.0 — Typed State Inventory

The database intentionally continues to store legacy-compatible `TEXT`. Wave 1 changes domain/read
models and maps at the persistence boundary. No migration is required. Unknown values either map to
an explicit `LEGACY_UNKNOWN` state for read-only legacy display, or raise `UnknownStoredValue` where
a fallback would change financial behavior.

## Wave 1 implemented

| Field / source | Known persisted values | Domain owner | Risk before | Domain type / unknown strategy | Migration impact |
|---|---|---|---|---|---|
| `purchases.paymentMethod` | null, `نقدی`, `کارتخوان`, `حواله` | Procurement / Treasury | unknown value silently became payable | `PurchasePaymentMethod`; unknown → typed failure | None |
| settlement query `paymentMethod` | `نقدی`, `کارتخوان`, `حواله` | Treasury | raw String reached UI/domain | `SettlementPaymentMethod`; unknown → typed failure | None |
| payroll/advance `paymentMethod` | `CASH`, `BANK` | Workforce / Treasury | String comparisons selected ledger account | `TreasuryChannel` through legacy adapter; unsupported channel rejected | None |
| stock movement `movementType` | purchase, receipt, return, sales, count, waste, transfer values | Inventory | UI filters and labels depended on raw literals | `InventoryMovementType`; known `SALE_CONSUMPTION` represented as explicit legacy state; other unknown → `LEGACY_UNKNOWN` | None |
| stock movement `referenceType` | purchase, receipt, return, sales, count, waste, transfer | Inventory | raw document ownership | `InventoryReferenceType`; unknown → `LEGACY_UNKNOWN` | None |
| accounting period control `status` | `CLOSED`, `REOPENED` | Accounting | String comparison in UI/read model | `AccountingPeriodStatus`; unknown → `LEGACY_UNKNOWN` | None |
| cash reconciliation `status` | `MATCHED`, `VARIANCE` | Treasury | String rendering and branching | `CashReconciliationStatus`; unknown → `LEGACY_UNKNOWN` | None |
| treasury command `channel/direction/kind/account kind` | new domain concepts | Treasury | no common vocabulary | `TreasuryChannel`, `TreasuryDirection`, `TreasuryTransactionKind`, `TreasuryAccountKind` | None; foundation only |

## Inventory 2.0 typed wave implemented in Alpha159

| Field | Domain type | Persisted values / unknown strategy | Migration impact |
|---|---|---|---|
| `inventory_items.itemType` | `InventoryItemType` | ingredient, packaging, consumable, prepared item, finished good; unknown rejected | 42→43 column + conservative backfill |
| `inventory_items.storageCondition` | `InventoryStorageCondition` | ambient, dry, chilled, frozen, other; unknown rejected | 42→43 column |
| `storage_locations.kind` | `InventoryLocationType` | warehouse, cold storage, freezer, kitchen, prep, bar, other; explicit legacy normalization | 42→43 normalization |
| `inventory_lots.status` | `InventoryLotStatus` | active, quarantined, expired, depleted, blocked; unknown is non-allocatable | 42→43 column/backfill |
| movement type/reference/reason | `InventoryMovementType`, `InventoryReferenceType`, `InventoryReasonCode` | full receipt/return/consumption/transfer/count/opening/reversal vocabulary; unknown fail-safe | String persistence retained |
| count session/line/scope | `InventoryCountStatus`, `InventoryCountLineStatus`, `InventoryCountScope` | explicit workflow states and transition policy | new 42→43 tables |
| waste reason/status | `WasteReason`, `WasteStatus` | typed reason and approval/post lifecycle; legacy reason preserved as detail and `LEGACY_UNKNOWN` code | waste table rebuild |
| transfer status | `InventoryTransferStatus` | draft/requested/approved/issued/in-transit/received/completed/cancelled | transfer table rebuild |
| replenishment risk/reason/policy | typed Inventory replenishment enums/value models | derived only; no raw stored business state | no schema state column |

State-changing commands reject `LEGACY_UNKNOWN`. Read models may display an explicit legacy state but
never interpret it as active, approved, available or otherwise permissive.

## Existing typed states verified and preserved

| Field | Type | Stored mapping |
|---|---|---|
| Journal status | `JournalStatus` | `DRAFT`, `POSTED`, explicit legacy unknown |
| Purchase payment status | `PurchasePaymentStatus` | `UNPAID`, `PARTIAL`, `PAID`, `REVERSED`, legacy unknown |
| Requisition status | `RequisitionStatus` | draft/submitted/approval/rejection lifecycle |
| Purchase-order status | `PurchaseOrderStatus` | open/partial/received/closed lifecycle |
| Three-way match | `ThreeWayMatchStatus` | matched/quantity variance/price variance |
| Inventory period read status | `InventoryPeriodStatus` | closed/reopened/legacy state |
| Payroll status | `PayrollStatus` | pending/posted/reversed lifecycle |
| Permission and role | `Permission`, typed `UserRole` mapping | explicit stored role mapping |
| Audit action/entity type | `AuditAction`, `AuditEntityType` value objects | validated upper-snake-case |

## Remaining String-state inventory

| Field / file family | Known values observed | Target owner | Risk | Recommended type | Migration impact |
|---|---|---|---|---|---|
| employee/contract/advance status | active/inactive, open/settled | Workforce | medium; workflow branching remains textual | separate lifecycle enums | none if adapter-only |
| attendance status | present/absent/leave variants | Workforce | medium; payroll rule input | `AttendanceStatus` | none if adapter-only |
| leave status | requested/approved/rejected/cancelled | Workforce | high for approval transitions | `LeaveStatus` with transition policy | none if adapter-only |
| performance goal/review status | draft/active/completed variants | Workforce | medium | goal/review lifecycle enums | none if adapter-only |
| shift swap status | pending/approved/rejected | Workforce | high for SoD/concurrency | `ShiftSwapStatus` | none if adapter-only |
| supplier credit status | `OPEN`, `PARTIAL`, `APPLIED` | Procurement / Treasury | high for settlement | `SupplierCreditStatus` | none if adapter-only |
| budget commitment status | `COMMITTED`, `CONSUMED`, release states | Analytics / Procurement | high for double commitment | `BudgetCommitmentStatus` | none if adapter-only |
| sales-day closure record status | `CLOSED`, `REOPENED` | Sales | high for replay/period rules | `SalesDayStatus` in all read models | none if adapter-only |
| asset status | active/recognized/disposed | Assets | high for depreciation/disposal | `AssetStatus` | none if adapter-only |
| audit list action/entity type | validated values persisted, legacy read model String | Audit | low for display; medium for filtering | expose existing value objects in read model | none |
| journal/account `sourceType`/account `type` | open set of source types; asset/liability/etc. | Accounting | source type is extensible, account type closed | value object for source; `AccountType` enum | none if adapter-only |

## Conversion rule

Future waves must convert one owner workflow at a time. Persistence remains String until a schema
change has independent business value. Mapping occurs in repositories/DAO adapters, never Compose.
An unrecognized value must remain visible as unknown or fail with structured context; it must never
silently become cash, bank, payable, open, approved or another financially meaningful default.
