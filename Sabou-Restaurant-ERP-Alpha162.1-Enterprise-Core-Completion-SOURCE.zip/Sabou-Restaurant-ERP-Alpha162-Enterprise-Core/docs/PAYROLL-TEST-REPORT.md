# HR / Payroll 2.0 Test Report

تاریخ اجرا: 2026-08-09  
محیط: Linux host، JDK 17، Gradle 8.13، Android SDK 36

## Summary

| Gate | Result |
|---|---|
| `:app:compileDebugKotlin` | PASS |
| `:app:testDebugUnitTest` | PASS — 234 tests, 0 failure, 0 skipped |
| HR/Payroll host SQL migration verifier | PASS — 186 production statements, 49 checks, deterministic |
| `:app:assembleDebugAndroidTest` | PASS — instrumentation APK ساخته شد |
| `:app:assembleDebug` | PASS |
| `scripts/verify-foundation.sh` | PASS |
| `:app:connectedDebugAndroidTest` | NOT EXECUTED — emulator/device در محیط موجود نیست |

## Tests added

### Employee / Contract

`EmployeeContractHistoryV2Test`

- effective contract exactly-one resolution؛
- future version؛
- typed missing/conflict؛
- open-ended/boundary overlap؛
- employment status transitions و termination rules.

Migration test/verifier همچنین uniqueness/backfill employee code و contract overlap DB guard را کنترل می‌کند.

### Attendance

`AttendanceEventAggregatorV2Test`

- clock in/out aggregation؛
- break deduction؛
- late/overtime؛
- missing out؛
- duplicate in؛
- unclosed break؛
- negative duration؛
- excessive duration؛
- outside employment period.

Correction path در implementation before/after/reason/actor/approval/audit و payroll-lock enforcement دارد و Room/KSP compile شده است.

### Leave

`LeaveBalanceV2Test`

- granted/used/pending/remaining؛
- no fake balance؛
- restore بیش از usage رد می‌شود.

`PayrollCalculationServiceV2Test` paid leave بدون absence deduction و unpaid leave با component مستقل را کنترل می‌کند.

### Payroll calculation / snapshot / accounting

`PayrollCalculationServiceV2Test`

- base salary و proration input؛
- overtime minutes/rate/multiplier؛
- absence/late/unpaid leave؛
- paid leave؛
- bonus/allowance/manual components؛
- insurance/tax/advance؛
- HALF_UP rounding؛
- determinism؛
- negative net؛
- Long/Money overflow boundary؛
- historical result unchanged after new salary/policy snapshot؛
- balanced semantic accrual.

### Lifecycle / approval

`PayrollLifecycleV2Test`

- calculation/approval/payment separation؛
- invalid direct transition rejection؛
- reversal terminal rules؛
- closed period و explicit reopen.

`PermissionMappingTest` همچنین payroll view/calculate/approve/reverse/pay separation برای Cashier/Manager/Accountant/Owner را کنترل می‌کند. SoD عمومی در `SegregationOfDutiesTest` و command services enforce شده است.

### Payment

`PayrollPaymentLedgerV2Test`

- full و zero-net settlement؛
- partial و multiple partial payments؛
- remaining amount؛
- compensating reversal؛
- overpayment؛
- duplicate/orphan reversal.

### Migration

`HrPayrollMigration43To44Test` نوشته و در Android test APK با موفقیت compile شد. این تست روی device موارد زیر را اجرا می‌کند:

- employees/contracts/attendance/leaves/advances/payroll preservation؛
- legacy period/batch/payslip؛
- no fake events/components/payments؛
- incomplete legacy snapshot؛
- FKs/indexes؛
- snapshot/no-delete/overlap triggers.

به علت نبود emulator، اجرای instrumentation آن `NOT EXECUTED` است.

برای پوشش executable مستقل از device، `scripts/verify-hr-payroll-migration.py` SQL واقعی Kotlin migration و 34 guard را از سورس استخراج و روی دو دیتابیس schema 43 مستقل اجرا کرد:

```text
HR_PAYROLL_SQL_MIGRATION_PASS statements=186 checks=49 deterministic=1
```

## Existing regression suite

کل 234 unit test شامل Foundation، authorization، accounting، inventory lot/balance/count/waste/transfer/replenishment/read models، procurement، sales، assets، sync و UI utilities است. هیچ تستی حذف یا skip نشد.

در جریان اجرای واقعی، چهار ایراد baseline نیز آشکار و اصلاح شد:

- deficit day باید روز ورود به deficit باشد؛
- no-approval waste policy نباید safe-money validation بی‌ربط اجرا کند؛
- sync retry gate محافظه‌کارانه و deterministic شد؛
- یک assertion timestamp از Int به Long اصلاح شد.

Android instrumentation baseline نیز برای APIهای current (`PostedJournal.id`, `SyncDao.pending(now, limit)`, explicit database close و import assertion) compile-repaired شد؛ تستی حذف نشد.

## Build artifacts

- Debug app APK: `app/build/outputs/apk/debug/app-debug.apk`
- Debug Android test APK: `app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk`
- Room schema: `app/schemas/ir.sabou.inventory.data.db.AppDatabase/44.json`

## Residual verification risk

تنها gate اجرا‌نشده، runtime instrumentation روی emulator/device است. APK تست ساخته شده و host migration SQL به‌طور کامل اجرا شده است، اما رفتار Android framework SQLite/Room روی device باید در CI متصل اجرا شود.
