# Payroll Migration Report — Schema 43 to 44

## Scope

Migration: `MIGRATION_43_44`  
Source: Alpha159 Inventory 2.0 schema 43  
Target: HR/Payroll 2.0 schema 44

Migration destructive نیست و chain کامل 1 تا 44 حفظ شده است. `fallbackToDestructiveMigration` وجود ندارد.

## Changes to existing tables

### employees

فیلدهای first/last/display name، department، location، manager، email، termination، notes و creator/updater اضافه می‌شوند. برای legacy:

- display name از name؛
- department برابر `UNASSIGNED`؛
- employee code خالی برابر `EMP-%06d`؛
- status قدیمی `INACTIVE` به `ARCHIVED` و سایر valueهای نامعتبر به `ARCHIVED` نگاشت می‌شود؛
- sensitive values به private profile منتقل و ستون‌های عمومی پاک می‌شوند.

### leaves

global ID، idempotency key، actor IDs و correlation اضافه می‌شوند. `PENDING` به typed `SUBMITTED` نگاشت می‌شود؛ fact مرخصی، بازه و مقدار تغییر نمی‌کند.

### payroll_policies

version، multiplier/insurance/tax basis points، status، actor و correlation اضافه می‌شوند. پارامترهای ناشناخته از legacy با default explicit نگه داشته می‌شوند؛ policy تاریخی fake version نمی‌شود.

## New tables

1. `employee_private_profiles`
2. `employment_assignments`
3. `employment_contract_versions`
4. `attendance_events`
5. `attendance_corrections`
6. `leave_ledger_entries`
7. `payroll_periods`
8. `payroll_batches`
9. `payroll_payslips`
10. `payroll_snapshots`
11. `payroll_components`
12. `payroll_manual_adjustments`
13. `payroll_approval_events`
14. `payroll_payments`
15. `payroll_advance_allocations_v2`
16. `payroll_exceptions`
17. `hr_payroll_migration_anomalies`
18. `hr_payroll_command_receipts`

## Employee migration

- IDs و current fields حفظ می‌شوند؛
- private profile با همان employee ID ساخته می‌شود؛
- bank/card کامل ذخیره مجدد نمی‌شود؛ فقط last four منتقل می‌شود؛
- assignment اولیه فقط از current job/department/branch و hire date معلوم ساخته می‌شود؛
- employee code deterministic است و اجرای تکراری migration داده متفاوت تولید نمی‌کند.

## Contract migration

هر `employee_contracts` legacy به یک `employment_contract_versions` با:

- `contractNumber = LEG-CTR-%08d`؛
- `versionNo = 1`؛
- `source = LEGACY_MIGRATION`؛
- effective dates و salary/minutes واقعی source؛
- `status = LEGACY`؛
- job/branch snapshot موجود و department `UNASSIGNED`؛

تبدیل می‌شود.

اگر قراردادها overlap داشته باشند، migration آنها را کوتاه، حذف یا merge نمی‌کند. `OVERLAPPING_LEGACY_CONTRACT` در anomaly table ثبت می‌شود. Resolver/Exception Center conflict را تا تصمیم انسانی blocking نگه می‌دارد.

## Attendance migration

جدول daily `attendance` بدون تغییر fact باقی می‌ماند. `attendance_events` خالی است مگر پس از migration رویداد واقعی ثبت شود. از check-in/check-out aggregate، timestamp یا event ساختگی تولید نمی‌شود.

## Leave migration

درخواست‌های legacy حفظ می‌شوند. Migration entitlement یا balance ساختگی از `employees.leaveBalanceMicros` تولید نمی‌کند. ledger جدید فقط برای grant/use واقعی پس از migration یا workflow قابل اثبات نوشته می‌شود.

## Payroll migration

برای هر `(periodYear, periodMonth)` موجود:

- یک period با key `LEGACY-YYYY-MM`؛
- یک batch با document `LEG-PAY-YYYY-MM` و source legacy؛
- برای هر payroll run یک payslip با همان employee، totals، revision و legacy row link؛
- یک incomplete snapshot با totals قابل اثبات؛

ساخته می‌شود.

### حفظ facts

- base/overtime/bonus stored values فقط برای gross total موجود استفاده می‌شوند؛
- net، revision، status و journal references حفظ می‌شوند؛
- approved/paid semantics قدیمی marker خود را حفظ می‌کنند؛
- original `payroll_runs` حذف یا overwrite نمی‌شود.

### عدم جعل اطلاعات

- `payroll_components`: برای legacy صفر row؛
- `payroll_payments`: برای legacy صفر row؛
- contract ID/version: unknown؛
- attendance/leave minutes: unknown؛
- policy version و calculation version: unknown؛
- `componentDetailComplete=false` و `detailComplete=false`؛
- `LEGACY_PAYSLIP_INCOMPLETE` anomaly ثبت می‌شود.

اگر net legacy از gross inputs ذخیره‌شده بیشتر باشد، total تغییر نمی‌کند و `LEGACY_NET_EXCEEDS_GROSS` ثبت می‌شود.

## Advances

`employee_advances` و settled amount حفظ می‌شوند. Allocation historical فاقد detail به allocation v2 جعل نمی‌شود. allocation جدید فقط هنگام approval native ساخته می‌شود.

## Constraints and indexes

Migration unique/index/FKهای زیر را اضافه یا تکمیل می‌کند:

- employee code/name/display/phone/job/department/location؛
- contract number و employee/effective range/status؛
- attendance employee/date/type؛
- leave employee/status/date؛
- unique period key و batch document/idempotency؛
- unique employee/period/revision؛
- component source و payslip/direction؛
- payment idempotency/reversal/payslip/status؛
- advance employee/status و allocation key؛
- command receipt key و correlation.

Room schema export: `app/schemas/ir.sabou.inventory.data.db.AppDatabase/44.json`.

## Guards

پس از data copy، 34 guard trigger نصب می‌شود. همان guardها در fresh database و factory reset callback نیز نصب می‌شوند. Guardها snapshot/component/payslip/payment/allocation/approval/receipt history را append-only یا controlled-transition نگه می‌دارند.

## Verification

مهاجرت با سه سطح بررسی شده است:

1. Room/KSP schema generation و compile — PASS؛
2. host SQLite execution روی schema 43 representative، اجرای تمام migration/guard statementها، FK/index/immutability/idempotency checks — PASS؛
3. `HrPayrollMigration43To44Test` Android APK compile — PASS؛ اجرای device در این محیط به علت نبود emulator: NOT EXECUTED.

Host validation موارد زیر را کنترل کرده است:

- employee/private/assignment/contract preservation؛
- anomaly قرارداد overlap؛
- attendance preservation و zero fake event؛
- leave/advance preservation؛
- deterministic legacy period/batch/payslip؛
- incomplete marker و zero fake component/payment؛
- foreign key check؛
- snapshot immutability، payslip no-delete و overlap guard؛
- اجرای دوم بدون duplicate logical legacy documents.

## Rollback / recovery

Migration در transaction Room اجرا می‌شود. failure قبل از commit نسخه 43 را سالم نگه می‌دارد. anomaly business باعث abort migration نمی‌شود؛ فقط anomaly row ایجاد می‌کند. SQL/schema failure migration را fail می‌کند و هیچ destructive fallback مجاز نیست.
