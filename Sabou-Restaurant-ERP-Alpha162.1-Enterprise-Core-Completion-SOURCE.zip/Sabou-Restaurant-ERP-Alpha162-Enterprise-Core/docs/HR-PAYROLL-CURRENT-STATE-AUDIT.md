# HR / Payroll 2.0 — Current State Audit & Impact Map

Baseline: `Sabou Restaurant ERP — Alpha159 Inventory 2.0 CI-Repair`

Audit date: 2026-08-09

This report was produced before HR/Payroll 2.0 implementation. It records the observed source, not an assumed architecture.

## Current Employee Model

- `EmployeeEntity` is a single mutable master row. It contains identity, contact, job title, branch, national ID, insurance number, bank card, monthly salary, leave balance and a raw `status`.
- `employeeCode` has a unique index but is nullable and is not generated for legacy or newly-created employees when omitted.
- `jobTitle` and `monthlySalaryRial` are overwritten during edit. They are therefore unsuitable as historical payroll inputs.
- Status is effectively `ACTIVE` / `INACTIVE`; there is no typed transition model, termination date, suspension/on-leave state, department, manager, email, location assignment history or archive policy.
- Sensitive identity/payment data is mixed into the main employee table and is returned unmasked by the repository model.

## Current Contract Model

- `EmployeeContractEntity` stores employee, type, start/end, base salary, daily minutes, weekly days, raw status and notes.
- Contract rows are updateable in place. There is no contract number, version/replacement link, creator/approver identity, policy version, job/department snapshot or immutable approval state.
- No domain or database overlap guard exists.
- `PersonnelDao.effectiveContract()` selects one overlapping row using `ORDER BY ... LIMIT 1`; multiple conflicting contracts are silently hidden.
- Payroll checks full-period coverage after selecting the row, but resolution is not deterministic in the presence of conflicts.

## Current Attendance Model

- Attendance is one mutable daily aggregate row per employee/day with status, in/out minute, late and overtime minutes.
- `saveAttendance()` inserts or updates the row directly. There is no event ledger, correction reason, before/after record, actor, source, device, location, approval or correlation ID.
- Worked minutes are derived as `checkOut - checkIn`; breaks are not included.
- Payroll-paid days are locked, but approved-only payroll does not exist as a separate state.
- Missing clock-out, duplicate clock-in, excessive duration, overlapping shifts and clock-outside-employment anomalies are not modeled.

## Current Leave Model

- Leave uses raw strings and a limited `PENDING -> APPROVED/REJECTED/CANCELLED` workflow.
- Approval writes synthetic daily `LEAVE` attendance aggregates. This couples workflow state to an attendance projection and cannot distinguish paid/unpaid leave in payroll inputs.
- `employees.leaveBalanceMicros` exists but has no entitlement/usage ledger and is not a reliable balance source.
- No granted/used/pending/remaining calculation exists.

## Current Payroll Calculation

- `PayrollCalculator` is a fixed-point domain calculator and uses checked `Long` arithmetic.
- The repository resolves one contract, one effective payroll policy and a daily attendance summary. It adds automatic overtime and absence/late deductions to manual inputs.
- Bonus and allowance are merged when persisted. Component source trace, quantity/rate, manual override approval and policy parameter snapshot do not exist.
- Calculation is not persisted as a complete immutable input snapshot.

## Current Payroll History

- `payroll_runs` preserves multiple revisions with a unique employee/year/month/revision index.
- The list projection exposes period, revision, gross, net, payment date/channel and status.
- There is no Payroll Period, Batch, first-class Payslip, component ledger, snapshot, approval history, payment history or detail query.
- Historical base/net amounts remain stored, but employee/contract/policy/attendance explanations can drift or disappear.

## Current Payroll Approval

- Creation makes a draft accounting journal and a `PENDING_APPROVAL` payroll row.
- Approval enforces `PAYROLL_APPROVE` plus creator/approver separation and then posts the journal.
- Approval changes payroll directly to `PAID`; review, approved, payment-pending and partially-paid states do not exist.
- The approved financial document is not frozen by database guards.

## Current Payroll Payment

- Payment is not a first-class command or ledger.
- Cash/bank is credited in the payroll journal that is posted during approval.
- No treasury account ID, payment reference, idempotency key, partial payment, multiple payments, remaining balance or payment reversal exists.

## Current Advance Handling

- Advances have principal, issue date, channel, journal, settled amount and status.
- Payroll approval creates per-payroll/per-advance allocation rows and advances balances with checked arithmetic.
- Direct settlement posts a journal and updates the mutable balance.
- Allocation reversal restores the balance, but allocation rows have no reversed state/event, command ID, repayment plan, treasury transaction reference or independent audit trail.

## Current Accounting Posting

- Payroll and advances use `LocalAccountingPostingEngine`, which implements `AccountingPostingService`; no direct journal DAO insert is performed by UI.
- Semantic account roles centralize chart mapping.
- Payroll accounting recognizes salary expense and simultaneously credits cash/bank and liabilities. Accrual and settlement are therefore conflated.
- Overtime/bonus expense roles are not separated. Payroll payable is used for miscellaneous deductions rather than net employee liability.

## Current Treasury Integration

- A typed `TreasuryService` and command boundary exists in Foundation, but there is no local implementation.
- Personnel maps payment channels directly to semantic cash/bank accounts. This bypasses the Treasury boundary.

## Current Authorization

- Repository commands enforce permissions at the application/data boundary.
- Most HR operations share coarse `PERSONNEL`; only final payroll approval has a separate permission.
- There are no distinct create/calculate/review/reverse/pay/view-own/view-all/sensitive-edit permissions.

## Current Audit

- Append-only audit infrastructure, actor identity, before/after snapshots and correlation IDs exist.
- Payroll approval and reversal are audited.
- Employee create/edit, contract change, attendance correction, leave review, policy change, manual components, payments and advance allocations are not comprehensively audited.

## Current UX

- `PersonnelScreens.kt` is a 656-line multi-purpose screen combining people, attendance, leave, policies, payroll, contracts, advances and performance dialogs.
- Employee detail exposes a limited sheet rather than bounded/paged Employee 360 tabs.
- Payroll history is a compact list; payslip breakdown, snapshot, approval, payment, accounting and audit detail are absent.
- Search is limited to name/job/code and one active filter.
- Workforce scheduling records are displayed and mutated from Management Control even though they belong to Workforce/HR.

## Data Integrity Risks

1. In-place contract edits can rewrite the meaning of historical payroll.
2. Ambiguous contract overlap is resolved by arbitrary `LIMIT 1` selection.
3. Approval and payment are one transition, preventing accrual/payment reconciliation.
4. Daily attendance can be silently overwritten without correction evidence.
5. Payroll has totals but no complete calculation provenance.
6. There is no payment ledger, so partial/duplicate/overpayment protection cannot be expressed.
7. Nullable employee codes weaken stable human identity.
8. Raw status/type strings allow unknown business states to enter command paths.
9. Leave balance is a mutable field without a supporting ledger.
10. Sensitive employee data is overexposed in the main model.
11. Legacy payroll rows cannot be distinguished from complete HR/Payroll 2.0 documents.
12. Coarse authorization exposes more payroll operations than least privilege requires.

## Missing Enterprise Capabilities

- Effective-dated assignments and immutable contract versions.
- Typed employee, contract, leave, attendance, payroll, payment and advance lifecycles.
- Employee 360 timeline and bounded detail projections.
- Event-based attendance, anomaly review and append-only corrections.
- Leave entitlement/balance ledger and paid/unpaid payroll trace.
- Payroll period, batch, payslip, snapshot and component ledgers.
- Deterministic exception-aware calculation engine.
- Separate review, approval, accrual, payment and close workflows.
- Payment idempotency, partial settlement and compensating reversal.
- Legacy batches and explicit incomplete legacy snapshot semantics.
- Database immutability/transition guards and optimistic state changes.
- Granular permissions and complete audit coverage.

## Target Architecture

The implementation will extend the existing Foundation rather than create parallel accounting, authorization, audit or correlation systems.

### HR master and history

- Keep `employees` as the current master/profile projection.
- Introduce typed `EmploymentStatus` and a validator.
- Backfill and enforce stable employee codes at command and migration boundaries.
- Add effective-dated employment assignments for job, department, branch/location and manager history.
- Add logically separated private profile metadata and mask payment identifiers in presentation.
- Version contracts; never edit an approved/payroll-referenced version in place.
- Resolve contracts through `EffectiveContractResolver`, returning typed zero/conflict failures.

### Attendance and leave

- Add append-only attendance events with typed event/source, actor and correlation metadata.
- Keep legacy daily attendance as an explicit compatibility summary; do not fabricate clock events.
- Derive new daily summaries from real events and surface anomalies.
- Record correction request/approval/before/after and audit evidence.
- Add typed leave lifecycle plus an entitlement/usage ledger; payroll consumes approved paid/unpaid leave inputs explicitly.

### Payroll document system

- `PayrollPeriod` owns the date range and close state.
- `PayrollBatch` owns scope, lifecycle, actors, correlation and exceptions.
- `PayrollPayslip` owns employee/period revision and immutable totals.
- `PayrollSnapshot` freezes employee, contract, attendance, leave, policy and calculation parameters.
- `PayrollComponent` is the positive-amount earning/deduction source ledger.
- `PayrollApprovalEvent` records review/approval/reversal history.
- `PayrollPayment` is an append-only, idempotent partial-payment ledger.
- `PayrollAdvanceAllocation` becomes reversible and traceable.

### Workflow boundaries

- Calculate: HR inputs -> deterministic result -> draft payslips/components/snapshots; no accounting or treasury effect.
- Approve: validate/freeze -> post expense/liability accrual through `AccountingPostingService` -> audit -> approved/payment-pending.
- Pay: execute `TreasuryService` adapter -> append payment -> settle payroll payable -> audit; supports partial payments.
- Reverse: compensating accounting/treasury and allocation events -> new revision workflow; no destructive mutation.

### Migration

- Schema 43 data is preserved.
- Existing payroll rows become deterministic legacy periods/batches/payslips with `LEGACY_MIGRATION` and `componentDetailComplete=false`.
- No historical contract/policy/attendance data is invented.
- Contract conflicts are recorded as migration anomalies, not silently repaired.
- Existing daily attendance remains `LEGACY_SUMMARY`; events are created only when genuine timestamps exist.

## Audited Source Map

- Database: `PersonnelEntities.kt`, `PersonnelDao.kt`, `AppDatabase.kt`, migrations 1–43.
- Domain: `PersonnelModels.kt`, attendance/payroll calculators, advance allocator, performance models.
- Application/data: `LocalPersonnelRepository.kt`, accounting posting engine, audit writer, session authorizer.
- Treasury: typed Foundation models plus legacy channel adapter; no service implementation.
- UI: `PersonnelViewModel.kt`, `PersonnelScreens.kt`, Workforce routes, management workforce controls, reports and print path.
- Tests: personnel unit tests, payroll/advance migration test, Foundation/security/accounting tests; no complete payroll workflow/payment/snapshot integration suite.

