# HR / Payroll 2.0 UX Map

## اصول

- Persian-first و RTL؛
- تاریخ شمسی در presentation، epoch day/timestamp در persistence؛
- business date و system timestamp در label/مدل جدا؛
- مبلغ Rial با grouping و بدون floating-point؛
- commandهای حساس فقط از actionهای state-aware، نه dropdown تغییر status؛
- اطلاعات بانکی فقط mask‌شده؛
- history فقط از snapshot/ledger و نه current salary.

## Navigation ownership

```mermaid
flowchart TD
    A["HR & Workforce"] --> B["People"]
    A --> C["Attendance"]
    A --> D["Leave"]
    A --> E["Payroll"]
    A --> F["Advances"]
    A --> G["Performance"]
```

Planned Shift، Availability، Shift Swap، Work Break و Labor Policy از Management Control خارج شده و در Workforce/HR route نمایش داده می‌شوند. Scheduling 2.0 کامل خارج Scope است، اما ownership و navigation صحیح است.

## People Home

| قابلیت | پیاده‌سازی |
|---|---|
| Search | name، display name، employee code، phone، job، department |
| Status filters | active، terminated، on leave، all |
| Organization filters | department، job و latest contract workflow status |
| Cards | code، job، department/branch، typed status |
| Actions | edit، Employee 360، archive |

## Employee 360

یک scrolling form بزرگ حذف شده است. detail با tab/chipهای مستقل:

| Tab | محتوا |
|---|---|
| Overview | هویت، تماس، job/department/branch، hire، bank mask |
| Employment | status، hire/termination و Timeline bounded |
| Contracts | شماره/نسخه/effective range/salary snapshot/status، approval، new revision |
| Attendance | recent bounded history و correction entry |
| Leave | type/status/date history |
| Payroll | period، gross، deductions، net، paid، remaining، batch، revision/status |
| Advances | principal/status/remaining و action |
| Performance | goal/review history |
| Documents | export/document-vault readiness |
| Audit | command audit/correlation readiness؛ financial detail در payslip audit section |

Timeline رویدادهای HR و مالی را از منابع اصلی projection می‌کند و stable reference نشان می‌دهد.

## Attendance Center

- لیست bounded آخرین روزها؛
- ثبت حضور؛
- اصلاح دستی با reason و optional approval؛
- مشاهده summary؛
- توضیح event/projection distinction؛
- anomalyهای blocking در Payroll Exception Center.

## Leave Center

- workflow status pill؛
- submit/approve/reject/cancel actions متناسب با state؛
- paid/unpaid type روشن؛
- پیام explicit که approved leave ورودی Payroll است؛
- entitlement ledger foundation و fake balance ممنوع.

## Payroll Center

### Current period

- period state و Persian range؛
- close/reopen controlled actions؛
- ساخت batch و policy؛
- KPIهای employees/gross/deductions/net/paid/remaining/exceptions.

### Work queues

- Draft batches؛
- Needs Review؛
- Needs Approval؛
- Payment Pending؛
- Partially Paid؛
- Paid؛
- Reversed.

Buttonهای هر card از state machine پیروی می‌کنند:

- DRAFT: Calculate Atomic؛
- CALCULATED: Submit Review؛
- UNDER_REVIEW: Final Approval/Accrual؛
- payment states: detail/payment؛
- immutable terminal states: فقط detail/reversal rule.

## Payroll Exception Center

blocking/non-blocking به‌صورت مجزا نمایش داده می‌شوند. missing/ambiguous contract، attendance anomaly، missing policy، unapproved adjustment، negative net، invalid employment range و advance over-allocation قابل مشاهده‌اند. approve تا رفع blocker فعال نمی‌شود.

## Payslip History row

هر row نشان می‌دهد:

- period؛
- gross، deductions، net؛
- paid و remaining؛
- batch number؛
- revision؛
- status؛
- legacy incomplete marker در صورت نبود detail واقعی.

مرتب‌سازی period/revision نزولی و query `LIMIT/OFFSET` است.

## Payslip Detail

| Section | محتوا |
|---|---|
| Earnings | componentهای مثبت و trace source |
| Deductions | componentهای مثبت با direction deduction |
| Totals | gross/deductions/net/paid/remaining |
| Attendance & Leave | worked/overtime/absence/late/paid/unpaid snapshot |
| Contract | contract ID/version/base salary snapshot |
| Policy | policy ID/version/rates |
| Advance allocations | advance ID و amount |
| Payment | هر پرداخت/برگشت، تاریخ، treasury account، reference |
| Accounting | accrual/reversal journal IDs |
| Approval & Audit | event، actor، from/to و reason |

فیش legacy به‌جای breakdown ساختگی پیام explicit «Snapshot کامل در منبع قبلی وجود ندارد» نشان می‌دهد.

## Dialog safety

- command ID با بازشدن dialog یک بار ساخته و برای retry/double-tap ثابت می‌ماند؛
- manual amount/reason validation قبل از command؛
- payment amount نمی‌تواند از remaining بیشتر باشد؛
- reversal reason/date اجباری؛
- bank/cash selection به TreasuryAccountId typed تبدیل می‌شود؛
- business failure از `UiErrorHandler` به پیام قابل فهم تبدیل می‌شود.

## Paging / loading

- تب‌ها history کامل را eager load نمی‌کنند؛
- Payslip detail on-demand است؛
- timeline و payroll history page size پیش‌فرض 100؛
- attendance/leave dashboard حداکثر 500 row اخیر؛
- batch KPI به‌صورت aggregate query است.

## Export readiness

PDF در Scope اجباری نیست. detail model برای export دارای employee snapshot، period، revision، approval status، component list، calculation snapshot، payments و accounting references است؛ بنابراین renderer بعدی به live employee/contract وابسته نخواهد بود.
