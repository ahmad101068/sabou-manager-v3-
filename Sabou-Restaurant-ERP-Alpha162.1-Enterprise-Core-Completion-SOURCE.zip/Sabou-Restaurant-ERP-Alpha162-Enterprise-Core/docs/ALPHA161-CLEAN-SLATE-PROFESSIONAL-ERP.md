# Alpha161 Clean-Slate Professional ERP — Architecture & Verification

## 1. تصمیم معماری

Clean-Slate در Alpha161 به معنی حذف کور بخش‌های سالم نیست. ممیزی سورس پایه نشان داد Accounting، Inventory 2.0، Procurement، HR/Payroll، Recipe، Assets، Security، Backup و Migration registry از قبل boundaryهای واقعی دارند. بازنویسی بی‌دلیل این قسمت‌ها ریسک migration و regression را بالا می‌برد. بنابراین Alpha161:

1. subsystem ناقص فروش را با POS تراکنشی واقعی جایگزین می‌کند؛
2. numbering پراکنده و timestamp-based را به سرویس تراکنشی مشترک منتقل می‌کند؛
3. اثرات Sales→Recipe→Inventory→COGS→Accounting→Audit را اتمیک می‌کند؛
4. UI قدیمی Daily Sales را فقط به‌عنوان مسیر compatibility جدا نگه می‌دارد و اجازه double-post نمی‌دهد؛
5. migration و guardهای DB را به قرارداد subsystem جدید اضافه می‌کند.

## 2. مسیر واقعی فروش

```text
ProfessionalSalesScreen
→ SalesPosViewModel
→ SalesUseCases
→ ProfessionalSalesRepository
→ LocalProfessionalSalesRepository
→ Room withTransaction
   ├─ Document sequence allocation
   ├─ Customer credit validation
   ├─ Active recipe/version lookup
   ├─ Cost snapshot
   ├─ Invoice/line/payment insert
   ├─ FEFO inventory issue + lot allocation
   ├─ Revenue journal
   ├─ COGS journal
   ├─ Sync change record
   └─ Audit event
→ Flow read model
→ Invoice details / print
```

هیچ مسیر موفقیت UI-only یا fake repository برای POS حرفه‌ای وجود ندارد.

## 3. Return / Void

### Return

- مقدار تجمعی برگشتی هر invoice line کنترل می‌شود.
- مبلغ، discount/service/tax و COGS به نسبت fact اصلی تخصیص می‌یابند.
- restoration موجودی به allocationهای Lot همان فروش متصل است.
- journal درآمد و COGS معکوس ایجاد می‌شود.
- وضعیت فاکتور `PARTIALLY_RETURNED` یا `RETURNED` می‌شود.

### Void

فقط فاکتور POSTED بدون مرجوعی قابل Void است. Void نیازمند Permission مستقل، روز باز و دلیل است و با reversalهای مالی/انباری ثبت می‌شود. fact اولیه حذف یا rewrite نمی‌شود.

## 4. Day Close / Reopen / Reconciliation

`sales_pos_day_closures` snapshot پایان روز را نگه می‌دارد. بسته‌شدن روز در سطح repository و trigger دیتابیس جلوی ثبت فاکتور/مرجوعی/حرکت انبار فروش را می‌گیرد. Owner می‌تواند با دلیل و Audit روز را REOPEN کند؛ بستن مجدد revision جدید می‌سازد.

Cash Reconciliation منبع مورد انتظار را از POS closure یا Legacy closure می‌گیرد. وجود هم‌زمان هر دو منبع بسته برای یک روز به‌عنوان خطای integrity رد می‌شود.

## 5. Document Numbering

`LocalDocumentNumberAllocator` مقدار sequence را داخل همان transaction با compare-and-advance رزرو می‌کند. شماره نمایش انسانی از PK و command/global ID مستقل است. این تفکیک اجازه idempotency فنی و شماره‌گذاری قابل‌فهم انسانی را هم‌زمان می‌دهد.

## 6. DB facts و guardها

factهای زیر append-only/immutable هستند یا فقط metadata مشخص‌شده آن‌ها قابل update است:

- `sales_invoices`
- `sales_invoice_lines`
- `sales_payments`
- `sales_consumption_snapshots`
- `sales_returns`
- `sales_return_lines`

برای Invoice فقط metadata مربوط به posting/status/void می‌تواند تغییر کند؛ مبلغ، مشتری، روز، شماره و COGS snapshot قابل rewrite نیست.

## 7. Migration 44→45

Migration فقط create/index/guard انجام می‌دهد و جدول قبلی را drop نمی‌کند. مسیر قبلی migration registry حفظ شده و `MIGRATION_44_45` در انتهای زنجیره ثبت شده است. `fallbackToDestructiveMigration` در source مجاز نیست و verifier آن را رد می‌کند.

## 8. ماژول‌های حفظ‌شده و اتصال Alpha161

- **Inventory 2.0:** ledger، location، lot، FEFO، transfer، count، waste و period lock حفظ شده؛ sales movement types و lot reversal جدید به آن متصل شده‌اند.
- **Recipe/Costing:** نسخه مؤثر رسپی و snapshot هزینه در فروش استفاده می‌شود.
- **Accounting:** semantic posting boundary موجود حفظ شده و Accounts Receivable مشتری به role جدید متصل است.
- **Procurement/Purchase:** جریان‌های requisition/order/receipt/return حفظ شده و شماره‌گذاری اسناد به allocator مرکزی منتقل شده است.
- **Assets:** lifecycle و depreciation موجود حفظ شده؛ asset code از allocator مرکزی صادر می‌شود.
- **HR/Payroll:** architecture موجود حفظ شده؛ صدور کد پرسنلی جدید به allocator تراکنشی `EMP` منتقل شده و داده تاریخی payroll rewrite نمی‌شود.
- **Security/Audit:** Permission دامنه برای Customer/Return/Void و Audit چاپ/بستن/بازگشایی اضافه شده است.
- **Dashboard:** KPI فروش حرفه‌ای از ledger جدید تغذیه می‌شود.

## 9. تست و CI

CI Alpha161 اجرا می‌کند:

```bash
bash scripts/verify-foundation.sh
bash scripts/verify-alpha161-professional-erp.sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest   # API 23
./gradlew --no-daemon connectedDebugAndroidTest   # API 35
./gradlew --no-daemon assembleRelease
```

تست جدید `SalesCalculatorTest` قرارداد fixed-point و payment equality را پوشش می‌دهد. تست `ProfessionalSalesMigration44To45Test` ساخت جدول/index/trigger، sequence CAS، immutability، closed-day و FK check را پوشش می‌دهد.

## 10. وضعیت قابل ادعا

در محیط تحویل static verifierها، SQLite migration/guards/day totals و compile مستقل دامنه PASS شده‌اند. Build کامل Gradle به علت عدم دسترسی shell به Gradle distribution اجرا نشد؛ مرجع نهایی build و Instrumentation، GitHub Actions همین سورس است. هیچ تستی برای سبز نشان‌دادن نتیجه حذف، Ignore یا تضعیف نشده است.
