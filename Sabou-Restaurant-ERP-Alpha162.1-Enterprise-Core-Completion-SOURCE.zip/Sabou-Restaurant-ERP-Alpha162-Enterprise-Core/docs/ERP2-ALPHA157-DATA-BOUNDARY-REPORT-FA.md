# گزارش فنی Alpha157 — Data Boundary Split

تاریخ: 2026-08-09

نسخه: `3.0.0-alpha157.0-data-boundary-split`

Schema: `42` بدون تغییر

## نتیجه

God File قدیمی `Daos.kt` حذف و قراردادهای آن به ۱۲ فایل با owner domain مشخص منتقل شد.
این تغییر عمداً مکانیکی است: هیچ Query، annotation، signature یا رفتار Repository تغییر
نکرد تا ریسک Regression مالی و موجودی با تغییر ساختاری مخلوط نشود.

## فایل‌های حاصل

| فایل | خطوط | Owner |
|---|---:|---|
| `SupplierDao.kt` | ۳۴ | Suppliers |
| `InventoryDao.kt` | ۱۴۶ | Inventory |
| `PurchaseDao.kt` | ۱۷۰ | Purchasing |
| `ProcurementDao.kt` | ۴۴۲ | Procurement |
| `AccountingDao.kt` | ۴۱۱ | Accounting |
| `PersonnelDao.kt` | ۲۰۳ | Workforce / Payroll |
| `RecipeDao.kt` | ۱۲۱ | Recipe |
| `InventoryControlDao.kt` | ۸۰ | Inventory Control |
| `AuditLogDao.kt` | ۱۵ | Audit |
| `SecurityDao.kt` | ۴۶ | Security |
| `AssetDao.kt` | ۵۵ | Assets |
| `AlertDao.kt` | ۵۳ | Alerts |

## PHASE A — Audit / Impact

`Daos.kt` شامل ۱۲ DAO، ۲۳ read row و قراردادهای چند Domain نامرتبط بود. Impact Map پیش از
Patch در `ERP2-ALPHA157-DATA-BOUNDARY-IMPACT-MAP-FA.md` ثبت شد.

## PHASE B — Target Design

هر DAO در همان package قبلی باقی ماند تا reference resolution و accessorهای `AppDatabase`
بدون API migration حفظ شوند. نام فایل اکنون owner domain را نشان می‌دهد.

## PHASE C/D — Data Model و Migration

هیچ Data Model یا Migration تغییر نکرد. Schema همچنان `42` است و
`APP_DATABASE_SCHEMA_VERSION`، `MIGRATION_41_42` و `ALL_MIGRATIONS` بدون diff باقی ماندند.

## PHASE E/F — Domain و Repository

Domain rule و Repository behavior دست‌نخورده باقی ماندند. این جداسازی، پیش‌نیاز تفکیک
بعدی Repositoryهای Procurement و مرز مستقل Treasury است.

## PHASE G/H — ViewModel و UI

تغییری انجام نشد؛ این Increment presentation behavior ندارد.

## PHASE I — Tests / Contract Parity

محتوای declarationهای قبل و بعد با حذف package/import/blank-line مقایسه شد. شمارش قبل و
بعد دقیقاً برابر است:

- ۱۲ `@Dao`
- ۱۷۲ `@Query`
- ۳۹ `@Insert`
- ۱۲ `@Update`
- دو `@Transaction`
- ۲۳ read row
- ۱۷ accessor در `AppDatabase`

تست‌های موجود حذف یا bypass نشدند: ۱۶۴ Unit Test و ۶۱ Instrumentation Test در سورس باقی‌اند.

## PHASE J — Verification

| Gate | نتیجه |
|---|---|
| declaration/annotation/accessor parity | موفق |
| یکتایی declaration هر DAO | موفق |
| parse نحوی ۱۲ فایل Kotlin | بدون خطا |
| `scripts/verify-foundation.sh` | موفق |
| `git diff --check` | موفق |
| Gradle/KSP/Room/Lint | اجرا نشده؛ در انتظار CI |

اجرای `./gradlew --offline --version` نیز نشان داد Gradle 8.13 در cache محیط وجود ندارد و
Wrapper برای دریافت distribution به شبکه غیرقابل‌دسترسی نیاز دارد؛ بنابراین نتیجه Compile
یا KSP به‌صورت غیرواقعی اعلام نشده است.

## PHASE K — تصمیم بعدی

Increment بعدی باید `AppDatabase.kt` را بدون تغییر migration behavior به database definition،
migration ranges، seed و guard lifecycle تفکیک کند. پس از Build سبز، تفکیک
`LocalProcurementRepository` به command ownerهای Requisition/Approval/Order/Receiving/
Matching/Return انجام می‌شود.
