# CafeManager alpha154.3 — Accounting Boundary Phase 2

Implemented on top of alpha154.2.

## Completed
- Migrated Personnel employee-advance issuance journals to SemanticAccountRole.
- Migrated employee-advance settlement journals to SemanticAccountRole.
- Migrated Payroll draft journal construction to the centralized LocalAccountingPostingEngine.
- Migrated Fixed Asset acquisition journals to semantic accounting roles.
- Migrated Fixed Asset depreciation journals to semantic accounting roles.
- Migrated Fixed Asset no-proceeds disposal journals to semantic accounting roles.
- Removed chart-of-account codes from AssetAcquisitionSource domain enum.
- Sync payloads now describe the acquisition source semantically rather than exposing an account code.
- Preserved existing Room transaction boundaries and journal finalization workflow.
- Allowed provisional semantic journals with sourceId=0 so existing create-then-finalize workflows remain compatible.

## Verification
A source scan confirms LocalPersonnelRepository and LocalAssetRepository no longer contain the migrated hard-coded system account codes.

Gradle unit tests could not be executed in this environment because Gradle 8.13 is not locally cached and services.gradle.org is unavailable. No successful-build claim is made.

## Next
Migrate Procurement/Purchases and Operations inventory-waste accounting to the same accounting boundary, then remove account-code ownership from purchase-domain payment enums.
