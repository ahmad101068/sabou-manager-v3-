# Changelog — Alpha159 Inventory 2.0

## Added

- Item Master 2.0 با SKU پایدار، Barcode اصلی، نوع کالا، شرایط نگهداری، Policy لات/انقضا و پارامترهای تأمین
- Location master نوع‌دار و projection بازسازی‌پذیر `inventory_balances` در سطح کالا/محل
- Lot/Expiry/FEFO service با تخصیص deterministic، exclusion لات منقضی/قرنطینه/مسدود و shortage صریح
- Count Session/Line workflow با Blind Count، Recount policy، Approval، SoD و posting اتمیک
- Waste document workflow با دلیل و وضعیت type-safe، cost snapshot، Approval، Accounting و Audit
- Transfer document workflow با Request/Approve/Issue/In-Transit/Receive/Complete و variance صریح
- Replenishment service با available، on-order، in-transit، lead-time demand، safety stock و days of cover
- Inventory integrity checker و read-side bounded SQL برای Dashboard، Balance و Movement Ledger
- Workspace و Routeهای مستقل Inventory برای کالا، انقضا، گردش، شمارش، ضایعات، انتقال، تأمین و دوره
- تست‌های Domain، Room integration و Migration برای مسیرهای بحرانی Inventory 2.0

## Changed

- تمام مسیرهای مهاجرت‌یافته موجودی از `InventoryCommandService` و transaction boundary مشترک عبور می‌کنند.
- Goods Receipt داده Lot/Expiry/Location را به Inventory boundary تحویل می‌دهد.
- Sales/Recipe consumption و reversal با location projection و تخصیص لات سازگار شده‌اند.
- Management Control دیگر مالک UI محل، لات، FEFO و انتقال موجودی نیست و به Workspace انبار هدایت می‌کند.
- نسخه برنامه به `3.0.0-alpha159.0-inventory-2` / `versionCode 202` ارتقا یافت.

## Database

- Room schema از `42` به `43` ارتقا یافت.
- Migration `42 → 43` حفظ‌داده، غیرتخریبی و در Registry ترتیبی 1→43 ثبت شد.
- موجودی legacy با movement نوع `OPENING_BALANCE` فقط به اندازه اختلاف projection و ledger reconcile می‌شود.
- محل پیش‌فرض پایدار `MAIN` ایجاد/نرمال می‌شود؛ برای موجودی بدون lot، lot جعلی ساخته نمی‌شود.
- Waste و Transfer legacy با حفظ شناسه/داده به سندهای Posted/Completed منتقل می‌شوند.

## Verification status

- Foundation static verification، Kotlin syntax parsing، SQL simulations و `git diff --check`: اجرا شده‌اند.
- Gradle compile/assemble/unit/instrumentation، KSP/Room validation و Android migration tests: در این محیط به‌دلیل نبود Gradle 8.13 و عدم دسترسی شبکه **NOT EXECUTED** هستند.
- تا سبز شدن CI و تولید/تأیید Room schema export نسخه 43، وضعیت Release برابر BLOCKED است.
