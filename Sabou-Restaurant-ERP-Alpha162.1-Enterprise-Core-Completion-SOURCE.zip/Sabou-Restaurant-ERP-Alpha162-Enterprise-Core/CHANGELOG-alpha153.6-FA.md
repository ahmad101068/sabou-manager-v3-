# تغییرات alpha153.6 — Domain Integrity

- `versionCode`: 192
- `versionName`: `3.0.0-alpha153.6-domain-integrity`
- Database schema: 39 (بدون Migration)

## تغییرات

- Audit Trail قابل انتساب برای خرید، تسویه، فروش روزانه و سند دستی تکمیل شد.
- Outbox برگشت عملیات مالی تکمیل شد.
- کنترل توازن سند تدارکات در برابر overflow مقاوم شد.
- گزارش ممیزی دامنه، ریسک‌ها و نقشه راه اضافه شد.

## Verification

- Foundation/static verification: اجرا و موفق.
- Gradle build, lint, unit/instrumentation tests: در محیط فعلی به دلیل نبود Android SDK/دسترسی توزیع Gradle اجرا نشده‌اند.
