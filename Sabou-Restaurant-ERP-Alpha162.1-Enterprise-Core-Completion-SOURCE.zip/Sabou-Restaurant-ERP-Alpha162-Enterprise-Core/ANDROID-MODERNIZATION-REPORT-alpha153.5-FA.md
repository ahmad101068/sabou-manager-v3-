# گزارش نهایی ارتقای Android — alpha153.5

## Architecture Before / After

| محور | قبل | بعد |
|---|---|---|
| State collection | `collectAsState` بدون آگاهی مستقیم از Lifecycle | `collectAsStateWithLifecycle` برای ۱۲ StateFlow اصلی |
| UI recreation | Navigation حفظ می‌شد؛ Queryها و تب‌های مهم عمدتاً از بین می‌رفتند | Navigation، Query جست‌وجوی سراسری/فروش و تب حسابداری حفظ می‌شوند |
| Theme host | Cast مستقیم Context به Activity | Activity resolution امن از ContextWrapper و رفتار سازگار Preview |
| Search load | هر نویسه می‌توانست Query جدید Room ایجاد کند | Debounce ۲۵۰ms و حذف درخواست تکراری در خرید، فروش و حسابداری |
| Notification permission | درخواست ناگهانی هنگام Startup | توضیح و اقدام اختیاری داخل مرکز هشدارها |
| Lazy lists | بعضی فهرست‌ها بدون Stable Key | Module list و Global Search دارای کلید پایدار |
| Search component | بدون Clear action و IME مشخص | Clear action قابل‌دسترسی و IME Search |

## Module Upgrades

- Dashboard: کلید پایدار ماژول‌ها و Semantics روشن برای ورودی تنظیمات.
- Navigation: Route stack و دیالوگ خروج در Recreation حفظ می‌شوند؛ Route coverage استاتیک کنترل شد.
- Global Search: Query ماندگار، Stable Key و Empty State خواناتر.
- Purchases / Daily Sales / Accounting: جست‌وجوی Debounced برای کاهش Queryهای پی‌درپی.
- Alerts: Permission UX در Context و Progress روشن برای Refresh.
- Theme / Design System: Context-safe host، حفظ سیستم مرکزی Light/Dark/RTL و بهبود Search/Empty components.
- همه Presentation Stateها: Collection وابسته به Lifecycle.

## مواردی که عمداً تغییر نکردند

- منطق مالی، ثبت دوبل، موجودی، Payroll و محاسبات رسپی.
- Schema دیتابیس ۳۹ و Migrationهای `1 → 39`.
- ساختار تک‌ماژولی Gradle؛ Multi-module migration بدون Build baseline قابل‌اعتماد ارزش خالص نداشت.
- Hilt/Koin اضافه نشد؛ `AppContainer` برای اندازه فعلی Composition Root قابل‌قبول است.
- Dynamic Color فعال نشد تا هویت سبز/طلایی محصول و Contrast کنترل‌شده حفظ شود.
- Sync Production فعال نشد و همچنان fail-closed است.
- فایل‌های بزرگ مالی/DAO صرفاً برای زیبایی معماری شکسته نشدند.

## Files Changed در alpha153.5

- `app/build.gradle.kts`
- `gradle/libs.versions.toml`
- `app/src/main/java/ir/sabou/inventory/MainActivity.kt`
- `app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt`
- `app/src/main/java/ir/sabou/inventory/ui/theme/Theme.kt`
- `app/src/main/java/ir/sabou/inventory/ui/DesignComponents.kt`
- `app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt`
- `app/src/main/java/ir/sabou/inventory/ui/DailySalesScreens.kt`
- `app/src/main/java/ir/sabou/inventory/ui/AccountingScreens.kt`
- `app/src/main/java/ir/sabou/inventory/ui/AlertScreens.kt`
- `app/src/main/java/ir/sabou/inventory/ui/DailySalesViewModel.kt`
- `app/src/main/java/ir/sabou/inventory/ui/AccountingViewModel.kt`
- `app/src/main/java/ir/sabou/inventory/ui/OperationsViewModel.kt`
- `.github/workflows/build-apk.yml`
- `scripts/verify-foundation.sh`
- `README-fa.md` و `STATUS-FA.md`
- گزارش‌ها و Changelog این نسخه

## Verification

| کنترل | نتیجه |
|---|---|
| Foundation structural checks | `PASSED` |
| Route coverage برای همه AppScreenها | `PASSED` |
| نبود `collectAsState` خام در UI | `PASSED` |
| Duplicate import scan | `PASSED` |
| Version/CI metadata consistency | `PASSED` |
| Gradle `testDebugUnitTest lintDebug assembleDebug` | `BLOCKED` پیش از Build؛ Gradle 8.13 در Cache نیست و شبکه محیط اجازه دانلود نمی‌دهد |
| Unit Tests | `NOT RUN` |
| Lint | `NOT RUN` |
| Compose UI / Instrumented tests | `NOT RUN` |
| Visual Regression روی گوشی/تبلت | `NOT RUN` |
| APK | `NOT BUILT` |

## Remaining Issues / Risks

- تغییرات Compose از نظر API به‌صورت استاتیک بررسی شده‌اند، اما تا اجرای CI نباید `BUILD VERIFIED` اعلام شوند.
- Formهای بزرگ هنوز Stateهای محلی `remember` دارند و برای Unsaved Changes/Process Death به ارتقای مرحله‌ای نیاز دارند.
- مرکز کنترل، DAOها و چند Screen/Repository بزرگ نیازمند Refactor هستند؛ این کار باید پس از سبز شدن Build و ایجاد تست‌های حفاظتی انجام شود.
- Permission denial دائمی اعلان بهتر است در نسخه بعد به صفحه تنظیمات سیستم هدایت شود.
- Adaptive/Tablet، Font Scale بزرگ، Dark Mode، RTL و Keyboard باید با Screenshot/Compose UI tests روی دستگاه بررسی شوند.
- Full Cost رسپی مطابق Roadmap باید Sprint مستقل و Migration امن `39 → 40` داشته باشد.

## Delivery Status

`IMPLEMENTED + STATICALLY VERIFIED + BUILD BLOCKED BY ENVIRONMENT`

این نسخه از نظر Lifecycle، UX، Performance و Maintainability بهتر از alpha153.4 است، اما Production Gate نهایی همچنان سبز شدن CI و تست دستگاه واقعی است.
