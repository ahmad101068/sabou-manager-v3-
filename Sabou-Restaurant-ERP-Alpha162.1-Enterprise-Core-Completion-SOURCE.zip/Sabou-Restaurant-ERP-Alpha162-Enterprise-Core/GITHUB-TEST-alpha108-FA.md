# آزمون نسخه alpha108 در GitHub

۱. محتوای داخل پوشه پروژه را در ریشه مخزن GitHub قرار دهید؛ پوشه `.github` باید در
ریشه مخزن باشد.

۲. تغییرات را روی شاخه `main` یا `master` Push کنید. Workflow با نام
`Build Android APK` خودکار اجرا می‌شود. اجرای دستی آن نیز از بخش Actions ممکن است.

۳. مراحل زیر باید سبز شوند:

- Static verification
- Unit tests, lint, and debug build
- Run integration tests on minimum Android API 23
- Run integration tests on Android 35
- Verify unsigned release build

۴. پس از موفقیت، در انتهای همان اجرای Actions فایل
`sabou-manager-alpha108-debug-apk-<run number>` را از بخش Artifacts دانلود کنید.

۵. اگر مرحله‌ای قرمز شد، نام مرحله و متن کامل خطای همان مرحله را نگه دارید؛ اصلاح بعدی
باید روی همین نسخه انجام شود، نه روی شاخه یا فایل قدیمی.
