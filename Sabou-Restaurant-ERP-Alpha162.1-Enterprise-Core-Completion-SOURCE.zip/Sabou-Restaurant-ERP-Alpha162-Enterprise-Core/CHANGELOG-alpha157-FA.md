# Changelog — Alpha157 Data Boundary Split

## Added

- ۱۲ فایل DAO مستقل با ownership روشن برای suppliers، inventory، purchasing، procurement،
  accounting، workforce/payroll، recipe، inventory control، audit، security، assets و alerts
- Impact Map و گزارش parity مخصوص Increment تفکیک Data Boundary
- کنترل ایستا برای جلوگیری از بازگشت God File قدیمی و duplicate declarationهای DAO

## Changed

- `Daos.kt` با ۱٬۷۱۲ خط حذف شد.
- تمام declarationها بدون تغییر package و public contract به فایل owner domain منتقل شدند.
- نسخه برنامه به `3.0.0-alpha157.0-data-boundary-split` و `versionCode 200` ارتقا یافت.
- نام artifact در GitHub Actions با Alpha157 هماهنگ شد.

## Compatibility

- Room Schema روی `42` باقی مانده است.
- هیچ Entity، column، index، trigger، Migration، SQL query یا DAO signature تغییر نکرده است.
- Repository، ViewModel، UI و Navigation تغییر رفتاری ندارند.

## Verification

- parity کامل ۱۲ DAO، ۱۷۲ `@Query`، ۳۹ `@Insert`، ۱۲ `@Update`، دو `@Transaction`،
  ۲۳ read row و ۱۷ accessor کنترل شد.
- ۱۲ فایل Kotlin جدید بدون خطای نحوی Parse شدند.
- static foundation check و `git diff --check` موفق‌اند.
- Gradle/KSP/Room/Lint در این محیط اجرا نشده و همچنان CI گیت نهایی است.
