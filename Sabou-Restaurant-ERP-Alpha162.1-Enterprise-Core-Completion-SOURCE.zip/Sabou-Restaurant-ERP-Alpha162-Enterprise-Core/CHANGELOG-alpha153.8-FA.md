# تغییرات alpha153.8 — Operational Drill-down

- `versionCode`: 195
- `versionName`: `3.0.0-alpha153.8-operational-drilldown`
- Schema: 39، بدون Migration

صورت‌حساب حساب، تاریخچه گردش کالا، Drill-down مستقیم Search، Timeline حضور پرسنل و اصلاح نمایش مقادیر منفی اضافه شدند.
