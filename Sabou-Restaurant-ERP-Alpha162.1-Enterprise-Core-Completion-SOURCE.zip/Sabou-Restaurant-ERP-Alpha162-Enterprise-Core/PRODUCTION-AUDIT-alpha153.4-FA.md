# گزارش ممیزی Production — alpha153.4

## دامنه بررسی

- ۳۹۴ فایل پروژه، شامل ۱۲۹ فایل Kotlin اصلی، ۵۵ تست واحد اولیه و ۳۱ تست Android اولیه بررسی شدند.
- ساختار Gradle، Manifest، Room/SQLCipher، Migrationهای `1 → 39`، Repositoryها، امنیت نشست و PIN، عملیات حساس، پشتیبان، Sync، CI و مسیر چاپ بررسی شدند.
- این بازبینی Migration یا پاک‌سازی داده ندارد و Schema دیتابیس روی نسخه ۳۹ باقی مانده است.

## یافته‌ها و اصلاحات

### HIGH — اعتبارسنجی ناکافی Sync endpoint

بررسی قبلی فقط با `startsWith("https://")` انجام می‌شد و ساختار URI، host، user-info، query و fragment را کنترل نمی‌کرد. اعتبارسنجی مرکزی URI اضافه و در هر دو مسیر Upload و Token Refresh استفاده شد.

وضعیت: `IMPLEMENTED` و `STATICALLY VERIFIED`؛ تست واحد Regression افزوده شد ولی Gradle در این محیط اجرا نشد.

### MEDIUM — آزاد نشدن قطعی HttpURLConnection

اتصال‌های Upload و Token Refresh در `finally` قطع نمی‌شدند. هر دو مسیر اکنون در موفقیت و شکست `disconnect()` می‌شوند.

وضعیت: `IMPLEMENTED` و `STATICALLY VERIFIED`.

### MEDIUM — سطح حمله غیرضروری WebView چاپ

WebView فقط برای سند HTML محلی چاپ استفاده می‌شود، اما سیاست‌های محدودکننده صریح نبودند. JavaScript، دسترسی فایل، دسترسی ContentProvider و بارگذاری شبکه غیرفعال شدند. WebViewClient نیز بعد از نخستین Page Load جدا می‌شود تا چاپ تکراری ایجاد نشود.

وضعیت: `IMPLEMENTED` و `STATICALLY VERIFIED`.

### LOW — ناسازگاری متادیتای نسخه و CI

`STATUS-FA.md` و نام Artifact در CI با Build واقعی هماهنگ نبودند. نسخه به `3.0.0-alpha153.4-production-audit` با `versionCode 190` ارتقا یافت و مستندات، کنترل ساختاری و CI هماهنگ شدند.

وضعیت: `VERIFIED` با اسکریپت Foundation.

### LOW — مستند معماری با ساختار واقعی منطبق نبود

مستند از لایه‌های `feature` و `app` نام می‌برد، درحالی‌که ساختار واقعی `ui`، ریشه پکیج برنامه و `AppContainer` است. مستند با سورس همگام شد.

وضعیت: `VERIFIED` با بررسی ساختار فایل‌ها.

## موارد بررسی‌شده و بدون تغییر

- دیتابیس با SQLCipher و کلید تصادفی محافظت‌شده توسط Android Keystore باز می‌شود.
- Android Backup و انتقال داده سیستم برای دیتابیس، فایل‌ها و SharedPreferences مسدود است.
- Cleartext Traffic غیرفعال است.
- Restore، Factory Reset و بستن/بازگشایی دوره‌ها در مرز داده مجوز PIN کوتاه‌عمر، متصل به کاربر/عملیات و یک‌بارمصرف می‌خواهند.
- Sync چنددستگاهی عمداً fail-closed و غیرفعال است؛ Outbox به‌عنوان قابلیت کامل Sync معرفی نمی‌شود.
- زنجیره Migration ثبت‌شده `1 → 39` است و تست Migration کامل در پروژه وجود دارد.
- TODO، FIXME، HACK، Empty Catch، `fallbackToDestructiveMigration` و `allowMainThreadQueries` خطرناک پیدا نشد.

## Technical Debt باقی‌مانده

- `Daos.kt`، `AppDatabase.kt`، `LocalProcurementRepository.kt`، `OperationsScreens.kt` و `SabouApp.kt` بزرگ هستند. تفکیک آن‌ها بدون Build و تست Android کامل انجام نشد، چون Correctness و ریسک Migration از بهبود ظاهری مهم‌تر است.
- پاسخ‌های JSON در Sync با Codec داخلی محدود پردازش می‌شوند. پیش از فعال‌سازی Production Sync باید قرارداد دریافت/اعمال داده، parser ساخت‌یافته، محدودیت اندازه پاسخ و تست End-to-End سرور تکمیل شود.
- Biometric پیاده‌سازی نشده؛ PIN جاری مسیر رسمی احراز مجدد است.
- تست روی دستگاه فیزیکی، بازیابی واقعی بین دو دستگاه و تست Upgrade دیتابیس واقعی همچنان Release Gate هستند.

## Verification

| کنترل | نتیجه |
|---|---|
| بررسی ساختار و اتصالات Foundation | `PASSED` |
| بررسی Manifest و سیاست Backup | `PASSED` |
| بررسی نسخه/Schema/Migration Contract به‌صورت استاتیک | `PASSED` |
| اجرای Gradle 8.13 | `BLOCKED` — Distribution در Cache نیست و شبکه محیط اجازه دانلود نمی‌دهد |
| Unit Test / Lint / assembleDebug | `NOT RUN` — Gradle و Android SDK در دسترس نیستند |
| Android Instrumented Tests | `NOT RUN` — Android SDK/Emulator موجود نیست |
| Release APK | `NOT BUILT` |
| تست گوشی واقعی | `NOT RUN` |

## نتیجه Production Readiness

این نسخه نسبت به alpha153.3 سخت‌تر و منسجم‌تر است، اما تا سبز شدن CI کامل، تست Migration روی کپی واقعی داده، Restore روی دستگاه دوم و تست گوشی فیزیکی نباید `Production-Verified` یا تنها مرجع مالی اعلام شود.

وضعیت دقیق تحویل: `IMPLEMENTED + STATICALLY VERIFIED + BUILD BLOCKED BY ENVIRONMENT`.
