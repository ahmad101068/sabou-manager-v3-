# Changelog — Sabou Alpha161 Clean-Slate Professional ERP

نسخه: `3.0.0-alpha161-clean-slate-professional-erp`  
Schema: `45`  
Migration جدید: `44 → 45`

## هدف این Increment

Alpha161 اجرای مستقل و production-heavy برای رفع مهم‌ترین شکاف معماری Alpha160 است. بخش‌های سالم ERP 2.0 حفظ شده‌اند؛ مرزهای ضعیف حذف یا دور زده نشده‌اند و برای فروش حرفه‌ای، شماره‌گذاری اسناد و کنترل پایان روز، مسیرهای واقعی Domain/Data/Room/Audit/Print/Test اضافه شده‌اند.

## فروش و صندوق حرفه‌ای

- POS تراکنشی مستقل از ثبت تجمیعی قدیمی با فاکتور ردیفی، مشتری، تخفیف ردیف/کل، سرویس، مالیات و چند روش پرداخت.
- پرداخت نقد، کارت، انتقال و اعتبار مشتری؛ فروش اعتباری نیازمند مشتری و سررسید و محدود به سقف اعتبار واقعی است.
- snapshot نسخه رسپی و بهای تمام‌شده در لحظه فروش؛ تغییر بعدی رسپی تاریخچه فروش را تغییر نمی‌دهد.
- مصرف موجودی در همان transaction ثبت فاکتور، با FEFO/Lot allocation و COGS حسابداری.
- مرجوعی جزئی/کامل با allocation تجمعی، برگشت موجودی و Lot، اصلاح COGS و سند مالی معکوس.
- Void کنترل‌شده با Permission مستقل، دلیل اجباری، برگشت کامل موجودی و accounting reversal.
- Hold/Resume با snapshot تخفیف کل، سرویس، مالیات و ردیف‌ها.
- فاکتور و factهای فروش پس از ثبت immutable هستند؛ اصلاح از مسیر Return/Void انجام می‌شود.
- چاپ A4/RTL از داده واقعی فاکتور؛ چاپ/چاپ مجدد در Audit ثبت می‌شود.
- بستن روز POS با snapshot خالص فروش، COGS، روش‌های پرداخت و تعداد فاکتور/مرجوعی؛ بازگشایی فقط Owner و با Audit.
- Cash Reconciliation می‌تواند مستقیماً از snapshot بسته‌شده POS استفاده کند.
- جلوگیری دوطرفه از اثرگذاری هم‌زمان POS حرفه‌ای و Daily Sales Legacy روی یک روز.

## شماره‌گذاری تراکنشی اسناد

جدول `document_sequences` و allocator مبتنی بر Compare-And-Advance داخل همان Room transaction اضافه شد. شماره‌ها دیگر از ساعت گوشی ساخته نمی‌شوند. این سیاست اکنون برای موارد زیر استفاده می‌شود:

- فاکتور خرید `PUR`
- درخواست خرید `PR`
- سفارش خرید `PO`
- رسید کالا `GR`
- مرجوعی خرید `PRT`
- انتقال انبار `TRF`
- فاکتور فروش `SAL`
- مرجوعی فروش `RET`
- Hold فروش `HLD`
- دارایی ثابت `AST`
- کد پرسنلی `EMP`
- مشتری `CUS`

Unique index دیتابیس همچنان لایه دفاع نهایی باقی مانده است.

## دیتابیس و یکپارچگی

Migration `44→45` بدون destructive migration این ساختارها را اضافه می‌کند:

- document sequence
- customer sub-ledger
- sales invoice / lines / payments
- recipe consumption snapshot
- sales return / lines
- sales holds / lines
- professional POS day closure

Triggerهای دیتابیس تغییر مستقیم factهای مالی/انباری فروش، حذف فاکتور/مرجوعی و ثبت عملیات فروش روی روز بسته را مسدود می‌کنند. lifecycle دیتابیس این guardها را پس از create/open نیز نصب و کنترل می‌کند.

## Dashboard / Security / Treasury

- KPI روز از ledger POS حرفه‌ای خوانده می‌شود و هنگام وجود تراکنش حرفه‌ای به Daily Summary قدیمی fallback نمی‌کند.
- مانده مطالبات مشتری و Holdها به داده مدیریتی متصل شده‌اند.
- Permissionهای `CUSTOMERS`، `SALES_RETURN` و `SALES_VOID` در boundary دامنه enforce می‌شوند.
- کانال پرداخت Payroll برای CARD/TRANSFER به BANK mapping امن دارد و دیگر به دلیل تفاوت نام کانال بی‌دلیل fail نمی‌شود.

## کنترل کیفیت اجراشده در محیط تحویل

موارد زیر واقعاً اجرا و PASS شدند:

- `bash scripts/verify-foundation.sh`
- `bash scripts/verify-alpha161-professional-erp.sh`
- کامپایل/اجرای مستقل دامنه فروش با `kotlinc`
- اجرای SQL واقعی Migration و 15 trigger روی SQLite میزبان
- `PRAGMA foreign_key_check` روی fixture Migration
- تست مستقل SQL تجمیع پایان روز POS با فروش/مرجوعی/روش‌های پرداخت
- syntax parse فایل‌های production اصلی تغییرکرده با compiler Kotlin

### محدودیت قابل اثبات محیط

Gradle Wrapper برای اجرای build کامل باید Gradle `8.13` را از `services.gradle.org` دریافت کند. محیط تحویل دسترسی DNS/شبکه shell به آن میزبان نداشت و اجرای Gradle با `UnknownHostException` متوقف شد. بنابراین این بسته **ادعای دروغین build سبز محلی ندارد**. Workflow گیت‌هاب برای اجرای Unit/Lint/Debug/Instrumentation روی API 23 و 35 و Release آماده شده است.
