-keepattributes *Annotation*
-keep class * extends androidx.room.RoomDatabase { *; }
-dontwarn javax.annotation.**

