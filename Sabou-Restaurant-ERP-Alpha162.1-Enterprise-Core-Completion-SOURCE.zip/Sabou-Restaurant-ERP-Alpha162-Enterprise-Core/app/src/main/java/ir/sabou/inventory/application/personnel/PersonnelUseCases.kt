package ir.sabou.inventory.application.personnel

import ir.sabou.inventory.domain.personnel.*
import ir.sabou.inventory.domain.treasury.TreasuryChannel

class PersonnelUseCases(private val repository: PersonnelRepository) {
    val employees get() = repository.employees
    val payrolls get() = repository.payrolls
    val attendance get() = repository.attendance
    val leaves get() = repository.leaves
    val pendingLeaves get() = repository.pendingLeaves
    val payrollPolicies get() = repository.payrollPolicies
    val openAdvances get() = repository.openAdvances
    suspend fun saveEmployee(id: Long?, draft: EmployeeDraft) = repository.saveEmployee(id, draft)
    suspend fun deactivateEmployee(id: Long) = repository.deactivateEmployee(id)
    suspend fun savePayrollPolicy(draft: PayrollPolicyDraft) = repository.savePayrollPolicy(draft)
    suspend fun transitionEmploymentStatus(id: Long, to: EmploymentStatus, terminationEpochDay: Long? = null) = repository.transitionEmploymentStatus(id, to, terminationEpochDay)
    suspend fun privateProfile(employeeId: Long) = repository.privateProfile(employeeId)
    fun assignments(employeeId: Long) = repository.assignments(employeeId)
    fun contracts(employeeId: Long) = repository.contracts(employeeId)
    fun advances(employeeId: Long) = repository.advances(employeeId)
    suspend fun saveContract(id: Long?, draft: EmployeeContractDraft) = repository.saveContract(id, draft)
    suspend fun approveContract(id: Long) = repository.approveContract(id)
    suspend fun effectiveContract(employeeId: Long, day: Long) = repository.effectiveContract(employeeId, day)
    suspend fun postAdvance(draft: EmployeeAdvanceDraft) = repository.postAdvance(draft)
    suspend fun settleAdvance(id: Long, amountRial: Long, method: TreasuryChannel, day: Long) = repository.settleAdvance(id, amountRial, method, day)
}

class AttendanceUseCases(private val repository: PersonnelRepository) {
    val attendance get() = repository.attendance
    val leaves get() = repository.leaves
    val pendingLeaves get() = repository.pendingLeaves
    suspend fun save(id: Long?, draft: AttendanceDraft) = repository.saveAttendance(id, draft)
    suspend fun dailySummary(employeeId: Long, day: Long) = repository.attendanceSummaryV2(employeeId, day)
    suspend fun approveCorrection(id: Long) = repository.approveAttendanceCorrection(id)
    suspend fun summary(employeeId: Long, from: Long, to: Long) = repository.attendanceSummary(employeeId, from, to)
    suspend fun requestLeave(draft: LeaveDraft, requestedBy: String) = repository.requestLeave(draft, requestedBy)
    suspend fun grantLeave(draft: LeaveGrantDraft) = repository.grantLeave(draft)
    suspend fun leaveBalance(employeeId: Long, leaveType: LeaveType) = repository.leaveBalance(employeeId, leaveType)
    suspend fun reviewLeave(draft: LeaveReviewDraft) = repository.reviewLeave(draft)
    suspend fun cancelLeave(id: Long) = repository.cancelLeave(id)
    suspend fun approveLeave(draft: LeaveDraft) = repository.approveLeave(draft)
    suspend fun payrollAdjustment(employeeId: Long, from: Long, to: Long, policy: AttendancePayrollPolicy) = repository.attendancePayrollAdjustment(employeeId, from, to, policy)
}
