package ir.sabou.inventory.data.repository

import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

enum class DashboardPeriod { TODAY, WEEK, MONTH, CUSTOM }

data class DashboardWarehouseOption(
    val id: Long,
    val name: String,
)

data class DashboardSnapshot(
    val fromEpochDay: Long = 0,
    val toEpochDay: Long = 0,
    val period: DashboardPeriod = DashboardPeriod.TODAY,
    val selectedBranchName: String? = null,
    val selectedWarehouseLocationId: Long? = null,
    val availableBranches: List<String> = emptyList(),
    val availableWarehouses: List<DashboardWarehouseOption> = emptyList(),
    val inventoryValueRial: Long = 0,
    val supplierPayablesRial: Long = 0,
    val cashBalanceRial: Long = 0,
    val bankBalanceRial: Long = 0,
    val todayProfessionalInvoiceCount: Long = 0,
    val todayProfessionalReturnCount: Long = 0,
    val todayProfessionalSalesRial: Long = 0,
    val todayProfessionalGrossProfitRial: Long = 0,
    val customerReceivablesRial: Long = 0,
    val heldSaleCount: Long = 0,
    val grossSalesRial: Long = 0,
    val discountRial: Long = 0,
    val taxRial: Long = 0,
    val serviceRial: Long = 0,
    val salesReturnRial: Long = 0,
    val cogsRial: Long = 0,
    val purchaseRial: Long = 0,
    val purchaseReturnRial: Long = 0,
    val lowStockCount: Long = 0,
    val expiringLotCount: Long = 0,
    val wasteRial: Long = 0,
    val slowStockCount: Long = 0,
    val presentCount: Long = 0,
    val absentCount: Long = 0,
    val attendanceAnomalyCount: Long = 0,
    val unpaidPayrollRial: Long = 0,
    val assetBookValueRial: Long = 0,
    val accumulatedDepreciationRial: Long = 0,
    val dueMaintenanceCount: Long = 0,
)

class DashboardRepository(private val database: AppDatabase) {
    fun observeRange(
        fromEpochDay: Long,
        toEpochDay: Long,
        period: DashboardPeriod,
        branchName: String? = null,
        warehouseLocationId: Long? = null,
    ): Flow<DashboardSnapshot> {
        require(fromEpochDay > 0 && toEpochDay >= fromEpochDay)
        require(branchName == null || branchName.isNotBlank())
        require(warehouseLocationId == null || warehouseLocationId > 0)
        val analytics = database.dashboardAnalyticsDao().observeRange(
            fromEpochDay, toEpochDay, branchName, warehouseLocationId,
        )
        return combine(
            analytics,
            database.dashboardAnalyticsDao().observeBranches(),
            database.inventoryLocationDao().observeAll(),
        ) { row, branches, warehouses ->
            DashboardSnapshot(
                fromEpochDay = fromEpochDay,
                toEpochDay = toEpochDay,
                period = period,
                selectedBranchName = branchName,
                selectedWarehouseLocationId = warehouseLocationId,
                availableBranches = branches,
                availableWarehouses = warehouses.filter { it.isActive }.map { DashboardWarehouseOption(it.id, it.name) },
                inventoryValueRial = row.inventoryValueRial,
                supplierPayablesRial = row.supplierPayablesRial,
                cashBalanceRial = row.cashBalanceRial,
                bankBalanceRial = row.bankBalanceRial,
                todayProfessionalInvoiceCount = row.invoiceCount,
                todayProfessionalReturnCount = row.returnCount,
                todayProfessionalSalesRial = row.netSalesRial,
                todayProfessionalGrossProfitRial = SignedLongMath.subtract(row.netSalesRial, row.cogsRial),
                customerReceivablesRial = row.customerReceivablesRial,
                heldSaleCount = row.heldSaleCount,
                grossSalesRial = row.grossSalesRial,
                discountRial = row.discountRial,
                taxRial = row.taxRial,
                serviceRial = row.serviceRial,
                salesReturnRial = row.salesReturnRial,
                cogsRial = row.cogsRial,
                purchaseRial = row.purchaseRial,
                purchaseReturnRial = row.purchaseReturnRial,
                lowStockCount = row.lowStockCount,
                expiringLotCount = row.expiringLotCount,
                wasteRial = row.wasteRial,
                slowStockCount = row.slowStockCount,
                presentCount = row.presentCount,
                absentCount = row.absentCount,
                attendanceAnomalyCount = row.attendanceAnomalyCount,
                unpaidPayrollRial = row.unpaidPayrollRial,
                assetBookValueRial = row.assetBookValueRial,
                accumulatedDepreciationRial = row.accumulatedDepreciationRial,
                dueMaintenanceCount = row.dueMaintenanceCount,
            )
        }
    }
}
