package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import kotlinx.coroutines.flow.Flow

enum class SalesPaymentMethod(
    val title: String,
    val accountRole: SemanticAccountRole,
) {
    CASH("نقدی", SemanticAccountRole.CASH),
    CARD("کارتخوان", SemanticAccountRole.BANK),
    TRANSFER("حواله", SemanticAccountRole.BANK),
    CREDIT("اعتباری", SemanticAccountRole.CUSTOMER_RECEIVABLE),
}

enum class SalesInvoiceStatus(val storedValue: String) {
    POSTED("POSTED"),
    PARTIALLY_RETURNED("PARTIALLY_RETURNED"),
    RETURNED("RETURNED"),
    VOIDED("VOIDED"),
    LEGACY_UNKNOWN("LEGACY_UNKNOWN");

    companion object {
        fun fromStoredValue(value: String): SalesInvoiceStatus =
            entries.firstOrNull { it.storedValue == value } ?: LEGACY_UNKNOWN
    }
}

data class CustomerDraft(
    val name: String,
    val phone: String = "",
    val nationalId: String = "",
    val creditLimitRial: Long = 0,
    val notes: String = "",
    val mobile: String = "",
    val address: String = "",
    val branch: String = "",
    val paymentTermsDays: Int = 0,
    val status: String = "ACTIVE",
) {
    fun validated(): CustomerDraft {
        val normalizedName = name.trim()
        val normalizedPhone = phone.filter(Char::isDigit)
        val normalizedNationalId = nationalId.filter(Char::isDigit)
        require(normalizedName.length in 2..120) { "نام مشتری باید بین ۲ تا ۱۲۰ نویسه باشد." }
        require(normalizedPhone.isBlank() || normalizedPhone.length in 7..15) { "شماره تماس مشتری معتبر نیست." }
        require(normalizedNationalId.isBlank() || normalizedNationalId.length in 8..12) { "شناسه ملی/کد ملی مشتری معتبر نیست." }
        require(creditLimitRial >= 0) { "سقف اعتبار نمی‌تواند منفی باشد." }
        require(notes.trim().length <= 500) { "توضیحات مشتری بیش از حد طولانی است." }
        require(paymentTermsDays in 0..3650) { "مهلت پرداخت مشتری معتبر نیست." }
        require(status.trim().uppercase() in setOf("ACTIVE", "ON_HOLD", "INACTIVE")) { "وضعیت مشتری معتبر نیست." }
        return copy(
            name = normalizedName,
            phone = normalizedPhone,
            nationalId = normalizedNationalId,
            mobile = mobile.filter(Char::isDigit),
            address = address.trim(),
            branch = branch.trim(),
            status = status.trim().uppercase(),
            notes = notes.trim(),
        )
    }
}

data class CustomerRecord(
    val id: Long,
    val customerCode: String,
    val name: String,
    val phone: String,
    val nationalId: String,
    val creditLimitRial: Long,
    val outstandingRial: Long,
    val notes: String,
    val isActive: Boolean,
    val mobile: String = "",
    val address: String = "",
    val branch: String = "",
    val paymentTermsDays: Int = 0,
    val status: String = "ACTIVE",
)

data class SalesLineDraft(
    val menuItemId: Long,
    val quantity: QuantityMicros,
    val unitPrice: MoneyRial,
    val lineDiscount: MoneyRial = MoneyRial.ZERO,
)

data class SalesPaymentDraft(
    val method: SalesPaymentMethod,
    val amount: MoneyRial,
    val referenceNo: String = "",
) {
    fun validated(): SalesPaymentDraft {
        require(amount > MoneyRial.ZERO) { "مبلغ روش پرداخت باید بیشتر از صفر باشد." }
        require(referenceNo.trim().length <= 80) { "شماره پیگیری بیش از حد طولانی است." }
        return copy(referenceNo = referenceNo.trim())
    }
}

data class SalesInvoiceDraft(
    val businessEpochDay: Long,
    val branchName: String = "",
    val customerId: Long? = null,
    val dueEpochDay: Long? = null,
    val orderDiscount: MoneyRial = MoneyRial.ZERO,
    val service: MoneyRial = MoneyRial.ZERO,
    val tax: MoneyRial = MoneyRial.ZERO,
    val notes: String = "",
    val lines: List<SalesLineDraft>,
    val payments: List<SalesPaymentDraft>,
    val commandId: String = GlobalId.new().value,
    val creditOverrideReason: String = "",
) {
    fun normalized(): SalesInvoiceDraft {
        require(businessEpochDay > 0) { "تاریخ فروش معتبر نیست." }
        require(lines.isNotEmpty() && lines.size <= 200) { "فاکتور باید بین ۱ تا ۲۰۰ ردیف داشته باشد." }
        require(lines.all { it.menuItemId > 0 && it.quantity > QuantityMicros.ZERO && it.unitPrice > MoneyRial.ZERO }) {
            "ردیف فروش ناقص است."
        }
        require(lines.map { it.menuItemId }.distinct().size == lines.size) { "هر آیتم منو فقط یک بار در فاکتور مجاز است." }
        require(orderDiscount >= MoneyRial.ZERO && service >= MoneyRial.ZERO && tax >= MoneyRial.ZERO) { "مبالغ فاکتور نمی‌توانند منفی باشند." }
        require(notes.trim().length <= 500) { "توضیحات فاکتور بیش از حد طولانی است." }
        val normalizedPayments = payments.map(SalesPaymentDraft::validated)
        val hasCredit = normalizedPayments.any { it.method == SalesPaymentMethod.CREDIT }
        if (hasCredit) {
            require(customerId != null && customerId > 0) { "فروش اعتباری نیازمند انتخاب مشتری است." }
            require(dueEpochDay != null && dueEpochDay >= businessEpochDay) { "سررسید فروش اعتباری معتبر نیست." }
        }
        return copy(
            branchName = branchName.trim().take(80),
            notes = notes.trim(),
            creditOverrideReason = creditOverrideReason.trim(),
            payments = normalizedPayments,
            commandId = GlobalId.parse(commandId).value,
        )
    }
}

data class PostedSalesInvoice(
    val id: Long,
    val invoiceNo: String,
    val netRial: Long,
    val theoreticalCostRial: Long,
    val idempotentReplay: Boolean,
)

data class SalesInvoiceLineRecord(
    val id: Long,
    val menuItemId: Long,
    val recipeVersionId: Long,
    val name: String,
    val quantityMicros: Long,
    val unitPriceRial: Long,
    val grossRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netRial: Long,
    val theoreticalCostRial: Long,
    val returnedQuantityMicros: Long,
)

data class SalesPaymentRecord(
    val method: SalesPaymentMethod,
    val amountRial: Long,
    val referenceNo: String,
)

data class SalesInvoiceRecord(
    val id: Long,
    val invoiceNo: String,
    val businessEpochDay: Long,
    val customerName: String?,
    val grossRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netRial: Long,
    val theoreticalCostRial: Long,
    val status: SalesInvoiceStatus,
    val notes: String,
)

data class SalesInvoiceDetails(
    val invoice: SalesInvoiceRecord,
    val customerId: Long?,
    val dueEpochDay: Long?,
    val lines: List<SalesInvoiceLineRecord>,
    val payments: List<SalesPaymentRecord>,
) {
    val canVoid: Boolean get() = invoice.status == SalesInvoiceStatus.POSTED && lines.none { it.returnedQuantityMicros > 0 }
    val canReturn: Boolean get() = invoice.status == SalesInvoiceStatus.POSTED || invoice.status == SalesInvoiceStatus.PARTIALLY_RETURNED
}

data class SalesReturnLineDraft(
    val invoiceLineId: Long,
    val quantity: QuantityMicros,
)

data class SalesReturnDraft(
    val invoiceId: Long,
    val returnEpochDay: Long,
    val refundMethod: SalesPaymentMethod,
    val reason: String,
    val lines: List<SalesReturnLineDraft>,
    val commandId: String = GlobalId.new().value,
) {
    fun validated(): SalesReturnDraft {
        require(invoiceId > 0 && returnEpochDay > 0) { "فاکتور یا تاریخ برگشت معتبر نیست." }
        require(refundMethod != SalesPaymentMethod.CREDIT || invoiceId > 0) { "روش برگشت اعتبار معتبر نیست." }
        val normalizedReason = reason.trim()
        require(normalizedReason.length in 3..300) { "دلیل برگشت باید بین ۳ تا ۳۰۰ نویسه باشد." }
        require(lines.isNotEmpty() && lines.size <= 200) { "حداقل یک ردیف برای برگشت انتخاب کنید." }
        require(lines.map { it.invoiceLineId }.distinct().size == lines.size) { "ردیف برگشت تکراری است." }
        require(lines.all { it.invoiceLineId > 0 && it.quantity > QuantityMicros.ZERO }) { "مقدار برگشت نامعتبر است." }
        return copy(reason = normalizedReason, commandId = GlobalId.parse(commandId).value)
    }
}

data class PostedSalesReturn(
    val id: Long,
    val returnNo: String,
    val refundRial: Long,
    val idempotentReplay: Boolean,
)

data class SalesHoldDraft(
    val customerId: Long? = null,
    val orderDiscount: MoneyRial = MoneyRial.ZERO,
    val service: MoneyRial = MoneyRial.ZERO,
    val tax: MoneyRial = MoneyRial.ZERO,
    val notes: String = "",
    val lines: List<SalesLineDraft>,
    val commandId: String = GlobalId.new().value,
) {
    fun validated(): SalesHoldDraft {
        require(lines.isNotEmpty() && lines.size <= 200) { "سفارش نگه‌داشته‌شده باید ردیف داشته باشد." }
        require(lines.map { it.menuItemId }.distinct().size == lines.size) { "یک آیتم منو در سفارش چند بار تکرار شده است؛ مقدار همان ردیف را اصلاح کنید." }
        require(lines.all { it.menuItemId > 0 && it.quantity > QuantityMicros.ZERO && it.unitPrice > MoneyRial.ZERO }) { "ردیف سفارش نگه‌داشته‌شده معتبر نیست." }
        require(lines.all { it.lineDiscount >= MoneyRial.ZERO && it.lineDiscount <= it.unitPrice.times(it.quantity) }) { "تخفیف یکی از ردیف‌های سفارش معتبر نیست." }
        require(orderDiscount >= MoneyRial.ZERO && service >= MoneyRial.ZERO && tax >= MoneyRial.ZERO)
        require(notes.trim().length <= 500)
        val subtotal = lines.fold(MoneyRial.ZERO) { total, line -> total + (line.unitPrice.times(line.quantity) - line.lineDiscount) }
        require(orderDiscount <= subtotal) { "تخفیف کل سفارش از مبلغ ردیف‌ها بیشتر است." }
        return copy(notes = notes.trim(), commandId = GlobalId.parse(commandId).value)
    }
}

data class SalesHoldRecord(
    val id: Long,
    val holdNo: String,
    val customerName: String?,
    val notes: String,
    val lineCount: Int,
    val grossRial: Long,
    val createdAtEpochMillis: Long,
)

data class ProfessionalSalesDayClosureRecord(
    val businessEpochDay: Long,
    val netSalesRial: Long,
    val cogsRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val creditRial: Long,
    val invoiceCount: Int,
    val returnCount: Int,
    val status: String,
    val revisionNo: Int,
    val closedByName: String,
    val note: String,
    val reopenReason: String,
)

interface ProfessionalSalesRepository {
    val customers: Flow<List<CustomerRecord>>
    val holds: Flow<List<SalesHoldRecord>>
    val dayClosures: Flow<List<ProfessionalSalesDayClosureRecord>>
    fun observeInvoices(query: String = ""): Flow<List<SalesInvoiceRecord>>
    fun observeDetails(invoiceId: Long): Flow<SalesInvoiceDetails?>
    suspend fun saveCustomer(id: Long?, draft: CustomerDraft): Long
    suspend fun deactivateCustomer(id: Long)
    suspend fun post(draft: SalesInvoiceDraft): PostedSalesInvoice
    suspend fun returnSale(draft: SalesReturnDraft): PostedSalesReturn
    suspend fun voidInvoice(invoiceId: Long, voidEpochDay: Long, reason: String, commandId: String = GlobalId.new().value)
    suspend fun auditInvoicePrint(invoiceId: Long)
    suspend fun closeDay(businessEpochDay: Long, note: String = "")
    suspend fun reopenDay(businessEpochDay: Long, reason: String)
    suspend fun hold(draft: SalesHoldDraft): Long
    suspend fun deleteHold(id: Long)
    suspend fun loadHold(id: Long): SalesHoldDraft
}
