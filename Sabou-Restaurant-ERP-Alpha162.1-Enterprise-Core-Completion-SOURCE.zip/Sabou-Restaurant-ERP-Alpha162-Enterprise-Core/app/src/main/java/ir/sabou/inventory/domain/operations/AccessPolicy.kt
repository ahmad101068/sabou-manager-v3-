package ir.sabou.inventory.domain.operations

/** Compatibility aliases while call sites move to the security-owned boundary. */
typealias Permission = ir.sabou.inventory.domain.security.Permission
typealias UserRole = ir.sabou.inventory.domain.security.UserRole
