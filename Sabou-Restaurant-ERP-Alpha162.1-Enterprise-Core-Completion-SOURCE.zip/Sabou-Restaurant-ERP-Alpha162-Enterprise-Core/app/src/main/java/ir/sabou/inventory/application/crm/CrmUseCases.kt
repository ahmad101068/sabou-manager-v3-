package ir.sabou.inventory.application.crm

import ir.sabou.inventory.domain.crm.CustomerAccountService
import ir.sabou.inventory.domain.crm.CustomerOpeningBalanceCommand
import ir.sabou.inventory.domain.crm.CustomerReceivableAdjustmentCommand

class CrmUseCases(private val service: CustomerAccountService) {
    fun ledger(customerId: Long) = service.observeLedger(customerId)
    suspend fun aging(customerId: Long, todayEpochDay: Long) = service.aging(customerId, todayEpochDay)
    suspend fun duplicateCandidates(customerId: Long, phone: String, nationalId: String) = service.duplicateCandidates(customerId, phone, nationalId)
    suspend fun postOpeningBalance(command: CustomerOpeningBalanceCommand) = service.postOpeningBalance(command.validated())
    suspend fun postAdjustment(command: CustomerReceivableAdjustmentCommand) = service.postAdjustment(command.validated())
    suspend fun merge(sourceCustomerId: Long, targetCustomerId: Long, reason: String) = service.merge(sourceCustomerId, targetCustomerId, reason.trim())
}
