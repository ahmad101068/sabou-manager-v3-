package ir.sabou.inventory.core

import java.util.Calendar
import java.util.GregorianCalendar
import java.util.TimeZone

private const val MILLIS_PER_DAY = 86_400_000L
private val utcTimeZone: TimeZone = TimeZone.getTimeZone("UTC")

/** Returns today's local calendar date as an epoch day on every supported Android version. */
fun currentLocalEpochDay(): Long {
    val local = Calendar.getInstance()
    val utcMidnight = GregorianCalendar(utcTimeZone).apply {
        clear()
        set(
            local.get(Calendar.YEAR),
            local.get(Calendar.MONTH),
            local.get(Calendar.DAY_OF_MONTH),
            0,
            0,
            0,
        )
    }
    return utcMidnight.timeInMillis / MILLIS_PER_DAY
}
