package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.CorrelationId
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AttendanceCorrectionEntity
import ir.sabou.inventory.data.db.AttendanceEntity
import ir.sabou.inventory.data.db.AttendanceEventEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.personnel.AttendanceAggregationPolicy
import ir.sabou.inventory.domain.personnel.AttendanceCalculator
import ir.sabou.inventory.domain.personnel.AttendanceCorrectionCodec
import ir.sabou.inventory.domain.personnel.AttendanceCorrectionSnapshot
import ir.sabou.inventory.domain.personnel.AttendanceDraft
import ir.sabou.inventory.domain.personnel.AttendanceEvent
import ir.sabou.inventory.domain.personnel.AttendanceEventAggregator
import ir.sabou.inventory.domain.personnel.AttendanceEventType
import ir.sabou.inventory.domain.personnel.AttendancePayrollAdjustment
import ir.sabou.inventory.domain.personnel.AttendancePayrollCalculator
import ir.sabou.inventory.domain.personnel.AttendancePayrollPolicy
import ir.sabou.inventory.domain.personnel.AttendanceSource
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.DailyAttendanceStatus
import ir.sabou.inventory.domain.personnel.DailyAttendanceSummaryV2
import ir.sabou.inventory.domain.personnel.EmploymentStatus
import ir.sabou.inventory.domain.security.Permission
import ir.sabou.inventory.domain.security.SegregationOfDuties

/**
 * Owns attendance command/query rules so PersonnelRepository does not coordinate employee master,
 * attendance event sourcing, corrections, leave, advances, and legacy payroll in one God class.
 *
 * Every write remains transaction-bound to the shared Room database and keeps permission + audit
 * checks in the domain/data boundary rather than relying on UI visibility.
 */
internal class PersonnelAttendanceService(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val auditWriter: LocalAuditEventWriter,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    private val personnel get() = database.personnelDao()
    private val hr get() = database.hrPayrollDao()

    suspend fun save(id: Long?, draft: AttendanceDraft): Long {
        val actor = authorizer.require(Permission.PERSONNEL)
        val valid = draft.validated()
        val calculated = AttendanceCalculator.calculate(valid)
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            val employeeStatus = EmploymentStatus.fromStoredValue(employee.status)
            require(employeeStatus in setOf(EmploymentStatus.ACTIVE, EmploymentStatus.ON_LEAVE)) {
                "برای این وضعیت استخدام نمی‌توان حضور ثبت کرد."
            }
            require(employee.hireEpochDay == null || valid.workEpochDay >= employee.hireEpochDay) {
                "تاریخ حضور قبل از شروع همکاری است."
            }
            require(employee.terminationEpochDay == null || valid.workEpochDay <= employee.terminationEpochDay) {
                "تاریخ حضور بعد از خاتمه همکاری است."
            }
            require(!personnel.attendanceDayLocked(valid.employeeId, valid.workEpochDay)) {
                "دوره حقوق این روز نهایی شده و حضور و غیاب آن قفل است."
            }
            if (valid.status != "LEAVE") {
                require(!personnel.hasApprovedLeave(valid.employeeId, valid.workEpochDay)) {
                    "برای این روز مرخصی تأییدشده وجود دارد."
                }
            }

            val correlation = CorrelationId.forCommand("attendance", GlobalId.parse(valid.commandId)).value
            val baseKey = "attendance:${valid.commandId}:primary"
            hr.attendanceEventByIdempotencyKey(baseKey)?.let { replay ->
                val existing = personnel.attendanceByEmployeeDay(replay.employeeId, replay.businessEpochDay)
                    ?: error("Projection حضور برای فرمان تکراری پیدا نشد.")
                return@withTransaction existing.id
            }

            val entity = AttendanceEntity(
                id = id ?: 0,
                employeeId = valid.employeeId,
                workEpochDay = valid.workEpochDay,
                status = valid.status,
                checkInMinute = valid.checkInMinute,
                checkOutMinute = valid.checkOutMinute,
                lateMinutes = calculated.lateMinutes,
                overtimeMinutes = calculated.overtimeMinutes,
                notes = valid.notes,
            )

            if (id == null) {
                val attendanceId = personnel.insertAttendance(entity)
                appendInputEvents(valid, actor.id, correlation, baseKey)
                auditWriter.appendAuthorized(
                    authorizer, "CREATE", "ATTENDANCE", attendanceId, "ثبت حضور و غیاب روزانه",
                    clock(), valid.workEpochDay, valid.notes.ifBlank { "ثبت حضور" }, null,
                    snapshot(entity), correlation,
                )
                attendanceId
            } else {
                authorizer.require(Permission.ATTENDANCE_CORRECT)
                val current = personnel.attendanceById(id) ?: error("رکورد حضور پیدا نشد.")
                require(current.employeeId == valid.employeeId) { "پرسنل رکورد حضور قابل تغییر نیست." }
                require(valid.correctionReason.length >= 3) { "دلیل اصلاح حضور و غیاب الزامی است." }
                val before = snapshot(current)
                val after = snapshot(entity)
                val now = clock()
                val correctionId = hr.insertAttendanceCorrection(
                    AttendanceCorrectionEntity(
                        employeeId = valid.employeeId,
                        businessEpochDay = valid.workEpochDay,
                        idempotencyKey = "attendance_correction:${valid.commandId}",
                        beforeSnapshot = before,
                        afterSnapshot = after,
                        reason = valid.correctionReason,
                        status = if (valid.requiresApproval) "SUBMITTED" else "APPROVED",
                        requestedByActorId = actor.id,
                        approvedByActorId = actor.id.takeUnless { valid.requiresApproval },
                        requestedAtEpochMillis = now,
                        approvedAtEpochMillis = now.takeUnless { valid.requiresApproval },
                        correlationId = correlation,
                    ),
                )
                if (!valid.requiresApproval) {
                    check(personnel.updateAttendance(entity) == 1) { "اعمال Projection اصلاح حضور انجام نشد." }
                }
                hr.insertAttendanceEvent(
                    AttendanceEventEntity(
                        globalId = GlobalId.new().value,
                        idempotencyKey = baseKey,
                        employeeId = valid.employeeId,
                        eventType = AttendanceEventType.MANUAL_ADJUSTMENT.storedValue,
                        businessEpochDay = valid.workEpochDay,
                        timestampEpochMillis = now,
                        minuteOfDay = valid.checkInMinute ?: 0,
                        source = AttendanceSource.MANUAL.storedValue,
                        deviceId = null,
                        locationId = employee.locationId,
                        createdByActorId = actor.id,
                        reason = valid.correctionReason,
                        correlationId = correlation,
                    ),
                )
                auditWriter.appendAuthorized(
                    authorizer,
                    if (valid.requiresApproval) "CORRECTION_SUBMIT" else "CORRECT",
                    "ATTENDANCE",
                    id,
                    "اصلاح حضور و غیاب",
                    now,
                    valid.workEpochDay,
                    valid.correctionReason,
                    before,
                    after,
                    correlation,
                    "ATTENDANCE_CORRECTION",
                    correctionId,
                )
                id
            }
        }
    }

    suspend fun dailySummary(employeeId: Long, businessEpochDay: Long): DailyAttendanceSummaryV2 {
        authorizer.require(Permission.PERSONNEL)
        val employee = personnel.employeeById(employeeId) ?: error("پرسنل پیدا نشد.")
        hr.latestApprovedAttendanceCorrection(employeeId, businessEpochDay)?.let { correction ->
            return correction.toDailySummary()
        }
        val events = hr.attendanceEventsForDay(employeeId, businessEpochDay)
        if (events.isEmpty()) {
            personnel.attendanceByEmployeeDay(employeeId, businessEpochDay)?.let { return it.toDailySummaryV2() }
        }
        val contract = hr.effectiveContractCandidates(employeeId, businessEpochDay).singleOrNull()
        val startMinute = 8 * 60
        val endMinute = (startMinute + (contract?.standardDailyMinutes ?: 8 * 60)).coerceAtMost(24 * 60)
        return AttendanceEventAggregator.summarize(
            employeeId = employeeId,
            businessEpochDay = businessEpochDay,
            events = events.map { it.toAttendanceDomain() },
            policy = AttendanceAggregationPolicy(startMinute, endMinute),
            employmentFromEpochDay = employee.hireEpochDay ?: 1,
            employmentToEpochDay = employee.terminationEpochDay,
        )
    }

    suspend fun approveCorrection(correctionId: Long) {
        val actor = authorizer.require(Permission.ATTENDANCE_CORRECT)
        database.withTransaction {
            val correction = hr.attendanceCorrection(correctionId) ?: error("درخواست اصلاح حضور پیدا نشد.")
            if (correction.status == "APPROVED") return@withTransaction
            require(correction.status == "SUBMITTED") { "درخواست اصلاح در انتظار تأیید نیست." }
            SegregationOfDuties.requireDifferentActors(
                "ATTENDANCE_CORRECTION_APPROVAL", correction.requestedByActorId, actor.id,
            )
            val now = clock()
            require(!personnel.attendanceDayLocked(correction.employeeId, correction.businessEpochDay)) {
                "دوره حقوق این روز نهایی شده و اصلاح باید از مسیر revision حقوق انجام شود."
            }
            check(hr.approveAttendanceCorrection(correction.id, actor.id, now) == 1) { "تأیید اصلاح انجام نشد." }
            val correctionSnapshot = AttendanceCorrectionCodec.decode(correction.afterSnapshot)
            personnel.attendanceByEmployeeDay(correction.employeeId, correction.businessEpochDay)?.let { current ->
                check(
                    personnel.updateAttendance(
                        current.copy(
                            status = correctionSnapshot.status.toLegacyAttendanceStatus(),
                            checkInMinute = correctionSnapshot.firstInMinute,
                            checkOutMinute = correctionSnapshot.lastOutMinute,
                            lateMinutes = correctionSnapshot.lateMinutes,
                            overtimeMinutes = correctionSnapshot.overtimeMinutes,
                            notes = "اصلاح تأییدشده: ${correction.reason}",
                        ),
                    ) == 1,
                ) { "به‌روزرسانی Projection حضور پس از تأیید انجام نشد." }
            }
            auditWriter.appendAuthorized(
                authorizer, "CORRECTION_APPROVE", "ATTENDANCE", null, "تأیید اصلاح حضور و غیاب",
                now, correction.businessEpochDay, correction.reason, correction.beforeSnapshot,
                correction.afterSnapshot, correction.correlationId, "ATTENDANCE_CORRECTION", correction.id,
            )
        }
    }

    suspend fun summary(employeeId: Long, startEpochDay: Long, endEpochDay: Long): AttendanceSummary {
        authorizer.require(Permission.PERSONNEL)
        require(employeeId > 0 && startEpochDay > 0 && endEpochDay >= startEpochDay) { "بازه گزارش معتبر نیست." }
        val rows = personnel.attendanceInRange(employeeId, startEpochDay, endEpochDay)
        return AttendanceSummary(
            employeeId,
            startEpochDay,
            endEpochDay,
            presentDays = rows.count { it.status == "PRESENT" },
            absentDays = rows.count { it.status == "ABSENT" },
            leaveDays = rows.count { it.status == "LEAVE" },
            missionDays = rows.count { it.status == "MISSION" },
            workedMinutes = rows.sumOf { row ->
                if (row.checkInMinute != null && row.checkOutMinute != null) row.checkOutMinute - row.checkInMinute else 0
            },
            lateMinutes = rows.sumOf { it.lateMinutes },
            overtimeMinutes = rows.sumOf { it.overtimeMinutes },
        )
    }

    suspend fun payrollAdjustment(
        employeeId: Long,
        startEpochDay: Long,
        endEpochDay: Long,
        policy: AttendancePayrollPolicy,
    ): AttendancePayrollAdjustment = AttendancePayrollCalculator.calculate(
        summary(employeeId, startEpochDay, endEpochDay),
        policy,
    )

    private suspend fun appendInputEvents(
        draft: AttendanceDraft,
        actorId: Long,
        correlationId: String,
        baseIdempotencyKey: String,
    ) {
        suspend fun append(type: AttendanceEventType, minuteOfDay: Int, key: String, globalId: String) {
            hr.insertAttendanceEvent(
                AttendanceEventEntity(
                    globalId = globalId,
                    idempotencyKey = key,
                    employeeId = draft.employeeId,
                    eventType = type.storedValue,
                    businessEpochDay = draft.workEpochDay,
                    timestampEpochMillis = attendanceEventEpochMillis(draft.workEpochDay, minuteOfDay),
                    minuteOfDay = minuteOfDay,
                    source = draft.source.storedValue,
                    deviceId = null,
                    locationId = null,
                    createdByActorId = actorId,
                    reason = draft.notes.takeIf { it.isNotBlank() },
                    correlationId = correlationId,
                ),
            )
        }
        when (draft.status) {
            "PRESENT" -> {
                append(AttendanceEventType.CLOCK_IN, requireNotNull(draft.checkInMinute), baseIdempotencyKey, draft.commandId)
                append(
                    AttendanceEventType.CLOCK_OUT,
                    requireNotNull(draft.checkOutMinute),
                    "$baseIdempotencyKey:clock_out",
                    GlobalId.new().value,
                )
            }
            "ABSENT" -> append(AttendanceEventType.ABSENCE_MARK, 0, baseIdempotencyKey, draft.commandId)
            "LEAVE", "MISSION", "HOLIDAY" -> append(
                AttendanceEventType.MANUAL_ADJUSTMENT,
                draft.checkInMinute ?: 0,
                baseIdempotencyKey,
                draft.commandId,
            )
            else -> error("attendance_status_not_exhaustive:${draft.status}")
        }
    }
}

private fun AttendanceEventEntity.toAttendanceDomain() = AttendanceEvent(
    id = id,
    employeeId = employeeId,
    eventType = AttendanceEventType.fromStoredValue(eventType),
    businessEpochDay = businessEpochDay,
    timestampEpochMillis = timestampEpochMillis,
    minuteOfDay = minuteOfDay,
    source = AttendanceSource.fromStoredValue(source),
    deviceId = deviceId,
    locationId = locationId,
    createdByActorId = createdByActorId,
    reason = reason,
    correlationId = CorrelationId.parse(correlationId),
)

private fun AttendanceCorrectionEntity.toDailySummary(): DailyAttendanceSummaryV2 {
    val snapshot = AttendanceCorrectionCodec.decode(afterSnapshot)
    return DailyAttendanceSummaryV2(
        employeeId = employeeId,
        businessEpochDay = businessEpochDay,
        firstInMinute = snapshot.firstInMinute,
        lastOutMinute = snapshot.lastOutMinute,
        workedMinutes = snapshot.workedMinutes,
        breakMinutes = snapshot.breakMinutes,
        lateMinutes = snapshot.lateMinutes,
        earlyLeaveMinutes = snapshot.earlyLeaveMinutes,
        overtimeMinutes = snapshot.overtimeMinutes,
        absenceMinutes = snapshot.absenceMinutes,
        paidLeaveMinutes = 0,
        unpaidLeaveMinutes = 0,
        status = snapshot.status,
        anomalies = emptyList(),
        source = AttendanceSource.MANUAL,
    )
}

private fun AttendanceEntity.toDailySummaryV2(): DailyAttendanceSummaryV2 {
    val worked = if (checkInMinute != null && checkOutMinute != null) checkOutMinute - checkInMinute else 0
    val typedStatus = when (status) {
        "PRESENT" -> DailyAttendanceStatus.PRESENT
        "ABSENT" -> DailyAttendanceStatus.ABSENT
        "MISSION" -> DailyAttendanceStatus.MISSION
        "HOLIDAY" -> DailyAttendanceStatus.HOLIDAY
        "LEAVE" -> DailyAttendanceStatus.INCOMPLETE
        else -> DailyAttendanceStatus.INCOMPLETE
    }
    return DailyAttendanceSummaryV2(
        employeeId = employeeId,
        businessEpochDay = workEpochDay,
        firstInMinute = checkInMinute,
        lastOutMinute = checkOutMinute,
        workedMinutes = worked,
        breakMinutes = 0,
        lateMinutes = lateMinutes,
        earlyLeaveMinutes = 0,
        overtimeMinutes = overtimeMinutes,
        absenceMinutes = if (typedStatus == DailyAttendanceStatus.ABSENT) 8 * 60 else 0,
        paidLeaveMinutes = 0,
        unpaidLeaveMinutes = 0,
        status = typedStatus,
        anomalies = emptyList(),
        source = AttendanceSource.LEGACY,
    )
}

private fun snapshot(entity: AttendanceEntity): String = AttendanceCorrectionCodec.encode(
    AttendanceCorrectionSnapshot(
        firstInMinute = entity.checkInMinute,
        lastOutMinute = entity.checkOutMinute,
        workedMinutes = if (entity.checkInMinute != null && entity.checkOutMinute != null) {
            entity.checkOutMinute - entity.checkInMinute
        } else {
            0
        },
        breakMinutes = 0,
        lateMinutes = entity.lateMinutes,
        earlyLeaveMinutes = 0,
        overtimeMinutes = entity.overtimeMinutes,
        absenceMinutes = if (entity.status == "ABSENT") 8 * 60 else 0,
        status = when (entity.status) {
            "PRESENT" -> DailyAttendanceStatus.PRESENT
            "ABSENT" -> DailyAttendanceStatus.ABSENT
            "MISSION" -> DailyAttendanceStatus.MISSION
            "HOLIDAY" -> DailyAttendanceStatus.HOLIDAY
            "LEAVE" -> DailyAttendanceStatus.INCOMPLETE
            else -> DailyAttendanceStatus.INCOMPLETE
        },
    ),
)

private fun DailyAttendanceStatus.toLegacyAttendanceStatus(): String = when (this) {
    DailyAttendanceStatus.PRESENT -> "PRESENT"
    DailyAttendanceStatus.ABSENT -> "ABSENT"
    DailyAttendanceStatus.PAID_LEAVE, DailyAttendanceStatus.UNPAID_LEAVE -> "LEAVE"
    DailyAttendanceStatus.MISSION -> "MISSION"
    DailyAttendanceStatus.HOLIDAY -> "HOLIDAY"
    DailyAttendanceStatus.INCOMPLETE, DailyAttendanceStatus.ANOMALY -> "PRESENT"
}

private fun attendanceEventEpochMillis(epochDay: Long, minuteOfDay: Int): Long = SignedLongMath.add(
    SignedLongMath.multiply(epochDay, 86_400_000L),
    SignedLongMath.multiply(minuteOfDay.toLong(), 60_000L),
)
