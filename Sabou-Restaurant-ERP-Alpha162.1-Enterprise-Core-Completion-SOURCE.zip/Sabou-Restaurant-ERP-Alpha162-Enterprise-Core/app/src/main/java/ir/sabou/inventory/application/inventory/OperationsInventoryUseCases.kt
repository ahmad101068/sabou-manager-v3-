package ir.sabou.inventory.application.inventory

import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodCloseDraft
import ir.sabou.inventory.domain.operations.InventoryPeriodReopenDraft
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.SensitiveAction
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.WasteDraft

/**
 * Application boundary for the still-active legacy Operations inventory surface.
 *
 * The modern InventoryWorkspace uses [InventoryUseCases]. This boundary prevents the older
 * OperationsViewModel from bypassing application policy while that presentation surface remains
 * reachable. Validation and sensitive-action authorization happen here before repository commands.
 */
class OperationsInventoryUseCases(
    private val operations: OperationsRepository,
    private val security: SecurityRepository,
) {
    suspend fun saveSupplier(id: Long?, draft: SupplierDraft): Long {
        val valid = draft.validated()
        return if (id == null) operations.createSupplier(valid) else {
            require(id > 0) { "شناسه تأمین‌کننده معتبر نیست." }
            operations.updateSupplier(id, valid)
            id
        }
    }

    suspend fun deactivateSupplier(id: Long) {
        require(id > 0) { "شناسه تأمین‌کننده معتبر نیست." }
        operations.deactivateSupplier(id)
    }

    suspend fun saveInventoryItem(id: Long?, draft: InventoryItemDraft): Long {
        val valid = draft.validated()
        return if (id == null) operations.createInventoryItem(valid) else {
            require(id > 0) { "شناسه کالا معتبر نیست." }
            operations.updateInventoryItem(id, valid)
            id
        }
    }

    suspend fun deactivateInventoryItem(id: Long) {
        require(id > 0) { "شناسه کالا معتبر نیست." }
        operations.deactivateInventoryItem(id)
    }

    suspend fun postInventoryCount(draft: InventoryCountDraft, pin: String): Long {
        security.authorizeSensitiveAction(SensitiveAction.ADJUST_INVENTORY, pin)
        return operations.postInventoryCount(draft.validated())
    }

    suspend fun closeInventoryPeriod(draft: InventoryPeriodCloseDraft, pin: String): Long {
        security.authorizeSensitiveAction(SensitiveAction.CLOSE_INVENTORY_PERIOD, pin)
        return operations.closeInventoryPeriod(draft.validated())
    }

    suspend fun reopenInventoryPeriod(closureId: Long, reason: String, pin: String) {
        val valid = InventoryPeriodReopenDraft(closureId, reason).validated()
        security.authorizeSensitiveAction(SensitiveAction.REOPEN_INVENTORY_PERIOD, pin)
        operations.reopenInventoryPeriod(valid)
    }

    suspend fun postWaste(draft: WasteDraft): Long = operations.postWaste(draft.validated())
}
