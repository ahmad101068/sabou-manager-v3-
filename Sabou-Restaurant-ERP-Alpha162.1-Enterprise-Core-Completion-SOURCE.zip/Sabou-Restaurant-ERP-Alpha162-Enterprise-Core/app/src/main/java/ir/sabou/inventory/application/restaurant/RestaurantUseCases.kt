package ir.sabou.inventory.application.restaurant

import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.domain.restaurant.KitchenTicketStatus
import ir.sabou.inventory.domain.restaurant.OpenTableCommand
import ir.sabou.inventory.domain.restaurant.RestaurantOrderLineDraft
import ir.sabou.inventory.domain.restaurant.RestaurantPaymentSplit
import ir.sabou.inventory.domain.restaurant.RestaurantReservationStatus
import ir.sabou.inventory.domain.restaurant.RestaurantService
import ir.sabou.inventory.domain.restaurant.TableReservationDraft

/** Presentation-neutral application boundary for table service and KDS. */
class RestaurantUseCases(private val service: RestaurantService) {
    val halls get() = service.halls
    val tables get() = service.tables
    val reservations get() = service.reservations
    val openOrders get() = service.openOrders
    val kitchenTickets get() = service.kitchenTickets
    fun orderLines(orderId: Long) = service.observeOrderLines(orderId)

    suspend fun createHall(name: String) = service.createHall(name)
    suspend fun createTable(hallId: Long, tableNo: String, capacity: Int) = service.createTable(hallId, tableNo, capacity)
    suspend fun reserve(draft: TableReservationDraft) = service.reserve(draft)
    suspend fun transitionReservation(reservationId: Long, to: RestaurantReservationStatus, reason: String = "") = service.transitionReservation(reservationId, to, reason)
    suspend fun openTable(command: OpenTableCommand) = service.openTable(command)
    suspend fun addItem(draft: RestaurantOrderLineDraft) = service.addItem(draft)
    suspend fun changeQuantity(lineId: Long, quantity: QuantityMicros) = service.changeQuantity(lineId, quantity)
    suspend fun transferTable(orderId: Long, targetTableId: Long, reason: String) = service.transferTable(orderId, targetTableId, reason)
    suspend fun mergeTables(sourceOrderId: Long, targetOrderId: Long, reason: String) = service.mergeTables(sourceOrderId, targetOrderId, reason)
    suspend fun transitionKitchen(ticketId: Long, to: KitchenTicketStatus, reason: String = "") = service.transitionKitchen(ticketId, to, reason)
    suspend fun closeTable(orderId: Long, payments: List<RestaurantPaymentSplit>, dueEpochDay: Long? = null) = service.closeTable(orderId, payments, dueEpochDay)
}
