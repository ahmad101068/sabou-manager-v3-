package ir.sabou.inventory.domain.restaurant

import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.domain.sales.PostedSalesInvoice
import ir.sabou.inventory.domain.sales.SalesPaymentMethod
import kotlinx.coroutines.flow.Flow

enum class RestaurantTableStatus { AVAILABLE, RESERVED, OCCUPIED }
enum class RestaurantReservationStatus { BOOKED, CONFIRMED, SEATED, COMPLETED, CANCELLED, NO_SHOW }
enum class RestaurantOrderStatus { OPEN, CLOSED, MERGED, CANCELLED }
enum class RestaurantCourse { STARTER, MAIN, DESSERT, DRINK }
enum class KitchenTicketStatus { NEW, ACCEPTED, PREPARING, READY, SERVED, CANCELLED }

data class RestaurantHallRecord(val id: Long, val name: String, val sortOrder: Int)

data class RestaurantTableRecord(
    val id: Long,
    val hallId: Long,
    val tableNo: String,
    val capacity: Int,
    val status: RestaurantTableStatus,
    val currentOrderId: Long?,
)

data class RestaurantReservationRecord(
    val id: Long,
    val customerId: Long?,
    val guestName: String,
    val guestPhone: String,
    val reservationEpochDay: Long,
    val startMinuteOfDay: Int,
    val guestCount: Int,
    val tableId: Long,
    val status: RestaurantReservationStatus,
    val note: String,
)

data class RestaurantOrderRecord(
    val id: Long,
    val tableId: Long,
    val waiterUserId: Long?,
    val shiftReference: String,
    val customerId: Long?,
    val guestCount: Int,
    val status: RestaurantOrderStatus,
    val openedEpochDay: Long,
)

data class RestaurantOrderLineRecord(
    val id: Long,
    val orderId: Long,
    val menuItemId: Long,
    val name: String,
    val course: RestaurantCourse,
    val quantity: QuantityMicros,
    val unitPrice: MoneyRial,
    val note: String,
)

data class KitchenTicketRecord(
    val id: Long,
    val orderLineId: Long,
    val status: KitchenTicketStatus,
    val updatedAtEpochMillis: Long,
)

data class TableReservationDraft(
    val tableId: Long,
    val customerId: Long? = null,
    val guestName: String,
    val guestPhone: String = "",
    val reservationEpochDay: Long,
    val startMinuteOfDay: Int,
    val guestCount: Int,
    val note: String = "",
) {
    fun validated(): TableReservationDraft {
        require(tableId > 0 && reservationEpochDay > 0)
        require(startMinuteOfDay in 0..1439)
        require(guestCount in 1..100)
        require(guestName.trim().length in 2..120)
        require(guestPhone.filter(Char::isDigit).length <= 15)
        require(note.trim().length <= 500)
        return copy(guestName = guestName.trim(), guestPhone = guestPhone.filter(Char::isDigit), note = note.trim())
    }
}

data class OpenTableCommand(
    val tableId: Long,
    val guestCount: Int,
    val waiterUserId: Long? = null,
    val shiftReference: String = "",
    val customerId: Long? = null,
    val note: String = "",
    val commandId: String = GlobalId.new().value,
)

data class RestaurantOrderLineDraft(
    val orderId: Long,
    val menuItemId: Long,
    val quantity: QuantityMicros,
    val course: RestaurantCourse = RestaurantCourse.MAIN,
    val note: String = "",
)

data class RestaurantPaymentSplit(
    val payerNo: Int,
    val method: SalesPaymentMethod,
    val amount: MoneyRial,
    val referenceNo: String = "",
    val orderLineId: Long? = null,
) {
    fun validated(): RestaurantPaymentSplit {
        require(payerNo > 0)
        require(amount > MoneyRial.ZERO)
        require(referenceNo.trim().length <= 80)
        return copy(referenceNo = referenceNo.trim())
    }
}

interface RestaurantService {
    val halls: Flow<List<RestaurantHallRecord>>
    val tables: Flow<List<RestaurantTableRecord>>
    val reservations: Flow<List<RestaurantReservationRecord>>
    val openOrders: Flow<List<RestaurantOrderRecord>>
    val kitchenTickets: Flow<List<KitchenTicketRecord>>
    fun observeOrderLines(orderId: Long): Flow<List<RestaurantOrderLineRecord>>

    suspend fun createHall(name: String): Long
    suspend fun createTable(hallId: Long, tableNo: String, capacity: Int): Long
    suspend fun reserve(draft: TableReservationDraft): Long
    suspend fun transitionReservation(reservationId: Long, to: RestaurantReservationStatus, reason: String = "")
    suspend fun openTable(command: OpenTableCommand): Long
    suspend fun addItem(draft: RestaurantOrderLineDraft): Long
    suspend fun changeQuantity(lineId: Long, quantity: QuantityMicros)
    suspend fun transferTable(orderId: Long, targetTableId: Long, reason: String)
    suspend fun mergeTables(sourceOrderId: Long, targetOrderId: Long, reason: String)
    suspend fun transitionKitchen(ticketId: Long, to: KitchenTicketStatus, reason: String = "")
    suspend fun closeTable(orderId: Long, payments: List<RestaurantPaymentSplit>, dueEpochDay: Long? = null): PostedSalesInvoice
}
