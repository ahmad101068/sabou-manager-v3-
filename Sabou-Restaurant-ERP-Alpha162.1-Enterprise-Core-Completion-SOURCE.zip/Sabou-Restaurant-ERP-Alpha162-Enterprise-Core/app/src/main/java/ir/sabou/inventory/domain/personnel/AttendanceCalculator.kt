package ir.sabou.inventory.domain.personnel

object AttendanceCalculator {
    data class Result(val workedMinutes: Int, val lateMinutes: Int, val overtimeMinutes: Int)

    fun calculate(draft: AttendanceDraft): Result {
        val valid = draft.validated()
        if (valid.status != "PRESENT") return Result(0, 0, 0)
        val checkIn = requireNotNull(valid.checkInMinute)
        val checkOut = requireNotNull(valid.checkOutMinute)
        val worked = checkOut - checkIn
        val late = (checkIn - valid.scheduledStartMinute).coerceAtLeast(0)
        val overtime = (checkOut - valid.scheduledEndMinute).coerceAtLeast(0)
        return Result(worked, late, overtime)
    }
}
