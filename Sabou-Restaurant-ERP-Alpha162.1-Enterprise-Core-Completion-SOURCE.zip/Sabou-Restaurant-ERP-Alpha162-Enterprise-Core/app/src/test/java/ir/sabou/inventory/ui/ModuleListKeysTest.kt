package ir.sabou.inventory.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class ModuleListKeysTest {
    @Test
    fun crmRowTypesNeverShareAComposeKey() {
        assertNotEquals(crmCustomerListKey(1), crmFollowUpListKey(1))
    }

    @Test
    fun restaurantRowTypesNeverShareAComposeKey() {
        val keys = setOf(
            restaurantTableListKey(1),
            restaurantTicketListKey(1),
            restaurantApprovalListKey(1),
            restaurantShiftListKey(1),
        )
        assertEquals(4, keys.size)
    }
}
