package ir.sabou.inventory.ui

import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.DomainFailure
import ir.sabou.inventory.domain.common.JournalInvalidReason
import org.junit.Assert.assertTrue
import org.junit.Test

class DomainFailureMappingTest {
    @Test
    fun typedAccountingFailureGetsActionablePersianTextOnlyAtPresentationBoundary() {
        val failure: DomainFailure = BusinessError.InvalidJournal(JournalInvalidReason.UNBALANCED)

        val message = UiErrorHandler.run { failure.toPersianMessage() }

        assertTrue(message.contains("سند حسابداری"))
        assertTrue(message.contains("بدهکار/بستانکار"))
    }
}
