package ir.sabou.inventory.ui

import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.UserRole
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AppScreenAccessTest {
    @Test
    fun `cashier can open reports granted by its role without seeing accounting alerts`() {
        val cashier = AppUserRecord(
            id = 1,
            username = "cashier",
            displayName = "صندوقدار",
            role = UserRole.CASHIER,
            isActive = true,
            hasRecoveryCode = false,
        )

        assertTrue(canOpenScreen(cashier, AppScreen.REPORTS))
        assertFalse(canOpenScreen(cashier, AppScreen.ALERTS))
        assertFalse(canOpenScreen(cashier, AppScreen.ACCOUNTING))
    }
}
