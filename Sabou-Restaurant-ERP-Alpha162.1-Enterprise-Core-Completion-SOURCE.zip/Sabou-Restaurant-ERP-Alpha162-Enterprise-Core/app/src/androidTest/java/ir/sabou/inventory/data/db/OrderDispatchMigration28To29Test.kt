package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class OrderDispatchMigration28To29Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val name = "order-dispatch-migration-28-29.db"
    @After fun cleanUp() { context.deleteDatabase(name) }

    @Test fun addsDispatchStateAndKeepsExistingOrder() {
        open(28).use { helper ->
            helper.writableDatabase.execSQL("CREATE TABLE purchase_orders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, orderNo TEXT NOT NULL)")
            helper.writableDatabase.execSQL("INSERT INTO purchase_orders(orderNo) VALUES('PO-OLD')")
        }
        open(29).use { helper ->
            helper.writableDatabase.query("SELECT orderNo, sentAtEpochMillis, acknowledgedAtEpochMillis, supplierConfirmationNo, confirmedExpectedEpochDay FROM purchase_orders").use { cursor ->
                assertTrue(cursor.moveToFirst()); assertEquals("PO-OLD", cursor.getString(0)); assertTrue(cursor.isNull(1)); assertTrue(cursor.isNull(2)); assertTrue(cursor.isNull(3)); assertTrue(cursor.isNull(4))
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) { if (oldVersion == 28 && newVersion == 29) MIGRATION_28_29.migrate(db) }
        }
        return FrameworkSQLiteOpenHelperFactory().create(SupportSQLiteOpenHelper.Configuration.builder(context).name(name).callback(callback).build())
    }
}
