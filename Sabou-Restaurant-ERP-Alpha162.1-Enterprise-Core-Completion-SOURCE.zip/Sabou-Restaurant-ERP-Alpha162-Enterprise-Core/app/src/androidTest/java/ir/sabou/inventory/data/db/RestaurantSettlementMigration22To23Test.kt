package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class RestaurantSettlementMigration22To23Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "restaurant-settlement-migration-22-23.db"

    @After fun cleanUp() { context.deleteDatabase(databaseName) }

    @Test
    fun addsSettlementTablesAndKeepsExistingOrderLine() {
        open(22).use { helper ->
            val db = helper.writableDatabase
            db.execSQL("CREATE TABLE kitchen_tickets (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,orderNo TEXT NOT NULL)")
            db.execSQL("CREATE TABLE table_order_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,itemName TEXT NOT NULL)")
            db.execSQL("INSERT INTO table_order_lines(itemName) VALUES ('کباب')")
        }
        open(23).use { helper ->
            val db = helper.writableDatabase
            db.query("SELECT itemName,voidReason FROM table_order_lines").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("کباب", cursor.getString(0))
                assertTrue(cursor.isNull(1))
            }
            listOf("bill_splits", "bill_split_lines", "cash_shifts").forEach { table ->
                db.query("SELECT COUNT(*) FROM $table").use { cursor -> assertTrue(cursor.moveToFirst()) }
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 22 && newVersion == 23) MIGRATION_22_23.migrate(db)
            }
        }
        return FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(databaseName).callback(callback).build(),
        )
    }
}
