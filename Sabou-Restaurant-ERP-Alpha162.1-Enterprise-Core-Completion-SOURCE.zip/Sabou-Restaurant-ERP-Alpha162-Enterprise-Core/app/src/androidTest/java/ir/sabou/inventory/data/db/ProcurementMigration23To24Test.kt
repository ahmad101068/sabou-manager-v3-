package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ProcurementMigration23To24Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "procurement-migration-23-24.db"

    @After fun cleanUp() { context.deleteDatabase(databaseName) }

    @Test
    fun addsProcurementWorkflowAndKeepsLegacySupplier() {
        open(23).use { helper ->
            val db = helper.writableDatabase
            db.execSQL("CREATE TABLE suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL)")
            db.execSQL("INSERT INTO suppliers(name) VALUES ('تأمین نمونه')")
        }
        open(24).use { helper ->
            val db = helper.writableDatabase
            db.query("SELECT name FROM suppliers").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("تأمین نمونه", cursor.getString(0))
            }
            listOf(
                "purchase_requisitions",
                "purchase_requisition_lines",
                "purchase_orders",
                "purchase_order_lines",
                "goods_receipts",
                "goods_receipt_lines",
                "procurement_invoice_links",
            ).forEach { table ->
                db.query("SELECT COUNT(*) FROM $table").use { cursor -> assertTrue(cursor.moveToFirst()) }
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 23 && newVersion == 24) MIGRATION_23_24.migrate(db)
            }
        }
        return FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(databaseName).callback(callback).build(),
        )
    }
}
