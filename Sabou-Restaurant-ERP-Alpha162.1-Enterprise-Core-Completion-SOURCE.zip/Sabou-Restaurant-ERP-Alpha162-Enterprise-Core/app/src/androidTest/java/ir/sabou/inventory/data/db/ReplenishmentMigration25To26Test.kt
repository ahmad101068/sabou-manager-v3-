package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ReplenishmentMigration25To26Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "replenishment-migration-25-26.db"

    @After fun cleanUp() { context.deleteDatabase(databaseName) }

    @Test
    fun addsReplenishmentPoliciesAndKeepsExistingData() {
        open(25).use { helper ->
            val db = helper.writableDatabase
            db.execSQL("CREATE TABLE legacy_marker (id INTEGER PRIMARY KEY NOT NULL, value TEXT NOT NULL)")
            db.execSQL("INSERT INTO legacy_marker(id, value) VALUES (1, 'محفوظ')")
        }
        open(26).use { helper ->
            val db = helper.writableDatabase
            db.query("SELECT value FROM legacy_marker WHERE id = 1").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("محفوظ", cursor.getString(0))
            }
            db.query("PRAGMA table_info(inventory_replenishment_policies)").use { cursor ->
                val columns = mutableSetOf<String>()
                while (cursor.moveToNext()) columns += cursor.getString(cursor.getColumnIndexOrThrow("name"))
                assertTrue(columns.containsAll(setOf("itemId", "preferredSupplierId", "targetCoverDays", "leadTimeDays", "safetyStockMicros", "orderMultipleMicros", "isEnabled")))
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 25 && newVersion == 26) MIGRATION_25_26.migrate(db)
            }
        }
        return FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(databaseName).callback(callback).build(),
        )
    }
}
