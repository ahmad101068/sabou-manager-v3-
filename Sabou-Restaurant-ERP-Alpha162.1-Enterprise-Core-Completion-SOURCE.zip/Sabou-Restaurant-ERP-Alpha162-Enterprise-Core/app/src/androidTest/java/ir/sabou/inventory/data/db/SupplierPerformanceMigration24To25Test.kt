package ir.sabou.inventory.data.db

import android.content.Context
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SupplierPerformanceMigration24To25Test {
    private val context = ApplicationProvider.getApplicationContext<Context>()
    private val databaseName = "supplier-performance-migration-24-25.db"

    @After fun cleanUp() { context.deleteDatabase(databaseName) }

    @Test
    fun addsReturnsAndPreservesExistingOrderLine() {
        open(24).use { helper ->
            val db = helper.writableDatabase
            db.execSQL("CREATE TABLE purchase_order_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, purchaseOrderId INTEGER NOT NULL, itemId INTEGER NOT NULL, itemNameSnapshot TEXT NOT NULL, orderedQtyMicros INTEGER NOT NULL, unitCostRial INTEGER NOT NULL, receivedQtyMicros INTEGER NOT NULL, rejectedQtyMicros INTEGER NOT NULL)")
            db.execSQL("INSERT INTO purchase_order_lines(purchaseOrderId,itemId,itemNameSnapshot,orderedQtyMicros,unitCostRial,receivedQtyMicros,rejectedQtyMicros) VALUES (1,2,'قهوه',1000000,500000,1000000,0)")
        }
        open(25).use { helper ->
            val db = helper.writableDatabase
            db.query("SELECT itemNameSnapshot,returnedQtyMicros FROM purchase_order_lines").use { cursor ->
                assertTrue(cursor.moveToFirst())
                assertEquals("قهوه", cursor.getString(0))
                assertEquals(0L, cursor.getLong(1))
            }
            listOf("purchase_returns", "purchase_return_lines", "supplier_credits").forEach { table ->
                db.query("SELECT COUNT(*) FROM $table").use { cursor -> assertTrue(cursor.moveToFirst()) }
            }
        }
    }

    private fun open(version: Int): SupportSQLiteOpenHelper {
        val callback = object : SupportSQLiteOpenHelper.Callback(version) {
            override fun onCreate(db: SupportSQLiteDatabase) = Unit
            override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
                if (oldVersion == 24 && newVersion == 25) MIGRATION_24_25.migrate(db)
            }
        }
        return FrameworkSQLiteOpenHelperFactory().create(
            SupportSQLiteOpenHelper.Configuration.builder(context).name(databaseName).callback(callback).build(),
        )
    }
}
