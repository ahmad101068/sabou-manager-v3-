# Changelog — Alpha158 Foundation Hardening

## Added

- ordered `ALL_MIGRATIONS` registry and physically separated migration/lifecycle/seed files
- `AccountingPostingService`, `TreasuryService`, `AuthorizationService`, `AuditService`
- validated `CorrelationId` and structured `DomainFailure` extensions
- typed treasury/payment adapters and compatibility treasury account catalog
- exact-payload goods-receipt idempotency and transaction/audit integration coverage
- procurement receiving/return and invoice-matching workflow services behind the compatibility facade
- domain-oriented Operations and Accounting screen files and six navigation route groups
- maintainable architecture verification rules and five TASK 01-B technical reports

## Changed

- `AppDatabase.kt` reduced from 1,786 to 171 lines without changing migration SQL or schema 42
- `LocalProcurementRepository.kt` reduced to 820 lines while preserving `ProcurementRepository`
- `OperationsScreens.kt`, `AccountingScreens.kt`, and `SabouApp.kt` decomposed without UX redesign
- payment channel, stock movement/reference and selected document-control read states are typed
- accounting posts and clean reversals write append-only audit events in the posting transaction
- version advanced to `3.0.0-alpha158.0-foundation-hardening` / `versionCode 201`

## Database

- no schema version change
- no entity, column, index, foreign key, trigger or migration SQL change
- no destructive fallback
- complete migration chain 1→42 retained

## Verification status

- architecture script, Kotlin syntax parser, migration source parity and `git diff --check`: executed
- Gradle unit tests, lint, KSP/Room verification, APK build and Android instrumentation: NOT EXECUTED
  in the local environment; GitHub CI is the release gate

