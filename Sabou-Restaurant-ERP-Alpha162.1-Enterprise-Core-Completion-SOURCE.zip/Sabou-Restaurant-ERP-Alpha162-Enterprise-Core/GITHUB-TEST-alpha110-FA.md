# آزمون نسخه alpha110 در GitHub

محتوای این ZIP را جایگزین نسخه قبلی مخزن کنید و گردش‌کار Build را اجرا کنید.
پس از موفقیت، فایل APK در Artifact زیر قرار می‌گیرد:

`sabou-manager-alpha110-debug-apk-<run number>`

اگر اجرا شکست خورد، ZIP کامل Logs همان اجرا را ارسال کنید.
