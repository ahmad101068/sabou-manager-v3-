# وضعیت فعلی پروژه

نسخه Candidate: `3.0.0-alpha159.0-inventory-2`

`versionCode: 202` · `Room schema: 43` · تاریخ گزارش: 2026-08-09

## نتیجه Increment

- Foundation Alpha158 بدون ایجاد Accounting/Treasury/Security/Audit موازی حفظ شده است.
- Item Master، SKU، Barcode اصلی، Location، Lot، Expiry و FEFO تحت مالکیت Inventory هستند.
- `stock_movements` مرجع تاریخی تغییرناپذیر و `inventory_balances` projection کالا/محل است.
- Count، Waste و Transfer سندمحور، type-safe، مجوزدار، auditable و replay-safe شده‌اند.
- Replenishment قابل اقدام، روزهای پوشش، lead-time demand و Procurement Requisition boundary دارد.
- Workspace انبار از Management Control جدا و به Screen/Routeهای مستقل تقسیم شده است.
- Migration حفظ‌داده 42→43 و تست‌های Domain/Integration/Migration در سورس وجود دارند.

## کنترل کیفیت اجراشده

- `scripts/verify-foundation.sh`: PASS
- parse نحوی Kotlin برای Scope تغییرات: PASS
- شبیه‌سازی‌های SQLite برای Migration، guard و Queryهای Inventory: PASS
- `git diff --check`: PASS

## کنترل کیفیت اجرا‌نشده

Gradle 8.13 در محیط موجود نیست و Gradle Wrapper نیز به endpoint دانلود دسترسی ندارد. بنابراین
`compileDebugKotlin`، `assembleDebug`، Unit Tests، KSP/Room validation، Lint و Android
Migration/Integration Tests همگی **NOT EXECUTED** هستند. Room schema export نسخه 43 نیز باید در CI
تولید و بررسی شود.

## گیت انتشار

تا سبز شدن CI، وضعیت نهایی Task 02 برابر `INVENTORY 2.0 BLOCKED` است. Blocking issueها فقط گیت
Verification واقعی‌اند؛ هیچ Migration یا Test برای دور زدن این محدودیت تضعیف نشده است.

## خارج از Scope / بدهی بعدی

Scanner SDK و Barcode چندبسته‌ای، multi-branch sync/conflict resolution، forecasting پیشرفته،
Production/WIP، POS/KDS و Treasury مستقل در این Task تکمیل نشده‌اند. Inventory turnover نیز تا
کامل‌شدن COGS به‌صورت KPI نهایی نمایش داده نمی‌شود.
