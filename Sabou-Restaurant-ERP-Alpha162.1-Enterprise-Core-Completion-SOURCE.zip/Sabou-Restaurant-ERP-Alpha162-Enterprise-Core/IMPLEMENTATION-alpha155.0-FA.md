# CafeManager alpha155.0 — Enterprise Boundaries

## اجرای پیوسته ۸ مرحله

1. Unit Conversion Phase 2: Purchase و Recipe به تبدیل دقیق Purchase/Recipe → Stock متصل شدند؛ ویرایش کالا امکان تعریف واحد خرید/رسپی و ضریب تبدیل را دارد. داده‌های قدیمی 1:1 باقی می‌مانند.
2. Treasury: مدل دامنه Treasury برای Receipt/Payment، Channel و Settlement Status اضافه شد تا جداسازی Approval/Accounting/Settlement بر مبنای type-safe انجام شود. مهاجرت کامل workflowهای مالی به این boundary در build-verified phase بعدی انجام شود.
3. Costing: هسته مستقل Standard/Actual Cost و Variance اضافه شد؛ این هسته عمداً historical snapshotهای فعلی را بازنویسی نمی‌کند.
4. Personnel/Payroll: محاسبه و ثبت Payroll اکنون حقوق پایه را از قرارداد فعال و مؤثر که کل دوره را پوشش می‌دهد می‌گیرد؛ نبود قرارداد معتبر خطای صریح است.
5. Fixed Assets: Depreciation Run Calculator مستقل با cap دقیق تا depreciable base اضافه شد؛ foundation برای batch preview/run است.
6. Management Intelligence: KPI Definition با business definition/source/drill-down اضافه شد و Labor Cost صریحاً از Net Pay تفکیک شد.
7. UI/UX: ویرایش Inventory برای Unit Architecture ارتقا یافت. بازطراحی گسترده Workspace/360 در این بسته عمداً انجام نشد چون بدون build قابل اتکا، تغییر انبوه Compose پرریسک است.
8. Hardening: تست‌های pure-domain برای Costing/Treasury/Depreciation اضافه شد و versionName به alpha155.0 ارتقا یافت.

## محدودیت تأیید
Gradle Wrapper به Gradle 8.13 نیاز دارد و محیط فعلی به services.gradle.org دسترسی ندارد؛ بنابراین build/test pass ادعا نشده است. قبل از merge در GitHub CI، `./gradlew testDebugUnitTest` و build کامل اجرا شود.

## اصل ایمنی
این نسخه deliberately از تغییر schema اضافی و migrationهای پرریسک برای Treasury/Payroll Components خودداری می‌کند تا بدون اجرای Build/Migration tests، دیتای مالی در معرض ریسک قرار نگیرد.
