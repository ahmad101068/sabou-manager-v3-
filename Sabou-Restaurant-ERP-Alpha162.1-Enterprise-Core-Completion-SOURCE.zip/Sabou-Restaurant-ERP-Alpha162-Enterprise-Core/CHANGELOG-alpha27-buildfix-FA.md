# تغییرات alpha27-buildfix

- رفع خطای کامپایل مربوط به import داخلی `weight` در نسخه جدید Compose.
- اضافه‌کردن import مفقود `ElevatedCard` در صفحه‌های عملیات.
- رفع خطاهای زنجیره‌ای Composable ناشی از شناسایی‌نشدن `ElevatedCard`.
