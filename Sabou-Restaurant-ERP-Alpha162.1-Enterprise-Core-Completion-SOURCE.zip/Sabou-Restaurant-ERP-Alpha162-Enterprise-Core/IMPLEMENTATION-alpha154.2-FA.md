# CafeManager alpha154.2 — Accounting Boundary Phase 1

- Added SemanticAccountRole and centralized current system-chart mapping.
- Added SemanticJournalDraft/SemanticJournalLine with balance validation.
- Added LocalAccountingPostingEngine as the accounting-owned journal construction boundary.
- Migrated Daily Sales revenue and COGS journal creation away from concrete account codes.
- Preserved the existing Room transaction boundary: sales, inventory mutation, journal posting, outbox and audit remain atomic.
- Added AccountingPostingTest for semantic mapping and balanced-journal invariants.

## Verification
`./gradlew testDebugUnitTest --offline` was attempted. The environment does not contain Gradle 8.13 and cannot reach services.gradle.org, so tests could not be executed here. No passing-build claim is made.

## Next migration targets
Personnel/Payroll, Fixed Assets, Procurement/Purchases, Operations, then Dashboard read models.
