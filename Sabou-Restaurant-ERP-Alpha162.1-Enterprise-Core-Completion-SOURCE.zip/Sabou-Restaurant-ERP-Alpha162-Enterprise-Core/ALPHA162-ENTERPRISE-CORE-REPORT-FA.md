# گزارش تحویل Sabou Restaurant ERP — Alpha162 Enterprise Core

## 1) وضعیت نهایی بر اساس Definition of Done سخت‌گیرانه

این گزارش بین **پیاده‌سازی موجود در سورس** و **اثبات اجرایی** تفاوت می‌گذارد.

- نسخه پایگاه‌داده در سورس: **46**
- Migrationهای مرتبط: **44→45** (اصلاح و Backfill sequence) و **45→46** (Enterprise Core)
- Static/contract gates اجراشده در این محیط: **8 gate**؛ همه gateهای کد/قرارداد PASS هستند.
- Code Quality Gate: **PASS**
- Room schema export رسمی: **NOT COMPLETE**؛ `45.json` و `46.json` هنوز توسط Room/KSP تولید نشده‌اند.
- Gradle `testDebugUnitTest / lintDebug / assembleDebug / assembleDebugAndroidTest`: **NOT RUN TO TASK EXECUTION**؛ Wrapper قبل از شروع taskها در دانلود Gradle 8.13 با `UnknownHostException: services.gradle.org` متوقف شد.
- `connectedDebugAndroidTest`: **NOT RUN** در این runtime.
- GitHub Actions نهایی Alpha162: **NOT RUN**؛ دسترسی شبکه مستقیم runtime به GitHub نیز با DNS failure متوقف شد و سورس ZIP نهایی از این محیط Push نشده است.

بنابراین طبق Definition of Done پرامپت، **هیچ‌یک از ۱۰ مرحله در این گزارش DONE اعلام نمی‌شود**. در عین حال، پیاده‌سازی و تست‌های مورد نیاز در سورس تا سطحی که در ادامه با فایل مشخص شده، انجام شده‌اند.

---

## 2) شواهد Gateهای اجراشده

خروجی آخرین اجرای محلی:

```text
Sabou ERP 2.0 foundation architecture static checks passed.
ALPHA161_STATIC_VERIFICATION=PASS
ALPHA161_SQL_VERIFICATION=PASS v44_entities=86 tables=99 triggers=15
ALPHA161_CI_LOGFIX_REGRESSION=PASS
HR_PAYROLL_SQL_MIGRATION_PASS statements=186 checks=49 deterministic=1
RUNTIME_CRASH_REPAIR_HOST_PASS ...
ALPHA162_ENTERPRISE_CORE_VERIFICATION=PASS schema=46 vertical_slices=5 compose_e2e=11
ALPHA162_CODE_QUALITY=PASS production_files=295 test_files=148
ALPHA162_ROOM_SCHEMA_EVIDENCE=NOT_COMPLETE missing=45,46
```

مدرک: `evidence/alpha162-static-gates.log`

تلاش Gradle واقعی:

```text
Downloading https://services.gradle.org/distributions/gradle-8.13-bin.zip
java.net.UnknownHostException: services.gradle.org
GRADLE_EXIT_CODE=1
```

مدرک: `evidence/alpha162-local-gradle.log`

---

## 3) آمار تغییرات و تست

مقایسه با Alpha161.1 ورودی، با حذف cache/build/evidence از شمارش کد:

- فایل تغییرکرده کل: **107**
- Added: **49**
- Modified: **57**
- Deleted: **1** (حذف عمدی `LocalTreasuryServiceAdapter.kt` مرده)

مدرک: `evidence/alpha162-changed-files.txt`

آمار تعریف تست‌ها در سورس:

| دسته | تعداد `@Test` |
|---|---:|
| Unit (`app/src/test`) | 237 |
| Instrumentation (`app/src/androidTest`) | 129 |
| Migration tests | 34 |
| Integration tests | 80 |
| Compose E2E | 11 |
| DAO-oriented tests | 9 |

> دسته‌ها هم‌پوشانی دارند و نباید با هم جمع شوند. این اعداد تعداد تست‌های **تعریف‌شده در سورس** هستند؛ اجرای کامل آن‌ها به علت Gradle blocker در این runtime اثبات نشده است.

---

# 4) مرحله 1 — Room Schema / Migration

**وضعیت DoD: NOT COMPLETE** — پیاده‌سازی و تست قرارداد وجود دارد؛ export رسمی schema و اجرای MigrationTest توسط Gradle هنوز اثبات نشده است.

| مورد | مدرک |
|---|---|
| Requirement | تثبیت v45، اصلاح 44→45، schema/current validation |
| Implementation | Backfill امن sequenceهای اسناد قدیمی؛ سپس ایجاد migration مستقل 45→46 برای Alpha162 |
| Files | `ProfessionalErpMigrations.kt`, `Alpha162Migrations.kt`, `AppMigrations.kt`, `AppDatabase.kt` |
| DB | `APP_DATABASE_SCHEMA_VERSION = 46`; migrationهای 44→45 و 45→46 |
| Domain | sequenceها از داده واقعی قبلی seed می‌شوند؛ Alpha162 schema به migration قبلی تزریق نشده است |
| Tests | `ProfessionalSalesMigration44To45Test.kt`, `EnterpriseCoreMigration45To46Test.kt`, `Alpha162DaoTest.kt` |
| Integrity/FK | تست شامل `PRAGMA integrity_check`, `PRAGMA foreign_key_check`, FK/indexهای Restaurant، AR backfill 1000-250=750 |
| CI | Static gates PASS؛ Gradle/Room execution NOT COMPLETE |

### نکته Schema

در `app/schemas/ir.sabou.inventory.data.db.AppDatabase/` هنوز فقط `1.json` و `44.json` وجود دارد. `45.json` یا `46.json` دستی ساخته نشده است تا مدرک جعلی ایجاد نشود؛ باید توسط Room/KSP در Build واقعی export شود.

---

# 5) مرحله 2 — Treasury 2.0

**وضعیت DoD: NOT COMPLETE** — Source/Test wiring پیاده شده؛ CI اجرایی نهایی موجود نیست.

- Receipt: cash/bank/card/customer/other
- Payment: supplier/expense/payroll/other
- Internal Transfer
- Settlement کامل/جزئی
- Reconciliation
- Treasury Ledger مستقل
- Balanced Accounting posting
- Append-only reversal به‌جای edit عملیات posted
- Idempotency با command ID
- Permission در Domain (`TREASURY` + permission تخصصی)
- Audit
- Purchase payable settlement اکنون `purchases.paidRial/paymentStatus` را در همان transaction تغییر می‌دهد و reversal آن را برمی‌گرداند.
- Customer receipt/reversal به Receivable Ledger متصل است.

**Proof of wiring:**

`TreasuryScreen.kt` → `TreasuryViewModel.kt` → `TreasuryUseCases.kt` → `LocalTreasuryServiceV2.kt` → `Alpha162Dao.kt` / treasury tables → Accounting + AR/Purchase side effects + Audit → `TreasuryV2IntegrationTest.kt` / `EnterpriseCoreComposeE2ETest.kt`

تست اختصاصی Treasury: حداقل 6 سناریو شامل replay/idempotency، mid-operation rollback، internal transfer، reversal، payable settlement/reversal و reconciliation.

---

# 6) مرحله 3 — Restaurant POS 2.0

**وضعیت DoD: NOT COMPLETE** — Source/Test wiring پیاده شده؛ CI اجرایی نهایی موجود نیست.

- Hall / Table / capacity / status
- Reservation با state machine: BOOKED/CONFIRMED/SEATED/COMPLETED/CANCELLED/NO_SHOW
- Table order، تغییر سفارش، transfer table، merge با permission
- Waiter/User/Shift واقعی؛ waiter/customer دارای FK و validation هستند.
- KDS states با history/timestamp
- Course: Starter/Main/Dessert/Drink
- Split bill و multi payment
- بستن میز از `ProfessionalSalesRepository.post()` عبور می‌کند تا Sales/Inventory/Recipe/COGS/Accounting دوباره‌نویسی نشود.

**Proof of wiring:**

`RestaurantScreens.kt` → `RestaurantViewModel.kt` → `RestaurantUseCases.kt` → `LocalRestaurantService.kt` → `Alpha162Dao.kt` / Restaurant entities → `ProfessionalSalesRepository.post()` → Inventory/Recipe/COGS/Accounting/Audit → Restaurant integration + Compose E2E.

DB proof در migration test: FKهای `tableId`, `waiterUserId`, `customerId` و index مشتری Restaurant بررسی می‌شوند.

---

# 7) مرحله 4 — Dashboard + Alert Engine 2.0

**وضعیت DoD: NOT COMPLETE** — منطق و تست source-level موجود؛ CI اجرایی نهایی موجود نیست.

Dashboard:
- Today / Week / Month / Custom range
- Branch / Warehouse filter
- اصلاح midnight rollover؛ تاریخ در lifecycle Repository ثابت نمی‌ماند.
- KPI و drill-down به ماژول‌ها.

Alerts:
- LOW_STOCK
- LOT_EXPIRING
- LOT_EXPIRED
- PURCHASE_PAYABLE
- CUSTOMER_RECEIVABLE
- CONTRACT_EXPIRY
- UNPAID_PAYROLL
- ASSET_MAINTENANCE
- ATTENDANCE_ANOMALY
- PURCHASE_DELIVERY_OVERDUE
- INVENTORY_DISCREPANCY

States: NEW/READ/ACTIONED/RESOLVED/DISMISSED؛ refresh تکراری duplicate نمی‌سازد.

Receivable alert و CRM Aging از `ReceivableAgingCalculator.kt` مشترک استفاده می‌کنند تا receiptهای واقعی از aging کم شوند.

Tests: `AlertStateIntegrationTest.kt`, `AlertReceivableIntegrationTest.kt`, `ReceivableAgingCalculatorTest.kt`.

---

# 8) مرحله 5 — Recipe & Costing 2.0

**وضعیت DoD: NOT COMPLETE** — Source/Test wiring پیاده شده؛ CI اجرایی نهایی موجود نیست.

- Draft / Active / Retired
- Create/Copy/Edit Draft/Activate/Retire/History
- Active recipe immutable
- Nested recipe / sub-recipe
- جلوگیری از A→B→A و A→B→C→A قبل از commit
- substitution با permission + reason + audit
- Material/Waste/Preparation/Cooking/Packaging/Labor/Overhead costing
- `SalesRecipeCostSnapshotService.kt` برای flatten nested recipe و حفظ COGS تاریخی فروش
- parse نامعتبر quantity دیگر به صفر معتبر تبدیل نمی‌شود؛ به validation نامعتبر منتقل می‌شود.

**Proof of wiring:**

`RecipeScreens.kt` → `RecipeViewModel.kt` → `RecipeUseCases.kt` → `LocalRecipeRepository.kt` → `RecipeDao.kt` / Recipe entities → Sales snapshot + Inventory/Audit → Recipe lifecycle integration + Compose E2E.

---

# 9) مرحله 6 — Fixed Assets 2.0

**وضعیت DoD: NOT COMPLETE** — Source/Test wiring پیاده شده؛ CI اجرایی نهایی موجود نیست.

- Historical Cost immutable
- `Book Value = Historical Cost - Accumulated Depreciation - Accumulated Impairment`
- Transfer location/branch/responsible + history/audit
- Maintenance + next service + accounting
- Impairment + balanced journal
- Sale با Book Value / Gain-Loss + balanced journal
- lifecycle events persistent

**Proof of wiring:**

`AssetScreens.kt` → `AssetViewModel.kt` → `AssetUseCases.kt` → `LocalAssetRepository.kt` → `AssetDao.kt` / asset lifecycle tables → Accounting/Audit → `AssetLifecycleIntegrationTest.kt` + depreciation Compose E2E.

چهار Integration test اختصاصی lifecycle وجود دارد: transfer، maintenance، impairment، sale after depreciation/impairment.

---

# 10) مرحله 7 — CRM / Accounts Receivable 2.0

**وضعیت DoD: NOT COMPLETE** — Source/Test wiring پیاده شده؛ CI اجرایی نهایی موجود نیست.

- Customer master توسعه‌یافته
- Receivable Ledger: Sale/Return/Receipt/Adjustment/Reversal
- Aging: Current/1-30/31-60/61-90/+90 با FIFO settlement
- Credit limit override فقط با permission + reason + audit
- duplicate detection بر اساس identifiers normalized
- controlled merge؛ references و ledger منتقل می‌شوند و source به MERGED می‌رود.
- فروش اعتباری/مرجوعی/Treasury receipt به AR ledger متصل شده‌اند.

**Proof of wiring:**

`CrmScreen.kt` → `CrmViewModel.kt` → `CrmUseCases.kt` → `LocalCustomerAccountService.kt` → CRM/AR DAO tables → Sales/Treasury/Audit → `CrmReceivablesIntegrationTest.kt`.

---

# 11) مرحله 8 — Legacy Cleanup / God Class Refactor

**وضعیت DoD: NOT COMPLETE** — refactorهای اصلی انجام شده؛ full compile/CI اثبات نشده است.

Refactorهای responsibility-based:

- `PersonnelAttendanceService.kt` استخراج از `LocalPersonnelRepository`
- `InventoryLotMovementService.kt` استخراج FEFO/lot movement از `LocalInventoryCommandEngine`
- `PayrollBatchPreparationService.kt` استخراج payroll preparation/calculation inputs
- `PayrollPaymentPostingService.kt` استخراج پرداخت/برگشت پرداخت حقوق
- `SalesRecipeCostSnapshotService.kt` استخراج snapshot هزینه رسپی فروش
- `HrPayrollDialogs.kt` جدا از workspace اصلی `HrPayrollScreens.kt`

`PersonnelViewModel` دیگر متدهای fail-fast قدیمی `.calculatePayroll/.postPayroll/.approvePayroll/.reversePayroll` را صدا نمی‌زند.

`LocalTreasuryServiceAdapter.kt` مرده حذف شده است. `LegacyTreasuryChannelAdapter` حفظ شده چون هنوز برای سازگاری داده HR قدیمی caller واقعی دارد.

---

# 12) مرحله 9 — Application / UseCase Layer

**وضعیت DoD: NOT COMPLETE** — لایه UseCase در سورس ایجاد و در مسیرهای کلیدی wiring شده؛ full compile/CI اثبات نشده است.

UseCaseها:

- Sales (موجود قبلی و حفظ شده)
- `ProcurementUseCases.kt`
- `InventoryUseCases.kt`
- `RecipeUseCases.kt`
- `TreasuryUseCases.kt`
- `AccountingUseCases.kt`
- `AssetUseCases.kt`
- `CrmUseCases.kt`
- `PersonnelUseCases.kt`
- `AttendanceUseCases` در همان فایل Personnel application boundary
- `PayrollUseCases.kt`
- `RestaurantUseCases.kt`

ViewModelهای Treasury/Restaurant/Recipe/Asset/CRM/Personnel به UseCaseهای مربوطه متصل هستند.

---

# 13) مرحله 10 — Test Architecture / E2E

**وضعیت DoD: NOT COMPLETE** — تست‌ها در سورس ایجاد شده‌اند، اما connected/Gradle execution نهایی در این runtime انجام نشده است.

Compose test dependency اضافه شده و `EnterpriseCoreComposeE2ETest.kt` از `createAndroidComposeRule<MainActivity>()` استفاده می‌کند.

11 Flow تعریف‌شده:

1. Sale → Inventory/COGS/Accounting
2. Sale Return → stock/financial reversal
3. Purchase/GRN → stock/accounting
4. Inventory transfer issue/receive
5. Inventory count record/approve/post
6. Payroll registration/approval/accrual
7. Payroll payment → Treasury
8. Treasury receipt → ledger/accounting
9. Asset depreciation → book/accounting
10. Recipe draft/activation immutable version
11. Restaurant table → KDS → invoice → multi-payment → close table

Test selectors با testTagهای Production screen تطبیق داده شده‌اند. Mock repository در این Compose E2E استفاده نشده است.

---

# 14) End-to-End Business Flow Mapping

| Flow پرامپت | پوشش سورس/تست |
|---|---|
| Purchase → GRN → Lot → Stock → Payable → Accounting | Repository/integration + Compose purchase/GRN |
| Sale → Recipe → Inventory → COGS → Payment → Accounting | Sales transaction + snapshot + Compose E2E |
| Sale Return → Stock Restore → COGS Reverse → Financial Reverse | Sales return E2E/integration |
| Waste → Stock decrease → Waste Expense → Audit | Inventory waste workflow integration موجود |
| Transfer → Issue → In Transit → Receive | Inventory transfer integration + Compose E2E |
| Attendance → Payroll → Approval → Payment → Accounting | Payroll/attendance UseCases + E2E payroll/payment |
| Asset → Depreciation → Book Value → Accounting | Asset lifecycle + Compose depreciation |
| Recipe version change → historical COGS unchanged | Sales recipe snapshot + recipe lifecycle tests |
| Credit Sale → Receivable → Receipt → Settlement | CRM ledger + Treasury receipt/settlement tests |
| Restaurant Table → Kitchen → Invoice → Multi Payment → Close | Restaurant Compose E2E + integration |

اجرای نهایی این جدول روی emulator/CI هنوز مدرک ندارد؛ بنابراین صرف وجود پوشش در سورس به معنی DONE نیست.

---

# 15) Security / Audit

`EnterprisePermissionIntegrationTest.kt` حداقل پنج boundary حساس را پوشش می‌دهد:

- Treasury receipt نیازمند `TREASURY`
- Restaurant merge نیازمند permission اختصاصی merge
- Customer merge نیازمند `CUSTOMER_MERGE`
- Asset transfer نیازمند `ASSET_LIFECYCLE`
- Recipe activation نیازمند permission اختصاصی activation

عملیات Treasury علاوه بر permission تخصصی، خود `TREASURY` را در Domain الزام می‌کند. عملیات حساس جدید دارای audit event/metadata در Service/Repository هستند.

---

# 16) Code Quality Gate

`verify-alpha162-code-quality.py` این موارد را روی Production/Test source کنترل می‌کند:

- TODO/FIXME/NotImplemented/ComingSoon production = 0
- Empty catch = 0
- Exception → hardcoded `Result.success` = 0
- `fallbackToDestructiveMigration` = 0
- Float/Double money declarations = 0
- Fake/Mock/Demo repository/service/DAO production = 0
- disabled tests (`@Ignore/@Disabled/assume(false)`) = 0
- legacy dead Treasury adapter = absent
- basic sensitive-log pattern = no hit

نتیجه آخر: **ALPHA162_CODE_QUALITY=PASS**.

---

# 17) Remaining Issues — اجباری و صریح

1. **Room `45.json` و `46.json` وجود ندارند.** باید در Build واقعی با Room/KSP تولید و commit شوند.
2. **Gradle tasks اجرا نشده‌اند** چون Wrapper قبل از task execution به علت DNS نتوانست Gradle 8.13 را دانلود کند.
3. **Instrumentation/Compose tests روی emulator اجرا نشده‌اند**؛ فقط وجود/wiring/static contract و parser-level بررسی شده است.
4. **GitHub Actions نهایی Alpha162 اجرا نشده است.** runtime مستقیم به `github.com` هم DNS resolution ندارد و ZIP نهایی از این محیط Push نشده است.
5. تا رفع 1 تا 4، عبارت‌های `Production Ready / Fully Tested / DONE` برای این نسخه معتبر نیستند.

---

# 18) دستورات CI مورد نیاز پس از قرار گرفتن سورس در محیط شبکه‌دار

```bash
./gradlew --no-daemon testDebugUnitTest
./gradlew --no-daemon lintDebug
./gradlew --no-daemon assembleDebug
./gradlew --no-daemon assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
```

سپس باید خروجی Room schema بررسی شود:

```text
app/schemas/ir.sabou.inventory.data.db.AppDatabase/45.json
app/schemas/ir.sabou.inventory.data.db.AppDatabase/46.json
```

و در نهایت GitHub Actions باید با همان ZIP نهایی اجرا و لاگ failure در صورت وجود به Root Cause کد بازگردانده شود.

---

## جمع‌بندی

Alpha162 در سورس دارای توسعه واقعی برای Treasury، Restaurant/KDS، Dashboard/Alerts، Recipe lifecycle/costing، Asset lifecycle، CRM/AR، UseCase boundaries، God-class extraction و Test Architecture است. هشت Gate محلی contract/code-quality پاس شده‌اند. اما طبق قرارداد ضد فریب مأموریت، **اثبات نهایی Build/Room schema/Instrumentation/GitHub CI هنوز موجود نیست و همه مراحل از دید Definition of Done در وضعیت NOT COMPLETE باقی می‌مانند تا آن سه دسته مدرک اجرایی تولید شوند.**
