# Sabou Restaurant ERP — Alpha161 Clean-Slate Professional ERP

نسخه سورس: `3.0.0-alpha161-clean-slate-professional-erp`  
Room Schema: `45`  
Migration جدید: `44 → 45`

Sabou یک ERP فارسی/RTL برای مدیریت داخلی رستوران بر پایه Kotlin، Jetpack Compose، Room/SQLite، SQLCipher و WorkManager است. Alpha161 یک خروجی مستقل و production-heavy است: subsystemهای سالم ERP 2.0 حفظ شده‌اند و مهم‌ترین شکاف سورس پایه—فروش سفارش‌محور و POS تراکنشی—با مسیر واقعی Domain/Data/Room/Accounting/Inventory/Audit/Print تکمیل شده است.

## Alpha161 چه چیزی را تغییر می‌دهد؟

- POS حرفه‌ای با فاکتور ردیفی، مشتری، پرداخت چندگانه، Hold/Resume، مرجوعی جزئی/کامل و Void کنترل‌شده.
- اتصال فروش به نسخه مؤثر رسپی، snapshot بهای تمام‌شده، FEFO/Lot، موجودی و COGS.
- حساب‌های دریافتنی مشتری، سقف اعتبار و سررسید فروش اعتباری.
- بستن/بازگشایی روز POS با revision، Audit و snapshot صندوق؛ اتصال مستقیم Cash Reconciliation.
- چاپ A4/RTL فاکتور و Audit چاپ/چاپ مجدد.
- `document_sequences` برای شماره‌گذاری تراکنشی فاکتور خرید/فروش، درخواست و سفارش خرید، رسید، مرجوعی، انتقال انبار، دارایی، کد پرسنلی، Hold و مشتری.
- Migration حفظ‌داده 44→45 و triggerهای immutable/closed-day برای ledger فروش.
- جلوگیری از double-post بین POS حرفه‌ای و Daily Sales Legacy.
- Dashboard متصل به KPI واقعی ledger جدید.
- Permissionهای مستقل Customers / Sales Return / Sales Void.

## معماری مسیر فروش

```text
Compose UI
→ SalesPosViewModel
→ SalesUseCases
→ ProfessionalSalesRepository
→ LocalProfessionalSalesRepository
→ Room transaction
→ Recipe snapshot + Inventory/Lot + Accounting + Audit/Sync
→ Flow read model
→ Report / Print
```

Daily Sales قدیمی حذف نشده است تا داده و سازگاری نسخه‌های قبل از بین نرود، اما در مسیر جداگانه‌ی `SALES_DAILY_CONTROL` قرار دارد و نمی‌تواند برای یک روز هم‌زمان با POS حرفه‌ای اثر مالی/انباری ایجاد کند.

## ساخت و کنترل کیفیت

پیش‌نیازها: JDK 17، Android SDK سازگار پروژه و دسترسی Gradle Wrapper به Gradle 8.13.

```bash
bash scripts/verify-foundation.sh
bash scripts/verify-alpha161-professional-erp.sh
./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
./gradlew --no-daemon connectedDebugAndroidTest
./gradlew --no-daemon assembleRelease
```

GitHub Actions همین سورس را روی API 23 و API 35 تست می‌کند و APK Debug، Room schema و گزارش شکست را artifact می‌کند.

### وضعیت Verification این بسته

در محیط تحویل، هر دو static verifier، اجرای واقعی SQL Migration/Triggerها روی SQLite، `foreign_key_check`، تست SQL جمع‌بندی پایان روز و compile/اجرای مستقل دامنه فروش با `kotlinc` PASS شده‌اند. اجرای Gradle محلی به علت `UnknownHostException` هنگام دریافت Gradle 8.13 از `services.gradle.org` کامل نشد؛ بنابراین نتیجه build محلی به‌صورت غیرواقعی «سبز» اعلام نشده است.

## مستندات Alpha161

- [Changelog Alpha161](CHANGELOG-alpha161-FA.md)
- [معماری و Verification Alpha161](docs/ALPHA161-CLEAN-SLATE-PROFESSIONAL-ERP.md)
- [معماری هدف ERP 2.0](docs/ERP2-TARGET-ARCHITECTURE-FA.md)
- [مرزهای دامنه](docs/DOMAIN-BOUNDARIES.md)
- [ماتریس یکپارچگی تراکنش](docs/TRANSACTION-INTEGRITY-MATRIX.md)
- [Inventory 2.0 Architecture](docs/INVENTORY-2-ARCHITECTURE.md)
- [HR/Payroll 2 Architecture](docs/HR-PAYROLL-2-ARCHITECTURE.md)

## اصل عدم تقلب در کیفیت

هیچ `fallbackToDestructiveMigration`، حذف/Ignore تست، fake success یا rewrite مستقیم factهای مالی فروش برای سبزکردن CI اضافه نشده است. اگر CI روی GitHub خطای compiler/Room/Instrumentation جدیدی نشان دهد، همان خطا باید ریشه‌ای در سورس اصلاح شود، نه با تضعیف تست یا constraint.
