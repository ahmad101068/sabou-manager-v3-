# تغییرات نسخه 3.0.0-alpha115-payroll-compile-fix

## رفع خطای ساخت

- اصلاح دو ارجاع حذف‌شده به متغیر `now` در فرم ثبت و محاسبه حقوق.
- استفاده از یک مقدار ثابت `today` برای تاریخ پرداخت و تاریخ شمسی دوره حقوق.
- خطای گزارش‌شده توسط GitHub Actions در مرحله `compileDebugKotlin` برطرف شد.

## نسخه

- `versionCode`: 148
- `versionName`: `3.0.0-alpha115-payroll-compile-fix`
