# TASK 02 — Inventory 2.0 Delivery Report

## Executive Summary

Alpha159 changes Inventory from an item-global stock feature into a location- and lot-aware control
domain built around an immutable ledger. Item/location projections are rebuildable and guarded;
Count, Waste and Transfer are controlled documents; FEFO, expiry, replenishment, authorization, audit,
correlation and idempotency share the established Foundation boundaries.

Implementation and verification assets are present. Static architecture/syntax/SQL checks pass. The
release gate is still blocked because this workspace cannot obtain Gradle 8.13, so Kotlin semantic
compile, KSP/Room validation, APK assembly and Android tests were not executed.

## Inventory Before

- item-global mutable quantity/value projection used by availability guards;
- incomplete location/lot reconstruction from movement history;
- immediate count and transfer records without controlled lifecycle;
- free-text waste and Management Control ownership of location/lot/FEFO/transfer UI;
- item-global replenishment and broad Inventory permission;
- list-oriented Inventory UI with aggregate in-memory state.

## Inventory After

- immutable `stock_movements` history plus item/location `inventory_balances` projection;
- guarded compatibility aggregate and lot cache, updated in the same transaction;
- Item Master 2.0, typed locations/lots/movements/statuses and strict persistence mapping;
- deterministic location-aware FEFO and explicit shortage;
- document workflows for Count, Waste and Transfer;
- structured integrity diagnostics and bounded SQL read models;
- decision-oriented Inventory Workspace and fine-grained service authorization.

## Architecture Changes

- Added Inventory command, master/read, lot, count, waste, transfer, replenishment and integrity
  contracts under the Inventory domain.
- Extended `LocalInventoryCommandEngine`; no second stock or accounting engine was created.
- Added owner-oriented Inventory DAOs and local services, wired only in `AppContainer`.
- Procurement and Sales/Recipe integrations call the Inventory boundary.
- Reused Foundation Accounting, Authorization, Audit, Correlation and Domain Failure contracts.
- Removed the presentation God file and introduced focused Inventory routes/screens/ViewModel.

## Database Changes

Room schema advances `42 → 43`. Item/location/lot and goods-receipt facts are enriched;
`inventory_balances`, `inventory_count_sessions` and `inventory_count_lines` are added; waste and
transfer tables are rebuilt with document lifecycle, actor, idempotency and foreign-key constraints.
Operational indexes and immutability/transition guards are installed. No destructive fallback exists.

## Migration Strategy

Legacy rows are preserved and explicitly mapped. `MAIN` is the stable default location. A single
idempotent opening movement reconciles only the delta between legacy aggregate stock/value and existing
ledger totals. No fake history or mandatory fake lot is generated. Migration tests cover preservation,
uniqueness, foreign keys and guards; Android execution and schema-43 export validation remain blocked.

## Item Master

Supports stable unique SKU, primary barcode lookup, typed item/storage state, base/purchase/recipe units
and fixed-point conversion, brand, shelf-life and lot/expiry policies, stock thresholds, preferred
supplier, lead time, active lifecycle and bounded database search. Multi-packaging barcode rows are
deferred; the primary barcode boundary is complete.

## Ledger

Every migrated stock effect appends an immutable movement with item, location, quantity/value,
unit-cost snapshot, source, business/creation time, actor, correlation and reversal link. Posted rows
cannot be updated/deleted. Correction uses linked reversal and a correcting command.

## Location

Location is a first-class Inventory master with stable code, typed kind and active state. Availability
and negative-stock checks operate at item/location scope. Inventory, not Management Control, owns its
UI and service boundary.

## Lot / Expiry / FEFO

Lots retain source receipt, supplier lot, production/receipt/expiry dates, cost, status, actor and
correlation. Expired/quarantined/blocked lots are fail-safe and excluded from normal FEFO. Allocation is
deterministic and returns selected lots plus shortage. Expiry never silently removes inventory.

## Inventory Count

Count Session/Lines implement Draft/Open/Counting/Recount/Pending Approval/Approved/Posted/Cancelled,
blind count, configurable recount thresholds, actor separation and snapshot-aware atomic variance
posting. Unique post command identity prevents duplicate movements.

## Waste

Waste is a typed, numbered, lot/location-aware document with unit-cost snapshot, total cost, reason,
business date, creators/approvers/poster, correlation and lifecycle. Posting atomically decreases
inventory/lot, posts accounting through `AccountingPostingService`, audits and transitions the document.

## Transfers

Transfer documents track requested/approved/issued/received actors and times, requested/issued/received/
variance quantities, source/destination, lot and correlation. Issue moves value to in-transit; receipt
moves it to destination. Same-entity transfer creates no P&L journal.

## Replenishment

Recommendations combine available, on-order, in-transit, average usage, lead time, safety/min/max stock,
reorder point and preferred supplier. They expose days of cover, reason, risk and non-negative suggested
quantity. Waste inclusion is an explicit policy. The output can create a Procurement requisition, never
a purchase order.

## Analytics

Dashboard read models expose inventory value, low/out stock, expiring/expired lots, posted waste cost,
posted count variance and pending transfer/count counts. Inventory turnover is deliberately absent
until complete COGS integration can support a truthful KPI.

## Permissions

Fine-grained permissions cover view, item/location/lot management, count create/perform/approve/post,
waste create/approve and transfer create/issue/receive. Services validate current actor and permission;
Compose visibility is convenience only. Count approval supports segregation of duties.

## Audit

Item/location changes, lot status, count workflow, waste posting and transfer lifecycle append audit
events with actor, business/system time, source, reason and correlation. Audit failure propagates and
rolls back sensitive transactions.

## Transaction Integrity

Receipt/return, sales/recipe consumption, waste, count posting, transfer issue/receipt, adjustment and
reversal were mapped. Each migrated workflow joins one Room transaction for document, ledger,
projections, accounting (when applicable), audit and outbox. CAS writes and database guards reject
stale or invalid state.

## Idempotency

Receipt application, ledger commands, count posting, waste create/post, transfer create/issue/receive,
sales posting and reversal use stable source/command identities. Exact replay returns the existing
result; a changed payload with the same identity is rejected.

## Performance

Search/filter/sort/limit runs in SQL for operational workspace lists. Movement and balance reads are
explicitly bounded; stable ids drive Compose lists. Formal device benchmarks at 1,000 items, 50,000
movements and 10,000 lots were not executed and remain a release/performance-validation item.

## UI/UX

The RTL Inventory Workspace contains Overview, Item/Location, Expiry/Lot, Ledger, Count, Waste,
Transfer, Replenishment and Period centers. Item detail is sectioned rather than one giant form. KPIs
drill down into the owner workflow and errors remain actionable Persian presentation mappings.

## Files Added

- Domain: `domain/inventory/Inventory*Models.kt` contracts for master, balance, lot, count, waste,
  transfer, replenishment and read models.
- Database: Inventory balance/count/location/lot/read/replenishment/transfer DAOs/entities.
- Services: `LocalInventoryRepository` and dedicated Inventory command-support services.
- Presentation: Inventory Workspace, ViewModel, Routes and eight focused centers.
- Tests: Inventory domain, Room integration and migration suites.
- Documentation: six required Inventory 2.0 reports and Alpha159 changelog.

## Files Modified

- Database registry/entities/guards, `AppContainer`, existing Inventory engine and integration adapters.
- Procurement receipt/return, Operations compatibility facade and Management Control redirect.
- Security permissions, UI error mapping, application routes and Foundation verification script.
- README, status and Foundation/domain-boundary documentation.

## Files Removed

- `app/src/main/java/ir/sabou/inventory/ui/InventoryOperationsScreens.kt` — replaced by owner-focused
  Inventory screens; no business behavior was intentionally removed.

## Tests Added

Domain tests cover master validation, balance math, FEFO, count/recount/blind views, waste, transfer,
replenishment and reads. Room integration tests cover ledger rollback/replay, Count, Waste, Transfer,
Replenishment, read authorization and receipt/sales compatibility. Migration 42→43 preservation and
full-chain registry tests are present.

## Tests Executed

- Foundation static verification: PASS.
- Kotlin syntax parser for 90 Kotlin files changed since Alpha158: PASS, zero syntax errors.
- Representative SQLite migration/query/guard simulations: PASS.
- Whitespace/diff validation: PASS.

These are not reported as Gradle unit/instrumentation results.

## Build Results

- `:app:compileDebugKotlin`: NOT EXECUTED — Gradle 8.13 distribution unavailable.
- `:app:assembleDebug`: NOT EXECUTED — compile gate could not start.
- Unit/Room migration/integration tests: NOT EXECUTED.
- KSP/Room schema validation: NOT EXECUTED; KSP was not reached.
- Foundation verification: PASS.

## Remaining Risks

1. Semantic Kotlin/Compose/Room compilation has not been proven locally.
2. Room schema 43 export has not been generated/reviewed.
3. Migration and transactional tests have not run on Android/SQLCipher runtime.
4. Device performance and tablet usability have not been measured.

## Remaining Technical Debt

- Multi-unit/package barcode table and physical scanner adapter;
- explicit standalone adjustment document beyond controlled count compatibility;
- legacy item aggregate projection removal after every cross-domain reader migrates;
- full multi-branch/global-id sync conflict protocol;
- internal decomposition of the 1,032-line Inventory command engine after semantic build coverage is available;
- advanced forecasting and truthful turnover once complete COGS data is available;
- Compose instrumentation/accessibility coverage.

## Completion Matrix

| Capability | Status | Evidence / limitation |
|---|---|---|
| Item Master | DONE | typed master and bounded repository |
| SKU | DONE | stable unique indexed SKU and migration backfill |
| Barcode | PARTIAL | primary barcode + lookup; packaging barcode table deferred |
| Location | DONE | typed master and item/location projection |
| Lot | DONE | first-class guarded lot lifecycle |
| Expiry | DONE | configurable policy and explicit blocking/disposal |
| FEFO | DONE | deterministic allocation with shortage |
| Stock Ledger | DONE | immutable authority and reversals |
| Projection | DONE | rebuildable location + compatibility aggregate CAS |
| Integrity Checker | DONE | structured ledger/projection/lot/transfer checks |
| Count Session | DONE | document/line workflow |
| Blind Count | DONE | role-aware read model |
| Recount | DONE | injectable threshold policy |
| Waste | DONE | typed/costed/atomic/accounted document |
| Transfer | DONE | issue/in-transit/receive/variance document |
| Valuation | DONE | weighted-average policy preserved and centralized |
| Replenishment | DONE | actionable SQL-backed recommendations |
| Dashboard | DONE | decision KPIs and drill-down workspaces |
| Permissions | DONE | fine-grained command-boundary enforcement |
| Audit | DONE | sensitive workflows append correlated audit |
| Idempotency | DONE | critical Inventory command replay controls |
| Migration | PARTIAL | implementation/tests complete; Android execution/schema export blocked |
| Performance | PARTIAL | bounded SQL complete; device volume profiling not executed |
| Tests | PARTIAL | meaningful suites authored; Gradle/Android execution blocked |
| Build | BLOCKED | Gradle 8.13 distribution unavailable |

## Recommendation

Do not mark this candidate release-ready or merge it as a verified production baseline until CI passes
compile, KSP/Room, unit, migration, instrumentation and APK gates and commits/reviews schema 43 export.
The source package is ready for that CI verification; no integrity shortcut should be introduced to
clear the gate.

**INVENTORY 2.0 BLOCKED**
