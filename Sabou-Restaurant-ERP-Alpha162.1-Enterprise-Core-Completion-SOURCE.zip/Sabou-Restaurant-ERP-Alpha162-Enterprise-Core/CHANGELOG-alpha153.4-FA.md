# تغییرات alpha153.4 — Production Audit

## اصلاحات

- اعتبارسنجی endpoint همگام‌سازی اکنون فقط URI معتبر HTTPS با host مشخص و بدون user-info، query یا fragment را می‌پذیرد.
- endpoint و شناسه‌های tenant/device پیش از استفاده normalize می‌شوند.
- اتصال‌های HTTP همگام‌سازی و تمدید توکن در مسیر موفق و خطا به‌طور قطعی آزاد می‌شوند.
- WebView داخلی چاپ با JavaScript، دسترسی فایل، دسترسی ContentProvider و بارگذاری شبکه غیرفعال اجرا می‌شود.
- WebViewClient چاپ پس از نخستین بارگذاری جدا می‌شود تا درخواست چاپ تکراری ایجاد نشود.
- نسخه Build، وضعیت پروژه و نام Artifact در CI یکپارچه شدند.
- تست واحد Regression برای اعتبارسنجی endpoint اضافه شد.

## سازگاری

- Schema دیتابیس همچنان نسخه ۳۹ است و Migration جدید یا تغییر مخرب داده وجود ندارد.
- قراردادهای Repository و داده‌های ذخیره‌شده تغییر نکرده‌اند.
- Sync همچنان به‌صورت fail-closed غیرفعال است.

## وضعیت Verification

- کنترل ساختاری پروژه اجرا شده است.
- اجرای کامل Gradle، Lint، Unit Test و Android Test به Gradle 8.13 و Android SDK نیاز دارد.
