# Sabou Restaurant ERP 2.0 — راهنمای فارسی

نسخه جاری: `3.0.0-alpha157.0-data-boundary-split`، `versionCode 200`، Schema `42`.

راهنمای اصلی و دستورهای Build در [README.md](README.md) قرار دارد. این Increment هسته
دفتر موجودی، مرز ثبت حسابداری، Audit، Authorization، Idempotency و Migration را سخت‌سازی
کرده و در این مرحله God File مربوط به DAOها را به ۱۲ فایل domain-owned تفکیک می‌کند؛ تکمیل
همه قابلیت‌های Restaurant OS را ادعا نمی‌کند.

برای بررسی فنی از این ترتیب استفاده کنید:

1. [ممیزی و Impact Map](docs/ERP2-AUDIT-IMPACT-MAP-FA.md)
2. [معماری هدف](docs/ERP2-TARGET-ARCHITECTURE-FA.md)
3. [Migration 41→42](docs/ERP2-MIGRATION-41-42-FA.md)
4. [گزارش فنی A تا K](docs/ERP2-TECHNICAL-REPORT-FA.md)
5. [Roadmap](docs/ERP2-REMAINING-ROADMAP-FA.md)
6. [گزارش تفکیک Data Boundary](docs/ERP2-ALPHA157-DATA-BOUNDARY-REPORT-FA.md)

تا پیش از سبزشدن CI، تست Migration روی کپی واقعی دیتابیس و آزمون گوشی فیزیکی، این نسخه
نباید تنها مرجع مالی یا موجودی محیط عملیاتی باشد.
