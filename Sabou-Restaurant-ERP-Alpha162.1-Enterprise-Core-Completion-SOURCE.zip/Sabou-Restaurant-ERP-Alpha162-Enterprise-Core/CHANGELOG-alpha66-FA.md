# تغییرات Sabou Manager v3 alpha66 — اصلاح Build

- خطای کامپایل `Unresolved reference: BorderStroke` در `OperationsScreens.kt` با import رسمی Compose اصلاح شد.
- اکشن `setup-java` در GitHub Actions به نسخه سازگارتر با Node جدید ارتقا یافت.
- نام Artifact خروجی APK با نسخه فعلی هماهنگ شد.
- هشدارهای strip کتابخانه‌های native خطای کامپایل نیستند و به‌عنوان هشدار بسته‌بندی باقی می‌مانند.
- نسخه: `3.0.0-alpha66-buildfix-floor-sync`، کد نسخه `99`.
