# CafeManager alpha154.5 — Inventory Command Engine Phase 1

## اجرا شده
- ایجاد `LocalInventoryCommandEngine` به عنوان write boundary مرکزی موجودی.
- متمرکزسازی تغییر quantity/value، ثبت StockMovement، FEFO lot consumption و restoration در reversal.
- مهاجرت Daily Sales consumption و Daily Sales reversal به Inventory Command Engine.
- مهاجرت Purchase receipt و Purchase reversal به Inventory Command Engine.
- مهاجرت Procurement Goods Receipt و Purchase Return به Inventory Command Engine.
- حفظ transaction boundaryهای موجود؛ Engine تراکنش مستقل باز نمی‌کند و داخل `Room.withTransaction` workflow فراخوانی می‌شود.
- حفظ رفتار تاریخی FEFO: Daily Sales از `FEFO_ALL` و Purchase/Procurement return/reversal از `FEFO_ALLOCATED_ONLY` استفاده می‌کنند.

## Verification
Static scan confirms the three migrated repositories no longer directly call:
- `inventoryDao().updateValuation`
- `inventoryDao().restoreValuation`
- `stockMovementDao().insert`
- `managementControlDao().updateLot`

Gradle test execution was attempted with `./gradlew testDebugUnitTest --offline`, but Gradle 8.13 is not cached and the environment cannot resolve `services.gradle.org`. No successful-build claim is made.

## مرحله بعد
- migrate remaining inventory mutations (Operations/Management Control where domain-appropriate)
- introduce explicit inventory command/value objects
- add integration tests around command engine rollback and FEFO invariants
- then proceed to Unit Conversion architecture.
