# ممیزی دامنه و یکپارچگی — alpha153.6

## نتیجه اجرایی

پروژه یک سامانه داخلی و Local-First با هسته حسابداری دوطرفه است؛ صرفاً Income/Expense Tracker نیست. Room/SQLCipher منبع اصلی داده است و عملیات ترکیبی مهم در تراکنش Room انجام می‌شوند. این نسخه Schema را تغییر نمی‌دهد و روی تکمیل Audit Trail و ایمنی جمع مبالغ سند تمرکز دارد.

## مدل واقعی و منبع حقیقت

| حوزه | Entity/منبع اصلی | ارتباط عملیاتی | وضعیت |
|---|---|---|---|
| حسابداری | `accounts`, `journal_entries`, `journal_lines`, `accounting_period_locks` | تمام اثرهای مالی به سند متوازن ختم می‌شوند | Functional / کنترل‌شده |
| خرید | supplier، purchase، line، settlement journal | خرید → ورود موجودی → بدهی/پرداخت → سند | Functional |
| تدارکات | requisition، order، receipt، invoice link، return، supplier credit | درخواست تا دریافت و اتصال فاکتور | Functional، گردش پیشرفته نیازمند تست E2E بیشتر |
| موجودی | item، stock movement، location، lot، transfer، count، closure | گردش کالا و لات قابل ردیابی است | Functional |
| فروش | daily summary، menu line، recipe version، closure | فروش روزانه → مصرف مواد → درآمد و COGS | Functional |
| پرسنل | employee، contract، attendance، leave، advance، payroll | کارکرد/قرارداد → حقوق → سند مالی | Functional |
| کنترل مدیریت | budget، commitment، reconciliation، alert، audit | کنترل بودجه/صندوق/هشدار | Functional / بخشی نیازمند پوشش UI بیشتر |
| امنیت و بازیابی | user/session، SQLCipher، backup validation، append-only audit | احراز محلی، رمزنگاری و بازیابی | Functional |

## قواعد حیاتی اثبات‌شده در کد

- `JournalIntegrity` حداقل دو سطر، مبلغ غیرمنفی، فقط یک سمت بدهکار/بستانکار و توازن `Debit = Credit > 0` را الزام می‌کند.
- جمع سطرهای سند با محاسبات overflow-safe انجام می‌شود؛ مسیر تدارکات در این نسخه نیز از `MoneyRial.sum` استفاده می‌کند.
- عملیات خرید، فروش روزانه، شمارش موجودی و حقوق مرتبط با ثبت مالی داخل تراکنش دیتابیس اجرا می‌شوند.
- Triggerهای دیتابیس و Repositoryها تغییر سند/گردش بسته‌شده و هم‌پوشانی دوره‌های مالی را محدود می‌کنند.
- Audit Log و تاریخچه Recipe append-only هستند؛ حذف مخرب یا destructive migration فعال نیست.

## اصلاحات alpha153.6

1. ثبت Audit دارای actor برای ایجاد خرید، تسویه، برگشت تسویه و برگشت خرید.
2. ثبت Audit دارای actor برای ایجاد و برگشت فروش روزانه.
3. ثبت Audit دارای actor برای ایجاد و برگشت سند دستی.
4. تکمیل Sync Outbox برای برگشت تسویه، برگشت خرید و برگشت سند دستی.
5. حذف جمع خام `Long` در کنترل توازن سند تدارکات و استفاده از `MoneyRial.sum` مقاوم به overflow.
6. پاک‌سازی newline و delimiter از متن/actor پیش از Audit برای حفظ قابلیت جست‌وجو و خروجی امن‌تر.

## شکاف‌ها و ریسک‌های باقی‌مانده

| شدت | مورد | تصمیم امن |
|---|---|---|
| HIGH | Build و تست Android در محیط فعلی به‌علت نبود SDK/دسترسی Gradle قابل اجرا نیست | CI یا سیستم دارای Android SDK باید Gate نهایی باشد |
| MEDIUM | Sync کامل عملیاتی نیست و نباید Source of Truth فرض شود | Local DB منبع حقیقت باقی بماند تا قرارداد Conflict Resolution تعریف شود |
| MEDIUM | گزارش‌ها و Global Search در همه Entityها یکپارچه و category-aware نیستند | Query/index و قرارداد UX قبل از توسعه مشخص شود |
| MEDIUM | Customer Receivable در مدل فروش تجمیعی فعلی وجود ندارد | بدون Business Rule واقعی مشتری/اعتبار اضافه نشود |
| MEDIUM | Loan مستقل برای پرسنل دیده نشد؛ Advance موجود است | Loan با Advance ادغام یا از روی نام Feature اختراع نشود |
| LOW | برخی گردش‌های پیشرفته تدارکات/کنترل مدیریت پوشش E2E محدود دارند | تست سازگاری وضعیت‌ها و rollback مرحله بعد |

## نقشه راه اولویت‌دار

1. اجرای `testDebugUnitTest`, `lintDebug`, `assembleDebug` و تست‌های Room/Instrumentation در CI دارای SDK.
2. افزودن Integration Test برای actor audit و rollback عملیات create/reverse/settlement.
3. تکمیل گزارش Account/Item/Employee History با فیلتر تاریخ و reference بین‌ماژولی.
4. تعریف رسمی قرارداد Receivable/Payable و Loan فقط با تأیید قواعد کسب‌وکار.
5. تکمیل Backup/Restore drill روی دیتابیس نسخه‌های واقعی و تست migration آینده.
6. توسعه Global Search فقط پس از طراحی index و کنترل دسترسی داده حساس.

## وضعیت Verification

- `IMPLEMENTED`: اصلاحات Audit/Sync و محاسبات امن.
- `STATIC VERIFIED`: اسکریپت foundation و بررسی ساختاری سورس.
- `BUILD/TEST NOT VERIFIED`: Gradle/Android SDK در محیط اجرا در دسترس نیست؛ موفقیت Build ادعا نمی‌شود.
