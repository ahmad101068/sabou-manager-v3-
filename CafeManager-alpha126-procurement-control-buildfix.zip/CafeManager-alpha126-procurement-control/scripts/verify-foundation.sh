#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"

required_files=(
  "app/src/main/AndroidManifest.xml"
  "app/src/main/java/ir/sabou/inventory/core/MoneyRial.kt"
  "app/src/main/java/ir/sabou/inventory/core/QuantityMicros.kt"
  "app/src/main/java/ir/sabou/inventory/core/SignedLongMath.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
  "app/src/main/java/ir/sabou/inventory/data/db/SalesEntities.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/repository/LocalAccountingRepository.kt"
  "app/src/main/java/ir/sabou/inventory/data/security/DatabaseKeyProvider.kt"
  "app/src/main/java/ir/sabou/inventory/domain/accounting/AccountingModels.kt"
  "app/src/main/java/ir/sabou/inventory/ui/AccountingScreens.kt"
  "app/src/main/java/ir/sabou/inventory/ui/AccountingViewModel.kt"
  "app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
  "app/src/main/java/ir/sabou/inventory/ui/PurchaseManagementDialogs.kt"
  "app/src/main/java/ir/sabou/inventory/ui/PersianDate.kt"
  "app/src/main/java/ir/sabou/inventory/ui/AssetListKeys.kt"
  "app/src/main/java/ir/sabou/inventory/ui/ModuleListKeys.kt"
  "app/src/main/java/ir/sabou/inventory/ui/ClockInput.kt"
  "app/src/main/java/ir/sabou/inventory/ui/InputParsers.kt"
  "app/src/main/java/ir/sabou/inventory/OrganizationIdentity.kt"
  "app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
  "app/src/test/java/ir/sabou/inventory/core/MoneyRialTest.kt"
  "app/src/test/java/ir/sabou/inventory/core/SignedLongMathTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/accounting/AccountingModelsTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/PurchaseManagementTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/purchase/ProcurementModelsTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/PersonnelListKeysTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/AssetListKeysTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/ModuleListKeysTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/ClockInputTest.kt"
  "app/src/test/java/ir/sabou/inventory/ui/InputParsersTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/personnel/EmployeeDraftTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/sales/TableOrderRulesTest.kt"
  "app/src/test/java/ir/sabou/inventory/domain/sales/BillSplitPlannerTest.kt"
  "app/src/test/java/ir/sabou/inventory/OrganizationIdentityTest.kt"
)

for relative in "${required_files[@]}"; do
  test -s "$ROOT/$relative"
done

rg -q 'android:allowBackup="false"' "$ROOT/app/src/main/AndroidManifest.xml"
rg -q 'android:usesCleartextTraffic="false"' "$ROOT/app/src/main/AndroidManifest.xml"
rg -q 'android.permission.INTERNET' "$ROOT/app/src/main/AndroidManifest.xml"
rg -q 'HttpsSyncTransport' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -q 'applicationId = "ir.sabou.inventory"' "$ROOT/app/build.gradle.kts"
rg -q 'minSdk = 23' "$ROOT/app/build.gradle.kts"
rg -q 'SupportOpenHelperFactory' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'version = 24' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -Fq 'versionCode = 160' "$ROOT/app/build.gradle.kts"
rg -Fq 'versionName = "3.0.0-alpha126-procurement-control-buildfix"' "$ROOT/app/build.gradle.kts"
rg -q 'MIGRATION_16_17' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_17_18' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_18_19' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_19_20' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_20_21' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_21_22' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_22_23' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'MIGRATION_23_24' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -q 'ThreeWayMatchStatus' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/ProcurementModels.kt"
rg -q 'GOODS_RECEIPT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalProcurementRepository.kt"
rg -q 'SyncPayloadCodec.sha256' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/SyncRecorder.kt"
rg -q 'suspend fun maxRevision' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/SyncDao.kt"
rg -q 'createInMemory' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/repository/SecurityIntegrationTest.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/repository/AssetOutboxIntegrationTest.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/BackupManagerDeleteTest.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/RestaurantOperationsMigration18To19Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/CoreIdentityMigration19To20Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/AssetQuantityMigration20To21Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/TableOrdersMigration21To22Test.kt"
test -s "$ROOT/app/src/androidTest/java/ir/sabou/inventory/data/db/RestaurantSettlementMigration22To23Test.kt"
test -s "$ROOT/app/src/test/java/ir/sabou/inventory/domain/operations/AccessPolicyTest.kt"
rg -q 'connectedDebugAndroidTest' "$ROOT/.github/workflows/build-apk.yml"
rg -q 'api-level: 23' "$ROOT/.github/workflows/build-apk.yml"
rg -q 'CURRENT_ALGORITHM = "PBKDF2WithHmacSHA1"' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSecurityRepository.kt"
rg -q 'SessionAuthorizer' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -q 'SyncChangeType.DISPOSE' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalAssetRepository.kt"
rg -q 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalAssetRepository.kt"
rg -q 'cipher_integrity_check' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'testImplementation(kotlin("test"))' "$ROOT/app/build.gradle.kts"
rg -Uq 'val reversalOfPaymentId: Long\? = null,\n[[:space:]]*val createdAtEpochMillis: Long,\n[[:space:]]*\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/SalesEntities.kt"
rg -Fq 'return name' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'fun export(name: String, destination: OutputStream)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'fun importFrom(source: InputStream)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'ActivityResultContracts.CreateDocument' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'customerId = customer.id' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSalesRepository.kt"
rg -Fq 'creditLimitRial = customer.creditLimitRial' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSalesRepository.kt"
rg -Fq 'import androidx.compose.runtime.LaunchedEffect' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'fun initialize()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'withContext(Dispatchers.IO)' "$ROOT/app/src/main/java/ir/sabou/inventory/MainActivity.kt"
rg -Fq 'StartupFailure(' "$ROOT/app/src/main/java/ir/sabou/inventory/MainActivity.kt"
rg -Fq 'Build.VERSION.SDK_INT >= Build.VERSION_CODES.O' "$ROOT/app/src/main/java/ir/sabou/inventory/AlertRefreshWorker.kt"
if rg -n 'java\.time\.' "$ROOT/app/src/main/java"; then
  echo "java.time بدون desugaring در کد سازگار با API 23 باقی مانده است." >&2
  exit 1
fi
rg -Fq 'mutableStateOf(listOf(AppScreen.SECURITY.name))' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'require(integrityErrors.isEmpty())' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'if (bootstrap)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSecurityRepository.kt"
rg -Fq 'AppSessionEntity(currentUserId = savedId' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSecurityRepository.kt"
rg -Fq 'suspend fun logout()' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/SecurityModels.kt"
rg -Fq 'suspend fun clearSession()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'canOpenScreen(securityState.currentUser, target)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'canManageKitchen = securityState.currentUser?.role?.allows("KITCHEN") == true' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'suspend fun checkoutTableOrder' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/RestaurantOperationsRepository.kt"
rg -Fq 'skipKitchenDispatch = true' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalRestaurantOperationsRepository.kt"
rg -Fq 'suspend fun checkoutBillSplit' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/RestaurantOperationsRepository.kt"
rg -Fq 'suspend fun closeCashShift' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/RestaurantOperationsRepository.kt"
rg -Fq 'fun printBillSplit' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt"
rg -Fq 'fun printCashShift' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt"
rg -Fq 'personnelEmployeeListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'personnelPayrollListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'assetRecordListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'assetDepreciationListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'label = { Text("تعداد") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'Text("ویرایش")' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"
rg -Fq 'crmCustomerListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/CrmScreens.kt"
rg -Fq 'crmFollowUpListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/CrmScreens.kt"
rg -Fq 'restaurantTableListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/RestaurantOperationsScreens.kt"
rg -Fq 'restaurantTicketListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/RestaurantOperationsScreens.kt"
rg -Fq 'restaurantApprovalListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/RestaurantOperationsScreens.kt"
rg -Fq 'restaurantShiftListKey(it.id)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/RestaurantOperationsScreens.kt"
if rg -n 'items\(state\.(employees|payrolls), key = \{ it\.id \}\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"; then
  echo "کلید خام و مشترک پرسنل/حقوق دوباره وارد فهرست شده است." >&2
  exit 1
fi
if rg -n 'key[[:space:]]*=[[:space:]]*\{[[:space:]]*it\.id[[:space:]]*\}' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/CrmScreens.kt" \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/RestaurantOperationsScreens.kt"; then
  echo "کلید خام مشترک در ماژول CRM یا عملیات رستوران باقی مانده است." >&2
  exit 1
fi
if rg -n 'items\(state\.(assets|depreciations), key = \{ it\.id \}\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AssetScreens.kt"; then
  echo "کلید خام و مشترک دارایی/استهلاک دوباره وارد فهرست شده است." >&2
  exit 1
fi
if rg -n '\bnow\.toEpochDay\(\)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"; then
  echo "ارجاع حذف‌شده now در فرم حقوق باقی مانده است." >&2
  exit 1
fi
rg -Fq 'screen == AppScreen.DASHBOARD || routeStack.size == 1' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"

if rg -Fq 'cursor.moveToFirst() && cursor.getString(0).equals("ok"' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"; then
  echo "تفسیر قدیمی و نادرست cipher_integrity_check باقی مانده است." >&2
  exit 1
fi

if rg -n '\b(OperationGuard|Permission\.MANAGE_)\b' "$ROOT/app/src"; then
  echo "ارجاع به مدل مجوز حذف‌شده در سورس باقی مانده است." >&2
  exit 1
fi

if rg -n 'payloadHash\s*=\s*"local-' "$ROOT/app/src/main"; then
  echo "هش ساختگی payload وارد outbox شده است." >&2
  exit 1
fi
rg -q 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -q 'BalancedJournalDraft' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -Fq 'fun observeSearch(query: String)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'fun observeLowStock()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'PersianDatePickerDialog' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Uq 'internal fun PersianDateField\(\n[[:space:]]*label: String,\n[[:space:]]*epochDay: Long,\n[[:space:]]*onSelected: \(Long\) -> Unit,\n\)' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Fq 'OptionalPersianDateField' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Fq 'printPayrollSlip' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'printJournal' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/AccountingScreens.kt"
rg -Fq 'printManagementSummary' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportsScreens.kt"
rg -Fq 'backupToDrive' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityViewModel.kt"
rg -Fq 'CreateDocument("application/x-sqlite3")' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'fun delete(name: String)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupManager.kt"
rg -Fq 'onDeleteBackup = security::deleteBackup' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'Text("حذف این نسخه"' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'suspend fun resetPinWithRecovery' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/operations/SecurityModels.kt"
rg -Fq 'رمز را فراموش کرده‌ام' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SecurityScreens.kt"
rg -Fq 'recoveryCodeHash TEXT NOT NULL DEFAULT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/AppDatabase.kt"
rg -Fq 'val fatherName: String' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/personnel/PersonnelModels.kt"
rg -Fq 'label = { Text("نام پدر") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'ClockField(checkIn' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'ClockField(checkOut' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'fun formatMoneyInput' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/InputParsers.kt"
rg -Fq 'onValueChange = { amount = formatMoneyInput(it) }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PurchaseManagementDialogs.kt"
rg -Fq 'label = { Text("نام رستوران یا مجموعه") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'FormSection("واحد پول"' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'FormSection("پشتیبان‌گیری خودکار"' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'FontScalePreference.entries' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'import androidx.compose.material3.AlertDialog' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/NavigationSettingsScreens.kt"
rg -Fq 'AutomaticBackupWorker' "$ROOT/app/src/main/java/ir/sabou/inventory/data/BackupScheduling.kt"
rg -Fq 'suspend fun factoryReset()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/AppContainer.kt"
rg -Fq 'مجموع حقوق پرداخت‌شده' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'val employeeCode: String?' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/personnel/PersonnelModels.kt"
rg -Fq 'label = { Text("شماره کارت بانکی (۱۶ رقم)") }' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/PersonnelScreens.kt"
rg -Fq 'AutoClearMessage(operationsState.message' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'organizationDisplayTitle(organizationName)' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'applicationContext.organizationDisplayName()' "$ROOT/app/src/main/java/ir/sabou/inventory/AlertRefreshWorker.kt"
rg -Fq 'context.organizationDisplayName().html()' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/ReportPrinter.kt"
if rg -n 'SABOU  ·|خروج از سابو|کاربر سابو|هویت سابو|سابو منیجر|سبو مدیر' \
  "$ROOT/app/src/main"; then
  echo "نام تجاری قبلی دوباره وارد رابط کاربری شده است." >&2
  exit 1
fi
if rg -n 'Text\("(روز سیستم|روز فروش|از روز|تا روز|تاریخ تولد \(روز عددی\)|تاریخ استخدام \(روز عددی\))"' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/ui"; then
  echo "ورودی تاریخ عددی قدیمی دوباره وارد رابط شده است." >&2
  exit 1
fi
rg -Fq 'PurchasePaymentMethod.TRANSFER' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/OperationsScreens.kt"
rg -Fq 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalOperationsRepository.kt"
rg -Fq 'database.withTransaction' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalAccountingRepository.kt"
rg -Fq 'fun observeJournals(query: String)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'fun observeJournalDetails(entryId: Long)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'fun observeAccountBalances()' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'suspend fun reverseManual' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/accounting/AccountingModels.kt"
rg -Fq 'AppScreen.ACCOUNTING' "$ROOT/app/src/main/java/ir/sabou/inventory/ui/SabouApp.kt"
rg -Fq 'suspend fun settle' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/PurchaseModels.kt"
rg -Fq 'suspend fun reverse' "$ROOT/app/src/main/java/ir/sabou/inventory/domain/purchase/PurchaseModels.kt"
rg -Fq 'PURCHASE_SETTLEMENT' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -Fq 'PURCHASE_REVERSAL' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalPurchaseRepository.kt"
rg -Fq 'expectedPaidRial' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'suspend fun saleConsumptions(saleId: Long)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/db/Daos.kt"
rg -Fq 'val originalConsumptions = database.stockMovementDao().saleConsumptions(saleId)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSalesRepository.kt"
rg -Fq 'require(paymentEpochDay >= sale.saleEpochDay)' "$ROOT/app/src/main/java/ir/sabou/inventory/data/repository/LocalSalesRepository.kt"

if rg -n 'DELETE FROM (journal_entries|journal_lines)' "$ROOT/app/src/main"; then
  echo "حذف مستقیم اسناد مالی ممنوع است." >&2
  exit 1
fi

if rg -n '\b(Double|Float)\b' \
  "$ROOT/app/src/main/java/ir/sabou/inventory/core" \
  "$ROOT/app/src/main/java/ir/sabou/inventory/domain"; then
  echo "نوع اعشاری وارد هسته مالی شده است." >&2
  exit 1
fi

if rg -n 'Math\.(addExact|subtractExact|multiplyExact|negateExact)' \
  "$ROOT/app/src/main/java"; then
  echo "توابع عددی ناسازگار با Android API 23 وارد کد شده‌اند." >&2
  exit 1
fi

if rg -n 'fallbackToDestructiveMigration' "$ROOT/app/src/main"; then
  echo "مهاجرت تخریبی خودکار ممنوع است." >&2
  exit 1
fi

echo "Cafe Restaurant Manager foundation checks passed."
