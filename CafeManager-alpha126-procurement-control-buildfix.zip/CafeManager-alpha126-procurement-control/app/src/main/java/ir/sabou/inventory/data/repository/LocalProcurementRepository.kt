package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.GoodsReceiptEntity
import ir.sabou.inventory.data.db.GoodsReceiptLineEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.db.ProcurementInvoiceLinkEntity
import ir.sabou.inventory.data.db.PurchaseEntity
import ir.sabou.inventory.data.db.PurchaseLineEntity
import ir.sabou.inventory.data.db.PurchaseOrderEntity
import ir.sabou.inventory.data.db.PurchaseOrderLineEntity
import ir.sabou.inventory.data.db.PurchaseRequisitionEntity
import ir.sabou.inventory.data.db.PurchaseRequisitionLineEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.purchase.GoodsReceiptDraft
import ir.sabou.inventory.domain.purchase.PostedPurchase
import ir.sabou.inventory.domain.purchase.ProcurementOverview
import ir.sabou.inventory.domain.purchase.ProcurementRepository
import ir.sabou.inventory.domain.purchase.PurchaseCalculator
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderLineRecord
import ir.sabou.inventory.domain.purchase.PurchaseOrderRecord
import ir.sabou.inventory.domain.purchase.PurchaseOrderStatus
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod
import ir.sabou.inventory.domain.purchase.PurchaseRequisitionDraft
import ir.sabou.inventory.domain.purchase.RequisitionRecord
import ir.sabou.inventory.domain.purchase.RequisitionStatus
import ir.sabou.inventory.domain.purchase.ThreeWayMatchResult
import ir.sabou.inventory.domain.purchase.ThreeWayMatchStatus
import java.util.UUID
import kotlin.math.abs
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class LocalProcurementRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val clock: () -> Long = System::currentTimeMillis,
    private val syncRecorder: SyncRecorder? = null,
) : ProcurementRepository {
    override val overview: Flow<ProcurementOverview> = combine(
        database.procurementDao().observeRequisitions(),
        database.procurementDao().observeRequisitionLines(),
        database.procurementDao().observeOrders(),
        database.procurementDao().observeOrderLines(),
    ) { requisitions, requisitionLines, orders, lines ->
        ProcurementOverview(
            requisitions = requisitions.map {
                RequisitionRecord(
                    id = it.id,
                    requestNo = it.requestNo,
                    department = it.department,
                    requiredEpochDay = it.requiredEpochDay,
                    status = RequisitionStatus.valueOf(it.status),
                    requestedBy = it.requestedBy,
                    approvedBy = it.approvedBy,
                    estimatedTotalRial = MoneyRial.sum(
                        requisitionLines.filter { line -> line.requisitionId == it.id }.map { line ->
                            MoneyRial.of(line.estimatedUnitCostRial).times(QuantityMicros.of(line.requestedQtyMicros))
                        },
                    ).value,
                    lineCount = it.lineCount,
                )
            },
            orders = orders.map { order ->
                PurchaseOrderRecord(
                    id = order.id,
                    orderNo = order.orderNo,
                    supplierId = order.supplierId,
                    supplierName = order.supplierName,
                    requisitionId = order.requisitionId,
                    orderEpochDay = order.orderEpochDay,
                    expectedEpochDay = order.expectedEpochDay,
                    status = PurchaseOrderStatus.valueOf(order.status),
                    orderedValueRial = MoneyRial.sum(
                        lines.filter { it.purchaseOrderId == order.id }.map {
                            MoneyRial.of(it.unitCostRial).times(QuantityMicros.of(it.orderedQtyMicros))
                        },
                    ).value,
                    acceptedValueRial = MoneyRial.sum(
                        lines.filter { it.purchaseOrderId == order.id }.map {
                            MoneyRial.of(it.unitCostRial).times(QuantityMicros.of(it.receivedQtyMicros))
                        },
                    ).value,
                    receiptCount = order.receiptCount,
                    invoiceNo = order.invoiceNo,
                    lines = lines.filter { it.purchaseOrderId == order.id }.map {
                        PurchaseOrderLineRecord(
                            id = it.id,
                            itemId = it.itemId,
                            itemName = it.itemNameSnapshot,
                            orderedQtyMicros = it.orderedQtyMicros,
                            receivedQtyMicros = it.receivedQtyMicros,
                            rejectedQtyMicros = it.rejectedQtyMicros,
                            unitCostRial = it.unitCostRial,
                        )
                    },
                )
            },
        )
    }

    override suspend fun submitRequisition(draft: PurchaseRequisitionDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        val actor = authorizer.actor()
        return database.withTransaction {
            val id = database.procurementDao().insertRequisition(
                PurchaseRequisitionEntity(
                    requestNo = "PR-${now}-${UUID.randomUUID().toString().take(4)}",
                    department = valid.department,
                    requiredEpochDay = valid.requiredEpochDay,
                    status = RequisitionStatus.SUBMITTED.name,
                    requestedBy = actor,
                    approvedBy = null,
                    note = valid.note,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            database.procurementDao().insertRequisitionLines(valid.lines.map { line ->
                val item = database.inventoryDao().activeById(line.itemId)
                    ?: error("یکی از کالاهای درخواست فعال نیست.")
                PurchaseRequisitionLineEntity(
                    requisitionId = id,
                    itemId = item.id,
                    itemNameSnapshot = item.name,
                    requestedQtyMicros = line.quantityMicros,
                    estimatedUnitCostRial = line.estimatedUnitCostRial,
                    note = line.note,
                )
            })
            syncRecorder?.record("PURCHASE_REQUISITION", id, "SUBMIT", now)
            id
        }
    }

    override suspend fun reviewRequisition(requisitionId: Long, approve: Boolean, note: String) {
        authorizer.require("AUDIT")
        require(note.trim().length <= 300) { "توضیحات بررسی بیش از حد طولانی است." }
        val now = clock()
        val actor = authorizer.actor()
        database.withTransaction {
            val current = database.procurementDao().requisitionById(requisitionId)
                ?: error("درخواست خرید پیدا نشد.")
            check(database.procurementDao().transitionRequisition(
                id = current.id,
                expectedStatus = RequisitionStatus.SUBMITTED.name,
                newStatus = if (approve) RequisitionStatus.APPROVED.name else RequisitionStatus.REJECTED.name,
                approvedBy = actor,
                note = note.trim().ifBlank { current.note },
                updatedAtEpochMillis = now,
            ) == 1) { "درخواست قبلاً بررسی شده یا هم‌زمان تغییر کرده است." }
            syncRecorder?.record("PURCHASE_REQUISITION", current.id, if (approve) "APPROVE" else "REJECT", now)
        }
    }

    override suspend fun createOrder(draft: PurchaseOrderDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        val actor = authorizer.actor()
        return database.withTransaction {
            val request = database.procurementDao().requisitionById(valid.requisitionId)
                ?: error("درخواست خرید پیدا نشد.")
            require(request.status == RequisitionStatus.APPROVED.name) { "فقط درخواست تأییدشده قابل تبدیل به سفارش است." }
            val supplier = database.supplierDao().activeById(valid.supplierId)
                ?: error("تأمین‌کننده فعال پیدا نشد.")
            val requestLines = database.procurementDao().requisitionLines(request.id)
            require(requestLines.isNotEmpty()) { "ردیف‌های درخواست پیدا نشدند." }
            val orderId = database.procurementDao().insertOrder(
                PurchaseOrderEntity(
                    orderNo = "PO-${now}-${UUID.randomUUID().toString().take(4)}",
                    supplierId = supplier.id,
                    supplierNameSnapshot = supplier.name,
                    requisitionId = request.id,
                    orderEpochDay = valid.orderEpochDay,
                    expectedEpochDay = valid.expectedEpochDay,
                    status = PurchaseOrderStatus.OPEN.name,
                    note = valid.note,
                    createdBy = actor,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
            database.procurementDao().insertOrderLines(requestLines.map {
                PurchaseOrderLineEntity(
                    purchaseOrderId = orderId,
                    itemId = it.itemId,
                    itemNameSnapshot = it.itemNameSnapshot,
                    orderedQtyMicros = it.requestedQtyMicros,
                    unitCostRial = it.estimatedUnitCostRial,
                    receivedQtyMicros = 0,
                    rejectedQtyMicros = 0,
                )
            })
            check(database.procurementDao().transitionRequisition(
                id = request.id,
                expectedStatus = RequisitionStatus.APPROVED.name,
                newStatus = RequisitionStatus.CONVERTED.name,
                approvedBy = request.approvedBy,
                note = request.note,
                updatedAtEpochMillis = now,
            ) == 1) { "درخواست هم‌زمان تغییر کرده است." }
            syncRecorder?.record("PURCHASE_ORDER", orderId, "CREATE", now)
            orderId
        }
    }

    override suspend fun postGoodsReceipt(draft: GoodsReceiptDraft): Long {
        authorizer.require("PURCHASES")
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(valid.purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(order.status in setOf(PurchaseOrderStatus.OPEN.name, PurchaseOrderStatus.PARTIALLY_RECEIVED.name)) {
                "این سفارش قابل دریافت نیست."
            }
            require(valid.receiptEpochDay >= order.orderEpochDay) { "تاریخ دریافت نمی‌تواند قبل از سفارش باشد." }
            val receiptNo = "GR-${now}-${UUID.randomUUID().toString().take(4)}"
            require(!database.procurementDao().receiptNoExists(receiptNo)) { "شماره رسید تکراری است." }
            require(!database.procurementDao().deliveryNoteExists(order.id, valid.deliveryNoteNo)) {
                "این شماره حواله قبلاً برای سفارش ثبت شده است."
            }
            val receiptId = database.procurementDao().insertReceipt(
                GoodsReceiptEntity(
                    receiptNo = receiptNo,
                    purchaseOrderId = order.id,
                    receiptEpochDay = valid.receiptEpochDay,
                    deliveryNoteNo = valid.deliveryNoteNo,
                    receivedBy = authorizer.actor(),
                    note = valid.note,
                    createdAtEpochMillis = now,
                ),
            )
            val orderLines = database.procurementDao().orderLines(order.id).associateBy { it.id }
            var acceptedTotal = MoneyRial.ZERO
            val receiptLines = valid.lines.map { received ->
                val orderLine = orderLines[received.purchaseOrderLineId]
                    ?: error("ردیف تحویل متعلق به این سفارش نیست.")
                val remaining = orderLine.orderedQtyMicros - orderLine.receivedQtyMicros
                require(received.deliveredQtyMicros <= remaining) { "تحویل «${orderLine.itemNameSnapshot}» از مانده سفارش بیشتر است." }
                val rejected = if (valid.finalizeOrder) {
                    remaining - received.acceptedQtyMicros
                } else {
                    received.deliveredQtyMicros - received.acceptedQtyMicros
                }
                require(rejected == 0L || received.rejectionReason.length >= 3) {
                    "برای کسری یا رد «${orderLine.itemNameSnapshot}» دلیل ثبت کنید."
                }
                check(database.procurementDao().addReceiptQuantities(
                    lineId = orderLine.id,
                    purchaseOrderId = order.id,
                    acceptedQtyMicros = received.acceptedQtyMicros,
                    rejectedQtyMicros = rejected,
                ) == 1) { "مقدار دریافت هم‌زمان تغییر کرده است؛ دوباره تلاش کنید." }
                val acceptedValue = MoneyRial.of(orderLine.unitCostRial).times(QuantityMicros.of(received.acceptedQtyMicros))
                acceptedTotal += acceptedValue
                if (received.acceptedQtyMicros > 0) {
                    val item = database.inventoryDao().activeById(orderLine.itemId)
                        ?: error("کالای «${orderLine.itemNameSnapshot}» فعال نیست.")
                    val nextStock = QuantityMicros.of(item.stockMicros) + QuantityMicros.of(received.acceptedQtyMicros)
                    val nextValue = MoneyRial.of(item.inventoryValueRial) + acceptedValue
                    check(database.inventoryDao().updateValuation(item.id, nextStock.value, nextValue.value, now) == 1) {
                        "به‌روزرسانی موجودی انجام نشد."
                    }
                    database.stockMovementDao().insert(
                        StockMovementEntity(
                            itemId = item.id,
                            movementType = "GOODS_RECEIPT",
                            quantityDeltaMicros = received.acceptedQtyMicros,
                            valueDeltaRial = acceptedValue.value,
                            referenceType = "GOODS_RECEIPT",
                            referenceId = receiptId,
                            movementEpochDay = valid.receiptEpochDay,
                            notes = "${order.orderNo} / ${valid.deliveryNoteNo}",
                            createdAtEpochMillis = now,
                        ),
                    )
                }
                GoodsReceiptLineEntity(
                    goodsReceiptId = receiptId,
                    purchaseOrderLineId = orderLine.id,
                    itemId = orderLine.itemId,
                    deliveredQtyMicros = received.deliveredQtyMicros,
                    acceptedQtyMicros = received.acceptedQtyMicros,
                    rejectedQtyMicros = rejected,
                    rejectionReason = received.rejectionReason,
                    acceptedValueRial = acceptedValue.value,
                )
            }
            database.procurementDao().insertReceiptLines(receiptLines)
            if (acceptedTotal > MoneyRial.ZERO) postJournal(
                entryNo = "رس-$receiptId",
                epochDay = valid.receiptEpochDay,
                description = "دریافت کالا برای ${order.orderNo}",
                sourceType = "GOODS_RECEIPT",
                sourceId = receiptId,
                lines = listOf(
                    JournalLineEntity(entryId = 0, accountCode = "1301", debitRial = acceptedTotal.value, creditRial = 0),
                    JournalLineEntity(entryId = 0, accountCode = "2105", debitRial = 0, creditRial = acceptedTotal.value),
                ),
                now = now,
            )
            val refreshed = database.procurementDao().orderLines(order.id)
            val status = if (valid.finalizeOrder || refreshed.all { it.receivedQtyMicros == it.orderedQtyMicros }) {
                PurchaseOrderStatus.RECEIVED
            } else {
                PurchaseOrderStatus.PARTIALLY_RECEIVED
            }
            check(database.procurementDao().updateOrderStatus(order.id, status.name, now) == 1) { "وضعیت سفارش تغییر نکرد." }
            syncRecorder?.record("GOODS_RECEIPT", receiptId, "POST", now)
            receiptId
        }
    }

    override suspend fun previewThreeWayMatch(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
    ): ThreeWayMatchResult = database.withTransaction { calculateMatch(purchaseOrderId, invoice) }

    override suspend fun postMatchedInvoice(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
        approvePriceVariance: Boolean,
    ): PostedPurchase {
        authorizer.require("PURCHASES")
        val prepared = PurchaseCalculator.prepare(invoice)
        val now = clock()
        return database.withTransaction {
            val order = database.procurementDao().orderById(purchaseOrderId)
                ?: error("سفارش خرید پیدا نشد.")
            require(order.status == PurchaseOrderStatus.RECEIVED.name) { "برای تطبیق فاکتور، دریافت سفارش باید کامل باشد." }
            require(order.supplierId == prepared.draft.supplierId) { "تأمین‌کننده فاکتور با سفارش یکسان نیست." }
            require(prepared.draft.purchaseEpochDay >= order.orderEpochDay) { "تاریخ فاکتور نمی‌تواند قبل از سفارش خرید باشد." }
            require(!database.procurementDao().orderHasInvoice(order.id)) { "برای این سفارش قبلاً فاکتور ثبت شده است." }
            require(!database.purchaseDao().invoiceExists(prepared.draft.invoiceNo)) { "شماره فاکتور خرید تکراری است." }
            val match = calculateMatch(order.id, prepared.draft)
            require(match.status != ThreeWayMatchStatus.QUANTITY_VARIANCE) { "مقدار فاکتور با کالای پذیرفته‌شده یکسان نیست." }
            val requiresApproval = match.status == ThreeWayMatchStatus.PRICE_VARIANCE && match.priceVarianceBasisPoints > 500
            if (requiresApproval) {
                require(approvePriceVariance) { "مغایرت قیمت بیش از ۵٪ است و تأیید مدیر لازم دارد." }
                authorizer.require("AUDIT")
            }
            val paid = prepared.draft.paymentMethod != PurchasePaymentMethod.PAYABLE
            val purchaseId = database.purchaseDao().insert(
                PurchaseEntity(
                    invoiceNo = prepared.draft.invoiceNo,
                    supplierId = order.supplierId,
                    purchaseEpochDay = prepared.draft.purchaseEpochDay,
                    dueEpochDay = prepared.draft.dueEpochDay,
                    totalRial = prepared.total.value,
                    paidRial = if (paid) prepared.total.value else 0,
                    paymentStatus = if (paid) "PAID" else "UNPAID",
                    paymentMethod = prepared.draft.paymentMethod.storedValue,
                    reminderEnabled = !paid && prepared.draft.reminderEnabled,
                    reminderEpochDay = if (!paid && prepared.draft.reminderEnabled) prepared.draft.reminderEpochDay else null,
                    createdAtEpochMillis = now,
                ),
            )
            val items = database.procurementDao().orderLines(order.id).associateBy { it.itemId }
            database.purchaseDao().insertLines(prepared.lines.map { line ->
                val ordered = items[line.itemId] ?: error("کالای فاکتور در سفارش وجود ندارد.")
                PurchaseLineEntity(
                    purchaseId = purchaseId,
                    itemId = line.itemId,
                    itemNameSnapshot = ordered.itemNameSnapshot,
                    quantityMicros = line.quantityMicros,
                    unitCostRial = line.unitCostRial,
                    lineTotalRial = line.total.value,
                )
            })
            val journalLines = buildList {
                add(JournalLineEntity(entryId = 0, accountCode = "2105", debitRial = match.acceptedValueRial, creditRial = 0))
                if (match.priceVarianceRial > 0) {
                    add(JournalLineEntity(entryId = 0, accountCode = "6111", debitRial = match.priceVarianceRial, creditRial = 0))
                } else if (match.priceVarianceRial < 0) {
                    add(JournalLineEntity(entryId = 0, accountCode = "6111", debitRial = 0, creditRial = -match.priceVarianceRial))
                }
                add(JournalLineEntity(
                    entryId = 0,
                    accountCode = requireNotNull(prepared.draft.paymentMethod.accountCode),
                    debitRial = 0,
                    creditRial = prepared.total.value,
                ))
            }
            val journalId = postJournal(
                entryNo = "تخ-$purchaseId",
                epochDay = prepared.draft.purchaseEpochDay,
                description = "تطبیق فاکتور ${prepared.draft.invoiceNo} با ${order.orderNo}",
                sourceType = "PROCUREMENT_INVOICE",
                sourceId = purchaseId,
                lines = journalLines,
                now = now,
            )
            database.procurementDao().insertInvoiceLink(
                ProcurementInvoiceLinkEntity(
                    purchaseOrderId = order.id,
                    purchaseId = purchaseId,
                    matchStatus = match.status.name,
                    acceptedValueRial = match.acceptedValueRial,
                    invoiceValueRial = match.invoiceValueRial,
                    priceVarianceRial = match.priceVarianceRial,
                    varianceApprovedBy = if (requiresApproval) authorizer.actor() else null,
                    matchedAtEpochMillis = now,
                ),
            )
            check(database.procurementDao().updateOrderStatus(order.id, PurchaseOrderStatus.CLOSED.name, now) == 1) {
                "بستن سفارش انجام نشد."
            }
            syncRecorder?.record("PURCHASE", purchaseId, "THREE_WAY_MATCH", now)
            PostedPurchase(purchaseId, journalId, prepared.total)
        }
    }

    private suspend fun calculateMatch(purchaseOrderId: Long, invoice: PurchaseDraft): ThreeWayMatchResult {
        val prepared = PurchaseCalculator.prepare(invoice)
        val accepted = database.procurementDao().orderLines(purchaseOrderId)
        require(accepted.isNotEmpty()) { "ردیف‌های سفارش پیدا نشدند." }
        val invoiceQty = prepared.lines.associate { it.itemId to it.quantityMicros }
        val acceptedQty = accepted.filter { it.receivedQtyMicros > 0 }.associate { it.itemId to it.receivedQtyMicros }
        val quantityMatches = invoiceQty == acceptedQty
        val acceptedValue = MoneyRial.sum(accepted.map {
            MoneyRial.of(it.unitCostRial).times(QuantityMicros.of(it.receivedQtyMicros))
        }).value
        val variance = prepared.total.value - acceptedValue
        val basisPoints = if (acceptedValue == 0L) 0L else {
            java.math.BigInteger.valueOf(abs(variance))
                .multiply(java.math.BigInteger.valueOf(10_000))
                .divide(java.math.BigInteger.valueOf(acceptedValue))
                .longValueExact()
        }
        val status = when {
            !quantityMatches -> ThreeWayMatchStatus.QUANTITY_VARIANCE
            variance != 0L -> ThreeWayMatchStatus.PRICE_VARIANCE
            else -> ThreeWayMatchStatus.MATCHED
        }
        return ThreeWayMatchResult(status, acceptedValue, prepared.total.value, variance, basisPoints)
    }

    private suspend fun postJournal(
        entryNo: String,
        epochDay: Long,
        description: String,
        sourceType: String,
        sourceId: Long,
        lines: List<JournalLineEntity>,
        now: Long,
    ): Long {
        lines.forEach { require(database.accountingDao().activeAccountExists(it.accountCode)) { "حساب ${it.accountCode} فعال نیست." } }
        require(lines.sumOf { it.debitRial } == lines.sumOf { it.creditRial }) { "سند حسابداری توازن ندارد." }
        val entryId = database.accountingDao().insertEntry(
            JournalEntryEntity(
                entryNo = entryNo,
                entryEpochDay = epochDay,
                description = description,
                sourceType = sourceType,
                sourceId = sourceId,
                createdAtEpochMillis = now,
            ),
        )
        database.accountingDao().insertLines(lines.map { it.copy(entryId = entryId) })
        return entryId
    }
}
