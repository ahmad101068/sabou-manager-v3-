package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.purchase.GoodsReceiptDraft
import ir.sabou.inventory.domain.purchase.GoodsReceiptLineDraft
import ir.sabou.inventory.domain.purchase.PurchaseDraft
import ir.sabou.inventory.domain.purchase.PurchaseLineDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderDraft
import ir.sabou.inventory.domain.purchase.PurchaseOrderRecord
import ir.sabou.inventory.domain.purchase.PurchaseOrderStatus
import ir.sabou.inventory.domain.purchase.PurchasePaymentMethod
import ir.sabou.inventory.domain.purchase.PurchaseRequisitionDraft
import ir.sabou.inventory.domain.purchase.RequisitionLineDraft
import ir.sabou.inventory.domain.purchase.RequisitionRecord
import ir.sabou.inventory.domain.purchase.RequisitionStatus

@Composable
internal fun ProcurementControlPanel(
    state: OperationsUiState,
    onSubmit: (PurchaseRequisitionDraft, () -> Unit) -> Unit,
    onReview: (Long, Boolean) -> Unit,
    onCreateOrder: (PurchaseOrderDraft, () -> Unit) -> Unit,
    onReceive: (GoodsReceiptDraft, () -> Unit) -> Unit,
    onMatchInvoice: (Long, PurchaseDraft, Boolean, () -> Unit) -> Unit,
) {
    var requestDialog by remember { mutableStateOf(false) }
    var orderTarget by remember { mutableStateOf<RequisitionRecord?>(null) }
    var receiptTarget by remember { mutableStateOf<PurchaseOrderRecord?>(null) }
    var invoiceTarget by remember { mutableStateOf<PurchaseOrderRecord?>(null) }
    val procurement = state.procurement

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("کنترل تدارکات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text("درخواست ← سفارش ← دریافت ← تطبیق سه‌طرفه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Button(onClick = { requestDialog = true }, enabled = !state.busy) { Text("درخواست جدید") }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricTile("منتظر تأیید", procurement.awaitingApproval.toString(), Modifier.weight(1f))
                MetricTile("سفارش باز", procurement.openOrders.toString(), Modifier.weight(1f))
                MetricTile("منتظر فاکتور", procurement.pendingInvoiceMatches.toString(), Modifier.weight(1f))
            }
            procurement.requisitions.take(5).forEach { request ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${request.requestNo} · ${request.department}", fontWeight = FontWeight.Bold)
                        Text("${request.lineCount} قلم · برآورد ${formatMoney(request.estimatedTotalRial)} · ${requisitionTitle(request.status)}")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (request.status == RequisitionStatus.SUBMITTED) {
                                Button(onClick = { onReview(request.id, true) }, enabled = !state.busy) { Text("تأیید") }
                                TextButton(onClick = { onReview(request.id, false) }, enabled = !state.busy) { Text("رد") }
                            }
                            if (request.status == RequisitionStatus.APPROVED) {
                                OutlinedButton(onClick = { orderTarget = request }) { Text("ساخت سفارش") }
                            }
                        }
                    }
                }
            }
            procurement.orders.take(5).forEach { order ->
                Card {
                    Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${order.orderNo} · ${order.supplierName}", fontWeight = FontWeight.Bold)
                        Text("${orderStatusTitle(order.status)} · پذیرفته ${formatMoney(order.acceptedValueRial)} از ${formatMoney(order.orderedValueRial)}")
                        if (order.lines.any { it.rejectedQtyMicros > 0 }) {
                            Text("این سفارش دارای مغایرت/مرجوعی ثبت‌شده است.", color = MaterialTheme.colorScheme.error)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (order.status in setOf(PurchaseOrderStatus.OPEN, PurchaseOrderStatus.PARTIALLY_RECEIVED)) {
                                OutlinedButton(onClick = { receiptTarget = order }) { Text("ثبت تحویل") }
                            }
                            if (order.status == PurchaseOrderStatus.RECEIVED && order.invoiceNo == null) {
                                Button(onClick = { invoiceTarget = order }) { Text("تطبیق فاکتور") }
                            }
                            order.invoiceNo?.let { Text("فاکتور $it", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
            }
        }
    }

    if (requestDialog) RequisitionDialog(state, { requestDialog = false }) { draft ->
        onSubmit(draft) { requestDialog = false }
    }
    orderTarget?.let { target -> OrderDialog(state, target, { orderTarget = null }) { draft ->
        onCreateOrder(draft) { orderTarget = null }
    } }
    receiptTarget?.let { target -> ReceiptDialog(target, { receiptTarget = null }) { draft ->
        onReceive(draft) { receiptTarget = null }
    } }
    invoiceTarget?.let { target -> MatchedInvoiceDialog(state, target, { invoiceTarget = null }) { draft, override ->
        onMatchInvoice(target.id, draft, override) { invoiceTarget = null }
    } }
}

@Composable
private fun RequisitionDialog(
    state: OperationsUiState,
    onDismiss: () -> Unit,
    onConfirm: (PurchaseRequisitionDraft) -> Unit,
) {
    var department by remember { mutableStateOf("") }
    var requiredDay by remember { mutableLongStateOf(currentEpochDay()) }
    var itemId by remember { mutableStateOf<Long?>(null) }
    var quantity by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var lines by remember { mutableStateOf<List<RequisitionLineDraft>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("درخواست خرید") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                OutlinedTextField(department, { department = it }, label = { Text("واحد درخواست‌کننده") }, modifier = Modifier.fillMaxWidth())
                PersianDateField("تاریخ نیاز", requiredDay) { requiredDay = it }
                SelectionField("کالا", state.inventoryItems.firstOrNull { it.id == itemId }?.name, state.inventoryItems.map { it.id to it.name }) { itemId = it }
                OutlinedTextField(quantity, { quantity = it }, label = { Text("مقدار") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cost, { cost = it }, label = { Text("برآورد قیمت واحد (ریال)") }, modifier = Modifier.fillMaxWidth())
                OutlinedButton(onClick = {
                    runCatching {
                        val selected = requireNotNull(itemId) { "کالا را انتخاب کنید." }
                        require(lines.none { it.itemId == selected }) { "این کالا قبلاً اضافه شده است." }
                        lines = lines + RequisitionLineDraft(selected, parseQuantity(quantity).value, parseMoneyRial(cost).value)
                        quantity = ""; cost = ""; itemId = null; error = null
                    }.onFailure { error = it.message }
                }, modifier = Modifier.fillMaxWidth()) { Text("افزودن قلم") }
                lines.forEach { line ->
                    Text("• ${state.inventoryItems.firstOrNull { it.id == line.itemId }?.name} — ${formatQuantity(line.quantityMicros)}")
                }
            }
        },
        confirmButton = { Button(onClick = {
            runCatching { PurchaseRequisitionDraft(department, requiredDay, lines = lines).validated() }
                .onSuccess(onConfirm).onFailure { error = it.message }
        }, enabled = !state.busy) { Text("ارسال برای تأیید") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun OrderDialog(
    state: OperationsUiState,
    request: RequisitionRecord,
    onDismiss: () -> Unit,
    onConfirm: (PurchaseOrderDraft) -> Unit,
) {
    var supplierId by remember { mutableStateOf<Long?>(null) }
    var orderDay by remember { mutableLongStateOf(currentEpochDay()) }
    var expectedDay by remember { mutableLongStateOf(request.requiredEpochDay.coerceAtLeast(orderDay)) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ساخت سفارش از ${request.requestNo}") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            SelectionField("تأمین‌کننده", state.suppliers.firstOrNull { it.id == supplierId }?.name, state.suppliers.map { it.id to it.name }) { supplierId = it }
            PersianDateField("تاریخ سفارش", orderDay) { orderDay = it; if (expectedDay < it) expectedDay = it }
            PersianDateField("تاریخ تحویل مورد انتظار", expectedDay) { expectedDay = it }
        } },
        confirmButton = { Button(onClick = {
            runCatching { PurchaseOrderDraft(request.id, requireNotNull(supplierId) { "تأمین‌کننده را انتخاب کنید." }, orderDay, expectedDay).validated() }
                .onSuccess(onConfirm).onFailure { error = it.message }
        }, enabled = !state.busy) { Text("ایجاد سفارش") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

private data class ReceiptInput(val delivered: String, val accepted: String, val reason: String)

@Composable
private fun ReceiptDialog(order: PurchaseOrderRecord, onDismiss: () -> Unit, onConfirm: (GoodsReceiptDraft) -> Unit) {
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var deliveryNo by remember { mutableStateOf("") }
    var finalizeOrder by remember { mutableStateOf(false) }
    var values by remember(order.id) { mutableStateOf(order.lines.associate { it.id to ReceiptInput(formatQuantity(it.remainingQtyMicros), formatQuantity(it.remainingQtyMicros), "") }) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تحویل ${order.orderNo}") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedTextField(deliveryNo, { deliveryNo = it }, label = { Text("شماره حواله تأمین‌کننده") }, modifier = Modifier.fillMaxWidth())
            PersianDateField("تاریخ تحویل", day) { day = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(finalizeOrder, { finalizeOrder = it })
                Text("این آخرین تحویل است؛ مانده ثبت‌نشده به‌عنوان کسری بسته شود")
            }
            order.lines.filter { it.remainingQtyMicros > 0 }.forEach { line ->
                val value = values.getValue(line.id)
                Card { Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${line.itemName} · مانده ${formatQuantity(line.remainingQtyMicros)}", fontWeight = FontWeight.Bold)
                    OutlinedTextField(value.delivered, { values = values + (line.id to value.copy(delivered = it)) }, label = { Text("مقدار تحویلی") })
                    OutlinedTextField(value.accepted, { values = values + (line.id to value.copy(accepted = it)) }, label = { Text("مقدار پذیرفته‌شده") })
                    OutlinedTextField(value.reason, { values = values + (line.id to value.copy(reason = it)) }, label = { Text("دلیل کسری/رد (در صورت مغایرت)") })
                } }
            }
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                GoodsReceiptDraft(order.id, day, deliveryNo, finalizeOrder = finalizeOrder, lines = order.lines.filter { it.remainingQtyMicros > 0 }.map { line ->
                    val value = values.getValue(line.id)
                    GoodsReceiptLineDraft(line.id, parseQuantity(value.delivered).value, parseQuantity(value.accepted).value, value.reason)
                }).validated()
            }.onSuccess(onConfirm).onFailure { error = it.message }
        }) { Text("ثبت رسید و موجودی") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun MatchedInvoiceDialog(
    state: OperationsUiState,
    order: PurchaseOrderRecord,
    onDismiss: () -> Unit,
    onConfirm: (PurchaseDraft, Boolean) -> Unit,
) {
    var invoiceNo by remember { mutableStateOf("") }
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var dueDay by remember { mutableLongStateOf(day) }
    var costs by remember(order.id) { mutableStateOf(order.lines.associate { it.id to it.unitCostRial.toString() }) }
    var approveVariance by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تطبیق سه‌طرفه ${order.orderNo}") },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Text("مقدار فاکتور با مقدار پذیرفته‌شده کنترل می‌شود؛ تغییر قیمت بیش از ۵٪ تأیید مدیر می‌خواهد.")
            OutlinedTextField(invoiceNo, { invoiceNo = it }, label = { Text("شماره فاکتور تأمین‌کننده") }, modifier = Modifier.fillMaxWidth())
            PersianDateField("تاریخ فاکتور", day) { day = it; if (dueDay < it) dueDay = it }
            PersianDateField("سررسید", dueDay) { dueDay = it }
            order.lines.forEach { line ->
                OutlinedTextField(costs.getValue(line.id), { costs = costs + (line.id to it) }, label = { Text("قیمت واحد ${line.itemName}") }, modifier = Modifier.fillMaxWidth())
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(approveVariance, { approveVariance = it })
                Text("تأیید مدیریتی مغایرت قیمت بیش از ۵٪")
            }
        } },
        confirmButton = { Button(onClick = {
            runCatching {
                PurchaseDraft(
                    invoiceNo = invoiceNo,
                    supplierId = order.supplierId,
                    purchaseEpochDay = day,
                    dueEpochDay = dueDay,
                    paymentMethod = PurchasePaymentMethod.PAYABLE,
                    reminderEnabled = true,
                    reminderEpochDay = dueDay,
                    lines = order.lines.filter { it.receivedQtyMicros > 0 }.map { line ->
                        PurchaseLineDraft(line.itemId, ir.sabou.inventory.core.QuantityMicros.of(line.receivedQtyMicros), parseMoneyRial(costs.getValue(line.id)))
                    },
                )
            }.onSuccess { onConfirm(it, approveVariance) }.onFailure { error = it.message }
        }, enabled = !state.busy) { Text("تطبیق و ثبت فاکتور") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

private fun requisitionTitle(status: RequisitionStatus): String = when (status) {
    RequisitionStatus.SUBMITTED -> "منتظر تأیید"
    RequisitionStatus.APPROVED -> "تأییدشده"
    RequisitionStatus.REJECTED -> "ردشده"
    RequisitionStatus.CONVERTED -> "تبدیل به سفارش"
}

private fun orderStatusTitle(status: PurchaseOrderStatus): String = when (status) {
    PurchaseOrderStatus.OPEN -> "باز"
    PurchaseOrderStatus.PARTIALLY_RECEIVED -> "تحویل جزئی"
    PurchaseOrderStatus.RECEIVED -> "دریافت کامل"
    PurchaseOrderStatus.CLOSED -> "بسته‌شده"
    PurchaseOrderStatus.CANCELLED -> "لغوشده"
}
