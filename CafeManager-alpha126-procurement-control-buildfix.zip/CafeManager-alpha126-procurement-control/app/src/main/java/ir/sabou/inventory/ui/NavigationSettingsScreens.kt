package ir.sabou.inventory.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowOutward
import androidx.compose.material.icons.outlined.ColorLens
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.data.AutomaticBackupFrequency
import ir.sabou.inventory.data.BackupPolicy

enum class ThemePreference(val title: String, val description: String) {
    SYSTEM("مطابق گوشی", "حالت روشن یا تیره را از تنظیمات دستگاه بگیر"),
    LIGHT("روشن", "پس‌زمینه روشن برای محیط‌های پرنور"),
    DARK("تیره", "نمای تیره برای استفاده شبانه"),
}

enum class FontScalePreference(val title: String, val multiplier: Float) {
    NORMAL("معمولی", 1f),
    LARGE("بزرگ", 1.15f),
    EXTRA_LARGE("خیلی بزرگ", 1.3f),
}

internal data class NavigationDestination(
    val title: String,
    val subtitle: String,
    val keywords: String,
    val screen: AppScreen,
)

internal val navigationDestinations = listOf(
    NavigationDestination("خرید و فاکتورها", "ثبت، جست‌وجو و تسویه خرید", "خرید فاکتور تامین کننده پرداخت", AppScreen.PURCHASES),
    NavigationDestination("ثبت خرید جدید", "ایجاد فاکتور خرید", "خرید جدید فاکتور", AppScreen.NEW_PURCHASE),
    NavigationDestination("تأمین‌کنندگان", "مدیریت فروشندگان و مانده‌ها", "تامین کننده فروشنده", AppScreen.SUPPLIERS),
    NavigationDestination("انبار", "کالا، موجودی و انبارگردانی", "انبار کالا موجودی شمارش", AppScreen.INVENTORY),
    NavigationDestination("فروش", "فاکتور فروش و دریافت‌ها", "فروش مشتری فاکتور دریافت", AppScreen.SALES),
    NavigationDestination("تولید و رسپی", "محصول و مواد اولیه", "رسپی تولید محصول مواد اولیه", AppScreen.RECIPES),
    NavigationDestination("حسابداری", "اسناد، حساب‌ها و گزارش‌های مالی", "حسابداری سند حساب دفتر تراز سود", AppScreen.ACCOUNTING),
    NavigationDestination("ثبت سند جدید", "سند دستی حسابداری", "سند جدید حسابداری", AppScreen.NEW_JOURNAL),
    NavigationDestination("CRM", "باشگاه مشتریان و پیگیری", "مشتری امتیاز پیگیری باشگاه", AppScreen.CRM),
    NavigationDestination("پرسنل و حقوق", "کارکنان و پرداخت حقوق", "پرسنل کارمند حقوق", AppScreen.PERSONNEL),
    NavigationDestination("دارایی‌های ثابت", "اموال و استهلاک", "دارایی اموال استهلاک", AppScreen.ASSETS),
    NavigationDestination("مرکز هشدارها", "هشدارهای عملیاتی و مالی", "هشدار سررسید موجودی", AppScreen.ALERTS),
    NavigationDestination("گزارش‌های مدیریتی", "شاخص‌های کلیدی کسب‌وکار", "گزارش فروش سود موجودی", AppScreen.REPORTS),
    NavigationDestination("لاگ عملیات", "ردیابی تغییرات و حسابرسی", "لاگ حسابرسی عملیات", AppScreen.AUDIT_LOG),
    NavigationDestination("کاربران و پشتیبان", "امنیت، کاربران و نسخه پشتیبان", "کاربر امنیت بکاپ پشتیبان", AppScreen.SECURITY),
    NavigationDestination("تنظیمات برنامه", "ظاهر و تجربه کاربری", "تنظیمات ظاهر تم", AppScreen.SETTINGS),
    NavigationDestination("عملیات رستوران", "میز، رزرو، آشپزخانه و شیفت", "میز رزرو آشپزخانه شیفت تایید", AppScreen.RESTAURANT_OPERATIONS),
)

@Composable
internal fun GlobalSearchScreen(
    currentUser: ir.sabou.inventory.domain.operations.AppUserRecord?,
    onOpen: (AppScreen) -> Unit,
    onBack: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    val allowed = navigationDestinations.filter { destination ->
        canOpenScreen(currentUser, destination.screen)
    }
    val normalized = query.trim()
    val results = if (normalized.isBlank()) allowed else allowed.filter {
        it.title.contains(normalized, ignoreCase = true) ||
            it.subtitle.contains(normalized, ignoreCase = true) ||
            it.keywords.contains(normalized, ignoreCase = true)
    }

    Scaffold(topBar = { ProfessionalTopBar("جست‌وجوی سراسری", "دسترسی سریع به همه بخش‌های مجاز", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("نام بخش یا عملیات") },
                    placeholder = { Text("مثلاً انبار، حقوق یا سند") },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                )
            }
            item {
                Text(
                    if (query.isBlank()) "همه میان‌برها" else "${results.size} نتیجه",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                )
            }
            if (results.isEmpty()) {
                item { EmptyStatePanel("نتیجه‌ای پیدا نشد", "عبارت کوتاه‌تری وارد کنید یا نام بخش را تغییر دهید.") }
            } else {
                items(results) { destination ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onOpen(destination.screen) },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                                androidx.compose.material3.Icon(
                                    Icons.Outlined.ArrowOutward,
                                    contentDescription = null,
                                    modifier = Modifier.padding(10.dp).size(20.dp),
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(destination.title, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(destination.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
internal fun SettingsScreen(
    organizationName: String,
    onOrganizationNameChange: (String) -> Unit,
    themePreference: ThemePreference,
    currencyUnit: CurrencyUnit,
    fontScalePreference: FontScalePreference,
    backupPolicy: BackupPolicy,
    syncState: SyncUiState,
    onSaveSync: (String,String,Boolean) -> Unit,
    onRunSync: () -> Unit,
    onThemePreferenceChange: (ThemePreference) -> Unit,
    onCurrencyUnitChange: (CurrencyUnit) -> Unit,
    onFontScalePreferenceChange: (FontScalePreference) -> Unit,
    onBackupPolicyChange: (BackupPolicy) -> Unit,
    onFactoryReset: () -> Unit,
    onOpenSecurity: () -> Unit,
    showSensitiveSettings: Boolean,
    canFactoryReset: Boolean,
    onBack: () -> Unit,
) {
    var organizationNameDraft by remember(organizationName) { mutableStateOf(organizationName) }
    var showResetConfirmation by remember { mutableStateOf(false) }
    Scaffold(topBar = { ProfessionalTopBar("تنظیمات برنامه", "ظاهر، امنیت و اطلاعات نسخه", onBack) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                BrandStatementCard(
                    title = "هویت مجموعه",
                    description = "نام رستوران، کافه یا مجموعه خود را وارد کنید تا در داشبورد، اعلان‌ها و چاپ‌ها نمایش داده شود.",
                )
            }
            item {
                FormSection("نام مجموعه", "اگر این قسمت خالی باشد، عنوان عمومی «مدیریت کافه رستوران» نمایش داده می‌شود") {
                    OutlinedTextField(
                        value = organizationNameDraft,
                        onValueChange = { organizationNameDraft = it.take(80) },
                        label = { Text("نام رستوران یا مجموعه") },
                        placeholder = { Text("مثلاً رستوران نمونه") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Button(
                        onClick = { onOrganizationNameChange(organizationNameDraft.trim()) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("ذخیره نام مجموعه") }
                }
            }
            item {
                FormSection("ظاهر برنامه", "انتخاب شما بلافاصله اعمال و روی دستگاه ذخیره می‌شود") {
                    ThemePreference.entries.forEach { preference ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { onThemePreferenceChange(preference) },
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (themePreference == preference) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                            ),
                            border = BorderStroke(1.dp, if (themePreference == preference) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                        ) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(preference.title, fontWeight = FontWeight.Bold)
                                    Text(preference.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Text(if (themePreference == preference) "●" else "○", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                    Text("اندازه نوشته‌ها", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FontScalePreference.entries.forEach { preference ->
                            OutlinedButton(
                                onClick = { onFontScalePreferenceChange(preference) },
                                modifier = Modifier.weight(1f),
                            ) { Text(if (fontScalePreference == preference) "✓ ${preference.title}" else preference.title) }
                        }
                    }
                }
            }
            item {
                FormSection("واحد پول", "مبالغ در دیتابیس به‌صورت ریال ذخیره می‌شوند و فقط ورود و نمایش تغییر می‌کند") {
                    CurrencyUnit.entries.forEach { unit ->
                        OutlinedButton(
                            onClick = { onCurrencyUnitChange(unit) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (currencyUnit == unit) "✓ ${currencyUnitLabel(unit)}" else currencyUnitLabel(unit)) }
                    }
                }
            }
            if (showSensitiveSettings) {
                item {
                    FormSection("پشتیبان‌گیری خودکار", "نسخه‌های خودکار داخل فضای امن برنامه ساخته و براساس سقف انتخابی نگهداری می‌شوند") {
                    AutomaticBackupFrequency.entries.forEach { frequency ->
                        OutlinedButton(
                            onClick = { onBackupPolicyChange(backupPolicy.copy(frequency = frequency)) },
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text(if (backupPolicy.frequency == frequency) "✓ ${frequency.title}" else frequency.title) }
                    }
                    Text("حداکثر فایل‌های پشتیبان", fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(10, 25, 50, 100).forEach { count ->
                            OutlinedButton(
                                onClick = { onBackupPolicyChange(backupPolicy.copy(maxFiles = count)) },
                                modifier = Modifier.weight(1f),
                            ) { Text(if (backupPolicy.maxFiles == count) "✓ $count" else count.toString()) }
                        }
                    }
                    Text("ذخیره مستقیم در Google Drive فعلاً از بخش کاربران و پشتیبان و با انتخاب امن فایل انجام می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            if (showSensitiveSettings) {
                item { SyncHealthPanel(syncState) }
                item { SyncConfigurationPanel(syncState,onSaveSync,onRunSync) }
            }
            item {
                FormSection("امنیت و داده‌ها", "مدیریت کاربران، پشتیبان‌گیری و بازیابی") {
                    TextButton(onClick = onOpenSecurity, modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.Icon(Icons.Outlined.Security, null, modifier = Modifier.size(20.dp))
                        Text("باز کردن کاربران و پشتیبان", modifier = Modifier.padding(start = 8.dp), fontWeight = FontWeight.Bold)
                    }
                    if (canFactoryReset) {
                        OutlinedButton(onClick = { showResetConfirmation = true }, modifier = Modifier.fillMaxWidth()) {
                            Text("بازنشانی کامل اطلاعات برنامه", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
            item {
                FormSection("درباره برنامه") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("نسخه")
                        Text("3.0.0-alpha126-procurement-control-buildfix", fontWeight = FontWeight.Bold)
                    }
                    Text("مدیریت کافه رستوران", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                    Text("مدیریت یکپارچه خرید، فروش، انبار، حسابداری و عملیات مجموعه", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item { Spacer(Modifier.height(20.dp)) }
        }
    }
    if (showResetConfirmation) {
        AlertDialog(
            onDismissRequest = { showResetConfirmation = false },
            title = { Text("بازنشانی کامل برنامه") },
            text = { Text("همه اطلاعات، کاربران، تنظیمات اتصال و فایل‌های پشتیبان محلی پاک می‌شوند. این عملیات قابل بازگشت نیست.") },
            confirmButton = {
                Button(onClick = { showResetConfirmation = false; onFactoryReset() }) { Text("پاک‌کردن همه اطلاعات") }
            },
            dismissButton = { TextButton(onClick = { showResetConfirmation = false }) { Text("انصراف") } },
        )
    }
}

@Composable private fun SyncConfigurationPanel(state:SyncUiState,onSave:(String,String,Boolean)->Unit,onRun:()->Unit){var endpoint by remember(state.config.endpoint){mutableStateOf(state.config.endpoint)};var tenant by remember(state.config.tenantId){mutableStateOf(state.config.tenantId)};var enabled by remember(state.config.enabled){mutableStateOf(state.config.enabled)};FormSection("اتصال ابری","نشانی HTTPS و شناسه مجموعه را وارد کنید"){OutlinedTextField(endpoint,{endpoint=it},label={Text("نشانی سرویس")},modifier=Modifier.fillMaxWidth(),singleLine=true);OutlinedTextField(tenant,{tenant=it},label={Text("شناسه مجموعه")},modifier=Modifier.fillMaxWidth(),singleLine=true);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("فعال‌سازی همگام‌سازی");Switch(enabled,{enabled=it})};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={onSave(endpoint,tenant,enabled)}){Text("ذخیره")};OutlinedButton(onClick=onRun,enabled=enabled&&!state.running){Text(if(state.running)"در حال اجرا…" else "همگام‌سازی اکنون")}};state.message?.let{Text(it,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable
private fun SyncHealthPanel(state: SyncUiState) {
    val summary = state.summary
    val (title, color) = when (summary.health) {
        ir.sabou.inventory.domain.operations.SyncHealth.HEALTHY -> "همگام‌سازی سالم" to MaterialTheme.colorScheme.primary
        ir.sabou.inventory.domain.operations.SyncHealth.PENDING_WORK -> "تغییر در انتظار همگام‌سازی" to MaterialTheme.colorScheme.secondary
        ir.sabou.inventory.domain.operations.SyncHealth.NEEDS_ATTENTION -> "نیازمند بررسی تعارض" to MaterialTheme.colorScheme.error
    }
    FormSection("وضعیت همگام‌سازی", "پایش صف تغییرات آفلاین دستگاه") {
        StatusPill(title, containerColor = color.copy(alpha = .14f), contentColor = color)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CompactInfoRow("کل تغییرات", summary.total.toString())
            CompactInfoRow("در انتظار", summary.pending.toString())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            CompactInfoRow("همگام‌شده", summary.synced.toString())
            CompactInfoRow("تعارض", summary.conflicts.toString())
        }
    }
}
