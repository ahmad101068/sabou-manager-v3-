package ir.sabou.inventory.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import ir.sabou.inventory.data.security.DatabaseKeyProvider
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory

@Database(
    entities = [
        AccountEntity::class,
        JournalEntryEntity::class,
        JournalLineEntity::class,
        SupplierEntity::class,
        InventoryItemEntity::class,
        PurchaseEntity::class,
        PurchaseLineEntity::class,
        StockMovementEntity::class,
        EmployeeEntity::class,
        AttendanceEntity::class,
        LeaveEntity::class,
        PayrollRunEntity::class,
        EmployeeContractEntity::class,
        EmployeeAdvanceEntity::class,
        PerformanceGoalEntity::class,
        PerformanceReviewEntity::class,
        PerformanceScoreEntity::class,
        CustomerEntity::class,
        SaleEntity::class,
        SaleLineEntity::class,
        SalePaymentEntity::class,
        MenuItemEntity::class,
        RecipeIngredientEntity::class,
        InventoryCountEntity::class,
        AuditLogEntity::class,
        AppUserEntity::class,
        AppSessionEntity::class,
        FixedAssetEntity::class,
        AssetDepreciationEntity::class,
        LoyaltyTransactionEntity::class,
        CustomerFollowUpEntity::class,
        AppAlertEntity::class,
        SyncChangeEntity::class,
        RestaurantTableEntity::class,
        ReservationEntity::class,
        KitchenTicketEntity::class,
        PlannedShiftEntity::class,
        ApprovalRequestEntity::class,
        TableOrderEntity::class,
        TableOrderLineEntity::class,
        BillSplitEntity::class,
        BillSplitLineEntity::class,
        CashShiftEntity::class,
        PurchaseRequisitionEntity::class,
        PurchaseRequisitionLineEntity::class,
        PurchaseOrderEntity::class,
        PurchaseOrderLineEntity::class,
        GoodsReceiptEntity::class,
        GoodsReceiptLineEntity::class,
        ProcurementInvoiceLinkEntity::class,
    ],
    version = 24,
    exportSchema = true,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun supplierDao(): SupplierDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun purchaseDao(): PurchaseDao
    abstract fun stockMovementDao(): StockMovementDao
    abstract fun accountingDao(): AccountingDao
    abstract fun personnelDao(): PersonnelDao
    abstract fun performanceDao(): PerformanceDao
    abstract fun salesDao(): SalesDao
    abstract fun recipeDao(): RecipeDao
    abstract fun inventoryControlDao(): InventoryControlDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun securityDao(): SecurityDao
    abstract fun assetDao(): AssetDao
    abstract fun crmDao(): CrmDao
    abstract fun alertDao(): AlertDao
    abstract fun syncDao(): SyncDao
    abstract fun restaurantOperationsDao(): RestaurantOperationsDao
    abstract fun procurementDao(): ProcurementDao

    companion object {
        fun create(context: Context, keyProvider: DatabaseKeyProvider): AppDatabase {
            System.loadLibrary("sqlcipher")
            val factory = SupportOpenHelperFactory(keyProvider.getOrCreatePassphrase(), null, true)
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "sabou_manager_v3.db",
            )
                .openHelperFactory(factory)
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18, MIGRATION_18_19, MIGRATION_19_20, MIGRATION_20_21, MIGRATION_21_22, MIGRATION_22_23, MIGRATION_23_24)
                .addCallback(AccountSeedCallback)
                .build()
        }

        internal fun createInMemory(context: Context): AppDatabase =
            Room.inMemoryDatabaseBuilder(context.applicationContext, AppDatabase::class.java)
                .addCallback(AccountSeedCallback)
                .build()
    }
}

internal val MIGRATION_23_24 = object : Migration(23, 24) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchase_requisitions (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, requestNo TEXT NOT NULL, department TEXT NOT NULL, requiredEpochDay INTEGER NOT NULL, status TEXT NOT NULL, requestedBy TEXT NOT NULL, approvedBy TEXT, note TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL)""")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_purchase_requisitions_requestNo ON purchase_requisitions(requestNo)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisitions_status ON purchase_requisitions(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisitions_requiredEpochDay ON purchase_requisitions(requiredEpochDay)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchase_requisition_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, requisitionId INTEGER NOT NULL, itemId INTEGER NOT NULL, itemNameSnapshot TEXT NOT NULL, requestedQtyMicros INTEGER NOT NULL, estimatedUnitCostRial INTEGER NOT NULL, note TEXT NOT NULL, FOREIGN KEY(requisitionId) REFERENCES purchase_requisitions(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(itemId) REFERENCES inventory_items(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisition_lines_requisitionId ON purchase_requisition_lines(requisitionId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_requisition_lines_itemId ON purchase_requisition_lines(itemId)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchase_orders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, orderNo TEXT NOT NULL, supplierId INTEGER NOT NULL, supplierNameSnapshot TEXT NOT NULL, requisitionId INTEGER NOT NULL, orderEpochDay INTEGER NOT NULL, expectedEpochDay INTEGER NOT NULL, status TEXT NOT NULL, note TEXT NOT NULL, createdBy TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL, FOREIGN KEY(supplierId) REFERENCES suppliers(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(requisitionId) REFERENCES purchase_requisitions(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_purchase_orders_orderNo ON purchase_orders(orderNo)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_orders_supplierId ON purchase_orders(supplierId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_orders_requisitionId ON purchase_orders(requisitionId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_orders_status ON purchase_orders(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_orders_expectedEpochDay ON purchase_orders(expectedEpochDay)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS purchase_order_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, purchaseOrderId INTEGER NOT NULL, itemId INTEGER NOT NULL, itemNameSnapshot TEXT NOT NULL, orderedQtyMicros INTEGER NOT NULL, unitCostRial INTEGER NOT NULL, receivedQtyMicros INTEGER NOT NULL, rejectedQtyMicros INTEGER NOT NULL, FOREIGN KEY(purchaseOrderId) REFERENCES purchase_orders(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(itemId) REFERENCES inventory_items(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_order_lines_purchaseOrderId ON purchase_order_lines(purchaseOrderId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_purchase_order_lines_itemId ON purchase_order_lines(itemId)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS goods_receipts (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, receiptNo TEXT NOT NULL, purchaseOrderId INTEGER NOT NULL, receiptEpochDay INTEGER NOT NULL, deliveryNoteNo TEXT NOT NULL, receivedBy TEXT NOT NULL, note TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, FOREIGN KEY(purchaseOrderId) REFERENCES purchase_orders(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_goods_receipts_receiptNo ON goods_receipts(receiptNo)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_goods_receipts_purchaseOrderId_deliveryNoteNo ON goods_receipts(purchaseOrderId, deliveryNoteNo)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_goods_receipts_purchaseOrderId ON goods_receipts(purchaseOrderId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_goods_receipts_receiptEpochDay ON goods_receipts(receiptEpochDay)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS goods_receipt_lines (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, goodsReceiptId INTEGER NOT NULL, purchaseOrderLineId INTEGER NOT NULL, itemId INTEGER NOT NULL, deliveredQtyMicros INTEGER NOT NULL, acceptedQtyMicros INTEGER NOT NULL, rejectedQtyMicros INTEGER NOT NULL, rejectionReason TEXT NOT NULL, acceptedValueRial INTEGER NOT NULL, FOREIGN KEY(goodsReceiptId) REFERENCES goods_receipts(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(purchaseOrderLineId) REFERENCES purchase_order_lines(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_goods_receipt_lines_goodsReceiptId ON goods_receipt_lines(goodsReceiptId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_goods_receipt_lines_purchaseOrderLineId ON goods_receipt_lines(purchaseOrderLineId)")
        db.execSQL("""CREATE TABLE IF NOT EXISTS procurement_invoice_links (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, purchaseOrderId INTEGER NOT NULL, purchaseId INTEGER NOT NULL, matchStatus TEXT NOT NULL, acceptedValueRial INTEGER NOT NULL, invoiceValueRial INTEGER NOT NULL, priceVarianceRial INTEGER NOT NULL, varianceApprovedBy TEXT, matchedAtEpochMillis INTEGER NOT NULL, FOREIGN KEY(purchaseOrderId) REFERENCES purchase_orders(id) ON UPDATE NO ACTION ON DELETE RESTRICT, FOREIGN KEY(purchaseId) REFERENCES purchases(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_procurement_invoice_links_purchaseOrderId ON procurement_invoice_links(purchaseOrderId)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_procurement_invoice_links_purchaseId ON procurement_invoice_links(purchaseId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_procurement_invoice_links_matchStatus ON procurement_invoice_links(matchStatus)")
    }
}

internal val MIGRATION_22_23 = object : Migration(22, 23) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE kitchen_tickets ADD COLUMN orderLineId INTEGER")
        db.execSQL("ALTER TABLE table_order_lines ADD COLUMN voidReason TEXT")
        db.execSQL("ALTER TABLE table_order_lines ADD COLUMN voidedBy TEXT")
        db.execSQL("ALTER TABLE table_order_lines ADD COLUMN voidedAtEpochMillis INTEGER")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS bill_splits (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                orderId INTEGER NOT NULL,
                label TEXT NOT NULL,
                mode TEXT NOT NULL,
                status TEXT NOT NULL,
                saleId INTEGER,
                createdAtEpochMillis INTEGER NOT NULL,
                settledAtEpochMillis INTEGER
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS index_bill_splits_orderId ON bill_splits(orderId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_bill_splits_status ON bill_splits(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_bill_splits_saleId ON bill_splits(saleId)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS bill_split_lines (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                splitId INTEGER NOT NULL,
                orderLineId INTEGER NOT NULL,
                FOREIGN KEY(splitId) REFERENCES bill_splits(id) ON UPDATE NO ACTION ON DELETE RESTRICT,
                FOREIGN KEY(orderLineId) REFERENCES table_order_lines(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS index_bill_split_lines_splitId ON bill_split_lines(splitId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_bill_split_lines_orderLineId ON bill_split_lines(orderLineId)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS cash_shifts (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                openedAtEpochMillis INTEGER NOT NULL,
                closedAtEpochMillis INTEGER,
                openingFloatRial INTEGER NOT NULL,
                expectedCashRial INTEGER NOT NULL,
                countedCashRial INTEGER,
                varianceRial INTEGER,
                openedBy TEXT NOT NULL,
                closedBy TEXT,
                status TEXT NOT NULL,
                note TEXT NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS index_cash_shifts_status ON cash_shifts(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_cash_shifts_openedAtEpochMillis ON cash_shifts(openedAtEpochMillis)")
    }
}

internal val MIGRATION_21_22 = object : Migration(21, 22) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS table_orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                orderNo TEXT NOT NULL,
                tableId INTEGER NOT NULL,
                guestCount INTEGER NOT NULL,
                waiterName TEXT NOT NULL,
                customerId INTEGER,
                customerName TEXT NOT NULL,
                status TEXT NOT NULL,
                openedAtEpochMillis INTEGER NOT NULL,
                closedAtEpochMillis INTEGER,
                mergedIntoOrderId INTEGER,
                saleId INTEGER,
                notes TEXT NOT NULL
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_table_orders_orderNo ON table_orders(orderNo)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_table_orders_tableId ON table_orders(tableId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_table_orders_status ON table_orders(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_table_orders_openedAtEpochMillis ON table_orders(openedAtEpochMillis)")
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS table_order_lines (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                orderId INTEGER NOT NULL,
                menuItemId INTEGER NOT NULL,
                itemName TEXT NOT NULL,
                quantityMicros INTEGER NOT NULL,
                unitPriceRial INTEGER NOT NULL,
                seatNo INTEGER NOT NULL,
                courseNo INTEGER NOT NULL,
                notes TEXT NOT NULL,
                status TEXT NOT NULL,
                sentToKitchenAtEpochMillis INTEGER,
                FOREIGN KEY(orderId) REFERENCES table_orders(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS index_table_order_lines_orderId ON table_order_lines(orderId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_table_order_lines_menuItemId ON table_order_lines(menuItemId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_table_order_lines_status ON table_order_lines(status)")
    }
}

internal val MIGRATION_20_21 = object : Migration(20, 21) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE fixed_assets ADD COLUMN quantity INTEGER NOT NULL DEFAULT 1")
    }
}

internal val MIGRATION_19_20 = object : Migration(19, 20) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE employees ADD COLUMN fatherName TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE app_users ADD COLUMN recoveryCodeHash TEXT NOT NULL DEFAULT ''")
    }
}

internal val MIGRATION_18_19 = object : Migration(18, 19) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS restaurant_tables (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,label TEXT NOT NULL,capacity INTEGER NOT NULL,zone TEXT NOT NULL,status TEXT NOT NULL,activeOrderId INTEGER)")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_restaurant_tables_label ON restaurant_tables(label)")
        db.execSQL("CREATE TABLE IF NOT EXISTS reservations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,customerName TEXT NOT NULL,phone TEXT NOT NULL,tableId INTEGER NOT NULL,startEpochMillis INTEGER NOT NULL,endEpochMillis INTEGER NOT NULL,partySize INTEGER NOT NULL,notes TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_reservations_tableId ON reservations(tableId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_reservations_startEpochMillis ON reservations(startEpochMillis)")
        db.execSQL("CREATE TABLE IF NOT EXISTS kitchen_tickets (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,orderNo TEXT NOT NULL,station TEXT NOT NULL,itemName TEXT NOT NULL,quantity INTEGER NOT NULL,createdAtEpochMillis INTEGER NOT NULL,status TEXT NOT NULL,priority INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_kitchen_tickets_status ON kitchen_tickets(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_kitchen_tickets_createdAtEpochMillis ON kitchen_tickets(createdAtEpochMillis)")
        db.execSQL("CREATE TABLE IF NOT EXISTS planned_shifts (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,employeeId INTEGER NOT NULL,employeeName TEXT NOT NULL,role TEXT NOT NULL,epochDay INTEGER NOT NULL,startMinute INTEGER NOT NULL,endMinute INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_planned_shifts_employeeId ON planned_shifts(employeeId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_planned_shifts_epochDay ON planned_shifts(epochDay)")
        db.execSQL("CREATE TABLE IF NOT EXISTS approval_requests (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,requestType TEXT NOT NULL,entityId INTEGER NOT NULL,amountRial INTEGER NOT NULL,requestedBy TEXT NOT NULL,approver TEXT,status TEXT NOT NULL,note TEXT NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_approval_requests_status ON approval_requests(status)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_approval_requests_requestType_entityId ON approval_requests(requestType,entityId)")
    }
}

internal val MIGRATION_17_18 = object : Migration(17, 18) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE sync_changes ADD COLUMN revision INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE sync_changes ADD COLUMN payloadVersion INTEGER NOT NULL DEFAULT 1")
        db.execSQL("ALTER TABLE sync_changes ADD COLUMN payload TEXT NOT NULL DEFAULT 'legacy'")
        db.execSQL("UPDATE sync_changes SET payloadHash = '${"0".repeat(64)}', state = 'REJECTED', lastError = 'Legacy payload requires regeneration' WHERE state IN ('PENDING', 'LOCAL_ONLY')")
    }
}

private val MIGRATION_16_17 = object : Migration(16, 17) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE app_users ADD COLUMN failedPinAttempts INTEGER NOT NULL DEFAULT 0")
        db.execSQL("ALTER TABLE app_users ADD COLUMN lockUntilEpochMillis INTEGER NOT NULL DEFAULT 0")
    }
}

private val MIGRATION_15_16 = object : Migration(15, 16) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sync_changes (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                changeId TEXT NOT NULL,
                entityType TEXT NOT NULL,
                entityId INTEGER NOT NULL,
                changeType TEXT NOT NULL,
                deviceId TEXT NOT NULL,
                occurredAtEpochMillis INTEGER NOT NULL,
                payloadHash TEXT NOT NULL,
                state TEXT NOT NULL,
                lastError TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_sync_changes_changeId ON sync_changes(changeId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_changes_state ON sync_changes(state)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sync_changes_occurredAtEpochMillis ON sync_changes(occurredAtEpochMillis)")
    }
}

private val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS customers (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
                creditLimitRial INTEGER NOT NULL, notes TEXT NOT NULL, isActive INTEGER NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_customers_name ON customers(name)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sales (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, invoiceNo TEXT NOT NULL,
                customerId INTEGER, customerNameSnapshot TEXT NOT NULL, saleEpochDay INTEGER NOT NULL,
                dueEpochDay INTEGER, channel TEXT NOT NULL, subtotalRial INTEGER NOT NULL,
                discountRial INTEGER NOT NULL, deliveryRial INTEGER NOT NULL, totalRial INTEGER NOT NULL,
                paidRial INTEGER NOT NULL, paymentStatus TEXT NOT NULL, paymentMethod TEXT, notes TEXT NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(customerId) REFERENCES customers(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_sales_invoiceNo ON sales(invoiceNo)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sales_customerId ON sales(customerId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sales_saleEpochDay ON sales(saleEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sales_dueEpochDay ON sales(dueEpochDay)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sale_lines (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, saleId INTEGER NOT NULL,
                productNameSnapshot TEXT NOT NULL, quantityMicros INTEGER NOT NULL,
                unitPriceRial INTEGER NOT NULL, lineTotalRial INTEGER NOT NULL,
                FOREIGN KEY(saleId) REFERENCES sales(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sale_lines_saleId ON sale_lines(saleId)")
    }
}


private val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS sale_payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                saleId INTEGER NOT NULL,
                amountRial INTEGER NOT NULL,
                paymentEpochDay INTEGER NOT NULL,
                method TEXT NOT NULL,
                journalEntryId INTEGER NOT NULL,
                reversalOfPaymentId INTEGER,
                createdAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(saleId) REFERENCES sales(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sale_payments_saleId ON sale_payments(saleId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sale_payments_reversalOfPaymentId ON sale_payments(reversalOfPaymentId)")
    }
}

internal object AccountSeedCallback : RoomDatabase.Callback() {
    override fun onCreate(db: SupportSQLiteDatabase) {
        super.onCreate(db)
        seedMissingAccounts(db)
    }

    override fun onOpen(db: SupportSQLiteDatabase) {
        super.onOpen(db)
        seedMissingAccounts(db)
    }

    fun seedMissingAccounts(db: SupportSQLiteDatabase) {
        val accounts = listOf(
            arrayOf("1101", "صندوق", "ASSET"),
            arrayOf("1102", "بانک و کارت‌خوان", "ASSET"),
            arrayOf("1103", "تنخواه‌گردان", "ASSET"),
            arrayOf("1201", "حساب‌های دریافتنی", "ASSET"),
            arrayOf("1202", "اسناد دریافتنی", "ASSET"),
            arrayOf("1301", "موجودی مواد اولیه", "ASSET"),
            arrayOf("1302", "موجودی ملزومات و بسته‌بندی", "ASSET"),
            arrayOf("1401", "مساعده پرسنل", "ASSET"),
            arrayOf("1501", "دارایی‌های ثابت", "ASSET"),
            arrayOf("1502", "استهلاک انباشته دارایی‌ها", "ASSET"),
            arrayOf("2101", "حساب‌های پرداختنی", "LIABILITY"),
            arrayOf("2102", "حقوق پرداختنی", "LIABILITY"),
            arrayOf("2103", "مالیات و عوارض پرداختنی", "LIABILITY"),
            arrayOf("2104", "بیمه پرداختنی", "LIABILITY"),
            arrayOf("2105", "کالای دریافت‌شده فاکتورنشده", "LIABILITY"),
            arrayOf("3101", "سرمایه", "EQUITY"),
            arrayOf("4101", "فروش غذا و نوشیدنی", "REVENUE"),
            arrayOf("4102", "سایر درآمدها", "REVENUE"),
            arrayOf("4103", "درآمد ارسال و خدمات", "REVENUE"),
            arrayOf("5101", "بهای تمام‌شده فروش", "EXPENSE"),
            arrayOf("5102", "ملزومات و بسته‌بندی مصرف‌شده", "EXPENSE"),
            arrayOf("6101", "حقوق و دستمزد", "EXPENSE"),
            arrayOf("6102", "اجاره", "EXPENSE"),
            arrayOf("6103", "آب، برق و گاز", "EXPENSE"),
            arrayOf("6104", "ضایعات مواد اولیه", "EXPENSE"),
            arrayOf("6105", "سایر هزینه‌های جاری", "EXPENSE"),
            arrayOf("6106", "بیمه سهم کارفرما", "EXPENSE"),
            arrayOf("6107", "تعمیر و نگهداری", "EXPENSE"),
            arrayOf("6108", "تبلیغات", "EXPENSE"),
            arrayOf("6109", "هزینه ارسال", "EXPENSE"),
            arrayOf("6110", "استهلاک", "EXPENSE"),
            arrayOf("6111", "مغایرت قیمت خرید", "EXPENSE"),
        )
        accounts.forEach { account ->
            db.execSQL(
                """
                INSERT OR IGNORE INTO accounts(code, name, type, isSystem, isActive)
                VALUES (?, ?, ?, 1, 1)
                """.trimIndent(),
                account,
            )
        }
    }
}

private val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS menu_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                name TEXT NOT NULL, category TEXT NOT NULL, salePriceRial INTEGER NOT NULL,
                isActive INTEGER NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_menu_items_name ON menu_items(name)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS recipe_ingredients (
                menuItemId INTEGER NOT NULL, inventoryItemId INTEGER NOT NULL, quantityMicrosPerUnit INTEGER NOT NULL,
                PRIMARY KEY(menuItemId, inventoryItemId),
                FOREIGN KEY(menuItemId) REFERENCES menu_items(id) ON UPDATE NO ACTION ON DELETE CASCADE,
                FOREIGN KEY(inventoryItemId) REFERENCES inventory_items(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_recipe_ingredients_inventoryItemId ON recipe_ingredients(inventoryItemId)")
    }
}


private val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE sales ADD COLUMN reversedAtEpochDay INTEGER")
        db.execSQL("ALTER TABLE sale_lines ADD COLUMN menuItemId INTEGER")
        db.execSQL("ALTER TABLE sale_lines ADD COLUMN costOfGoodsRial INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sale_lines_menuItemId ON sale_lines(menuItemId)")
    }
}


private val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE sales ADD COLUMN replacementOfSaleId INTEGER")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_sales_replacementOfSaleId ON sales(replacementOfSaleId)")
    }
}


private val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS inventory_counts (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, itemId INTEGER NOT NULL,
                previousQuantityMicros INTEGER NOT NULL, countedQuantityMicros INTEGER NOT NULL,
                previousValueRial INTEGER NOT NULL, countedValueRial INTEGER NOT NULL,
                countEpochDay INTEGER NOT NULL, reason TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(itemId) REFERENCES inventory_items(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_counts_itemId ON inventory_counts(itemId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_counts_countEpochDay ON inventory_counts(countEpochDay)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, action TEXT NOT NULL, entityType TEXT NOT NULL,
                entityId INTEGER, description TEXT NOT NULL, actor TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_createdAtEpochMillis ON audit_logs(createdAtEpochMillis)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_audit_logs_entityType_entityId ON audit_logs(entityType, entityId)")
    }
}


private val MIGRATION_7_8 = object : Migration(7, 8) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS app_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, username TEXT NOT NULL, displayName TEXT NOT NULL,
                pinHash TEXT NOT NULL, role TEXT NOT NULL, isActive INTEGER NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_app_users_username ON app_users(username)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS app_session (
                singletonId INTEGER NOT NULL PRIMARY KEY, currentUserId INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL
            )
        """.trimIndent())
        // No default credentials are created. The first owner must be configured explicitly in the UI.
    }
}


private val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS payroll_runs (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, employeeId INTEGER NOT NULL,
                periodYear INTEGER NOT NULL, periodMonth INTEGER NOT NULL, baseSalaryRial INTEGER NOT NULL,
                overtimeRial INTEGER NOT NULL, bonusRial INTEGER NOT NULL, deductionsRial INTEGER NOT NULL,
                insuranceRial INTEGER NOT NULL, taxRial INTEGER NOT NULL, netPayRial INTEGER NOT NULL,
                paymentEpochDay INTEGER NOT NULL, paymentMethod TEXT NOT NULL, journalEntryId INTEGER NOT NULL,
                status TEXT NOT NULL, notes TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_payroll_runs_employeeId_periodYear_periodMonth ON payroll_runs(employeeId, periodYear, periodMonth)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_payroll_runs_paymentEpochDay ON payroll_runs(paymentEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_payroll_runs_journalEntryId ON payroll_runs(journalEntryId)")
    }
}

private val MIGRATION_9_10 = object : Migration(9, 10) {
 override fun migrate(db: SupportSQLiteDatabase) {
  db.execSQL("""CREATE TABLE IF NOT EXISTS fixed_assets (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, assetCode TEXT NOT NULL, name TEXT NOT NULL, category TEXT NOT NULL, purchaseEpochDay INTEGER NOT NULL, purchaseCostRial INTEGER NOT NULL, salvageValueRial INTEGER NOT NULL, usefulLifeMonths INTEGER NOT NULL, accumulatedDepreciationRial INTEGER NOT NULL, location TEXT NOT NULL, status TEXT NOT NULL, notes TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL)""")
  db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_fixed_assets_assetCode ON fixed_assets(assetCode)")
  db.execSQL("CREATE INDEX IF NOT EXISTS index_fixed_assets_status ON fixed_assets(status)")
  db.execSQL("""CREATE TABLE IF NOT EXISTS asset_depreciations (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, assetId INTEGER NOT NULL, periodYear INTEGER NOT NULL, periodMonth INTEGER NOT NULL, amountRial INTEGER NOT NULL, journalEntryId INTEGER NOT NULL, createdAtEpochMillis INTEGER NOT NULL, FOREIGN KEY(assetId) REFERENCES fixed_assets(id) ON UPDATE NO ACTION ON DELETE RESTRICT)""")
  db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_asset_depreciations_assetId_periodYear_periodMonth ON asset_depreciations(assetId,periodYear,periodMonth)")
  db.execSQL("CREATE INDEX IF NOT EXISTS index_asset_depreciations_journalEntryId ON asset_depreciations(journalEntryId)")
  db.execSQL("INSERT OR IGNORE INTO accounts(code,name,type,isSystem,isActive) VALUES ('1502','استهلاک انباشته دارایی‌ها','ASSET',1,1)")
 }
}


private val MIGRATION_10_11 = object : Migration(10, 11) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS loyalty_transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, customerId INTEGER NOT NULL,
                pointsDelta INTEGER NOT NULL, reason TEXT NOT NULL, referenceType TEXT NOT NULL,
                referenceId INTEGER, createdAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(customerId) REFERENCES customers(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_loyalty_transactions_customerId ON loyalty_transactions(customerId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_loyalty_transactions_createdAtEpochMillis ON loyalty_transactions(createdAtEpochMillis)")
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS customer_followups (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, customerId INTEGER NOT NULL, title TEXT NOT NULL,
                dueEpochDay INTEGER NOT NULL, notes TEXT NOT NULL, isDone INTEGER NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL, completedAtEpochMillis INTEGER,
                FOREIGN KEY(customerId) REFERENCES customers(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_customer_followups_customerId ON customer_followups(customerId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_customer_followups_dueEpochDay ON customer_followups(dueEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_customer_followups_isDone ON customer_followups(isDone)")
    }
}


private val MIGRATION_11_12 = object : Migration(11, 12) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS app_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                sourceType TEXT NOT NULL, sourceId INTEGER NOT NULL,
                title TEXT NOT NULL, message TEXT NOT NULL, severity TEXT NOT NULL,
                dueEpochDay INTEGER, isRead INTEGER NOT NULL, isDismissed INTEGER NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_app_alerts_sourceType_sourceId ON app_alerts(sourceType, sourceId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_app_alerts_severity ON app_alerts(severity)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_app_alerts_isRead ON app_alerts(isRead)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_app_alerts_isDismissed ON app_alerts(isDismissed)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_app_alerts_dueEpochDay ON app_alerts(dueEpochDay)")
    }
}


private val MIGRATION_12_13 = object : Migration(12, 13) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE employees ADD COLUMN employeeCode TEXT")
        db.execSQL("ALTER TABLE employees ADD COLUMN branchName TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE employees ADD COLUMN hireEpochDay INTEGER")
        db.execSQL("ALTER TABLE employees ADD COLUMN insuranceNumber TEXT")
        db.execSQL("ALTER TABLE employees ADD COLUMN address TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE employees ADD COLUMN emergencyContact TEXT NOT NULL DEFAULT ''")
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_employees_employeeCode ON employees(employeeCode)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employees_branchName ON employees(branchName)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employees_status ON employees(status)")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS employee_contracts (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                employeeId INTEGER NOT NULL, contractType TEXT NOT NULL,
                startEpochDay INTEGER NOT NULL, endEpochDay INTEGER,
                baseSalaryRial INTEGER NOT NULL, dailyWorkMinutes INTEGER NOT NULL,
                weeklyWorkDays INTEGER NOT NULL, status TEXT NOT NULL, notes TEXT NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL, updatedAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_contracts_employeeId ON employee_contracts(employeeId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_contracts_startEpochDay ON employee_contracts(startEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_contracts_endEpochDay ON employee_contracts(endEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_contracts_status ON employee_contracts(status)")

        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS employee_advances (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                employeeId INTEGER NOT NULL, amountRial INTEGER NOT NULL,
                advanceEpochDay INTEGER NOT NULL, paymentMethod TEXT NOT NULL,
                journalEntryId INTEGER NOT NULL, settledAmountRial INTEGER NOT NULL,
                status TEXT NOT NULL, notes TEXT NOT NULL, createdAtEpochMillis INTEGER NOT NULL,
                updatedAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
            """.trimIndent(),
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_advances_employeeId ON employee_advances(employeeId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_advances_advanceEpochDay ON employee_advances(advanceEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_advances_journalEntryId ON employee_advances(journalEntryId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_employee_advances_status ON employee_advances(status)")
    }
}


private val MIGRATION_13_14 = object : Migration(13, 14) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE leaves ADD COLUMN requestedBy TEXT NOT NULL DEFAULT 'SYSTEM'")
        db.execSQL("ALTER TABLE leaves ADD COLUMN reviewedBy TEXT")
        db.execSQL("ALTER TABLE leaves ADD COLUMN reviewNotes TEXT NOT NULL DEFAULT ''")
        db.execSQL("ALTER TABLE leaves ADD COLUMN reviewedAtEpochMillis INTEGER")
        db.execSQL("ALTER TABLE leaves ADD COLUMN cancelledAtEpochMillis INTEGER")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_leaves_status ON leaves(status)")
    }
}


private val MIGRATION_14_15 = object : Migration(14, 15) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS performance_goals (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                employeeId INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                weightPercent INTEGER NOT NULL,
                targetValue REAL,
                unit TEXT NOT NULL,
                periodStartEpochDay INTEGER NOT NULL,
                periodEndEpochDay INTEGER NOT NULL,
                status TEXT NOT NULL,
                createdBy TEXT NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL,
                updatedAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_goals_employeeId ON performance_goals(employeeId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_goals_periodStartEpochDay ON performance_goals(periodStartEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_goals_periodEndEpochDay ON performance_goals(periodEndEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_goals_status ON performance_goals(status)")

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS performance_reviews (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                employeeId INTEGER NOT NULL,
                periodStartEpochDay INTEGER NOT NULL,
                periodEndEpochDay INTEGER NOT NULL,
                reviewerName TEXT NOT NULL,
                finalScoreBasisPoints INTEGER NOT NULL,
                status TEXT NOT NULL,
                managerComment TEXT NOT NULL,
                employeeComment TEXT NOT NULL,
                submittedAtEpochMillis INTEGER,
                completedAtEpochMillis INTEGER,
                createdAtEpochMillis INTEGER NOT NULL,
                updatedAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(employeeId) REFERENCES employees(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_reviews_employeeId ON performance_reviews(employeeId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_reviews_periodStartEpochDay ON performance_reviews(periodStartEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_reviews_periodEndEpochDay ON performance_reviews(periodEndEpochDay)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_reviews_status ON performance_reviews(status)")

        db.execSQL("""
            CREATE TABLE IF NOT EXISTS performance_scores (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                reviewId INTEGER NOT NULL,
                goalId INTEGER NOT NULL,
                achievedValue REAL,
                scoreBasisPoints INTEGER NOT NULL,
                weightedScoreBasisPoints INTEGER NOT NULL,
                notes TEXT NOT NULL,
                createdAtEpochMillis INTEGER NOT NULL,
                updatedAtEpochMillis INTEGER NOT NULL,
                FOREIGN KEY(reviewId) REFERENCES performance_reviews(id) ON UPDATE NO ACTION ON DELETE CASCADE,
                FOREIGN KEY(goalId) REFERENCES performance_goals(id) ON UPDATE NO ACTION ON DELETE RESTRICT
            )
        """.trimIndent())
        db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_performance_scores_reviewId_goalId ON performance_scores(reviewId, goalId)")
        db.execSQL("CREATE INDEX IF NOT EXISTS index_performance_scores_goalId ON performance_scores(goalId)")
    }
}
