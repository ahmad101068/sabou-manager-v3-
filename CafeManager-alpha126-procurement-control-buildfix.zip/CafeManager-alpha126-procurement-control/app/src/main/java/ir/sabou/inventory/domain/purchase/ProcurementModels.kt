package ir.sabou.inventory.domain.purchase

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import kotlinx.coroutines.flow.Flow

enum class RequisitionStatus { SUBMITTED, APPROVED, REJECTED, CONVERTED }
enum class PurchaseOrderStatus { OPEN, PARTIALLY_RECEIVED, RECEIVED, CLOSED, CANCELLED }
enum class ThreeWayMatchStatus { MATCHED, PRICE_VARIANCE, QUANTITY_VARIANCE }

data class RequisitionLineDraft(
    val itemId: Long,
    val quantityMicros: Long,
    val estimatedUnitCostRial: Long,
    val note: String = "",
)

data class PurchaseRequisitionDraft(
    val department: String,
    val requiredEpochDay: Long,
    val note: String = "",
    val lines: List<RequisitionLineDraft>,
) {
    fun validated(): PurchaseRequisitionDraft {
        val normalizedDepartment = department.trim()
        require(normalizedDepartment.length in 2..80) { "واحد درخواست‌کننده معتبر نیست." }
        require(note.trim().length <= 300) { "توضیحات درخواست بیش از حد طولانی است." }
        require(lines.isNotEmpty() && lines.size <= 100) { "درخواست خرید باید بین ۱ تا ۱۰۰ ردیف داشته باشد." }
        require(lines.map { it.itemId }.distinct().size == lines.size) { "یک کالا در درخواست خرید تکرار شده است." }
        require(lines.all { it.itemId > 0 && it.quantityMicros > 0 && it.estimatedUnitCostRial >= 0 }) {
            "مقدار یا برآورد یکی از ردیف‌های درخواست معتبر نیست."
        }
        lines.forEach {
            require(it.note.trim().length <= 200) { "توضیحات یکی از ردیف‌ها بیش از حد طولانی است." }
            QuantityMicros.positive(it.quantityMicros)
            MoneyRial.of(it.estimatedUnitCostRial).times(QuantityMicros.of(it.quantityMicros))
        }
        return copy(
            department = normalizedDepartment,
            note = note.trim(),
            lines = lines.map { it.copy(note = it.note.trim()) },
        )
    }
}

data class PurchaseOrderDraft(
    val requisitionId: Long,
    val supplierId: Long,
    val orderEpochDay: Long,
    val expectedEpochDay: Long,
    val note: String = "",
) {
    fun validated(): PurchaseOrderDraft {
        require(requisitionId > 0 && supplierId > 0) { "درخواست خرید و تأمین‌کننده الزامی است." }
        require(expectedEpochDay >= orderEpochDay) { "تاریخ تحویل نمی‌تواند قبل از تاریخ سفارش باشد." }
        require(note.trim().length <= 300) { "توضیحات سفارش بیش از حد طولانی است." }
        return copy(note = note.trim())
    }
}

data class GoodsReceiptLineDraft(
    val purchaseOrderLineId: Long,
    val deliveredQtyMicros: Long,
    val acceptedQtyMicros: Long,
    val rejectionReason: String = "",
)

data class GoodsReceiptDraft(
    val purchaseOrderId: Long,
    val receiptEpochDay: Long,
    val deliveryNoteNo: String,
    val note: String = "",
    val finalizeOrder: Boolean = false,
    val lines: List<GoodsReceiptLineDraft>,
) {
    fun validated(): GoodsReceiptDraft {
        require(purchaseOrderId > 0) { "سفارش خرید معتبر نیست." }
        require(deliveryNoteNo.trim().length in 1..80) { "شماره حواله تحویل الزامی است." }
        require(note.trim().length <= 300) { "توضیحات رسید بیش از حد طولانی است." }
        require(lines.isNotEmpty() && lines.size <= 100) { "حداقل یک ردیف تحویل لازم است." }
        require(lines.map { it.purchaseOrderLineId }.distinct().size == lines.size) { "یک ردیف سفارش در رسید تکرار شده است." }
        lines.forEach {
            require(it.purchaseOrderLineId > 0) { "ردیف سفارش معتبر نیست." }
            require(it.deliveredQtyMicros >= 0) { "مقدار تحویل نمی‌تواند منفی باشد." }
            require(it.acceptedQtyMicros in 0..it.deliveredQtyMicros) { "مقدار پذیرفته‌شده از مقدار تحویل بیشتر است." }
            QuantityMicros.of(it.deliveredQtyMicros)
            QuantityMicros.of(it.acceptedQtyMicros)
            require(it.deliveredQtyMicros == it.acceptedQtyMicros || it.rejectionReason.trim().length >= 3) {
                "برای کسری یا کالای ردشده دلیل ثبت کنید."
            }
            require(it.rejectionReason.trim().length <= 300) { "دلیل مغایرت بیش از حد طولانی است." }
        }
        require(lines.any { it.deliveredQtyMicros > 0 } || finalizeOrder) { "حداقل یک مقدار تحویلی لازم است." }
        return copy(
            deliveryNoteNo = deliveryNoteNo.trim(),
            note = note.trim(),
            lines = lines.map { it.copy(rejectionReason = it.rejectionReason.trim()) },
        )
    }
}

data class RequisitionRecord(
    val id: Long,
    val requestNo: String,
    val department: String,
    val requiredEpochDay: Long,
    val status: RequisitionStatus,
    val requestedBy: String,
    val approvedBy: String?,
    val estimatedTotalRial: Long,
    val lineCount: Int,
)

data class PurchaseOrderLineRecord(
    val id: Long,
    val itemId: Long,
    val itemName: String,
    val orderedQtyMicros: Long,
    val receivedQtyMicros: Long,
    val rejectedQtyMicros: Long,
    val unitCostRial: Long,
) {
    val remainingQtyMicros: Long get() = (orderedQtyMicros - receivedQtyMicros).coerceAtLeast(0)
}

data class PurchaseOrderRecord(
    val id: Long,
    val orderNo: String,
    val supplierId: Long,
    val supplierName: String,
    val requisitionId: Long,
    val orderEpochDay: Long,
    val expectedEpochDay: Long,
    val status: PurchaseOrderStatus,
    val orderedValueRial: Long,
    val acceptedValueRial: Long,
    val receiptCount: Int,
    val invoiceNo: String?,
    val lines: List<PurchaseOrderLineRecord>,
)

data class ProcurementOverview(
    val requisitions: List<RequisitionRecord> = emptyList(),
    val orders: List<PurchaseOrderRecord> = emptyList(),
) {
    val awaitingApproval: Int get() = requisitions.count { it.status == RequisitionStatus.SUBMITTED }
    val openOrders: Int get() = orders.count { it.status in setOf(PurchaseOrderStatus.OPEN, PurchaseOrderStatus.PARTIALLY_RECEIVED) }
    val pendingInvoiceMatches: Int get() = orders.count { it.status == PurchaseOrderStatus.RECEIVED && it.invoiceNo == null }
}

data class ThreeWayMatchResult(
    val status: ThreeWayMatchStatus,
    val acceptedValueRial: Long,
    val invoiceValueRial: Long,
    val priceVarianceRial: Long,
    /** Absolute variance in basis points; 500 means five percent. */
    val priceVarianceBasisPoints: Long,
)

interface ProcurementRepository {
    val overview: Flow<ProcurementOverview>
    suspend fun submitRequisition(draft: PurchaseRequisitionDraft): Long
    suspend fun reviewRequisition(requisitionId: Long, approve: Boolean, note: String = "")
    suspend fun createOrder(draft: PurchaseOrderDraft): Long
    suspend fun postGoodsReceipt(draft: GoodsReceiptDraft): Long
    suspend fun previewThreeWayMatch(purchaseOrderId: Long, invoice: PurchaseDraft): ThreeWayMatchResult
    suspend fun postMatchedInvoice(
        purchaseOrderId: Long,
        invoice: PurchaseDraft,
        approvePriceVariance: Boolean,
    ): PostedPurchase
}
