package ir.sabou.inventory.domain.operations

enum class UserRole(val title: String, val permissions: Set<String>) {
    OWNER("مالک", setOf("*")),
    MANAGER("مدیر", setOf("PURCHASES", "SUPPLIERS", "INVENTORY", "RECIPES", "SALES", "ACCOUNTING", "REPORTS", "AUDIT", "BACKUP", "PERSONNEL", "ASSETS")),
    CASHIER("صندوقدار", setOf("SALES", "REPORTS")),
    KITCHEN("آشپزخانه", setOf("KITCHEN")),
    INVENTORY("انبار", setOf("INVENTORY")),
    STOREKEEPER("انباردار", setOf("PURCHASES", "SUPPLIERS", "INVENTORY", "RECIPES")),
    ACCOUNTANT("حسابدار", setOf("PURCHASES", "SALES", "ACCOUNTING", "REPORTS", "AUDIT", "PERSONNEL", "ASSETS"));
    fun allows(permission: String): Boolean = "*" in permissions || permission in permissions
}
enum class Permission { VIEW_REPORTS, POST_SALE, POST_PURCHASE, MANAGE_USERS, MANAGE_INVENTORY }

object AccessPolicy {
    fun allows(role: UserRole, permission: Permission): Boolean = when (role) {
        UserRole.OWNER -> true
        UserRole.MANAGER -> permission != Permission.MANAGE_USERS
        UserRole.CASHIER -> permission == Permission.POST_SALE
        UserRole.KITCHEN -> false
        UserRole.INVENTORY -> permission == Permission.MANAGE_INVENTORY
    }
}
