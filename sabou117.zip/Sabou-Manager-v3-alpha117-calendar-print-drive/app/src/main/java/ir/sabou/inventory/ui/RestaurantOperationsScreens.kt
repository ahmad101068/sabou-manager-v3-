package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.operations.ApprovalStatus
import ir.sabou.inventory.domain.operations.KitchenTicketStatus
import ir.sabou.inventory.domain.operations.ShiftDemand
import ir.sabou.inventory.domain.operations.StaffAvailability
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.sales.Reservation
import ir.sabou.inventory.domain.sales.RestaurantTable
import ir.sabou.inventory.domain.sales.TableStatus

private enum class OpsDialog { TABLE, RESERVATION, KITCHEN, SHIFT, APPROVAL }

@Composable
fun RestaurantOperationsScreen(
    state: RestaurantOperationsUiState,
    employees: List<EmployeeRecord>,
    canManageTables: Boolean,
    canManageKitchen: Boolean,
    canManageShifts: Boolean,
    canManageApprovals: Boolean,
    onAddTable: (String, Int, String) -> Unit,
    onTable: (Long, TableStatus, Long?) -> Unit,
    onReservation: (Reservation) -> Unit,
    onTicket: (String, String, String, Int, Int) -> Unit,
    onTicketStatus: (Long, KitchenTicketStatus) -> Unit,
    onShift: (ShiftDemand, List<StaffAvailability>) -> Unit,
    onApproval: (String, Long, Long, String) -> Unit,
    onReview: (Long, Boolean, String, String) -> Unit,
    onBack: () -> Unit,
) {
    var dialog by remember { mutableStateOf<OpsDialog?>(null) }
    val actions = buildList {
        if (canManageTables) {
            add("میز" to OpsDialog.TABLE)
            add("رزرو" to OpsDialog.RESERVATION)
        }
        if (canManageKitchen) add("آشپزخانه" to OpsDialog.KITCHEN)
        if (canManageShifts) add("شیفت" to OpsDialog.SHIFT)
        if (canManageApprovals) add("تأیید" to OpsDialog.APPROVAL)
    }

    Scaffold(
        topBar = { ProfessionalTopBar("عملیات رستوران", "میز، رزرو، آشپزخانه، شیفت و تأیید", onBack) },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            state.message?.let { message ->
                item { StatusPill(message, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.onSecondaryContainer) }
            }
            if (actions.isNotEmpty()) item { ActionStrip(actions) { dialog = it } }

            if (canManageTables) {
                item { SectionHeading("میزها و رزرو", "${state.tables.size} میز · ${state.reservations.size} رزرو") }
                items(state.tables, key = { it.id }) { table ->
                    Card {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text("میز ${table.label} · ${table.zone}", fontWeight = FontWeight.Bold)
                            Text("ظرفیت ${table.capacity} · ${table.status.name}")
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                nextTableStatuses(table.status).forEach { next ->
                                    TextButton(
                                        onClick = {
                                            onTable(
                                                table.id,
                                                next,
                                                if (next == TableStatus.OCCUPIED) System.currentTimeMillis() else table.activeOrderId,
                                            )
                                        },
                                    ) { Text(next.name) }
                                }
                            }
                        }
                    }
                }
            }

            if (canManageKitchen) {
                item { SectionHeading("صف آشپزخانه", "اولویت‌بندی زنده سفارش‌ها") }
                items(state.tickets, key = { it.id }) { ticket ->
                    Card {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Column {
                                Text("${ticket.orderNo} · ${ticket.itemName}", fontWeight = FontWeight.Bold)
                                Text("${ticket.quantity} عدد · ${ticket.station} · ${ticket.status.name}")
                            }
                            nextTicketStatus(ticket.status)?.let { next ->
                                TextButton(onClick = { onTicketStatus(ticket.id, next) }) { Text(next.name) }
                            }
                        }
                    }
                }
            }

            if (canManageShifts) {
                item { SectionHeading("شیفت‌ها", "${state.shifts.size} شیفت برنامه‌ریزی‌شده") }
                items(state.shifts.take(8)) { shift ->
                    Text("${shift.employeeName} · ${epochDayToPersian(shift.epochDay).display()} · ${shift.startMinute / 60}:${(shift.startMinute % 60).toString().padStart(2, '0')}–${shift.endMinute / 60}:${(shift.endMinute % 60).toString().padStart(2, '0')}")
                }
            }

            if (canManageApprovals) {
                item { SectionHeading("تأییدها", "${state.approvals.count { it.status == ApprovalStatus.PENDING }} در انتظار") }
                items(state.approvals, key = { it.id }) { request ->
                    Card {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text("${request.requestType} · ${formatMoney(request.amountRial)}", fontWeight = FontWeight.Bold)
                            Text(request.status.name)
                            if (request.status == ApprovalStatus.PENDING) {
                                Row {
                                    TextButton(onClick = { onReview(request.id, true, "مدیر", "") }) { Text("تأیید") }
                                    TextButton(onClick = { onReview(request.id, false, "مدیر", "رد توسط مدیر") }) { Text("رد") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    dialog?.let { mode ->
        OperationsInputDialog(mode, state.tables, employees, { dialog = null }) { a, b, c, d, e, selectedDay ->
            when (mode) {
                OpsDialog.TABLE -> onAddTable(a, b.toIntOrNull() ?: 0, c)
                OpsDialog.RESERVATION -> {
                    val table = state.tables.firstOrNull()
                    if (table != null) {
                        onReservation(
                            Reservation(
                                0,
                                a,
                                b,
                                table.id,
                                selectedDay * 86_400_000L + 12 * 3_600_000L,
                                selectedDay * 86_400_000L + 14 * 3_600_000L,
                                c.toIntOrNull() ?: 1,
                                d,
                            ),
                        )
                    }
                }
                OpsDialog.KITCHEN -> onTicket(a, b, c, d.toIntOrNull() ?: 1, e.toIntOrNull() ?: 0)
                OpsDialog.SHIFT -> onShift(
                    ShiftDemand(selectedDay, a.toIntOrNull() ?: 540, b.toIntOrNull() ?: 1020, c.toIntOrNull() ?: 1),
                    employees.filter { it.isActive }.map { StaffAvailability(it.id, it.name, 0, 1440, it.jobTitle) },
                )
                OpsDialog.APPROVAL -> onApproval(a, b.toLongOrNull() ?: 1, c.toLongOrNull() ?: 0, d)
            }
        }
    }
}

@Composable
private fun ActionStrip(actions: List<Pair<String, OpsDialog>>, onClick: (OpsDialog) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(actions) { (label, mode) ->
            FilledTonalButton(onClick = { onClick(mode) }) { Text("افزودن $label") }
        }
    }
}

private fun nextTableStatuses(status: TableStatus) = when (status) {
    TableStatus.FREE -> listOf(TableStatus.RESERVED, TableStatus.OCCUPIED)
    TableStatus.RESERVED -> listOf(TableStatus.OCCUPIED, TableStatus.FREE)
    TableStatus.OCCUPIED -> listOf(TableStatus.WAITING_PAYMENT, TableStatus.CLEANING)
    TableStatus.WAITING_PAYMENT -> listOf(TableStatus.CLEANING)
    TableStatus.CLEANING -> listOf(TableStatus.FREE)
}

private fun nextTicketStatus(status: KitchenTicketStatus) = when (status) {
    KitchenTicketStatus.QUEUED -> KitchenTicketStatus.PREPARING
    KitchenTicketStatus.PREPARING -> KitchenTicketStatus.READY
    KitchenTicketStatus.READY -> KitchenTicketStatus.SERVED
    else -> null
}

@Composable
private fun OperationsInputDialog(
    mode: OpsDialog,
    tables: List<RestaurantTable>,
    employees: List<EmployeeRecord>,
    dismiss: () -> Unit,
    save: (String, String, String, String, String, Long) -> Unit,
) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    var d by remember { mutableStateOf("") }
    var e by remember { mutableStateOf("") }
    var selectedDay by remember { mutableLongStateOf(currentEpochDay()) }
    val labels = when (mode) {
        OpsDialog.TABLE -> listOf("برچسب میز", "ظرفیت", "بخش")
        OpsDialog.RESERVATION -> listOf("نام مشتری", "تلفن", "تعداد مهمان", "یادداشت")
        OpsDialog.KITCHEN -> listOf("شماره سفارش", "ایستگاه", "نام آیتم", "تعداد", "اولویت ۰ تا ۱۰")
        OpsDialog.SHIFT -> listOf("شروع به دقیقه", "پایان به دقیقه", "نیروی موردنیاز")
        OpsDialog.APPROVAL -> listOf("نوع درخواست", "شناسه مرجع", "مبلغ", "درخواست‌کننده")
    }
    val values = listOf(a, b, c, d, e)
    AlertDialog(
        onDismissRequest = dismiss,
        title = { Text("ثبت ${mode.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mode == OpsDialog.RESERVATION) Text("رزرو برای ${tables.firstOrNull()?.label ?: "ابتدا میز ثبت کنید"}")
                if (mode == OpsDialog.SHIFT) Text("${employees.count { it.isActive }} پرسنل فعال")
                if (mode == OpsDialog.RESERVATION || mode == OpsDialog.SHIFT) {
                    PersianDateField(
                        label = if (mode == OpsDialog.RESERVATION) "تاریخ رزرو" else "تاریخ شیفت",
                        epochDay = selectedDay,
                        onSelected = { selectedDay = it },
                    )
                }
                labels.forEachIndexed { index, label ->
                    OutlinedTextField(
                        values[index],
                        { value ->
                            when (index) {
                                0 -> a = value
                                1 -> b = value
                                2 -> c = value
                                3 -> d = value
                                else -> e = value
                            }
                        },
                        label = { Text(label) },
                        singleLine = true,
                    )
                }
            }
        },
        confirmButton = { Button(onClick = { save(a, b, c, d, e, selectedDay); dismiss() }) { Text("ثبت") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("انصراف") } },
    )
}
