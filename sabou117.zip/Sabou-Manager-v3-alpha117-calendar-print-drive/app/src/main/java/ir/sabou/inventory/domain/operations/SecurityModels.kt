package ir.sabou.inventory.domain.operations

import kotlinx.coroutines.flow.Flow

data class AppUserRecord(val id: Long, val username: String, val displayName: String, val role: UserRole, val isActive: Boolean)
data class UserDraft(val username: String, val displayName: String, val pin: String, val role: UserRole)

interface SecurityRepository {
    val users: Flow<List<AppUserRecord>>
    val currentUser: Flow<AppUserRecord?>
    suspend fun save(id: Long?, draft: UserDraft): Long
    suspend fun deactivate(id: Long)
    suspend fun switchUser(id: Long, pin: String)
    suspend fun logout()
}
