package ir.sabou.inventory.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.activity.compose.BackHandler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalance
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import android.app.Activity
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.ui.theme.SabouBrand

enum class AppScreen {
    DASHBOARD,
    PURCHASES,
    NEW_PURCHASE,
    SUPPLIERS,
    INVENTORY,
    SALES,
    RECIPES,
    ACCOUNTING,
    NEW_JOURNAL,
    AUDIT_LOG,
    SECURITY,
    PERSONNEL,
    ASSETS,
    CRM,
    ALERTS,
    REPORTS,
    GLOBAL_SEARCH,
    SETTINGS,
    RESTAURANT_OPERATIONS,
}

private data class ModuleCard(val title: String, val screen: AppScreen?, val permission: String? = null)

private val modules = listOf(
    ModuleCard("خرید و فاکتورها", AppScreen.PURCHASES, "PURCHASES"),
    ModuleCard("تأمین‌کنندگان", AppScreen.SUPPLIERS, "SUPPLIERS"),
    ModuleCard("انبار و هشدار موجودی", AppScreen.INVENTORY, "INVENTORY"),
    ModuleCard("رسپی و بهای تمام‌شده", AppScreen.RECIPES, "RECIPES"),
    ModuleCard("فروش و مشتریان", AppScreen.SALES, "SALES"),
    ModuleCard("باشگاه مشتریان و CRM", AppScreen.CRM, "SALES"),
    ModuleCard("مرکز هشدارها", AppScreen.ALERTS, null),
    ModuleCard("حسابداری", AppScreen.ACCOUNTING, "ACCOUNTING"),
    ModuleCard("پرسنل و حقوق", AppScreen.PERSONNEL, "PERSONNEL"),
    ModuleCard("دارایی‌های رستوران", AppScreen.ASSETS, "ASSETS"),
    ModuleCard("گزارش و چاپ", AppScreen.REPORTS, "ACCOUNTING"),
    ModuleCard("لاگ عملیات و حسابرسی", AppScreen.AUDIT_LOG, "AUDIT"),
    ModuleCard("عملیات رستوران و آشپزخانه", AppScreen.RESTAURANT_OPERATIONS, null),
    ModuleCard("کاربران و پشتیبان", AppScreen.SECURITY, "BACKUP"),
)

@Composable
fun SabouApp(
    container: AppContainer,
    themePreference: ThemePreference,
    onThemePreferenceChange: (ThemePreference) -> Unit,
) {
    val dashboard: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(container.dashboardRepository),
    )
    val operations: OperationsViewModel = viewModel(
        factory = OperationsViewModel.factory(
            container.operationsRepository,
            container.purchaseRepository,
        ),
    )
    val accounting: AccountingViewModel = viewModel(
        factory = AccountingViewModel.factory(container.accountingRepository),
    )
    val sales: SalesViewModel = viewModel(
        factory = SalesViewModel.factory(container.salesRepository, container.recipeRepository),
    )
    val recipes: RecipeViewModel = viewModel(
        factory = RecipeViewModel.factory(container.recipeRepository, container.operationsRepository),
    )
    val personnel: PersonnelViewModel = viewModel(factory = PersonnelViewModel.factory(container.personnelRepository))
    val performance: PerformanceViewModel = viewModel(factory = PerformanceViewModel.factory(container.performanceRepository))
    val sync: SyncViewModel = viewModel(factory = SyncViewModel.factory(container.syncRepository, container))
    val restaurantOperations: RestaurantOperationsViewModel = viewModel(factory = RestaurantOperationsViewModel.factory(container.restaurantOperationsRepository))
    val assets: AssetViewModel = viewModel(factory = AssetViewModel.factory(container.assetRepository))
    val crm: CrmViewModel = viewModel(factory = CrmViewModel.factory(container.crmRepository))
    val alerts: AlertViewModel = viewModel(factory = AlertViewModel.factory(container.alertRepository))
    val security: SecurityViewModel = viewModel(
        factory = SecurityViewModel.factory(container.securityRepository, container),
    )
    val dashboardState by dashboard.state.collectAsState()
    val operationsState by operations.state.collectAsState()
    val accountingState by accounting.state.collectAsState()
    val salesState by sales.state.collectAsState()
    val recipeState by recipes.state.collectAsState()
    val alertState by alerts.state.collectAsState()
    val securityState by security.state.collectAsState()
    val personnelState by personnel.state.collectAsState()
    val performanceState by performance.state.collectAsState()
    val syncState by sync.state.collectAsState()
    val restaurantOperationsState by restaurantOperations.state.collectAsState()
    val assetState by assets.state.collectAsState()
    val crmState by crm.state.collectAsState()
    var routeStack by rememberSaveable { mutableStateOf(listOf(AppScreen.SECURITY.name)) }
    val screen = AppScreen.valueOf(routeStack.last())
    var showExitConfirmation by remember { mutableStateOf(false) }
    val activity = LocalContext.current as? Activity

    fun navigate(target: AppScreen) {
        if (target != screen && canOpenScreen(securityState.currentUser, target)) {
            routeStack = routeStack + target.name
        }
    }

    fun navigateBack() {
        if (routeStack.size > 1) {
            routeStack = routeStack.dropLast(1)
        } else {
            showExitConfirmation = true
        }
    }

    BackHandler {
        if (screen == AppScreen.DASHBOARD || routeStack.size == 1) {
            showExitConfirmation = true
        } else {
            navigateBack()
        }
    }

    if (showExitConfirmation) {
        AlertDialog(
            onDismissRequest = { showExitConfirmation = false },
            title = { Text("خروج از سابو") },
            text = { Text("آیا می‌خواهید از برنامه خارج شوید؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showExitConfirmation = false
                        activity?.finish()
                    },
                ) {
                    Text("خروج")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirmation = false }) {
                    Text("انصراف")
                }
            },
        )
    }

    LaunchedEffect(securityState.currentUser, securityState.users.size) {
        if (securityState.currentUser == null) {
            if (screen != AppScreen.SECURITY || routeStack.size != 1) {
                routeStack = listOf(AppScreen.SECURITY.name)
            }
        } else if (!canOpenScreen(securityState.currentUser, screen)) {
            routeStack = listOf(AppScreen.DASHBOARD.name)
        } else if (screen == AppScreen.SECURITY && routeStack.size == 1) {
            routeStack = listOf(AppScreen.DASHBOARD.name)
        }
    }

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        when (screen) {
            AppScreen.DASHBOARD -> DashboardScreen(
                state = dashboardState,
                operationsState = operationsState,
                currentUser = securityState.currentUser,
                onSearch = { navigate(AppScreen.GLOBAL_SEARCH) },
                onSettings = { navigate(AppScreen.SETTINGS) },
                onOpen = { target ->
                    if (target != null) navigate(target)
                    else operations.clearMessage()
                },
            )

            AppScreen.PURCHASES -> PurchasesScreen(
                state = operationsState,
                onSearch = operations::searchPurchases,
                onSelect = operations::selectPurchase,
                onSettle = operations::settlePurchase,
                onReverseSettlement = operations::reversePurchaseSettlement,
                onReverse = operations::reversePurchase,
                onAdd = { navigate(AppScreen.NEW_PURCHASE) },
                onBack = {
                    operations.selectPurchase(null)
                    navigateBack()
                },
            )

            AppScreen.NEW_PURCHASE -> PurchaseEntryScreen(
                state = operationsState,
                onPost = operations::postPurchase,
                onBack = { navigateBack() },
            )

            AppScreen.SUPPLIERS -> SuppliersScreen(
                state = operationsState,
                onSave = operations::saveSupplier,
                onDeactivate = operations::deactivateSupplier,
                onBack = { navigateBack() },
            )

            AppScreen.INVENTORY -> InventoryScreen(
                state = operationsState,
                onSave = operations::saveInventoryItem,
                onDeactivate = operations::deactivateInventoryItem,
                onCount = operations::postInventoryCount,
                onBack = { navigateBack() },
            )

            AppScreen.SALES -> SalesScreen(
                state = salesState,
                onSearch = sales::search,
                onSelect = sales::selectSale,
                onAddCustomer = sales::addCustomer,
                onPostSale = sales::postSale,
                onReceive = sales::receive,
                onReverse = sales::reverse,
                onReverseSale = sales::reverseSale,
                onReplaceSale = sales::replaceSale,
                onSetReportRange = sales::setReportRange,
                onBack = { sales.selectSale(null); navigateBack() },
            )

            AppScreen.RECIPES -> RecipeScreen(
                state = recipeState,
                onSelect = recipes::select,
                onSave = recipes::save,
                onBack = { recipes.select(null); navigateBack() },
            )

            AppScreen.ACCOUNTING -> AccountingScreen(
                state = accountingState,
                onSearch = accounting::searchJournals,
                onSelectJournal = accounting::selectJournal,
                onSelectLedger = accounting::selectLedger,
                onSaveAccount = accounting::saveAccount,
                onDeactivateAccount = accounting::deactivateAccount,
                onReverse = accounting::reverseManual,
                onAddJournal = { navigate(AppScreen.NEW_JOURNAL) },
                onBack = { navigateBack() },
            )

            AppScreen.AUDIT_LOG -> AuditLogScreen(state = operationsState, onBack = { navigateBack() })

            AppScreen.RESTAURANT_OPERATIONS -> RestaurantOperationsScreen(
                state = restaurantOperationsState,
                employees = personnelState.employees,
                canManageTables = securityState.currentUser?.role?.allows("SALES") == true,
                canManageKitchen = securityState.currentUser?.role?.allows("KITCHEN") == true,
                canManageShifts = securityState.currentUser?.role?.allows("PERSONNEL") == true,
                canManageApprovals = securityState.currentUser?.role?.allows("AUDIT") == true,
                onAddTable = restaurantOperations::addTable,
                onTable = restaurantOperations::transitionTable,
                onReservation = restaurantOperations::addReservation,
                onTicket = restaurantOperations::addTicket,
                onTicketStatus = restaurantOperations::transitionTicket,
                onShift = restaurantOperations::planShift,
                onApproval = restaurantOperations::requestApproval,
                onReview = restaurantOperations::review,
                onBack = { navigateBack() },
            )

            AppScreen.PERSONNEL -> PersonnelScreen(
                state = personnelState,
                performanceState = performanceState,
                onSaveEmployee = personnel::saveEmployee,
                onDeactivate = personnel::deactivate,
                onSaveAttendance = personnel::saveAttendance,
                onPostPayroll = personnel::postPayroll,
                onCalculatePayroll = personnel::calculatePayroll,
                onSelectEmployee = personnel::selectEmployee,
                onSaveContract = personnel::saveContract,
                onPostAdvance = personnel::postAdvance,
                onSettleAdvance = personnel::settleAdvance,
                onRequestLeave = personnel::requestLeave,
                onReviewLeave = personnel::reviewLeave,
                onCancelLeave = personnel::cancelLeave,
                onLoadAttendanceSummary = personnel::loadAttendanceSummary,
                onSavePerformanceGoal = { performance.saveGoal(null, it) },
                onDeactivatePerformanceGoal = performance::deactivateGoal,
                onSubmitPerformanceReview = performance::submitReview,
                onBack = { navigateBack() },
            )

            AppScreen.SECURITY -> SecurityScreen(
                state = securityState,
                onSave = security::save,
                onDeactivate = security::deactivate,
                onSwitch = security::switchUser,
                onLogout = security::logout,
                onBackup = security::createBackup,
                onBackupToDrive = security::backupToDrive,
                onExport = security::exportBackup,
                onImport = security::importBackup,
                onRestore = security::restore,
                canManageUsers = securityState.currentUser?.role?.allows("MANAGE_USERS") == true,
                canBackup = securityState.currentUser?.role?.allows("BACKUP") == true,
                onBack = { navigateBack() },
            )

            AppScreen.ASSETS -> AssetScreen(
                state = assetState,
                onSave = assets::save,
                onDispose = assets::dispose,
                onDepreciate = assets::depreciate,
                onBack = { navigateBack() },
            )


            AppScreen.CRM -> CrmScreen(
                state = crmState,
                onAdjustPoints = crm::adjustPoints,
                onAddFollowUp = crm::addFollowUp,
                onComplete = crm::complete,
                onBack = { navigateBack() },
            )

            AppScreen.ALERTS -> AlertCenterScreen(
                state = alertState,
                onRefresh = alerts::refresh,
                onRead = alerts::markRead,
                onDismiss = alerts::dismiss,
                onClearDismissed = alerts::clearDismissed,
                onBack = { navigateBack() },
            )

            AppScreen.REPORTS -> ReportsCenterScreen(
                dashboard = dashboardState,
                sales = salesState,
                accounting = accountingState,
                operations = operationsState,
                onOpenSales = { navigate(AppScreen.SALES) },
                onOpenAccounting = { navigate(AppScreen.ACCOUNTING) },
                onOpenInventory = { navigate(AppScreen.INVENTORY) },
                onBack = { navigateBack() },
            )


            AppScreen.GLOBAL_SEARCH -> GlobalSearchScreen(
                currentUser = securityState.currentUser,
                onOpen = { navigate(it) },
                onBack = { navigateBack() },
            )

            AppScreen.SETTINGS -> SettingsScreen(
                themePreference = themePreference,
                syncState = syncState,
                onSaveSync = sync::save,
                onRunSync = sync::runNow,
                onThemePreferenceChange = onThemePreferenceChange,
                onOpenSecurity = { navigate(AppScreen.SECURITY) },
                showSensitiveSettings = securityState.currentUser?.role?.allows("BACKUP") == true,
                onBack = { navigateBack() },
            )

            AppScreen.NEW_JOURNAL -> ManualJournalEntryScreen(
                state = accountingState,
                onPost = accounting::postManual,
                onBack = { navigateBack() },
            )
        }
    }
}

@Composable
private fun DashboardScreen(
    state: DashboardSnapshot,
    operationsState: OperationsUiState,
    currentUser: AppUserRecord?,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (AppScreen?) -> Unit,
) {
    val visibleModules = modules.filter { module ->
        module.screen != null && canOpenScreen(currentUser, module.screen)
    }
    val totalLiquidity = state.cashBalanceRial + state.bankBalanceRial
    val urgentCount = operationsState.lowStockItems.size + operationsState.settlementAlerts.size
    val canSeeAccounting = currentUser?.role?.allows("ACCOUNTING") == true
    val canSeeAlerts = canOpenScreen(currentUser, AppScreen.ALERTS)

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            PremiumBottomBar(
                onHome = { },
                onOperations = { onOpen(AppScreen.SALES) },
                onReports = { onOpen(AppScreen.REPORTS) },
                onProfile = onSettings,
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp),
        ) {
            item {
                PremiumHeader(
                    userName = currentUser?.displayName ?: "کاربر سابو",
                    roleTitle = currentUser?.role?.title.orEmpty(),
                    alertCount = if (canSeeAlerts) urgentCount else 0,
                    onSearch = onSearch,
                    onAlerts = { onOpen(AppScreen.ALERTS) },
                    onSettings = onSettings,
                )
            }
            if (canSeeAlerts) {
                item {
                    DailyFocusCard(
                        urgentCount = urgentCount,
                        onOpen = { if (urgentCount > 0) onOpen(AppScreen.ALERTS) else onOpen(AppScreen.REPORTS) },
                    )
                }
            }
            if (canSeeAccounting) {
                item {
                    BalanceSpotlight(
                        totalLiquidity = totalLiquidity,
                        cash = state.cashBalanceRial,
                        bank = state.bankBalanceRial,
                        onOpenAccounting = { onOpen(AppScreen.ACCOUNTING) },
                    )
                }
            }
            item {
                PremiumSectionTitle(
                    title = "عملیات روزانه",
                    subtitle = "ثبت سریع بدون گشتن بین منوها",
                )
                Spacer(Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 20.dp),
                ) {
                    if (canOpenScreen(currentUser, AppScreen.SALES)) item { PremiumQuickAction("فروش", "فاکتور جدید", Icons.Outlined.PointOfSale) { onOpen(AppScreen.SALES) } }
                    if (canOpenScreen(currentUser, AppScreen.NEW_PURCHASE)) item { PremiumQuickAction("خرید", "ورود کالا", Icons.Outlined.ShoppingBag) { onOpen(AppScreen.NEW_PURCHASE) } }
                    if (canOpenScreen(currentUser, AppScreen.INVENTORY)) item { PremiumQuickAction("انبار", "موجودی کالا", Icons.Outlined.Inventory2) { onOpen(AppScreen.INVENTORY) } }
                    if (canOpenScreen(currentUser, AppScreen.CRM)) item { PremiumQuickAction("مشتریان", "ارتباط و وفاداری", Icons.Outlined.People) { onOpen(AppScreen.CRM) } }
                }
            }
            if (canSeeAccounting) {
                item {
                    PremiumSectionTitle(
                        title = "وضعیت امروز",
                        subtitle = "اعداد مهم در یک نمای جمع‌وجور",
                    )
                    Spacer(Modifier.height(10.dp))
                    BusinessPulse(
                        inventory = state.inventoryValueRial,
                        payables = state.supplierPayablesRial,
                        alerts = urgentCount,
                    )
                }
            }
            if (canOpenScreen(currentUser, AppScreen.INVENTORY) || canOpenScreen(currentUser, AppScreen.PURCHASES)) {
                item {
                    AttentionCard(
                        lowStockCount = operationsState.lowStockItems.size,
                        settlementCount = operationsState.settlementAlerts.size,
                        urgentCount = urgentCount,
                        onInventory = { onOpen(AppScreen.INVENTORY) },
                        onPurchases = { onOpen(AppScreen.PURCHASES) },
                    )
                }
            }
            item {
                PremiumSectionTitle(
                    title = "همه بخش‌ها",
                    subtitle = "ابزارهای مدیریتی در یک فهرست مرتب",
                    trailing = "جست‌وجو",
                    onTrailing = onSearch,
                )
            }
            items(visibleModules) { module ->
                PremiumModuleRow(
                    module = module,
                    modifier = Modifier.padding(horizontal = 20.dp),
                    onClick = { onOpen(module.screen) },
                )
            }
        }
    }
}

@Composable
private fun PremiumHeader(
    userName: String,
    roleTitle: String,
    alertCount: Int,
    onSearch: () -> Unit,
    onAlerts: () -> Unit,
    onSettings: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(SabouBrand.EvergreenDark, SabouBrand.Emerald)))
            .padding(horizontal = 20.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SabouBrandMark(Modifier.clickable(onClick = onSettings))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("SABOU  ·  مدیریت هوشمند", style = MaterialTheme.typography.labelLarge, color = SabouBrand.GoldBright, fontWeight = FontWeight.ExtraBold)
            Text("سلام، $userName", style = MaterialTheme.typography.titleLarge, color = Color.White, fontWeight = FontWeight.ExtraBold)
            Text(roleTitle.ifBlank { "مدیریت مجموعه" }, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .72f))
        }
        IconButton(onClick = onSearch) { Icon(Icons.Outlined.Search, contentDescription = "جست‌وجو", tint = Color.White) }
        Box {
            IconButton(onClick = onAlerts) { Icon(Icons.Outlined.NotificationsNone, contentDescription = "هشدارها", tint = Color.White) }
            if (alertCount > 0) {
                Surface(modifier = Modifier.align(Alignment.TopEnd), shape = CircleShape, color = MaterialTheme.colorScheme.error) {
                    Text(alertCount.coerceAtMost(9).toString(), modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp), color = MaterialTheme.colorScheme.onError, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DailyFocusCard(urgentCount: Int, onOpen: () -> Unit) {
    val hasUrgent = urgentCount > 0
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = if (hasUrgent) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = if (hasUrgent) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.secondary) {
                Icon(Icons.Outlined.AutoAwesome, null, tint = if (hasUrgent) MaterialTheme.colorScheme.onTertiary else MaterialTheme.colorScheme.onSecondary, modifier = Modifier.padding(10.dp).size(21.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(if (hasUrgent) "تمرکز امروز" else "شروع آرام امروز", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (hasUrgent) "$urgentCount مورد نیازمند بررسی است؛ از مهم‌ترین مورد شروع کن." else "هشدار فوری نداری؛ گزارش‌ها را مرور کن و برای روز برنامه بچین.",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (hasUrgent) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
            Text("‹", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun BalanceSpotlight(
    totalLiquidity: Long,
    cash: Long,
    bank: Long,
    onOpenAccounting: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).clickable(onClick = onOpenAccounting),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(SabouBrand.EvergreenDark, SabouBrand.Evergreen, SabouBrand.Emerald)))
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("نمای زنده نقدینگی", color = SabouBrand.GoldBright, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        formatMoney(totalLiquidity),
                        color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Surface(shape = CircleShape, color = SabouBrand.GoldBright.copy(alpha = .18f), border = BorderStroke(1.dp, SabouBrand.GoldBright.copy(alpha = .5f))) {
                    Icon(
                        Icons.Outlined.AccountBalance,
                        contentDescription = null,
                        tint = SabouBrand.GoldBright,
                        modifier = Modifier.padding(12.dp).size(22.dp),
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BalanceMiniTile("صندوق", formatMoney(cash), Modifier.weight(1f))
                BalanceMiniTile("بانک", formatMoney(bank), Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun BalanceMiniTile(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.onSecondary.copy(alpha = .10f)) {
        Column(Modifier.padding(horizontal = 13.dp, vertical = 11.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(label, color = MaterialTheme.colorScheme.onSecondary.copy(alpha = .72f), style = MaterialTheme.typography.labelMedium)
            Text(value, color = MaterialTheme.colorScheme.onSecondary, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun PremiumSectionTitle(
    title: String,
    subtitle: String,
    trailing: String? = null,
    onTrailing: (() -> Unit)? = null,
) {
    Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (trailing != null && onTrailing != null) {
            TextButton(onClick = onTrailing) { Text(trailing, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun PremiumQuickAction(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        modifier = Modifier.width(136.dp).height(112.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
    ) {
        Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.padding(9.dp).size(20.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }
    }
}

@Composable
private fun BusinessPulse(inventory: Long, payables: Long, alerts: Int) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f)),
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            PulseItem("ارزش انبار", formatMoney(inventory), Modifier.weight(1f))
            PulseDivider()
            PulseItem("بدهی خرید", formatMoney(payables), Modifier.weight(1f))
            PulseDivider()
            PulseItem("هشدار فعال", alerts.toString(), Modifier.weight(1f))
        }
    }
}

@Composable
private fun RowScope.PulseDivider() {
    Box(Modifier.width(1.dp).height(42.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = .65f)))
}

@Composable
private fun PulseItem(title: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
private fun AttentionCard(
    lowStockCount: Int,
    settlementCount: Int,
    urgentCount: Int,
    onInventory: () -> Unit,
    onPurchases: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .55f)),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = if (urgentCount > 0) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer) {
                    Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) {
                        Text(if (urgentCount > 0) urgentCount.toString() else "✓", fontWeight = FontWeight.Bold, color = if (urgentCount > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("نیازمند توجه", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text(if (urgentCount > 0) "مواردی که بهتر است امروز بررسی شوند" else "همه‌چیز مرتب است", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                }
            }
            if (lowStockCount > 0) AttentionRow("کمبود موجودی", "$lowStockCount کالا", onInventory)
            if (settlementCount > 0) AttentionRow("تسویه سررسید", "$settlementCount فاکتور", onPurchases)
            if (urgentCount == 0) Text("هشدار فوری یا سررسید عقب‌افتاده‌ای وجود ندارد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AttentionRow(title: String, count: String, onClick: () -> Unit) {
    Surface(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .48f)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
            Text(count, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun PremiumModuleRow(module: ModuleCard, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val enabled = module.screen != null
    val icon = moduleIcon(module.screen)
    Surface(
        modifier = modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).clickable(enabled = enabled, onClick = onClick),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .16f)),
        shadowElevation = 2.dp,
        shape = RoundedCornerShape(20.dp),
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primary) {
                Icon(icon, null, tint = SabouBrand.GoldBright, modifier = Modifier.padding(10.dp).size(21.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(module.title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.bodyLarge)
                Text(
                    if (enabled) moduleSubtitle(module.screen) else "به‌زودی",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text("‹", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

private fun moduleIcon(screen: AppScreen?): ImageVector = when (screen) {
    AppScreen.PURCHASES, AppScreen.NEW_PURCHASE -> Icons.Outlined.ShoppingBag
    AppScreen.INVENTORY -> Icons.Outlined.Inventory2
    AppScreen.SALES -> Icons.Outlined.PointOfSale
    AppScreen.CRM, AppScreen.SUPPLIERS, AppScreen.PERSONNEL -> Icons.Outlined.People
    AppScreen.ACCOUNTING -> Icons.Outlined.AccountBalance
    AppScreen.REPORTS -> Icons.Outlined.Assessment
    else -> Icons.Outlined.Assessment
}

private fun moduleSubtitle(screen: AppScreen?): String = when (screen) {
    AppScreen.PURCHASES -> "فاکتورها، پرداخت‌ها و سررسیدها"
    AppScreen.SUPPLIERS -> "تأمین‌کنندگان و مانده حساب"
    AppScreen.INVENTORY -> "موجودی، شمارش و هشدار کالا"
    AppScreen.RECIPES -> "محصول، رسپی و بهای تمام‌شده"
    AppScreen.SALES -> "فروش، دریافت و مشتریان"
    AppScreen.CRM -> "وفاداری و پیگیری مشتری"
    AppScreen.ALERTS -> "هشدارهای مالی و عملیاتی"
    AppScreen.ACCOUNTING -> "اسناد، حساب‌ها و گزارش مالی"
    AppScreen.PERSONNEL -> "کارکنان، حقوق و پرداخت"
    AppScreen.ASSETS -> "دارایی‌ها و استهلاک"
    AppScreen.REPORTS -> "شاخص‌های مدیریتی و چاپ"
    AppScreen.AUDIT_LOG -> "ردیابی فعالیت کاربران"
    AppScreen.SECURITY -> "کاربران، دسترسی و پشتیبان‌گیری"
    else -> "مدیریت و مشاهده جزئیات"
}

@Composable
private fun PremiumBottomBar(
    onHome: () -> Unit,
    onOperations: () -> Unit,
    onReports: () -> Unit,
    onProfile: () -> Unit,
) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 6.dp) {
        NavigationBarItem(selected = true, onClick = onHome, icon = { Icon(Icons.Outlined.Home, null) }, label = { Text("خانه") })
        NavigationBarItem(selected = false, onClick = onOperations, icon = { Icon(Icons.Outlined.PointOfSale, null) }, label = { Text("عملیات") })
        NavigationBarItem(selected = false, onClick = onReports, icon = { Icon(Icons.Outlined.Assessment, null) }, label = { Text("گزارش‌ها") })
        NavigationBarItem(selected = false, onClick = onProfile, icon = { Icon(Icons.Outlined.PersonOutline, null) }, label = { Text("حساب من") })
    }
}
