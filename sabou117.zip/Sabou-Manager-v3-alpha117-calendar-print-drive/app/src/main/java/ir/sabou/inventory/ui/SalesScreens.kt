package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.sales.CustomerItem
import ir.sabou.inventory.domain.sales.SalePaymentMethod
import ir.sabou.inventory.core.MoneyRial

internal fun saleLineTotalRial(line: SaleLineInput): Long = runCatching {
    MoneyRial.of(line.unitPriceRial).times(parseQuantity(line.quantity)).value
}.getOrDefault(0L)

@Composable
fun SalesScreen(
    state: SalesUiState,
    onSearch: (String)->Unit,
    onSelect: (Long?)->Unit,
    onAddCustomer: (String,String,String,Long,String,()->Unit)->Unit,
    onPostSale: (String,Long?,String,Long,Long?,String,Long,Long,SalePaymentMethod,String,List<SaleLineInput>,()->Unit)->Unit,
    onReceive: (Long,Long,Long,SalePaymentMethod,()->Unit)->Unit,
    onReverse: (Long,Long)->Unit,
    onReverseSale: (Long,Long)->Unit,
    onReplaceSale: (Long,Long,String,Long?,String,Long,Long?,String,Long,Long,SalePaymentMethod,String,List<SaleLineInput>,()->Unit)->Unit,
    onSetReportRange: (Long,Long)->Unit,
    onBack: ()->Unit,
) {
    var customerDialog by remember { mutableStateOf(false) }
    var saleDialog by remember { mutableStateOf(false) }
    var reportDialog by remember { mutableStateOf(false) }
    var replacementSaleId by remember { mutableStateOf<Long?>(null) }

    Scaffold(
        topBar = { ProfessionalTopBar("فروش", "فاکتورها، دریافت‌ها و عملکرد درآمد", onBack, "فروش جدید") { saleDialog = true } },
        containerColor = MaterialTheme.colorScheme.background,
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item { state.message?.let { MessageCard(it) } }
            item {
                Card(
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                ) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text("درآمد فعال", color = MaterialTheme.colorScheme.onPrimary.copy(alpha = .8f), style = MaterialTheme.typography.labelLarge)
                        Text(formatMoney(state.activeSalesRial), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            MetricTile("سود ناخالص", formatMoney(state.grossProfitRial), Modifier.weight(1f))
                            MetricTile("مطالبات", formatMoney(state.receivablesRial), Modifier.weight(1f))
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { customerDialog = true }, modifier = Modifier.weight(1f), shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) { Text("مشتری جدید") }
                    OutlinedButton(onClick = { reportDialog = true }, modifier = Modifier.weight(1f), shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) { Text("گزارش فروش") }
                }
            }
            item { PremiumSearchField(state.search, onSearch, "جست‌وجوی فاکتور یا مشتری") }
            item { SectionHeading("فاکتورهای اخیر", "وضعیت پرداخت و مانده هر فاکتور") }
            if (state.sales.isEmpty()) {
                item { EmptyStatePanel("هنوز فروشی ثبت نشده", "اولین فاکتور را ثبت کنید تا گزارش درآمد و مطالبات فعال شود.") }
            } else {
                items(state.sales, key = { it.id }) { sale ->
                    InvoiceSummaryCard(
                        title = "فاکتور ${sale.invoiceNo}",
                        party = sale.customerName,
                        amount = formatMoney(sale.totalRial),
                        status = sale.paymentStatus,
                        outstanding = (sale.totalRial - sale.paidRial).takeIf { it > 0 }?.let(::formatMoney),
                        meta = "${sale.channel}  •  مشاهده جزئیات و دریافت وجه",
                        onClick = { onSelect(sale.id) },
                    )
                }
            }
        }
    }
    if(customerDialog) CustomerDialog(onDismiss={customerDialog=false},onSave=onAddCustomer)
    if(saleDialog) SaleEntryDialog(state.customers,state.menuItems,onDismiss={saleDialog=false},onSave=onPostSale)
    if(reportDialog) SalesReportDialog(state,onDismiss={reportDialog=false},onApply=onSetReportRange)
    replacementSaleId?.let { id -> SaleEntryDialog(state.customers,state.menuItems,onDismiss={replacementSaleId=null},onSave={invoice,customerId,customerName,saleDay,dueDay,channel,discount,delivery,method,notes,lines,done -> onReplaceSale(id,currentEpochDay(),invoice,customerId,customerName,saleDay,dueDay,channel,discount,delivery,method,notes,lines){ done(); replacementSaleId=null } }) }
    state.selectedSaleId?.let { id -> ReceiptDialog(id,state.sales.firstOrNull { it.id == id },state.payments,onDismiss={onSelect(null)},onReceive=onReceive,onReverse=onReverse,onReverseSale=onReverseSale,onReplace={ replacementSaleId=id; onSelect(null) }) }
}

@Composable
private fun SaleEntryDialog(
    customers: List<CustomerItem>,
    menuItems: List<ir.sabou.inventory.domain.recipe.MenuItem>,
    onDismiss: () -> Unit,
    onSave: (String, Long?, String, Long, Long?, String, Long, Long, SalePaymentMethod, String, List<SaleLineInput>, () -> Unit) -> Unit,
) {
    val today = remember { currentEpochDay() }
    var invoice by remember { mutableStateOf("FR-${System.currentTimeMillis().toString().takeLast(10)}") }
    var customerId by remember { mutableStateOf<Long?>(null) }
    var customerName by remember { mutableStateOf("مشتری متفرقه") }
    var day by remember { mutableLongStateOf(today) }
    var due by remember { mutableStateOf<Long?>(null) }
    var channel by remember { mutableStateOf("حضوری") }
    var discount by remember { mutableStateOf("") }
    var delivery by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var method by remember { mutableStateOf(SalePaymentMethod.CARD) }
    var error by remember { mutableStateOf<String?>(null) }
    var lines by remember { mutableStateOf(listOf(SaleLineInput(productName = "", quantity = "1", unitPriceRial = 0))) }
    val subtotal = lines.sumOf(::saleLineTotalRial)
    val payable = (subtotal - (discount.toLongOrNull() ?: 0L) + (delivery.toLongOrNull() ?: 0L)).coerceAtLeast(0L)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("صدور فاکتور فروش", fontWeight = FontWeight.ExtraBold) },
        text = {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.heightIn(max = 620.dp),
            ) {
                item { error?.let { MessageCard(it, isError = true) } }
                item {
                    FormSection("اطلاعات فاکتور", "شماره، تاریخ و کانال فروش") {
                        OutlinedTextField(invoice, { invoice = it }, label = { Text("شماره فاکتور خودکار") }, readOnly = true, singleLine = true, modifier = Modifier.fillMaxWidth())
                        PersianDateField("تاریخ فروش", day, { day = it })
                        OptionalPersianDateField("تاریخ سررسید", due, { due = it }, defaultEpochDay = day)
                        OutlinedTextField(channel, { channel = it }, label = { Text("کانال فروش") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
                item {
                    FormSection("مشتری", "مشتری ثبت‌شده یا فروش متفرقه") {
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp),
                        ) {
                            item { FilterChip(selected = customerId == null, onClick = { customerId = null; customerName = "مشتری متفرقه" }, label = { Text("متفرقه") }) }
                            items(customers.take(8), key = { it.id }) { customer ->
                                FilterChip(selected = customerId == customer.id, onClick = { customerId = customer.id; customerName = customer.name }, label = { Text(customer.name, maxLines = 1) })
                            }
                        }
                        OutlinedTextField(customerName, { customerName = it }, label = { Text("نام مشتری") }, enabled = customerId == null, singleLine = true, modifier = Modifier.fillMaxWidth())
                    }
                }
                item { SectionHeading("اقلام فاکتور", "قیمت و تعداد هر ردیف را وارد کنید") }
                items(lines.indices.toList()) { index ->
                    val line = lines[index]
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("ردیف ${index + 1}", fontWeight = FontWeight.Bold)
                            if (menuItems.isNotEmpty()) {
                                LazyRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    contentPadding = PaddingValues(horizontal = 2.dp),
                                ) {
                                    items(menuItems, key = { it.id }) { menu ->
                                        FilterChip(
                                            selected = line.menuItemId == menu.id,
                                            onClick = { lines = lines.toMutableList().also { it[index] = line.copy(menuItemId = menu.id, productName = menu.name, unitPriceRial = menu.salePriceRial) } },
                                            label = { Text(menu.name, maxLines = 1) },
                                        )
                                    }
                                }
                            }
                            OutlinedTextField(line.productName, { value -> lines = lines.toMutableList().also { it[index] = line.copy(menuItemId = null, productName = value) } }, label = { Text("شرح محصول") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(line.quantity, { value -> lines = lines.toMutableList().also { it[index] = line.copy(quantity = value.filter { ch -> ch.isDigit() || ch == '.' }) } }, label = { Text("تعداد") }, modifier = Modifier.weight(1f))
                                OutlinedTextField(if (line.unitPriceRial == 0L) "" else line.unitPriceRial.toString(), { value -> lines = lines.toMutableList().also { it[index] = line.copy(unitPriceRial = value.filter(Char::isDigit).toLongOrNull() ?: 0L) } }, label = { Text("قیمت واحد") }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("جمع ردیف", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(formatMoney(saleLineTotalRial(line)), fontWeight = FontWeight.Bold)
                            }
                            if (lines.size > 1) TextButton(onClick = { lines = lines.toMutableList().also { it.removeAt(index) } }) { Text("حذف ردیف") }
                        }
                    }
                }
                item { OutlinedButton(onClick = { lines = lines + SaleLineInput(productName = "", quantity = "1", unitPriceRial = 0) }, modifier = Modifier.fillMaxWidth()) { Text("افزودن ردیف جدید") } }
                item {
                    FormSection("پرداخت و جمع‌بندی", "مبلغ نهایی پیش از ثبت") {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(discount, { discount = it.filter(Char::isDigit) }, label = { Text("تخفیف") }, modifier = Modifier.weight(1f))
                            OutlinedTextField(delivery, { delivery = it.filter(Char::isDigit) }, label = { Text("هزینه ارسال") }, modifier = Modifier.weight(1f))
                        }
                        Text("روش پرداخت", fontWeight = FontWeight.Bold)
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(5.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp),
                        ) {
                            items(SalePaymentMethod.entries.toList(), key = { it.name }) { value ->
                                FilterChip(selected = method == value, onClick = { method = value }, label = { Text(value.storedValue ?: "اعتباری", maxLines = 1) })
                            }
                        }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("جمع اقلام"); Text(formatMoney(subtotal)) }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("مبلغ قابل پرداخت", fontWeight = FontWeight.Bold); Text(formatMoney(payable), fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary) }
                        OutlinedTextField(notes, { notes = it }, label = { Text("توضیحات") }, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    when {
                        invoice.isBlank() -> error = "شماره فاکتور را وارد کنید."
                        customerName.isBlank() -> error = "نام مشتری را وارد کنید."
                        day <= 0 -> error = "تاریخ فروش معتبر نیست."
                        lines.isEmpty() || lines.any { it.productName.isBlank() || runCatching { parseQuantity(it.quantity).value }.getOrDefault(0L) <= 0 || it.unitPriceRial <= 0 } -> error = "اطلاعات همه ردیف‌های فاکتور را کامل کنید."
                        else -> {
                            error = null
                            onSave(invoice, customerId, customerName, day, due, channel, discount.toLongOrNull() ?: 0L, delivery.toLongOrNull() ?: 0L, method, notes, lines, onDismiss)
                        }
                    }
                },
            ) { Text("ثبت نهایی فاکتور") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable private fun CustomerDialog(onDismiss:()->Unit,onSave:(String,String,String,Long,String,()->Unit)->Unit){
    var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}; var address by remember{mutableStateOf("")}; var credit by remember{mutableStateOf("")}; var notes by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text("مشتری جدید")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){ OutlinedTextField(name,{name=it},label={Text("نام")}); OutlinedTextField(phone,{phone=it},label={Text("تلفن")}); OutlinedTextField(address,{address=it},label={Text("آدرس")}); OutlinedTextField(credit,{credit=it.filter(Char::isDigit)},label={Text("سقف اعتبار (ریال)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number)); OutlinedTextField(notes,{notes=it},label={Text("یادداشت")}) }},confirmButton={Button(onClick={onSave(name,phone,address,credit.toLongOrNull()?:0,notes,onDismiss)}){Text("ثبت")}},dismissButton={TextButton(onClick=onDismiss){Text("انصراف")}})
}

@Composable
private fun ReceiptDialog(
    saleId: Long,
    sale: ir.sabou.inventory.domain.sales.SaleListItem?,
    payments: List<ir.sabou.inventory.domain.sales.SalePaymentItem>,
    onDismiss: () -> Unit,
    onReceive: (Long, Long, Long, SalePaymentMethod, () -> Unit) -> Unit,
    onReverse: (Long, Long) -> Unit,
    onReverseSale: (Long, Long) -> Unit,
    onReplace: () -> Unit,
) {
    var amount by remember { mutableStateOf("") }
    var day by remember { mutableLongStateOf(currentEpochDay()) }
    var method by remember { mutableStateOf(SalePaymentMethod.CARD) }
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("وصول مطالبات") },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                item { OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("مبلغ ریال") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
                item { PersianDateField("تاریخ عملیات", day, { day = it }) }
                item {
                    LazyRow(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf(SalePaymentMethod.CASH, SalePaymentMethod.CARD, SalePaymentMethod.TRANSFER), key = { it.name }) { value ->
                            FilterChip(selected = method == value, onClick = { method = value }, label = { Text(value.storedValue ?: value.name, maxLines = 1) })
                        }
                    }
                }
                item { Text("تاریخچه", fontWeight = FontWeight.Bold) }
                items(payments, key = { it.id }) { payment ->
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${formatMoney(payment.amountRial)} · ${payment.method}${if (payment.reversed) " · برگشت‌خورده" else ""}")
                        if (!payment.reversed) TextButton(onClick = { onReverse(payment.id, day) }) { Text("برگشت پرداخت") }
                        HorizontalDivider()
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onReceive(saleId, amount.toLongOrNull() ?: 0, day, method, onDismiss) }) { Text("ثبت وصول") } },
        dismissButton = {
            Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                TextButton(onClick = onReplace) { Text("اصلاح با جایگزین") }
                sale?.let { OutlinedButton(onClick = { printSalesInvoice(context, it, payments) }) { Text("چاپ فاکتور / PDF") } }
                TextButton(onClick = { onReverseSale(saleId, day) }) { Text("برگشت فاکتور") }
                TextButton(onClick = onDismiss) { Text("بستن") }
            }
        },
    )
}


@Composable
private fun SalesReportDialog(state: SalesUiState, onDismiss: () -> Unit, onApply: (Long, Long) -> Unit) {
    var from by remember(state.reportFromEpochDay) { mutableLongStateOf(state.reportFromEpochDay) }
    var to by remember(state.reportToEpochDay) { mutableLongStateOf(state.reportToEpochDay) }
    val report = state.report
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("گزارش بازه‌ای فروش") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PersianDateField("از تاریخ", from, { from = it })
                PersianDateField("تا تاریخ", to, { to = it })
                report?.let {
                    HorizontalDivider()
                    Text("تعداد فاکتور: ${it.invoiceCount}")
                    Text("فروش: ${formatMoney(it.salesRial)}")
                    Text("بهای تمام‌شده: ${formatMoney(it.costOfGoodsRial)}")
                    Text("سود ناخالص: ${formatMoney(it.grossProfitRial)}", fontWeight = FontWeight.Bold)
                    Text("مطالبات باز: ${formatMoney(it.receivablesRial)}")
                    if (it.topChannels.isNotEmpty()) {
                        Text("کانال‌های برتر", fontWeight = FontWeight.Bold)
                        it.topChannels.forEach { (name, amount) -> Text("$name: ${formatMoney(amount)}") }
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { onApply(from, to) }) { Text("اعمال بازه") } },
        dismissButton = { Column(horizontalAlignment = androidx.compose.ui.Alignment.End) { report?.let { OutlinedButton(onClick={ printSalesReport(context, it) }) { Text("چاپ / PDF") } }; TextButton(onClick = onDismiss) { Text("بستن") } } },
    )
}
