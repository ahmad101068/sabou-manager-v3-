package ir.sabou.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.ui.SabouApp
import ir.sabou.inventory.ui.SabouSplash
import ir.sabou.inventory.ui.ThemePreference
import ir.sabou.inventory.ui.theme.SabouTheme
import kotlinx.coroutines.delay
import android.Manifest
import android.os.Build
import android.os.SystemClock
import androidx.activity.result.contract.ActivityResultContracts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        val container = (application as SabouApplication).container
        val preferences = getSharedPreferences("sabou_ui", MODE_PRIVATE)
        var selectedTheme by mutableStateOf(
            preferences.getString("theme", null)
                ?.let { stored -> runCatching { ThemePreference.valueOf(stored) }.getOrNull() }
                ?: ThemePreference.SYSTEM,
        )
        setContent {
            val dark = when (selectedTheme) {
                ThemePreference.SYSTEM -> isSystemInDarkTheme()
                ThemePreference.LIGHT -> false
                ThemePreference.DARK -> true
            }
            SabouTheme(darkTheme = dark) {
                var startupResult by remember(container) { mutableStateOf<Result<Unit>?>(null) }
                LaunchedEffect(container) {
                    val startedAt = SystemClock.elapsedRealtime()
                    val result = withContext(Dispatchers.IO) {
                        runCatching { container.initialize() }
                    }
                    val remainingSplashTime = 1_250L - (SystemClock.elapsedRealtime() - startedAt)
                    if (remainingSplashTime > 0L) delay(remainingSplashTime)
                    startupResult = result
                }
                when {
                    startupResult == null -> SabouSplash(visible = true)
                    startupResult?.isFailure == true -> StartupFailure(
                        checkNotNull(startupResult?.exceptionOrNull()),
                    )
                    else -> SabouApp(
                            container = container,
                            themePreference = selectedTheme,
                            onThemePreferenceChange = { value ->
                                selectedTheme = value
                                preferences.edit().putString("theme", value.name).apply()
                            },
                        )
                }
            }
        }
    }
}

@Composable
private fun StartupFailure(error: Throwable) {
    val details = remember(error) {
        generateSequence(error) { it.cause }
            .take(8)
            .joinToString(separator = "\n") { cause ->
                "${cause::class.java.simpleName}: ${cause.message ?: "بدون پیام"}"
            }
    }
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                "راه‌اندازی سابو انجام نشد",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.error,
            )
            Text("برنامه برای جلوگیری از بسته‌شدن ناگهانی متوقف شد. از متن زیر عکس بگیرید و ارسال کنید.")
            SelectionContainer {
                Text(
                    details,
                    modifier = Modifier.padding(vertical = 8.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}
