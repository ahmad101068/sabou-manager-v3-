package ir.sabou.inventory.data.repository

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.security.AuthenticationRequiredException
import ir.sabou.inventory.data.security.AccessDeniedException
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SecurityIntegrationTest {
    private lateinit var database: AppDatabase
    private lateinit var authorizer: SessionAuthorizer
    private var now = 1_000_000L

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = AppDatabase.createInMemory(context)
        authorizer = SessionAuthorizer(database)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun commandsAreDeniedWhenSessionIsMissing() = runBlocking {
        expectThrows<AuthenticationRequiredException> { authorizer.require("ASSETS") }
    }

    @Test
    fun firstUserMustBeOwnerAndOwnerCanCreateAnotherUser() = runBlocking {
        val repository = repository()
        expectThrows<IllegalArgumentException> {
            repository.save(null, UserDraft("cashier", "صندوقدار", "123456", UserRole.CASHIER))
        }
        val ownerId = repository.save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER))
        assertTrue(requireNotNull(database.securityDao().byId(ownerId)).pinHash.startsWith("pbkdf2-sha1$310000$"))
        assertEquals(ownerId, database.securityDao().currentUser()?.id)
        repository.switchUser(ownerId, "123456")
        val cashierId = repository.save(null, UserDraft("cashier", "صندوقدار", "654321", UserRole.CASHIER))
        assertTrue(cashierId > ownerId)
        assertEquals(2, database.securityDao().userCount())
    }

    @Test
    fun managerCannotCreateOrPromoteUsers() = runBlocking {
        val repository = repository()
        val ownerId = repository.save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER))
        repository.switchUser(ownerId, "123456")
        val managerId = repository.save(null, UserDraft("manager", "مدیر", "654321", UserRole.MANAGER))
        repository.switchUser(managerId, "654321")
        expectThrows<AccessDeniedException> {
            repository.save(null, UserDraft("second", "کاربر دوم", "111111", UserRole.OWNER))
        }
        assertEquals(2, database.securityDao().userCount())
    }

    @Test
    fun fiveWrongPinsLockLoginAndSuccessfulLoginResetsCounter() = runBlocking {
        val repository = repository()
        val ownerId = repository.save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER))
        repeat(5) {
            expectThrows<IllegalArgumentException> { repository.switchUser(ownerId, "000000") }
        }
        val locked = requireNotNull(database.securityDao().byId(ownerId))
        assertEquals(5, locked.failedPinAttempts)
        assertEquals(now + 30_000L, locked.lockUntilEpochMillis)
        expectThrows<IllegalArgumentException> { repository.switchUser(ownerId, "123456") }
        now += 30_000L
        repository.switchUser(ownerId, "123456")
        val recovered = requireNotNull(database.securityDao().byId(ownerId))
        assertEquals(0, recovered.failedPinAttempts)
        assertEquals(0L, recovered.lockUntilEpochMillis)
    }

    @Test
    fun logoutClearsTheActiveSession() = runBlocking {
        val repository = repository()
        repository.save(null, UserDraft("owner", "مالک", "123456", UserRole.OWNER))
        assertTrue(database.securityDao().currentUser() != null)

        repository.logout()

        assertEquals(null, database.securityDao().currentUser())
    }

    private fun repository() = LocalSecurityRepository(database, clock = { now }, authorizer = authorizer)

    private suspend inline fun <reified T : Throwable> expectThrows(crossinline block: suspend () -> Unit) {
        try {
            block()
            fail("Expected ${T::class.java.simpleName}")
        } catch (error: Throwable) {
            assertTrue("Expected ${T::class.java.simpleName}, got ${error::class.java.simpleName}", error is T)
        }
    }
}
