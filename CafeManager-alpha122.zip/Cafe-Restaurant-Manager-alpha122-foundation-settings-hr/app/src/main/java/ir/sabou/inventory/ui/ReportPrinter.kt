package ir.sabou.inventory.ui

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import ir.sabou.inventory.domain.accounting.JournalDetails
import ir.sabou.inventory.domain.accounting.ProfitLossSnapshot
import ir.sabou.inventory.domain.accounting.TrialBalanceSnapshot
import ir.sabou.inventory.domain.assets.AssetRecord
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.personnel.AttendanceSummary
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.purchase.PurchaseDetails
import ir.sabou.inventory.domain.recipe.MenuItem
import ir.sabou.inventory.domain.recipe.RecipeIngredientItem
import ir.sabou.inventory.domain.sales.SaleListItem
import ir.sabou.inventory.domain.sales.SalePaymentItem
import ir.sabou.inventory.domain.sales.SalesReport
import ir.sabou.inventory.organizationDisplayName

private const val PRINT_CSS = """
    @page { size: A4; margin: 14mm; }
    body { font-family: sans-serif; color: #1d1b20; line-height: 1.7; }
    h1 { color: #8d332c; font-size: 22px; margin-bottom: 4px; }
    .meta { color: #625b71; margin-bottom: 18px; }
    table { width: 100%; border-collapse: collapse; margin-top: 12px; }
    th, td { border: 1px solid #aaa; padding: 7px; text-align: right; }
    th { background: #f5e9e7; }
    .total { font-weight: bold; background: #f7f2fa; }
    .footer { margin-top: 28px; color: #625b71; font-size: 11px; }
"""

private fun htmlDocument(context: Context, title: String, body: String): String =
    """<!doctype html><html dir="rtl" lang="fa"><head><meta charset="utf-8"><style>$PRINT_CSS</style></head><body><h1>${title.html()}</h1>$body<div class="footer">${context.organizationDisplayName().html()} · ${epochDayToPersian(currentEpochDay()).display()}</div></body></html>"""

private fun String.html(): String = buildString(length) {
    this@html.forEach { char ->
        append(
            when (char) {
                '&' -> "&amp;"
                '<' -> "&lt;"
                '>' -> "&gt;"
                '"' -> "&quot;"
                '\'' -> "&#39;"
                else -> char
            },
        )
    }
}

private fun printHtml(context: Context, title: String, html: String) {
    val webView = WebView(context)
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            manager.print(
                title,
                view.createPrintDocumentAdapter(title),
                PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build(),
            )
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}

fun printPurchaseInvoice(context: Context, details: PurchaseDetails) {
    val rows = details.lines.joinToString("") {
        "<tr><td>${it.itemName.html()}</td><td>${it.quantityMicros / 1_000_000.0} ${it.unit.html()}</td><td>${formatMoney(it.unitCostRial).html()}</td><td>${formatMoney(it.lineTotalRial).html()}</td></tr>"
    }
    val body = """
        <div class="meta">تأمین‌کننده: ${details.supplierName.html()} · تاریخ: ${epochDayToPersian(details.purchaseEpochDay).display()}</div>
        <table><tr><th>شرح</th><th>تعداد</th><th>فی</th><th>جمع</th></tr>$rows
        <tr class="total"><td colspan="3">جمع کل</td><td>${formatMoney(details.totalRial).html()}</td></tr></table>
    """.trimIndent()
    printHtml(context, "فاکتور خرید ${details.invoiceNo}", htmlDocument(context, "فاکتور خرید ${details.invoiceNo}", body))
}

fun printSalesInvoice(context: Context, sale: SaleListItem, payments: List<SalePaymentItem>) {
    val paymentRows = payments.joinToString("") {
        "<tr><td>${epochDayToPersian(it.paymentEpochDay).display()}</td><td>${it.method.html()}</td><td>${formatMoney(it.amountRial).html()}</td><td>${if (it.reversed) "برگشت‌خورده" else "ثبت‌شده"}</td></tr>"
    }
    val body = """
        <div class="meta">مشتری: ${sale.customerName.html()} · تاریخ فروش: ${epochDayToPersian(sale.saleEpochDay).display()}</div>
        <table>
          <tr><th>مبلغ فاکتور</th><td>${formatMoney(sale.totalRial).html()}</td></tr>
          <tr><th>دریافت‌شده</th><td>${formatMoney(sale.paidRial).html()}</td></tr>
          <tr class="total"><th>مانده</th><td>${formatMoney((sale.totalRial - sale.paidRial).coerceAtLeast(0)).html()}</td></tr>
          <tr><th>کانال</th><td>${sale.channel.html()}</td></tr>
        </table>
        ${if (paymentRows.isBlank()) "" else "<h2>سوابق دریافت</h2><table><tr><th>تاریخ</th><th>روش</th><th>مبلغ</th><th>وضعیت</th></tr>$paymentRows</table>"}
    """.trimIndent()
    printHtml(context, "فاکتور فروش ${sale.invoiceNo}", htmlDocument(context, "فاکتور فروش ${sale.invoiceNo}", body))
}

fun printPayrollSlip(context: Context, payroll: PayrollRecord) {
    val deductions = (payroll.grossPayRial - payroll.netPayRial).coerceAtLeast(0)
    val body = """
        <div class="meta">پرسنل: ${payroll.employeeName.html()} · دوره: ${payroll.periodYear}/${payroll.periodMonth}</div>
        <table>
          <tr><th>حقوق و مزایای ناخالص</th><td>${formatMoney(payroll.grossPayRial).html()}</td></tr>
          <tr><th>جمع کسورات</th><td>${formatMoney(deductions).html()}</td></tr>
          <tr class="total"><th>خالص پرداختی</th><td>${formatMoney(payroll.netPayRial).html()}</td></tr>
          <tr><th>تاریخ پرداخت</th><td>${epochDayToPersian(payroll.paymentEpochDay).display()}</td></tr>
          <tr><th>روش پرداخت</th><td>${payroll.paymentMethod.html()}</td></tr>
          <tr><th>وضعیت</th><td>${payroll.status.html()}</td></tr>
        </table>
    """.trimIndent()
    printHtml(context, "فیش حقوقی ${payroll.employeeName}", htmlDocument(context, "فیش حقوقی", body))
}

fun printAttendanceSummary(context: Context, employeeName: String, summary: AttendanceSummary) {
    val body = """
        <div class="meta">پرسنل: ${employeeName.html()} · از ${epochDayToPersian(summary.startEpochDay).display()} تا ${epochDayToPersian(summary.endEpochDay).display()}</div>
        <table>
          <tr><th>روز حاضر</th><td>${summary.presentDays}</td><th>روز غیبت</th><td>${summary.absentDays}</td></tr>
          <tr><th>مرخصی</th><td>${summary.leaveDays}</td><th>ماموریت</th><td>${summary.missionDays}</td></tr>
          <tr><th>کارکرد</th><td>${summary.workedMinutes} دقیقه</td><th>تأخیر</th><td>${summary.lateMinutes} دقیقه</td></tr>
          <tr class="total"><th>اضافه‌کاری</th><td colspan="3">${summary.overtimeMinutes} دقیقه</td></tr>
        </table>
    """.trimIndent()
    printHtml(context, "گزارش حضور $employeeName", htmlDocument(context, "گزارش حضور و غیاب", body))
}

fun printJournal(context: Context, details: JournalDetails) {
    val rows = details.lines.joinToString("") {
        "<tr><td>${it.accountCode.html()}</td><td>${it.accountName.html()}</td><td>${formatMoney(it.debitRial).html()}</td><td>${formatMoney(it.creditRial).html()}</td><td>${it.memo.html()}</td></tr>"
    }
    val body = """
        <div class="meta">تاریخ: ${epochDayToPersian(details.entryEpochDay).display()} · شرح: ${details.description.html()}</div>
        <table><tr><th>کد</th><th>حساب</th><th>بدهکار</th><th>بستانکار</th><th>شرح</th></tr>$rows
        <tr class="total"><td colspan="2">جمع</td><td>${formatMoney(details.totalDebitRial).html()}</td><td>${formatMoney(details.totalCreditRial).html()}</td><td></td></tr></table>
    """.trimIndent()
    printHtml(context, "سند ${details.entryNo}", htmlDocument(context, "سند حسابداری ${details.entryNo}", body))
}

fun printAccountingSummary(context: Context, profitLoss: ProfitLossSnapshot, trial: TrialBalanceSnapshot) {
    val rows = trial.accounts.joinToString("") {
        "<tr><td>${it.code.html()}</td><td>${it.name.html()}</td><td>${formatMoney(it.debitBalanceRial).html()}</td><td>${formatMoney(it.creditBalanceRial).html()}</td></tr>"
    }
    val body = """
        <table>
          <tr><th>درآمد</th><td>${formatMoney(profitLoss.revenueRial).html()}</td><th>هزینه</th><td>${formatMoney(profitLoss.expenseRial).html()}</td></tr>
          <tr class="total"><th>سود/زیان خالص</th><td colspan="3">${formatMoney(profitLoss.netProfitRial).html()}</td></tr>
        </table>
        <h2>تراز آزمایشی</h2>
        <table><tr><th>کد</th><th>حساب</th><th>مانده بدهکار</th><th>مانده بستانکار</th></tr>$rows
        <tr class="total"><td colspan="2">جمع</td><td>${formatMoney(trial.totalDebitBalanceRial).html()}</td><td>${formatMoney(trial.totalCreditBalanceRial).html()}</td></tr></table>
    """.trimIndent()
    printHtml(context, "گزارش حسابداری", htmlDocument(context, "سود و زیان و تراز آزمایشی", body))
}

fun printAssetRegister(context: Context, assets: List<AssetRecord>) {
    val rows = assets.joinToString("") {
        "<tr><td>${it.assetCode.html()}</td><td>${it.name.html()}</td><td>${it.category.html()}</td><td>${it.quantity}</td><td>${formatMoney(it.purchaseCostRial).html()}</td><td>${formatMoney(it.bookValueRial).html()}</td><td>${if (it.isActive) "فعال" else "خارج‌شده"}</td></tr>"
    }
    val body = "<table><tr><th>کد</th><th>دارایی</th><th>دسته</th><th>تعداد</th><th>بهای خرید</th><th>ارزش دفتری</th><th>وضعیت</th></tr>$rows</table>"
    printHtml(context, "دفتر دارایی‌ها", htmlDocument(context, "دفتر دارایی‌های ثابت", body))
}

fun printInventoryRegister(context: Context, items: List<InventoryItemRecord>) {
    val rows = items.joinToString("") {
        "<tr><td>${it.name.html()}</td><td>${it.category.html()}</td><td>${formatQuantity(it.stockMicros)} ${it.unit.html()}</td><td>${formatMoney(it.inventoryValueRial).html()}</td><td>${if (it.alertEnabled) formatQuantity(it.alertThresholdMicros) else "—"}</td></tr>"
    }
    val body = "<table><tr><th>کالا</th><th>دسته</th><th>موجودی</th><th>ارزش</th><th>حد هشدار</th></tr>$rows</table>"
    printHtml(context, "گزارش موجودی", htmlDocument(context, "دفتر موجودی انبار", body))
}

fun printRecipeSheet(context: Context, item: MenuItem, ingredients: List<RecipeIngredientItem>) {
    val rows = ingredients.joinToString("") {
        "<tr><td>${it.inventoryName.html()}</td><td>${formatQuantity(it.quantityMicrosPerUnit)}</td><td>${it.unit.html()}</td></tr>"
    }
    val body = """
        <div class="meta">دسته: ${item.category.ifBlank { "بدون دسته‌بندی" }.html()} · قیمت فروش: ${formatMoney(item.salePriceRial).html()}</div>
        <table><tr><th>ماده اولیه</th><th>مقدار برای یک واحد</th><th>واحد</th></tr>$rows</table>
    """.trimIndent()
    printHtml(context, "رسپی ${item.name}", htmlDocument(context, "برگه رسپی ${item.name}", body))
}

fun printManagementSummary(
    context: Context,
    netProfitRial: Long,
    liquidityRial: Long,
    salesRial: Long,
    grossProfitRial: Long,
    receivablesRial: Long,
    inventoryRial: Long,
    lowStockCount: Int,
    overdueCount: Int,
) {
    val body = """
        <table>
          <tr><th>سود خالص</th><td>${formatMoney(netProfitRial).html()}</td><th>نقدینگی</th><td>${formatMoney(liquidityRial).html()}</td></tr>
          <tr><th>فروش</th><td>${formatMoney(salesRial).html()}</td><th>سود ناخالص</th><td>${formatMoney(grossProfitRial).html()}</td></tr>
          <tr><th>مطالبات</th><td>${formatMoney(receivablesRial).html()}</td><th>ارزش انبار</th><td>${formatMoney(inventoryRial).html()}</td></tr>
          <tr><th>کالای کم‌موجود</th><td>$lowStockCount</td><th>تسویه سررسیدشده</th><td>$overdueCount</td></tr>
        </table>
    """.trimIndent()
    printHtml(context, "گزارش مدیریتی", htmlDocument(context, "خلاصه گزارش مدیریتی", body))
}

fun printSalesReport(context: Context, report: SalesReport) {
    val channels = report.topChannels.joinToString("") { "<tr><td>${it.first.html()}</td><td>${formatMoney(it.second).html()}</td></tr>" }
    val body = """
        <div class="meta">از ${epochDayToPersian(report.fromEpochDay).display()} تا ${epochDayToPersian(report.toEpochDay).display()}</div>
        <table>
          <tr><th>تعداد فاکتور</th><td>${report.invoiceCount}</td></tr>
          <tr><th>فروش</th><td>${formatMoney(report.salesRial).html()}</td></tr>
          <tr><th>بهای تمام‌شده</th><td>${formatMoney(report.costOfGoodsRial).html()}</td></tr>
          <tr class="total"><th>سود ناخالص</th><td>${formatMoney(report.grossProfitRial).html()}</td></tr>
          <tr><th>مطالبات</th><td>${formatMoney(report.receivablesRial).html()}</td></tr>
        </table>
        ${if (channels.isBlank()) "" else "<h2>کانال‌های فروش</h2><table><tr><th>کانال</th><th>مبلغ</th></tr>$channels</table>"}
    """.trimIndent()
    printHtml(context, "گزارش فروش", htmlDocument(context, "گزارش فروش", body))
}
