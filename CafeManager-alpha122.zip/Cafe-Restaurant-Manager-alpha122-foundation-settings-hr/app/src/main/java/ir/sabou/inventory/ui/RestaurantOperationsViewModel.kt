package ir.sabou.inventory.ui

import androidx.lifecycle.*
import ir.sabou.inventory.domain.operations.*
import ir.sabou.inventory.domain.sales.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class RestaurantOperationsUiState(val tables:List<RestaurantTable> = emptyList(),val reservations:List<Reservation> = emptyList(),val tickets:List<KitchenTicket> = emptyList(),val shifts:List<PlannedShift> = emptyList(),val approvals:List<ApprovalRequest> = emptyList(),val message:String?=null)

class RestaurantOperationsViewModel(private val repository:RestaurantOperationsRepository):ViewModel(){
    private val message=MutableStateFlow<String?>(null)
    private val content=combine(repository.tables,repository.reservations,repository.kitchenTickets,repository.shifts,repository.approvals){ tables,reservations,tickets,shifts,approvals->RestaurantOperationsUiState(tables,reservations,tickets,shifts,approvals) }
    val state=combine(content,message){ value,text->value.copy(message=text)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),RestaurantOperationsUiState())
    private fun run(success:String,block:suspend()->Unit)=viewModelScope.launch{message.value=runCatching{block();success}.getOrElse{it.message?:"عملیات انجام نشد."}}
    fun addTable(label:String,capacity:Int,zone:String)=run("میز ثبت شد."){repository.addTable(label,capacity,zone)}
    fun transitionTable(id:Long,status:TableStatus,orderId:Long?=null)=run("وضعیت میز تغییر کرد."){repository.transitionTable(id,status,orderId)}
    fun addReservation(value:Reservation)=run("رزرو ثبت شد."){repository.addReservation(value)}
    fun addTicket(orderNo:String,station:String,item:String,quantity:Int,priority:Int)=run("سفارش آشپزخانه ثبت شد."){repository.addKitchenTicket(orderNo,station,item,quantity,priority)}
    fun transitionTicket(id:Long,status:KitchenTicketStatus)=run("وضعیت سفارش تغییر کرد."){repository.transitionKitchenTicket(id,status)}
    fun planShift(demand:ShiftDemand,staff:List<StaffAvailability>)=run("شیفت برنامه‌ریزی شد."){repository.planShift(demand,staff)}
    fun requestApproval(type:String,entityId:Long,amount:Long,by:String)=run("درخواست تأیید ثبت شد."){repository.requestApproval(type,entityId,amount,by)}
    fun review(id:Long,approve:Boolean,by:String,note:String="")=run("درخواست بررسی شد."){repository.reviewApproval(id,approve,by,note)}
    fun clearMessage(){message.value=null}
    companion object{fun factory(repository:RestaurantOperationsRepository)=object:ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST") override fun<T:ViewModel>create(modelClass:Class<T>):T=RestaurantOperationsViewModel(repository) as T}}
}
