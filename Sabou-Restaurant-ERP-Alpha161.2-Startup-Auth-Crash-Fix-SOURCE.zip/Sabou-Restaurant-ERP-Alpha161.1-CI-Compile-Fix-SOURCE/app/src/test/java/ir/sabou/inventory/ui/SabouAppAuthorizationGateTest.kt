package ir.sabou.inventory.ui

import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.security.UserRole
import kotlin.test.Test
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class SabouAppAuthorizationGateTest {
    @Test
    fun payrollFlowIsNotObservedBeforeAuthentication() {
        assertFalse(canObserveHrPayroll(null))
    }

    @Test
    fun payrollFlowIsNotObservedForRoleWithoutPayrollPermission() {
        assertFalse(canObserveHrPayroll(user(role = UserRole.CASHIER)))
    }

    @Test
    fun payrollFlowIsObservedOnlyForActiveAuthorizedUser() {
        assertTrue(canObserveHrPayroll(user(role = UserRole.MANAGER)))
        assertFalse(canObserveHrPayroll(user(role = UserRole.MANAGER, isActive = false)))
    }

    private fun user(role: UserRole, isActive: Boolean = true) = AppUserRecord(
        id = 1L,
        username = "test-user",
        displayName = "Test User",
        role = role,
        isActive = isActive,
        hasRecoveryCode = false,
    )
}
