package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

data class PersonnelUiState(val employees: List<EmployeeRecord> = emptyList(), val payrolls: List<PayrollRecord> = emptyList(), val message: String? = null)

class PersonnelViewModel(private val repository: PersonnelRepository) : ViewModel() {
    private val message = MutableStateFlow<String?>(null)
    val state: StateFlow<PersonnelUiState> = combine(repository.employees, repository.payrolls, message) { e, p, m -> PersonnelUiState(e,p,m) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PersonnelUiState())

    fun saveEmployee(id: Long?, draft: EmployeeDraft) = launch("پرسنل ذخیره شد.") { repository.saveEmployee(id, draft) }
    fun deactivate(id: Long) = launch("پرسنل غیرفعال شد.") { repository.deactivateEmployee(id) }
    fun postPayroll(draft: PayrollDraft) = launch("حقوق ثبت و سند حسابداری صادر شد.") { repository.postPayroll(draft) }
    fun clearMessage() { message.value = null }
    private fun launch(success: String, block: suspend () -> Unit) = viewModelScope.launch {
        runCatching { block() }.onSuccess { message.value = success }.onFailure { message.value = it.message ?: "خطا" }
    }
    companion object { fun factory(repo: PersonnelRepository) = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = PersonnelViewModel(repo) as T
    } }
}
