package ir.sabou.inventory.domain.personnel

import kotlinx.coroutines.flow.Flow

data class EmployeeRecord(
    val id: Long,
    val name: String,
    val jobTitle: String,
    val phone: String,
    val monthlySalaryRial: Long,
    val isActive: Boolean,
)

data class EmployeeDraft(
    val name: String,
    val jobTitle: String,
    val phone: String,
    val monthlySalaryRial: Long,
) {
    fun validated(): EmployeeDraft {
        require(name.trim().length >= 2) { "نام پرسنل معتبر نیست." }
        require(jobTitle.trim().isNotEmpty()) { "عنوان شغلی الزامی است." }
        require(monthlySalaryRial >= 0) { "حقوق پایه نمی‌تواند منفی باشد." }
        return copy(name = name.trim(), jobTitle = jobTitle.trim(), phone = phone.trim())
    }
}

data class PayrollDraft(
    val employeeId: Long,
    val periodYear: Int,
    val periodMonth: Int,
    val overtimeRial: Long,
    val bonusRial: Long,
    val deductionsRial: Long,
    val insuranceRial: Long,
    val taxRial: Long,
    val paymentEpochDay: Long,
    val paymentMethod: String,
    val notes: String,
) {
    fun validated(): PayrollDraft {
        require(employeeId > 0) { "پرسنل انتخاب نشده است." }
        require(periodYear in 1300..1600) { "سال دوره معتبر نیست." }
        require(periodMonth in 1..12) { "ماه دوره معتبر نیست." }
        require(listOf(overtimeRial, bonusRial, deductionsRial, insuranceRial, taxRial).all { it >= 0 }) {
            "مبالغ حقوق نمی‌توانند منفی باشند."
        }
        require(paymentMethod in setOf("CASH", "BANK")) { "روش پرداخت معتبر نیست." }
        return copy(notes = notes.trim())
    }
}

data class PayrollRecord(
    val id: Long,
    val employeeName: String,
    val periodYear: Int,
    val periodMonth: Int,
    val grossPayRial: Long,
    val netPayRial: Long,
    val paymentEpochDay: Long,
    val paymentMethod: String,
    val status: String,
)

interface PersonnelRepository {
    val employees: Flow<List<EmployeeRecord>>
    val payrolls: Flow<List<PayrollRecord>>
    suspend fun saveEmployee(id: Long?, draft: EmployeeDraft): Long
    suspend fun deactivateEmployee(id: Long)
    suspend fun postPayroll(draft: PayrollDraft): Long
}
