package ir.sabou.inventory.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val SabouLightColors = lightColorScheme(
    primary = Color(0xFF165D50),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD4F3E9),
    onPrimaryContainer = Color(0xFF082F28),
    secondary = Color(0xFF8A5B17),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFE8C1),
    onSecondaryContainer = Color(0xFF3D2900),
    tertiary = Color(0xFF4D6177),
    tertiaryContainer = Color(0xFFD5E5FA),
    background = Color(0xFFF6F7F4),
    onBackground = Color(0xFF191C1B),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF191C1B),
    surfaceVariant = Color(0xFFE9EEEB),
    onSurfaceVariant = Color(0xFF5C6561),
    outline = Color(0xFF7B8580),
    outlineVariant = Color(0xFFD7DEDA),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
)

private val SabouDarkColors = darkColorScheme(
    primary = Color(0xFF9BD8C8),
    onPrimary = Color(0xFF00382F),
    primaryContainer = Color(0xFF005143),
    onPrimaryContainer = Color(0xFFB7F4E4),
    secondary = Color(0xFFF6C66F),
    onSecondary = Color(0xFF492F00),
    secondaryContainer = Color(0xFF674600),
    onSecondaryContainer = Color(0xFFFFDEA5),
    background = Color(0xFF101412),
    onBackground = Color(0xFFE1E4E1),
    surface = Color(0xFF171B19),
    onSurface = Color(0xFFE1E4E1),
    surfaceVariant = Color(0xFF3F4945),
    onSurfaceVariant = Color(0xFFBFC9C4),
    outlineVariant = Color(0xFF3F4945),
)

private val SabouTypography = Typography(
    headlineMedium = TextStyle(fontSize = 27.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 29.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 26.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
)

@Composable
fun SabouTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colors = if (darkTheme) SabouDarkColors else SabouLightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.primary.toArgb()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.navigationBarColor = colors.background.toArgb()
            }
        }
    }
    MaterialTheme(
        colorScheme = colors,
        typography = SabouTypography,
        content = content,
    )
}
