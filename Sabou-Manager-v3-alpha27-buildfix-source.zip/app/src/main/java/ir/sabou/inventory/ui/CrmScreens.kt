@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun CrmScreen(state: CrmState, onAdjustPoints: (Long,Long,String)->Unit, onAddFollowUp:(Long,String,Long,String)->Unit, onComplete:(Long)->Unit, onBack:()->Unit) {
    var selected by remember { mutableStateOf<Long?>(null) }
    var points by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var due by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    val selectedCustomer = state.customers.firstOrNull { it.id == selected }
    val openFollowUps = state.followUps.count { !it.isDone }

    Scaffold(topBar = { ProfessionalTopBar("باشگاه مشتریان", "وفاداری، ارزش مشتری و پیگیری ارتباطات", onBack) }) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            state.message?.let { message -> item { StatusPill(message) } }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricTile("تعداد مشتری", state.customers.size.toString(), Modifier.weight(1f))
                    MetricTile("پیگیری باز", openFollowUps.toString(), Modifier.weight(1f))
                }
            }
            item { SectionHeading("مشتریان ارزشمند", "برای مدیریت امتیاز و پیگیری، یک مشتری را انتخاب کنید") }
            if (state.customers.isEmpty()) item { EmptyStatePanel("هنوز مشتری ندارید", "با ثبت اولین فروش، پروفایل مشتری در این بخش نمایش داده می‌شود.") }
            items(state.customers, key = { it.id }) { c ->
                ElevatedCard(
                    onClick = { selected = if (selected == c.id) null else c.id },
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.elevatedCardColors(containerColor = if (selected == c.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface),
                ) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
                                if (c.phone.isNotBlank()) Text(c.phone, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill("${c.points} امتیاز")
                        }
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("ارزش خرید کل", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatMoney(c.lifetimeValueRial), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            selectedCustomer?.let { customer ->
                item {
                    ElevatedCard(shape = RoundedCornerShape(24.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            SectionHeading("اقدامات برای ${customer.name}", "تغییر امتیاز یا ایجاد پیگیری جدید")
                            OutlinedTextField(points, { points = it }, label = { Text("تغییر امتیاز") }, supportingText = { Text("برای کسر امتیاز عدد منفی وارد کنید") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(reason, { reason = it }, label = { Text("دلیل تغییر") }, modifier = Modifier.fillMaxWidth())
                            Button(onClick = { points.toLongOrNull()?.let { onAdjustPoints(customer.id, it, reason); points = ""; reason = "" } }, modifier = Modifier.fillMaxWidth()) { Text("ثبت تغییر امتیاز") }
                            HorizontalDivider(Modifier.padding(vertical = 4.dp))
                            Text("پیگیری جدید", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            OutlinedTextField(title, { title = it }, label = { Text("عنوان پیگیری") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(due, { due = it }, label = { Text("روز سررسید") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(notes, { notes = it }, label = { Text("یادداشت") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                            FilledTonalButton(onClick = { due.toLongOrNull()?.let { onAddFollowUp(customer.id, title, it, notes); title = ""; due = ""; notes = "" } }, modifier = Modifier.fillMaxWidth()) { Text("ثبت پیگیری") }
                        }
                    }
                }
            }
            item { SectionHeading("پیگیری‌های ارتباطی", "کارهای باز در ابتدای فهرست قرار دارند") }
            if (state.followUps.isEmpty()) item { EmptyStatePanel("پیگیری فعالی نیست", "برای تماس، یادآوری یا ارائه پیشنهاد، یک پیگیری بسازید.") }
            items(state.followUps.sortedBy { it.isDone }, key = { it.id }) { f ->
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = if (f.isDone) MaterialTheme.colorScheme.surfaceContainerLow else MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(f.title, fontWeight = FontWeight.Bold)
                                Text(f.customerName, style = MaterialTheme.typography.bodySmall)
                            }
                            StatusPill(if (f.isDone) "انجام‌شده" else "باز")
                        }
                        Text("سررسید: ${epochDayToPersian(f.dueEpochDay).display()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (f.notes.isNotBlank()) Text(f.notes)
                        if (!f.isDone) FilledTonalButton(onClick = { onComplete(f.id) }, modifier = Modifier.align(Alignment.End)) { Text("علامت‌گذاری انجام‌شده") }
                    }
                }
            }
        }
    }
}
