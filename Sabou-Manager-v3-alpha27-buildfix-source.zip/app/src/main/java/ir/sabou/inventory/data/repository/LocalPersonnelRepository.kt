package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.EmployeeEntity
import ir.sabou.inventory.data.db.JournalEntryEntity
import ir.sabou.inventory.data.db.JournalLineEntity
import ir.sabou.inventory.data.db.PayrollRunEntity
import ir.sabou.inventory.domain.personnel.EmployeeDraft
import ir.sabou.inventory.domain.personnel.EmployeeRecord
import ir.sabou.inventory.domain.personnel.PayrollDraft
import ir.sabou.inventory.domain.personnel.PayrollRecord
import ir.sabou.inventory.domain.personnel.PersonnelRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalPersonnelRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) : PersonnelRepository {
    private val personnel get() = database.personnelDao()
    private val accounting get() = database.accountingDao()

    override val employees: Flow<List<EmployeeRecord>> = personnel.observeEmployees().map { rows ->
        rows.map { EmployeeRecord(it.id, it.name, it.jobTitle, it.phone, it.monthlySalaryRial, it.status == "ACTIVE") }
    }

    override val payrolls: Flow<List<PayrollRecord>> = personnel.observePayrolls().map { rows ->
        rows.map { PayrollRecord(it.id, it.employeeName, it.periodYear, it.periodMonth, it.grossPayRial, it.netPayRial, it.paymentEpochDay, it.paymentMethod, it.status) }
    }

    override suspend fun saveEmployee(id: Long?, draft: EmployeeDraft): Long {
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            if (id == null) {
                personnel.insertEmployee(EmployeeEntity(name = valid.name, jobTitle = valid.jobTitle, phone = valid.phone,
                    monthlySalaryRial = valid.monthlySalaryRial, leaveBalanceMicros = 0, createdAtEpochMillis = now, updatedAtEpochMillis = now))
            } else {
                val current = personnel.employeeById(id) ?: error("پرسنل پیدا نشد.")
                check(personnel.updateEmployee(current.copy(name=valid.name, jobTitle=valid.jobTitle, phone=valid.phone,
                    monthlySalaryRial=valid.monthlySalaryRial, status="ACTIVE", updatedAtEpochMillis=now)) == 1)
                id
            }
        }
    }

    override suspend fun deactivateEmployee(id: Long) {
        check(personnel.deactivateEmployee(id, clock()) == 1) { "غیرفعال‌کردن پرسنل انجام نشد." }
    }

    override suspend fun postPayroll(draft: PayrollDraft): Long {
        val valid = draft.validated()
        return database.withTransaction {
            val employee = personnel.employeeById(valid.employeeId) ?: error("پرسنل پیدا نشد.")
            require(employee.status == "ACTIVE") { "پرسنل غیرفعال است." }
            require(!personnel.payrollExists(employee.id, valid.periodYear, valid.periodMonth)) { "حقوق این دوره قبلاً ثبت شده است." }
            val gross = SignedLongMath.add(SignedLongMath.add(employee.monthlySalaryRial, valid.overtimeRial), valid.bonusRial)
            val totalDeduction = SignedLongMath.add(SignedLongMath.add(valid.deductionsRial, valid.insuranceRial), valid.taxRial)
            val net = SignedLongMath.subtract(gross, totalDeduction)
            require(net >= 0) { "خالص پرداخت نمی‌تواند منفی باشد." }
            val tempNo = "TMP-PAY-${clock()}"
            val entryId = accounting.insertEntry(JournalEntryEntity(entryNo=tempNo, entryEpochDay=valid.paymentEpochDay,
                description="حقوق ${employee.name} ${valid.periodYear}/${valid.periodMonth}", sourceType="PAYROLL", sourceId=0,
                createdAtEpochMillis=clock()))
            check(accounting.finalizeEntryIdentity(entryId, "ح-$entryId", entryId) == 1)
            val cashAccount = if (valid.paymentMethod == "CASH") "1101" else "1102"
            accounting.insertLines(listOf(
                JournalLineEntity(entryId=entryId, accountCode="6101", debitRial=gross, creditRial=0, memo="حقوق و مزایا"),
                JournalLineEntity(entryId=entryId, accountCode=cashAccount, debitRial=0, creditRial=net, memo="خالص پرداخت"),
                JournalLineEntity(entryId=entryId, accountCode="2104", debitRial=0, creditRial=valid.insuranceRial, memo="بیمه پرداختنی"),
                JournalLineEntity(entryId=entryId, accountCode="2103", debitRial=0, creditRial=valid.taxRial, memo="مالیات پرداختنی"),
                JournalLineEntity(entryId=entryId, accountCode="2102", debitRial=0, creditRial=valid.deductionsRial, memo="سایر کسورات"),
            ).filter { it.debitRial != 0L || it.creditRial != 0L })
            personnel.insertPayroll(PayrollRunEntity(employeeId=employee.id, periodYear=valid.periodYear, periodMonth=valid.periodMonth,
                baseSalaryRial=employee.monthlySalaryRial, overtimeRial=valid.overtimeRial, bonusRial=valid.bonusRial,
                deductionsRial=valid.deductionsRial, insuranceRial=valid.insuranceRial, taxRial=valid.taxRial, netPayRial=net,
                paymentEpochDay=valid.paymentEpochDay, paymentMethod=valid.paymentMethod, journalEntryId=entryId,
                notes=valid.notes, createdAtEpochMillis=clock()))
        }
    }
}
