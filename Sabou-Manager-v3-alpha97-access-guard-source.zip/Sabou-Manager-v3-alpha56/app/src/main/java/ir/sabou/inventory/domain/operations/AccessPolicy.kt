package ir.sabou.inventory.domain.operations

enum class UserRole { OWNER, MANAGER, CASHIER, KITCHEN, INVENTORY }
enum class Permission { VIEW_REPORTS, POST_SALE, POST_PURCHASE, MANAGE_USERS, MANAGE_INVENTORY }

object AccessPolicy {
    fun allows(role: UserRole, permission: Permission): Boolean = when (role) {
        UserRole.OWNER -> true
        UserRole.MANAGER -> permission != Permission.MANAGE_USERS
        UserRole.CASHIER -> permission == Permission.POST_SALE
        UserRole.KITCHEN -> false
        UserRole.INVENTORY -> permission == Permission.MANAGE_INVENTORY
    }
}
