package ir.sabou.inventory.data.repository

import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.SyncChangeEntity

/** Records local mutations in the durable outbox in the same Room transaction. */
class SyncRecorder(private val database: AppDatabase, private val deviceId: String = "local") {
    suspend fun record(entityType: String, entityId: Long, changeType: String, occurredAt: Long) {
        val changeId = "$deviceId:$entityType:$entityId:$occurredAt"
        database.syncDao().insert(
            SyncChangeEntity(
                changeId = changeId,
                entityType = entityType,
                entityId = entityId,
                changeType = changeType,
                deviceId = deviceId,
                occurredAtEpochMillis = occurredAt,
                payloadHash = "local-${entityType.lowercase()}-$entityId",
            ),
        )
    }
}
