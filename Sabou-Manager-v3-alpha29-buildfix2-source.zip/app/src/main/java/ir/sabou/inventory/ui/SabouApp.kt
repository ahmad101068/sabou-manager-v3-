package ir.sabou.inventory.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.data.repository.DashboardSnapshot
import ir.sabou.inventory.domain.operations.AppUserRecord

enum class AppScreen {
    DASHBOARD,
    PURCHASES,
    NEW_PURCHASE,
    SUPPLIERS,
    INVENTORY,
    SALES,
    RECIPES,
    ACCOUNTING,
    NEW_JOURNAL,
    AUDIT_LOG,
    SECURITY,
    PERSONNEL,
    ASSETS,
    CRM,
    ALERTS,
    REPORTS,
    GLOBAL_SEARCH,
    SETTINGS,
}

private data class ModuleCard(val title: String, val screen: AppScreen?, val permission: String? = null)

private val modules = listOf(
    ModuleCard("خرید و فاکتورها", AppScreen.PURCHASES, "PURCHASES"),
    ModuleCard("تأمین‌کنندگان", AppScreen.SUPPLIERS, "SUPPLIERS"),
    ModuleCard("انبار و هشدار موجودی", AppScreen.INVENTORY, "INVENTORY"),
    ModuleCard("رسپی و بهای تمام‌شده", AppScreen.RECIPES, "RECIPES"),
    ModuleCard("فروش و مشتریان", AppScreen.SALES, "SALES"),
    ModuleCard("باشگاه مشتریان و CRM", AppScreen.CRM, "SALES"),
    ModuleCard("مرکز هشدارها", AppScreen.ALERTS, null),
    ModuleCard("حسابداری", AppScreen.ACCOUNTING, "ACCOUNTING"),
    ModuleCard("پرسنل و حقوق", AppScreen.PERSONNEL, "PERSONNEL"),
    ModuleCard("دارایی‌های رستوران", AppScreen.ASSETS, "ASSETS"),
    ModuleCard("گزارش و چاپ", AppScreen.REPORTS, "ACCOUNTING"),
    ModuleCard("لاگ عملیات و حسابرسی", AppScreen.AUDIT_LOG, "AUDIT"),
    ModuleCard("کاربران و پشتیبان", AppScreen.SECURITY, "BACKUP"),
)

@Composable
fun SabouApp(
    container: AppContainer,
    themePreference: ThemePreference,
    onThemePreferenceChange: (ThemePreference) -> Unit,
) {
    val dashboard: DashboardViewModel = viewModel(
        factory = DashboardViewModel.factory(container.dashboardRepository),
    )
    val operations: OperationsViewModel = viewModel(
        factory = OperationsViewModel.factory(
            container.operationsRepository,
            container.purchaseRepository,
        ),
    )
    val accounting: AccountingViewModel = viewModel(
        factory = AccountingViewModel.factory(container.accountingRepository),
    )
    val sales: SalesViewModel = viewModel(
        factory = SalesViewModel.factory(container.salesRepository, container.recipeRepository),
    )
    val recipes: RecipeViewModel = viewModel(
        factory = RecipeViewModel.factory(container.recipeRepository, container.operationsRepository),
    )
    val personnel: PersonnelViewModel = viewModel(factory = PersonnelViewModel.factory(container.personnelRepository))
    val assets: AssetViewModel = viewModel(factory = AssetViewModel.factory(container.assetRepository))
    val crm: CrmViewModel = viewModel(factory = CrmViewModel.factory(container.crmRepository))
    val alerts: AlertViewModel = viewModel(factory = AlertViewModel.factory(container.alertRepository))
    val security: SecurityViewModel = viewModel(
        factory = SecurityViewModel.factory(container.securityRepository, container),
    )
    val dashboardState by dashboard.state.collectAsState()
    val operationsState by operations.state.collectAsState()
    val accountingState by accounting.state.collectAsState()
    val salesState by sales.state.collectAsState()
    val recipeState by recipes.state.collectAsState()
    val alertState by alerts.state.collectAsState()
    val securityState by security.state.collectAsState()
    val personnelState by personnel.state.collectAsState()
    val assetState by assets.state.collectAsState()
    val crmState by crm.state.collectAsState()
    var screen by remember { mutableStateOf(AppScreen.DASHBOARD) }

    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
        when (screen) {
            AppScreen.DASHBOARD -> DashboardScreen(
                state = dashboardState,
                operationsState = operationsState,
                currentUser = securityState.currentUser,
                onSearch = { screen = AppScreen.GLOBAL_SEARCH },
                onSettings = { screen = AppScreen.SETTINGS },
                onOpen = { target ->
                    if (target != null) screen = target
                    else operations.clearMessage()
                },
            )

            AppScreen.PURCHASES -> PurchasesScreen(
                state = operationsState,
                onSearch = operations::searchPurchases,
                onSelect = operations::selectPurchase,
                onSettle = operations::settlePurchase,
                onReverseSettlement = operations::reversePurchaseSettlement,
                onReverse = operations::reversePurchase,
                onAdd = { screen = AppScreen.NEW_PURCHASE },
                onBack = {
                    operations.selectPurchase(null)
                    screen = AppScreen.DASHBOARD
                },
            )

            AppScreen.NEW_PURCHASE -> PurchaseEntryScreen(
                state = operationsState,
                onPost = operations::postPurchase,
                onBack = { screen = AppScreen.PURCHASES },
            )

            AppScreen.SUPPLIERS -> SuppliersScreen(
                state = operationsState,
                onSave = operations::saveSupplier,
                onDeactivate = operations::deactivateSupplier,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.INVENTORY -> InventoryScreen(
                state = operationsState,
                onSave = operations::saveInventoryItem,
                onDeactivate = operations::deactivateInventoryItem,
                onCount = operations::postInventoryCount,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SALES -> SalesScreen(
                state = salesState,
                onSearch = sales::search,
                onSelect = sales::selectSale,
                onAddCustomer = sales::addCustomer,
                onPostSale = sales::postSale,
                onReceive = sales::receive,
                onReverse = sales::reverse,
                onReverseSale = sales::reverseSale,
                onReplaceSale = sales::replaceSale,
                onSetReportRange = sales::setReportRange,
                onBack = { sales.selectSale(null); screen = AppScreen.DASHBOARD },
            )

            AppScreen.RECIPES -> RecipeScreen(
                state = recipeState,
                onSelect = recipes::select,
                onSave = recipes::save,
                onBack = { recipes.select(null); screen = AppScreen.DASHBOARD },
            )

            AppScreen.ACCOUNTING -> AccountingScreen(
                state = accountingState,
                onSearch = accounting::searchJournals,
                onSelectJournal = accounting::selectJournal,
                onSelectLedger = accounting::selectLedger,
                onSaveAccount = accounting::saveAccount,
                onDeactivateAccount = accounting::deactivateAccount,
                onReverse = accounting::reverseManual,
                onAddJournal = { screen = AppScreen.NEW_JOURNAL },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.AUDIT_LOG -> AuditLogScreen(state = operationsState, onBack = { screen = AppScreen.DASHBOARD })

            AppScreen.PERSONNEL -> PersonnelScreen(
                state = personnelState,
                onSaveEmployee = personnel::saveEmployee,
                onDeactivate = personnel::deactivate,
                onPostPayroll = personnel::postPayroll,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SECURITY -> SecurityScreen(
                state = securityState,
                onSave = security::save,
                onDeactivate = security::deactivate,
                onSwitch = security::switchUser,
                onBackup = security::createBackup,
                onRestore = security::restore,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.ASSETS -> AssetScreen(
                state = assetState,
                onSave = assets::save,
                onDispose = assets::dispose,
                onDepreciate = assets::depreciate,
                onBack = { screen = AppScreen.DASHBOARD },
            )


            AppScreen.CRM -> CrmScreen(
                state = crmState,
                onAdjustPoints = crm::adjustPoints,
                onAddFollowUp = crm::addFollowUp,
                onComplete = crm::complete,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.ALERTS -> AlertCenterScreen(
                state = alertState,
                onRefresh = alerts::refresh,
                onRead = alerts::markRead,
                onDismiss = alerts::dismiss,
                onClearDismissed = alerts::clearDismissed,
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.REPORTS -> ReportsCenterScreen(
                dashboard = dashboardState,
                sales = salesState,
                accounting = accountingState,
                operations = operationsState,
                onOpenSales = { screen = AppScreen.SALES },
                onOpenAccounting = { screen = AppScreen.ACCOUNTING },
                onOpenInventory = { screen = AppScreen.INVENTORY },
                onBack = { screen = AppScreen.DASHBOARD },
            )


            AppScreen.GLOBAL_SEARCH -> GlobalSearchScreen(
                currentUser = securityState.currentUser,
                onOpen = { screen = it },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.SETTINGS -> SettingsScreen(
                themePreference = themePreference,
                onThemePreferenceChange = onThemePreferenceChange,
                onOpenSecurity = { screen = AppScreen.SECURITY },
                onBack = { screen = AppScreen.DASHBOARD },
            )

            AppScreen.NEW_JOURNAL -> ManualJournalEntryScreen(
                state = accountingState,
                onPost = accounting::postManual,
                onBack = { screen = AppScreen.ACCOUNTING },
            )
        }
    }
}

@Composable
private fun DashboardScreen(
    state: DashboardSnapshot,
    operationsState: OperationsUiState,
    currentUser: AppUserRecord?,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onOpen: (AppScreen?) -> Unit,
) {
    val visibleModules = modules.filter {
        it.permission == null || currentUser?.role?.allows(it.permission) == true
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item {
                DashboardHero(
                    userName = currentUser?.displayName ?: "کاربر سابو",
                    roleTitle = currentUser?.role?.title.orEmpty(),
                    lowStockCount = operationsState.lowStockItems.size,
                    settlementCount = operationsState.settlementAlerts.size,
                    onInventory = { onOpen(AppScreen.INVENTORY) },
                    onPurchases = { onOpen(AppScreen.PURCHASES) },
                    onSearch = onSearch,
                    onSettings = onSettings,
                )
            }

            item {
                SectionHeader(
                    title = "نمای کلی کسب‌وکار",
                    subtitle = "وضعیت مالی و موجودی در یک نگاه",
                )
                Spacer(Modifier.height(12.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp),
                ) {
                    item { MetricCard("ارزش موجودی", formatMoney(state.inventoryValueRial), "انبار", "◆") }
                    item { MetricCard("مانده صندوق", formatMoney(state.cashBalanceRial), "نقد", "●") }
                    item { MetricCard("مانده بانک", formatMoney(state.bankBalanceRial), "حساب‌ها", "▰") }
                    item { MetricCard("بدهی تأمین‌کنندگان", formatMoney(state.supplierPayablesRial), "پرداختنی", "↙") }
                }
            }

            item {
                SectionHeader(
                    title = "عملیات سریع",
                    subtitle = "کارهای پرتکرار را بدون جست‌وجو انجام دهید",
                )
                Spacer(Modifier.height(12.dp))
                Row(
                    modifier = Modifier.padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    QuickAction("ثبت خرید", "+", Modifier.weight(1f)) { onOpen(AppScreen.NEW_PURCHASE) }
                    QuickAction("فروش", "↗", Modifier.weight(1f)) { onOpen(AppScreen.SALES) }
                    QuickAction("کالا", "□", Modifier.weight(1f)) { onOpen(AppScreen.INVENTORY) }
                    QuickAction("مشتری", "◎", Modifier.weight(1f)) { onOpen(AppScreen.CRM) }
                }
            }

            item {
                SectionHeader(
                    title = "بخش‌های مدیریت",
                    subtitle = "همه ابزارهای سابو، مرتب و در دسترس",
                )
            }

            items(visibleModules.chunked(2)) { rowModules ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    rowModules.forEach { module ->
                        ModuleTile(
                            module = module,
                            modifier = Modifier.weight(1f),
                            onClick = { onOpen(module.screen) },
                        )
                    }
                    if (rowModules.size == 1) Spacer(Modifier.weight(1f))
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun DashboardHero(
    userName: String,
    roleTitle: String,
    lowStockCount: Int,
    settlementCount: Int,
    onInventory: () -> Unit,
    onPurchases: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = 20.dp, vertical = 24.dp),
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.14f))
                        .border(1.dp, MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.22f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("س", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "سلام، $userName",
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        roleTitle.ifBlank { "مدیریت مجموعه" },
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        modifier = Modifier.clickable(onClick = onSearch),
                        shape = RoundedCornerShape(999.dp),
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.12f),
                    ) {
                        Text("جست‌وجو", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                    Surface(
                        modifier = Modifier.clickable(onClick = onSettings),
                        shape = RoundedCornerShape(999.dp),
                        color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.12f),
                    ) {
                        Text("تنظیمات", modifier = Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Text(
                "امروز چه چیزی در کسب‌وکارت نیاز به توجه دارد؟",
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.88f),
                style = MaterialTheme.typography.bodyLarge,
            )

            if (lowStockCount == 0 && settlementCount == 0) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.10f),
                ) {
                    Text(
                        "همه‌چیز مرتب است؛ هشدار فوری ندارید.",
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (lowStockCount > 0) {
                        AlertPill("$lowStockCount کمبود موجودی", Modifier.weight(1f), onInventory)
                    }
                    if (settlementCount > 0) {
                        AlertPill("$settlementCount تسویه سررسید", Modifier.weight(1f), onPurchases)
                    }
                }
            }
        }
    }
}

@Composable
private fun AlertPill(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.onPrimary,
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(Modifier.padding(horizontal = 18.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Text(
            subtitle,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@Composable
private fun MetricCard(title: String, value: String, label: String, symbol: String) {
    Card(
        modifier = Modifier.width(220.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.65f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                ) {
                    Text(
                        symbol,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun QuickAction(title: String, symbol: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(symbol, color = MaterialTheme.colorScheme.onSecondaryContainer, fontWeight = FontWeight.Black)
            Text(
                title,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun ModuleTile(module: ModuleCard, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val enabled = module.screen != null
    Card(
        modifier = modifier
            .height(108.dp)
            .clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant,
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = if (enabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
            ) {
                Text(
                    if (enabled) "●" else "—",
                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                    color = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
            Column {
                Text(module.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (!enabled) {
                    Text("به‌زودی", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
