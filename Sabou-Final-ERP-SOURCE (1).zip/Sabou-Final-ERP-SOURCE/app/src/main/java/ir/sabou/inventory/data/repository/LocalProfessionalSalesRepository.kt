package ir.sabou.inventory.data.repository

import ir.sabou.inventory.core.toLongExactCompat
import androidx.room.withTransaction
import ir.sabou.inventory.core.GlobalId
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.SignedLongMath
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.CustomerEntity
import ir.sabou.inventory.data.db.CustomerReceivableLedgerEntity
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.ProfessionalSalesDayClosureEntity
import ir.sabou.inventory.data.db.SalesConsumptionSnapshotEntity
import ir.sabou.inventory.data.db.SalesHoldEntity
import ir.sabou.inventory.data.db.SalesHoldLineEntity
import ir.sabou.inventory.data.db.SalesInvoiceEntity
import ir.sabou.inventory.data.db.SalesInvoiceLineEntity
import ir.sabou.inventory.data.db.SalesPaymentEntity
import ir.sabou.inventory.data.db.SalesReturnEntity
import ir.sabou.inventory.data.db.SalesReturnLineEntity
import ir.sabou.inventory.data.security.SessionAuthorizer
import ir.sabou.inventory.domain.accounting.AccountingPostingContext
import ir.sabou.inventory.domain.accounting.AccountingReversalCommand
import ir.sabou.inventory.domain.accounting.SemanticAccountRole
import ir.sabou.inventory.domain.accounting.SemanticJournalDraft
import ir.sabou.inventory.domain.accounting.SemanticJournalLine
import ir.sabou.inventory.domain.common.BusinessError
import ir.sabou.inventory.domain.common.DocumentNumberType
import ir.sabou.inventory.domain.common.asViolation
import ir.sabou.inventory.domain.inventory.InventoryCommandContext
import ir.sabou.inventory.domain.inventory.InventoryMovementType
import ir.sabou.inventory.domain.inventory.InventoryReasonCode
import ir.sabou.inventory.domain.inventory.InventoryReferenceType
import ir.sabou.inventory.domain.sales.CustomerDraft
import ir.sabou.inventory.domain.sales.CustomerRecord
import ir.sabou.inventory.domain.sales.PostedSalesInvoice
import ir.sabou.inventory.domain.sales.PostedSalesReturn
import ir.sabou.inventory.domain.sales.ProfessionalSalesDayClosureRecord
import ir.sabou.inventory.domain.sales.ProfessionalSalesRepository
import ir.sabou.inventory.domain.sales.SalesCalculator
import ir.sabou.inventory.domain.sales.SalesHoldDraft
import ir.sabou.inventory.domain.sales.SalesDashboardSummary
import ir.sabou.inventory.domain.sales.SalesHoldRecord
import ir.sabou.inventory.domain.sales.SalesInvoiceDetails
import ir.sabou.inventory.domain.sales.SalesInvoiceDraft
import ir.sabou.inventory.domain.sales.SalesInvoiceLineRecord
import ir.sabou.inventory.domain.sales.SalesInvoiceRecord
import ir.sabou.inventory.domain.sales.SalesInvoiceStatus
import ir.sabou.inventory.domain.sales.SalesLineDraft
import ir.sabou.inventory.domain.sales.SalesPaymentDraft
import ir.sabou.inventory.domain.sales.SalesPaymentMethod
import ir.sabou.inventory.domain.sales.SalesPaymentRecord
import ir.sabou.inventory.domain.sales.SalesReturnDraft
import ir.sabou.inventory.domain.security.Permission
import java.math.BigInteger
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/**
 * Alpha161 authoritative POS command boundary.
 *
 * Invoice + immutable recipe/cost snapshots + inventory issue + accounting + audit/outbox commit in
 * one Room transaction. Returns and voids are compensating documents; posted financial facts are
 * never edited in place.
 */
class LocalProfessionalSalesRepository(
    private val database: AppDatabase,
    private val authorizer: SessionAuthorizer,
    private val syncRecorder: SyncRecorder? = null,
    private val clock: () -> Long = System::currentTimeMillis,
) : ProfessionalSalesRepository {
    private val recipeCostSnapshots = SalesRecipeCostSnapshotService(database)
    private val inventory = LocalInventoryCommandEngine(database, clock)
    private val accounting = LocalAccountingPostingEngine(database, clock = clock)
    private val audit = LocalAuditEventWriter(database)
    private val numbering = LocalDocumentNumberAllocator(database, clock)
    private val customerMaster = SalesCustomerMasterService(database, authorizer, syncRecorder, clock)

    override val customers: Flow<List<CustomerRecord>> = database.salesDao().observeCustomers().map { rows ->
        rows.map { row ->
            CustomerRecord(
                id = row.id,
                customerCode = row.customerCode,
                name = row.name,
                phone = row.phone,
                nationalId = row.nationalId,
                creditLimitRial = row.creditLimitRial,
                outstandingRial = row.outstandingRial,
                notes = row.notes,
                isActive = row.isActive,
                mobile = row.mobile,
                address = row.address,
                branch = row.branch,
                paymentTermsDays = row.paymentTermsDays,
                status = row.status,
            )
        }
    }

    override val holds: Flow<List<SalesHoldRecord>> = database.salesDao().observeHolds().map { rows ->
        rows.map { row ->
            SalesHoldRecord(row.id, row.holdNo, row.customerName, row.notes, row.lineCount, row.grossRial, row.createdAtEpochMillis)
        }
    }

    override val dayClosures: Flow<List<ProfessionalSalesDayClosureRecord>> =
        database.salesDao().observePosDayClosures().map { rows ->
            rows.map { row ->
                ProfessionalSalesDayClosureRecord(
                    row.businessEpochDay, row.netSalesRial, row.cogsRial, row.cashRial, row.cardRial,
                    row.transferRial, row.creditRial, row.invoiceCount, row.returnCount, row.status,
                    row.revisionNo, row.closedByName, row.note, row.reopenReason,
                )
            }
        }

    override fun observeInvoices(query: String): Flow<List<SalesInvoiceRecord>> =
        database.salesDao().observeInvoices(query.trim()).map { rows -> rows.map { it.toRecord() } }

    override fun observeRecentInvoices(limit: Int): Flow<List<SalesInvoiceRecord>> {
        require(limit in 1..20) { "تعداد فاکتورهای اخیر معتبر نیست." }
        return database.salesDao().observeRecentInvoices(limit).map { rows -> rows.map { it.toRecord() } }
    }

    override fun observeDashboardSummary(
        fromEpochDay: Long,
        toEpochDay: Long,
        createdFromEpochMillis: Long,
        createdToEpochMillisExclusive: Long,
    ): Flow<SalesDashboardSummary> {
        require(fromEpochDay > 0 && toEpochDay >= fromEpochDay) { "بازه داشبورد فروش معتبر نیست." }
        require(createdFromEpochMillis >= 0 && createdToEpochMillisExclusive > createdFromEpochMillis) { "بازه زمانی مشتریان معتبر نیست." }
        return database.salesDao().observeDashboardSummary(
            fromEpochDay,
            toEpochDay,
            createdFromEpochMillis,
            createdToEpochMillisExclusive,
        ).map { row ->
            SalesDashboardSummary(
                netSalesRial = row.netSalesRial,
                invoiceNetRial = row.invoiceNetRial,
                invoiceCount = row.invoiceCount,
                returnRial = row.returnRial,
                newCustomerCount = row.newCustomerCount,
                customerReceivablesRial = row.customerReceivablesRial,
                heldSaleCount = row.heldSaleCount,
            )
        }
    }

    override fun observeDetails(invoiceId: Long): Flow<SalesInvoiceDetails?> = combine(
        database.salesDao().observeInvoiceHeader(invoiceId),
        database.salesDao().observeInvoiceLines(invoiceId),
        database.salesDao().observePayments(invoiceId),
    ) { header, lines, payments ->
        header?.let { h ->
            SalesInvoiceDetails(
                invoice = SalesInvoiceRecord(
                    id = h.id,
                    invoiceNo = h.invoiceNo,
                    businessEpochDay = h.businessEpochDay,
                    customerName = h.customerName,
                    grossRial = h.grossRial,
                    discountRial = h.discountRial,
                    serviceRial = h.serviceRial,
                    taxRial = h.taxRial,
                    netRial = h.netRial,
                    theoreticalCostRial = h.theoreticalCostRial,
                    status = SalesInvoiceStatus.fromStoredValue(h.status),
                    notes = h.notes,
                    createdAtEpochMillis = h.createdAtEpochMillis,
                ),
                customerId = h.customerId,
                dueEpochDay = h.dueEpochDay,
                lines = lines.map { row ->
                    SalesInvoiceLineRecord(
                        id = row.id,
                        menuItemId = row.menuItemId,
                        recipeVersionId = row.recipeVersionId,
                        name = row.menuItemNameSnapshot,
                        quantityMicros = row.quantityMicros,
                        unitPriceRial = row.unitPriceRial,
                        grossRial = row.grossRial,
                        discountRial = row.discountRial,
                        serviceRial = row.serviceRial,
                        taxRial = row.taxRial,
                        netRial = row.netRial,
                        theoreticalCostRial = row.theoreticalCostRial,
                        returnedQuantityMicros = row.returnedQuantityMicros,
                    )
                },
                payments = payments.map { payment ->
                    SalesPaymentRecord(payment.method.toPaymentMethod(), payment.amountRial, payment.referenceNo)
                },
            )
        }
    }

    override suspend fun saveCustomer(id: Long?, draft: CustomerDraft): Long =
        customerMaster.save(id, draft)

    override suspend fun deactivateCustomer(id: Long) {
        customerMaster.deactivate(id)
    }

    override suspend fun post(draft: SalesInvoiceDraft): PostedSalesInvoice {
        val actor = authorizer.require(Permission.SALES)
        val calculated = SalesCalculator.prepare(draft)
        return database.withTransaction {
            val dao = database.salesDao()
            dao.invoiceByCommandId(calculated.draft.commandId)?.let { existing ->
                ensureInvoiceReplayMatches(existing, calculated)
                return@withTransaction PostedSalesInvoice(existing.id, existing.invoiceNo, existing.netRial, existing.theoreticalCostRial, true)
            }
            require(!database.dailySalesDao().dayClosed(calculated.draft.businessEpochDay) && !dao.posDayClosed(calculated.draft.businessEpochDay)) { "روز فروش بسته است و ثبت فاکتور جدید مجاز نیست." }
            require(database.dailySalesDao().activeSummaryByDay(calculated.draft.businessEpochDay) == null) {
                "برای این روز ثبت تجمیعی فروش قدیمی وجود دارد؛ قبل از استفاده از POS آن سند باید از مسیر کنترل‌شده برگشت داده شود."
            }
            val customer = calculated.draft.customerId?.let { id ->
                dao.activeCustomerById(id) ?: throw BusinessError.EntityNotFound("ACTIVE_CUSTOMER", id).asViolation()
            }
            val creditRial = calculated.draft.payments.filter { it.method == SalesPaymentMethod.CREDIT }
                .fold(0L) { total, payment -> SignedLongMath.add(total, payment.amount.value) }
            var creditOverrideReason: String? = null
            if (creditRial > 0) {
                requireNotNull(customer) { "فروش اعتباری نیازمند مشتری فعال است." }
                require(customer.status == "ACTIVE") { "وضعیت مشتری اجازه فروش اعتباری نمی‌دهد." }
                val outstanding = database.customerReceivableDao().balanceRial(customer.id)
                val projected = SignedLongMath.add(outstanding, creditRial)
                if (customer.creditLimitRial <= 0 || projected > customer.creditLimitRial) {
                    authorizer.require(Permission.CREDIT_OVERRIDE)
                    val reason = calculated.draft.creditOverrideReason.trim()
                    require(reason.length in 3..300) { "عبور از سقف اعتبار نیازمند مجوز و دلیل است." }
                    creditOverrideReason = reason
                }
            }

            val preparedLines = recipeCostSnapshots.prepare(calculated)
            val aggregatedConsumption = preparedLines.flatMap { it.consumptions }.groupBy { it.item.id }.map { (_, rows) ->
                val item = rows.first().item
                val quantity = exactSum(rows.map { it.quantityMicros })
                val value = exactSum(rows.map { it.valueRial })
                require(item.stockMicros >= quantity) { "موجودی ${item.name} برای این فروش کافی نیست." }
                AggregateConsumption(item, quantity, value)
            }
            val totalCogs = exactSum(preparedLines.map { it.rawCogsRial })
            val now = clock()
            val invoiceNo = numbering.next(DocumentNumberType.SALES_INVOICE)
            val invoiceId = dao.insertInvoice(
                SalesInvoiceEntity(
                    invoiceNo = invoiceNo,
                    commandId = calculated.draft.commandId,
                    businessEpochDay = calculated.draft.businessEpochDay,
                    branchName = calculated.draft.branchName,
                    customerId = calculated.draft.customerId,
                    dueEpochDay = calculated.draft.dueEpochDay,
                    grossRial = calculated.grossRial,
                    discountRial = calculated.discountRial,
                    serviceRial = calculated.serviceRial,
                    taxRial = calculated.taxRial,
                    netRial = calculated.netRial,
                    creditRial = creditRial,
                    theoreticalCostRial = totalCogs,
                    journalEntryId = null,
                    cogsJournalEntryId = null,
                    status = SalesInvoiceStatus.POSTED.storedValue,
                    notes = calculated.draft.notes,
                    createdByActorId = actor.id,
                    createdAtEpochMillis = now,
                ),
            )
            if (creditRial > 0 && calculated.draft.customerId != null) {
                database.customerReceivableDao().insertLedger(
                    CustomerReceivableLedgerEntity(
                        customerId = calculated.draft.customerId, businessEpochDay = calculated.draft.businessEpochDay, entryType = "SALE",
                        debitRial = creditRial, creditRial = 0, sourceType = "SALES_INVOICE", sourceId = invoiceId, reference = invoiceNo,
                        dueEpochDay = calculated.draft.dueEpochDay, actorId = actor.id, createdAtEpochMillis = now,
                    ),
                )
                creditOverrideReason?.let { reason ->
                    audit.appendAuthorized(authorizer, "CREDIT_OVERRIDE", "SALES_INVOICE", invoiceId, "عبور کنترل‌شده از سقف اعتبار مشتری", now, calculated.draft.businessEpochDay, reason, afterSnapshot = "customerId=${calculated.draft.customerId};creditRial=$creditRial", correlationId = "sales_invoice:$invoiceId:credit_override")
                }
            }

            preparedLines.forEach { line ->
                val lineId = dao.insertInvoiceLine(
                    SalesInvoiceLineEntity(
                        invoiceId = invoiceId,
                        menuItemId = line.financial.menuItemId,
                        recipeVersionId = line.recipeVersionId,
                        menuItemNameSnapshot = line.menuName,
                        quantityMicros = line.financial.quantityMicros,
                        unitPriceRial = line.financial.unitPriceRial,
                        grossRial = line.financial.grossRial,
                        discountRial = line.financial.discountRial,
                        serviceRial = line.financial.serviceRial,
                        taxRial = line.financial.taxRial,
                        netRial = line.financial.netRial,
                        theoreticalCostRial = line.rawCogsRial,
                        foodCostSnapshotRial = line.foodCostRial,
                        packagingCostSnapshotRial = line.packagingRial,
                        directLaborCostSnapshotRial = line.laborRial,
                        allocatedOverheadSnapshotRial = line.overheadRial,
                    ),
                )
                dao.insertConsumptionSnapshots(
                    line.consumptions.map { consumption ->
                        SalesConsumptionSnapshotEntity(
                            invoiceLineId = lineId,
                            inventoryItemId = consumption.item.id,
                            inventoryItemNameSnapshot = consumption.item.name,
                            quantityMicros = consumption.quantityMicros,
                            valueRial = consumption.valueRial,
                        )
                    },
                )
            }
            dao.insertPayments(calculated.draft.payments.map { payment ->
                SalesPaymentEntity(
                    invoiceId = invoiceId,
                    method = payment.method.name,
                    amountRial = payment.amount.value,
                    referenceNo = payment.referenceNo,
                )
            })

            aggregatedConsumption.forEach { row ->
                inventory.issue(
                    itemId = row.item.id,
                    quantityMicros = row.quantityMicros,
                    valueRial = row.valueRial,
                    movementType = InventoryMovementType.SALES_INVOICE_CONSUMPTION,
                    referenceType = InventoryReferenceType.SALES_INVOICE,
                    referenceId = invoiceId,
                    movementEpochDay = calculated.draft.businessEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.SALES_INVOICE,
                        referenceId = invoiceId,
                        suffix = "consume:${row.item.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.SALES_CONSUMPTION,
                        reason = "مصرف رسپی فاکتور $invoiceNo",
                        correlationId = "sales_invoice:$invoiceId",
                    ),
                    notes = "مصرف رسپی $invoiceNo",
                    lotPolicy = LocalInventoryCommandEngine.LotIssuePolicy.FEFO_ALL,
                )
            }

            val journalId = accounting.post(
                draft = SemanticJournalDraft(
                    entryNo = "ف-$invoiceNo",
                    entryEpochDay = calculated.draft.businessEpochDay,
                    description = "فروش $invoiceNo",
                    sourceType = "SALES_INVOICE",
                    sourceId = invoiceId,
                    lines = revenueJournalLines(calculated.draft.payments, calculated.productRevenueRial, calculated.serviceRial, calculated.taxRial),
                ),
                context = AccountingPostingContext.local(
                    sourceType = "SALES_INVOICE",
                    sourceId = invoiceId,
                    suffix = "revenue",
                    actorId = actor.id,
                    correlationId = "sales_invoice:$invoiceId",
                ),
            )
            val cogsJournalId = if (totalCogs > 0) {
                accounting.post(
                    draft = SemanticJournalDraft(
                        entryNo = "بف-$invoiceNo",
                        entryEpochDay = calculated.draft.businessEpochDay,
                        description = "بهای تمام‌شده $invoiceNo",
                        sourceType = "SALES_INVOICE_COGS",
                        sourceId = invoiceId,
                        lines = listOf(
                            SemanticJournalLine(SemanticAccountRole.COGS, debit = MoneyRial.of(totalCogs)),
                            SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, credit = MoneyRial.of(totalCogs)),
                        ),
                    ),
                    context = AccountingPostingContext.local(
                        sourceType = "SALES_INVOICE_COGS",
                        sourceId = invoiceId,
                        suffix = "cogs",
                        actorId = actor.id,
                        correlationId = "sales_invoice:$invoiceId",
                    ),
                )
            } else null
            check(dao.linkInvoiceJournals(invoiceId, journalId, cogsJournalId) == 1) { "اتصال سند حسابداری فروش انجام نشد." }
            syncRecorder?.record("SALES_INVOICE", invoiceId, "POST", now, recordAudit = false)
            audit.appendAuthorized(
                authorizer, "POST", "SALES_INVOICE", invoiceId,
                "ثبت $invoiceNo؛ خالص=${calculated.netRial}؛ بهای تمام‌شده=$totalCogs",
                now,
                businessEpochDay = calculated.draft.businessEpochDay,
                reason = "POS_SALE_POSTED",
                afterSnapshot = "status=POSTED;netRial=${calculated.netRial};cogsRial=$totalCogs;journal=$journalId",
                correlationId = "sales_invoice:$invoiceId",
            )
            PostedSalesInvoice(invoiceId, invoiceNo, calculated.netRial, totalCogs, false)
        }
    }

    override suspend fun returnSale(draft: SalesReturnDraft): PostedSalesReturn {
        val actor = authorizer.require(Permission.SALES_RETURN)
        val valid = draft.validated()
        return database.withTransaction {
            val dao = database.salesDao()
            dao.returnByCommandId(valid.commandId)?.let { existing ->
                ensureReturnReplayMatches(existing, valid)
                return@withTransaction PostedSalesReturn(existing.id, existing.returnNo, existing.refundRial, true)
            }
            val invoice = dao.invoiceById(valid.invoiceId) ?: throw BusinessError.EntityNotFound("SALES_INVOICE", valid.invoiceId).asViolation()
            require(invoice.status == SalesInvoiceStatus.POSTED.storedValue || invoice.status == SalesInvoiceStatus.PARTIALLY_RETURNED.storedValue) {
                "فاکتور در وضعیت قابل مرجوعی نیست."
            }
            require(valid.returnEpochDay >= invoice.businessEpochDay) { "تاریخ مرجوعی نمی‌تواند قبل از فروش باشد." }
            require(!database.dailySalesDao().dayClosed(valid.returnEpochDay)) { "روز انتخاب‌شده برای مرجوعی بسته است." }

            val sourceLines = dao.invoiceLines(invoice.id).associateBy { it.id }
            val prior = dao.returnedTotals(invoice.id).associateBy { it.invoiceLineId }
            data class ReturnComputation(
                val source: SalesInvoiceLineEntity,
                val quantity: Long,
                val gross: Long,
                val discount: Long,
                val service: Long,
                val tax: Long,
                val net: Long,
                val cogs: Long,
                val consumptionDeltas: List<ConsumptionDelta>,
            )
            val computed = valid.lines.map { request ->
                val source = sourceLines[request.invoiceLineId] ?: error("ردیف مرجوعی متعلق به این فاکتور نیست.")
                val already = prior[source.id]?.quantityMicros ?: 0L
                val nextReturned = SignedLongMath.add(already, request.quantity.value)
                require(nextReturned <= source.quantityMicros) { "مقدار مرجوعی «${source.menuItemNameSnapshot}» از مانده قابل برگشت بیشتر است." }
                val gross = allocationDelta(source.grossRial, source.quantityMicros, already, nextReturned)
                val discount = allocationDelta(source.discountRial, source.quantityMicros, already, nextReturned)
                val service = allocationDelta(source.serviceRial, source.quantityMicros, already, nextReturned)
                val tax = allocationDelta(source.taxRial, source.quantityMicros, already, nextReturned)
                val net = allocationDelta(source.netRial, source.quantityMicros, already, nextReturned)
                val consumptionDeltas = dao.consumptionSnapshots(source.id).map { snapshot ->
                    ConsumptionDelta(
                        itemId = snapshot.inventoryItemId,
                        quantityMicros = allocationDelta(snapshot.quantityMicros, source.quantityMicros, already, nextReturned),
                        valueRial = allocationDelta(snapshot.valueRial, source.quantityMicros, already, nextReturned),
                    )
                }.filter { it.quantityMicros > 0 }
                val cogs = exactSum(consumptionDeltas.map { it.valueRial })
                ReturnComputation(source, request.quantity.value, gross, discount, service, tax, net, cogs, consumptionDeltas)
            }
            val refund = exactSum(computed.map { it.net })
            require(refund > 0) { "مبلغ مرجوعی باید بیشتر از صفر باشد." }
            if (valid.refundMethod == SalesPaymentMethod.CREDIT) {
                require(invoice.customerId != null) { "مرجوعی اعتباری فقط برای فاکتور دارای مشتری مجاز است." }
                val paidCredit = invoice.creditRial
                val alreadyCreditRefunded = dao.creditRefundedRial(invoice.id)
                require(SignedLongMath.add(alreadyCreditRefunded, refund) <= paidCredit) {
                    "مبلغ برگشت اعتباری از مانده اعتبار همان فاکتور بیشتر است."
                }
            }
            val returnNo = numbering.next(DocumentNumberType.SALES_RETURN)
            val now = clock()
            val returnId = dao.insertReturn(
                SalesReturnEntity(
                    returnNo = returnNo,
                    commandId = valid.commandId,
                    invoiceId = invoice.id,
                    returnEpochDay = valid.returnEpochDay,
                    refundMethod = valid.refundMethod.name,
                    grossRial = exactSum(computed.map { it.gross }),
                    discountRial = exactSum(computed.map { it.discount }),
                    serviceRial = exactSum(computed.map { it.service }),
                    taxRial = exactSum(computed.map { it.tax }),
                    refundRial = refund,
                    cogsRial = exactSum(computed.map { it.cogs }),
                    reason = valid.reason,
                    journalEntryId = null,
                    cogsJournalEntryId = null,
                    createdByActorId = actor.id,
                    createdAtEpochMillis = now,
                ),
            )
            dao.insertReturnLines(computed.map { row ->
                SalesReturnLineEntity(
                    returnId = returnId,
                    invoiceLineId = row.source.id,
                    quantityMicros = row.quantity,
                    grossRial = row.gross,
                    discountRial = row.discount,
                    serviceRial = row.service,
                    taxRial = row.tax,
                    netRial = row.net,
                    cogsRial = row.cogs,
                )
            })

            val saleMovements = database.stockMovementDao().professionalSalesConsumptions(invoice.id).associateBy { it.itemId }
            val aggregateReturns = computed.flatMap { it.consumptionDeltas }.groupBy { it.itemId }.map { (itemId, rows) ->
                Triple(itemId, exactSum(rows.map { it.quantityMicros }), exactSum(rows.map { it.valueRial }))
            }
            aggregateReturns.forEach { (itemId, quantity, value) ->
                val sourceMovement = saleMovements[itemId] ?: error("گردش مصرف اصلی فروش برای کالای $itemId پیدا نشد.")
                inventory.receive(
                    itemId = itemId,
                    quantityMicros = quantity,
                    valueRial = value,
                    movementType = InventoryMovementType.SALES_RETURN,
                    referenceType = InventoryReferenceType.SALES_RETURN,
                    referenceId = returnId,
                    movementEpochDay = valid.returnEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.SALES_RETURN,
                        referenceId = returnId,
                        suffix = "restore:$itemId",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.SALES_REVERSAL,
                        reason = "مرجوعی $returnNo از ${invoice.invoiceNo}",
                        correlationId = "sales_return:$returnId",
                        locationId = sourceMovement.locationId,
                    ),
                    notes = "بازگشت موجودی $returnNo",
                    enforceLotPolicy = false,
                )
                inventory.restoreTrackedLotQuantity(sourceMovement.id, quantity)
            }

            val productRevenueReturn = SignedLongMath.subtract(exactSum(computed.map { it.gross }), exactSum(computed.map { it.discount }))
            val serviceReturn = exactSum(computed.map { it.service })
            val taxReturn = exactSum(computed.map { it.tax })
            val journalLines = buildList {
                if (productRevenueReturn > 0) add(SemanticJournalLine(SemanticAccountRole.SALES_REVENUE, debit = MoneyRial.of(productRevenueReturn)))
                if (serviceReturn > 0) add(SemanticJournalLine(SemanticAccountRole.SERVICE_REVENUE, debit = MoneyRial.of(serviceReturn)))
                if (taxReturn > 0) add(SemanticJournalLine(SemanticAccountRole.TAX_PAYABLE, debit = MoneyRial.of(taxReturn)))
                add(SemanticJournalLine(valid.refundMethod.accountRole, credit = MoneyRial.of(refund), memo = valid.refundMethod.title))
            }
            val journalId = accounting.post(
                SemanticJournalDraft("برگ-$returnNo", "مرجوعی $returnNo از ${invoice.invoiceNo}", valid.returnEpochDay, "SALES_RETURN", returnId, lines = journalLines),
                AccountingPostingContext.local("SALES_RETURN", returnId, "revenue", actor.id, "sales_return:$returnId"),
            )
            val cogs = exactSum(computed.map { it.cogs })
            val cogsJournalId = if (cogs > 0) accounting.post(
                SemanticJournalDraft(
                    "ببرگ-$returnNo", "برگشت بهای تمام‌شده $returnNo", valid.returnEpochDay, "SALES_RETURN_COGS", returnId,
                    lines = listOf(
                        SemanticJournalLine(SemanticAccountRole.INVENTORY_ASSET, debit = MoneyRial.of(cogs)),
                        SemanticJournalLine(SemanticAccountRole.COGS, credit = MoneyRial.of(cogs)),
                    ),
                ),
                AccountingPostingContext.local("SALES_RETURN_COGS", returnId, "cogs", actor.id, "sales_return:$returnId"),
            ) else null
            check(dao.linkReturnJournals(returnId, journalId, cogsJournalId) == 1) { "اتصال سند مرجوعی انجام نشد." }

            if (valid.refundMethod == SalesPaymentMethod.CREDIT && invoice.customerId != null) {
                database.customerReceivableDao().insertLedger(
                    CustomerReceivableLedgerEntity(
                        customerId = invoice.customerId, businessEpochDay = valid.returnEpochDay, entryType = "RETURN", debitRial = 0, creditRial = refund,
                        sourceType = "SALES_RETURN", sourceId = returnId, reference = returnNo, actorId = actor.id, createdAtEpochMillis = now,
                    ),
                )
            }

            val afterTotals = dao.returnedTotals(invoice.id)
            val allReturned = sourceLines.values.all { source ->
                afterTotals.firstOrNull { it.invoiceLineId == source.id }?.quantityMicros == source.quantityMicros
            }
            check(dao.updateReturnStatus(invoice.id, if (allReturned) SalesInvoiceStatus.RETURNED.storedValue else SalesInvoiceStatus.PARTIALLY_RETURNED.storedValue) == 1) {
                "وضعیت فاکتور پس از مرجوعی به‌روزرسانی نشد."
            }
            syncRecorder?.record("SALES_RETURN", returnId, "POST", now, recordAudit = false)
            audit.appendAuthorized(
                authorizer, "RETURN", "SALES_INVOICE", invoice.id,
                "مرجوعی $returnNo از ${invoice.invoiceNo}؛ مبلغ=$refund؛ دلیل=${valid.reason}", now,
                businessEpochDay = valid.returnEpochDay,
                reason = valid.reason,
                afterSnapshot = "returnId=$returnId;refundRial=$refund;cogsRial=$cogs",
                correlationId = "sales_return:$returnId",
            )
            PostedSalesReturn(returnId, returnNo, refund, false)
        }
    }

    override suspend fun voidInvoice(invoiceId: Long, voidEpochDay: Long, reason: String, commandId: String) {
        val actor = authorizer.require(Permission.SALES_VOID)
        val normalizedCommandId = GlobalId.parse(commandId).value
        val normalizedReason = reason.trim()
        require(invoiceId > 0 && voidEpochDay > 0 && normalizedReason.length in 3..300) { "اطلاعات ابطال کامل نیست." }
        database.withTransaction {
            val dao = database.salesDao()
            dao.invoiceByVoidCommandId(normalizedCommandId)?.let { existing ->
                if (existing.id != invoiceId || existing.voidedAtEpochDay != voidEpochDay || existing.voidReason != normalizedReason) {
                    throw BusinessError.IdempotencyConflict("SALES_VOID:$normalizedCommandId").asViolation()
                }
                return@withTransaction
            }
            val invoice = dao.invoiceById(invoiceId) ?: throw BusinessError.EntityNotFound("SALES_INVOICE", invoiceId).asViolation()
            require(invoice.status == SalesInvoiceStatus.POSTED.storedValue) { "فقط فاکتور ثبت‌شده بدون مرجوعی قابل ابطال است." }
            require(dao.returnCount(invoice.id) == 0L) { "فاکتور دارای مرجوعی است؛ ابطال مستقیم مجاز نیست." }
            require(voidEpochDay >= invoice.businessEpochDay) { "تاریخ ابطال نمی‌تواند قبل از فروش باشد." }
            require(!database.dailySalesDao().dayClosed(invoice.businessEpochDay) && !dao.posDayClosed(invoice.businessEpochDay)) { "روز اصلی فروش بسته است؛ از مسیر مرجوعی در روز باز استفاده کنید." }
            require(!database.dailySalesDao().dayClosed(voidEpochDay) && !dao.posDayClosed(voidEpochDay)) { "روز ابطال بسته است." }
            val revenueJournal = requireNotNull(invoice.journalEntryId) { "سند درآمد فاکتور ناقص است." }
            val revenueReversal = accounting.reverse(
                AccountingReversalCommand(
                    originalEntryId = revenueJournal,
                    entryNo = "ابط-${invoice.invoiceNo}",
                    sourceType = "SALES_VOID",
                    sourceId = invoice.id,
                    businessEpochDay = voidEpochDay,
                    reason = normalizedReason,
                    idempotencyKey = "SALES_VOID:${invoice.id}:$normalizedCommandId:revenue",
                    correlationId = ir.sabou.inventory.core.CorrelationId.parse("sales_void:$normalizedCommandId"),
                    actorId = actor.id,
                ),
            )
            val cogsReversal = invoice.cogsJournalEntryId?.let { original ->
                accounting.reverse(
                    AccountingReversalCommand(
                        originalEntryId = original,
                        entryNo = "بابط-${invoice.invoiceNo}",
                        sourceType = "SALES_VOID_COGS",
                        sourceId = invoice.id,
                        businessEpochDay = voidEpochDay,
                        reason = normalizedReason,
                        idempotencyKey = "SALES_VOID:${invoice.id}:$normalizedCommandId:cogs",
                        correlationId = ir.sabou.inventory.core.CorrelationId.parse("sales_void:$normalizedCommandId"),
                        actorId = actor.id,
                    ),
                )
            }
            database.stockMovementDao().professionalSalesConsumptions(invoice.id).forEach { movement ->
                inventory.restoreIssuedMovement(
                    movement = movement,
                    reversalMovementType = InventoryMovementType.SALES_VOID,
                    reversalEpochDay = voidEpochDay,
                    context = InventoryCommandContext.local(
                        referenceType = InventoryReferenceType.SALES_VOID,
                        referenceId = invoice.id,
                        suffix = "restore:${movement.id}",
                        actorId = actor.id,
                        reasonCode = InventoryReasonCode.SALES_REVERSAL,
                        reason = normalizedReason,
                        correlationId = "sales_void:$normalizedCommandId",
                        locationId = movement.locationId,
                    ),
                    notes = "ابطال ${invoice.invoiceNo}: $normalizedReason",
                )
            }
            check(dao.markVoided(invoice.id, voidEpochDay, normalizedCommandId, normalizedReason, revenueReversal.entryId, cogsReversal?.entryId) == 1) {
                "ثبت وضعیت ابطال فاکتور انجام نشد."
            }
            val now = clock()
            if (invoice.creditRial > 0 && invoice.customerId != null) {
                database.customerReceivableDao().insertLedger(
                    CustomerReceivableLedgerEntity(
                        customerId = invoice.customerId, businessEpochDay = voidEpochDay, entryType = "REVERSAL", debitRial = 0, creditRial = invoice.creditRial,
                        sourceType = "SALES_VOID", sourceId = invoice.id, reference = invoice.invoiceNo, actorId = actor.id, createdAtEpochMillis = now,
                    ),
                )
            }
            syncRecorder?.record("SALES_INVOICE", invoice.id, "VOID", now, recordAudit = false)
            audit.appendAuthorized(
                authorizer, "VOID", "SALES_INVOICE", invoice.id,
                "ابطال ${invoice.invoiceNo}: $normalizedReason", now,
                businessEpochDay = voidEpochDay, reason = normalizedReason,
                beforeSnapshot = "status=POSTED;netRial=${invoice.netRial}",
                afterSnapshot = "status=VOIDED;reversalJournal=${revenueReversal.entryId}",
                correlationId = "sales_void:$normalizedCommandId",
            )
        }
    }

    override suspend fun closeDay(businessEpochDay: Long, note: String) {
        authorizer.require(Permission.SALES_DAY_CLOSE)
        require(businessEpochDay > 0) { "تاریخ بستن روز معتبر نیست." }
        require(note.trim().length <= 300) { "توضیحات بستن روز بیش از حد طولانی است." }
        database.withTransaction {
            val dao = database.salesDao()
            require(!database.dailySalesDao().dayClosed(businessEpochDay)) { "این روز از مسیر قدیمی بسته شده است." }
            require(!dao.posDayClosed(businessEpochDay)) { "این روز قبلاً بسته شده است." }
            val totals = dao.dayTotals(businessEpochDay)
            require(totals.invoiceCount > 0 || totals.returnCount > 0) { "برای این روز فروش یا مرجوعی POS ثبت نشده است." }
            val actor = authorizer.actorIdentity()
            val previous = dao.posDayClosure(businessEpochDay)
            val now = clock()
            val entity = ProfessionalSalesDayClosureEntity(
                businessEpochDay = businessEpochDay,
                grossSalesRial = totals.grossSalesRial,
                netSalesRial = totals.netSalesRial,
                returnRial = totals.returnRial,
                cogsRial = totals.cogsRial,
                cashRial = totals.cashRial,
                cardRial = totals.cardRial,
                transferRial = totals.transferRial,
                creditRial = totals.creditRial,
                invoiceCount = totals.invoiceCount.toInt(),
                returnCount = totals.returnCount.toInt(),
                status = "CLOSED",
                revisionNo = (previous?.revisionNo ?: 0) + 1,
                closedByActorId = actor.id,
                closedByName = actor.displayName,
                note = note.trim(),
                createdAtEpochMillis = now,
            )
            if (previous == null) dao.insertPosDayClosure(entity) else check(dao.updatePosDayClosure(entity) == 1) { "بستن مجدد روز انجام نشد." }
            audit.appendAuthorized(
                authorizer, "CLOSE", "SALES_POS_DAY", businessEpochDay,
                "بستن POS روز $businessEpochDay؛ خالص=${totals.netSalesRial}؛ فاکتور=${totals.invoiceCount}؛ مرجوعی=${totals.returnCount}", now,
                businessEpochDay = businessEpochDay, reason = note.trim().ifBlank { "پایان روز POS" },
                afterSnapshot = "status=CLOSED;revision=${entity.revisionNo};cash=${totals.cashRial};card=${totals.cardRial};transfer=${totals.transferRial};credit=${totals.creditRial}",
                correlationId = "sales_pos_day:$businessEpochDay:CLOSE:${entity.revisionNo}",
            )
            syncRecorder?.record("SALES_POS_DAY", businessEpochDay, "CLOSE", now, recordAudit = false)
        }
    }

    override suspend fun reopenDay(businessEpochDay: Long, reason: String) {
        authorizer.requireOwner()
        val normalized = reason.trim()
        require(businessEpochDay > 0 && normalized.length in 3..300) { "تاریخ یا دلیل بازگشایی معتبر نیست." }
        database.withTransaction {
            val dao = database.salesDao()
            val closure = dao.posDayClosure(businessEpochDay) ?: error("سند بستن روز POS پیدا نشد.")
            require(closure.status == "CLOSED") { "این روز در وضعیت بسته نیست." }
            val actor = authorizer.actorIdentity()
            val now = clock()
            check(dao.updatePosDayClosure(closure.copy(
                status = "REOPENED", reopenedByActorId = actor.id, reopenedByName = actor.displayName,
                reopenReason = normalized, reopenedAtEpochMillis = now,
            )) == 1) { "بازگشایی روز POS انجام نشد." }
            audit.appendAuthorized(
                authorizer, "REOPEN", "SALES_POS_DAY", businessEpochDay,
                "بازگشایی کنترل‌شده POS روز $businessEpochDay: $normalized", now,
                businessEpochDay = businessEpochDay, reason = normalized, beforeSnapshot = "status=CLOSED;revision=${closure.revisionNo}",
                afterSnapshot = "status=REOPENED", correlationId = "sales_pos_day:$businessEpochDay:REOPEN:${closure.revisionNo}",
            )
            syncRecorder?.record("SALES_POS_DAY", businessEpochDay, "REOPEN", now, recordAudit = false)
        }
    }

    override suspend fun auditInvoicePrint(invoiceId: Long) {
        authorizer.require(Permission.SALES)
        require(invoiceId > 0) { "فاکتور معتبر نیست." }
        database.withTransaction {
            val invoice = database.salesDao().invoiceById(invoiceId)
                ?: throw BusinessError.EntityNotFound("SALES_INVOICE", invoiceId).asViolation()
            val now = clock()
            audit.appendAuthorized(
                authorizer = authorizer,
                action = "REPRINT",
                entityType = "SALES_INVOICE",
                entityId = invoice.id,
                description = "چاپ/چاپ مجدد فاکتور ${invoice.invoiceNo}",
                occurredAtEpochMillis = now,
                businessEpochDay = invoice.businessEpochDay,
                reason = "PRINT",
                correlationId = "sales_print:${invoice.id}:$now",
            )
        }
    }

    override suspend fun hold(draft: SalesHoldDraft): Long {
        val actor = authorizer.require(Permission.SALES)
        val valid = draft.validated()
        return database.withTransaction {
            val dao = database.salesDao()
            dao.holdByCommandId(valid.commandId)?.let { existing ->
                val persisted = dao.holdLines(existing.id)
                val same = existing.customerId == valid.customerId && existing.orderDiscountRial == valid.orderDiscount.value &&
                    existing.serviceRial == valid.service.value && existing.taxRial == valid.tax.value && existing.notes == valid.notes && persisted.size == valid.lines.size &&
                    persisted.zip(valid.lines).all { (left, right) -> left.menuItemId == right.menuItemId && left.quantityMicros == right.quantity.value && left.unitPriceRial == right.unitPrice.value && left.lineDiscountRial == right.lineDiscount.value }
                if (!same) throw BusinessError.IdempotencyConflict("SALES_HOLD:${valid.commandId}").asViolation()
                return@withTransaction existing.id
            }
            valid.customerId?.let { dao.activeCustomerById(it) ?: throw BusinessError.EntityNotFound("ACTIVE_CUSTOMER", it).asViolation() }
            valid.lines.forEach { line ->
                database.recipeDao().activeMenuItem(line.menuItemId) ?: throw BusinessError.EntityNotFound("MENU_ITEM", line.menuItemId).asViolation()
                require(line.lineDiscount.value <= line.unitPrice.times(line.quantity).value) { "تخفیف ردیف سفارش نگه‌داشته‌شده نامعتبر است." }
            }
            val now = clock()
            val holdNo = numbering.next(DocumentNumberType.SALES_HOLD)
            val holdId = dao.insertHold(SalesHoldEntity(holdNo = holdNo, commandId = valid.commandId, customerId = valid.customerId, orderDiscountRial = valid.orderDiscount.value, serviceRial = valid.service.value, taxRial = valid.tax.value, notes = valid.notes, createdAtEpochMillis = now, updatedAtEpochMillis = now))
            dao.insertHoldLines(valid.lines.map { line -> SalesHoldLineEntity(holdId = holdId, menuItemId = line.menuItemId, quantityMicros = line.quantity.value, unitPriceRial = line.unitPrice.value, lineDiscountRial = line.lineDiscount.value) })
            syncRecorder?.record("SALES_HOLD", holdId, "CREATE", now, recordAudit = false)
            audit.appendAuthorized(authorizer, "CREATE", "SALES_HOLD", holdId, "نگهداری سفارش $holdNo", now, reason = "POS_HOLD", correlationId = "sales_hold:$holdId")
            holdId
        }
    }

    override suspend fun deleteHold(id: Long) {
        authorizer.require(Permission.SALES)
        database.withTransaction {
            val hold = database.salesDao().holdById(id) ?: return@withTransaction
            check(database.salesDao().deleteHold(id) == 1) { "حذف سفارش نگه‌داشته‌شده انجام نشد." }
            val now = clock()
            syncRecorder?.record("SALES_HOLD", id, "DELETE", now, recordAudit = false)
            audit.appendAuthorized(authorizer, "DELETE", "SALES_HOLD", id, "حذف سفارش نگه‌داشته‌شده ${hold.holdNo}", now, reason = "POS_HOLD_REMOVED")
        }
    }

    override suspend fun loadHold(id: Long): SalesHoldDraft = database.withTransaction {
        authorizer.require(Permission.SALES)
        val hold = database.salesDao().holdById(id) ?: throw BusinessError.EntityNotFound("SALES_HOLD", id).asViolation()
        SalesHoldDraft(
            customerId = hold.customerId,
            orderDiscount = MoneyRial.of(hold.orderDiscountRial),
            service = MoneyRial.of(hold.serviceRial),
            tax = MoneyRial.of(hold.taxRial),
            notes = hold.notes,
            lines = database.salesDao().holdLines(id).map { line ->
                SalesLineDraft(line.menuItemId, ir.sabou.inventory.core.QuantityMicros.of(line.quantityMicros), MoneyRial.of(line.unitPriceRial), MoneyRial.of(line.lineDiscountRial))
            },
            commandId = GlobalId.new().value,
        )
    }

    private suspend fun ensureInvoiceReplayMatches(existing: SalesInvoiceEntity, calculated: ir.sabou.inventory.domain.sales.PreparedSalesInvoice) {
        val dao = database.salesDao()
        val sameHeader = existing.businessEpochDay == calculated.draft.businessEpochDay &&
            existing.customerId == calculated.draft.customerId && existing.dueEpochDay == calculated.draft.dueEpochDay &&
            existing.grossRial == calculated.grossRial && existing.discountRial == calculated.discountRial &&
            existing.serviceRial == calculated.serviceRial && existing.taxRial == calculated.taxRial &&
            existing.netRial == calculated.netRial && existing.notes == calculated.draft.notes
        val lines = dao.invoiceLines(existing.id)
        val sameLines = lines.size == calculated.lines.size && lines.zip(calculated.lines).all { (stored, input) ->
            stored.menuItemId == input.menuItemId && stored.quantityMicros == input.quantityMicros && stored.unitPriceRial == input.unitPriceRial &&
                stored.grossRial == input.grossRial && stored.discountRial == input.discountRial && stored.serviceRial == input.serviceRial && stored.taxRial == input.taxRial && stored.netRial == input.netRial
        }
        val payments = dao.payments(existing.id)
        val samePayments = payments.size == calculated.draft.payments.size && payments.zip(calculated.draft.payments).all { (stored, input) ->
            stored.method == input.method.name && stored.amountRial == input.amount.value && stored.referenceNo == input.referenceNo
        }
        if (!sameHeader || !sameLines || !samePayments) throw BusinessError.IdempotencyConflict("SALES_INVOICE:${calculated.draft.commandId}").asViolation()
    }

    private suspend fun ensureReturnReplayMatches(existing: SalesReturnEntity, draft: SalesReturnDraft) {
        val storedLines = database.salesDao().returnLines(existing.id).associateBy { it.invoiceLineId }
        val same = existing.invoiceId == draft.invoiceId && existing.returnEpochDay == draft.returnEpochDay && existing.refundMethod == draft.refundMethod.name &&
            existing.reason == draft.reason && storedLines.size == draft.lines.size && draft.lines.all { storedLines[it.invoiceLineId]?.quantityMicros == it.quantity.value }
        if (!same) throw BusinessError.IdempotencyConflict("SALES_RETURN:${draft.commandId}").asViolation()
    }

    private fun revenueJournalLines(payments: List<SalesPaymentDraft>, productRevenue: Long, service: Long, tax: Long): List<SemanticJournalLine> = buildList {
        payments.groupBy { it.method.accountRole }.forEach { (role, rows) ->
            val amount = exactSum(rows.map { it.amount.value })
            if (amount > 0) add(SemanticJournalLine(role, debit = MoneyRial.of(amount), memo = rows.joinToString("+") { it.method.title }))
        }
        if (productRevenue > 0) add(SemanticJournalLine(SemanticAccountRole.SALES_REVENUE, credit = MoneyRial.of(productRevenue)))
        if (service > 0) add(SemanticJournalLine(SemanticAccountRole.SERVICE_REVENUE, credit = MoneyRial.of(service)))
        if (tax > 0) add(SemanticJournalLine(SemanticAccountRole.TAX_PAYABLE, credit = MoneyRial.of(tax)))
    }

    private fun allocationDelta(total: Long, originalQuantity: Long, previousReturned: Long, nextReturned: Long): Long {
        require(total >= 0 && originalQuantity > 0 && previousReturned in 0..nextReturned && nextReturned <= originalQuantity)
        val previous = if (previousReturned == originalQuantity) total else mulDiv(total, previousReturned, originalQuantity)
        val next = if (nextReturned == originalQuantity) total else mulDiv(total, nextReturned, originalQuantity)
        return SignedLongMath.subtract(next, previous)
    }

    private fun exactSum(values: Iterable<Long>): Long = values.fold(0L, SignedLongMath::add)

    private fun mulDiv(a: Long, b: Long, divisor: Long): Long {
        require(a >= 0 && b >= 0 && divisor > 0)
        return BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(divisor)).toLongExactCompat()
    }

    private fun String.toPaymentMethod(): SalesPaymentMethod = SalesPaymentMethod.entries.firstOrNull { it.name == this }
        ?: error("روش پرداخت ناشناخته: $this")

    private fun ir.sabou.inventory.data.db.SalesInvoiceListRow.toRecord() = SalesInvoiceRecord(
        id = id,
        invoiceNo = invoiceNo,
        businessEpochDay = businessEpochDay,
        customerName = customerName,
        grossRial = grossRial,
        discountRial = discountRial,
        serviceRial = serviceRial,
        taxRial = taxRial,
        netRial = netRial,
        theoreticalCostRial = theoreticalCostRial,
        status = SalesInvoiceStatus.fromStoredValue(status),
        notes = notes,
        createdAtEpochMillis = createdAtEpochMillis,
    )

    private data class AggregateConsumption(val item: InventoryItemEntity, val quantityMicros: Long, val valueRial: Long)
    private data class ConsumptionDelta(val itemId: Long, val quantityMicros: Long, val valueRial: Long)
}
