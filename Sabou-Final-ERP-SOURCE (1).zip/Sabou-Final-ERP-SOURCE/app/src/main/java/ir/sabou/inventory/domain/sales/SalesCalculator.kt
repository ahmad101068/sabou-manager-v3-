package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.toLongExactCompat
import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.SignedLongMath
import java.math.BigInteger

data class PreparedSalesLine(
    val menuItemId: Long,
    val quantityMicros: Long,
    val unitPriceRial: Long,
    val grossRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netRial: Long,
)

data class PreparedSalesInvoice(
    val draft: SalesInvoiceDraft,
    val lines: List<PreparedSalesLine>,
    val grossRial: Long,
    val discountRial: Long,
    val productRevenueRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netRial: Long,
)

object SalesCalculator {
    fun prepare(input: SalesInvoiceDraft): PreparedSalesInvoice {
        val draft = input.normalized()
        val baseRows = draft.lines.map { line ->
            val gross = line.unitPrice.times(line.quantity).value
            require(line.lineDiscount.value in 0..gross) { "تخفیف ردیف نمی‌تواند از مبلغ ردیف بیشتر باشد." }
            BaseLine(line, gross, SignedLongMath.subtract(gross, line.lineDiscount.value))
        }
        val subtotal = exactSum(baseRows.map { it.afterLineDiscount })
        require(subtotal > 0) { "مبلغ فروش پس از تخفیف باید بیشتر از صفر باشد." }
        require(draft.orderDiscount.value <= subtotal) { "تخفیف کل از مبلغ فاکتور بیشتر است." }
        val orderDiscountAllocation = allocate(draft.orderDiscount.value, baseRows.map { it.afterLineDiscount })
        val serviceAllocation = allocate(draft.service.value, baseRows.map { it.afterLineDiscount })
        val taxAllocation = allocate(draft.tax.value, baseRows.map { it.afterLineDiscount })
        val lines = baseRows.indices.map { index ->
            val row = baseRows[index]
            val discount = SignedLongMath.add(row.line.lineDiscount.value, orderDiscountAllocation[index])
            val product = SignedLongMath.subtract(row.gross, discount)
            val net = SignedLongMath.add(SignedLongMath.add(product, serviceAllocation[index]), taxAllocation[index])
            PreparedSalesLine(
                menuItemId = row.line.menuItemId,
                quantityMicros = row.line.quantity.value,
                unitPriceRial = row.line.unitPrice.value,
                grossRial = row.gross,
                discountRial = discount,
                serviceRial = serviceAllocation[index],
                taxRial = taxAllocation[index],
                netRial = net,
            )
        }
        val gross = exactSum(lines.map { it.grossRial })
        val discount = exactSum(lines.map { it.discountRial })
        val productRevenue = SignedLongMath.subtract(gross, discount)
        val net = SignedLongMath.add(SignedLongMath.add(productRevenue, draft.service.value), draft.tax.value)
        require(exactSum(draft.payments.map { it.amount.value }) == net) { "جمع روش‌های پرداخت باید دقیقاً با مبلغ قابل پرداخت برابر باشد." }
        return PreparedSalesInvoice(draft, lines, gross, discount, productRevenue, draft.service.value, draft.tax.value, net)
    }

    private data class BaseLine(val line: SalesLineDraft, val gross: Long, val afterLineDiscount: Long)

    private fun allocate(total: Long, weights: List<Long>): List<Long> {
        if (total == 0L) return List(weights.size) { 0L }
        require(total > 0 && weights.isNotEmpty())
        val weightTotal = exactSum(weights)
        require(weightTotal > 0)
        var allocated = 0L
        return weights.mapIndexed { index, weight ->
            if (index == weights.lastIndex) {
                SignedLongMath.subtract(total, allocated)
            } else {
                val value = mulDiv(total, weight, weightTotal)
                allocated = SignedLongMath.add(allocated, value)
                value
            }
        }
    }

    internal fun mulDiv(a: Long, b: Long, divisor: Long): Long {
        require(a >= 0 && b >= 0 && divisor > 0)
        return BigInteger.valueOf(a).multiply(BigInteger.valueOf(b)).divide(BigInteger.valueOf(divisor)).toLongExactCompat()
    }

    private fun exactSum(values: Iterable<Long>): Long = values.fold(0L, SignedLongMath::add)
}
