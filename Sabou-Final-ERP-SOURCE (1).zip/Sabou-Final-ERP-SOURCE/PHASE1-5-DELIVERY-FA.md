# گزارش تحویل Phase 1 تا 5 — سبوی عشق

مبنای این تحویل: checkpoint واقعی Fix21. تغییرات به‌صورت incremental انجام شده‌اند و Room schema، migration history، SQLCipher، database key management، accounting/inventory ledger، backup key workflow و atomic transaction logic عمداً بازنویسی نشده‌اند.

## Phase 1 — Design System
- Formatter مشترک `ErpDisplayFormatters` برای پول، عدد، درصد و تاریخ/ساعت نسبی فارسی اضافه شد.
- کامپوننت‌های مشترک Dashboard در `ErpModuleComponents` اضافه شد: Header، Quick Action، Attention و Loading/Empty/Error.
- Design System موجود Fix20 حفظ و توسعه داده شد؛ سیستم موازی ساخته نشد.

## Phase 2 — Home
- ظاهر Fix20/Fix21 حفظ شد.
- Formatterهای Trend/Home به Formatter مرکزی متصل شدند.
- منطق واقعی Trend و Today/Week/Month موجود در Fix21 دست‌نخورده ماند.
- scan نهایی هیچ درصد مدیریتی hardcoded در Dashboard پیدا نکرد.

## Phase 3 — Inventory
- `InventoryWorkspaceViewModel` از refresh همه‌چیز به load-plan وابسته به Section refactor شد.
- Overview فقط summary، location، replenishment لازم و ۵ movement اخیر را می‌گیرد.
- Items/Transfers/Lots/Counts/Waste فقط هنگام ورود به Section مربوطه load می‌شوند.
- Quarantine count از query واقعی DB می‌آید و دیگر از subset محدود lotها تخمین زده نمی‌شود.
- Search، stock filter و warehouse selector واقعی و DB-backed شدند.
- Quick Actionهای Create Item/Transfer/Count/Waste به dialog/workflow واقعی متصل شدند.
- «ورود کالا» به Goods Receipt واقعی Procurement متصل شد.
- «خروج کالا» به جای ledger write عمومی و ناامن، مسیرهای کنترل‌شده Transfer/Waste را ارائه می‌دهد.
- باگ تاریخ movement که همه رکوردها را «امروز» نمایش می‌داد رفع شد.

## Phase 4 — Sales
- Summary query واقعی و bounded برای فروش دوره اضافه شد.
- KPIهای واقعی: فروش خالص دوره، تعداد فاکتور، میانگین فاکتور، مشتری جدید، دریافتنی، برگشت فروش و سفارش باز.
- ۵ فاکتور اخیر با query محدود از DB دریافت می‌شود.
- لیست جست‌وجوی فاکتور DB-side به ۱۰۰ رکورد محدود شد.
- Dashboard فروش با Design System مشترک بازطراحی شد و Bottom Navigation یکپارچه دارد.
- Trend فروش از current/previous واقعی محاسبه می‌شود و zero baseline بدون NaN/Infinity مدیریت می‌شود.
- Quick Actionهای نمایش‌داده‌شده فقط به workflow واقعی وصل هستند. چون workflow واقعی پیش‌فاکتور در سورس پیدا نشد، دکمه جعلی برای آن اضافه نشد.
- Flowهای تراکنشی Post/Return/Void/Hold/Customer/Day Control بازنویسی نشدند.

## Phase 5 — Purchase / Procurement
- Summary query واقعی و مستقل از Search برای خرید دوره اضافه شد.
- KPIها: خرید دوره، سفارش خرید باز، تأمین‌کننده فعال، پرداختنی، دریافت معلق، درخواست خرید باز، تأییدهای معلق و سفارش دیرکرده.
- Search فاکتور خرید DB-side به ۱۰۰ رکورد محدود شد.
- Dashboard خرید با Periodهای Today/Week/Month و Design System مشترک بازطراحی شد.
- Quick Actionهای Requisition/Order/Goods Receipt/Purchase Return به intentهای واقعی Procurement وصل شدند.
- Supplier و Purchase Invoice به routeهای واقعی موجود متصل هستند.
- Needs Attention فقط از داده واقعی summary/reminder ساخته می‌شود؛ threshold ساختگی برای «قیمت غیرعادی» اختراع نشد.

## تست‌های اضافه‌شده
- `ErpDisplayFormattersTest`
- `InventoryLoadPlannerTest`
- `SalesDashboardModelsTest`
- `PurchaseDashboardModelsTest`
- تست‌های Fix21 برای Dashboard Trend/Period نیز حفظ شده‌اند.

پوشش جدید شامل: تاریخ Today/Yesterday/Old، NaN/Infinity درصد، Inventory section load-plan، Sales Week/Month comparable ranges، zero baseline، Sales Empty state و Purchase period labels/summary mapping است.

## Validation
Verifierهای پروژه:
- `ALPHA162_CODE_QUALITY=PASS`
- `DASHBOARD_UX2_VERIFICATION=PASS`
- `ALPHA162_ENTERPRISE_CORE_VERIFICATION=PASS`

Scanها:
- `صابو` در Runtime UI: یافت نشد.
- درصد مدیریتی hardcoded در Dashboard/Sales/Purchase: یافت نشد.
- `onClick = {}` عملیاتی در صفحات اصلی دست‌خورده: یافت نشد.
- متن‌های توسعه‌ای `POS تراکنشی Alpha` / `کنترل Legacy`: حذف شدند.

## Build / Unit Test / Lint
سه فرمان رسمی اجرا شدند:
- `:app:compileDebugKotlin`
- `:app:testDebugUnitTest`
- `:app:lintDebug`

هر سه قبل از رسیدن به compile/test/lint متوقف شدند، زیرا Gradle Wrapper نیاز به `gradle-8.13-bin.zip` دارد و محیط فعلی DNS برای `services.gradle.org` ندارد:
`java.net.UnknownHostException: services.gradle.org`

بنابراین Build/Test/Lint رسمی **موفق اعلام نمی‌شوند**؛ محدودیت محیط ثبت شده است. verifierهای مستقل پروژه PASS هستند.

## مورد موجود از قبل
Verifier کد کیفیت همچنان گزارش می‌دهد:
`ALPHA162_ROOM_SCHEMA_EVIDENCE=NOT_COMPLETE missing=45,46,47`
این مورد مربوط به evidence فایل‌های schema موجود پروژه است و در این Phase چون تغییر schema انجام نشده، migration یا schema دست‌کاری نشد.

## Business Logic عمداً دست‌نخورده
- Room entities/schema/migrations (به‌جز query/read projectionهای additive؛ بدون schema migration)
- SQLCipher و database encryption/key workflow
- Accounting ledger و Debit/Credit posting logic
- Inventory ledger و inventory transaction invariants
- Purchase/Sales transactional posting, reversal/void and settlement logic
- Backup/Restore و security key logic
