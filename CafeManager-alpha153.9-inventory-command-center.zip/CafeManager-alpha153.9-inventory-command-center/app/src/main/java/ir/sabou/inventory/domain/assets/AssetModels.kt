package ir.sabou.inventory.domain.assets

import kotlinx.coroutines.flow.Flow

enum class AssetAcquisitionSource(val accountCode: String, val title: String) {
 CASH("1101", "پرداخت از صندوق"),
 BANK("1102", "پرداخت از بانک یا کارت"),
 PAYABLE("2101", "خرید نسیه / حساب پرداختنی"),
 OWNER_CAPITAL("3101", "آورده مالک"),
}

data class AssetDraft(val assetCode:String,val name:String,val category:String,val quantity:Int,val purchaseEpochDay:Long,val purchaseCostRial:Long,val salvageValueRial:Long,val usefulLifeMonths:Int,val location:String,val notes:String,val acquisitionSource:AssetAcquisitionSource=AssetAcquisitionSource.BANK){
 fun validated()=copy(assetCode=assetCode.trim(),name=name.trim(),category=category.trim(),location=location.trim(),notes=notes.trim()).also{
  require(it.assetCode.isNotBlank()){ "کد دارایی الزامی است." }; require(it.name.isNotBlank()){ "نام دارایی الزامی است." }
  require(it.quantity>0){ "تعداد دارایی باید مثبت باشد." }; require(it.purchaseEpochDay>0){ "تاریخ خرید معتبر نیست." }; require(it.purchaseCostRial>0){ "بهای خرید باید مثبت باشد." }; require(it.salvageValueRial in 0..it.purchaseCostRial){ "ارزش اسقاط نامعتبر است." }; require(it.usefulLifeMonths>0){ "عمر مفید باید مثبت باشد." }
 }
}
data class AssetRecord(val id:Long,val assetCode:String,val name:String,val category:String,val quantity:Int,val purchaseEpochDay:Long,val purchaseCostRial:Long,val salvageValueRial:Long,val accumulatedDepreciationRial:Long,val usefulLifeMonths:Int,val location:String,val notes:String,val isActive:Boolean,val isAccountingRecognized:Boolean){ val bookValueRial get()=purchaseCostRial-accumulatedDepreciationRial }
data class DepreciationRecord(val id:Long,val assetName:String,val periodYear:Int,val periodMonth:Int,val amountRial:Long)
data class DepreciationDraft(val assetId:Long,val periodYear:Int,val periodMonth:Int,val postingEpochDay:Long){ fun validated()=also{require(assetId>0);require(periodMonth in 1..12);require(periodYear>1300)} }
interface AssetRepository { val assets:Flow<List<AssetRecord>>; val depreciations:Flow<List<DepreciationRecord>>; suspend fun save(id:Long?,draft:AssetDraft):Long; suspend fun recognizeLegacyAsset(id:Long):Long; suspend fun dispose(id:Long); suspend fun postDepreciation(draft:DepreciationDraft):Long }
