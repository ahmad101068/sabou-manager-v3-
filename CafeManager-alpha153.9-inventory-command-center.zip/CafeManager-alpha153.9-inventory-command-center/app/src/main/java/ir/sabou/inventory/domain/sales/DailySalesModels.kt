package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.domain.recipe.MenuPerformanceResult
import kotlinx.coroutines.flow.Flow

data class DailyMenuSaleDraft(
    val menuItemId: Long,
    val quantityMicros: Long,
    val grossSalesRial: Long,
)

data class DailySalesDraft(
    val businessEpochDay: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val notes: String = "",
    val lines: List<DailyMenuSaleDraft>,
)

data class DailySalesReversalDraft(
    val summaryId: Long,
    val reversalEpochDay: Long,
    val reason: String,
) {
    fun validated(originalEpochDay: Long): DailySalesReversalDraft {
        val normalizedReason = reason.trim()
        require(summaryId > 0) { "فروش روزانه معتبر نیست." }
        require(reversalEpochDay >= originalEpochDay) { "تاریخ برگشت نمی‌تواند قبل از روز فروش باشد." }
        require(normalizedReason.length in 3..200) { "دلیل برگشت باید بین ۳ تا ۲۰۰ نویسه باشد." }
        return copy(reason = normalizedReason)
    }
}

data class DailySalesItem(
    val id: Long,
    val businessEpochDay: Long,
    val grossSalesRial: Long,
    val discountRial: Long,
    val serviceRial: Long,
    val taxRial: Long,
    val netSalesRial: Long,
    val theoreticalCostRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val notes: String,
    val isLegacyArchive: Boolean,
    val reversedAtEpochDay: Long?,
    val reversalReason: String,
    val isClosed: Boolean = false,
    val closedBy: String? = null,
    val closeNote: String = "",
    val closureStatus: String? = null,
    val closureRevisionNo: Int = 0,
    val reopenedBy: String? = null,
    val reopenReason: String = "",
    val isReversed: Boolean = reversedAtEpochDay != null,
)

data class SalesDayClosureDraft(val businessEpochDay: Long, val note: String = "") {
    fun validated(): SalesDayClosureDraft {
        require(businessEpochDay > 0) { "روز فروش معتبر نیست." }
        return copy(note = note.trim())
    }
}

data class SalesDayReopenDraft(val businessEpochDay: Long, val reason: String) {
    fun validated(): SalesDayReopenDraft {
        require(businessEpochDay > 0) { "روز فروش معتبر نیست." }
        val normalized = reason.trim()
        require(normalized.length in 5..300) { "دلیل بازگشایی باید بین ۵ تا ۳۰۰ نویسه باشد." }
        return copy(reason = normalized)
    }
}

data class SalesDayClosureRecord(
    val businessEpochDay: Long,
    val summaryId: Long,
    val grossSalesRial: Long,
    val netSalesRial: Long,
    val theoreticalCostRial: Long,
    val cashRial: Long,
    val cardRial: Long,
    val transferRial: Long,
    val status: String,
    val revisionNo: Int,
    val closedBy: String,
    val note: String,
    val reopenedBy: String? = null,
    val reopenReason: String = "",
    val createdAtEpochMillis: Long,
)

data class DailySalesReport(
    val fromEpochDay: Long,
    val toEpochDay: Long,
    val dayCount: Int,
    val salesRial: Long,
    val costOfGoodsRial: Long,
    val grossProfitRial: Long,
    val menuPerformance: List<MenuPerformanceResult>,
)

interface DailySalesRepository {
    val dayClosures: Flow<List<SalesDayClosureRecord>>
    suspend fun post(draft: DailySalesDraft): Long
    suspend fun reverse(draft: DailySalesReversalDraft)
    suspend fun closeDay(draft: SalesDayClosureDraft)
    suspend fun reopenDay(draft: SalesDayReopenDraft)
    fun observe(query: String = ""): Flow<List<DailySalesItem>>
    fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<DailySalesReport>
}
