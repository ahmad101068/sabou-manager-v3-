package ir.sabou.inventory.domain.recipe

import kotlinx.coroutines.flow.Flow

data class MenuItem(
    val id: Long,
    val name: String,
    val category: String,
    val salePriceRial: Long,
    val ingredientCount: Int = 0,
    val recipeRevisionNo: Int = 0,
    val recipeEffectiveFromEpochDay: Long = 0,
)

data class RecipeIngredientInput(
    val inventoryItemId: Long,
    val quantityMicrosPerUnit: Long,
)

data class RecipeIngredientItem(
    val inventoryItemId: Long,
    val inventoryName: String,
    val unit: String,
    val quantityMicrosPerUnit: Long,
)

interface RecipeRepository {
    suspend fun saveMenuItem(
        id: Long?,
        name: String,
        category: String,
        salePriceRial: Long,
        ingredients: List<RecipeIngredientInput>,
    ): Long

    fun observeMenuItems(): Flow<List<MenuItem>>
    fun observeIngredients(menuItemId: Long): Flow<List<RecipeIngredientItem>>
}
