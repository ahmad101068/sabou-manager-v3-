@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call scripts\windows-env.bat

if not defined SABOU_KEYSTORE_PATH goto :missing
if not defined SABOU_KEYSTORE_PASSWORD goto :missing
if not defined SABOU_KEY_ALIAS goto :missing
if not defined SABOU_KEY_PASSWORD goto :missing
if not exist "%SABOU_KEYSTORE_PATH%" (
  echo [ERROR] Keystore not found: %SABOU_KEYSTORE_PATH%
  pause
  exit /b 12
)

> local.properties echo sdk.dir=%ANDROID_SDK_ROOT:\=\\%
call gradlew.bat --no-daemon clean testReleaseUnitTest assembleRelease
if errorlevel 1 (
  echo [ERROR] Release build failed.
  pause
  exit /b 20
)

set "APK=%CD%\app\build\outputs\apk\release\app-release.apk"
if not exist "%APK%" (
  echo [ERROR] Signed release APK was not found.
  pause
  exit /b 21
)

echo [OK] Signed release APK created:
echo %APK%
start "" explorer.exe /select,"%APK%"
pause
exit /b 0

:missing
echo [ERROR] Signing variables are missing.
echo.
echo Set these variables in the same Command Prompt before running this file:
echo   set SABOU_KEYSTORE_PATH=C:\secure\sabou-release.jks
echo   set SABOU_KEYSTORE_PASSWORD=your_store_password
echo   set SABOU_KEY_ALIAS=sabou
echo   set SABOU_KEY_PASSWORD=your_key_password
echo   call build-release-apk.bat
echo.
echo Do not save passwords inside the project.
pause
exit /b 11
