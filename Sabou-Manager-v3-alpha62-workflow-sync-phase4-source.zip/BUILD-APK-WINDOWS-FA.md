# ساخت APK بدون Android Studio در ویندوز

## روش سریع Debug

1. JDK 17 را نصب کنید. Temurin 17 یا JDK داخلی Android Studio قابل استفاده است.
2. فایل `setup-android-sdk.bat` را با دوبارکلیک اجرا کنید.
3. پس از پایان دانلود، `build-debug-apk.bat` را اجرا کنید.
4. خروجی در مسیر زیر ساخته می‌شود:

```text
app\build\outputs\apk\debug\app-debug.apk
```

SDK در پوشه `.android-sdk` همین پروژه نصب می‌شود و دسترسی Administrator لازم نیست.
اسکریپت SHA-256 بسته رسمی Command-line Tools را پیش از استخراج بررسی می‌کند.

## ساخت Release امضاشده

ابتدا فقط یک‌بار `create-release-keystore.bat` را اجرا کنید. فایل کلید را گم نکنید.
سپس Command Prompt را در پوشه پروژه باز کنید و متغیرها را تنظیم کنید:

```bat
set SABOU_KEYSTORE_PATH=C:\Users\YOUR_NAME\SabouKeys\sabou-release.jks
set SABOU_KEYSTORE_PASSWORD=STORE_PASSWORD
set SABOU_KEY_ALIAS=sabou
set SABOU_KEY_PASSWORD=KEY_PASSWORD
call build-release-apk.bat
```

رمزها یا فایل JKS را داخل Git یا ZIP عمومی قرار ندهید. برای به‌روزرسانی نسخه‌های بعدی باید همان
`applicationId` و همان کلید امضا استفاده شود.

## ساخت آنلاین با GitHub Actions

1. محتویات پروژه را در یک Repository خصوصی GitHub آپلود کنید.
2. تب Actions را باز کنید.
3. Workflow با نام `Build Android APK` را انتخاب کنید.
4. `Run workflow` را بزنید.
5. پس از موفقیت، APK را از بخش Artifacts همان اجرا دریافت کنید.

Workflow فعلی Debug APK می‌سازد و کلید انتشار دریافت نمی‌کند؛ بنابراین هیچ رمز یا کلید خصوصی در GitHub لازم نیست.

## خطاهای رایج

- `JDK 17 was not found`: متغیر `JAVA_HOME` را روی پوشه JDK 17 تنظیم کنید.
- خطای دانلود: VPN، فایروال، تاریخ سیستم و دسترسی به `dl.google.com` و `services.gradle.org` را بررسی کنید.
- `SDK package installation failed`: فایل setup را دوباره اجرا کنید؛ اجرای مجدد امن است.
- شکست Gradle: اولین خطای اصلی قبل از `BUILD FAILED` را بررسی کنید.
