package ir.sabou.inventory.domain.operations

import org.junit.Assert.assertEquals
import org.junit.Test

class SyncModelsTest {
    @Test
    fun latestChangeWinsDeterministically() {
        val left = SyncEnvelope("a", "sale", 1, SyncChangeType.UPDATE, "phone-a", 10, "12345678")
        val right = left.copy(changeId = "b", deviceId = "phone-b", occurredAtEpochMillis = 20)
        assertEquals("b", SyncConflictResolver.choose(left, right).changeId)
    }
}
