package ir.sabou.inventory.data

import android.content.Context
import ir.sabou.inventory.data.db.AppDatabase
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupManager(private val context: Context) {
    private val backupDir = File(context.filesDir, "backups").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("backup_state", Context.MODE_PRIVATE)

    fun applyPendingRestore() {
        val pending = prefs.getString("pending_restore", null) ?: return
        val source = resolveBackup(pending)
        if (source.isFile) {
            require(source.length() >= MIN_DATABASE_BYTES) { "فایل پشتیبان ناقص یا نامعتبر است." }
            context.getDatabasePath("sabou_manager_v3.db").also { target ->
                target.parentFile?.mkdirs()
                val staged = File(target.parentFile, "${target.name}.restore")
                source.copyTo(staged, overwrite = true)
                require(staged.length() == source.length()) { "کپی فایل پشتیبان کامل نشد." }
                if (target.exists()) target.copyTo(File(backupDir, "pre-restore-recovery.db"), overwrite = true)
                require(staged.renameTo(target) || runCatching { staged.copyTo(target, overwrite = true); staged.delete(); true }.getOrDefault(false)) {
                    "جایگزینی پایگاه داده انجام نشد."
                }
            }
            context.getDatabasePath("sabou_manager_v3.db-wal").delete()
            context.getDatabasePath("sabou_manager_v3.db-shm").delete()
        }
        prefs.edit().remove("pending_restore").apply()
    }

    fun create(database: AppDatabase): String {
        database.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        val name = "sabou-backup-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}.db"
        context.getDatabasePath("sabou_manager_v3.db").copyTo(File(backupDir, name), overwrite = true)
        return name
    }

    fun list(): List<String> = backupDir.listFiles()?.filter { it.isFile && it.extension == "db" }?.sortedByDescending { it.lastModified() }?.map { it.name }.orEmpty()

    fun scheduleRestore(name: String) {
        require(resolveBackup(name).isFile) { "فایل پشتیبان پیدا نشد." }
        prefs.edit().putString("pending_restore", name).apply()
    }

    private fun resolveBackup(name: String): File {
        require(name == File(name).name && name.endsWith(".db")) { "نام فایل پشتیبان معتبر نیست." }
        val candidate = File(backupDir, name).canonicalFile
        require(candidate.parentFile == backupDir.canonicalFile) { "مسیر فایل پشتیبان معتبر نیست." }
        return candidate
    }

    private companion object {
        const val MIN_DATABASE_BYTES = 4_096L
    }
}
