package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.InventoryItemEntity
import ir.sabou.inventory.data.db.InventoryCountEntity
import ir.sabou.inventory.data.db.AuditLogEntity
import ir.sabou.inventory.data.db.StockMovementEntity
import ir.sabou.inventory.data.db.SupplierEntity
import ir.sabou.inventory.domain.operations.InventoryItemDraft
import ir.sabou.inventory.domain.operations.InventoryCountDraft
import ir.sabou.inventory.domain.operations.InventoryCountRecord
import ir.sabou.inventory.domain.operations.AuditLogRecord
import ir.sabou.inventory.domain.operations.InventoryItemRecord
import ir.sabou.inventory.domain.operations.OperationsRepository
import ir.sabou.inventory.domain.operations.PurchaseSummary
import ir.sabou.inventory.domain.operations.SupplierDraft
import ir.sabou.inventory.domain.operations.SupplierRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalOperationsRepository(
    private val database: AppDatabase,
    private val clock: () -> Long = System::currentTimeMillis,
) : OperationsRepository {
    override val suppliers: Flow<List<SupplierRecord>> =
        database.supplierDao().observeActive().map { rows -> rows.map(SupplierEntity::toRecord) }

    override val inventoryItems: Flow<List<InventoryItemRecord>> =
        database.inventoryDao().observeActive().map { rows -> rows.map(InventoryItemEntity::toRecord) }

    override val lowStockItems: Flow<List<InventoryItemRecord>> =
        database.inventoryDao().observeLowStock().map { rows -> rows.map(InventoryItemEntity::toRecord) }

    override val inventoryCounts: Flow<List<InventoryCountRecord>> =
        database.inventoryControlDao().observeRecentCounts().map { rows -> rows.map { InventoryCountRecord(it.id, it.itemId, it.previousQuantityMicros, it.countedQuantityMicros, it.previousValueRial, it.countedValueRial, it.countEpochDay, it.reason) } }

    override val auditLogs: Flow<List<AuditLogRecord>> =
        database.auditLogDao().observeRecent().map { rows -> rows.map { AuditLogRecord(it.id, it.action, it.entityType, it.entityId, it.description, it.actor, it.createdAtEpochMillis) } }

    override fun purchases(query: String): Flow<List<PurchaseSummary>> =
        database.purchaseDao().observeSearch(query.trim()).map { rows ->
            rows.map { row ->
                PurchaseSummary(
                    id = row.purchaseId,
                    invoiceNo = row.invoiceNo,
                    supplierName = row.supplierName,
                    purchaseEpochDay = row.purchaseEpochDay,
                    dueEpochDay = row.dueEpochDay,
                    totalRial = row.totalRial,
                    paidRial = row.paidRial,
                    isPaid = row.paymentStatus == "PAID",
                    paymentStatus = row.paymentStatus,
                    paymentMethod = row.paymentMethod,
                    reminderEnabled = row.reminderEnabled,
                    reminderEpochDay = row.reminderEpochDay,
                )
            }
        }

    override suspend fun createSupplier(draft: SupplierDraft): Long {
        val valid = draft.validated()
        val now = clock()
        return database.withTransaction {
            val previous = database.supplierDao().byName(valid.name)
            if (previous != null) {
                require(!previous.isActive) { "تأمین‌کننده‌ای با این نام وجود دارد." }
                check(
                    database.supplierDao().update(
                        previous.copy(
                            contactName = valid.contactName,
                            phone = valid.phone,
                            address = valid.address,
                            paymentTermsDays = valid.paymentTermsDays,
                            notes = valid.notes,
                            isActive = true,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "فعال‌سازی دوباره تأمین‌کننده انجام نشد." }
                return@withTransaction previous.id
            }
            database.supplierDao().insert(
                SupplierEntity(
                    name = valid.name,
                    contactName = valid.contactName,
                    phone = valid.phone,
                    address = valid.address,
                    paymentTermsDays = valid.paymentTermsDays,
                    notes = valid.notes,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
        }
    }

    override suspend fun updateSupplier(id: Long, draft: SupplierDraft) {
        val current = database.supplierDao().activeById(id)
            ?: error("تأمین‌کننده پیدا نشد.")
        val valid = draft.validated()
        check(
            database.supplierDao().update(
                current.copy(
                    name = valid.name,
                    contactName = valid.contactName,
                    phone = valid.phone,
                    address = valid.address,
                    paymentTermsDays = valid.paymentTermsDays,
                    notes = valid.notes,
                    updatedAtEpochMillis = clock(),
                ),
            ) == 1,
        ) { "ویرایش تأمین‌کننده انجام نشد." }
    }

    override suspend fun deactivateSupplier(id: Long) {
        database.withTransaction {
            val now = clock()
            check(database.supplierDao().deactivate(id, now) == 1) {
                "حذف تأمین‌کننده انجام نشد."
            }
            database.inventoryDao().clearSupplierReference(id, now)
        }
    }

    override suspend fun createInventoryItem(draft: InventoryItemDraft): Long {
        val valid = draft.validated()
        ensureSupplierIsActive(valid.supplierId)
        val now = clock()
        return database.withTransaction {
            val previous = database.inventoryDao().byName(valid.name)
            if (previous != null) {
                require(!previous.isActive) { "کالایی با این نام وجود دارد." }
                check(
                    database.inventoryDao().update(
                        previous.copy(
                            category = valid.category,
                            unit = valid.unit,
                            alertEnabled = valid.alertEnabled,
                            alertThresholdMicros = valid.alertThresholdMicros,
                            supplierId = valid.supplierId,
                            isActive = true,
                            updatedAtEpochMillis = now,
                        ),
                    ) == 1,
                ) { "فعال‌سازی دوباره کالا انجام نشد." }
                return@withTransaction previous.id
            }
            database.inventoryDao().insert(
                InventoryItemEntity(
                    name = valid.name,
                    category = valid.category,
                    unit = valid.unit,
                    alertEnabled = valid.alertEnabled,
                    alertThresholdMicros = valid.alertThresholdMicros,
                    supplierId = valid.supplierId,
                    createdAtEpochMillis = now,
                    updatedAtEpochMillis = now,
                ),
            )
        }
    }

    override suspend fun updateInventoryItem(id: Long, draft: InventoryItemDraft) {
        val current = database.inventoryDao().activeById(id)
            ?: error("کالا پیدا نشد.")
        val valid = draft.validated()
        ensureSupplierIsActive(valid.supplierId)
        check(
            database.inventoryDao().update(
                current.copy(
                    name = valid.name,
                    category = valid.category,
                    unit = valid.unit,
                    alertEnabled = valid.alertEnabled,
                    alertThresholdMicros = valid.alertThresholdMicros,
                    supplierId = valid.supplierId,
                    updatedAtEpochMillis = clock(),
                ),
            ) == 1,
        ) { "ویرایش کالا انجام نشد." }
    }

    override suspend fun deactivateInventoryItem(id: Long) {
        val current = database.inventoryDao().activeById(id)
            ?: error("کالا پیدا نشد.")
        require(current.stockMicros == 0L && current.inventoryValueRial == 0L) {
            "کالای دارای موجودی یا ارزش انبار را نمی‌توان غیرفعال کرد؛ ابتدا موجودی آن را تعیین تکلیف کنید."
        }
        check(database.inventoryDao().deactivate(id, clock()) == 1) {
            "غیرفعال‌سازی کالا انجام نشد؛ اطلاعات آن هم‌زمان تغییر کرده است."
        }
        log("DEACTIVATE", "INVENTORY_ITEM", id, "غیرفعال‌سازی کالا: ${current.name}")
    }

    override suspend fun postInventoryCount(draft: InventoryCountDraft): Long {
        val valid = draft.validated()
        return database.withTransaction {
            val current = database.inventoryDao().activeById(valid.itemId) ?: error("کالا پیدا نشد.")
            val now = clock()
            val countId = database.inventoryControlDao().insertCount(
                InventoryCountEntity(
                    itemId = current.id, previousQuantityMicros = current.stockMicros,
                    countedQuantityMicros = valid.countedQuantityMicros, previousValueRial = current.inventoryValueRial,
                    countedValueRial = valid.countedValueRial, countEpochDay = valid.countEpochDay,
                    reason = valid.reason, createdAtEpochMillis = now,
                ),
            )
            check(database.inventoryDao().updateValuation(current.id, valid.countedQuantityMicros, valid.countedValueRial, now) == 1) { "اصلاح موجودی انجام نشد." }
            database.stockMovementDao().insert(StockMovementEntity(
                itemId = current.id, movementType = "INVENTORY_COUNT",
                quantityDeltaMicros = valid.countedQuantityMicros - current.stockMicros,
                valueDeltaRial = valid.countedValueRial - current.inventoryValueRial,
                referenceType = "INVENTORY_COUNT", referenceId = countId,
                movementEpochDay = valid.countEpochDay, notes = valid.reason, createdAtEpochMillis = now,
            ))
            database.auditLogDao().insert(AuditLogEntity(action="INVENTORY_COUNT", entityType="INVENTORY_ITEM", entityId=current.id, description="انبارگردانی ${current.name}: ${current.stockMicros} → ${valid.countedQuantityMicros}", actor="local-admin", createdAtEpochMillis=now))
            countId
        }
    }

    private suspend fun log(action: String, entityType: String, entityId: Long?, description: String) {
        database.auditLogDao().insert(AuditLogEntity(action=action, entityType=entityType, entityId=entityId, description=description, actor="local-admin", createdAtEpochMillis=clock()))
    }

    private suspend fun ensureSupplierIsActive(supplierId: Long?) {
        if (supplierId != null) {
            require(database.supplierDao().activeById(supplierId) != null) {
                "تأمین‌کننده انتخاب‌شده فعال نیست."
            }
        }
    }
}

private fun SupplierEntity.toRecord() = SupplierRecord(
    id = id,
    name = name,
    contactName = contactName,
    phone = phone,
    address = address,
    paymentTermsDays = paymentTermsDays,
    notes = notes,
)

private fun InventoryItemEntity.toRecord() = InventoryItemRecord(
    id = id,
    name = name,
    category = category,
    unit = unit,
    stockMicros = stockMicros,
    inventoryValueRial = inventoryValueRial,
    alertEnabled = alertEnabled,
    alertThresholdMicros = alertThresholdMicros,
    supplierId = supplierId,
)
