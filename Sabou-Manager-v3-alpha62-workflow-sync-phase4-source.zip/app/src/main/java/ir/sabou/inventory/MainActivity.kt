package ir.sabou.inventory

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import ir.sabou.inventory.ui.SabouApp
import ir.sabou.inventory.ui.SabouSplash
import ir.sabou.inventory.ui.ThemePreference
import ir.sabou.inventory.ui.theme.SabouTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences = getSharedPreferences("sabou_ui", MODE_PRIVATE)
        var selectedTheme by mutableStateOf(
            preferences.getString("theme", null)
                ?.let { stored -> runCatching { ThemePreference.valueOf(stored) }.getOrNull() }
                ?: ThemePreference.SYSTEM,
        )
        setContent {
            val dark = when (selectedTheme) {
                ThemePreference.SYSTEM -> isSystemInDarkTheme()
                ThemePreference.LIGHT -> false
                ThemePreference.DARK -> true
            }
            SabouTheme(darkTheme = dark) {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(1_250)
                    showSplash = false
                }
                if (showSplash) {
                    SabouSplash(visible = true)
                } else {
                    SabouApp(
                        container = (application as SabouApplication).container,
                        themePreference = selectedTheme,
                        onThemePreferenceChange = { value ->
                            selectedTheme = value
                            preferences.edit().putString("theme", value.name).apply()
                        },
                    )
                }
            }
        }
    }
}
