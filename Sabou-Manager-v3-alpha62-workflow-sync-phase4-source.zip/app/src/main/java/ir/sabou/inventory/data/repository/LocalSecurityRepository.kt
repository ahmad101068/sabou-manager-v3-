package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.AppDatabase
import ir.sabou.inventory.data.db.AppSessionEntity
import ir.sabou.inventory.data.db.AppUserEntity
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.UserDraft
import ir.sabou.inventory.domain.operations.UserRole
import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalSecurityRepository(private val db: AppDatabase, private val clock: () -> Long = System::currentTimeMillis) : SecurityRepository {
    override val users: Flow<List<AppUserRecord>> = db.securityDao().observeUsers().map { list ->
        list.map { entity -> entity.asRecord() }
    }
    override val currentUser: Flow<AppUserRecord?> = db.securityDao().observeCurrentUser().map { entity -> entity?.asRecord() }

    override suspend fun save(id: Long?, draft: UserDraft): Long {
        val username = draft.username.trim().lowercase()
        val displayName = draft.displayName.trim()
        require(username.length >= 3) { "نام کاربری باید حداقل ۳ حرف باشد." }
        require(displayName.isNotBlank()) { "نام نمایشی الزامی است." }
        require(draft.pin.length >= 4 && draft.pin.all(Char::isDigit)) { "رمز باید حداقل ۴ رقم باشد." }
        val now = clock()
        return db.withTransaction {
            val duplicate = db.securityDao().byUsername(username)
            require(duplicate == null || duplicate.id == id) { "این نام کاربری قبلاً ثبت شده است." }
            if (id == null) db.securityDao().insert(AppUserEntity(username=username, displayName=displayName, pinHash=hashPin(draft.pin), role=draft.role.name, createdAtEpochMillis=now, updatedAtEpochMillis=now))
            else {
                val current = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
                check(db.securityDao().update(current.copy(username=username, displayName=displayName, pinHash=hashPin(draft.pin), role=draft.role.name, isActive=true, updatedAtEpochMillis=now)) == 1)
                id
            }
        }
    }

    override suspend fun deactivate(id: Long) {
        check(db.securityDao().deactivate(id, clock()) == 1) { "کاربر مالک قابل غیرفعال‌سازی نیست یا کاربر پیدا نشد." }
    }

    override suspend fun switchUser(id: Long, pin: String) {
        val user = db.securityDao().byId(id) ?: error("کاربر پیدا نشد.")
        require(user.isActive) { "این کاربر غیرفعال است." }
        require(verifyPin(pin, user.pinHash)) { "رمز ورود نادرست است." }
        if (!user.pinHash.startsWith("pbkdf2$")) {
            db.securityDao().update(user.copy(pinHash = hashPin(pin), updatedAtEpochMillis = clock()))
        }
        db.securityDao().setSession(AppSessionEntity(currentUserId=id, updatedAtEpochMillis=clock()))
    }

    private fun AppUserEntity.asRecord() = AppUserRecord(id, username, displayName, runCatching { UserRole.valueOf(role) }.getOrDefault(UserRole.CASHIER), isActive)

    private fun hashPin(pin: String): String {
        val iterations = 210_000
        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        val hash = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return listOf("pbkdf2", iterations.toString(), Base64.encodeToString(salt, Base64.NO_WRAP), Base64.encodeToString(hash, Base64.NO_WRAP)).joinToString("$")
    }

    private fun verifyPin(pin: String, encoded: String): Boolean {
        if (!encoded.startsWith("pbkdf2$")) {
            val legacy = MessageDigest.getInstance("SHA-256")
                .digest(("sabou-v3:" + pin).toByteArray())
                .joinToString("") { "%02x".format(it) }
            return MessageDigest.isEqual(legacy.toByteArray(), encoded.toByteArray())
        }
        val parts = encoded.split('$')
        if (parts.size != 4) return false
        val iterations = parts[1].toIntOrNull() ?: return false
        val salt = runCatching { Base64.decode(parts[2], Base64.NO_WRAP) }.getOrNull() ?: return false
        val expected = runCatching { Base64.decode(parts[3], Base64.NO_WRAP) }.getOrNull() ?: return false
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, expected.size * 8)
        val actual = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return MessageDigest.isEqual(expected, actual)
    }
}
