package ir.sabou.inventory.data.repository

import androidx.room.withTransaction
import ir.sabou.inventory.data.db.*
import ir.sabou.inventory.domain.recipe.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class LocalRecipeRepository(private val database: AppDatabase, private val clock: () -> Long = System::currentTimeMillis) : RecipeRepository {
    override suspend fun saveMenuItem(id: Long?, name: String, category: String, salePriceRial: Long, ingredients: List<RecipeIngredientInput>): Long {
        val normalized = name.trim(); require(normalized.isNotEmpty()) { "نام محصول الزامی است." }; require(salePriceRial >= 0) { "قیمت فروش نامعتبر است." }
        require(ingredients.isNotEmpty()) { "رسپی باید حداقل یک ماده اولیه داشته باشد." }
        require(ingredients.all { it.quantityMicrosPerUnit > 0 }) { "مقدار مصرف مواد باید بیشتر از صفر باشد." }
        require(ingredients.map { it.inventoryItemId }.distinct().size == ingredients.size) { "ماده اولیه تکراری است." }
        val now = clock()
        return database.withTransaction {
            ingredients.forEach { require(database.inventoryDao().activeById(it.inventoryItemId) != null) { "ماده اولیه فعال پیدا نشد." } }
            val menuId = if (id == null) database.recipeDao().insertMenuItem(MenuItemEntity(name=normalized, category=category.trim(), salePriceRial=salePriceRial, createdAtEpochMillis=now, updatedAtEpochMillis=now)) else {
                val old=database.recipeDao().activeMenuItem(id) ?: error("محصول منو پیدا نشد.")
                check(database.recipeDao().updateMenuItem(old.copy(name=normalized, category=category.trim(), salePriceRial=salePriceRial, updatedAtEpochMillis=now))==1); id
            }
            database.recipeDao().clearIngredients(menuId)
            database.recipeDao().upsertIngredients(ingredients.map { RecipeIngredientEntity(menuId, it.inventoryItemId, it.quantityMicrosPerUnit) })
            menuId
        }
    }
    override fun observeMenuItems(): Flow<List<MenuItem>> = database.recipeDao().observeActiveMenuItems().map { rows -> rows.map { MenuItem(it.id,it.name,it.category,it.salePriceRial) } }
    override fun observeIngredients(menuItemId: Long): Flow<List<RecipeIngredientItem>> = database.recipeDao().observeIngredientRows(menuItemId).map { rows -> rows.map { RecipeIngredientItem(it.inventoryItemId,it.inventoryName,it.unit,it.quantityMicrosPerUnit) } }
}
