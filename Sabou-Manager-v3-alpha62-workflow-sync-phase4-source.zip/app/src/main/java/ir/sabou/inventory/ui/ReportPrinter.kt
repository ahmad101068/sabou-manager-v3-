package ir.sabou.inventory.ui

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebView
import ir.sabou.inventory.domain.sales.SalesReport

fun printSalesReport(context: Context, report: SalesReport) {
    val html = """<html dir='rtl'><head><meta charset='utf-8'><style>body{font-family:sans-serif;padding:24px}h1{font-size:22px}table{width:100%;border-collapse:collapse}td{border:1px solid #888;padding:8px}</style></head><body><h1>گزارش فروش سبو</h1><p>بازه: ${report.fromEpochDay} تا ${report.toEpochDay}</p><table><tr><td>تعداد فاکتور</td><td>${report.invoiceCount}</td></tr><tr><td>فروش</td><td>${report.salesRial}</td></tr><tr><td>بهای تمام‌شده</td><td>${report.costOfGoodsRial}</td></tr><tr><td>سود ناخالص</td><td>${report.grossProfitRial}</td></tr><tr><td>مطالبات</td><td>${report.receivablesRial}</td></tr></table></body></html>"""
    val webView = WebView(context)
    webView.webViewClient = object : android.webkit.WebViewClient() {
        override fun onPageFinished(view: WebView, url: String?) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            manager.print("Sabou-Sales-Report", view.createPrintDocumentAdapter("گزارش فروش"), PrintAttributes.Builder().build())
        }
    }
    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
}
