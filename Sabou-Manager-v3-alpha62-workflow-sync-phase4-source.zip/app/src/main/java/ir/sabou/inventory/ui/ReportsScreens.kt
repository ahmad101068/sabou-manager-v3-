package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.data.repository.DashboardSnapshot

@Composable
fun ReportsCenterScreen(
    dashboard: DashboardSnapshot,
    sales: SalesUiState,
    accounting: AccountingUiState,
    operations: OperationsUiState,
    onOpenSales: () -> Unit,
    onOpenAccounting: () -> Unit,
    onOpenInventory: () -> Unit,
    onBack: () -> Unit,
) {
    val netProfit = accounting.profitLoss.netProfitRial
    val liquidity = dashboard.cashBalanceRial + dashboard.bankBalanceRial
    val lowStock = operations.lowStockItems.size
    val openSettlements = operations.settlementAlerts.size
    Scaffold(topBar = { ProfessionalTopBar("مرکز گزارش‌ها", "تصمیم‌گیری سریع با شاخص‌های کلیدی", onBack) }, containerColor = MaterialTheme.colorScheme.background) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { PremiumHero("سود خالص", formatMoney(netProfit), "نقدینگی در دسترس ${formatMoney(liquidity)}") }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("فروش فعال", formatMoney(sales.activeSalesRial), Modifier.weight(1f)); MetricTile("سود ناخالص", formatMoney(sales.grossProfitRial), Modifier.weight(1f)) } }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricTile("مطالبات", formatMoney(sales.receivablesRial), Modifier.weight(1f)); MetricTile("ارزش انبار", formatMoney(dashboard.inventoryValueRial), Modifier.weight(1f)) } }
            item { SectionHeading("نیازمند توجه", "مواردی که بهتر است امروز بررسی شوند") }
            item { Card(shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) { Column(Modifier.fillMaxWidth().padding(17.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) { ReportAlertRow("کالاهای کم‌موجود", "$lowStock مورد", lowStock > 0); ReportAlertRow("تسویه‌های سررسید", "$openSettlements مورد", openSettlements > 0); ReportAlertRow("بدهی تأمین‌کنندگان", formatMoney(dashboard.supplierPayablesRial), dashboard.supplierPayablesRial > 0) } } }
            item { SectionHeading("گزارش‌های تفصیلی", "ورود سریع به تحلیل هر حوزه") }
            item { ReportDestinationCard("فروش و درآمد", "فروش، بهای تمام‌شده، سود ناخالص و مطالبات", "مشاهده فروش", onOpenSales) }
            item { ReportDestinationCard("حسابداری و تراز", "سود و زیان، تراز آزمایشی و اسناد", "ورود به حسابداری", onOpenAccounting) }
            item { ReportDestinationCard("موجودی و تأمین", "ارزش انبار، کمبودها و اصلاح موجودی", "مشاهده انبار", onOpenInventory) }
        }
    }
}

@Composable
private fun ReportAlertRow(title: String, value: String, needsAttention: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.SemiBold)
        StatusPill(
            text = value,
            containerColor = if (needsAttention) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer,
            contentColor = if (needsAttention) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer,
        )
    }
}

@Composable
private fun ReportDestinationCard(title: String, description: String, action: String, onClick: () -> Unit) {
    Card(
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
            Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, modifier = Modifier.fillMaxWidth()) { Text(action) }
        }
    }
}
