package ir.sabou.inventory.domain.sales

import ir.sabou.inventory.core.MoneyRial
import ir.sabou.inventory.core.QuantityMicros
import kotlinx.coroutines.flow.Flow

enum class SalePaymentMethod(val accountCode: String?, val storedValue: String?) {
    RECEIVABLE("1201", null), CASH("1101", "نقدی"), CARD("1102", "کارتخوان"), TRANSFER("1102", "حواله")
}

data class SaleLineDraft(val menuItemId: Long?, val productName: String, val quantity: QuantityMicros, val unitPrice: MoneyRial)
data class SaleDraft(
    val invoiceNo: String,
    val customerId: Long?,
    val customerName: String,
    val saleEpochDay: Long,
    val dueEpochDay: Long?,
    val channel: String,
    val discount: MoneyRial,
    val delivery: MoneyRial,
    val paymentMethod: SalePaymentMethod,
    val notes: String = "",
    val lines: List<SaleLineDraft>,
)
data class PreparedSaleLine(val menuItemId: Long?, val productName: String, val quantityMicros: Long, val unitPriceRial: Long, val total: MoneyRial)
data class PreparedSale(val draft: SaleDraft, val lines: List<PreparedSaleLine>, val subtotal: MoneyRial, val total: MoneyRial)
data class PostedSale(val saleId: Long, val journalEntryId: Long, val total: MoneyRial, val costOfGoodsRial: Long)
data class SaleListItem(val id: Long, val invoiceNo: String, val customerName: String, val saleEpochDay: Long, val totalRial: Long, val paidRial: Long, val paymentStatus: String, val channel: String, val costOfGoodsRial: Long = 0, val reversed: Boolean = false)
data class CustomerItem(val id: Long, val name: String, val phone: String, val creditLimitRial: Long)
data class SalePaymentItem(val id: Long, val amountRial: Long, val paymentEpochDay: Long, val method: String, val reversed: Boolean)
data class SalesReport(val fromEpochDay: Long, val toEpochDay: Long, val invoiceCount: Int, val salesRial: Long, val costOfGoodsRial: Long, val grossProfitRial: Long, val receivablesRial: Long, val topChannels: List<Pair<String, Long>>)

interface SalesRepository {
    suspend fun post(draft: SaleDraft): PostedSale
    suspend fun addCustomer(name: String, phone: String, address: String, creditLimitRial: Long, notes: String = ""): Long
    suspend fun receive(saleId: Long, amount: MoneyRial, paymentEpochDay: Long, method: SalePaymentMethod): Long
    suspend fun reverseReceipt(paymentId: Long, reversalEpochDay: Long): Long
    suspend fun reverseSale(saleId: Long, reversalEpochDay: Long): Long
    suspend fun replaceSale(saleId: Long, reversalEpochDay: Long, replacement: SaleDraft): PostedSale
    fun observeCustomers(): Flow<List<CustomerItem>>
    fun observePayments(saleId: Long): Flow<List<SalePaymentItem>>
    fun observeSales(query: String = ""): Flow<List<SaleListItem>>
    fun observeReport(fromEpochDay: Long, toEpochDay: Long): Flow<SalesReport>
}
