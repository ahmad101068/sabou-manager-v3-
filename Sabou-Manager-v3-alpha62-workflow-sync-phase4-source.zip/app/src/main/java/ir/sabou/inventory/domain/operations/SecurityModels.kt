package ir.sabou.inventory.domain.operations

import kotlinx.coroutines.flow.Flow

enum class UserRole(val title: String, val permissions: Set<String>) {
    OWNER("مالک", setOf("*")),
    MANAGER("مدیر", setOf("PURCHASES", "SUPPLIERS", "INVENTORY", "RECIPES", "SALES", "ACCOUNTING", "REPORTS", "AUDIT", "BACKUP", "PERSONNEL", "ASSETS")),
    CASHIER("صندوقدار", setOf("SALES", "REPORTS")),
    STOREKEEPER("انباردار", setOf("PURCHASES", "SUPPLIERS", "INVENTORY", "RECIPES")),
    ACCOUNTANT("حسابدار", setOf("PURCHASES", "SALES", "ACCOUNTING", "REPORTS", "AUDIT", "PERSONNEL", "ASSETS"));

    fun allows(permission: String): Boolean = "*" in permissions || permission in permissions
}

data class AppUserRecord(val id: Long, val username: String, val displayName: String, val role: UserRole, val isActive: Boolean)
data class UserDraft(val username: String, val displayName: String, val pin: String, val role: UserRole)

interface SecurityRepository {
    val users: Flow<List<AppUserRecord>>
    val currentUser: Flow<AppUserRecord?>
    suspend fun save(id: Long?, draft: UserDraft): Long
    suspend fun deactivate(id: Long)
    suspend fun switchUser(id: Long, pin: String)
}
