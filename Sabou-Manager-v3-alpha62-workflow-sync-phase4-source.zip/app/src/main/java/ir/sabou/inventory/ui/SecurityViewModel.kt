package ir.sabou.inventory.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import ir.sabou.inventory.data.AppContainer
import ir.sabou.inventory.domain.operations.AppUserRecord
import ir.sabou.inventory.domain.operations.SecurityRepository
import ir.sabou.inventory.domain.operations.UserDraft
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SecurityUiState(
    val users: List<AppUserRecord> = emptyList(),
    val currentUser: AppUserRecord? = null,
    val backups: List<String> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null,
)

class SecurityViewModel(private val repository: SecurityRepository, private val container: AppContainer) : ViewModel() {
    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val backups = MutableStateFlow(container.listBackups())

    val state: StateFlow<SecurityUiState> = combine(repository.users, repository.currentUser, backups, busy, message) { users, current, copies, isBusy, msg ->
        SecurityUiState(users, current, copies, isBusy, msg)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SecurityUiState())

    fun save(id: Long?, draft: UserDraft, done: () -> Unit = {}) = run("کاربر ذخیره شد.", done) { repository.save(id, draft) }
    fun deactivate(id: Long) = run("کاربر غیرفعال شد.") { repository.deactivate(id) }
    fun switchUser(id: Long, pin: String, done: () -> Unit = {}) = run("کاربر فعال تغییر کرد.", done) { repository.switchUser(id, pin) }
    fun createBackup() = run("نسخه پشتیبان ساخته شد.") { container.createBackup(); backups.value = container.listBackups() }
    fun restore(name: String) = run("بازیابی برای اجرای بعدی برنامه زمان‌بندی شد؛ برنامه را کامل ببندید و دوباره باز کنید.") { container.scheduleRestore(name) }
    fun clearMessage() { message.value = null }

    private fun run(success: String, done: () -> Unit = {}, block: suspend () -> Unit) {
        if (busy.value) return
        viewModelScope.launch {
            busy.value = true; message.value = null
            try { block(); message.value = success; done() }
            catch (e: Exception) { message.value = UiErrorHandler.message("SecurityViewModel", e) }
            finally { busy.value = false }
        }
    }

    companion object {
        fun factory(repository: SecurityRepository, container: AppContainer): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = SecurityViewModel(repository, container) as T
        }
    }
}
