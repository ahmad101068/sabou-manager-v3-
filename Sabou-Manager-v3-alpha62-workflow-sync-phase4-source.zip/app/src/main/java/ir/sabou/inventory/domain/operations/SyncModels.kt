package ir.sabou.inventory.domain.operations

enum class SyncChangeType { CREATE, UPDATE, REVERSAL }
enum class SyncState { LOCAL_ONLY, PENDING, SYNCED, CONFLICT }

data class SyncEnvelope(
    val changeId: String,
    val entityType: String,
    val entityId: Long,
    val type: SyncChangeType,
    val deviceId: String,
    val occurredAtEpochMillis: Long,
    val payloadHash: String,
    val state: SyncState = SyncState.PENDING,
) {
    fun validated(): SyncEnvelope {
        require(changeId.isNotBlank() && entityType.isNotBlank() && deviceId.isNotBlank()) { "شناسه تغییر همگام‌سازی معتبر نیست." }
        require(entityId > 0 && occurredAtEpochMillis > 0 && payloadHash.length >= 8) { "بسته همگام‌سازی ناقص است." }
        return this
    }
}

object SyncConflictResolver {
    fun choose(left: SyncEnvelope, right: SyncEnvelope): SyncEnvelope {
        left.validated(); right.validated()
        require(left.entityType == right.entityType && left.entityId == right.entityId) { "تغییرها متعلق به یک رکورد نیستند." }
        return when {
            left.occurredAtEpochMillis > right.occurredAtEpochMillis -> left.copy(state = SyncState.SYNCED)
            right.occurredAtEpochMillis > left.occurredAtEpochMillis -> right.copy(state = SyncState.SYNCED)
            left.changeId >= right.changeId -> left.copy(state = SyncState.SYNCED)
            else -> right.copy(state = SyncState.SYNCED)
        }
    }
}
