@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ir.sabou.inventory.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import ir.sabou.inventory.domain.assets.AssetDraft
import ir.sabou.inventory.domain.assets.DepreciationDraft

@Composable
fun AssetScreen(
    state: AssetUiState,
    onSave: (Long?, AssetDraft) -> Unit,
    onDispose: (Long) -> Unit,
    onDepreciate: (DepreciationDraft) -> Unit,
    onBack: () -> Unit,
) {
    var add by remember { mutableStateOf(false) }
    var dep by remember { mutableStateOf(false) }
    val activeAssets = state.assets.filter { it.isActive }
    val totalBookValue = activeAssets.sumOf { it.bookValueRial }
    val totalDepreciation = state.assets.sumOf { it.accumulatedDepreciationRial }

    Scaffold(
        topBar = {
            ProfessionalTopBar(
                title = "دارایی‌های ثابت",
                subtitle = "کنترل ارزش دفتری، استهلاک و چرخه عمر تجهیزات",
                onBack = onBack,
                actionLabel = "ثبت دارایی",
                onAction = { add = true },
            )
        },
        floatingActionButton = {
            if (activeAssets.isNotEmpty()) {
                Button(onClick = { dep = true }) {
                    Text("ثبت استهلاک")
                }
            }
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricTile("دارایی فعال", activeAssets.size.toString(), Modifier.weight(1f))
                        MetricTile("ارزش دفتری", formatMoney(totalBookValue, CurrencyUnit.RIAL), Modifier.weight(1f))
                    }
                    MetricTile("استهلاک انباشته", formatMoney(totalDepreciation, CurrencyUnit.RIAL), Modifier.fillMaxWidth())
                }
            }
            state.message?.let { message ->
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) {
                        Text(message, Modifier.fillMaxWidth().padding(14.dp), color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
            }
            item { SectionHeading("فهرست دارایی‌ها", "ارزش فعلی و وضعیت بهره‌برداری هر دارایی") }
            if (state.assets.isEmpty()) {
                item { EmptyStatePanel("هنوز دارایی ثبت نشده", "برای ثبت تجهیزات، ماشین‌آلات یا اثاثیه از گزینه ثبت دارایی استفاده کنید.") }
            } else {
                items(state.assets, key = { it.id }) { asset ->
                    Card(
                        shape = MaterialTheme.shapes.extraLarge,
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(asset.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("${asset.assetCode} · ${asset.category}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                StatusPill(if (asset.isActive) "فعال" else "خارج‌شده")
                            }
                            Text("محل استقرار: ${asset.location.ifBlank { "ثبت نشده" }}", style = MaterialTheme.typography.bodyMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                MetricTile("ارزش دفتری", formatMoney(asset.bookValueRial, CurrencyUnit.RIAL), Modifier.weight(1f))
                                MetricTile("استهلاک", formatMoney(asset.accumulatedDepreciationRial, CurrencyUnit.RIAL), Modifier.weight(1f))
                            }
                            if (asset.isActive) {
                                OutlinedButton(onClick = { onDispose(asset.id) }, modifier = Modifier.fillMaxWidth()) {
                                    Text("ثبت خروج از بهره‌برداری")
                                }
                            }
                        }
                    }
                }
            }
            item { SectionHeading("سوابق استهلاک", "آخرین ثبت‌های دوره‌ای دارایی‌ها") }
            if (state.depreciations.isEmpty()) {
                item { EmptyStatePanel("سابقه‌ای وجود ندارد", "پس از ثبت استهلاک ماهانه، سوابق در این بخش نمایش داده می‌شوند.") }
            } else {
                items(state.depreciations, key = { it.id }) { depreciation ->
                    Card(shape = MaterialTheme.shapes.large) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(depreciation.assetName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("دوره ${depreciation.periodYear}/${depreciation.periodMonth}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text(formatMoney(depreciation.amountRial, CurrencyUnit.RIAL), fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }

    if (add) AssetDialog(onDismiss = { add = false }) { draft ->
        onSave(null, draft)
        add = false
    }
    if (dep) DepDialog(state, onDismiss = { dep = false }) { draft ->
        onDepreciate(draft)
        dep = false
    }
}

@Composable
private fun AssetDialog(onDismiss: () -> Unit, onSave: (AssetDraft) -> Unit) {
    var code by remember { mutableStateOf("AST-${System.currentTimeMillis().toString().takeLast(8)}") }
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var categoryExpanded by remember { mutableStateOf(false) }
    val categories = listOf("تجهیزات آشپزخانه", "اثاثیه", "وسایل نقلیه", "تجهیزات اداری", "تأسیسات", "ابزار و ماشین‌آلات")
    var cost by remember { mutableStateOf("") }
    var salvage by remember { mutableStateOf("0") }
    var life by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    val today = currentEpochDay()
    val valid = code.isNotBlank() && name.isNotBlank() && category.isNotBlank() &&
        (cost.toLongOrNull() ?: 0L) > 0L && (life.toIntOrNull() ?: 0) > 0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت دارایی جدید") },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 520.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(code, { code = it }, label = { Text("کد دارایی خودکار") }, readOnly = true, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(name, { name = it }, label = { Text("نام دارایی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { categoryExpanded = true }, modifier = Modifier.fillMaxWidth()) { Text(category.ifBlank { "انتخاب دسته‌بندی" }) }
                    androidx.compose.material3.DropdownMenu(categoryExpanded, { categoryExpanded = false }) {
                        categories.forEach { value -> androidx.compose.material3.DropdownMenuItem(text = { Text(value) }, onClick = { category = value; categoryExpanded = false }) }
                    }
                }
                OutlinedTextField(cost, { cost = it.filter(Char::isDigit) }, label = { Text("بهای خرید (ریال)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(salvage, { salvage = it.filter(Char::isDigit) }, label = { Text("ارزش اسقاط") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(life, { life = it.filter(Char::isDigit) }, label = { Text("عمر مفید (ماه)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(location, { location = it }, label = { Text("محل استقرار") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                enabled = valid,
                onClick = {
                    onSave(AssetDraft(code.trim(), name.trim(), category.trim(), today, cost.toLong(), salvage.toLongOrNull() ?: 0L, life.toInt(), location.trim(), ""))
                },
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DepDialog(state: AssetUiState, onDismiss: () -> Unit, onSave: (DepreciationDraft) -> Unit) {
    val active = state.assets.filter { it.isActive }
    var selected by remember { mutableStateOf(active.firstOrNull()?.id ?: 0L) }
    var expanded by remember { mutableStateOf(false) }
    val persianDate = epochDayToPersian(currentEpochDay())
    var year by remember { mutableStateOf(persianDate.year.toString()) }
    var month by remember { mutableStateOf(persianDate.month.toString()) }
    val monthNumber = month.toIntOrNull()
    val valid = selected > 0L && (year.toIntOrNull() ?: 0) > 0 && monthNumber != null && monthNumber in 1..12

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت استهلاک ماهانه") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(active.firstOrNull { it.id == selected }?.name ?: "انتخاب دارایی", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    androidx.compose.material3.DropdownMenu(expanded, { expanded = false }) {
                        active.forEach { asset ->
                            androidx.compose.material3.DropdownMenuItem(
                                text = { Text(asset.name) },
                                onClick = { selected = asset.id; expanded = false },
                            )
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(year, { year = it.filter(Char::isDigit) }, label = { Text("سال") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(month, { month = it.filter(Char::isDigit) }, label = { Text("ماه") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                Text("با ثبت این عملیات، سند حسابداری استهلاک نیز صادر می‌شود.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(
                enabled = valid,
                onClick = { onSave(DepreciationDraft(selected, year.toInt(), month.toInt(), currentEpochDay())) },
            ) { Text("ثبت و صدور سند") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}
